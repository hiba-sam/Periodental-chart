# Rapport Final de Projet : Système de Charting Parodontal Moderne

## 1. Présentation du Projet
Ce projet consiste en la modernisation d'une application de diagnostic dentaire. L'objectif était de transformer un outil statique en une plateforme Full-Stack performante capable de gérer des données médicales précises, de les visualiser de manière interactive et de les stocker durablement.

---

## 2. Architecture Technique (La "Stack")
Le projet repose sur une architecture robuste et moderne :
- **Frontend** : Next.js 16 (App Router) + TypeScript.
- **Backend** : Node.js (API Routes intégrées à Next.js).
- **Base de Données** : PostgreSQL.
- **Rendu Graphique** : API Google Charts + Moteur `odonto.js`.
- **Styling** : CSS Vanille (Optimisation pour le format d'impression A4).

---

## 3. Innovation Frontend : De l'Image Statique à l'Interactivité
L'un des points forts du projet est la solution innovante pour le rendu des dents.

### La Solution "Interactive Layering" (Effet SVG)
Au lieu d'utiliser des images PNG mortes, nous avons créé un système de couches (layers) :
1. **Couche Anatomique (PNG)** : Fournit le visuel réaliste de la dent.
2. **Couche de Données (Vectorielle)** : Un graphique **Google Charts** transparent est superposé exactement sur la dent.
3. **Interactivité** : Lorsque l'utilisateur modifie une valeur (ex: Profondeur de sondage), le code JavaScript redessine instantanément la courbe vectorielle. 
   - **Bénéfice** : On obtient la précision mathématique du vectoriel (SVG-like) tout en gardant l'esthétique détaillée du médical.

---

## 4. Architecture Backend & Base de Données
Le système est conçu pour l'intégrité des données médicales.

### Schéma Relationnel (PostgreSQL)
L'organisation des données suit une logique clinique :
- **Table `patients`** : Identité du patient (Nom, Prénom, Date de naissance).
- **Table `chart_exams`** : Historique des sessions de diagnostic (Initial, Réévaluation).
- **Table `tooth_sites`** : Le cœur du système. Stocke les 192+ points de mesure par examen.
  - *Champs clés* : `tooth_number` (11-48), `site_position` (A, B, C), `pd` (Profondeur), `gm` (Gencive), `bop` (Saignement).

### Performance : Le Système "Batch"
Le backend utilise une route API spécifique (`/api/tooth-sites/batch`) capable de traiter des centaines de mesures en une seule transaction SQL. 
- **Sécurité** : Utilisation de `BEGIN` et `COMMIT` pour s'assurer que si un seul point échoue, la base de données reste propre (Atomicité).

---

## 5. Fonctionnalités Clés Implémentées
1. **Saisie Rapide** : Tableau de bord synchronisé avec le graphique visuel.
2. **Visualisation Dynamique** : Feedback visuel immédiat (les courbes rouges et bleues bougent en temps réel).
3. **Historisation** : Possibilité de comparer des examens à des dates différentes.
4. **Format Professionnel** : Mise en page strictement fixée à 980px pour une impression parfaite des rapports cliniques.

---

## 6. Conclusion pour la Soutenance
Ce projet démontre une maîtrise complète du cycle de développement :
- **Conception** : Schématisation de données complexes.
- **Développement** : Intégration de technologies modernes (React/Next) avec des outils de visualisation (Google Charts).
- **Sécurité** : Gestion rigoureuse des transactions en base de données pour garantir la fiabilité médicale.

---
*Rapport généré le 01 Mars 2026 pour la soutenance finale.*
