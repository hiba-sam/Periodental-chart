"use client";

import { useEffect } from "react";

// Upper palatin molars that need TWO furcation table cells: f{t}b-a + f{t}b-b
const PALATIN_TWO_CELL = [18, 17, 16, 14, 28, 27, 26, 24];
// Upper palatin multiroot teeth that need TWO visual furcation markers: furca{t}-a + furca{t}-b
const PALATIN_MULTIROOT_UPPER = [18, 17, 16, 26, 27, 28];

export default function LegacyToothChart() {
    const topRx = [18, 17, 16, 15, 14, 13, 12, 11];
    const topLx = [21, 22, 23, 24, 25, 26, 27, 28];
    const botLx = [48, 47, 46, 45, 44, 43, 42, 41];
    const botRx = [31, 32, 33, 34, 35, 36, 37, 38];

    useEffect(() => {
        // Load odonto.js only after the component mounts so elements exist
        const timer = setTimeout(() => {
            const script1 = document.createElement("script");
            script1.src = "/odonto.js?v=13";
            script1.async = false;
            document.body.appendChild(script1);

            const script2 = document.createElement("script");
            script2.src = "/legacy-inline.js?v=13";
            script2.async = false;
            document.body.appendChild(script2);
        }, 1500); // 1.5s to ensure google charts is ready
        return () => clearTimeout(timer);
    }, []);

    const toggleFurca = (id: string) => {
        const el = document.getElementById(id);
        if (!el) return;
        const current = parseInt(el.dataset.value || '0', 10);
        const next = (current + 1) % 4;
        el.dataset.value = next.toString();
        el.innerText = next > 0 ? next.toString() : '';
        el.style.fontWeight = 'bold';
        el.style.color = '#dc2626';
    };

    const toggleImplant = (id: string) => {
        const el = document.getElementById(id);
        if (!el) return;
        const active = el.dataset.active === 'true';
        const next = !active;
        el.dataset.active = next.toString();
        el.style.backgroundColor = next ? '#000' : 'transparent';
        el.style.borderRadius = '50%';
        el.style.width = '12px';
        el.style.height = '12px';
        el.style.margin = 'auto';
    };

    const renderToothHeaders = (teeth: number[]) => teeth.map(t => <td key={`d${t}`} className="borde"><div id={`d${t}`}>{Math.floor(t / 10)}.{t % 10}</div></td>);
    const renderImplants = (teeth: number[], suffix: string = '') => teeth.map(t => <td key={`i${t}${suffix}`} className="borde" onClick={() => toggleImplant(`i${t}${suffix}`)} style={{ cursor: 'pointer' }}><div id={`i${t}${suffix}`}></div></td>);
    const renderMobility = (teeth: number[], startingTab: number, suffix: string = '') => teeth.map((t, i) => <td key={`m${t}${suffix}`} className="borde"><input type="text" id={`m${t}${suffix}`} name={`m${t}${suffix}`} defaultValue="0" tabIndex={startingTab + i} onBlur={(e) => { (window as any).rangoNumero && (window as any).rangoNumero(e.target.id); }} /></td>);
    const renderPrognosis = (teeth: number[], startingTab: number, suffix: string = '') => teeth.map((t, i) => <td key={`pi${t}${suffix}`} className="borde"><input type="text" id={`pi${t}${suffix}`} name={`pi${t}${suffix}`} tabIndex={startingTab + i} /></td>);
    const renderFurca = (teeth: number[], suffix: string = '') => teeth.map(t => {
        const isMultiroot = [18, 17, 16, 26, 27, 28, 48, 47, 46, 36, 37, 38].includes(t);
        // Upper palatin molars need TWO separate furcation cells (CSS: #f17b-a, #f17b-b)
        const isTwoCell = suffix === 'b' && PALATIN_TWO_CELL.includes(t);
        if (isTwoCell) {
            return (
                <td key={`f${t}${suffix}`} className="borde" style={{ padding: 0 }}>
                    <div
                        id={`f${t}${suffix}-a`}
                        onClick={() => toggleFurca(`f${t}${suffix}-a`)}
                        style={{
                            cursor: 'pointer', display: 'inline-block', width: '45%', height: '18px',
                            background: '#fff', border: '1px solid #C3C9C8', borderRight: '1px solid #000',
                            boxSizing: 'border-box', verticalAlign: 'top', textAlign: 'center', fontSize: '9px'
                        }}
                    ></div>
                    <div
                        id={`f${t}${suffix}-b`}
                        onClick={() => toggleFurca(`f${t}${suffix}-b`)}
                        style={{
                            cursor: 'pointer', display: 'inline-block', width: '45%', height: '18px',
                            background: '#fff', border: '1px solid #C3C9C8',
                            boxSizing: 'border-box', verticalAlign: 'top', textAlign: 'center', fontSize: '9px'
                        }}
                    ></div>
                </td>
            );
        }
        return (
            <td key={`f${t}${suffix}`} className="borde"
                onClick={isMultiroot ? () => toggleFurca(`f${t}${suffix}`) : undefined}
                style={{ cursor: isMultiroot ? 'pointer' : 'default' }}>
                {isMultiroot ? <div id={`f${t}${suffix}`}></div> : null}
            </td>
        );
    });
    const renderBleeding = (teeth: number[], suffix: string = '') => teeth.map(t => <td key={`s${t}${suffix}`} className="borde"><div id={`s${t}${suffix}-a`}></div><div id={`s${t}${suffix}-b`}></div><div id={`s${t}${suffix}-c`}></div></td>);
    const renderPlaque = (teeth: number[], suffix: string = '') => teeth.map(t => <td key={`p${t}${suffix}`} className="borde"><div id={`p${t}${suffix}-a`}></div><div id={`p${t}${suffix}-b`}></div><div id={`p${t}${suffix}-c`}></div></td>);
    const renderCAL = (teeth: number[], startingTab: number, suffix: string = '') => teeth.map((t, i) => (
        <td key={`ae${t}${suffix}`} className="borde">
            <input type="text" id={`ae${t}${suffix}-a`} name={`ae${t}${suffix}-a`} defaultValue="0" tabIndex={startingTab + (i * 3)} />
            <input type="text" id={`ae${t}${suffix}-b`} name={`ae${t}${suffix}-b`} defaultValue="0" tabIndex={startingTab + (i * 3) + 1} />
            <input type="text" id={`ae${t}${suffix}-c`} name={`ae${t}${suffix}-c`} defaultValue="0" tabIndex={startingTab + (i * 3) + 2} />
        </td>
    ));

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const id = e.target.id; // e.g. ps18-a or mg18b-a
        // Match prefix, tooth number, suffix (optional 'b'), and site (a, b, or c)
        const match = id.match(/^(ps|mg|ae)(\d+)(b?)-(a|b|c)$/);
        if (!match) return;

        const [_, prefix, tooth, suffix, site] = match;
        const psId = `ps${tooth}${suffix}-${site}`;
        const mgId = `mg${tooth}${suffix}-${site}`;
        const calId = `ae${tooth}${suffix}-${site}`;

        const psEl = document.getElementById(psId) as HTMLInputElement;
        const mgEl = document.getElementById(mgId) as HTMLInputElement;
        const calEl = document.getElementById(calId) as HTMLInputElement;

        if (psEl && mgEl && calEl) {
            const psVal = parseInt(psEl.value || '0', 10);
            const mgVal = parseInt(mgEl.value || '0', 10);
            calEl.value = (psVal + mgVal).toString();
        }
    };

    const renderGingivalMargin = (teeth: number[], startingTab: number, suffix: string = '') => teeth.map((t, i) => (
        <td key={`mg${t}${suffix}`} className="borde">
            <input type="text" id={`mg${t}${suffix}-a`} name={`mg${t}${suffix}-a`} defaultValue="0" tabIndex={startingTab + (i * 3)} onChange={handleInputChange} />
            <input type="text" id={`mg${t}${suffix}-b`} name={`mg${t}${suffix}-b`} defaultValue="0" tabIndex={startingTab + (i * 3) + 1} onChange={handleInputChange} />
            <input type="text" id={`mg${t}${suffix}-c`} name={`mg${t}${suffix}-c`} defaultValue="0" tabIndex={startingTab + (i * 3) + 2} onChange={handleInputChange} />
        </td>
    ));

    const renderProbingDepth = (teeth: number[], startingTab: number, suffix: string = '') => teeth.map((t, i) => (
        <td key={`ps${t}${suffix}`} className="borde">
            <input type="text" id={`ps${t}${suffix}-a`} name={`ps${t}${suffix}-a`} defaultValue="0" tabIndex={startingTab + (i * 3)} onChange={handleInputChange} />
            <input type="text" id={`ps${t}${suffix}-b`} name={`ps${t}${suffix}-b`} defaultValue="0" tabIndex={startingTab + (i * 3) + 1} onChange={handleInputChange} />
            <input type="text" id={`ps${t}${suffix}-c`} name={`ps${t}${suffix}-c`} defaultValue="0" tabIndex={startingTab + (i * 3) + 2} onChange={handleInputChange} />
        </td>
    ));

    const renderVisuals = (teeth: number[], suffix: string = '') => teeth.map((t, index) => {
        const isInf = suffix === 'b' && t > 30;
        const isMultiroot = [18, 17, 16, 26, 27, 28, 48, 47, 46, 36, 37, 38].includes(t);
        // Upper palatin multiroot teeth need two separate visual markers: furca{t}-a and furca{t}-b
        // (positioned at different locations per CSS: margin-top 70px / 80px+28px)
        const isPalatinMultiroot = suffix === 'b' && PALATIN_MULTIROOT_UPPER.includes(t);
        return (
            <td key={`v${t}${suffix}`} className="noborde status-tooth-container">
                <div id={`diente${t}${suffix}-a`} className="status-tooth-background">
                    {isMultiroot && !isPalatinMultiroot && (
                        <div id={`furca${t}${suffix}`}></div>
                    )}
                    {isPalatinMultiroot && (
                        <>
                            <div id={`furca${t}-a`}></div>
                            <div id={`furca${t}-b`}></div>
                        </>
                    )}
                </div>
                <div className={isInf ? "status-grid-inf" : "status-grid-sup"}></div>
                <div id={`visualization${t}${suffix === '' ? 'a' : 'b'}`} className="status-chart-overlay"></div>
            </td>
        );
    });

    return (
        <>
            <table id="separador">
                <tbody>
                    <tr><td>SUPERIOR</td></tr>
                </tbody>
            </table>

            <table id="tabla-superior">
                <tbody>
                    <tr>
                        <td>
                            <table id="tabla-1">
                                <tbody>
                                    <tr><td></td>{renderToothHeaders(topRx)}</tr>
                                    <tr><td className="titulo">Mobilité</td>{renderMobility(topRx, 1)}</tr>
                                    <tr><td className="titulo">Implant</td>{renderImplants(topRx)}</tr>
                                    <tr><td className="titulo">Furcation</td>{renderFurca(topRx)}</tr>
                                    <tr><td className="titulo">Saignement au sondage</td>{renderBleeding(topRx)}</tr>
                                    <tr><td className="titulo">Plaque</td>{renderPlaque(topRx)}</tr>
                                    <tr><td className="titulo">Niveau gingival</td>{renderGingivalMargin(topRx, 49)}</tr>
                                    <tr><td className="titulo">Profondeur de sondage</td>{renderProbingDepth(topRx, 97)}</tr>
                                    <tr><td className="titulo">Niv. d'attache</td>{renderCAL(topRx, 457)}</tr>
                                    <tr><td className="titulo">Vestibulaire</td>{renderVisuals(topRx)}</tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table id="tabla-2">
                                <tbody>
                                    <tr><td className="titulo"></td>{renderToothHeaders(topLx)}</tr>
                                    <tr><td className="titulo"></td>{renderMobility(topLx, 9)}</tr>
                                    <tr><td className="titulo"></td>{renderImplants(topLx)}</tr>
                                    <tr><td className="titulo"></td>{renderFurca(topLx)}</tr>
                                    <tr><td className="titulo"></td>{renderBleeding(topLx)}</tr>
                                    <tr><td className="titulo"></td>{renderPlaque(topLx)}</tr>
                                    <tr><td className="titulo"></td>{renderGingivalMargin(topLx, 73)}</tr>
                                    <tr><td className="titulo"></td>{renderProbingDepth(topLx, 121)}</tr>
                                    <tr><td className="titulo"></td>{renderCAL(topLx, 481)}</tr>
                                    <tr><td className="titulo"></td>{renderVisuals(topLx)}</tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table id="tabla-3">
                                <tbody>
                                    <tr><td className="titulo">Palatin</td>{renderVisuals(topRx, 'b')}</tr>
                                    <tr><td className="titulo">Niveau gingival</td>{renderGingivalMargin(topRx, 193, 'b')}</tr>
                                    <tr><td className="titulo">Profondeur de sondage</td>{renderProbingDepth(topRx, 145, 'b')}</tr>
                                    <tr><td className="titulo">Niv. d'attache</td>{renderCAL(topRx, 505, 'b')}</tr>
                                    <tr><td className="titulo">Plaque</td>{renderPlaque(topRx, 'b')}</tr>
                                    <tr><td className="titulo">Saignement au sondage</td>{renderBleeding(topRx, 'b')}</tr>
                                    <tr><td className="titulo">Furcation</td>{renderFurca(topRx, 'b')}</tr>
                                    <tr><td className="titulo">Note</td>{renderPrognosis(topRx, 241)}</tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table id="tabla-4">
                                <tbody>
                                    <tr><td className="titulo"></td>{renderVisuals(topLx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderGingivalMargin(topLx, 217, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderProbingDepth(topLx, 169, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderCAL(topLx, 529, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderPlaque(topLx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderBleeding(topLx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderFurca(topLx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderPrognosis(topLx, 249)}</tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>

            {/* Calculations Summary Panel */}
            <div className="my-1 bg-white border-y-[4px] border-black p-2 flex flex-wrap justify-center items-center text-black text-xs font-semibold gap-8">
                <div className="flex items-center space-x-1">
                    <span>Prof. de sondage moyenne =</span>
                    <div id="suma4" className="font-bold">0</div>
                    <span>mm</span>
                </div>
                <div className="flex items-center space-x-1">
                    <span>Niv. d'attache moyen =</span>
                    <div id="suma5" className="font-bold">0</div>
                    <span>mm</span>
                </div>
                <div className="flex items-center space-x-1">
                    <div id="suma2" className="font-bold">0</div>
                    <span>% Plaque</span>
                </div>
                <div className="flex items-center space-x-1">
                    <div id="suma" className="font-bold">0</div>
                    <span>% Saignement au sondage</span>
                </div>
            </div>

            <table id="separador">
                <tbody>
                    <tr><td>INFERIOR</td></tr>
                </tbody>
            </table>

            <table id="tabla-inferior">
                <tbody>
                    <tr>
                        <td>
                            <table id="tabla-5">
                                <tbody>
                                    <tr><td className="titulo">Note</td>{renderPrognosis(botLx, 257)}</tr>
                                    <tr><td className="titulo">Furcation</td>{renderFurca(botLx)}</tr>
                                    <tr><td className="titulo">Saignement au sondage</td>{renderBleeding(botLx)}</tr>
                                    <tr><td className="titulo">Plaque</td>{renderPlaque(botLx)}</tr>
                                    <tr><td className="titulo">Niveau gingival</td>{renderGingivalMargin(botLx, 297)}</tr>
                                    <tr><td className="titulo">Profondeur de sondage</td>{renderProbingDepth(botLx, 345)}</tr>
                                    <tr><td className="titulo">Niv. d'attache</td>{renderCAL(botLx, 553)}</tr>
                                    <tr><td className="titulo">Lingual</td>{renderVisuals(botLx)}</tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table id="tabla-6">
                                <tbody>
                                    <tr><td className="titulo"></td>{renderPrognosis(botRx, 265)}</tr>
                                    <tr><td className="titulo"></td>{renderFurca(botRx)}</tr>
                                    <tr><td className="titulo"></td>{renderBleeding(botRx)}</tr>
                                    <tr><td className="titulo"></td>{renderPlaque(botRx)}</tr>
                                    <tr><td className="titulo"></td>{renderGingivalMargin(botRx, 321)}</tr>
                                    <tr><td className="titulo"></td>{renderProbingDepth(botRx, 409)}</tr>
                                    <tr><td className="titulo"></td>{renderCAL(botRx, 577)}</tr>
                                    <tr><td className="titulo"></td>{renderVisuals(botRx)}</tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table id="tabla-7">
                                <tbody>
                                    <tr><td className="titulo">Vestibulaire</td>{renderVisuals(botLx, 'b')}</tr>
                                    <tr><td className="titulo">Niveau gingival</td>{renderGingivalMargin(botLx, 309, 'b')}</tr>
                                    <tr><td className="titulo">Profondeur de sondage</td>{renderProbingDepth(botLx, 369, 'b')}</tr>
                                    <tr><td className="titulo">Niv. d'attache</td>{renderCAL(botLx, 601, 'b')}</tr>
                                    <tr><td className="titulo">Plaque</td>{renderPlaque(botLx, 'b')}</tr>
                                    <tr><td className="titulo">Saignement au sondage</td>{renderBleeding(botLx, 'b')}</tr>
                                    <tr><td className="titulo">Furcation</td>{renderFurca(botLx, 'b')}</tr>
                                    <tr><td className="titulo">Implant</td>{renderImplants(botLx, 'b')}</tr>
                                    <tr><td className="titulo">Mobilité</td>{renderMobility(botLx, 17, 'b')}</tr>
                                    <tr><td></td>{renderToothHeaders(botLx)}</tr>
                                </tbody>
                            </table>
                        </td>
                        <td>
                            <table id="tabla-8">
                                <tbody>
                                    <tr><td className="titulo"></td>{renderVisuals(botRx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderGingivalMargin(botRx, 333, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderProbingDepth(botRx, 433, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderCAL(botRx, 625, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderPlaque(botRx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderBleeding(botRx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderFurca(botRx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderImplants(botRx, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderMobility(botRx, 25, 'b')}</tr>
                                    <tr><td className="titulo"></td>{renderToothHeaders(botRx)}</tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </>
    );
}
