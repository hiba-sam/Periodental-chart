import { NextResponse } from 'next/server';
import { getClient } from '@/lib/db';

export async function POST(request: Request) {
    const client = await getClient();
    try {
        const body = await request.json();
        const { patient_id, sites } = body;

        if (!patient_id || !Array.isArray(sites)) {
            return NextResponse.json({ error: 'invalid payload' }, { status: 400 });
        }

        await client.query('BEGIN');

        // Delete existing points (we assume the client always sends the full latest state)
        await client.query('DELETE FROM tooth_sites WHERE patient_id = $1', [patient_id]);

        // Insert new points
        for (const site of sites) {
            await client.query(
                `INSERT INTO tooth_sites (patient_id, tooth_number, site_position, pd, gm, cal, bop, plaque, mobility, furcation, implant, prognosis)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
                [
                    patient_id,
                    site.tooth_number,
                    site.site_location,
                    site.probing_depth || 0,
                    site.gingival_margin || 0,
                    site.cal || 0,
                    site.bleeding_on_probing || false,
                    site.plaque || false,
                    site.mobility || 0,
                    site.furcation || 0,
                    site.implant || false,
                    site.prognosis || ''
                ]
            );
        }

        await client.query('COMMIT');

        return NextResponse.json({ success: true }, { status: 201 });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error batch inserting tooth sites:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    } finally {
        client.release();
    }
}
