"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import ToothSitesTable from "@/components/ToothSitesTable";
import LegacyToothChart from "@/components/LegacyToothChart";

export default function PatientChartPage() {
    const params = useParams();
    const router = useRouter();
    const patientId = params.id as string;

    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'visual' | 'table'>('visual');

    // Patient Form State
    const [patientInfo, setPatientInfo] = useState({
        first_name: '',
        last_name: '',
        date_of_birth: ''
    });
    const [isSaving, setIsSaving] = useState(false);
    const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

    // Safe date formatter for <input type="date">
    const safeISODate = (dateStr: string | null | undefined) => {
        if (!dateStr) return '';
        try {
            const d = new Date(dateStr);
            if (isNaN(d.getTime())) return '';
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            // Ensure year is 4 digits
            if (y > 9999 || y < 1000) return '';
            return `${y}-${m}-${day}`;
        } catch (e) {
            return '';
        }
    };

    useEffect(() => {
        async function fetchData() {
            try {
                // Fetch tooth sites
                const sitesResponse = await fetch(`/api/tooth-sites?patient_id=${patientId}`);
                if (sitesResponse.ok) {
                    const sites = await sitesResponse.json();
                    setData(sites);
                }

                // Fetch patient info
                const patientResponse = await fetch(`/api/patients/${patientId}`);
                if (patientResponse.ok) {
                    const patient = await patientResponse.json();
                    if (patient) {
                        setPatientInfo({
                            first_name: patient.first_name || '',
                            last_name: patient.last_name || '',
                            date_of_birth: patient.date_of_birth ? new Date(patient.date_of_birth).toISOString().split('T')[0] : ''
                        });
                    }
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                setLoading(false);
            }
        }

        if (patientId) {
            fetchData();
        }
    }, [patientId]);
    useEffect(() => {
        // Hydrate the visual legacy chart when data arrives
        if (data.length > 0 && activeTab === 'visual') {
            // Add a small delay to ensure DOM nodes in LegacyToothChart are fully mounted
            setTimeout(() => {
                // reset all first or let them be overwritten? Overwriting is better to support re-renders.
                data.forEach(site => {
                    const t = site.tooth_number;
                    // 'a', 'b' or 'c'
                    const loc = site.site_location;
                    if (!loc) return;
                    if (site.probing_depth > 0) {
                        const el = document.getElementById(`ps${t}${loc}`) as HTMLInputElement;
                        if (el) el.value = site.probing_depth.toString();
                    }
                    if (site.gingival_margin > 0) {
                        const el = document.getElementById(`mg${t}${loc}`) as HTMLInputElement;
                        if (el) el.value = site.gingival_margin.toString();
                    }
                    if (site.cal > 0) {
                        const el = document.getElementById(`ae${t}${loc}`) as HTMLInputElement;
                        if (el) el.value = site.cal.toString();
                    }
                    if (site.bleeding_on_probing) {
                        const el = document.getElementById(`s${t}${loc}`);
                        if (el) el.style.backgroundColor = '#58ACFA';
                    }
                    if (site.plaque) {
                        const el = document.getElementById(`p${t}${loc}`);
                        if (el) el.style.backgroundColor = '#58ACFA';
                    }

                    // Hydrate new tooth-level fields (mobility, furcation, implant, prognosis)
                    // These are usually on site_location suffix '-a' or 'b-a'
                    if (typeof loc === 'string' && loc.endsWith('-a')) {
                        const su = loc.startsWith('b') ? 'b' : '';
                        if (site.mobility !== undefined) {
                            const el = document.getElementById(`m${t}${su}`) as HTMLInputElement;
                            if (el) el.value = site.mobility.toString();
                        }
                        if (site.prognosis) {
                            const el = document.getElementById(`pi${t}${su}`) as HTMLInputElement;
                            if (el) el.value = site.prognosis;
                        }
                        if (site.furcation !== undefined) {
                            // Upper palatin molars have two cells: f{t}b-a and f{t}b-b
                            const palatinTwoCell = [18, 17, 16, 14, 28, 27, 26, 24];
                            if (su === 'b' && palatinTwoCell.includes(t)) {
                                const elA = document.getElementById(`f${t}${su}-a`);
                                if (elA) {
                                    elA.dataset.value = site.furcation.toString();
                                    elA.innerText = site.furcation > 0 ? site.furcation.toString() : '';
                                    (elA as HTMLElement).style.fontWeight = 'bold';
                                    (elA as HTMLElement).style.color = '#dc2626';
                                }
                            } else {
                                const el = document.getElementById(`f${t}${su}`);
                                if (el) {
                                    el.dataset.value = site.furcation.toString();
                                    el.innerText = site.furcation > 0 ? site.furcation.toString() : '';
                                }
                            }
                        }
                        if (site.implant) {
                            const el = document.getElementById(`i${t}${su}`);
                            if (el) {
                                el.dataset.active = 'true';
                                el.style.backgroundColor = '#000'; // Placeholder for implant visual
                            }
                        }
                    }
                });

                // Trigger re-draws for modified teeth using the legacy global window functions
                // Only draw charts for sides that have actual non-zero data (prevents blue ghost line)
                const uniqueTeeth = Array.from(new Set(data.map(d => d.tooth_number)));
                uniqueTeeth.forEach(t => {
                    const globalWindow = window as any;
                    ['a', 'b'].forEach(suffix => {
                        const fnName = `cargar${t}${suffix}`;
                        if (typeof globalWindow[fnName] === 'function') {
                            globalWindow[fnName]();
                        }
                    });
                });
            }, 500);
        }
    }, [data, activeTab]);

    const handleExportCAL = () => {
        // Collect CAL = PD + GM for all teeth
        const teeth = [
            { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: '', label: 'Sup Droit' },
            { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: '', label: 'Sup Gauche' },
            { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: 'b', label: 'Sup Droit (Palatin)' },
            { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: 'b', label: 'Sup Gauche (Palatin)' },
            { teeth: [48, 47, 46, 45, 44, 43, 42, 41], suffix: '', label: 'Inf Gauche' },
            { teeth: [31, 32, 33, 34, 35, 36, 37, 38], suffix: '', label: 'Inf Droit' },
            { teeth: [48, 47, 46, 45, 44, 43, 42, 41], suffix: 'b', label: 'Inf Gauche (Vestib)' },
            { teeth: [31, 32, 33, 34, 35, 36, 37, 38], suffix: 'b', label: 'Inf Droit (Vestib)' },
        ];

        const getVal = (id: string) => {
            const el = document.getElementById(id) as HTMLInputElement;
            return el && el.value ? parseInt(el.value, 10) : 0;
        };

        const rows: string[] = ['Quadrant,Dent,Site,PS (mm),MG (mm),CAL (mm)'];

        for (const row of teeth) {
            for (const t of row.teeth) {
                const su = row.suffix;
                for (const loc of ['a', 'b', 'c']) {
                    const ps = getVal(`ps${t}${su}-${loc}`);
                    const mg = getVal(`mg${t}${su}-${loc}`);
                    const cal = ps + mg;
                    if (ps > 0 || mg > 0) {
                        const toothLabel = `${Math.floor(t / 10)}.${t % 10}`;
                        rows.push(`${row.label},${toothLabel},${loc.toUpperCase()},${ps},${mg},${cal}`);
                    }
                }
            }
        }

        const csvContent = rows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `CAL_patient_${patientId}.csv`;
        link.click();
        URL.revokeObjectURL(url);
    };

    const handleExportPSBOP = () => {
        const teeth = [
            { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: '', label: 'Sup Droit' },
            { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: '', label: 'Sup Gauche' },
            { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: 'b', label: 'Sup Droit (Palatin)' },
            { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: 'b', label: 'Sup Gauche (Palatin)' },
            { teeth: [48, 47, 46, 45, 44, 43, 42, 41], suffix: '', label: 'Inf Gauche' },
            { teeth: [31, 32, 33, 34, 35, 36, 37, 38], suffix: '', label: 'Inf Droit' },
        ];
        const getVal = (id: string) => { const e = document.getElementById(id) as HTMLInputElement; return e?.value ? parseInt(e.value, 10) : 0; };
        const isBOP = (id: string) => { const e = document.getElementById(id); if (!e) return false; const bg = e.style.backgroundColor; return bg === 'rgb(88, 172, 250)' || bg === '#58ACFA'; };
        const rows: string[] = ['Quadrant,Dent,Site,PS (mm),BOP'];
        for (const row of teeth) {
            for (const t of row.teeth) {
                const su = row.suffix;
                for (const loc of ['a', 'b', 'c']) {
                    const ps = getVal(`ps${t}${su}-${loc}`);
                    const bop = isBOP(`s${t}${su}-${loc}`) ? 'Oui' : 'Non';
                    if (ps > 0) rows.push(`${row.label},${Math.floor(t / 10)}.${t % 10},${loc.toUpperCase()},${ps},${bop}`);
                }
            }
        }
        const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a'); a.href = url; a.download = `PSBOP_patient_${patientId}.csv`; a.click();
        URL.revokeObjectURL(url);
    };

    const handlePrint = () => window.print();

    const handleSavePatient = async () => {
        setIsSaving(true);
        setSaveStatus('idle');
        try {
            // Save patient metadata
            const res = await fetch(`/api/patients/${patientId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(patientInfo)
            });

            if (!res.ok) throw new Error('Failed to save patient metadata');

            // --- Scraping Legacy DOM values ---
            const sites: any[] = [];
            const teethRows = [
                { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: '' },
                { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: '' },
                { teeth: [18, 17, 16, 15, 14, 13, 12, 11], suffix: 'b' },
                { teeth: [21, 22, 23, 24, 25, 26, 27, 28], suffix: 'b' },
                { teeth: [48, 47, 46, 45, 44, 43, 42, 41], suffix: '' },
                { teeth: [31, 32, 33, 34, 35, 36, 37, 38], suffix: '' },
                { teeth: [48, 47, 46, 45, 44, 43, 42, 41], suffix: 'b' },
                { teeth: [31, 32, 33, 34, 35, 36, 37, 38], suffix: 'b' },
            ];

            const parseVal = (id: string) => {
                const el = document.getElementById(id) as HTMLInputElement;
                return el && el.value ? parseInt(el.value, 10) : 0;
            };

            const isBlueBackground = (id: string) => {
                const el = document.getElementById(id);
                if (!el) return false;
                const bg = el.style.backgroundColor;
                // legacy chart sets background to #58ACFA rgb(88, 172, 250) natively when clicked
                return bg === 'rgb(88, 172, 250)' || bg === '#58ACFA' || bg === '#58acfa';
            };

            for (const row of teethRows) {
                for (const t of row.teeth) {
                    const su = row.suffix; // '' or 'b'
                    // PD (Probing Depth) inputs: ps18-a
                    const pdA = parseVal(`ps${t}${su}-a`);
                    const pdB = parseVal(`ps${t}${su}-b`);
                    const pdC = parseVal(`ps${t}${su}-c`);

                    // GM (Gingival Margin) inputs: mg18-a
                    const gmA = parseVal(`mg${t}${su}-a`);
                    const gmB = parseVal(`mg${t}${su}-b`);
                    const gmC = parseVal(`mg${t}${su}-c`);

                    // BOP (Bleeding on probing) elements: s18-a (background color toggle)
                    const bopA = isBlueBackground(`s${t}${su}-a`);
                    const bopB = isBlueBackground(`s${t}${su}-b`);
                    const bopC = isBlueBackground(`s${t}${su}-c`);

                    // Plaque elements: p18-a (background color toggle)
                    const plaqueA = isBlueBackground(`p${t}${su}-a`);
                    const plaqueB = isBlueBackground(`p${t}${su}-b`);
                    const plaqueC = isBlueBackground(`p${t}${su}-c`);

                    // CAL (Attachment level) inputs: ae18-a (calculated or inputted sometimes, using as cal)
                    const calA = parseVal(`ae${t}${su}-a`);
                    const calB = parseVal(`ae${t}${su}-b`);
                    const calC = parseVal(`ae${t}${su}-c`);

                    // New fields: mobility, furcation, implant, prognosis (stored once per tooth side)
                    const mobility = parseVal(`m${t}${su}`);
                    const prognosisEl = document.getElementById(`pi${t}${su}`) as HTMLInputElement;
                    const prognosis = prognosisEl ? prognosisEl.value : '';

                    // Furcation and Implant are divs that toggle. We check their style/background or text.
                    // For now, assume they might have a custom data attribute if we added it, 
                    // or we check if they have content. 
                    // Let's check for standard legacy values if we can find them.
                    // Upper palatin molars use two cells: f{t}b-a and f{t}b-b
                    const palatinTwoCell = [18, 17, 16, 14, 28, 27, 26, 24];
                    let furcation = 0;
                    if (su === 'b' && palatinTwoCell.includes(t)) {
                        const furcaElA = document.getElementById(`f${t}${su}-a`);
                        const furcaElB = document.getElementById(`f${t}${su}-b`);
                        const valA = furcaElA ? parseInt(furcaElA.dataset.value || '0', 10) : 0;
                        const valB = furcaElB ? parseInt(furcaElB.dataset.value || '0', 10) : 0;
                        furcation = Math.max(valA, valB);
                    } else {
                        const furcaEl = document.getElementById(`f${t}${su}`);
                        furcation = furcaEl ? parseInt(furcaEl.dataset.value || '0', 10) : 0;
                    }

                    const implantEl = document.getElementById(`i${t}${su}`);
                    const implant = implantEl ? implantEl.dataset.active === 'true' : false;

                    const common = { mobility, furcation, implant, prognosis };

                    if (pdA || gmA || bopA || plaqueA || calA || mobility || furcation || implant || prognosis)
                        sites.push({ tooth_number: t, site_location: `${su}-a`, probing_depth: pdA, gingival_margin: gmA, bleeding_on_probing: bopA, plaque: plaqueA, cal: calA, ...common });
                    if (pdB || gmB || bopB || plaqueB || calB)
                        sites.push({ tooth_number: t, site_location: `${su}-b`, probing_depth: pdB, gingival_margin: gmB, bleeding_on_probing: bopB, plaque: plaqueB, cal: calB });
                    if (pdC || gmC || bopC || plaqueC || calC)
                        sites.push({ tooth_number: t, site_location: `${su}-c`, probing_depth: pdC, gingival_margin: gmC, bleeding_on_probing: bopC, plaque: plaqueC, cal: calC });
                }
            }

            const batchRes = await fetch('/api/tooth-sites/batch', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ patient_id: parseInt(patientId), sites })
            });

            if (!batchRes.ok) throw new Error('Failed to save tooth sites');

            setSaveStatus('success');
            // Re-fetch to update table
            const sitesResponse = await fetch(`/api/tooth-sites?patient_id=${patientId}`);
            if (sitesResponse.ok) {
                const refreshedSites = await sitesResponse.json();
                setData(refreshedSites);
            }

            setTimeout(() => setSaveStatus('idle'), 3000);
        } catch (error) {
            console.error("Failed to save patient", error);
            setSaveStatus('error');
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="flex flex-col items-center bg-white min-h-screen pt-4">
            {/* Floating right-side export panel */}
            <div style={{
                position: 'fixed', right: '12px', top: '50%', transform: 'translateY(-50%)',
                display: 'flex', flexDirection: 'column', gap: '6px', zIndex: 1000
            }}>
                {/* Print */}
                <button
                    onClick={handlePrint}
                    title="Imprimer"
                    style={{ background: '#f4f4f4', border: '1px solid #ddd', borderRadius: '8px', padding: '8px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', fontSize: '10px', gap: '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}
                >
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 6 2 18 2 18 9" /><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" /><rect x="6" y="14" width="12" height="8" /></svg>
                </button>
                {/* Export full CSV */}
                <button
                    onClick={handleSavePatient}
                    title="Exporter données"
                    style={{ background: '#f4f4f4', border: '1px solid #ddd', borderRadius: '8px', padding: '8px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', fontSize: '10px', gap: '2px', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}
                >
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" /></svg>
                </button>
                {/* Export PS/BOP */}
                <button
                    onClick={handleExportPSBOP}
                    title="Exporter PS/BOP"
                    style={{ background: '#f4f4f4', border: '1px solid #ddd', borderRadius: '8px', padding: '8px 6px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', fontSize: '10px', gap: '2px', fontWeight: 'bold', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}
                >
                    PS/BOP
                </button>
                {/* Export CAL */}
                <button
                    onClick={handleExportCAL}
                    title="Exporter CAL (Niveau d'attache)"
                    style={{ background: '#0044cc', color: '#fff', border: '1px solid #0033aa', borderRadius: '8px', padding: '8px 6px', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', fontSize: '10px', gap: '2px', fontWeight: 'bold', boxShadow: '0 1px 3px rgba(0,0,0,0.15)' }}
                >
                    CAL
                </button>
            </div>
            {/* Header Navigation Tab (Minimalist) */}
            <div className="mb-2 max-w-[980px] w-full flex justify-between px-2">
                <button
                    onClick={() => router.push('/patients')}
                    className="text-blue-600 hover:text-blue-800 text-sm font-semibold transition-colors flex items-center"
                >
                    <span className="mr-1">←</span> Retour à la liste des patients
                </button>
                <div className="flex space-x-2">
                    {activeTab === 'visual' ? (
                        <button onClick={() => setActiveTab('table')} className="text-gray-500 hover:text-gray-700 text-sm">Vue Tableau</button>
                    ) : (
                        <button onClick={() => setActiveTab('visual')} className="text-gray-500 hover:text-gray-700 text-sm">Vue Visuelle</button>
                    )}
                </div>
            </div>

            <div id="wrapper" className="periodontograma-legacy-wrapper" style={{ margin: '0 auto', width: '980px' }}>
                {/* Legacy Header Table */}
                <table id="tabla-titulo">
                    <tbody>
                        <tr>
                            <td>
                                {/* Removed non-existent logo */}
                            </td>
                            <td>
                                <div className="flex justify-between items-center w-full">
                                    <span style={{ fontSize: '24px', fontWeight: 'bold' }}>STATUS PARODONTAL</span>
                                    <div className="flex items-center space-x-2">
                                        <button
                                            onClick={handleSavePatient}
                                            disabled={isSaving}
                                            className="bg-[#0044cc] hover:bg-[#003399] text-white font-bold py-1 px-4 rounded shadow text-sm disabled:opacity-50"
                                            style={{ background: 'linear-gradient(to bottom, #4477D8, #0D47A1)', border: '1px solid #002266' }}
                                        >
                                            {isSaving ? 'Enregistrement...' : 'Sauvegarder'}
                                        </button>
                                        {saveStatus === 'success' && <span className="text-green-600 text-sm ml-2">✓</span>}
                                        {saveStatus === 'error' && <span className="text-red-500 text-sm ml-2">Erreur</span>}
                                        <label style={{ marginLeft: '15px' }}>Date</label>
                                        <input
                                            type="date"
                                            name="date"
                                            className="bg-[#E5EAE9] outline-none px-1 text-sm border border-gray-300"
                                            style={{ width: '130px', height: '22px' }}
                                        />
                                    </div>
                                </div>

                                <br />

                                <label>Nom</label>
                                <input
                                    type="text"
                                    id="apellidos"
                                    name="apellidos"
                                    value={patientInfo.last_name || ''}
                                    onChange={(e) => setPatientInfo({ ...patientInfo, last_name: e.target.value })}
                                    className="bg-[#E5EAE9] outline-none"
                                    style={{ width: '180px', marginLeft: '10px' }}
                                />

                                <label style={{ marginLeft: '20px' }}>Prénom</label>
                                <input
                                    type="text"
                                    id="paciente"
                                    name="paciente"
                                    value={patientInfo.first_name || ''}
                                    onChange={(e) => setPatientInfo({ ...patientInfo, first_name: e.target.value })}
                                    className="bg-[#E5EAE9] outline-none"
                                    style={{ width: '180px', marginLeft: '10px' }}
                                />

                                <label style={{ marginLeft: '20px' }}>Date de naissance</label>
                                <input
                                    type="date"
                                    id="fecha"
                                    name="fecha"
                                    value={safeISODate(patientInfo.date_of_birth)}
                                    onChange={(e) => setPatientInfo({ ...patientInfo, date_of_birth: e.target.value })}
                                    className="bg-[#E5EAE9] outline-none"
                                />

                                <br />
                                <div style={{ marginTop: '10px', display: 'flex', alignItems: 'center' }}>
                                    <input type="checkbox" id="examen_initial" style={{ width: 'auto', margin: '0 5px 0 0' }} />
                                    <label style={{ margin: '0 15px 0 0', fontWeight: 'bold' }}>Examen initial</label>

                                    <input type="checkbox" id="reevaluation" style={{ width: 'auto', margin: '0 5px 0 0' }} />
                                    <label style={{ margin: '0', fontWeight: 'bold' }}>Réévaluation</label>

                                    <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center' }}>
                                        <label style={{ marginRight: '5px' }}>Praticien</label>
                                        <input type="text" style={{ width: '150px' }} className="bg-[#E5EAE9] outline-none" />
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>

                {activeTab === 'visual' ? (
                    <LegacyToothChart />
                ) : (
                    <div className="bg-white p-4 mt-4 border border-gray-200" style={{ minHeight: '800px' }}>
                        <ToothSitesTable data={data} />
                    </div>
                )}
            </div>
        </div>
    );
}
