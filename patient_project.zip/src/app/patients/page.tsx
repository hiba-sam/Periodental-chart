"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function PatientsDashboard() {
    const [patients, setPatients] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
        async function fetchPatients() {
            try {
                const response = await fetch('/api/patients');
                if (response.ok) {
                    const data = await response.json();
                    setPatients(data);
                }
            } catch (error) {
                console.error("Error fetching patients list:", error);
            } finally {
                setLoading(false);
            }
        }
        fetchPatients();
    }, []);

    const handleCreateNew = async () => {
        try {
            const res = await fetch('/api/patients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ first_name: '', last_name: 'Nouveau Patient', date_of_birth: null })
            });

            if (res.ok) {
                const newPatient = await res.json();
                router.push(`/patients/${newPatient.id}/chart`);
            } else {
                alert("Erreur: Impossible de créer un nouveau patient. Base de données indisponible?");
            }
        } catch (error) {
            console.error("Failed to create new patient:", error);
            alert("Erreur de connexion.");
        }
    };

    return (
        <div className="container mx-auto p-8 max-w-5xl">
            <div className="flex justify-between items-center mb-8 border-b-2 border-slate-200 pb-4">
                <h1 className="text-4xl font-extrabold text-slate-800 tracking-tight">Liste des Patients</h1>

                <button
                    onClick={handleCreateNew}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-lg shadow-sm transition-colors"
                >
                    + Nouveau Patient
                </button>
            </div>

            {loading ? (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
            ) : patients.length === 0 ? (
                <div className="bg-slate-50 p-12 rounded-xl border border-slate-200 text-center">
                    <p className="text-xl text-slate-600 mb-4">La liste est vide, ou la base de données PostgreSQL n'est pas connectée.</p>
                    <p className="text-slate-500 mb-6">Assurez-vous que Docker Desktop fonctionne et que `docker compose up -d` a été exécuté.</p>
                </div>
            ) : (
                <div className="bg-white rounded-xl shadow border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-slate-50 border-b border-slate-200">
                                <th className="p-4 font-semibold text-slate-700">ID</th>
                                <th className="p-4 font-semibold text-slate-700">Nom de famille</th>
                                <th className="p-4 font-semibold text-slate-700">Prénom</th>
                                <th className="p-4 font-semibold text-slate-700">Date de naissance</th>
                                <th className="p-4 font-semibold text-slate-700 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {patients.map(p => (
                                <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                                    <td className="p-4 text-slate-500 font-medium">#{p.id}</td>
                                    <td className="p-4 font-bold text-slate-800">{p.last_name || '-'}</td>
                                    <td className="p-4 text-slate-700">{p.first_name || '-'}</td>
                                    <td className="p-4 text-slate-600">{p.date_of_birth ? new Date(p.date_of_birth).toLocaleDateString('fr-FR') : '-'}</td>
                                    <td className="p-4 text-right">
                                        <Link
                                            href={`/patients/${p.id}/chart`}
                                            className="inline-block bg-white hover:bg-slate-100 text-blue-600 font-semibold border border-slate-300 py-1 px-4 rounded transition-colors"
                                        >
                                            Voir le Statut ➔
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
