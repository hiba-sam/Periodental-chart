import Link from "next/link";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 bg-slate-50">
      <div className="bg-white p-12 rounded-2xl shadow-xl border border-slate-100 max-w-lg w-full text-center">
        <h1 className="text-4xl font-extrabold text-slate-800 mb-4 tracking-tight">Periodontal Chart</h1>
        <p className="text-slate-600 mb-8 text-lg">
          Next.js optimized version with Smart JSON Data Structure and interactive SVG plotting.
        </p>

        <div className="flex flex-col space-y-4">
          <Link
            href="/patients"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold flex justify-center py-3 px-6 rounded-lg transition-colors shadow-sm cursor-pointer"
          >
            Voir la Liste des Patients
          </Link>

          <div className="mt-6 p-4 bg-slate-100 rounded-lg text-sm text-left text-slate-700 border border-slate-200">
            <h3 className="font-bold mb-2">Features Included:</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>PostgreSQL backend (`tooth_sites` table)</li>
              <li>`react-data-table-component`</li>
              <li>Interactive SVG Visual Grid</li>
              <li>Tailwind CSS styling</li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  );
}
