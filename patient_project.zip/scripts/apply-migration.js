const { Pool } = require('pg');
const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_NAME || 'periodontal',
    password: process.env.DB_PASSWORD || 'password',
    port: parseInt(process.env.DB_PORT || '5432', 10),
});

async function migrate() {
    try {
        console.log('Applying migrations to tooth_sites...');
        await pool.query('ALTER TABLE tooth_sites ALTER COLUMN site_position TYPE VARCHAR(10)');
        await pool.query('ALTER TABLE tooth_sites ADD COLUMN IF NOT EXISTS plaque BOOLEAN DEFAULT FALSE');
        await pool.query('ALTER TABLE tooth_sites ADD COLUMN IF NOT EXISTS mobility INTEGER DEFAULT 0');
        await pool.query('ALTER TABLE tooth_sites ADD COLUMN IF NOT EXISTS furcation INTEGER DEFAULT 0');
        await pool.query('ALTER TABLE tooth_sites ADD COLUMN IF NOT EXISTS implant BOOLEAN DEFAULT FALSE');
        await pool.query('ALTER TABLE tooth_sites ADD COLUMN IF NOT EXISTS prognosis VARCHAR(50)');
        console.log('Migration successful!');
    } catch (err) {
        console.error('Migration failed:', err);
    } finally {
        await pool.end();
    }
}

migrate();
