/**
 * Type definitions for CSRF protection
 */

import 'express-session';

declare module 'express-session' {
    interface SessionData {
        csrfToken?: string;
        csrfSessionId?: string;
    }
}

declare global {
    namespace Express {
        interface Request {
            csrfToken?: () => string;
        }
    }
}

export {};
