declare module 'multer' {
    import { RequestHandler } from 'express';

    interface File {
        fieldname: string;
        originalname: string;
        encoding: string;
        mimetype: string;
        size: number;
        destination: string;
        filename: string;
        path: string;
        buffer: Buffer;
    }

    interface Options {
        dest?: string;
        storage?: any;
        limits?: {
            fieldNameSize?: number;
            fieldSize?: number;
            fields?: number;
            fileSize?: number;
            files?: number;
            parts?: number;
            headerPairs?: number;
        };
        fileFilter?: (req: any, file: File, cb: (error: Error | null, acceptFile?: boolean) => void) => void;
        preservePath?: boolean;
    }

    interface Multer {
        single(fieldname: string): RequestHandler;
        array(fieldname: string, maxCount?: number): RequestHandler;
        fields(fields: Array<{ name: string; maxCount?: number }>): RequestHandler;
        none(): RequestHandler;
        any(): RequestHandler;
    }

    interface DiskStorageOptions {
        destination?: string | ((req: any, file: File, cb: (error: Error | null, destination: string) => void) => void);
        filename?: (req: any, file: File, cb: (error: Error | null, filename: string) => void) => void;
    }

    function multer(options?: Options): Multer;

    namespace multer {
        function diskStorage(options: DiskStorageOptions): any;
        function memoryStorage(): any;
    }

    export = multer;
}
