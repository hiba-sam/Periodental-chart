/**
 * User Roles & Permissions - MyPresc
 * 
 * Système de contrôle d'accès basé sur les rôles (RBAC)
 * Conformité : OWASP A05:2021, RGPD Art.5, ANPDP Art.25
 */

// ============================================
// ENUM RÔLES
// ============================================

export enum UserRole {
    DOCTOR = 'doctor',
    ASSISTANT = 'assistant',
    PATIENT = 'patient',
    ADMIN = 'admin'
}

// ============================================
// PERMISSIONS PAR RÔLE
// ============================================

export interface RolePermissions {
    canReadPatients: boolean;
    canCreatePatient: boolean;            // Créer un nouveau patient
    canUpdatePatientAdmin: boolean;       // Modifier infos admin (nom, contact)
    canUpdatePatientMedical: boolean;     // Modifier données médicales
    canDeletePatients: boolean;
    canReadPrescriptions: boolean;
    canWritePrescriptions: boolean;
    canDeletePrescriptions: boolean;
    canReadAppointments: boolean;
    canWriteAppointments: boolean;
    canDeleteAppointments: boolean;
    canManageUsers: boolean;
    canAccessAllPatients: boolean; // Centralisation médicale
}

export const ROLE_PERMISSIONS: Record<UserRole, RolePermissions> = {
    [UserRole.DOCTOR]: {
        canReadPatients: true,
        canCreatePatient: true,
        canUpdatePatientAdmin: true,
        canUpdatePatientMedical: true,  // ✅ Peut modifier données médicales
        canDeletePatients: false, // Soft delete seulement
        canReadPrescriptions: true,
        canWritePrescriptions: true,
        canDeletePrescriptions: false,
        canReadAppointments: true,
        canWriteAppointments: true,
        canDeleteAppointments: false,
        canManageUsers: false,
        canAccessAllPatients: true // ⭐ Centralisation nationale
    },
    [UserRole.ASSISTANT]: {
        canReadPatients: true,
        canCreatePatient: true,          // ✅ Peut créer un patient (accueil)
        canUpdatePatientAdmin: true,     // ✅ Peut modifier nom, téléphone, adresse
        canUpdatePatientMedical: false,  // ❌ NE PEUT PAS modifier données médicales
        canDeletePatients: false,
        canReadPrescriptions: false, // Pas d'accès prescriptions
        canWritePrescriptions: false,
        canDeletePrescriptions: false,
        canReadAppointments: true,
        canWriteAppointments: true, // ✅ Peut créer/modifier/confirmer RDV
        canDeleteAppointments: false,
        canManageUsers: false,
        canAccessAllPatients: true // Accès tous patients (lecture + admin)
    },
    [UserRole.PATIENT]: {
        canReadPatients: true, // Seulement ses propres données
        canCreatePatient: false,
        canUpdatePatientAdmin: false,
        canUpdatePatientMedical: false,
        canDeletePatients: false,
        canReadPrescriptions: true, // Ses propres prescriptions
        canWritePrescriptions: false,
        canDeletePrescriptions: false,
        canReadAppointments: true, // Ses propres RDV
        canWriteAppointments: false,
        canDeleteAppointments: false,
        canManageUsers: false,
        canAccessAllPatients: false // ⚠️ Pas d'accès centralisation
    },
    [UserRole.ADMIN]: {
        canReadPatients: true,
        canCreatePatient: true,
        canUpdatePatientAdmin: true,
        canUpdatePatientMedical: true,
        canDeletePatients: true,
        canReadPrescriptions: true,
        canWritePrescriptions: true,
        canDeletePrescriptions: true,
        canReadAppointments: true,
        canWriteAppointments: true,
        canDeleteAppointments: true,
        canManageUsers: true,
        canAccessAllPatients: true
    }
};

// ============================================
// ACTIONS D'AUDIT
// ============================================

export enum AuditAction {
    READ = 'READ',
    CREATE = 'CREATE',
    UPDATE = 'UPDATE',
    DELETE = 'DELETE',
    ACCESS_DENIED = 'ACCESS_DENIED'
}

export enum TargetType {
    PATIENT_RECORD = 'PATIENT_RECORD',
    PRESCRIPTION = 'PRESCRIPTION',
    APPOINTMENT = 'APPOINTMENT',
    USER = 'USER',
    AUTH = 'AUTH'
}

// ============================================
// HELPERS
// ============================================

/**
 * Vérifie si un rôle a une permission spécifique
 */
export function hasPermission(role: UserRole, permission: keyof RolePermissions): boolean {
    return ROLE_PERMISSIONS[role][permission];
}

/**
 * Vérifie si un rôle peut effectuer une action sur un type de ressource
 */
export function canPerformAction(role: UserRole, action: AuditAction, targetType: TargetType): boolean {
    const permissions = ROLE_PERMISSIONS[role];
    
    switch (targetType) {
        case TargetType.PATIENT_RECORD:
            if (action === AuditAction.READ) return permissions.canReadPatients;
            if (action === AuditAction.CREATE) return permissions.canCreatePatient;
            if (action === AuditAction.UPDATE) return permissions.canUpdatePatientAdmin || permissions.canUpdatePatientMedical;
            if (action === AuditAction.DELETE) return permissions.canDeletePatients;
            break;
            
        case TargetType.PRESCRIPTION:
            if (action === AuditAction.READ) return permissions.canReadPrescriptions;
            if (action === AuditAction.CREATE || action === AuditAction.UPDATE) return permissions.canWritePrescriptions;
            if (action === AuditAction.DELETE) return permissions.canDeletePrescriptions;
            break;
            
        case TargetType.APPOINTMENT:
            if (action === AuditAction.READ) return permissions.canReadAppointments;
            if (action === AuditAction.CREATE || action === AuditAction.UPDATE) return permissions.canWriteAppointments;
            if (action === AuditAction.DELETE) return permissions.canDeleteAppointments;
            break;
            
        case TargetType.USER:
            return permissions.canManageUsers;
    }
    
    return false;
}

/**
 * Retourne la liste des rôles autorisés pour une action
 */
export function getRolesForAction(action: AuditAction, targetType: TargetType): UserRole[] {
    const roles: UserRole[] = [];
    
    for (const role of Object.values(UserRole)) {
        if (canPerformAction(role, action, targetType)) {
            roles.push(role);
        }
    }
    
    return roles;
}
