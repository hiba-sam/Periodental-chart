import { Pool } from 'pg';
import dotenv from 'dotenv';
import { securityLogger } from './utils/securityLogger';

dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: false,
    // ⚡ Phase 3: Proper pool sizing to prevent connection queuing under load
    max: 20,                      // Allow up to 20 concurrent DB connections (default was 10)
    min: 2,                       // Keep 2 warm connections always ready
    idleTimeoutMillis: 30_000,    // Release idle clients after 30s
    connectionTimeoutMillis: 5_000, // Fail fast if pool is exhausted (prevents silent hangs)
});

// Log unexpected errors on idle clients
pool.on('error', (err) => {
    console.error('Unexpected error on idle database client', err);
    securityLogger.error('Unexpected error on idle database client', { error: err.message, stack: err.stack });
});

// ⚡ Phase 3: Pool health monitoring — logs every 60s in development
if (process.env.NODE_ENV !== 'production') {
    setInterval(() => {
        console.log(
            `[Pool] total=${pool.totalCount} idle=${pool.idleCount} waiting=${pool.waitingCount}`
        );
    }, 60_000);
}

// Set encryption key as a PostgreSQL session variable for use in triggers
pool.on('connect', async (client) => {
    const encryptionKey = process.env.ENCRYPTION_KEY;
    try {
        await client.query(`SET app.encryption_key = '${encryptionKey?.replace(/'/g, "''")}'`);
        console.log('Database client connected and encryption key set');
        securityLogger.debug('Database client connected and encryption key set');
    } catch (error) {
        console.error('Failed to set encryption key in PostgreSQL session', error);
        securityLogger.error('Failed to set encryption key in PostgreSQL session', { error });
    }
});

// Startup connection test to verify DB reachability
(async () => {
    try {
        const client = await pool.connect();
        const res = await client.query('SELECT NOW()');
        client.release();
        console.log('Database connected successfully ✅');
        securityLogger.info('Database connected successfully ✅', { timestamp: res.rows[0].now });
    } catch (err) {
        console.error('Failed to connect to database on startup ❌', err);
        securityLogger.error('Failed to connect to database on startup ❌', { error: err });
    }
})();

export default pool;