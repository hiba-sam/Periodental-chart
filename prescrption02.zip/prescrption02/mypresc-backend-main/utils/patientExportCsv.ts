import type { Response } from "express";
import { getRelatedPatients } from "../services/patient.service";

export const generatePatientExportCsv = async (
    doctorUserId: number,
    res: Response
) => {
    try {
        if (!doctorUserId || isNaN(doctorUserId)) {
            return res.status(400).json({ success: false, error: "Invalid doctor ID" });
        }

        // Get all patients for this doctor
        const patients = await getRelatedPatients(doctorUserId);

        // Sort by creation date (most recent first)
        patients.sort((a, b) =>
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        );

        // Generate CSV content
        const header = "ID Patient,Nom,Prénom,Âge,Genre,Téléphone,Email,Adresse,Date de naissance,N° Sécurité Sociale,NIN,Allergies,Maladies chroniques,Notes,Contact d'urgence,Téléphone d'urgence,Date de création\n";

        const rows = patients.map(patient => {
            const birthDate = patient.dateNaissance
                ? new Date(patient.dateNaissance).toLocaleDateString("fr-FR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric"
                })
                : "";

            const createdDate = new Date(patient.created_at).toLocaleDateString("fr-FR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            });

            // Escape quotes and handle commas in content
            const escape = (text: string | null | undefined) => {
                if (text === null || text === undefined) return '""';
                return `"${String(text).replace(/"/g, '""')}"`;
            };

            return [
                escape(patient.id),
                escape(patient.name),
                escape(patient.family_name),
                escape(patient.age?.toString() || ""),
                escape(patient.genre),
                escape(patient.telephone || ""),
                escape(patient.email || ""),
                escape(patient.adresse || ""),
                escape(birthDate),
                escape(patient.numeroSecuriteSociale || ""),
                escape(patient.nin || ""),
                escape(patient.allergies || ""),
                escape(patient.chronicDiseases || ""),
                escape(patient.notes || ""),
                escape(patient.emergencyContact || ""),
                escape(patient.emergencyPhone || ""),
                escape(createdDate)
            ].join(",");
        }).join("\n");

        const csvContent = header + rows;
        const filename = `export_patients_${new Date().getTime()}.csv`;

        res.setHeader("Content-Type", "text/csv; charset=utf-8");
        res.setHeader("Content-Disposition", `attachment; filename=${filename}`);

        // Add BOM for proper Excel UTF-8 encoding
        res.send("\ufeff" + csvContent);

    } catch (error) {
        console.error("Error generating patient export CSV:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error while generating CSV export"
        });
    }
};
