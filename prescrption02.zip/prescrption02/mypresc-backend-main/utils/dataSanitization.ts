/**
 * Utilitaires pour minimiser et anonymiser les données médicales
 * avant envoi à des services tiers (OpenAI, etc.)
 * 
 * Conformité RGPD : Article 5 (minimisation des données)
 */

export class DataSanitizer {
    /**
     * Patterns pour détecter et masquer les données sensibles
     */
    private static readonly PATTERNS = {
        // Téléphone français/international
        phone: /(?:(?:\+|00)33|0)\s?[1-9](?:[\s.-]?\d{2}){4}/g,
        
        // Email
        email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
        
        // Numéro de sécurité sociale français (15 chiffres)
        nss: /[12]\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{3}\s?\d{3}\s?\d{2}/g,
        
        // Adresse IP
        ip: /\b(?:\d{1,3}\.){3}\d{1,3}\b/g,
        
        // Code postal français (5 chiffres consécutifs, mais attention aux faux positifs)
        // On ne masque que si précédé de mots clés d'adresse
        postalCode: /(?:code postal|cp|cedex)\s*:?\s*(\d{5})/gi,
        
        // Noms de rue (patterns communs français)
        street: /\d+\s*(?:rue|avenue|boulevard|place|impasse|allée|chemin|route)\s+[a-zA-ZÀ-ÿ\s'-]+/gi,
        
        // Carte bancaire (patterns simplifiés)
        creditCard: /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g,
    };

    /**
     * Masquer les données personnelles identifiables
     */
    static sanitizeText(text: string): string {
        if (!text) return text;

        let sanitized = text;

        // Masquer téléphones
        sanitized = sanitized.replace(
            this.PATTERNS.phone,
            '[TÉLÉPHONE MASQUÉ]'
        );

        // Masquer emails
        sanitized = sanitized.replace(
            this.PATTERNS.email,
            '[EMAIL MASQUÉ]'
        );

        // Masquer numéros de sécurité sociale
        sanitized = sanitized.replace(
            this.PATTERNS.nss,
            '[NSS MASQUÉ]'
        );

        // Masquer adresses IP
        sanitized = sanitized.replace(
            this.PATTERNS.ip,
            '[IP MASQUÉE]'
        );

        // Masquer codes postaux avec contexte
        sanitized = sanitized.replace(
            this.PATTERNS.postalCode,
            (match, code) => match.replace(code, '[CP MASQUÉ]')
        );

        // Masquer adresses de rue
        sanitized = sanitized.replace(
            this.PATTERNS.street,
            '[ADRESSE MASQUÉE]'
        );

        // Masquer cartes bancaires
        sanitized = sanitized.replace(
            this.PATTERNS.creditCard,
            '[CARTE BANCAIRE MASQUÉE]'
        );

        return sanitized;
    }

    /**
     * Masquer les noms propres si fournis explicitement
     * (à utiliser si le système connaît le nom du patient)
     */
    static maskKnownIdentifiers(
        text: string,
        identifiers: {
            patientName?: string;
            patientFamilyName?: string;
            doctorName?: string;
        }
    ): string {
        let masked = text;

        if (identifiers.patientName) {
            const nameRegex = new RegExp(
                `\\b${this.escapeRegex(identifiers.patientName)}\\b`,
                'gi'
            );
            masked = masked.replace(nameRegex, '[PATIENT]');
        }

        if (identifiers.patientFamilyName) {
            const familyNameRegex = new RegExp(
                `\\b${this.escapeRegex(identifiers.patientFamilyName)}\\b`,
                'gi'
            );
            masked = masked.replace(familyNameRegex, '[PATIENT]');
        }

        if (identifiers.doctorName) {
            const doctorRegex = new RegExp(
                `\\b${this.escapeRegex(identifiers.doctorName)}\\b`,
                'gi'
            );
            masked = masked.replace(doctorRegex, '[MÉDECIN]');
        }

        return masked;
    }

    /**
     * Échapper les caractères spéciaux pour regex
     */
    private static escapeRegex(str: string): string {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    /**
     * Vérifier si le texte contient encore des données sensibles
     * (pour audit/logging)
     */
    static containsSensitiveData(text: string): {
        hasSensitiveData: boolean;
        findings: string[];
    } {
        const findings: string[] = [];

        if (this.PATTERNS.phone.test(text)) findings.push('phone');
        if (this.PATTERNS.email.test(text)) findings.push('email');
        if (this.PATTERNS.nss.test(text)) findings.push('nss');
        if (this.PATTERNS.creditCard.test(text)) findings.push('creditCard');

        return {
            hasSensitiveData: findings.length > 0,
            findings
        };
    }

    /**
     * Générer un résumé sécurisé pour les logs
     * (sans contenu médical)
     */
    static createSafeLogSummary(text: string): {
        length: number;
        wordCount: number;
        containsNumbers: boolean;
        containsSpecialChars: boolean;
    } {
        return {
            length: text.length,
            wordCount: text.split(/\s+/).filter(w => w.length > 0).length,
            containsNumbers: /\d/.test(text),
            containsSpecialChars: /[^\w\sÀ-ÿ]/.test(text)
        };
    }
}

/**
 * Validator pour les uploads audio
 */
export class AudioValidator {
    private static readonly MAX_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB
    private static readonly MAX_DURATION_SECONDS = 180; // 3 minutes
    private static readonly ALLOWED_FORMATS = [
        'audio/webm',
        'audio/m4a',
        'audio/wav',
        'audio/mpeg',
        'audio/mp4',
        'audio/ogg'
    ];
    private static readonly ALLOWED_EXTENSIONS = ['webm', 'm4a', 'wav', 'mp3', 'mp4', 'ogg'];

    /**
     * Valider le fichier audio
     */
    static validateAudioFile(file: {
        size: number;
        mimetype: string;
        originalname: string;
    }): { valid: boolean; error?: string } {
        // Vérifier la taille
        if (file.size > this.MAX_SIZE_BYTES) {
            return {
                valid: false,
                error: `File too large. Max size: ${this.MAX_SIZE_BYTES / 1024 / 1024} MB`
            };
        }

        // Vérifier le type MIME
        if (!this.ALLOWED_FORMATS.includes(file.mimetype)) {
            return {
                valid: false,
                error: `Invalid file format. Allowed: ${this.ALLOWED_EXTENSIONS.join(', ')}`
            };
        }

        // Vérifier l'extension
        const ext = file.originalname.toLowerCase().split('.').pop();
        if (!ext || !this.ALLOWED_EXTENSIONS.includes(ext)) {
            return {
                valid: false,
                error: `Invalid file extension. Allowed: ${this.ALLOWED_EXTENSIONS.join(', ')}`
            };
        }

        return { valid: true };
    }

    /**
     * Estimer la durée d'un fichier audio (approximatif basé sur la taille)
     * Pour WAV non compressé: ~10 MB/minute
     * Pour formats compressés: variable
     */
    static estimateDuration(fileSize: number, format: string): number {
        const avgBytesPerSecond: Record<string, number> = {
            'audio/wav': 176400, // 44.1kHz, 16-bit, stereo
            'audio/webm': 16000, // ~128 kbps
            'audio/m4a': 16000,
            'audio/mpeg': 16000,
        };

        const bytesPerSecond = avgBytesPerSecond[format] || 16000;
        return fileSize / bytesPerSecond;
    }
}
