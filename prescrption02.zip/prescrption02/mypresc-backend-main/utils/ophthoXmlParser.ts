/**
 * ophthoXmlParser.ts
 * Parses JOIA-standard ophthalmology XML exports from computerised phoropters / chart projectors.
 * Currently supports: TOPCON CV-5000 (schema version 1.2)
 * Extensible to other JOIA-compliant vendors (Nidek, Zeiss, etc.)
 */

import { XMLParser } from 'fast-xml-parser';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EyeRefraction {
    sph:   number | null;
    cyl:   number | null;
    axis:  number | null;
    hPri:  number | null;
    vPri:  number | null;
    prism: number | null;
    angle: number | null;
    vd:    number | null;
}

export interface PupillaryDistance {
    r: number | null;
    l: number | null;
    b: number | null;
}

export interface ExamDistanceData {
    distanceCm: number;
    right:      EyeRefraction;
    left:       EyeRefraction;
    pd:         PupillaryDistance;
}

export interface MeasurementType {
    typeNo:    number;
    typeName:  string;   // 'Prescription' | 'Full Correction' | 'Objective Data'
    distances: ExamDistanceData[];
}

export interface ParsedOphthoXml {
    // Machine metadata
    company:          string;
    modelName:        string;
    machineNo:        string;
    romVersion:       string;
    schemaVersion:    string;
    // Exam timing
    examDate:         string;  // YYYY-MM-DD
    examTime:         string;  // HH:MM:SS.mmm
    duration:         string;  // HH:MM:SS
    // Patient link (machine-internal only — actual patient from route)
    machinePatientId: string;
    // All measurement types
    measureTypes: MeasurementType[];
    // Flattened Prescription (Type 1) for easy DB insert
    prescription: {
        far:  ExamDistanceData | null;
        near: ExamDistanceData | null;
    };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Normalize a raw XML value to a float.
 * fast-xml-parser returns { "#text": "0,75", "@_unit": "D" } when a tag has
 * both text content AND xml attributes (e.g. unit="D").
 * We unwrap that before replacing comma with dot.
 */
function parseNum(raw: any): number | null {
    if (raw === null || raw === undefined || raw === '') return null;
    // Unwrap object form: { "#text": "0,75", "@_unit": "D" }
    const val = (typeof raw === 'object' && raw !== null) ? (raw['#text'] ?? raw) : raw;
    if (val === null || val === undefined || val === '') return null;
    const str = String(val).replace(',', '.').trim();
    const n = parseFloat(str);
    return isNaN(n) ? null : n;
}

/** Parse an eye node (R or L) */
function parseEye(eye: any, vdRaw: any): EyeRefraction {
    return {
        sph:   parseNum(eye?.Sph),
        cyl:   parseNum(eye?.Cyl),
        axis:  parseNum(eye?.Axis),
        hPri:  parseNum(eye?.HPri),
        vPri:  parseNum(eye?.VPri),
        prism: parseNum(eye?.Prism),
        angle: parseNum(eye?.Angle),
        vd:    parseNum(vdRaw),
    };
}

/** Parse a PD node */
function parsePD(pd: any): PupillaryDistance {
    return {
        r: parseNum(pd?.R),
        l: parseNum(pd?.L),
        b: parseNum(pd?.B),
    };
}

/** Parse one ExamDistance block */
function parseExamDistance(dist: any): ExamDistanceData {
    const refData = dist?.RefractionData ?? {};
    const vd = refData?.VD;
    return {
        distanceCm: parseNum(dist?.Distance) ?? 0,
        right: parseEye(refData?.R, vd),
        left:  parseEye(refData?.L, vd),
        pd:    parsePD(dist?.PD),
    };
}

// ─── Main parser ──────────────────────────────────────────────────────────────

/**
 * Parses a JOIA-standard XML buffer from a TOPCON CV-5000 (or compatible) device.
 * Throws on invalid XML or missing required namespace structure.
 */
export function parseOphthoXml(xmlBuffer: Buffer | string): ParsedOphthoXml {
    const xmlStr = typeof xmlBuffer === 'string' ? xmlBuffer : xmlBuffer.toString('utf-8');

    const parser = new XMLParser({
        ignoreAttributes:          false,
        attributeNamePrefix:       '@_',
        removeNSPrefix:            true,   // strip nsCommon: / nsSBJ: prefixes
        parseTagValue:             true,
        parseAttributeValue:       true,
        trimValues:                true,
        // Always return these as arrays so we can safely use .find/.map regardless
        // of how many siblings appear in the document.
        isArray: (name) =>
            name === 'Type' || name === 'ExamDistance' ||
            name === 'Measure' || name === 'List',
    });

    let doc: any;
    try {
        doc = parser.parse(xmlStr);
    } catch (e) {
        throw new Error(`XML parse error: ${(e as Error).message}`);
    }

    const root = doc?.Ophthalmology;
    if (!root) {
        throw new Error('Not a valid JOIA ophthalmology XML: missing <Ophthalmology> root');
    }

    const common = root?.Common;
    if (!common) {
        throw new Error('Missing nsCommon:Common block');
    }

    // ── Machine metadata ──────────────────────────────────────────────────────
    const company       = String(common?.Company   ?? '');
    const modelName     = String(common?.ModelName ?? '');
    const machineNo     = String(common?.MachineNo ?? '');
    const romVersion    = String(common?.ROMVersion ?? '');
    const schemaVersion = String(common?.Version   ?? '');
    const examDate      = String(common?.Date      ?? '');   // YYYY-MM-DD
    const examTime      = String(common?.Time      ?? '');   // HH:MM:SS.mmm
    const duration      = String(common?.Duration  ?? '');

    const machinePatientId = String(common?.Patient?.ID ?? '');

    // ── Measurement types ─────────────────────────────────────────────────────
    // root.Measure is always an array now (isArray above).
    // When the file has both nsSBJ:Measure AND nsKM:Measure, both appear here
    // with their namespace stripped — we must find the one with type="SBJ".
    const allMeasures: any[] = Array.isArray(root?.Measure)
        ? root.Measure
        : root?.Measure ? [root.Measure] : [];

    const measure = allMeasures.find((m: any) =>
        String(m?.['@_type'] ?? '').toUpperCase() === 'SBJ'
    ) ?? allMeasures[0]; // fallback: first block (single-Measure files)

    if (!measure) {
        throw new Error('Missing nsSBJ:Measure block');
    }

    const rawTypes: any[] = Array.isArray(measure?.RefractionTest?.Type)
        ? measure.RefractionTest.Type
        : measure?.RefractionTest?.Type
            ? [measure.RefractionTest.Type]
            : [];

    const measureTypes: MeasurementType[] = rawTypes.map((t: any) => {
        const rawDistances: any[] = Array.isArray(t?.ExamDistance)
            ? t.ExamDistance
            : t?.ExamDistance ? [t.ExamDistance] : [];

        return {
            typeNo:    Number(t['@_No'] ?? 0),
            typeName:  String(t?.TypeName ?? ''),
            distances: rawDistances.map(parseExamDistance),
        };
    });

    // ── Extract Prescription (Type 1) ─────────────────────────────────────────
    const prescriptionType = measureTypes.find(m => m.typeNo === 1 || m.typeName === 'Prescription');
    const farDist  = prescriptionType?.distances.find(d => d.distanceCm >= 400) ?? null;
    const nearDist = prescriptionType?.distances.find(d => d.distanceCm < 400)  ?? null;

    return {
        company,
        modelName,
        machineNo,
        romVersion,
        schemaVersion,
        examDate,
        examTime,
        duration,
        machinePatientId,
        measureTypes,
        prescription: { far: farDist, near: nearDist },
    };
}

/**
 * Converts a ParsedOphthoXml into a flat DB insert object.
 * patientId and doctorUserId must be supplied from the route / auth context.
 */
export function flattenForDb(
    parsed: ParsedOphthoXml,
    patientId: string,
    doctorUserId: number,
    xmlRaw?: string,
): Record<string, any> {
    const far  = parsed.prescription.far;
    const near = parsed.prescription.near;

    return {
        patient_id:          patientId,
        doctor_user_id:      doctorUserId,

        machine_company:     parsed.company     || null,
        machine_model:       parsed.modelName   || null,
        machine_no:          parsed.machineNo   || null,
        machine_rom_version: parsed.romVersion  || null,
        schema_version:      parsed.schemaVersion || null,
        exam_date:           parsed.examDate    || null,
        exam_time:           parsed.examTime    ? parsed.examTime.substring(0, 8) : null, // HH:MM:SS
        exam_duration:       parsed.duration    || null,
        xml_raw:             xmlRaw             ?? null,

        // Far
        rx_far_right_sph:  far?.right.sph   ?? null,
        rx_far_right_cyl:  far?.right.cyl   ?? null,
        rx_far_right_axis: far?.right.axis  ?? null,
        rx_far_right_h_pri: far?.right.hPri ?? null,
        rx_far_right_v_pri: far?.right.vPri ?? null,
        rx_far_left_sph:   far?.left.sph    ?? null,
        rx_far_left_cyl:   far?.left.cyl    ?? null,
        rx_far_left_axis:  far?.left.axis   ?? null,
        rx_far_left_h_pri: far?.left.hPri   ?? null,
        rx_far_left_v_pri: far?.left.vPri   ?? null,
        rx_far_vd:         far?.right.vd    ?? null,
        rx_far_pd_r:       far?.pd.r        ?? null,
        rx_far_pd_l:       far?.pd.l        ?? null,
        rx_far_pd_b:       far?.pd.b        ?? null,

        // Near
        rx_near_right_sph:  near?.right.sph  ?? null,
        rx_near_right_cyl:  near?.right.cyl  ?? null,
        rx_near_right_axis: near?.right.axis ?? null,
        rx_near_right_h_pri: near?.right.hPri ?? null,
        rx_near_right_v_pri: near?.right.vPri ?? null,
        rx_near_left_sph:   near?.left.sph   ?? null,
        rx_near_left_cyl:   near?.left.cyl   ?? null,
        rx_near_left_axis:  near?.left.axis  ?? null,
        rx_near_left_h_pri: near?.left.hPri  ?? null,
        rx_near_left_v_pri: near?.left.vPri  ?? null,
        rx_near_vd:         near?.right.vd   ?? null,
        rx_near_pd_r:       near?.pd.r       ?? null,
        rx_near_pd_l:       near?.pd.l       ?? null,
        rx_near_pd_b:       near?.pd.b       ?? null,

        // Full raw dump
        raw_measurements: JSON.stringify(parsed.measureTypes),
    };
}

/**
 * ─── Vendor-Agnostic Entry Point ──────────────────────────────────────────────
 * parseJoiaXml() is the canonical public function.
 * It detects the company/modelName from the XML header and dispatches to the
 * appropriate parser implementation.
 *
 * Currently supported:
 *   • TOPCON  CV-5000   (JOIA schema 1.2) → parseOphthoXml()
 *
 * To add a new vendor:
 *   1. Create `parseNidekXml(xml)` (or similar) in this file or a sibling module.
 *   2. Add a new `else if` branch below keyed on `company`/`modelName`.
 *   3. Ensure the function returns a `ParsedOphthoXml`-compatible object.
 */
export function parseJoiaXml(xmlBuffer: Buffer | string): ParsedOphthoXml {
    const xmlStr = typeof xmlBuffer === 'string' ? xmlBuffer : xmlBuffer.toString('utf-8');

    // Quick peek at company + model without full parsing
    const companyMatch   = xmlStr.match(/<[^>]*:?Company[^>]*>(.*?)<\/[^>]*:?Company>/);
    const modelMatch     = xmlStr.match(/<[^>]*:?ModelName[^>]*>(.*?)<\/[^>]*:?ModelName>/);
    const company   = companyMatch?.[1]?.trim().toUpperCase()  ?? '';
    const modelName = modelMatch?.[1]?.trim().toUpperCase()    ?? '';

    // ── Dispatch ──────────────────────────────────────────────────────────────
    if (company === 'TOPCON' || modelName.includes('CV-')) {
        // TOPCON CV-5000 / CV-3000 — JOIA standard namespace format
        return parseOphthoXml(xmlBuffer);
    }

    // Fallback: attempt generic JOIA parse
    // If the file truly isn't JOIA-compatible, parseOphthoXml will throw.
    return parseOphthoXml(xmlBuffer);
}
