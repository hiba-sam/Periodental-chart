/**
 * Check if a user's subscription plan is expired
 * @param endDate - The plan's expiration date
 * @returns true if plan is expired, false otherwise
 */
export const isPlanExpired = (endDate: Date | null | undefined): boolean => {
    // If no end_date, plan is not expired (or not applicable)
    if (!endDate) {
        return false;
    }

    // Check if current date is past the end_date
    const currentDate = new Date();
    const planEndDate = new Date(endDate);

    return currentDate > planEndDate;
};
