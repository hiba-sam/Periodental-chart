import pool from '../db';

/**
 * Get or create a consultation for today between a doctor and patient
 * This ensures that multiple actions (prescription + medical report) on the same day
 * count as ONE consultation, not multiple
 * 
 * @param patientId - UUID of the patient
 * @param doctorUserId - ID of the doctor user
 * @param appointmentId - Optional appointment ID if consultation is linked to an appointment
 * @returns consultation ID
 */
export async function getOrCreateTodayConsultation(
    patientId: string,
    doctorUserId: number,
    appointmentId?: string
): Promise<number> {
    try {
        // Try to find existing consultation for today
        const findQuery = `
            SELECT id 
            FROM consultations 
            WHERE patient_id = $1 
            AND doctor_user_id = $2 
            AND consultation_date = CURRENT_DATE
        `;
        
        const findResult = await pool.query(findQuery, [patientId, doctorUserId]);
        
        if (findResult.rows.length > 0) {
            console.log(`♻️ Using existing consultation ${findResult.rows[0].id} for patient ${patientId}`);
            return findResult.rows[0].id;
        }
        
        // Create new consultation for today
        const createQuery = `
            INSERT INTO consultations (patient_id, doctor_user_id, consultation_date, appointment_id)
            VALUES ($1, $2, CURRENT_DATE, $3)
            RETURNING id
        `;
        
        const createResult = await pool.query(createQuery, [patientId, doctorUserId, appointmentId || null]);
        const consultationId = createResult.rows[0].id;
        
        console.log(`✨ Created new consultation ${consultationId} for patient ${patientId}`);
        console.log(`📊 Patient consultations counter automatically incremented by trigger`);
        
        return consultationId;
        
    } catch (error) {
        console.error('❌ Error in getOrCreateTodayConsultation:', error);
        throw error;
    }
}

/**
 * Mark that a prescription was created during a consultation
 */
export async function markConsultationHasPrescription(consultationId: number): Promise<void> {
    try {
        await pool.query(
            'UPDATE consultations SET has_prescription = true WHERE id = $1',
            [consultationId]
        );
        console.log(`📝 Marked consultation ${consultationId} as having prescription`);
    } catch (error) {
        console.error('❌ Error marking consultation has prescription:', error);
        throw error;
    }
}

/**
 * Mark that a medical report was created during a consultation
 */
export async function markConsultationHasMedicalReport(consultationId: number): Promise<void> {
    try {
        await pool.query(
            'UPDATE consultations SET has_medical_report = true WHERE id = $1',
            [consultationId]
        );
        console.log(`📋 Marked consultation ${consultationId} as having medical report`);
    } catch (error) {
        console.error('❌ Error marking consultation has medical report:', error);
        throw error;
    }
}

/**
 * Get consultation statistics for a patient
 */
export async function getPatientConsultationStats(patientId: string) {
    try {
        const query = `
            SELECT 
                COUNT(*) as total_consultations,
                COUNT(*) FILTER (WHERE has_prescription = true) as consultations_with_prescription,
                COUNT(*) FILTER (WHERE has_medical_report = true) as consultations_with_report,
                COUNT(DISTINCT doctor_user_id) as different_doctors,
                MIN(consultation_date) as first_consultation,
                MAX(consultation_date) as last_consultation
            FROM consultations
            WHERE patient_id = $1
        `;
        
        const result = await pool.query(query, [patientId]);
        return result.rows[0];
    } catch (error) {
        console.error('❌ Error getting patient consultation stats:', error);
        throw error;
    }
}
