/**
 * Data Encryption Module - MyPresc Backend
 * 
 * Chiffrement AES-256-GCM pour données médicales au repos
 * Mode authentifié (integrity + confidentiality)
 * 
 * Conformité : OWASP A02:2021, RGPD Art.32, ANPDP Art.25-26
 */

import crypto from 'crypto';
import { securityLogger } from './securityLogger';

// ============================================
// TYPES
// ============================================

export interface EncryptedPayload {
    iv: string;           // Initialization Vector (hex)
    tag: string;          // Authentication Tag (hex)
    ciphertext: string;   // Encrypted data (hex)
}

export interface EncryptionMetrics {
    encryptionTime: number;
    decryptionTime: number;
    dataSize: number;
}

// ============================================
// CONFIGURATION
// ============================================

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16; // 128 bits
const TAG_LENGTH = 16; // 128 bits
const KEY_LENGTH = 32; // 256 bits

/**
 * Récupère la clé de chiffrement depuis l'environnement
 */
function getEncryptionKey(): Buffer {
    const keyHex = process.env.DATA_ENCRYPTION_KEY;
    
    if (!keyHex) {
        const error = new Error('DATA_ENCRYPTION_KEY not configured in environment');
        securityLogger.error('[ENCRYPTION] Missing encryption key', {
            event: 'ENCRYPTION_ERROR',
            error: error.message
        });
        throw error;
    }
    
    // Convertir la clé hex en buffer
    try {
        const key = Buffer.from(keyHex, 'hex');
        
        if (key.length !== KEY_LENGTH) {
            throw new Error(`Invalid key length: ${key.length} bytes (expected ${KEY_LENGTH})`);
        }
        
        return key;
    } catch (error) {
        securityLogger.error('[ENCRYPTION] Invalid encryption key format', {
            event: 'ENCRYPTION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        throw error;
    }
}

// ============================================
// FONCTIONS DE CHIFFREMENT
// ============================================

/**
 * Chiffre des données avec AES-256-GCM
 * 
 * @param plainText - Texte en clair à chiffrer
 * @returns Payload chiffré avec IV et tag d'authentification
 */
export function encryptData(plainText: string): EncryptedPayload {
    const startTime = performance.now();
    
    try {
        if (!plainText || plainText.trim().length === 0) {
            throw new Error('Cannot encrypt empty data');
        }
        
        // Récupérer la clé
        const key = getEncryptionKey();
        
        // Générer un IV aléatoire unique
        const iv = crypto.randomBytes(IV_LENGTH);
        
        // Créer le cipher
        const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
        
        // Chiffrer
        let ciphertext = cipher.update(plainText, 'utf8', 'hex');
        ciphertext += cipher.final('hex');
        
        // Récupérer le tag d'authentification
        const tag = cipher.getAuthTag();
        
        const payload: EncryptedPayload = {
            iv: iv.toString('hex'),
            tag: tag.toString('hex'),
            ciphertext
        };
        
        const encryptionTime = performance.now() - startTime;
        
        // Logger l'opération (sans les données sensibles)
        securityLogger.info('[ENCRYPTION] Data encrypted successfully', {
            event: 'ENCRYPTION_SUCCESS',
            algorithm: ALGORITHM,
            dataSize: plainText.length,
            encryptionTime: `${encryptionTime.toFixed(2)}ms`
        });
        
        return payload;
        
    } catch (error) {
        const encryptionTime = performance.now() - startTime;
        
        securityLogger.error('[ENCRYPTION] Encryption failed', {
            event: 'ENCRYPTION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error',
            encryptionTime: `${encryptionTime.toFixed(2)}ms`
        });
        
        throw error;
    }
}

/**
 * Déchiffre des données AES-256-GCM
 * 
 * @param payload - Payload chiffré avec IV et tag
 * @returns Texte en clair
 */
export function decryptData(payload: EncryptedPayload): string {
    const startTime = performance.now();
    
    try {
        if (!payload || !payload.iv || !payload.tag || !payload.ciphertext) {
            throw new Error('Invalid encrypted payload structure');
        }
        
        // Récupérer la clé
        const key = getEncryptionKey();
        
        // Convertir IV et tag en buffers avec validation
        const iv = Buffer.from(payload.iv, 'hex');
        const tag = Buffer.from(payload.tag, 'hex');
        
        // Valider les longueurs pour détecter des payloads corrompus/malveillants
        if (iv.length !== IV_LENGTH) {
            throw new Error(`Invalid IV length: ${iv.length} bytes (expected ${IV_LENGTH})`);
        }
        if (tag.length !== TAG_LENGTH) {
            throw new Error(`Invalid auth tag length: ${tag.length} bytes (expected ${TAG_LENGTH})`);
        }
        
        // Créer le decipher
        const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
        decipher.setAuthTag(tag);
        
        // Déchiffrer
        let plainText = decipher.update(payload.ciphertext, 'hex', 'utf8');
        plainText += decipher.final('utf8');
        
        const decryptionTime = performance.now() - startTime;
        
        // Logger l'opération
        securityLogger.info('[ENCRYPTION] Data decrypted successfully', {
            event: 'DECRYPTION_SUCCESS',
            algorithm: ALGORITHM,
            dataSize: plainText.length,
            decryptionTime: `${decryptionTime.toFixed(2)}ms`
        });
        
        return plainText;
        
    } catch (error) {
        const decryptionTime = performance.now() - startTime;
        
        securityLogger.error('[ENCRYPTION] Decryption failed', {
            event: 'DECRYPTION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error',
            decryptionTime: `${decryptionTime.toFixed(2)}ms`
        });
        
        throw error;
    }
}

// ============================================
// FONCTIONS POUR JSON
// ============================================

/**
 * Chiffre un objet JSON
 * 
 * @param data - Objet à chiffrer
 * @returns Payload chiffré
 */
export function encryptJSON(data: any): EncryptedPayload {
    try {
        const jsonString = JSON.stringify(data);
        return encryptData(jsonString);
    } catch (error) {
        securityLogger.error('[ENCRYPTION] JSON encryption failed', {
            event: 'ENCRYPTION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        throw error;
    }
}

/**
 * Déchiffre un payload JSON
 * 
 * @param payload - Payload chiffré
 * @returns Objet déchiffré
 */
export function decryptJSON(payload: EncryptedPayload): any {
    try {
        const jsonString = decryptData(payload);
        return JSON.parse(jsonString);
    } catch (error) {
        securityLogger.error('[ENCRYPTION] JSON decryption failed', {
            event: 'DECRYPTION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        throw error;
    }
}

// ============================================
// FONCTIONS POUR CHAMPS NULLABLE
// ============================================

/**
 * Chiffre un champ (gère les valeurs null/undefined)
 * 
 * @param value - Valeur à chiffrer
 * @returns Payload chiffré ou null
 */
export function encryptField(value: string | null | undefined): EncryptedPayload | null {
    if (value === null || value === undefined || value.trim() === '') {
        return null;
    }
    return encryptData(value);
}

/**
 * Déchiffre un champ (gère les valeurs null)
 * 
 * @param payload - Payload chiffré ou null
 * @returns Texte déchiffré ou null
 */
export function decryptField(payload: EncryptedPayload | null | undefined): string | null {
    if (payload === null || payload === undefined) {
        return null;
    }
    return decryptData(payload);
}

// ============================================
// FONCTIONS BATCH
// ============================================

/**
 * Chiffre plusieurs champs
 * 
 * @param fields - Map de nom de champ → valeur
 * @returns Map de nom de champ → payload chiffré
 */
export function encryptFields(fields: Record<string, string>): Record<string, EncryptedPayload> {
    const encrypted: Record<string, EncryptedPayload> = {};
    
    for (const [key, value] of Object.entries(fields)) {
        if (value !== null && value !== undefined && value.trim() !== '') {
            encrypted[key] = encryptData(value);
        }
    }
    
    return encrypted;
}

/**
 * Déchiffre plusieurs champs
 * 
 * @param fields - Map de nom de champ → payload chiffré
 * @returns Map de nom de champ → valeur déchiffrée
 */
export function decryptFields(fields: Record<string, EncryptedPayload>): Record<string, string> {
    const decrypted: Record<string, string> = {};
    
    for (const [key, payload] of Object.entries(fields)) {
        if (payload !== null && payload !== undefined) {
            decrypted[key] = decryptData(payload);
        }
    }
    
    return decrypted;
}

// ============================================
// VALIDATION & TESTS
// ============================================

/**
 * Vérifie que le chiffrement/déchiffrement fonctionne
 * 
 * @returns true si fonctionnel, false sinon
 */
export function testEncryption(): boolean {
    try {
        const testData = 'Test de chiffrement AES-256-GCM';
        const encrypted = encryptData(testData);
        const decrypted = decryptData(encrypted);
        
        const isValid = decrypted === testData;
        
        if (isValid) {
            securityLogger.info('[ENCRYPTION] Self-test passed', {
                event: 'ENCRYPTION_TEST_SUCCESS'
            });
        } else {
            securityLogger.error('[ENCRYPTION] Self-test failed', {
                event: 'ENCRYPTION_TEST_FAILED',
                error: 'Decrypted data does not match original'
            });
        }
        
        return isValid;
    } catch (error) {
        securityLogger.error('[ENCRYPTION] Self-test error', {
            event: 'ENCRYPTION_TEST_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        return false;
    }
}

/**
 * Génère des métriques de performance
 * 
 * @param sampleSize - Taille de l'échantillon à tester (bytes)
 * @returns Métriques de performance
 */
export function benchmarkEncryption(sampleSize: number = 1000): EncryptionMetrics {
    const testData = 'x'.repeat(sampleSize);
    
    // Mesurer chiffrement
    const encryptStart = performance.now();
    const encrypted = encryptData(testData);
    const encryptionTime = performance.now() - encryptStart;
    
    // Mesurer déchiffrement
    const decryptStart = performance.now();
    decryptData(encrypted);
    const decryptionTime = performance.now() - decryptStart;
    
    return {
        encryptionTime,
        decryptionTime,
        dataSize: sampleSize
    };
}

// ============================================
// EXPORT PAR DÉFAUT
// ============================================

export default {
    encryptData,
    decryptData,
    encryptJSON,
    decryptJSON,
    encryptField,
    decryptField,
    encryptFields,
    decryptFields,
    testEncryption,
    benchmarkEncryption
};
