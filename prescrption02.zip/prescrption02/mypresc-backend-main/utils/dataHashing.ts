/**
 * Data Hashing Module - MyPresc Backend
 * 
 * Hachage SHA-512 non réversible pour identifiants patients/doctors
 * Protection contre la corrélation directe
 * 
 * Conformité : RGPD Art.25 (pseudonymisation), ANPDP Art.26
 */

import crypto from 'crypto';
import { securityLogger } from './securityLogger';

// ============================================
// CONFIGURATION
// ============================================

const HASH_ALGORITHM = 'sha512';

/**
 * Récupère le sel de hachage depuis l'environnement
 */
function getHashSalt(): string {
    const salt = process.env.HASH_SALT;
    
    if (!salt) {
        const error = new Error('HASH_SALT not configured in environment');
        securityLogger.error('[HASHING] Missing hash salt', {
            event: 'HASHING_ERROR',
            error: error.message
        });
        throw error;
    }
    
    if (salt.length < 32) {
        securityLogger.warn('[HASHING] Hash salt too short (< 32 chars)', {
            event: 'HASHING_WARNING',
            saltLength: salt.length
        });
    }
    
    return salt;
}

// ============================================
// FONCTIONS DE HACHAGE
// ============================================

/**
 * Hache une valeur avec SHA-512 + sel
 * 
 * @param value - Valeur à hacher
 * @returns Hash hex (128 caractères)
 */
export function hashValue(value: string | number): string {
    try {
        if (value === null || value === undefined || value === '') {
            throw new Error('Cannot hash empty value');
        }
        
        const salt = getHashSalt();
        const stringValue = String(value);
        
        // Créer le hash avec sel
        const hash = crypto
            .createHash(HASH_ALGORITHM)
            .update(stringValue + salt)
            .digest('hex');
        
        return hash;
    } catch (error) {
        securityLogger.error('[HASHING] Hashing failed', {
            event: 'HASHING_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        throw error;
    }
}

/**
 * Hache un ID patient
 * 
 * @param patientId - ID du patient
 * @returns Hash pseudonymisé
 */
export function hashPatientId(patientId: string | number): string {
    return hashValue(`patient:${patientId}`);
}

/**
 * Hache un ID docteur
 * 
 * @param doctorId - ID du docteur
 * @returns Hash pseudonymisé
 */
export function hashDoctorId(doctorId: string | number): string {
    return hashValue(`doctor:${doctorId}`);
}

/**
 * Hache un ID utilisateur générique
 * 
 * @param userId - ID de l'utilisateur
 * @param type - Type d'utilisateur (patient, doctor, admin)
 * @returns Hash pseudonymisé
 */
export function hashUserId(userId: string | number, type: string = 'user'): string {
    return hashValue(`${type}:${userId}`);
}

/**
 * Hache un email (pour logging anonyme)
 * 
 * @param email - Email à hacher
 * @returns Hash de l'email
 */
export function hashEmail(email: string): string {
    return hashValue(`email:${email.toLowerCase()}`);
}

/**
 * Hache un numéro de téléphone (pour logging anonyme)
 * 
 * @param phone - Numéro de téléphone
 * @returns Hash du téléphone
 */
export function hashPhone(phone: string): string {
    // Normaliser le téléphone (enlever espaces, tirets)
    const normalized = phone.replace(/[\s\-\(\)]/g, '');
    return hashValue(`phone:${normalized}`);
}

// ============================================
// HACHAGE AVEC PEPPER (double protection)
// ============================================

/**
 * Hache avec pepper additionnel (pour extra sécurité)
 * 
 * @param value - Valeur à hacher
 * @param pepper - Pepper additionnel (ex: secret application)
 * @returns Hash renforcé
 */
export function hashWithPepper(value: string, pepper: string): string {
    const salt = getHashSalt();
    
    return crypto
        .createHash(HASH_ALGORITHM)
        .update(value + salt + pepper)
        .digest('hex');
}

// ============================================
// HMAC POUR INDEX DÉTERMINISTE (DEC-002)
// ============================================

/**
 * Récupère la clé HMAC (pepper) depuis l'environnement
 */
function getHmacPepper(): string {
    const pepper = process.env.HMAC_PEPPER || process.env.HASH_SALT;
    
    if (!pepper) {
        const error = new Error('HMAC_PEPPER not configured in environment');
        securityLogger.error('[HASHING] Missing HMAC pepper', {
            event: 'HASHING_ERROR',
            error: error.message
        });
        throw error;
    }
    
    return pepper;
}

/**
 * Génère un index HMAC-SHA-256 pour recherche déterministe
 * Plus sécurisé que SHA-512 avec sel fixe pour les index (DEC-002)
 * 
 * @param value - Valeur à indexer (ex: NIN)
 * @returns Index HMAC hex (64 caractères)
 */
export function hmacIndex(value: string): string {
    try {
        if (!value || value.trim() === '') {
            throw new Error('Cannot create HMAC index for empty value');
        }
        
        const pepper = getHmacPepper();
        
        const hmac = crypto
            .createHmac('sha256', pepper)
            .update(value.trim().toLowerCase())
            .digest('hex');
        
        return hmac;
    } catch (error) {
        securityLogger.error('[HASHING] HMAC indexing failed', {
            event: 'HASHING_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        throw error;
    }
}

/**
 * Génère un index HMAC pour NIN patient (recherche déterministe)
 * Conforme à DEC-002: HMAC-SHA-256 avec pepper au lieu d'Argon2id
 * 
 * @param nin - Numéro d'Identification National
 * @returns Index HMAC pour recherche
 */
export function hmacNinIndex(nin: string): string {
    // Normaliser le NIN (enlever espaces, tirets, mettre en majuscules)
    const normalizedNin = nin.replace(/[\s\-]/g, '').toUpperCase();
    return hmacIndex(`nin:${normalizedNin}`);
}

/**
 * Vérifie qu'un HMAC correspond à une valeur
 * Utilise timing-safe comparison
 * 
 * @param value - Valeur originale
 * @param hmacValue - HMAC à vérifier
 * @returns true si le HMAC correspond
 */
export function verifyHmac(value: string, hmacValue: string): boolean {
    try {
        const computedHmac = hmacIndex(value);
        
        const computedBuffer = Buffer.from(computedHmac, 'hex');
        const providedBuffer = Buffer.from(hmacValue, 'hex');
        
        if (computedBuffer.length !== providedBuffer.length) {
            return false;
        }
        
        return crypto.timingSafeEqual(computedBuffer, providedBuffer);
    } catch (error) {
        return false;
    }
}

// ============================================
// VALIDATION
// ============================================

/**
 * Vérifie qu'un hash correspond à une valeur
 * Utilise timing-safe comparison pour éviter les timing attacks
 * 
 * @param value - Valeur originale
 * @param hash - Hash à vérifier
 * @returns true si le hash correspond
 */
export function verifyHash(value: string, hash: string): boolean {
    try {
        const computedHash = hashValue(value);
        
        // Utiliser timing-safe comparison pour éviter les timing attacks
        const computedBuffer = Buffer.from(computedHash, 'hex');
        const providedBuffer = Buffer.from(hash, 'hex');
        
        // Les buffers doivent avoir la même longueur pour timingSafeEqual
        if (computedBuffer.length !== providedBuffer.length) {
            return false;
        }
        
        return crypto.timingSafeEqual(computedBuffer, providedBuffer);
    } catch (error) {
        return false;
    }
}

/**
 * Teste le système de hachage
 * 
 * @returns true si fonctionnel
 */
export function testHashing(): boolean {
    try {
        const testValue = 'test123';
        const hash1 = hashValue(testValue);
        const hash2 = hashValue(testValue);
        
        // Les deux hash doivent être identiques
        const isConsistent = hash1 === hash2;
        
        // Le hash doit être différent de la valeur originale
        const isDifferent = hash1 !== testValue;
        
        // Le hash doit avoir 128 caractères (SHA-512)
        const isCorrectLength = hash1.length === 128;
        
        const isValid = isConsistent && isDifferent && isCorrectLength;
        
        if (isValid) {
            securityLogger.info('[HASHING] Self-test passed', {
                event: 'HASHING_TEST_SUCCESS',
                hashLength: hash1.length
            });
        } else {
            securityLogger.error('[HASHING] Self-test failed', {
                event: 'HASHING_TEST_FAILED',
                isConsistent,
                isDifferent,
                isCorrectLength
            });
        }
        
        return isValid;
    } catch (error) {
        securityLogger.error('[HASHING] Self-test error', {
            event: 'HASHING_TEST_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        return false;
    }
}

// ============================================
// EXPORT PAR DÉFAUT
// ============================================

export default {
    hashValue,
    hashPatientId,
    hashDoctorId,
    hashUserId,
    hashEmail,
    hashPhone,
    hashWithPepper,
    hmacIndex,
    hmacNinIndex,
    verifyHash,
    verifyHmac,
    testHashing
};
