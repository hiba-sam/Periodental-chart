import PdfPrinter from "pdfmake";
import type { Response } from "express";
import { PrescriptionModel } from "../models/prescription.model";
import { DoctorModel } from "../models/doctor.model";
import fs from "fs";
import path from "path";

const fonts = {
  Roboto: {
    normal:      "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
    bold:        "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
    italics:     "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
    bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff",
  },
};

const printer = new PdfPrinter(fonts);

const logoPath   = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

// ─── Palette ──────────────────────────────────────────────────────────────────
const TEAL       = "#1a7fa0";
const DARK_TEAL  = "#155f7a";
const LIGHT_TEAL = "#e8f5f9";
const QTY_BG     = "#f0f9fc";
const SEPARATOR  = "#d0e8ef";
const MUTED      = "#8aacb5";
const TEXT_DARK  = "#1a1a2e";
const TEXT_MED   = "#4a7a8a";

// A4 full width in points (595.28) minus default pdfmake internal gutters.
// pageMargins = [0,0,0,0] so usable width = 595.28pt
const PAGE_W = 595.28;

// ─── Layouts ──────────────────────────────────────────────────────────────────

const noLayout = {
  hLineWidth: () => 0,
  vLineWidth: () => 0,
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const dashedBorderLayout = {
  hLineWidth:  () => 0.8,
  vLineWidth:  () => 0.8,
  hLineColor:  () => TEAL,
  vLineColor:  () => TEAL,
  hLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  vLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const medRowLayout = {
  hLineWidth: () => 0,
  vLineWidth: (i: number) => (i === 2 ? 2 : 0),
  vLineColor: () => TEAL,
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const makeFooterContactLayout = (nCols: number) => ({
  hLineWidth: () => 0,
  vLineWidth: (i: number) => (i > 0 && i < nCols ? 0.6 : 0),
  vLineColor: () => SEPARATOR,
  paddingLeft:   (i: number) => (i === 0 ? 0 : 16),
  paddingRight:  (i: number) => (i === nCols - 1 ? 0 : 16),
  paddingTop:    () => 0,
  paddingBottom: () => 0,
});

// ─── Signature block (absolutePosition, same as medicalReportPdf) ─────────────
// x = PAGE_W - 40 (right margin) - 160 (box width) = 395.28
const SIGN_X = 395;
const SIGN_Y = 690; // fixed y — sits above the 50pt footer zone

const signatureBlock = {
  stack: [
    {
      table: {
        widths: [160],
        body: [[{
          text: "",
          border: [true, true, true, true],
          margin: [0, 45, 0, 0],
        }]],
      },
      layout: dashedBorderLayout,
    },
    {
      text: "Signature & Cachet du Médecin",
      fontSize: 8, color: MUTED, alignment: "right",
      characterSpacing: 0.4, margin: [0, 5, 55, 0],
    },
  ],
  absolutePosition: { x: SIGN_X, y: SIGN_Y },
};

// ─── Main generator ───────────────────────────────────────────────────────────

export const generatePrescription = async (id: number, res: Response) => {
  try {
    if (!id || isNaN(id)) {
      return res.status(400).json({ success: false, error: "Invalid prescription ID" });
    }

    const prescription = await PrescriptionModel.findByIdWithDetails(id);
    if (!prescription) {
      return res.status(404).json({ success: false, error: "Prescription not found" });
    }

    const doctorProfile = await DoctorModel.findByUserId(prescription.doctor_user_id);

    const doctor = {
      name:          `Dr. ${prescription.doctor.name ?? ""} ${prescription.doctor.family_name ?? ""}`.trim(),
      speciality:    doctorProfile?.speciality    || "Médecin généraliste",
      establishment: doctorProfile?.work_location || "",
      tel:           doctorProfile?.phone_number  || "",
      email:         prescription.doctor.email    || "",
    };

    const patientFullName = `${prescription.patient?.name ?? ""} ${prescription.patient?.family_name ?? ""}`.trim();
    const genre      = (prescription.patient?.genre || "").toLowerCase();
    const sexLabel   = genre === "femme" ? "Féminin" : genre === "homme" ? "Masculin" : "";
    const birthRaw: any = (prescription as any).patient?.dateNaissance ?? null;
    const birthDate  = birthRaw ? new Date(birthRaw) : null;
    const birthLabel = birthDate && !isNaN(birthDate.getTime()) ? birthDate.toLocaleDateString("fr-FR") : "";
    const patientAge = (prescription as any).patient?.age;
    const ageLabel   = patientAge != null ? `${patientAge} ans` : "";

    const medications = (prescription.medications || []).map((m) => {
      const brand   = m.medication?.nom_de_marque || m.medication?.denomination_commune_internationale || "";
      const medDose = m.medication?.dosage ? ` ${m.medication.dosage}` : "";
      return {
        name:               `${brand.toUpperCase()}${medDose}`.trim(),
        dosageInstructions: m.dosage   || "",
        note:               m.note     || "",
        qty:                m.quantity ?? 1,
        unit:               (m as any).unit || "",
      };
    });

    const today  = new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
    const ordNum = prescription.id
      ? `N° ORD-${new Date().getFullYear()}-${String(prescription.id).padStart(3, "0")}`
      : "";

    // ── Footer contact fields ─────────────────────────────────────────────────
    type CF = { label: string; value: string };
    const contactFields: CF[] = [];
    if (doctor.establishment) contactFields.push({ label: "ADRESSE",   value: doctor.establishment });
    if (doctor.tel)           contactFields.push({ label: "TÉLÉPHONE", value: doctor.tel });
    if (doctor.email)         contactFields.push({ label: "EMAIL",     value: doctor.email });

    const contactTableBody = [
      contactFields.map((f) => ({
        stack: [
          { text: f.label, fontSize: 7, bold: true, color: MUTED, characterSpacing: 1.2 },
          { text: f.value, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] },
        ],
        border: [false, false, false, false],
      })),
    ];
    const contactWidths = contactFields.map(() => "auto" as const);

    // ─────────────────────────────────────────────────────────────────────────
    // Helper: build a medication row element
    // ─────────────────────────────────────────────────────────────────────────
    const makeMedRow = (med: typeof medications[0], idx: number): any => ({
      table: {
        widths: [30, "*", 70],
        body: [[
          {
            text: String(idx + 1),
            fontSize: 11, bold: true, color: TEAL, alignment: "center",
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [0, 8, 0, 8],
          },
          {
            stack: [
              { text: med.name, bold: true, fontSize: 10, color: TEXT_DARK },
              ...(med.dosageInstructions ? [{ text: med.dosageInstructions, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] }] : []),
              ...(med.note               ? [{ text: med.note, fontSize: 8, color: "#888888", italics: true, margin: [0, 2, 0, 0] }] : []),
            ],
            border: [false, false, false, false],
            margin: [10, 8, 10, 8],
          },
          {
            stack: [
              { text: "QTÉ", fontSize: 7, bold: true, color: "#2a9ab8", alignment: "right", characterSpacing: 1 },
              { text: String(med.qty).padStart(2, "0"), fontSize: 22, bold: true, color: TEAL, alignment: "right", lineHeight: 1, margin: [0, 2, 0, 0] },
              ...(med.unit ? [{ text: med.unit, fontSize: 8, color: MUTED, alignment: "right", margin: [0, 2, 0, 0] }] : []),
            ],
            fillColor: QTY_BG,
            border: [false, false, false, false],
            margin: [8, 6, 10, 6],
          },
        ]],
      },
      layout: medRowLayout,
      margin: [40, 0, 40, 2],   // ← reduced bottom spacing between meds (was 6)
    });

    // ─────────────────────────────────────────────────────────────────────────
    // Split medications: first page max 8, rest on subsequent pages
    // ─────────────────────────────────────────────────────────────────────────
    const MEDS_PER_PAGE = 8;
    const firstPageMeds  = medications.slice(0, MEDS_PER_PAGE);
    const overflowMeds   = medications.slice(MEDS_PER_PAGE);

    // ─── HEADER ───────────────────────────────────────────────────────────────
    const headerBlock: any = {
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            stack: [
              { text: doctor.name, fontSize: 18, bold: true, color: TEAL, lineHeight: 1.1 },
              {
                text: doctor.speciality.toUpperCase(),
                fontSize: 9, color: DARK_TEAL, characterSpacing: 1,
                margin: [0, 4, 0, 10],
              },
              ...(doctor.establishment ? [{ text: doctor.establishment, fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.tel           ? [{ text: `Tél. ${doctor.tel}`,  fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.email         ? [{ text: doctor.email,          fontSize: 9, color: TEAL     }] : []),
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [40, 20, 8, 20],
          },
          {
            stack: [
              { image: `data:image/png;base64,${logoBase64}`, width: 110, alignment: "right" },
              ...(ordNum ? [{
                text: ordNum,
                fontSize: 8, color: MUTED, alignment: "right",
                characterSpacing: 0.5, margin: [0, 6, 0, 0],
              }] : []),
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [8, 20, 40, 20],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 0, 0, 0],
    };

    // ─── PATIENT BAR ──────────────────────────────────────────────────────────
    const patientBar: any = {
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            stack: [
              { text: "PATIENT", fontSize: 7, bold: true, color: "#cce8f0", characterSpacing: 1.5 },
              { text: patientFullName.toUpperCase(), fontSize: 15, bold: true, color: "white", margin: [0, 2, 0, 4] },
              {
                columns: [
                  ...(sexLabel ? [
                    { text: "Sexe :",        fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                    { text: `  ${sexLabel}`, fontSize: 8, color: "white",   width: "auto" },
                  ] : []),
                  ...(ageLabel ? [
                    { text: sexLabel ? "      Âge :" : "Âge :", fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                    { text: `  ${ageLabel}`, fontSize: 8, color: "white",   width: "auto" },
                  ] : []),
                  ...(!ageLabel && birthLabel ? [
                    { text: "  Né(e) le :",    fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                    { text: `  ${birthLabel}`, fontSize: 8, color: "white",   width: "auto" },
                  ] : []),
                ],
              },
            ],
            fillColor: TEAL,
            border: [false, false, false, false],
            margin: [40, 12, 8, 12],
          },
          {
            stack: [
              { text: "DATE",  fontSize: 7, bold: true, color: "#cce8f0", alignment: "right", characterSpacing: 1.5 },
              { text: today,   fontSize: 13, bold: true, color: "white",  alignment: "right", margin: [0, 3, 0, 0] },
            ],
            fillColor: TEAL,
            border: [false, false, false, false],
            margin: [8, 12, 40, 12],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 12, 0, 20],
    };

    // ─── TITLE + DIVIDER ──────────────────────────────────────────────────────
    const titleBlock: any[] = [
      {
        stack: [
          { text: "Ordonnance Médicale",      fontSize: 20, bold: true, color: DARK_TEAL },
          { text: "PRESCRIPTION & POSOLOGIE", fontSize: 7,  color: TEAL, characterSpacing: 1, margin: [0, 2, 0, 0] },
        ],
        margin: [40, 0, 40, 0],
      },
      {
        canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
        margin: [40, 10, 40, 14],
      },
    ];

    // ─── REMARKS (optional) ───────────────────────────────────────────────────
    const remarksBlock: any[] = prescription.remarks ? [
      {
        canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
        margin: [40, 12, 40, 0],
      },
      {
        table: {
          widths: [3, "*"],
          body: [[
            { text: "", fillColor: "#f0c040", border: [false, false, false, false] },
            {
              stack: [
                { text: "Remarques", bold: true, fontSize: 9, color: "#b8943a", margin: [0, 0, 0, 4] },
                { text: prescription.remarks, fontSize: 9, color: "#6b5a2a" },
              ],
              fillColor: "#fffbf0",
              border: [false, false, false, false],
              margin: [10, 8, 8, 8],
            },
          ]],
        },
        layout: noLayout,
        margin: [40, 8, 40, 0],
      },
    ] : [];

    // ─────────────────────────────────────────────────────────────────────────
    // Build content array
    // ─────────────────────────────────────────────────────────────────────────
    const content: any[] = [
      headerBlock,
      patientBar,
      ...titleBlock,

      // First page medications (up to 8)
      ...firstPageMeds.map((med, idx) => makeMedRow(med, idx)),

      // Remarks after first-page meds (only if no overflow — so they stay on page 1)
      ...(overflowMeds.length === 0 ? remarksBlock : []),

      // Signature block (absolutePosition — pinned to page 1 above footer)
      signatureBlock,
    ];

    // ─── OVERFLOW PAGES ───────────────────────────────────────────────────────
    if (overflowMeds.length > 0) {
      // Chunk overflowMeds into groups of MEDS_PER_PAGE for subsequent pages
      const chunks: typeof medications[] = [];
      for (let i = 0; i < overflowMeds.length; i += MEDS_PER_PAGE) {
        chunks.push(overflowMeds.slice(i, i + MEDS_PER_PAGE));
      }

      chunks.forEach((chunk, chunkIdx) => {
        const globalStartIdx = MEDS_PER_PAGE + chunkIdx * MEDS_PER_PAGE;

        // Force page break before each overflow chunk
        content.push({ text: "", pageBreak: "before" });

        // Continuation header (compact — just title, no patient bar repeated)
        content.push({
          stack: [
            { text: "Ordonnance Médicale — Suite", fontSize: 14, bold: true, color: DARK_TEAL },
            { text: `${doctor.name}  ·  ${today}`, fontSize: 8, color: MUTED, margin: [0, 3, 0, 0] },
          ],
          margin: [40, 24, 40, 8],
        });

        content.push({
          canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
          margin: [40, 0, 40, 12],
        });

        // Medications for this overflow page
        chunk.forEach((med, i) => {
          content.push(makeMedRow(med, globalStartIdx + i));
        });

        // Remarks after last overflow chunk
        const isLastChunk = chunkIdx === chunks.length - 1;
        if (isLastChunk) {
          content.push(...remarksBlock);
        }

        // Signature block on each overflow page (absolutePosition pins it on current page)
        content.push({
          stack: [
            {
              table: {
                widths: [160],
                body: [[{
                  text: "",
                  border: [true, true, true, true],
                  margin: [0, 45, 0, 0],
                }]],
              },
              layout: dashedBorderLayout,
            },
            {
              text: "Signature & Cachet du Médecin",
              fontSize: 8, color: MUTED, alignment: "right",
              characterSpacing: 0.4, margin: [0, 5, 55, 0],
            },
          ],
          absolutePosition: { x: SIGN_X, y: SIGN_Y },
        });
      });
    }

    // ─────────────────────────────────────────────────────────────────────────
    const docDefinition: any = {
      pageMargins: [0, 0, 0, 72],

      // ── FOOTER (pinned to absolute bottom on every page) ───────────────────
      footer: () => ({
        stack: [
          {
            canvas: [{
              type: "line",
              x1: 40, y1: 0, x2: PAGE_W - 40, y2: 0,
              lineWidth: 0.6, lineColor: SEPARATOR,
            }],
          },
          {
            columns: [
              contactFields.length > 0
                ? {
                    table: { widths: contactWidths, body: contactTableBody },
                    layout: makeFooterContactLayout(contactFields.length),
                    width: "*",
                    margin: [0, 8, 0, 0],
                  }
                : { text: "", width: "*" },
              {
                stack: [
                  { text: "MyPrescription",    fontSize: 10, bold: true, color: TEAL, alignment: "right" },
                  { text: "MYPRESCRIPTION.DZ", fontSize: 7.5, color: MUTED, alignment: "right", margin: [0, 2, 0, 0] },
                ],
                width: "auto",
                margin: [0, 8, 0, 0],
              },
            ],
            margin: [40, 0, 40, 0],
          },
          // Bottom teal bar — sits flush at page bottom
          {
            canvas: [{ type: "rect", x: 0, y: 0, w: PAGE_W, h: 10, color: TEAL }],
            margin: [0, 6, 0, 0],
          },
        ],
      }),

      content,
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "inline; filename=prescription.pdf");
    pdfDoc.pipe(res);
    pdfDoc.end();

  } catch (error) {
    console.error("Error generating prescription PDF:", error);
    return res.status(500).json({ success: false, error: "Internal server error while generating PDF" });
  }
};