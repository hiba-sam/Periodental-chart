import PdfPrinter from "pdfmake";
import type { Response } from "express";
import { OpticalCorrectionModel } from "../models/opticalCorrection.model";
import { DoctorModel } from "../models/doctor.model";
import fs from "fs";
import path from "path";

const fonts = {
  Roboto: {
    normal:      "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
    bold:        "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
    italics:     "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
    bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff",
  },
};

const printer = new PdfPrinter(fonts);

const logoPath   = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

// ─── Palette (shared with prescription + medical report) ──────────────────────
const TEAL       = "#1a7fa0";
const DARK_TEAL  = "#155f7a";
const LIGHT_TEAL = "#e8f5f9";
const QTY_BG     = "#f0f9fc";
const SEPARATOR  = "#d0e8ef";
const MUTED      = "#8aacb5";
const TEXT_MED   = "#4a7a8a";
const TEXT_DARK  = "#1a1a2e";
const PAGE_W     = 595.28;

// ─── Layouts ──────────────────────────────────────────────────────────────────

const noLayout = {
  hLineWidth: () => 0,
  vLineWidth: () => 0,
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const dashedBorderLayout = {
  hLineWidth:  () => 0.8,
  vLineWidth:  () => 0.8,
  hLineColor:  () => TEAL,
  vLineColor:  () => TEAL,
  hLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  vLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const makeFooterContactLayout = (nCols: number) => ({
  hLineWidth: () => 0,
  vLineWidth: (i: number) => (i > 0 && i < nCols ? 0.6 : 0),
  vLineColor: () => SEPARATOR,
  paddingLeft:   (i: number) => (i === 0 ? 0 : 16),
  paddingRight:  (i: number) => (i === nCols - 1 ? 0 : 16),
  paddingTop:    () => 0,
  paddingBottom: () => 0,
});

/** Optical table layout: solid teal header row, light borders elsewhere */
const opticalTableLayout = {
  hLineWidth: () => 1,
  vLineWidth: () => 1,
  hLineColor: (i: number) => (i === 0 || i === 1 ? TEAL : SEPARATOR),
  vLineColor: (i: number) => (i === 0 ? TEAL : SEPARATOR),
  paddingLeft:   () => 8,
  paddingRight:  () => 8,
  paddingTop:    () => 6,
  paddingBottom: () => 6,
  fillColor: (rowIndex: number) =>
    rowIndex === 0 ? TEAL : rowIndex % 2 === 0 ? LIGHT_TEAL : "#ffffff",
};

// ─── Main generator ───────────────────────────────────────────────────────────

export const generateOpticalCorrectionPdf = async (id: number, res: Response) => {
  try {
    if (!id || isNaN(id)) {
      return res.status(400).json({ success: false, error: "Invalid optical correction ID" });
    }

    const oc = await OpticalCorrectionModel.findByIdWithDetails(id);
    if (!oc) {
      return res.status(404).json({ success: false, error: "Optical correction not found" });
    }

    const doctorProfile = await DoctorModel.findByUserId(oc.doctor_user_id);

    const doctor = {
      name:          `Dr. ${oc.doctor.name ?? ""} ${oc.doctor.family_name ?? ""}`.trim(),
      speciality:    doctorProfile?.speciality    || "Ophtalmologiste",
      order:         doctorProfile?.order_num     || "",
      establishment: doctorProfile?.work_location || "",
      tel:           doctorProfile?.phone_number  || "",
      email:         oc.doctor.email              || "",
    };

    // ── Patient ───────────────────────────────────────────────────────────────
    const patientFullName = `${oc.patient?.name ?? ""} ${oc.patient?.family_name ?? ""}`.trim();
    const genre    = (oc.patient?.genre || "").toLowerCase();
    const sexLabel = genre === "femme" ? "Féminin" : genre === "homme" ? "Masculin" : "";
    const birthRaw: any = (oc as any).patient?.dateNaissance ?? null;
    const birthDate  = birthRaw ? new Date(birthRaw) : null;
    const birthLabel = birthDate && !isNaN(birthDate.getTime()) ? birthDate.toLocaleDateString("fr-FR") : "";
    const patientAge = (oc as any).patient?.age;
    const ageLabel   = patientAge != null ? `${patientAge} ans` : "";

    const today  = new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
    const ordNum = oc.id
      ? `N° OPT-${new Date().getFullYear()}-${String(oc.id).padStart(3, "0")}`
      : "";

    // ── Optical table ─────────────────────────────────────────────────────────
    const val = (v: any) => (v !== null && v !== undefined && v !== "") ? String(v) : "—";
    const axis = (v: any) => (v !== null && v !== undefined && v !== "") ? `${v}°` : "—";

    const tableBody = [
      // Header row
      [
        { text: "ŒIL",  bold: true, fontSize: 10, color: "white", alignment: "center" },
        { text: "SPH",   bold: true, fontSize: 10, color: "white", alignment: "center" },
        { text: "CYL",   bold: true, fontSize: 10, color: "white", alignment: "center" },
        { text: "AXE",   bold: true, fontSize: 10, color: "white", alignment: "center" },
        { text: "ADD",   bold: true, fontSize: 10, color: "white", alignment: "center" },
      ],
      // OD row
      [
        { text: "OD", bold: true, fontSize: 11, color: TEAL,      alignment: "center" },
        { text: val(oc.od_sph),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: val(oc.od_cyl),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: axis(oc.od_axis),     fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: val(oc.od_add),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
      ],
      // OG row
      [
        { text: "OG", bold: true, fontSize: 11, color: TEAL,      alignment: "center" },
        { text: val(oc.os_sph),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: val(oc.os_cyl),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: axis(oc.os_axis),     fontSize: 11, color: TEXT_DARK, alignment: "center" },
        { text: val(oc.os_add),       fontSize: 11, color: TEXT_DARK, alignment: "center" },
      ],
    ];

    // ── PD measure string ─────────────────────────────────────────────────────
    let measureText = "";
    if (oc.od_pd && oc.os_pd && oc.od_pd === oc.os_pd) {
      measureText = `PD : ${oc.od_pd} mm`;
    } else if (oc.od_pd || oc.os_pd) {
      const parts: string[] = [];
      if (oc.od_pd) parts.push(`OD : ${oc.od_pd} mm`);
      if (oc.os_pd) parts.push(`OG : ${oc.os_pd} mm`);
      measureText = `PD : ${parts.join("  —  ")}`;
    }

    // ── Footer contact fields ─────────────────────────────────────────────────
    type CF = { label: string; value: string };
    const contactFields: CF[] = [];
    if (doctor.establishment) contactFields.push({ label: "ADRESSE",   value: doctor.establishment });
    if (doctor.tel)           contactFields.push({ label: "TÉLÉPHONE", value: doctor.tel });
    if (doctor.email)         contactFields.push({ label: "EMAIL",     value: doctor.email });

    const contactTableBody = [
      contactFields.map((f) => ({
        stack: [
          { text: f.label, fontSize: 7, bold: true, color: MUTED, characterSpacing: 1.2 },
          { text: f.value, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] },
        ],
        border: [false, false, false, false],
      })),
    ];
    const contactWidths = contactFields.map(() => "auto" as const);

    // ─────────────────────────────────────────────────────────────────────────
    const docDefinition: any = {
      pageMargins: [0, 0, 0, 72],

      // ── FOOTER ───────────────────────────────────────────────────────────────
      footer: () => ({
        stack: [
          {
            canvas: [{
              type: "line",
              x1: 40, y1: 0, x2: PAGE_W - 40, y2: 0,
              lineWidth: 0.6, lineColor: SEPARATOR,
            }],
          },
          {
            columns: [
              contactFields.length > 0
                ? {
                    table: { widths: contactWidths, body: contactTableBody },
                    layout: makeFooterContactLayout(contactFields.length),
                    width: "*",
                    margin: [0, 8, 0, 0],
                  }
                : { text: "", width: "*" },
              {
                stack: [
                  { text: "MyPrescription",    fontSize: 10, bold: true, color: TEAL, alignment: "right" },
                  { text: "MYPRESCRIPTION.DZ", fontSize: 7.5, color: MUTED, alignment: "right", margin: [0, 2, 0, 0] },
                ],
                width: "auto",
                margin: [0, 8, 0, 0],
              },
            ],
            margin: [40, 0, 40, 0],
          },
          {
            canvas: [{ type: "rect", x: 0, y: 0, w: PAGE_W, h: 10, color: TEAL }],
            margin: [0, 6, 0, 0],
          },
        ],
      }),

      content: [

        // ── HEADER — full width ───────────────────────────────────────────────
        {
          table: {
            widths: ["*", "auto"],
            body: [[
              {
                stack: [
                  { text: doctor.name, fontSize: 18, bold: true, color: TEAL, lineHeight: 1.1 },
                  {
                    text: doctor.speciality.toUpperCase(),
                    fontSize: 9, color: DARK_TEAL, characterSpacing: 1,
                    margin: [0, 4, 0, 10],
                  },
                  ...(doctor.order         ? [{ text: `N° d'ordre ${doctor.order}`, fontSize: 9, color: TEXT_MED }] : []),
                  ...(doctor.establishment ? [{ text: doctor.establishment,          fontSize: 9, color: TEXT_MED }] : []),
                  ...(doctor.tel           ? [{ text: `Tél. ${doctor.tel}`,          fontSize: 9, color: TEXT_MED }] : []),
                  ...(doctor.email         ? [{ text: doctor.email,                  fontSize: 9, color: TEAL     }] : []),
                ],
                fillColor: LIGHT_TEAL,
                border: [false, false, false, false],
                margin: [40, 20, 8, 20],
              },
              {
                stack: [
                  { image: `data:image/png;base64,${logoBase64}`, width: 110, alignment: "right" },
                  ...(ordNum ? [{
                    text: ordNum,
                    fontSize: 8, color: MUTED, alignment: "right",
                    characterSpacing: 0.5, margin: [0, 6, 0, 0],
                  }] : []),
                ],
                fillColor: LIGHT_TEAL,
                border: [false, false, false, false],
                margin: [8, 20, 40, 20],
              },
            ]],
          },
          layout: noLayout,
          margin: [0, 0, 0, 0],
        },

        // ── PATIENT BAR — full width ──────────────────────────────────────────
        {
          table: {
            widths: ["*", "auto"],
            body: [[
              {
                stack: [
                  { text: "PATIENT", fontSize: 7, bold: true, color: "#cce8f0", characterSpacing: 1.5 },
                  { text: patientFullName.toUpperCase(), fontSize: 15, bold: true, color: "white", margin: [0, 2, 0, 4] },
                  {
                    columns: [
                      ...(sexLabel ? [
                        { text: "Sexe :",        fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                        { text: `  ${sexLabel}`, fontSize: 8, color: "white",   width: "auto" },
                      ] : []),
                      ...(ageLabel ? [
                        { text: sexLabel ? "      Âge :" : "Âge :", fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                        { text: `  ${ageLabel}`, fontSize: 8, color: "white",   width: "auto" },
                      ] : []),
                      ...(!ageLabel && birthLabel ? [
                        { text: "  Né(e) le :",    fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                        { text: `  ${birthLabel}`, fontSize: 8, color: "white",   width: "auto" },
                      ] : []),
                    ],
                  },
                ],
                fillColor: TEAL,
                border: [false, false, false, false],
                margin: [40, 12, 8, 12],
              },
              {
                stack: [
                  { text: "DATE",  fontSize: 7, bold: true, color: "#cce8f0", alignment: "right", characterSpacing: 1.5 },
                  { text: today,   fontSize: 13, bold: true, color: "white",  alignment: "right", margin: [0, 3, 0, 0] },
                ],
                fillColor: TEAL,
                border: [false, false, false, false],
                margin: [8, 12, 40, 12],
              },
            ]],
          },
          layout: noLayout,
          margin: [0, 12, 0, 24],
        },

        // ── SECTION TITLE ─────────────────────────────────────────────────────
        {
          stack: [
            {
              text: "Ordonnance de Correction Optique",
              fontSize: 20, bold: true, color: DARK_TEAL,
              alignment: "center",
            },
            {
              text: "PRESCRIPTION OPTIQUE",
              fontSize: 7, color: TEAL, characterSpacing: 1,
              alignment: "center", margin: [0, 4, 0, 0],
            },
          ],
          margin: [40, 0, 40, 0],
        },

        // Divider
        {
          canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
          margin: [40, 12, 40, 20],
        },

        // ── OPTICAL TABLE ─────────────────────────────────────────────────────
        {
          table: {
            headerRows: 1,
            widths: ["*", "*", "*", "*", "*"],
            body: tableBody,
          },
          layout: opticalTableLayout,
          margin: [40, 0, 40, 0],
        },

        // ── PD MEASURE ────────────────────────────────────────────────────────
        ...(measureText ? [
          {
            table: {
              widths: [4, "*"],
              body: [[
                { text: "", fillColor: TEAL, border: [false, false, false, false] },
                {
                  text: measureText,
                  fontSize: 10, color: TEXT_DARK,
                  fillColor: QTY_BG,
                  border: [false, false, false, false],
                  margin: [12, 8, 8, 8],
                },
              ]],
            },
            layout: noLayout,
            margin: [40, 10, 40, 0],
          } as any,
        ] : []),

        // ── REMARKS ───────────────────────────────────────────────────────────
        ...(oc.remarks ? [
          {
            canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
            margin: [40, 16, 40, 0],
          } as any,
          {
            table: {
              widths: [3, "*"],
              body: [[
                { text: "", fillColor: "#f0c040", border: [false, false, false, false] },
                {
                  stack: [
                    { text: "Remarques / Recommandations", bold: true, fontSize: 9, color: "#b8943a", margin: [0, 0, 0, 4] },
                    { text: oc.remarks, fontSize: 9, color: "#6b5a2a" },
                  ],
                  fillColor: "#fffbf0",
                  border: [false, false, false, false],
                  margin: [10, 8, 8, 8],
                },
              ]],
            },
            layout: noLayout,
            margin: [40, 8, 40, 0],
          } as any,
        ] : []),

        // ── SIGNATURE BOX — pinned bottom-right ───────────────────────────────
        // absolutePosition ignores margin; x = PAGE_W - 40 (right) - 160 (width) = 395
        {
          stack: [
            {
              table: {
                widths: [160],
                body: [[{
                  text: "",
                  border: [true, true, true, true],
                  margin: [0, 45, 0, 0],
                }]],
              },
              layout: dashedBorderLayout,
            },
            {
              text: "Signature & Cachet du Médecin",
              fontSize: 8, color: MUTED, alignment: "right",
              characterSpacing: 0.4, margin: [0, 5, 55, 0],
            },
          ],
          absolutePosition: { x: 395, y: 666 },
        },

      ],
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "inline; filename=ordonnance_optique.pdf");
    pdfDoc.pipe(res);
    pdfDoc.end();

  } catch (error) {
    console.error("Error generating optical correction PDF:", error);
    return res.status(500).json({ success: false, error: "Internal server error while generating PDF" });
  }
};