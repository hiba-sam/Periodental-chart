import PdfPrinter from "pdfmake";
import type { Response } from "express";
import { MedicalReportModel } from "../models/medicalReport.model";
import { DoctorModel } from "../models/doctor.model";
import fs from "fs";
import path from "path";

const fonts = {
  Roboto: {
    normal:      "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
    bold:        "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
    italics:     "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
    bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff",
  },
};

const printer = new PdfPrinter(fonts);

const logoPath   = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

// ─── Palette ──────────────────────────────────────────────────────────────────
const TEAL       = "#1a7fa0";
const DARK_TEAL  = "#155f7a";
const LIGHT_TEAL = "#e8f5f9";
const SEPARATOR  = "#d0e8ef";
const MUTED      = "#8aacb5";
const TEXT_MED   = "#4a7a8a";
const PAGE_W     = 595.28;

// ─── Layouts ──────────────────────────────────────────────────────────────────

const noLayout = {
  hLineWidth: () => 0,
  vLineWidth: () => 0,
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const dashedBorderLayout = {
  hLineWidth:  () => 0.8,
  vLineWidth:  () => 0.8,
  hLineColor:  () => TEAL,
  vLineColor:  () => TEAL,
  hLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  vLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const makeFooterContactLayout = (nCols: number) => ({
  hLineWidth: () => 0,
  vLineWidth: (i: number) => (i > 0 && i < nCols ? 0.6 : 0),
  vLineColor: () => SEPARATOR,
  paddingLeft:   (i: number) => (i === 0 ? 0 : 16),
  paddingRight:  (i: number) => (i === nCols - 1 ? 0 : 16),
  paddingTop:    () => 0,
  paddingBottom: () => 0,
});

// ─── Signature block ──────────────────────────────────────────────────────────
// absolutePosition pins it at the bottom-right of every page.
// x = PAGE_W − 40 (margin) − 160 (box) = 395.28
const SIGN_X = 395;
const SIGN_Y = 680;   // just above the 72pt footer zone

const makeSignatureBlock = (): any => ({
  stack: [
    {
      table: {
        widths: [160],
        body: [[{
          text: "",
          border: [true, true, true, true],
          margin: [0, 45, 0, 0],
        }]],
      },
      layout: dashedBorderLayout,
    },
    {
      text: "Signature & Cachet du Médecin",
      fontSize: 8, color: MUTED, alignment: "right",
      characterSpacing: 0.4, margin: [0, 5, 55, 0],
    },
  ],
  absolutePosition: { x: SIGN_X, y: SIGN_Y },
});

// ─── Line-based pagination ────────────────────────────────────────────────────
//
// Rule (same logic as medications):
//   • Each page holds exactly 21 rendered lines:
//       – 17 full-width lines  (full page margin, left=40 right=40)
//       – 4  narrow lines      (right margin=210 to clear the signature box)
//   • Paragraphs are kept whole (never split mid-sentence).
//   • Each zone always accepts at least 1 paragraph to guarantee progress.
//
// Character-per-line calibration (Roboto 10pt, lineHeight 1.2):
//   full-width column  ≈ 515pt usable → ~120 chars/line
//   narrow column      ≈ 305pt usable → ~72  chars/line
//
const CHARS_FULL        = 120;   // chars per rendered line, full column
const CHARS_NARROW      = 70;    // chars per rendered line, narrow column

const FULL_LINES_LIMIT   = 17;   // max full-width lines per page
const NARROW_LINES_LIMIT = 4;    // max narrow lines per page

// Narrow right margin: leaves 200pt for signature (160 box + 40 page margin)
const NARROW_RIGHT_MARGIN = 200;

const countFullLines   = (text: string): number =>
  Math.max(1, Math.ceil(text.length / CHARS_FULL));

const countNarrowLines = (text: string): number =>
  Math.max(1, Math.ceil(text.length / CHARS_NARROW));

// ─── Main generator ───────────────────────────────────────────────────────────

export const generateMedicalReportPdf = async (
  id: number,
  res: Response,
  requestingDoctorId: number
) => {
  try {
    if (!id || isNaN(id)) {
      return res.status(400).json({ success: false, error: "Invalid medical report ID" });
    }

    const report = await MedicalReportModel.findByIdWithDetails(id, requestingDoctorId);
    if (!report) {
      return res.status(404).json({ success: false, error: "Medical report not found" });
    }

    const doctorProfile = await DoctorModel.findByUserId(report.doctor_user_id);

    const doctor = {
      name:          `Dr. ${report.doctor.name ?? ""} ${report.doctor.family_name ?? ""}`.trim(),
      speciality:    doctorProfile?.speciality    || "Médecin généraliste",
      order:         doctorProfile?.order_num     || "",
      establishment: doctorProfile?.work_location || "",
      tel:           doctorProfile?.phone_number  || "",
      email:         report.doctor.email          || "",
    };

    const patientFullName = `${report.patient?.name ?? ""} ${report.patient?.family_name ?? ""}`.trim();
    const genre    = (report.patient?.genre || "").toLowerCase();
    const sexLabel = genre === "femme" ? "Féminin" : genre === "homme" ? "Masculin" : "";
    const birthRaw: any = (report as any).patient?.dateNaissance ?? null;
    const birthDate  = birthRaw ? new Date(birthRaw) : null;
    const birthLabel = birthDate && !isNaN(birthDate.getTime())
      ? birthDate.toLocaleDateString("fr-FR") : "";

    const examinationDate = new Date(report.examination_date);
    const formattedDate   = examinationDate.toLocaleDateString("fr-FR", {
      day: "numeric", month: "long", year: "numeric",
    });

    const ordNum = report.id
      ? `N° ORD-${new Date().getFullYear()}-${String(report.id).padStart(3, "0")}`
      : "";

    // ── Paragraphs ────────────────────────────────────────────────────────────
    const paragraphs = report.content
      .split("\n")
      .filter((p: string) => p.trim() !== "");

    // ── Footer contact fields ─────────────────────────────────────────────────
    type CF = { label: string; value: string };
    const contactFields: CF[] = [];
    if (doctor.establishment) contactFields.push({ label: "ADRESSE",   value: doctor.establishment });
    if (doctor.tel)           contactFields.push({ label: "TÉLÉPHONE", value: doctor.tel });
    if (doctor.email)         contactFields.push({ label: "EMAIL",     value: doctor.email });

    const contactTableBody = [
      contactFields.map((f) => ({
        stack: [
          { text: f.label, fontSize: 7, bold: true, color: MUTED, characterSpacing: 1.2 },
          { text: f.value, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] },
        ],
        border: [false, false, false, false],
      })),
    ];
    const contactWidths = contactFields.map(() => "auto" as const);

    // ─── Distribute paragraphs across pages ───────────────────────────────────
    //
    // Each page: FULL_LINES_LIMIT full-width lines, then NARROW_LINES_LIMIT
    // narrow lines (beside the signature box). Same rule for every page.
    // Paragraphs are never split; each paragraph goes whole into one zone.
    // ─────────────────────────────────────────────────────────────────────────

    type PageDef = { fullParas: string[]; narrowParas: string[] };
    const pages: PageDef[] = [];
    const remaining = [...paragraphs];

    while (remaining.length > 0) {
      const fullParas: string[]   = [];
      const narrowParas: string[] = [];
      let fullLines   = 0;
      let narrowLines = 0;

      // Fill full-width zone
      while (remaining.length > 0) {
        const first = remaining[0]!;
        const lines = countFullLines(first);
        if (fullLines + lines > FULL_LINES_LIMIT && fullParas.length > 0) break;
        fullLines += lines;
        fullParas.push(remaining.shift()!);
      }

      // Fill narrow zone (beside the signature box)
      while (remaining.length > 0) {
        const first = remaining[0]!;
        const lines = countNarrowLines(first);
        if (narrowLines + lines > NARROW_LINES_LIMIT && narrowParas.length > 0) break;
        narrowLines += lines;
        narrowParas.push(remaining.shift()!);
      }

      // Safety: always make progress even for a single very-long paragraph
      if (fullParas.length === 0 && narrowParas.length === 0 && remaining.length > 0) {
        narrowParas.push(remaining.shift()!);
      }

      pages.push({ fullParas, narrowParas });
    }

    if (pages.length === 0) pages.push({ fullParas: [], narrowParas: [] });

    // ─── Element builders ─────────────────────────────────────────────────────

    const makeFullParaEl = (text: string): any => ({
      text,
      fontSize: 10,
      color: "#333333",
      alignment: "justify",
      lineHeight: 1.2,
      margin: [40, 0, 40, 8],
    });

    const makeNarrowParaEl = (text: string): any => ({
      text,
      fontSize: 10,
      color: "#333333",
      alignment: "justify",
      lineHeight: 1.2,
      margin: [40, 0, NARROW_RIGHT_MARGIN, 8],
    });

    // ─── Build content ────────────────────────────────────────────────────────

    const content: any[] = [];

    // ── HEADER ───────────────────────────────────────────────────────────────
    content.push({
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            stack: [
              { text: doctor.name, fontSize: 18, bold: true, color: TEAL, lineHeight: 1.1 },
              {
                text: doctor.speciality.toUpperCase(),
                fontSize: 9, color: DARK_TEAL, characterSpacing: 1,
                margin: [0, 4, 0, 10],
              },
              ...(doctor.order         ? [{ text: `N° d'ordre ${doctor.order}`, fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.establishment ? [{ text: doctor.establishment,          fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.tel           ? [{ text: `Tél. ${doctor.tel}`,          fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.email         ? [{ text: doctor.email,                  fontSize: 9, color: TEAL     }] : []),
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [40, 20, 8, 20],
          },
          {
            stack: [
              { image: `data:image/png;base64,${logoBase64}`, width: 110, alignment: "right" },
              ...(ordNum ? [{
                text: ordNum,
                fontSize: 8, color: MUTED, alignment: "right",
                characterSpacing: 0.5, margin: [0, 6, 0, 0],
              }] : []),
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [8, 20, 40, 20],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 0, 0, 0],
    });

    // ── PATIENT BAR ──────────────────────────────────────────────────────────
    content.push({
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            stack: [
              { text: "PATIENT", fontSize: 7, bold: true, color: "#cce8f0", characterSpacing: 1.5 },
              { text: patientFullName.toUpperCase(), fontSize: 15, bold: true, color: "white", margin: [0, 2, 0, 4] },
              {
                columns: [
                  ...(sexLabel ? [
                    { text: "Sexe :",        fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                    { text: `  ${sexLabel}`, fontSize: 8, color: "white",   width: "auto" },
                  ] : []),
                  ...(birthLabel ? [
                    { text: sexLabel ? "      Né(e) le :" : "Né(e) le :", fontSize: 8, color: "#cce8f0", bold: true, width: "auto" },
                    { text: `  ${birthLabel}`,                              fontSize: 8, color: "white",   width: "auto" },
                  ] : []),
                ],
              },
            ],
            fillColor: TEAL,
            border: [false, false, false, false],
            margin: [40, 12, 8, 12],
          },
          {
            stack: [
              { text: "DATE",          fontSize: 7,  bold: true, color: "#cce8f0", alignment: "right", characterSpacing: 1.5 },
              { text: formattedDate,   fontSize: 13, bold: true, color: "white",   alignment: "right", margin: [0, 3, 0, 0] },
            ],
            fillColor: TEAL,
            border: [false, false, false, false],
            margin: [8, 12, 40, 12],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 12, 0, 24],
    });

    // ── REPORT TITLE ─────────────────────────────────────────────────────────
    content.push({
      stack: [
        {
          text: report.title,
          fontSize: 20, bold: true, color: DARK_TEAL,
          decoration: "underline", decorationStyle: "solid",
          alignment: "center",
        },
        {
          text: "COMPTE RENDU MÉDICAL",
          fontSize: 7, color: TEAL, characterSpacing: 1,
          alignment: "center", margin: [0, 4, 0, 0],
        },
      ],
      margin: [40, 0, 40, 0],
    });

    // Divider
    content.push({
      canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
      margin: [40, 12, 40, 16],
    });

    // Intro line
    content.push({
      text: `Concernant ${patientFullName},`,
      fontSize: 10, bold: true, color: DARK_TEAL,
      margin: [40, 0, 40, 14],
    });

    // ── Page 1 ───────────────────────────────────────────────────────────────
    const page0 = pages[0]!;
    page0.fullParas.forEach((p)   => content.push(makeFullParaEl(p)));
    page0.narrowParas.forEach((p) => content.push(makeNarrowParaEl(p)));
    content.push(makeSignatureBlock());

    // ── Continuation pages ────────────────────────────────────────────────────
    for (let pi = 1; pi < pages.length; pi++) {
      const page = pages[pi]!;

      content.push({ text: "", pageBreak: "before" });

      // Compact continuation header
      content.push({
        stack: [
          { text: `${report.title} — Suite`, fontSize: 14, bold: true, color: DARK_TEAL },
          { text: `${doctor.name}  ·  ${formattedDate}`, fontSize: 8, color: MUTED, margin: [0, 3, 0, 0] },
        ],
        margin: [40, 24, 40, 8],
      });

      content.push({
        canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
        margin: [40, 0, 40, 12],
      });

      page.fullParas.forEach((p)   => content.push(makeFullParaEl(p)));
      page.narrowParas.forEach((p) => content.push(makeNarrowParaEl(p)));
      content.push(makeSignatureBlock());
    }

    // ─────────────────────────────────────────────────────────────────────────
    const docDefinition: any = {
      pageMargins: [0, 0, 0, 72],

      footer: () => ({
        stack: [
          {
            canvas: [{
              type: "line",
              x1: 40, y1: 0, x2: PAGE_W - 40, y2: 0,
              lineWidth: 0.6, lineColor: SEPARATOR,
            }],
          },
          {
            columns: [
              contactFields.length > 0
                ? {
                    table: { widths: contactWidths, body: contactTableBody },
                    layout: makeFooterContactLayout(contactFields.length),
                    width: "*",
                    margin: [0, 8, 0, 0],
                  }
                : { text: "", width: "*" },
              {
                stack: [
                  { text: "MyPrescription",    fontSize: 10, bold: true, color: TEAL, alignment: "right" },
                  { text: "MYPRESCRIPTION.DZ", fontSize: 7.5, color: MUTED, alignment: "right", margin: [0, 2, 0, 0] },
                ],
                width: "auto",
                margin: [0, 8, 0, 0],
              },
            ],
            margin: [40, 0, 40, 0],
          },
          {
            canvas: [{ type: "rect", x: 0, y: 0, w: PAGE_W, h: 10, color: TEAL }],
            margin: [0, 6, 0, 0],
          },
        ],
      }),

      content,
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename=compte-rendu-${report.id}.pdf`);
    pdfDoc.pipe(res);
    pdfDoc.end();

  } catch (error) {
    console.error("Error generating medical report PDF:", error);
    return res.status(500).json({ success: false, error: "Internal server error while generating PDF" });
  }
};