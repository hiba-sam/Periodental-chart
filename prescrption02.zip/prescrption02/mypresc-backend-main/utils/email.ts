import nodemailer from 'nodemailer';

// Email options interface
interface EmailOptions {
    to: string;
    subject: string;
    text?: string;
    html?: string;
    attachments?: Array<{
        filename: string;
        content: Buffer;
        contentType?: string;
    }>;
}

class EmailService {
    private transporter: nodemailer.Transporter;

    constructor() {
        this.transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST || 'smtp.gmail.com',
            port: parseInt(process.env.SMTP_PORT || '587'),
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER || '',
                pass: process.env.SMTP_PASS || ''
            }
        });
    }

    async sendEmail(options: EmailOptions): Promise<boolean> {
        try {
            const mailOptions = {
                from: `"${process.env.APP_NAME || 'MyPresc'}" <${process.env.SMTP_USER}>`,
                to: options.to,
                subject: options.subject,
                text: options.text,
                html: options.html,
                attachments: options.attachments || []
            };

            await this.transporter.sendMail(mailOptions);
            return true;
        } catch (error) {
            console.error('Failed to send email:', error);
            return false;
        }
    }

    async sendRegistrationToTeam(approve_link: string, reject_link: string, userData: any, doctorData?: any): Promise<boolean> {
        const subject = '🔔 Nouvelle demande d\'inscription - MyPrescription';
        const teamEmail = process.env.TEAM_EMAIL || 'contact@myprescription.dz';

        // Lien vers le dashboard admin - page de détails directe
        const dashboardUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        const dashboardLink = `${dashboardUrl}/admin/registrations/${userData.id}`;

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nouvelle demande d'inscription</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    
                    <!-- Header avec gradient -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">🏥</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">MyPrescription</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">Système d'Administration</p>
                        </td>
                    </tr>
                    
                    <!-- Badge de notification -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #FFA500; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(255,165,0,0.3);">
                                    🔔 Nouvelle demande en attente
                                </span>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Demande d'inscription reçue
                            </h2>
                            <p style="margin: 0 0 30px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Un nouveau ${userData.role === 'doctor' ? 'médecin' : 'utilisateur'} s'est inscrit et attend votre validation.
                            </p>
                            
                            <!-- Informations utilisateur -->
                            <div style="background: linear-gradient(135deg, #f6f8fb 0%, #e9ecef 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #2d3748; font-size: 16px; font-weight: 700; display: flex; align-items: center;">
                                    👤 Informations Personnelles
                                </h3>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="padding: 8px 0; color: #718096; font-size: 14px; font-weight: 600;">Nom complet</td>
                                        <td style="padding: 8px 0; color: #1a202c; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${userData.role === 'doctor' ? 'Dr. ' : ''}${userData.name} ${userData.family_name}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #718096; font-size: 14px; font-weight: 600;">Email</td>
                                        <td style="padding: 8px 0; color: #1a202c; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${userData.email}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #718096; font-size: 14px; font-weight: 600;">Rôle</td>
                                        <td style="padding: 8px 0; text-align: right;">
                                            <span style="background-color: #4299e1; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; text-transform: capitalize;">
                                                ${userData.role}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #718096; font-size: 14px; font-weight: 600;">Date d'inscription</td>
                                        <td style="padding: 8px 0; color: #1a202c; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${new Date().toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}
                                        </td>
                                    </tr>
                                </table>
                            </div>

                            ${doctorData ? `
                            <!-- Informations médicales -->
                            <div style="background: linear-gradient(135deg, #e6f7ff 0%, #d1ecf1 100%); border-left: 4px solid #17a2b8; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #2d3748; font-size: 16px; font-weight: 700; display: flex; align-items: center;">
                                    🩺 Informations Médicales
                                </h3>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="padding: 8px 0; color: #0c5460; font-size: 14px; font-weight: 600;">Spécialité</td>
                                        <td style="padding: 8px 0; color: #004085; font-size: 14px; font-weight: 700; text-align: right;">
                                            ${doctorData.speciality || 'N/A'}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #0c5460; font-size: 14px; font-weight: 600;">Expérience</td>
                                        <td style="padding: 8px 0; color: #004085; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${doctorData.experience || 'N/A'} ans
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #0c5460; font-size: 14px; font-weight: 600;">N° Ordre</td>
                                        <td style="padding: 8px 0; color: #004085; font-size: 14px; font-weight: 500; text-align: right; font-family: 'Courier New', monospace;">
                                            ${doctorData.order_num || 'N/A'}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #0c5460; font-size: 14px; font-weight: 600;">Lieu d'exercice</td>
                                        <td style="padding: 8px 0; color: #004085; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${doctorData.work_location || 'N/A'}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #0c5460; font-size: 14px; font-weight: 600;">Date de naissance</td>
                                        <td style="padding: 8px 0; color: #004085; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${doctorData.birth_date || 'N/A'} (${doctorData.birth_place || 'N/A'})
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            ` : ''}
                            
                            <!-- Call to action -->
                            <div style="background: linear-gradient(135deg, #fff9e6 0%, #ffe5b4 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; border: 2px dashed #ffa500;">
                                <p style="margin: 0 0 20px; color: #744210; font-size: 15px; font-weight: 600; text-align: center;">
                                    ⚠️ Action requise
                                </p>
                                <p style="margin: 0 0 24px; color: #744210; font-size: 14px; line-height: 1.5; text-align: center;">
                                    Cette demande nécessite votre validation. Le lien ci-dessous vous emmènera directement vers la page de détails de cette inscription dans un nouvel onglet.
                                </p>
                                
                                <!-- Gros bouton principal -->
                                <div style="text-align: center;">
                                    <a href="${dashboardLink}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 16px 40px; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 16px; box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); transition: all 0.3s;">
                                        🔍 Voir les Détails et Valider →
                                    </a>
                                </div>
                                
                                <!-- Lien alternatif -->
                                <p style="margin: 20px 0 0; color: #744210; font-size: 12px; text-align: center;">
                                    Ou copiez ce lien : <br>
                                    <a href="${dashboardLink}" target="_blank" rel="noopener noreferrer" style="color: #667eea; word-break: break-all; font-size: 11px;">
                                        ${dashboardLink}
                                    </a>
                                </p>
                            </div>
                            
                            <!-- Info sécurité -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    🔐 <strong>Sécurité :</strong> Pour valider cette demande, vous devrez vous connecter au dashboard admin. Toutes vos actions seront enregistrées dans les logs d'audit.
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Cet email a été envoyé automatiquement par le système MyPrescription
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: teamEmail, subject, html });
    }

    /**
     * Envoyer un email de bienvenue après approbation
     */
    async sendApprovalEmail(userEmail: string, userName: string): Promise<boolean> {
        const subject = '🎉 Bienvenue dans MyPrescription !';
        const loginUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compte approuvé</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    
                    <!-- Header avec gradient vert -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">✅</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Compte Approuvé !</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">MyPrescription</p>
                        </td>
                    </tr>
                    
                    <!-- Badge de succès -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #10b981; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(16,185,129,0.3);">
                                    🎉 Félicitations
                                </span>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Bienvenue Dr. ${userName} !
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Nous sommes ravis de vous annoncer que votre compte a été <strong>approuvé avec succès</strong> ! 🎊
                            </p>
                            <p style="margin: 0 0 30px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Vous faites maintenant partie de l'équipe <strong>MyPrescription</strong> et vous pouvez commencer à utiliser toutes les fonctionnalités de notre plateforme.
                            </p>
                            
                            <!-- Avantages -->
                            <div style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #065f46; font-size: 16px; font-weight: 700;">
                                    🚀 Ce que vous pouvez faire maintenant :
                                </h3>
                                <ul style="margin: 0; padding-left: 20px; color: #047857; line-height: 1.8;">
                                    <li>Gérer vos patients et rendez-vous</li>
                                    <li>Créer et gérer des prescriptions</li>
                                    <li>Accéder au calendrier médical</li>
                                    <li>Utiliser la salle d'attente virtuelle</li>
                                    <li>Communiquer avec vos patients</li>
                                </ul>
                            </div>
                            
                            <!-- Bouton de connexion -->
                            <div style="background: linear-gradient(135deg, #fff9e6 0%, #fef3c7 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center;">
                                <p style="margin: 0 0 20px; color: #92400e; font-size: 15px; font-weight: 600;">
                                    Commencez dès maintenant !
                                </p>
                                <a href="${loginUrl}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 16px 40px; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 16px; box-shadow: 0 10px 25px rgba(16,185,129,0.4);">
                                    🔐 Se Connecter →
                                </a>
                            </div>
                            
                            <!-- Informations utiles -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0 0 10px; color: #1e40af; font-size: 14px; font-weight: 600;">
                                    📧 Besoin d'aide ?
                                </p>
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    Notre équipe support est à votre disposition : <a href="mailto:${process.env.TEAM_EMAIL}" style="color: #2563eb; text-decoration: none;">${process.env.TEAM_EMAIL}</a>
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Merci de rejoindre MyPrescription ! 🙏
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: userEmail, subject, html });
    }

    /**
     * Envoyer un email de refus
     */
    async sendRejectionEmail(userEmail: string, userName: string, reason?: string): Promise<boolean> {
        const subject = '❌ Inscription refusée - MyPrescription';
        const contactEmail = process.env.TEAM_EMAIL || 'contact@mypresc.com';

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription refusée</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    
                    <!-- Header avec gradient rouge -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">ℹ️</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Inscription Refusée</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">MyPrescription</p>
                        </td>
                    </tr>
                    
                    <!-- Badge de notification -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #ef4444; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(239,68,68,0.3);">
                                    ⚠️ Compte non approuvé
                                </span>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Bonjour Dr. ${userName},
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Nous vous remercions de l'intérêt que vous portez à <strong>MyPrescription</strong>.
                            </p>
                            <p style="margin: 0 0 30px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Malheureusement, après examen de votre demande d'inscription, nous ne pouvons pas l'approuver à ce stade.
                            </p>
                            
                            ${reason ? `
                            <!-- Raison du refus -->
                            <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 12px; color: #991b1b; font-size: 16px; font-weight: 700;">
                                    📋 Raison :
                                </h3>
                                <p style="margin: 0; color: #7f1d1d; font-size: 14px; line-height: 1.6;">
                                    ${reason}
                                </p>
                            </div>
                            ` : ''}
                            
                            <!-- Contact -->
                            <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #1e40af; font-size: 16px; font-weight: 700;">
                                    💬 Besoin d'informations supplémentaires ?
                                </h3>
                                <p style="margin: 0 0 16px; color: #1e3a8a; font-size: 14px; line-height: 1.6;">
                                    Si vous souhaitez obtenir plus d'informations sur cette décision ou si vous pensez qu'il s'agit d'une erreur, n'hésitez pas à nous contacter :
                                </p>
                                
                                <!-- Boutons de contact -->
                                <div style="text-align: center; margin: 20px 0;">
                                    <a href="mailto:${contactEmail}" style="display: inline-block; background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 12px 32px; text-decoration: none; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 6px 15px rgba(37,99,235,0.4); margin: 5px;">
                                        📧 Envoyer un Email
                                    </a>
                                </div>
                                
                                <p style="margin: 16px 0 0; color: #1e3a8a; font-size: 12px; text-align: center;">
                                    Email : <a href="mailto:${contactEmail}" style="color: #2563eb; text-decoration: none;">${contactEmail}</a>
                                </p>
                            </div>
                            
                            <!-- Informations complémentaires -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    <strong>Note :</strong> Cette décision peut être révisée. Notre équipe reste à votre disposition pour toute question ou clarification.
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Merci de votre compréhension
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: userEmail, subject, html });
    }


    async sendDemandRegistrationToTeam(demandData: {
        firstName: string;
        lastName: string;
        email: string;
        phone: string;
        specialty: string;
        id: string;
        created_at: Date;
    }): Promise<boolean> {
        const subject = 'New Doctor Registration Demand - MyPresc';
        const teamEmail = process.env.TEAM_EMAIL || 'contact@myprescription.dz';

        const html = `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
                    <h1 style="color: #ffffff; margin: 0; font-size: 28px;">New Doctor Registration Demand</h1>
                </div>

                <div style="padding: 30px; background-color: #f8f9fa;">
                    <p style="font-size: 16px; color: #333; margin-bottom: 20px;">
                        A new doctor has submitted a registration demand and is waiting for review:
                    </p>

                    <div style="background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin: 20px 0;">
                        <h3 style="color: #667eea; margin-top: 0; border-bottom: 2px solid #667eea; padding-bottom: 10px;">
                            Doctor Information
                        </h3>
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="padding: 10px 0; color: #666; font-weight: bold; width: 40%;">Full Name:</td>
                                <td style="padding: 10px 0; color: #333;">${demandData.firstName} ${demandData.lastName}</td>
                            </tr>
                            <tr style="background-color: #f8f9fa;">
                                <td style="padding: 10px 0; color: #666; font-weight: bold;">Email:</td>
                                <td style="padding: 10px 0; color: #333;">
                                    <a href="mailto:${demandData.email}" style="color: #667eea; text-decoration: none;">
                                        ${demandData.email}
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 10px 0; color: #666; font-weight: bold;">Phone:</td>
                                <td style="padding: 10px 0; color: #333;">
                                    <a href="tel:${demandData.phone}" style="color: #667eea; text-decoration: none;">
                                        ${demandData.phone}
                                    </a>
                                </td>
                            </tr>
                            <tr style="background-color: #f8f9fa;">
                                <td style="padding: 10px 0; color: #666; font-weight: bold;">Specialty:</td>
                                <td style="padding: 10px 0; color: #333;">
                                    <span style="background-color: #667eea; color: white; padding: 4px 12px; border-radius: 15px; font-size: 14px;">
                                        ${demandData.specialty}
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 10px 0; color: #666; font-weight: bold;">Demand ID:</td>
                                <td style="padding: 10px 0; color: #999; font-family: monospace; font-size: 12px;">
                                    ${demandData.id}
                                </td>
                            </tr>
                            <tr style="background-color: #f8f9fa;">
                                <td style="padding: 10px 0; color: #666; font-weight: bold;">Submitted:</td>
                                <td style="padding: 10px 0; color: #333;">
                                    ${new Date(demandData.created_at).toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div style="background-color: #fff3cd; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; margin: 20px 0;">
                        <p style="margin: 0; color: #856404;">
                            <strong>⚠️ Action Required:</strong> Please review this demand and contact the doctor to proceed with the registration process.
                        </p>
                    </div>
                </div>

                <div style="background-color: #2c3e50; padding: 20px; text-align: center; color: #ecf0f1;">
                    <p style="margin: 0; font-size: 14px;">
                        © ${new Date().getFullYear()} MyPresc - Medical Prescription Management System
                    </p>
                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #95a5a6;">
                        This is an automated notification. Please do not reply to this email.
                    </p>
                </div>
            </div>
        `;

        return await this.sendEmail({ to: teamEmail, subject, html });
    }

    async sendPaymentSuccessEmail(
        userEmail: string,
        userName: string,
        plan: string,
        amount: number,
        transactionId: string,
        invoicePdf?: Buffer,
        invoiceNumber?: string
    ): Promise<boolean> {
        const subject = 'Paiement Réussi - MyPrescription';
        const planDetails: Record<string, { name: string; duration: string }> = {
            flex: { name: 'Flex', duration: '30 jours' },
            smart: { name: 'Smart', duration: '180 jours' },
            pro: { name: 'Pro', duration: '365 jours' }
        };
        const selectedPlan = planDetails[plan] || { name: plan, duration: 'N/A' };

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement Réussi</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">

                    <!-- Header avec gradient vert -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">✅</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Paiement Réussi !</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">MyPrescription</p>
                        </td>
                    </tr>

                    <!-- Badge de succès -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #10b981; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(16,185,129,0.3);">
                                    🎉 Transaction Confirmée
                                </span>
                            </div>
                        </td>
                    </tr>

                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Merci Dr. ${userName} !
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Votre paiement a été traité avec succès. Votre abonnement <strong>${selectedPlan.name}</strong> est maintenant actif.
                            </p>

                            <!-- Détails du paiement -->
                            <div style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #065f46; font-size: 16px; font-weight: 700;">
                                    📋 Détails de la Transaction
                                </h3>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="padding: 8px 0; color: #047857; font-size: 14px; font-weight: 600;">Plan</td>
                                        <td style="padding: 8px 0; color: #065f46; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${selectedPlan.name}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #047857; font-size: 14px; font-weight: 600;">Durée</td>
                                        <td style="padding: 8px 0; color: #065f46; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${selectedPlan.duration}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #047857; font-size: 14px; font-weight: 600;">Montant</td>
                                        <td style="padding: 8px 0; color: #065f46; font-size: 18px; font-weight: 700; text-align: right;">
                                            ${amount} DZD
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #047857; font-size: 14px; font-weight: 600;">Transaction ID</td>
                                        <td style="padding: 8px 0; color: #065f46; font-size: 12px; font-family: monospace; text-align: right;">
                                            ${transactionId}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #047857; font-size: 14px; font-weight: 600;">Date</td>
                                        <td style="padding: 8px 0; color: #065f46; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${new Date().toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        })}
                                        </td>
                                    </tr>
                                </table>
                            </div>

                            <!-- Info -->
                            <div style="background-color: #eff6ff; border-left: 4px solid #2563eb; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #1e40af; font-size: 13px; line-height: 1.5;">
                                    💼 Votre abonnement est maintenant actif et vous pouvez profiter de toutes les fonctionnalités premium de MyPrescription.
                                </p>
                            </div>

                            ${invoicePdf ? `
                            <!-- Invoice attachment notice -->
                            <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-left: 4px solid #f59e0b; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #92400e; font-size: 13px; line-height: 1.5;">
                                    📎 <strong>Facture jointe</strong> : Votre facture (${invoiceNumber || 'N/A'}) est jointe à cet email au format PDF.
                                </p>
                            </div>
                            ` : ''}

                            <!-- Support -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 16px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    📧 Des questions ? Contactez-nous : <a href="mailto:${process.env.TEAM_EMAIL}" style="color: #2563eb; text-decoration: none;">${process.env.TEAM_EMAIL}</a>
                                </p>
                            </div>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Merci d'utiliser MyPrescription !
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        const attachments = invoicePdf && invoiceNumber ? [
            {
                filename: `${invoiceNumber}.pdf`,
                content: invoicePdf,
                contentType: 'application/pdf'
            }
        ] : undefined;

        return await this.sendEmail({ to: userEmail, subject, html, attachments });
    }

    async sendPaymentFailedEmail(
        userEmail: string,
        userName: string,
        plan: string,
        amount: number,
        reason?: string
    ): Promise<boolean> {
        const subject = 'Échec du Paiement - MyPrescription';
        const planDetails: Record<string, { name: string; duration: string }> = {
            flex: { name: 'Flex', duration: '30 jours' },
            smart: { name: 'Smart', duration: '180 jours' },
            pro: { name: 'Pro', duration: '365 jours' }
        };
        const selectedPlan = planDetails[plan] || { name: plan, duration: 'N/A' };
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        const retryUrl = `${frontendUrl}/subscription`;

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Échec du Paiement</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">

                    <!-- Header avec gradient rouge -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">❌</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Échec du Paiement</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">MyPrescription</p>
                        </td>
                    </tr>

                    <!-- Badge -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #ef4444; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(239,68,68,0.3);">
                                    ⚠️ Transaction Échouée
                                </span>
                            </div>
                        </td>
                    </tr>

                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Bonjour Dr. ${userName},
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Malheureusement, votre paiement pour l'abonnement <strong>${selectedPlan.name}</strong> n'a pas pu être traité.
                            </p>

                            ${reason ? `
                            <!-- Raison -->
                            <div style="background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); border-left: 4px solid #ef4444; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 12px; color: #991b1b; font-size: 16px; font-weight: 700;">
                                    📋 Raison :
                                </h3>
                                <p style="margin: 0; color: #7f1d1d; font-size: 14px; line-height: 1.6;">
                                    ${reason}
                                </p>
                            </div>
                            ` : ''}

                            <!-- Détails -->
                            <div style="background: linear-gradient(135deg, #f0f4f8 0%, #e0e7ef 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #2d3748; font-size: 16px; font-weight: 700;">
                                    📋 Détails de la Tentative
                                </h3>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <tr>
                                        <td style="padding: 8px 0; color: #4a5568; font-size: 14px; font-weight: 600;">Plan</td>
                                        <td style="padding: 8px 0; color: #2d3748; font-size: 14px; font-weight: 500; text-align: right;">
                                            ${selectedPlan.name}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; color: #4a5568; font-size: 14px; font-weight: 600;">Montant</td>
                                        <td style="padding: 8px 0; color: #2d3748; font-size: 18px; font-weight: 700; text-align: right;">
                                            ${amount} DZD
                                        </td>
                                    </tr>
                                </table>
                            </div>

                            <!-- Retry button -->
                            <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center;">
                                <p style="margin: 0 0 20px; color: #1e40af; font-size: 15px; font-weight: 600;">
                                    Réessayer le paiement
                                </p>
                                <a href="${retryUrl}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 16px 40px; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 16px; box-shadow: 0 10px 25px rgba(37,99,235,0.4);">
                                    🔄 Réessayer Maintenant →
                                </a>
                            </div>

                            <!-- Support -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    💬 Besoin d'aide ? Contactez notre support : <a href="mailto:${process.env.TEAM_EMAIL}" style="color: #2563eb; text-decoration: none;">${process.env.TEAM_EMAIL}</a>
                                </p>
                            </div>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                MyPrescription - Gestion Médicale
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: userEmail, subject, html });
    }

    async sendRegistrationConfirmationToDoctor(doctorEmail: string, doctorName: string): Promise<boolean> {
        const subject = 'Inscription Soumise avec Succès - MyPresc';

        const html = `
            <div style="font-family: Arial, sans-serif; max-width: 650px; margin: 0 auto; background-color: #ffffff;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
                    <h1 style="color: #ffffff; margin: 0; font-size: 32px;">✓ Inscription Reçue !</h1>
                    <p style="color: #f0f0f0; margin: 15px 0 0 0; font-size: 18px;">Merci de rejoindre MyPresc</p>
                </div>

                <div style="padding: 40px 30px; background-color: #f8f9fa;">
                    <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 25px;">
                        <h2 style="color: #667eea; margin-top: 0;">Cher Dr. ${doctorName},</h2>
                        <p style="color: #555; font-size: 16px; line-height: 1.6;">
                            Nous avons bien reçu votre demande d'inscription à MyPresc - Système de Gestion des Ordonnances Médicales.
                        </p>
                        <p style="color: #555; font-size: 16px; line-height: 1.6;">
                            Votre candidature est actuellement en cours d'examen par notre équipe. Nous vérifions soigneusement toutes les informations des médecins afin de maintenir les normes les plus élevées de notre plateforme.
                        </p>
                    </div>

                    <div style="background-color: #e7f3ff; padding: 25px; border-radius: 8px; border-left: 4px solid #2196F3; margin-bottom: 25px;">
                        <h3 style="color: #1976d2; margin: 0 0 15px 0;">⏱️ Prochaines Étapes</h3>
                        <div style="color: #555;">
                            <div style="margin: 15px 0; padding-left: 20px;">
                                <strong style="color: #1976d2;">Étape 1 :</strong> Notre équipe examine vos documents soumis
                            </div>
                            <div style="margin: 15px 0; padding-left: 20px;">
                                <strong style="color: #1976d2;">Étape 2 :</strong> Nous vérifions vos informations et licences médicales
                            </div>
                            <div style="margin: 15px 0; padding-left: 20px;">
                                <strong style="color: #1976d2;">Étape 3 :</strong> Vous recevrez un email avec la décision
                            </div>
                            <div style="margin: 15px 0; padding-left: 20px;">
                                <strong style="color: #1976d2;">Étape 4 :</strong> Une fois approuvé, vous pourrez commencer à utiliser la plateforme
                            </div>
                        </div>
                    </div>

                    <div style="background-color: #fff3cd; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; margin-bottom: 25px;">
                        <h3 style="color: #856404; margin: 0 0 10px 0;">📅 Délai d'Examen</h3>
                        <p style="color: #856404; margin: 0; font-size: 15px;">
                            <strong>Temps d'examen prévu :</strong> jusqu'à <strong>7 jours ouvrables</strong>
                        </p>
                        <p style="color: #856404; margin: 10px 0 0 0; font-size: 14px;">
                            Nous visons à terminer l'examen le plus rapidement possible, généralement dans un délai de 3 à 5 jours ouvrables.
                        </p>
                    </div>

                    <div style="background-color: #ffffff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                        <h3 style="color: #667eea; margin: 0 0 15px 0;">📞 Besoin d'Aide ?</h3>
                        <p style="color: #555; font-size: 15px; margin: 0 0 10px 0;">
                            Si vous avez des questions concernant votre inscription ou si vous souhaitez mettre à jour vos informations, veuillez contacter notre équipe de support :
                        </p>
                        <p style="color: #555; font-size: 15px; margin: 10px 0;">
                            <strong>Email :</strong> <a href="mailto:${process.env.TEAM_EMAIL || 'support@mypresc.com'}" style="color: #667eea; text-decoration: none;">${process.env.TEAM_EMAIL || 'support@mypresc.com'}</a>
                        </p>
                        <p style="color: #555; font-size: 15px; margin: 10px 0;">
                            <strong>Temps de réponse :</strong> Dans les 24 heures
                        </p>
                    </div>

                    <div style="text-align: center; margin-top: 30px; padding: 20px;">
                        <p style="color: #666; font-size: 14px; margin: 0;">
                            Nous sommes ravis de vous accueillir sur notre plateforme !
                        </p>
                        <p style="color: #667eea; font-size: 18px; font-weight: bold; margin: 10px 0 0 0;">
                            L'Équipe MyPresc
                        </p>
                    </div>
                </div>

                <div style="background-color: #2c3e50; padding: 25px 30px; text-align: center; color: #ecf0f1;">
                    <p style="margin: 0; font-size: 14px;">
                        © ${new Date().getFullYear()} MyPresc - Système de Gestion des Ordonnances Médicales
                    </p>
                    <p style="margin: 10px 0 0 0; font-size: 12px; color: #95a5a6;">
                        Ceci est une notification automatique. Veuillez ne pas répondre à cet email.
                    </p>
                    <p style="margin: 15px 0 0 0; font-size: 12px; color: #95a5a6;">
                        Vous avez reçu cet email car vous vous êtes inscrit pour un compte MyPresc.
                    </p>
                </div>
            </div>`
            ;

        return await this.sendEmail({ to: doctorEmail, subject, html });
    }

    async sendAssistantInvitation(
        assistantEmail: string,
        assistantName: string,
        doctorName: string,
        invitationToken: string
    ): Promise<boolean> {
        const subject = 'Invitation à rejoindre MyPrescription - Assistant Médical';
        const frontendUrl = process.env.WEBSITE_URL || 'https://myprescription.dz';
        const invitationLink = `${frontendUrl}/assistant-registration?invitationToken=${invitationToken}`;

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invitation Assistant</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">

                    <!-- Header avec gradient -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">👋</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Invitation à MyPrescription</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">Assistant Médical</p>
                        </td>
                    </tr>

                    <!-- Badge de notification -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #10b981; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(16,185,129,0.3);">
                                    ✉️ Vous êtes invité(e)
                                </span>
                            </div>
                        </td>
                    </tr>

                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Bonjour ${assistantName} !
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                <strong>Dr. ${doctorName}</strong> vous invite à rejoindre son équipe sur MyPrescription en tant qu'assistant(e) médical(e).
                            </p>
                            <p style="margin: 0 0 30px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                MyPrescription est une plateforme moderne de gestion des prescriptions et des rendez-vous médicaux qui facilitera votre travail quotidien.
                            </p>

                            <!-- Avantages -->
                            <div style="background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-left: 4px solid #10b981; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                                <h3 style="margin: 0 0 16px; color: #065f46; font-size: 16px; font-weight: 700;">
                                    🎯 En tant qu'assistant(e), vous pourrez :
                                </h3>
                                <ul style="margin: 0; padding-left: 20px; color: #047857; line-height: 1.8;">
                                    <li>Gérer les rendez-vous et le calendrier</li>
                                    <li>Gérer la salle d'attente virtuelle</li>
                                    <li>Accéder aux dossiers patients</li>
                                    <li>Consulter les prescriptions</li>
                                    <li>Faciliter la communication avec les patients</li>
                                </ul>
                            </div>

                            <!-- Call to action -->
                            <div style="background: linear-gradient(135deg, #fff9e6 0%, #ffe5b4 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; border: 2px dashed #667eea;">
                                <p style="margin: 0 0 20px; color: #744210; font-size: 15px; font-weight: 600; text-align: center;">
                                    Complétez votre inscription
                                </p>
                                <p style="margin: 0 0 24px; color: #744210; font-size: 14px; line-height: 1.5; text-align: center;">
                                    Cliquez sur le bouton ci-dessous pour créer votre compte et rejoindre l'équipe de Dr. ${doctorName}
                                </p>

                                <!-- Gros bouton principal -->
                                <div style="text-align: center;">
                                    <a href="${invitationLink}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 16px 40px; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 16px; box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); transition: all 0.3s;">
                                        🚀 Créer mon compte →
                                    </a>
                                </div>

                                <!-- Lien alternatif -->
                                <p style="margin: 20px 0 0; color: #744210; font-size: 12px; text-align: center;">
                                    Ou copiez ce lien : <br>
                                    <a href="${invitationLink}" target="_blank" rel="noopener noreferrer" style="color: #667eea; word-break: break-all; font-size: 11px;">
                                        ${invitationLink}
                                    </a>
                                </p>
                            </div>

                            <!-- Info validité -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    ⏰ <strong>Validité :</strong> Cette invitation est valable pendant <strong>7 jours</strong>. Veuillez compléter votre inscription avant l'expiration du lien.
                                </p>
                            </div>

                            <!-- Besoin d'aide -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 16px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    💬 <strong>Besoin d'aide ?</strong> Contactez notre équipe support : <a href="mailto:${process.env.TEAM_EMAIL}" style="color: #667eea; text-decoration: none;">${process.env.TEAM_EMAIL}</a>
                                </p>
                            </div>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Cet email a été envoyé automatiquement par MyPrescription
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: assistantEmail, subject, html });
    }

    async sendPasswordResetEmail(
        userEmail: string,
        userName: string,
        resetToken: string
    ): Promise<boolean> {
        const subject = 'Réinitialisation de votre mot de passe - MyPrescription';
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        const resetLink = `${frontendUrl}/resset_password/${resetToken}`;

        const html = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f5f5f5; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="padding: 40px 20px;">
                <table role="presentation" style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">

                    <!-- Header avec gradient -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
                            <table role="presentation" style="margin: 0 auto 20px;">
                                <tr>
                                    <td style="width: 80px; height: 80px; background-color: white; border-radius: 50%; text-align: center; vertical-align: middle; box-shadow: 0 4px 6px rgba(0,0,0,0.1); line-height: 80px;">
                                        <span style="font-size: 40px; display: inline-block; vertical-align: middle; line-height: normal;">🔐</span>
                                    </td>
                                </tr>
                            </table>
                            <h1 style="margin: 0; color: white; font-size: 28px; font-weight: 700;">Réinitialisation de mot de passe</h1>
                            <p style="margin: 10px 0 0; color: rgba(255,255,255,0.9); font-size: 16px;">MyPrescription</p>
                        </td>
                    </tr>

                    <!-- Badge de notification -->
                    <tr>
                        <td style="padding: 0 30px;">
                            <div style="margin-top: -25px; text-align: center;">
                                <span style="display: inline-block; background-color: #f59e0b; color: white; padding: 10px 24px; border-radius: 50px; font-weight: 600; font-size: 14px; box-shadow: 0 4px 6px rgba(245,158,11,0.3);">
                                    🔑 Demande de réinitialisation
                                </span>
                            </div>
                        </td>
                    </tr>

                    <!-- Contenu principal -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="margin: 0 0 20px; color: #1a202c; font-size: 22px; font-weight: 700;">
                                Bonjour ${userName},
                            </h2>
                            <p style="margin: 0 0 20px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Nous avons reçu une demande de réinitialisation de mot de passe pour votre compte MyPrescription.
                            </p>
                            <p style="margin: 0 0 30px; color: #4a5568; font-size: 16px; line-height: 1.6;">
                                Si vous êtes à l'origine de cette demande, cliquez sur le bouton ci-dessous pour créer un nouveau mot de passe :
                            </p>

                            <!-- Bouton de réinitialisation -->
                            <div style="background: linear-gradient(135deg, #fff9e6 0%, #ffe5b4 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; border: 2px dashed #667eea; text-align: center;">
                                <p style="margin: 0 0 20px; color: #744210; font-size: 15px; font-weight: 600;">
                                    Réinitialisez votre mot de passe
                                </p>

                                <!-- Gros bouton principal -->
                                <div style="text-align: center;">
                                    <a href="${resetLink}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 16px 40px; text-decoration: none; border-radius: 50px; font-weight: 700; font-size: 16px; box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); transition: all 0.3s;">
                                        🔑 Réinitialiser mon mot de passe →
                                    </a>
                                </div>

                                <!-- Lien alternatif -->
                                <p style="margin: 20px 0 0; color: #744210; font-size: 12px; text-align: center;">
                                    Ou copiez ce lien : <br>
                                    <a href="${resetLink}" target="_blank" rel="noopener noreferrer" style="color: #667eea; word-break: break-all; font-size: 11px;">
                                        ${resetLink}
                                    </a>
                                </p>
                            </div>

                            <!-- Info validité -->
                            <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                                <p style="margin: 0; color: #92400e; font-size: 13px; line-height: 1.5;">
                                    ⏰ <strong>Important :</strong> Ce lien est valable pendant <strong>1 heure</strong> seulement. Après ce délai, vous devrez faire une nouvelle demande de réinitialisation.
                                </p>
                            </div>

                            <!-- Avertissement sécurité -->
                            <div style="background-color: #fef2f2; border-left: 4px solid #ef4444; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                                <p style="margin: 0 0 10px; color: #991b1b; font-size: 14px; font-weight: 600;">
                                    🚨 Vous n'avez pas demandé cette réinitialisation ?
                                </p>
                                <p style="margin: 0; color: #7f1d1d; font-size: 13px; line-height: 1.5;">
                                    Si vous n'êtes pas à l'origine de cette demande, <strong>ignorez simplement cet email</strong>. Votre mot de passe actuel restera inchangé et sécurisé. Pour plus de sécurité, contactez notre support.
                                </p>
                            </div>

                            <!-- Info sécurité -->
                            <div style="background-color: #f0f4f8; border-radius: 8px; padding: 16px; margin-top: 24px;">
                                <p style="margin: 0; color: #4a5568; font-size: 13px; line-height: 1.5;">
                                    💬 <strong>Besoin d'aide ?</strong> Contactez notre équipe support : <a href="mailto:${process.env.TEAM_EMAIL}" style="color: #667eea; text-decoration: none;">${process.env.TEAM_EMAIL}</a>
                                </p>
                            </div>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f7fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 10px; color: #718096; font-size: 14px;">
                                Cet email a été envoyé automatiquement par MyPrescription
                            </p>
                            <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                                © ${new Date().getFullYear()} MyPrescription. Tous droits réservés.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
        `;

        return await this.sendEmail({ to: userEmail, subject, html });
    }

    async sendContactEmail(contactData: { fullName: string; email: string; phone: string; subject: string; message: string }): Promise<boolean> {
        const teamEmail = process.env.TEAM_EMAIL || 'contact@myprescription.dz';
        const emailSubject = `📩 Nouveau message de contact: ${contactData.subject}`;

        const html = `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
                <h2 style="color: #2c3e50; text-align: center;">Nouveau message de contact</h2>
                <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <p><strong>Nom complet:</strong> ${contactData.fullName}</p>
                    <p><strong>Email:</strong> ${contactData.email}</p>
                    <p><strong>Téléphone:</strong> ${contactData.phone}</p>
                    <p><strong>Sujet:</strong> ${contactData.subject}</p>
                    <hr style="border: 1px solid #e9ecef; margin: 15px 0;">
                    <p><strong>Message:</strong></p>
                    <p style="white-space: pre-wrap;">${contactData.message}</p>
                </div>
            </div>
        `;

        return this.sendEmail({
            to: teamEmail,
            subject: emailSubject,
            html
        });
    }
}

export const emailService = new EmailService();