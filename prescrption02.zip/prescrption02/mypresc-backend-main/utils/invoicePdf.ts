import PdfPrinter from "pdfmake";
import type { TDocumentDefinitions } from "pdfmake/interfaces";
import fs from "fs";
import path from "path";
import type { User } from "../models/user.model";
import type { Payment } from "../models/payment.model";

const fonts = {
    Roboto: {
        normal: "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
        bold: "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
        italics: "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
        bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff"
    },
};

const printer = new PdfPrinter(fonts);

const logoPath = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

export interface InvoiceData {
    invoiceNumber: string;
    invoiceDate: Date;
    user: User;
    payment: Payment;
    companyInfo?: {
        name: string;
        address: string;
        phone: string;
        email: string;
        registrationNumber?: string;
        taxNumber?: string;
    };
}

export const generateInvoicePdf = async (invoiceData: InvoiceData): Promise<Buffer> => {
    const {
        invoiceNumber,
        invoiceDate,
        user,
        payment,
        companyInfo = {
            name: "MyPrescription",
            address: "Alger, Algérie",
            phone: "+213 XX XX XX XX",
            email: process.env.TEAM_EMAIL || "contact@myprescription.dz",
            registrationNumber: "RC XXXXXX",
            taxNumber: "NIF XXXXXXXXX"
        }
    } = invoiceData;

    // Plan details
    const planDetails: Record<string, { name: string; duration: string; description: string }> = {
        test: { name: 'Test', duration: '7 jours', description: 'Période d\'essai' },
        flex: { name: 'Flex', duration: '30 jours', description: 'Abonnement mensuel' },
        smart: { name: 'Smart', duration: '180 jours', description: 'Abonnement semestriel' },
        pro: { name: 'Pro', duration: '365 jours', description: 'Abonnement annuel' }
    };

    const selectedPlan = planDetails[payment.plan as keyof typeof planDetails] || {
        name: payment.plan,
        duration: 'N/A',
        description: 'Abonnement'
    };

    // Calculate tax (0% TVA in Algeria)
    const taxRate = 0;
    // Convert amount to number (PostgreSQL returns DECIMAL as string)
    const subtotal = typeof payment.amount === 'string' ? parseFloat(payment.amount) : payment.amount;
    const taxAmount = subtotal * taxRate;
    const totalAmount = subtotal + taxAmount;

    // Format dates
    const formattedInvoiceDate = invoiceDate.toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "long",
        year: "numeric"
    });

    const formattedPaymentDate = payment.paid_at
        ? new Date(payment.paid_at).toLocaleDateString("fr-FR", {
            day: "2-digit",
            month: "long",
            year: "numeric"
        })
        : formattedInvoiceDate;

    const docDefinition: TDocumentDefinitions = {
        pageMargins: [40, 40, 40, 40] as [number, number, number, number],
        content: [
            // Header with logo and company info
            {
                columns: [
                    {
                        stack: [
                            { text: companyInfo.name, style: "companyName" },
                            { text: companyInfo.address, fontSize: 10, margin: [0, 5, 0, 2] as [number, number, number, number] },
                            { text: `Tél : ${companyInfo.phone}`, fontSize: 10, margin: [0, 2, 0, 2] as [number, number, number, number] },
                            { text: `Email : ${companyInfo.email}`, fontSize: 10, color: "#2563eb", margin: [0, 2, 0, 2] as [number, number, number, number] },
                            ...(companyInfo.registrationNumber ? [{ text: `RC : ${companyInfo.registrationNumber}`, fontSize: 9, margin: [0, 2, 0, 2] as [number, number, number, number] }] : []),
                            ...(companyInfo.taxNumber ? [{ text: `NIF : ${companyInfo.taxNumber}`, fontSize: 9, margin: [0, 2, 0, 2] as [number, number, number, number] }] : [])
                        ],
                        width: "*"
                    },
                    {
                        image: 'data:image/png;base64,' + logoBase64,
                        width: 100,
                        alignment: 'right'
                    }
                ],
                margin: [0, 0, 0, 30] as [number, number, number, number]
            },

            // Invoice title
            {
                text: "FACTURE",
                style: "invoiceTitle",
                alignment: "center",
                margin: [0, 0, 0, 5] as [number, number, number, number]
            },
            {
                text: `N° ${invoiceNumber}`,
                style: "invoiceNumber",
                alignment: "center",
                margin: [0, 0, 0, 30] as [number, number, number, number]
            },

            // Invoice details and client info
            {
                columns: [
                    {
                        stack: [
                            { text: "FACTURÉ À :", bold: true, fontSize: 11, margin: [0, 0, 0, 10] as [number, number, number, number] },
                            { text: `Dr. ${user.name} ${user.family_name}`, fontSize: 12, bold: true, margin: [0, 0, 0, 5] as [number, number, number, number] },
                            { text: user.email, fontSize: 10, color: "#4a5568", margin: [0, 0, 0, 2] as [number, number, number, number] }
                        ],
                        width: "*"
                    },
                    {
                        stack: [
                            {
                                table: {
                                    widths: [80, 100],
                                    body: [
                                        [
                                            { text: "Date facture :", bold: true, fontSize: 10, border: [false, false, false, false] },
                                            { text: formattedInvoiceDate, fontSize: 10, border: [false, false, false, false] }
                                        ],
                                        [
                                            { text: "Date paiement :", bold: true, fontSize: 10, border: [false, false, false, false] },
                                            { text: formattedPaymentDate, fontSize: 10, border: [false, false, false, false] }
                                        ],
                                        [
                                            { text: "Mode paiement :", bold: true, fontSize: 10, border: [false, false, false, false] },
                                            { text: payment.payment_method || 'Carte bancaire', fontSize: 10, border: [false, false, false, false] }
                                        ]
                                    ]
                                },
                                layout: 'noBorders'
                            }
                        ],
                        width: "auto"
                    }
                ],
                margin: [0, 0, 0, 30] as [number, number, number, number]
            },

            // Invoice items table
            {
                table: {
                    headerRows: 1,
                    widths: ['*', 60, 80, 80],
                    body: [
                        // Header
                        [
                            { text: 'DESCRIPTION', style: 'tableHeader' },
                            { text: 'DURÉE', style: 'tableHeader', alignment: 'center' },
                            { text: 'PRIX UNIT.', style: 'tableHeader', alignment: 'right' },
                            { text: 'MONTANT', style: 'tableHeader', alignment: 'right' }
                        ],
                        // Item
                        [
                            {
                                stack: [
                                    { text: `Abonnement ${selectedPlan.name}`, bold: true, fontSize: 11 },
                                    { text: selectedPlan.description, fontSize: 9, color: '#666666', margin: [0, 2, 0, 0] as [number, number, number, number] }
                                ]
                            },
                            { text: selectedPlan.duration, alignment: 'center', fontSize: 10 },
                            { text: `${subtotal.toFixed(2)} DZD`, alignment: 'right', fontSize: 10 },
                            { text: `${subtotal.toFixed(2)} DZD`, alignment: 'right', fontSize: 10, bold: true }
                        ]
                    ]
                },
                layout: {
                    fillColor: (rowIndex: number) => {
                        return rowIndex === 0 ? '#f0f4f8' : null;
                    },
                    hLineWidth: (i: number, node: { table: { body: unknown[] } }) => {
                        return i === 0 || i === 1 || i === node.table.body.length ? 1 : 0;
                    },
                    vLineWidth: () => {
                        return 0;
                    },
                    hLineColor: () => {
                        return '#e2e8f0';
                    }
                },
                margin: [0, 0, 0, 20] as [number, number, number, number]
            },

            // Totals section
            {
                columns: [
                    { text: '', width: '*' },
                    {
                        table: {
                            widths: [120, 80],
                            body: [
                                [
                                    { text: 'Sous-total HT :', fontSize: 10, border: [false, false, false, false] },
                                    { text: `${subtotal.toFixed(2)} DZD`, fontSize: 10, alignment: 'right', border: [false, false, false, false] }
                                ],
                                [
                                    { text: `TVA (${(taxRate * 100).toFixed(0)}%) :`, fontSize: 10, border: [false, false, false, false] },
                                    { text: `${taxAmount.toFixed(2)} DZD`, fontSize: 10, alignment: 'right', border: [false, false, false, false] }
                                ],
                                [
                                    { text: 'TOTAL TTC :', bold: true, fontSize: 12, fillColor: '#f0f4f8', border: [false, true, false, false], borderColor: ['', '#2563eb', '', ''], borderWidth: [0, 2, 0, 0], margin: [0, 5, 0, 5] as [number, number, number, number] },
                                    { text: `${totalAmount.toFixed(2)} DZD`, bold: true, fontSize: 12, alignment: 'right', fillColor: '#f0f4f8', border: [false, true, false, false], borderColor: ['', '#2563eb', '', ''], borderWidth: [0, 2, 0, 0], margin: [0, 5, 0, 5] as [number, number, number, number] }
                                ]
                            ]
                        },
                        layout: {
                            hLineWidth: (i: number) => {
                                return i === 2 ? 2 : 0;
                            },
                            hLineColor: () => {
                                return '#2563eb';
                            }
                        },
                        width: 200
                    }
                ],
                margin: [0, 0, 0, 30] as [number, number, number, number]
            },

            // Transaction ID
            {
                text: [
                    { text: 'ID Transaction : ', fontSize: 9, color: '#718096' },
                    { text: payment.transaction_id || payment.checkout_id, fontSize: 9, color: '#4a5568', bold: true }
                ],
                margin: [0, 0, 0, 30] as [number, number, number, number]
            },

            // Footer notes
            {
                stack: [
                    { text: 'Notes :', bold: true, fontSize: 10, margin: [0, 0, 0, 5] as [number, number, number, number] },
                    { text: 'Merci pour votre confiance en MyPrescription.', fontSize: 9, color: '#4a5568', margin: [0, 0, 0, 2] as [number, number, number, number] },
                    { text: 'Cette facture est générée automatiquement et ne nécessite pas de signature.', fontSize: 9, color: '#718096', margin: [0, 0, 0, 2] as [number, number, number, number] },
                    { text: `Pour toute question, contactez-nous à ${companyInfo.email}`, fontSize: 9, color: '#718096' }
                ],
                margin: [0, 20, 0, 0] as [number, number, number, number]
            }
        ],
        styles: {
            companyName: {
                fontSize: 16,
                bold: true,
                color: '#1a202c'
            },
            invoiceTitle: {
                fontSize: 24,
                bold: true,
                color: '#2563eb'
            },
            invoiceNumber: {
                fontSize: 14,
                color: '#4a5568'
            },
            tableHeader: {
                bold: true,
                fontSize: 10,
                color: '#1a202c'
            }
        },
        defaultStyle: {
            font: 'Roboto'
        }
    };

    return new Promise((resolve, reject) => {
        try {
            const pdfDoc = printer.createPdfKitDocument(docDefinition);
            const chunks: Buffer[] = [];

            pdfDoc.on('data', (chunk: Buffer) => {
                chunks.push(chunk);
            });

            pdfDoc.on('end', () => {
                const pdfBuffer = Buffer.concat(chunks);
                resolve(pdfBuffer);
            });

            pdfDoc.on('error', (error: Error) => {
                reject(error);
            });

            pdfDoc.end();
        } catch (error) {
            reject(error);
        }
    });
};

// Save invoice PDF to file system
export const saveInvoicePdf = async (
    invoiceNumber: string,
    pdfBuffer: Buffer
): Promise<string> => {
    const uploadsDir = path.join(process.cwd(), 'uploads', 'invoices');

    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
    }

    const fileName = `${invoiceNumber}.pdf`;
    const filePath = path.join(uploadsDir, fileName);

    fs.writeFileSync(filePath, pdfBuffer);

    // Return relative path for database storage
    return `uploads/invoices/${fileName}`;
};
