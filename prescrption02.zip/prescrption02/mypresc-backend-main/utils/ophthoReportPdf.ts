/**
 * ophthoReportPdf.ts
 * Generates a PDF "Compte Rendu Réfractométrique" from an ophthalmology_reports row.
 * Design mirrors opticalCorrectionPdf.ts / cardiologyReportPdf.ts (pdfmake, same palette).
 * Layout: Far and Near Rx tables side-by-side for compact output.
 */

import PdfPrinter from 'pdfmake';
import type { Response } from 'express';
import { OphthoReportModel } from '../models/ophthoReport.model.js';
import { DoctorModel } from '../models/doctor.model.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const fonts = {
    Roboto: {
        normal:      'node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff',
        bold:        'node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff',
        italics:     'node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff',
        bolditalics: 'node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff',
    },
};

const printer = new PdfPrinter(fonts);

const logoPath   = path.join(__dirname, 'logo.png');
const logoBase64 = fs.readFileSync(logoPath).toString('base64');

// ─── Palette ──────────────────────────────────────────────────────────────────
const TEAL       = '#1a7fa0';
const DARK_TEAL  = '#155f7a';
const LIGHT_TEAL = '#e8f5f9';
const SEPARATOR  = '#d0e8ef';
const MUTED      = '#8aacb5';
const TEXT_MED   = '#4a7a8a';
const TEXT_DARK  = '#1a1a2e';
const PAGE_W     = 595.28;

// ─── Layouts ──────────────────────────────────────────────────────────────────
const noLayout = {
    hLineWidth: () => 0,
    vLineWidth: () => 0,
    paddingLeft: () => 0, paddingRight: () => 0,
    paddingTop: () => 0,  paddingBottom: () => 0,
};

const dashedBorderLayout = {
    hLineWidth: () => 0.8, vLineWidth: () => 0.8,
    hLineColor: () => TEAL, vLineColor: () => TEAL,
    hLineStyle: () => ({ dash: { length: 4, space: 3 } }),
    vLineStyle: () => ({ dash: { length: 4, space: 3 } }),
    paddingLeft: () => 0, paddingRight: () => 0,
    paddingTop: () => 0,  paddingBottom: () => 0,
};

const rxTableLayout = {
    hLineWidth: () => 1,
    vLineWidth: () => 1,
    hLineColor: (i: number) => (i === 0 || i === 1 ? TEAL : SEPARATOR),
    vLineColor: (i: number) => (i === 0 ? TEAL : SEPARATOR),
    paddingLeft: () => 5, paddingRight: () => 5,
    paddingTop: () => 5,  paddingBottom: () => 5,
    fillColor: (rowIndex: number) =>
        rowIndex === 0 ? TEAL : rowIndex % 2 === 0 ? LIGHT_TEAL : '#ffffff',
};

const makeFooterContactLayout = (nCols: number) => ({
    hLineWidth: () => 0,
    vLineWidth: (i: number) => (i > 0 && i < nCols ? 0.6 : 0),
    vLineColor: () => SEPARATOR,
    paddingLeft:  (i: number) => (i === 0 ? 0 : 16),
    paddingRight: (i: number) => (i === nCols - 1 ? 0 : 16),
    paddingTop: () => 0, paddingBottom: () => 0,
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
const val = (v: any): string =>
    v !== null && v !== undefined && v !== '' ? String(v) : '—';

const diop = (v: any): string => {
    if (v === null || v === undefined || v === '') return '—';
    const n = parseFloat(String(v));
    if (isNaN(n)) return '—';
    return (n >= 0 ? '+' : '') + n.toFixed(2);
};

const axisStr = (v: any): string =>
    v !== null && v !== undefined && v !== '' ? `${v}°` : '—';

/** Build the OD/OS pdfmake table body */
function buildRxTableBody(report: any, prefix: 'rx_far' | 'rx_near') {
    const header = [
        { text: 'ŒIL', bold: true, fontSize: 9, color: 'white', alignment: 'center' },
        { text: 'SPH',  bold: true, fontSize: 9, color: 'white', alignment: 'center' },
        { text: 'CYL',  bold: true, fontSize: 9, color: 'white', alignment: 'center' },
        { text: 'AXE',  bold: true, fontSize: 9, color: 'white', alignment: 'center' },
        { text: 'VD',   bold: true, fontSize: 9, color: 'white', alignment: 'center' },
    ];

    const makeRow = (eye: 'right' | 'left', label: string) => [
        { text: label, bold: true, fontSize: 10, color: TEAL, alignment: 'center' },
        { text: diop(report[`${prefix}_${eye}_sph`]),  fontSize: 10, color: TEXT_DARK, alignment: 'center' },
        { text: diop(report[`${prefix}_${eye}_cyl`]),  fontSize: 10, color: TEXT_DARK, alignment: 'center' },
        { text: axisStr(report[`${prefix}_${eye}_axis`]), fontSize: 10, color: TEXT_DARK, alignment: 'center' },
        { text: val(report[`${prefix}_vd`]) !== '—' ? `${report[`${prefix}_vd`]} mm` : '—', fontSize: 10, color: TEXT_DARK, alignment: 'center' },
    ];

    return [header, makeRow('right', 'OD'), makeRow('left', 'OG')];
}

/** PD summary line */
function buildPdText(report: any, prefix: 'rx_far' | 'rx_near'): string {
    const r = report[`${prefix}_pd_r`];
    const l = report[`${prefix}_pd_l`];
    const b = report[`${prefix}_pd_b`];
    const parts: string[] = [];
    if (r) parts.push(`OD : ${r} mm`);
    if (l) parts.push(`OG : ${l} mm`);
    if (b) parts.push(`Total : ${b} mm`);
    return parts.length ? `Écart Pupillaire — ${parts.join('  /  ')}` : '';
}

/** Compute ADD */
function computeAdd(report: any, eye: 'right' | 'left'): string {
    const near = parseFloat(report[`rx_near_${eye}_sph`]);
    const far  = parseFloat(report[`rx_far_${eye}_sph`]);
    if (isNaN(near) || isNaN(far)) return '—';
    const add = near - far;
    return (add >= 0 ? '+' : '') + add.toFixed(2);
}

/** Small section title bar (left teal stripe + light-teal background) */
function sectionTitle(text: string): any {
    return {
        table: {
            widths: [3, '*'],
            body: [[
                { text: '', fillColor: TEAL, border: [false, false, false, false] },
                {
                    text: text.toUpperCase(),
                    fontSize: 8, bold: true, color: DARK_TEAL,
                    characterSpacing: 0.8,
                    fillColor: LIGHT_TEAL, border: [false, false, false, false],
                    margin: [8, 5, 6, 5],
                },
            ]],
        },
        layout: noLayout,
        margin: [0, 0, 0, 6],
    };
}

function divider(): any {
    return {
        canvas: [{ type: 'line', x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
        margin: [40, 8, 40, 8],
    };
}

// ─── Main generator ───────────────────────────────────────────────────────────
export const generateOphthoReportPdf = async (
    id: number,
    res: Response,
    requestingDoctorId?: number,
) => {
    try {
        if (!id || isNaN(id)) {
            return res.status(400).json({ success: false, error: 'Invalid report ID' });
        }

        const report = await OphthoReportModel.findByIdWithPatient(id, requestingDoctorId);
        if (!report) {
            return res.status(404).json({ success: false, error: 'Report not found' });
        }

        const doctorProfile = await DoctorModel.findByUserId(report.doctor_user_id);

        const doctor = {
            name:          `Dr. ${report.doctor_name ?? ''} ${report.doctor_family_name ?? ''}`.trim(),
            speciality:    doctorProfile?.speciality    || 'Ophtalmologiste',
            order:         doctorProfile?.order_num     || '',
            establishment: doctorProfile?.work_location || '',
            tel:           doctorProfile?.phone_number  || '',
            email:         report.doctor_email         || '',
        };

        const patient         = (report as any).patient;
        const patientFullName = `${patient?.name ?? ''} ${patient?.family_name ?? ''}`.trim();
        const genre           = (patient?.genre || '').toLowerCase();
        const sexLabel        = genre === 'femme' ? 'Féminin' : genre === 'homme' ? 'Masculin' : '';
        const birthRaw        = patient?.dateNaissance ?? null;
        const birthDate       = birthRaw ? new Date(birthRaw) : null;
        const birthLabel      = birthDate && !isNaN(birthDate.getTime())
            ? birthDate.toLocaleDateString('fr-FR') : '';

        const examDateLabel = report.exam_date
            ? new Date(report.exam_date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
            : new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

        const ordNum     = `N° OPH-${new Date().getFullYear()}-${String(id).padStart(3, '0')}`;
        const machineStr = [
            report.machine_company, report.machine_model,
            report.machine_no ? `N° ${report.machine_no}` : null,
        ].filter(Boolean).join(' · ');

        // ── Footer contact ─────────────────────────────────────────────────────
        type CF = { label: string; value: string };
        const contactFields: CF[] = [];
        if (doctor.establishment) contactFields.push({ label: 'ADRESSE',   value: doctor.establishment });
        if (doctor.tel)           contactFields.push({ label: 'TÉLÉPHONE', value: doctor.tel });
        if (doctor.email)         contactFields.push({ label: 'EMAIL',     value: doctor.email });

        const contactTableBody = [contactFields.map(f => ({
            stack: [
                { text: f.label, fontSize: 7, bold: true, color: MUTED, characterSpacing: 1.2 },
                { text: f.value, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] },
            ],
            border: [false, false, false, false],
        }))];
        const contactWidths = contactFields.map(() => 'auto' as const);

        // ── Rx data ────────────────────────────────────────────────────────────
        const farBody  = buildRxTableBody(report, 'rx_far');
        const nearBody = buildRxTableBody(report, 'rx_near');
        const farPdText  = buildPdText(report, 'rx_far');
        const nearPdText = buildPdText(report, 'rx_near');
        const addRight = computeAdd(report, 'right');
        const addLeft  = computeAdd(report, 'left');

        // ── Doc definition ─────────────────────────────────────────────────────
        const docDefinition: any = {
            pageMargins: [0, 0, 0, 72],

            footer: () => ({
                stack: [
                    { canvas: [{ type: 'line', x1: 40, y1: 0, x2: PAGE_W - 40, y2: 0, lineWidth: 0.6, lineColor: SEPARATOR }] },
                    {
                        columns: [
                            contactFields.length > 0
                                ? {
                                    table: { widths: contactWidths, body: contactTableBody },
                                    layout: makeFooterContactLayout(contactFields.length),
                                    width: '*', margin: [0, 8, 0, 0],
                                }
                                : { text: '', width: '*' },
                            {
                                stack: [
                                    { text: 'MyPrescription',    fontSize: 10, bold: true, color: TEAL, alignment: 'right' },
                                    { text: 'MYPRESCRIPTION.DZ', fontSize: 7.5, color: MUTED, alignment: 'right', margin: [0, 2, 0, 0] },
                                ],
                                width: 'auto', margin: [0, 8, 0, 0],
                            },
                        ],
                        margin: [40, 0, 40, 0],
                    },
                    { canvas: [{ type: 'rect', x: 0, y: 0, w: PAGE_W, h: 10, color: TEAL }], margin: [0, 6, 0, 0] },
                ],
            }),

            content: [

                // ── HEADER ──────────────────────────────────────────────────────
                {
                    table: {
                        widths: ['*', 'auto'],
                        body: [[
                            {
                                stack: [
                                    { text: doctor.name, fontSize: 18, bold: true, color: TEAL, lineHeight: 1.1 },
                                    { text: doctor.speciality.toUpperCase(), fontSize: 9, color: DARK_TEAL, characterSpacing: 1, margin: [0, 4, 0, 10] },
                                    ...(doctor.order         ? [{ text: `N° d'ordre ${doctor.order}`, fontSize: 9, color: TEXT_MED }] : []),
                                    ...(doctor.establishment ? [{ text: doctor.establishment,          fontSize: 9, color: TEXT_MED }] : []),
                                    ...(doctor.tel           ? [{ text: `Tél. ${doctor.tel}`,          fontSize: 9, color: TEXT_MED }] : []),
                                    ...(doctor.email         ? [{ text: doctor.email,                  fontSize: 9, color: TEAL     }] : []),
                                ],
                                fillColor: LIGHT_TEAL, border: [false, false, false, false], margin: [40, 20, 8, 20],
                            },
                            {
                                stack: [
                                    { image: `data:image/png;base64,${logoBase64}`, width: 110, alignment: 'right' },
                                    { text: ordNum, fontSize: 8, color: MUTED, alignment: 'right', characterSpacing: 0.5, margin: [0, 6, 0, 0] },
                                ],
                                fillColor: LIGHT_TEAL, border: [false, false, false, false], margin: [8, 20, 40, 20],
                            },
                        ]],
                    },
                    layout: noLayout,
                },

                // ── PATIENT BAR ─────────────────────────────────────────────────
                {
                    table: {
                        widths: ['*', 'auto'],
                        body: [[
                            {
                                stack: [
                                    { text: 'PATIENT', fontSize: 7, bold: true, color: '#cce8f0', characterSpacing: 1.5 },
                                    { text: patientFullName.toUpperCase() || 'N/A', fontSize: 15, bold: true, color: 'white', margin: [0, 2, 0, 4] },
                                    {
                                        columns: [
                                            ...(sexLabel   ? [{ text: 'Sexe :', fontSize: 8, color: '#cce8f0', bold: true, width: 'auto' }, { text: `  ${sexLabel}`, fontSize: 8, color: 'white', width: 'auto' }] : []),
                                            ...(birthLabel ? [{ text: sexLabel ? '      Né(e) le :' : 'Né(e) le :', fontSize: 8, color: '#cce8f0', bold: true, width: 'auto' }, { text: `  ${birthLabel}`, fontSize: 8, color: 'white', width: 'auto' }] : []),
                                        ],
                                    },
                                ],
                                fillColor: TEAL, border: [false, false, false, false], margin: [40, 12, 8, 12],
                            },
                            {
                                stack: [
                                    { text: 'DATE EXAMEN', fontSize: 7, bold: true, color: '#cce8f0', alignment: 'right', characterSpacing: 1.5 },
                                    { text: examDateLabel, fontSize: 11, bold: true, color: 'white', alignment: 'right', margin: [0, 3, 0, 0] },
                                ],
                                fillColor: TEAL, border: [false, false, false, false], margin: [8, 12, 40, 12],
                            },
                        ]],
                    },
                    layout: noLayout, margin: [0, 12, 0, 20],
                },

                // ── TITLE ────────────────────────────────────────────────────────
                {
                    stack: [
                        { text: 'Compte Rendu Réfractométrique', fontSize: 20, bold: true, color: DARK_TEAL, alignment: 'center' },
                        { text: 'BILAN DE RÉFRACTION SUBJECTIVE', fontSize: 7, color: TEAL, characterSpacing: 1, alignment: 'center', margin: [0, 4, 0, 0] },
                        ...(machineStr ? [{ text: machineStr, fontSize: 8, color: MUTED, alignment: 'center', margin: [0, 4, 0, 0] }] : []),
                    ],
                    margin: [40, 0, 40, 0],
                },

                divider(),

                // ── RX TABLES — FAR + NEAR SIDE BY SIDE ─────────────────────────
                {
                    columns: [

                        // LEFT: Loin ─────────────────────────────────────────────
                        {
                            width: '*',
                            stack: [
                                sectionTitle('Réfraction de Loin  (≥ 5 m)'),
                                {
                                    table: { headerRows: 1, widths: ['*','*','*','*','*'], body: farBody },
                                    layout: rxTableLayout,
                                },
                                ...(farPdText ? [{
                                    table: { widths: [3,'*'], body: [[
                                        { text: '', fillColor: TEAL, border: [false,false,false,false] },
                                        { text: farPdText, fontSize: 8, color: TEXT_DARK, fillColor: '#f0f9fc', border: [false,false,false,false], margin: [8,5,6,5] },
                                    ]]},
                                    layout: noLayout, margin: [0,6,0,0],
                                }] : []),
                            ],
                        },

                        // gap
                        { width: 14, text: '' },

                        // RIGHT: Près ────────────────────────────────────────────
                        {
                            width: '*',
                            stack: [
                                sectionTitle('Réfraction de Près  (~ 67 cm)'),
                                {
                                    table: { headerRows: 1, widths: ['*','*','*','*','*'], body: nearBody },
                                    layout: rxTableLayout,
                                },
                                // ADD badge inline below near table
                                {
                                    columns: [
                                        { text: 'ADD :', fontSize: 8, bold: true, color: MUTED, width: 'auto', margin: [0,2,5,0] },
                                        { text: `OD  ${addRight}`, fontSize: 10, bold: true, color: TEAL, width: 'auto', margin: [0,1,10,0] },
                                        { text: `OG  ${addLeft}`,  fontSize: 10, bold: true, color: TEAL, width: 'auto', margin: [0,1,0,0] },
                                    ],
                                    margin: [0, 6, 0, 0],
                                },
                                ...(nearPdText ? [{
                                    table: { widths: [3,'*'], body: [[
                                        { text: '', fillColor: TEAL, border: [false,false,false,false] },
                                        { text: nearPdText, fontSize: 8, color: TEXT_DARK, fillColor: '#f0f9fc', border: [false,false,false,false], margin: [8,5,6,5] },
                                    ]]},
                                    layout: noLayout, margin: [0,4,0,0],
                                }] : []),
                            ],
                        },
                    ],
                    margin: [40, 0, 40, 0],
                },

                // ── DIAGNOSTIC & NOTES ───────────────────────────────────────────
                ...(report.diagnosis || report.clinical_notes ? [
                    divider(),
                    {
                        table: {
                            widths: [4, '*'],
                            body: [[
                                { text: '', fillColor: TEAL, border: [false,false,false,false] },
                                {
                                    text: 'DIAGNOSTIC & NOTES CLINIQUES',
                                    fontSize: 8, bold: true, color: DARK_TEAL,
                                    characterSpacing: 0.8,
                                    fillColor: LIGHT_TEAL, border: [false,false,false,false],
                                    margin: [8,5,6,5],
                                },
                            ]],
                        },
                        layout: noLayout,
                        margin: [40, 0, 40, 8],
                    },
                    ...(report.diagnosis ? [{
                        text: report.diagnosis, fontSize: 10, color: TEXT_DARK, margin: [40, 0, 40, 6],
                    } as any] : []),
                    ...(report.clinical_notes ? [{
                        table: { widths: [3,'*'], body: [[
                            { text: '', fillColor: '#f0c040', border: [false,false,false,false] },
                            {
                                stack: [
                                    { text: 'Remarques', bold: true, fontSize: 9, color: '#b8943a', margin: [0,0,0,4] },
                                    { text: report.clinical_notes, fontSize: 9, color: '#6b5a2a' },
                                ],
                                fillColor: '#fffbf0', border: [false,false,false,false], margin: [10,8,8,8],
                            },
                        ]]},
                        layout: noLayout, margin: [40,0,40,0],
                    } as any] : []),
                ] : []),

                // ── SIGNATURE BOX ────────────────────────────────────────────────
                {
                    stack: [
                        {
                            table: { widths: [160], body: [[{ text: '', border: [true,true,true,true], margin: [0,45,0,0] }]] },
                            layout: dashedBorderLayout,
                        },
                        { text: 'Signature & Cachet du Médecin', fontSize: 8, color: MUTED, alignment: 'right', characterSpacing: 0.4, margin: [0,5,55,0] },
                    ],
                    absolutePosition: { x: 395, y: 570 },
                },

            ],
        };

        const pdfDoc = printer.createPdfKitDocument(docDefinition);
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `inline; filename=ophtho_report_${id}.pdf`);
        pdfDoc.pipe(res);
        pdfDoc.end();

    } catch (error) {
        console.error('Error generating ophthalmology PDF:', error);
        return res.status(500).json({ success: false, error: 'Internal server error while generating PDF' });
    }
};
