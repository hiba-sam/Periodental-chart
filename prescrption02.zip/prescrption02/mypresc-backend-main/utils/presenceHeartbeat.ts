import { PresenceModel } from '../models/presence.model';

/**
 * Presence Heartbeat - Periodic cleanup of stale presence records
 * 
 * This cleans up users who appear "online" but have disconnected abnormally
 * (e.g., browser crash, network disconnect without proper close)
 */

let heartbeatInterval: NodeJS.Timeout | null = null;

export function startPresenceHeartbeat(): void {
    if (heartbeatInterval) {
        console.log('[Heartbeat] Already running');
        return;
    }

    console.log('[Heartbeat] Starting presence cleanup (every 5 minutes)');

    // Run cleanup every 5 minutes
    heartbeatInterval = setInterval(async () => {
        try {
            await PresenceModel.cleanupStalePresence();
            console.log('[Heartbeat] Cleaned up stale presence records');
        } catch (error) {
            console.error('[Heartbeat] Failed to cleanup presence:', error);
        }
    }, 5 * 60 * 1000); // 5 minutes

    // Also run once immediately on startup
    PresenceModel.cleanupStalePresence().catch(error => {
        console.error('[Heartbeat] Initial cleanup failed:', error);
    });
}

export function stopPresenceHeartbeat(): void {
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
        console.log('[Heartbeat] Stopped');
    }
}
