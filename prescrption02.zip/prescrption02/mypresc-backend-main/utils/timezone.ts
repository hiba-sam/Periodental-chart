/**
 * Timezone utilities for Algeria (UTC+1)
 * The server runs in UTC, but we need to calculate dates in Algeria timezone
 */

const ALGERIA_OFFSET_MINUTES = 60; // UTC+1

/**
 * Get current date/time in Algeria timezone
 */
export function getAlgeriaDate(): Date {
    const now = new Date();
    const utcTime = now.getTime() + (now.getTimezoneOffset() * 60000);
    return new Date(utcTime + (ALGERIA_OFFSET_MINUTES * 60000));
}

/**
 * Get today's date string in YYYY-MM-DD format (Algeria timezone)
 */
export function getAlgeriaTodayString(): string {
    const algeriaDate = getAlgeriaDate();
    return `${algeriaDate.getFullYear()}-${String(algeriaDate.getMonth() + 1).padStart(2, '0')}-${String(algeriaDate.getDate()).padStart(2, '0')}`;
}

/**
 * Get today at midnight in Algeria timezone (as a Date object)
 */
export function getAlgeriaToday(): Date {
    return new Date(getAlgeriaTodayString());
}

/**
 * Get current minutes since midnight in Algeria timezone
 */
export function getAlgeriaMinutesNow(): number {
    const algeriaDate = getAlgeriaDate();
    return algeriaDate.getHours() * 60 + algeriaDate.getMinutes();
}
