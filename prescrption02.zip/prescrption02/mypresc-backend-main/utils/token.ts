import jwt from "jsonwebtoken";

const generateRegistrationToken = (userId: number | string, action: "approve" | "reject") => {
    const token = jwt.sign(
        {
            userId, action
        },
        process.env.JWT_SECRET!,
        { expiresIn: '168h' } // 7 days validity
    );

    return `${process.env.BASE_URL}/auth/complete-registration/${token}`
}

const generateAssistantInvitationToken = (doctorUserId: number, assistantEmail: string, assistantName: string) => {
    const token = jwt.sign(
        {
            doctorUserId,
            assistantEmail,
            assistantName
        },
        process.env.JWT_SECRET!,
        { expiresIn: '720h' } // 30 days validity
    );

    return token;
}

const generatePasswordResetToken = (userId: number, email: string) => {
    const token = jwt.sign(
        {
            userId,
            email,
            type: 'reset'
        },
        process.env.JWT_SECRET!,
        { expiresIn: '1h' } // 1 hour validity
    );

    return token;
}

export { generateRegistrationToken, generateAssistantInvitationToken, generatePasswordResetToken };