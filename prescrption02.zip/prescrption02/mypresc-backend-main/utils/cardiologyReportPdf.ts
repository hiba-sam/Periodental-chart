import PdfPrinter from "pdfmake";
import type { Response } from "express";
import { CardiologyReportModel } from "../models/cardiologyReport.model";
import { DoctorModel } from "../models/doctor.model";
import fs from "fs";
import path from "path";

const fonts = {
  Roboto: {
    normal:      "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
    bold:        "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
    italics:     "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
    bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff",
  },
};

const printer = new PdfPrinter(fonts);

const logoPath   = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

// ─── Palette ──────────────────────────────────────────────────────────────────
const TEAL      = "#1a7fa0";
const DARK_TEAL = "#155f7a";
const LIGHT_TEAL = "#e8f5f9";
const SEPARATOR  = "#d0e8ef";
const MUTED      = "#8aacb5";
const TEXT_MED   = "#4a7a8a";
const PAGE_W     = 595.28;

// ─── Layouts ──────────────────────────────────────────────────────────────────

const noLayout = {
  hLineWidth: () => 0,
  vLineWidth: () => 0,
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const dashedBorderLayout = {
  hLineWidth:  () => 0.8,
  vLineWidth:  () => 0.8,
  hLineColor:  () => TEAL,
  vLineColor:  () => TEAL,
  hLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  vLineStyle:  () => ({ dash: { length: 4, space: 3 } }),
  paddingLeft:   () => 0,
  paddingRight:  () => 0,
  paddingTop:    () => 0,
  paddingBottom: () => 0,
};

const makeFooterContactLayout = (nCols: number) => ({
  hLineWidth: () => 0,
  vLineWidth: (i: number) => (i > 0 && i < nCols ? 0.6 : 0),
  vLineColor: () => SEPARATOR,
  paddingLeft:   (i: number) => (i === 0 ? 0 : 16),
  paddingRight:  (i: number) => (i === nCols - 1 ? 0 : 16),
  paddingTop:    () => 0,
  paddingBottom: () => 0,
});

// ─── Signature block ──────────────────────────────────────────────────────────
const SIGN_X = 395;
const SIGN_Y = 680;

const makeSignatureBlock = (): any => ({
  stack: [
    {
      table: {
        widths: [160],
        body: [[{
          text: "",
          border: [true, true, true, true],
          margin: [0, 45, 0, 0],
        }]],
      },
      layout: dashedBorderLayout,
    },
    {
      text: "Signature & Cachet du Médecin",
      fontSize: 8, color: MUTED, alignment: "right",
      characterSpacing: 0.4, margin: [0, 5, 55, 0],
    },
  ],
  absolutePosition: { x: SIGN_X, y: SIGN_Y },
});

// ─── Pagination constants ─────────────────────────────────────────────────────
//
// All items render full-width. The absolutePosition signature block overlays
// naturally on top of any content near y=680. Text simply flows through it,
// which looks clean and professional.
//
// Typography calibration (Roboto 10pt section box, lineHeight 1.2):
//   Section content area ≈ 457pt  →  ~88 chars/line at 5.2pt avg char width
// ─────────────────────────────────────────────────────────────────────────────

const PAGE_H          = 841.89;
const FOOTER_RESERVED = 72;
const CONTENT_BOTTOM  = PAGE_H - FOOTER_RESERVED;   // ≈ 769.89pt

// Y where page-1 content starts (compact header + slim title bar + divider + intro)
const P1_START_Y = 235;
// Y where continuation page content starts (compact header + divider)
const PN_START_Y = 75;

// Typography
const CONTENT_LINE_H = 10 * 1.2;  // 12pt per content line (Roboto 10pt, lineHeight 1.2)
const CHARS_FULL     = 88;         // chars/line, full-width section box

// Section block overhead: title(15) + cell vPad(12) + block margin-bottom(6) = 33pt
const SECTION_BASE_H = 33;

// ─── Item types ───────────────────────────────────────────────────────────────
type Item =
  | { kind: "section";   title: string; content: string }
  | { kind: "intro";     text: string }
  | { kind: "paragraph"; text: string };

const estimateItemH = (item: Item): number => {
  if (item.kind === "section") {
    const lines = item.content ? Math.max(1, Math.ceil(item.content.length / CHARS_FULL)) : 0;
    return SECTION_BASE_H + lines * CONTENT_LINE_H;
  }
  if (item.kind === "intro") return CONTENT_LINE_H + 8;
  const lines = Math.max(1, Math.ceil(item.text.length / CHARS_FULL));
  return lines * CONTENT_LINE_H + 4;
};

// ─── Section block builder ────────────────────────────────────────────────────

const makeSectionBlock = (title: string, content: string): object => ({
  table: {
    widths: [3, "*"],
    body: [[
      { text: "", fillColor: TEAL, border: [false, false, false, false] },
      {
        stack: [
          { text: title, bold: true, fontSize: 9, color: TEAL, margin: [0, 0, 0, 2], characterSpacing: 0.5 },
          ...(content ? [{ text: content, fontSize: 10, color: "#333333", lineHeight: 1.2 }] : []),
        ],
        fillColor: LIGHT_TEAL,
        border: [false, false, false, false],
        margin: [10, 6, 8, 6],
      },
    ]],
  },
  layout: noLayout,
  margin: [40, 0, 40, 6],
});

// ─── Main generator ───────────────────────────────────────────────────────────

export const generateCardiologyReportPdf = async (
  id: number,
  res: Response,
  requestingDoctorId: number
) => {
  try {
    if (!id || isNaN(id)) {
      return res.status(400).json({ success: false, error: "Invalid cardiology report ID" });
    }

    const report = await CardiologyReportModel.findByIdWithPatient(id, requestingDoctorId);
    if (!report) {
      return res.status(404).json({ success: false, error: "Cardiology report not found" });
    }

    const doctorProfile = await DoctorModel.findByUserId(report.doctor_user_id);

    const doctor = {
      name:          `Dr. ${report.doctor_name ?? ""} ${report.doctor_family_name ?? ""}`.trim(),
      speciality:    doctorProfile?.speciality    || "Cardiologue",
      order:         doctorProfile?.order_num     || "",
      establishment: doctorProfile?.work_location || "",
      tel:           doctorProfile?.phone_number  || "",
      email:         (report as any).doctor_email || "",
    };

    const patient = report.patient;
    const patientFullName = patient
      ? `${patient.name ?? ""} ${patient.family_name ?? ""}`.trim()
      : "Patient inconnu";
    const genre    = (patient?.genre || "").toLowerCase();
    const sexLabel = genre === "femme" ? "Féminin" : genre === "homme" ? "Masculin" : "";
    const birthRaw = patient?.dateNaissance ?? null;
    const birthDate  = birthRaw ? new Date(birthRaw) : null;
    const birthLabel = birthDate && !isNaN(birthDate.getTime())
      ? birthDate.toLocaleDateString("fr-FR") : "";

    // Calculate age from birth date
    const ageLabel = (() => {
      if (!birthDate || isNaN(birthDate.getTime())) return "";
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const mDiff = today.getMonth() - birthDate.getMonth();
      if (mDiff < 0 || (mDiff === 0 && today.getDate() < birthDate.getDate())) age--;
      return `${age} ans`;
    })();

    // If genre or dateNaissance are missing from the patient record,
    // parse "Patient de X ans, sexe Y" from the generated report text as fallback.
    let effectiveSexLabel = sexLabel;
    let effectiveAgeLabel = ageLabel;
    if ((!effectiveSexLabel || !effectiveAgeLabel) && report.generated_report) {
      const m = report.generated_report.match(/Patient de (\d+) ans,?\s*sexe (\w+)/i);
      if (m) {
        if (!effectiveAgeLabel && m[1]) effectiveAgeLabel = `${m[1]} ans`;
        if (!effectiveSexLabel && m[2]) {
          const s = m[2].toLowerCase();
          effectiveSexLabel = s.includes("masculin") || s === "homme" ? "Masculin"
                            : s.includes("f")                         ? "F\u00e9minin"
                            : m[2];
        }
      }
    }

    const createdDate   = new Date(report.created_at);
    const formattedDate = createdDate.toLocaleDateString("fr-FR", {
      day: "numeric", month: "long", year: "numeric",
    });

    const ordNum = report.id
      ? `N° CR-${new Date().getFullYear()}-${String(report.id).padStart(3, "0")}`
      : "";

    // ── Content parsing ───────────────────────────────────────────────────────
    const SECTION_TITLES = [
      "EXAMEN CLINIQUE", "ANTÉCÉDENTS", "ECG", "ÉCHOCARDIOGRAPHIE",
      "BIOLOGIE", "SCORES", "NOTES", "CONCLUSION",
    ];
    const SECTION_REGEX = new RegExp(`^(${SECTION_TITLES.join("|")})\\s*:?\\s*(.*)`);

    const sanitize = (txt: string) =>
      txt
        .replace(/₀/g,"0").replace(/₁/g,"1").replace(/₂/g,"2").replace(/₃/g,"3").replace(/₄/g,"4")
        .replace(/₅/g,"5").replace(/₆/g,"6").replace(/₇/g,"7").replace(/₈/g,"8").replace(/₉/g,"9")
        .replace(/⁰/g,"0").replace(/¹/g,"1").replace(/²/g,"2").replace(/³/g,"3").replace(/⁴/g,"4")
        .replace(/⁵/g,"5").replace(/⁶/g,"6").replace(/⁷/g,"7").replace(/⁸/g,"8").replace(/⁹/g,"9");

    const items: Item[] = [];

    if (report.generated_report) {
      const paragraphs = sanitize(report.generated_report)
        .split("\n")
        .filter((p: string) => p.trim() !== "");

      for (let idx = 0; idx < paragraphs.length; idx++) {
        const p: string = paragraphs[idx]!;
        const match = p.match(SECTION_REGEX);

        if (match) {
          const title         = match[1] || "";
          const inlineContent = (match[2] || "").trim();
          let content = inlineContent;

          const next = idx + 1 < paragraphs.length ? paragraphs[idx + 1]! : "";
          if (!content && next && !next.match(SECTION_REGEX) && !next.startsWith("Patient de ")) {
            content = next;
            idx++;
          }
          items.push({ kind: "section", title, content });

        } else if (p.startsWith("Patient de ") || (idx === 0 && /\d+\s*ans/.test(p))) {
          items.push({ kind: "intro", text: p });
        } else {
          items.push({ kind: "paragraph", text: p });
        }
      }
    }

    if (report.free_notes && !report.generated_report?.includes(report.free_notes)) {
      items.push({ kind: "section", title: "NOTES", content: report.free_notes });
    }

    // ── Footer contact fields ─────────────────────────────────────────────────
    type CF = { label: string; value: string };
    const contactFields: CF[] = [];
    if (doctor.establishment) contactFields.push({ label: "ADRESSE",   value: doctor.establishment });
    if (doctor.tel)           contactFields.push({ label: "TÉLÉPHONE", value: doctor.tel });
    if (doctor.email)         contactFields.push({ label: "EMAIL",     value: doctor.email });

    const contactTableBody = [
      contactFields.map((f) => ({
        stack: [
          { text: f.label, fontSize: 7, bold: true, color: MUTED, characterSpacing: 1.2 },
          { text: f.value, fontSize: 9, color: TEAL, margin: [0, 2, 0, 0] },
        ],
        border: [false, false, false, false],
      })),
    ];
    const contactWidths = contactFields.map(() => "auto" as const);

    // ─── Simple full-width pagination ─────────────────────────────────────────
    //
    // Items fill each page until CONTENT_BOTTOM (≈769pt). The signature block
    // is absolutePosition at y=680 and naturally overlays any content beneath it.
    // No split, no narrow zone — text writes normally, signature floats on top.
    // ─────────────────────────────────────────────────────────────────────────

    type PageDef = { items: Item[] };
    const pages: PageDef[] = [];
    const remaining: Item[] = [...items];
    let isFirst = true;

    while (remaining.length > 0) {
      const startY = isFirst ? P1_START_Y : PN_START_Y;
      let currentY = startY;
      const pageItems: Item[] = [];

      while (remaining.length > 0) {
        const first = remaining[0]!;
        const h = estimateItemH(first);
        // Stop when adding this item would exceed the page's content area
        if (currentY + h > CONTENT_BOTTOM && pageItems.length > 0) break;
        currentY += h;
        pageItems.push(remaining.shift()!);
      }

      // Safety: always make at least one item of progress
      if (pageItems.length === 0 && remaining.length > 0) {
        pageItems.push(remaining.shift()!);
      }

      pages.push({ items: pageItems });
      isFirst = false;
    }

    if (pages.length === 0) pages.push({ items: [] });

    // ─── Item → pdfmake element ───────────────────────────────────────────────

    const itemToEl = (item: Item): object => {
      if (item.kind === "section")
        return makeSectionBlock(item.title, item.content);
      if (item.kind === "intro") {
        return {
          text: item.text,
          bold: true, fontSize: 11, color: "#111111",
          margin: [40, 0, 40, 8],
        };
      }
      return {
        text: item.text,
        fontSize: 10, color: "#333333",
        alignment: "justify", lineHeight: 1.2,
        margin: [40, 0, 40, 4],
      };
    };

    // ─── Build content ────────────────────────────────────────────────────────
    const content: any[] = [];

    // ── HEADER (light teal) ──────────────────────────────────────────────────────────────
    // Doctor info on the left, logo + order + patient info box on the right.
    // Merging patient info here removes the separate teal patient bar (~70pt saved).
    content.push({
      table: {
        widths: ["*", "auto"],
        body: [[
          {
            stack: [
              { text: doctor.name, fontSize: 18, bold: true, color: TEAL, lineHeight: 1.1 },
              {
                text: doctor.speciality.toUpperCase(),
                fontSize: 9, color: DARK_TEAL, characterSpacing: 1,
                margin: [0, 4, 0, 10],
              },
              ...(doctor.order         ? [{ text: `N\u00b0 d'ordre ${doctor.order}`, fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.establishment ? [{ text: doctor.establishment,                fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.tel           ? [{ text: `T\u00e9l. ${doctor.tel}`,           fontSize: 9, color: TEXT_MED }] : []),
              ...(doctor.email         ? [{ text: doctor.email,                        fontSize: 9, color: TEAL     }] : []),
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [40, 20, 8, 20],
          },
          {
            stack: [
              // Logo
              { image: `data:image/png;base64,${logoBase64}`, width: 110, alignment: "right" },
              // Order number
              ...(ordNum ? [{
                text: ordNum,
                fontSize: 8, color: MUTED, alignment: "right",
                characterSpacing: 0.5, margin: [0, 4, 0, 0],
              }] : []),
              // Patient info box (replaces the separate teal patient bar)
              {
                table: {
                  widths: ["*"],
                  body: [[
                    {
                      stack: [
                        { text: patientFullName.toUpperCase(), fontSize: 11, bold: true, color: "white" },
                        // Sex and age on the same row
                        ...((effectiveSexLabel || effectiveAgeLabel) ? [{
                          text: [
                            ...(effectiveSexLabel ? [effectiveSexLabel]                          : []),
                            ...(effectiveSexLabel && effectiveAgeLabel ? ["  \u00b7  "]          : []),
                            ...(effectiveAgeLabel ? [effectiveAgeLabel]                          : []),
                          ].join(""),
                          fontSize: 9, color: "#cce8f0", margin: [0, 3, 0, 0],
                        }] : []),
                        // Birth date (smaller, optional)
                        ...(birthLabel ? [{
                          text: `N\u00e9(e) le ${birthLabel}`,
                          fontSize: 7.5, color: "#9dd4e4", margin: [0, 1, 0, 0],
                        }] : []),
                      ],
                      fillColor: TEAL,
                      border: [false, false, false, false],
                      margin: [8, 6, 8, 6],
                    },
                  ]],
                },
                layout: noLayout,
                margin: [0, 6, 0, 0],
              },
            ],
            fillColor: LIGHT_TEAL,
            border: [false, false, false, false],
            margin: [8, 20, 40, 20],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 0, 0, 0],
    });

    // ── SLIM TITLE BAR — title on left, date on right ──────────────────────────────
    content.push({
      table: {
        widths: ["*"],
        body: [[
          {
            columns: [
              // Left: title + subtitle
              {
                stack: [
                  {
                    text: "Compte Rendu Cardiologique",
                    fontSize: 14, bold: true, color: "white",
                    decoration: "underline", decorationStyle: "solid",
                  },
                  {
                    text: "BILAN CARDIOLOGIQUE",
                    fontSize: 6.5, color: "#cce8f0", characterSpacing: 1,
                    margin: [0, 2, 0, 0],
                  },
                ],
                width: "*",
              },
              // Right: date label + value
              {
                stack: [
                  { text: "DATE", fontSize: 7, bold: true, color: "#9dd4e4", characterSpacing: 1.5, alignment: "right" },
                  { text: formattedDate, fontSize: 10, bold: true, color: "white", alignment: "right", margin: [0, 2, 0, 0] },
                ],
                width: "auto",
              },
            ],
            fillColor: DARK_TEAL,
            border: [false, false, false, false],
            margin: [40, 8, 40, 8],
          },
        ]],
      },
      layout: noLayout,
      margin: [0, 0, 0, 0],
    });

    // Divider
    content.push({
      canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
      margin: [40, 12, 40, 16],
    });

    // Intro line
    content.push({
      text: `Concernant ${patientFullName},`,
      fontSize: 10, bold: true, color: DARK_TEAL,
      margin: [40, 0, 40, 14],
    });

    // ── Page 1 ───────────────────────────────────────────────────────────────
    const page0 = pages[0]!;
    page0.items.forEach((item) => content.push(itemToEl(item)));
    content.push(makeSignatureBlock());

    // ── Continuation pages ────────────────────────────────────────────────────
    for (let pi = 1; pi < pages.length; pi++) {
      const page = pages[pi]!;

      content.push({ text: "", pageBreak: "before" });

      content.push({
        stack: [
          { text: "Compte Rendu Cardiologique — Suite", fontSize: 14, bold: true, color: DARK_TEAL },
          { text: `${doctor.name}  ·  ${formattedDate}`, fontSize: 8, color: MUTED, margin: [0, 3, 0, 0] },
        ],
        margin: [40, 24, 40, 8],
      });

      content.push({
        canvas: [{ type: "line", x1: 0, y1: 0, x2: PAGE_W - 80, y2: 0, lineWidth: 0.5, lineColor: SEPARATOR }],
        margin: [40, 0, 40, 12],
      });

      page.items.forEach((item) => content.push(itemToEl(item)));
      content.push(makeSignatureBlock());
    }

    // ─────────────────────────────────────────────────────────────────────────
    const docDefinition: any = {
      pageMargins: [0, 0, 0, 72],
      defaultStyle: { fontSize: 10, lineHeight: 1.2 },

      footer: () => ({
        stack: [
          {
            canvas: [{
              type: "line",
              x1: 40, y1: 0, x2: PAGE_W - 40, y2: 0,
              lineWidth: 0.6, lineColor: SEPARATOR,
            }],
          },
          {
            columns: [
              contactFields.length > 0
                ? {
                    table: { widths: contactWidths, body: contactTableBody },
                    layout: makeFooterContactLayout(contactFields.length),
                    width: "*",
                    margin: [0, 8, 0, 0],
                  }
                : { text: "", width: "*" },
              {
                stack: [
                  { text: "MyPrescription",    fontSize: 10, bold: true, color: TEAL, alignment: "right" },
                  { text: "MYPRESCRIPTION.DZ", fontSize: 7.5, color: MUTED, alignment: "right", margin: [0, 2, 0, 0] },
                ],
                width: "auto",
                margin: [0, 8, 0, 0],
              },
            ],
            margin: [40, 0, 40, 0],
          },
          {
            canvas: [{ type: "rect", x: 0, y: 0, w: PAGE_W, h: 10, color: TEAL }],
            margin: [0, 6, 0, 0],
          },
        ],
      }),

      content,
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename=cr-cardiologique-${report.id}.pdf`);
    pdfDoc.pipe(res);
    pdfDoc.end();

  } catch (error) {
    console.error("Error generating cardiology report PDF:", error);
    return res.status(500).json({ success: false, error: "Internal server error while generating PDF" });
  }
};