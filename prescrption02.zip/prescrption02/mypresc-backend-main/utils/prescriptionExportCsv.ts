import type { Response } from "express";
import { PrescriptionModel } from "../models/prescription.model";
import { DoctorModel } from "../models/doctor.model";
import { PatientModel } from "../models/patient.model";
import { UserModel } from "../models/user.model";

export const generatePrescriptionExportCsv = async (
    doctorUserId: number,
    patientIds: string[],
    isAll: boolean,
    res: Response
) => {
    try {
        if (!doctorUserId || isNaN(doctorUserId)) {
            return res.status(400).json({ success: false, error: "Invalid doctor ID" });
        }

        // Get doctor information
        const doctorProfile = await DoctorModel.findByUserId(doctorUserId);
        const user = await UserModel.findById(doctorUserId);
        if (!doctorProfile || !user) {
            return res.status(404).json({ success: false, error: "Doctor profile not found" });
        }

        let prescriptions: any[] = [];
        if (isAll) {
            // Get all prescriptions for this doctor (limit to 1000 for performance)
            prescriptions = await PrescriptionModel.findByDoctorId(doctorUserId, 1000, 0);
        } else {
            if (!patientIds || patientIds.length === 0) {
                // If not all and no patients selected, return empty list or handle as error?
                // Assuming empty list is valid but results in empty CSV
                prescriptions = [];
            } else {
                prescriptions = await PrescriptionModel.findByDoctorIdAndPatientIds(doctorUserId, patientIds);
            }
        }

        // Fetch patient details and medications for each prescription
        const prescriptionsWithPatients = await Promise.all(
            prescriptions.map(async (prescription) => {
                const patient = await PatientModel.findById(prescription.patient_id);
                const prescriptionDetails = await PrescriptionModel.findByIdWithDetails(prescription.id);

                // Format medications as a list
                const medications = prescriptionDetails?.medications || [];
                const medicationsList = medications.map(med => {
                    const brand = med.medication?.nom_de_marque || med.medication?.denomination_commune_internationale || "Médicament";
                    const dosage = med.dosage || "";
                    const quantity = med.quantity || 1;
                    return `${quantity}x ${brand} (${dosage})`;
                }).join("; ");

                return {
                    id: prescription.id,
                    created_at: prescription.created_at,
                    patient_name: patient ? `${patient.name} ${patient.family_name}`.trim() : "Patient inconnu",
                    medications: medicationsList || "Aucun médicament",
                    remarks: prescription.remarks || ""
                };
            })
        );

        // Sort by date (most recent first)
        prescriptionsWithPatients.sort((a, b) =>
            new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        );

        // Generate CSV content
        const header = "N° Ordonnance,Nom du patient,Date de création,Les Medicaments,Remarques\n";
        const rows = prescriptionsWithPatients.map(p => {
            const date = new Date(p.created_at).toLocaleDateString("fr-FR", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            });
            // Escape quotes and handle commas in content
            const escape = (text: string) => `"${text.replace(/"/g, '""')}"`;

            return [
                p.id,
                escape(p.patient_name),
                escape(date),
                escape(p.medications),
                escape(p.remarks)
            ].join(",");
        }).join("\n");

        const csvContent = header + rows;
        const filename = `export_ordonnances_${new Date().getTime()}.csv`;

        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename=${filename}`);

        res.send(csvContent);

    } catch (error) {
        console.error("Error generating prescription export CSV:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error while generating CSV export"
        });
    }
};
