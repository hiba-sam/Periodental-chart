import { Server as HTTPServer } from 'http';
import { Server as SocketServer, Socket } from 'socket.io';
import { socketAuthMiddleware } from '../middlewares/socketAuth';
import { securityLogger } from './securityLogger';
import passport from 'passport';

class SocketManager {
  private static instance: SocketManager;
  private io: SocketServer | null = null;

  private constructor() { }

  static getInstance(): SocketManager {
    if (!SocketManager.instance) {
      SocketManager.instance = new SocketManager();
    }
    return SocketManager.instance;
  }

  /**
   * Initialize Socket.io server
   */
  initialize(httpServer: HTTPServer, sessionMiddleware?: any): SocketServer {
    if (this.io) {
      return this.io;
    }

    this.io = new SocketServer(httpServer, {
      cors: {
        origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
        credentials: true,
        methods: ['GET', 'POST'],
      },
      transports: ['websocket', 'polling'],
      pingTimeout: 60000,
      pingInterval: 25000,
    });

    // Share Express session with Socket.io
    if (sessionMiddleware) {
      this.io.engine.use(sessionMiddleware);
      // Also add passport middlewares for session deserialization
      this.io.engine.use(passport.initialize());
      this.io.engine.use(passport.session());
    }

    // Apply authentication middleware
    this.io.use(socketAuthMiddleware);

    return this.io;
  }

  /**
   * Get Socket.io instance
   */
  getIO(): SocketServer {
    if (!this.io) {
      throw new Error('Socket.io not initialized. Call initialize() first.');
    }
    return this.io;
  }

  /**
   * Emit to user's socket(s)
   */
  emitToUser(userId: number, event: string, data: any): void {
    if (!this.io) return;

    // Emit to all sockets of this user (in case multiple tabs)
    this.io.to(`user:${userId}`).emit(event, data);
  }

  /**
   * Emit to conversation room
   */
  emitToConversation(conversationId: number, event: string, data: any): void {
    if (!this.io) return;

    this.io.to(`conversation:${conversationId}`).emit(event, data);
  }

  /**
   * Emit to a specific room
   */
  emitToRoom(room: string, event: string, data: any): void {
    if (!this.io) return;

    this.io.to(room).emit(event, data);
  }

  /**
   * Check if a user has any socket in a specific room
   */
  isUserInRoom(userId: number, room: string): boolean {
    if (!this.io) return false;

    const userSockets = this.io.sockets.adapter.rooms.get(`user:${userId}`);
    const roomSockets = this.io.sockets.adapter.rooms.get(room);

    if (!userSockets || !roomSockets) return false;

    // Check if any of user's sockets are in the target room
    for (const socketId of userSockets) {
      if (roomSockets.has(socketId)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Get all sockets for a user
   */
  getUserSockets(userId: number): Socket[] {
    if (!this.io) return [];

    const sockets: Socket[] = [];
    const roomSockets = this.io.sockets.adapter.rooms.get(`user:${userId}`);

    if (roomSockets) {
      roomSockets.forEach((socketId) => {
        const socket = this.io!.sockets.sockets.get(socketId);
        if (socket) {
          sockets.push(socket);
        }
      });
    }

    return sockets;
  }

  /**
   * Check if user is online
   */
  isUserOnline(userId: number): boolean {
    if (!this.io) return false;

    const room = this.io.sockets.adapter.rooms.get(`user:${userId}`);
    return room !== undefined && room.size > 0;
  }

  /**
   * Get online users count
   */
  getOnlineUsersCount(): number {
    if (!this.io) return 0;

    let count = 0;
    this.io.sockets.adapter.rooms.forEach((value, key) => {
      if (key.startsWith('user:')) {
        count++;
      }
    });

    return count;
  }

  /**
   * Disconnect all sockets for a user
   */
  disconnectUser(userId: number): void {
    const sockets = this.getUserSockets(userId);
    sockets.forEach((socket) => {
      socket.disconnect(true);
    });
  }

  /**
   * Broadcast presence change to conversation partners
   * Notifies all users who have a conversation with the given user
   */
  broadcastPresenceChange(
    userId: number,
    status: 'online' | 'away' | 'offline',
    partnerIds?: number[]
  ): void {
    if (!this.io) return;

    const payload = {
      userId,
      status,
      timestamp: new Date(),
    };

    // If partner IDs are provided, send to those specific users
    if (partnerIds && partnerIds.length > 0) {
      partnerIds.forEach(partnerId => {
        this.emitToUser(partnerId, 'presence:changed', payload);
      });
    } else {
      // Fallback: broadcast to all connected sockets (less efficient)
      this.io.emit('presence:changed', payload);
    }
  }

  /**
   * Get stats
   */
  getStats() {
    if (!this.io) {
      return { connected: 0, rooms: 0 };
    }

    return {
      connected: this.io.sockets.sockets.size,
      rooms: this.io.sockets.adapter.rooms.size,
      onlineUsers: this.getOnlineUsersCount(),
    };
  }
}

export default SocketManager.getInstance();
