import pool from '../db';

export type PatientAccessAction = 
    | 'VIEW'
    | 'VIEW_LIST'
    | 'SEARCH'
    | 'CREATE'
    | 'UPDATE'
    | 'DELETE'
    | 'EXPORT'
    | 'PRINT'
    | 'SHARE';

export interface PatientAccessLogData {
    userId: number;
    userRole: string;
    patientId: string;
    action: PatientAccessAction;
    accessedFields?: string[];
    queryParams?: Record<string, unknown>;
    ipAddress?: string;
    userAgent?: string;
    sessionId?: string;
    requestId?: string;
    success?: boolean;
    errorMessage?: string;
}

/**
 * Logger pour les accès aux données patients
 * Conformité Loi 25-11 Algérie - Traçabilité obligatoire
 */
export class PatientAccessLogger {
    /**
     * Log un accès aux données patient
     */
    static async log(data: PatientAccessLogData): Promise<number | null> {
        try {
            const query = `
                SELECT log_patient_access(
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11
                ) as log_id
            `;

            const result = await pool.query(query, [
                data.userId,
                data.userRole,
                data.patientId,
                data.action,
                data.accessedFields || null,
                data.ipAddress || null,
                data.userAgent || null,
                data.sessionId || null,
                data.requestId || null,
                data.success ?? true,
                data.errorMessage || null
            ]);

            return result.rows[0]?.log_id || null;
        } catch (error) {
            // Ne pas faire échouer l'opération principale si le logging échoue
            console.error('[PatientAccessLogger] Failed to log access:', error);
            return null;
        }
    }

    /**
     * Log une consultation de dossier patient
     */
    static async logView(
        userId: number,
        userRole: string,
        patientId: string,
        accessedFields?: string[],
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<number | null> {
        return this.log({
            userId,
            userRole,
            patientId,
            action: 'VIEW',
            accessedFields,
            ...context
        });
    }

    /**
     * Log une recherche de patients
     */
    static async logSearch(
        userId: number,
        userRole: string,
        queryParams: Record<string, unknown>,
        resultPatientIds: string[],
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<void> {
        // Logger chaque patient retourné par la recherche
        for (const patientId of resultPatientIds) {
            await this.log({
                userId,
                userRole,
                patientId,
                action: 'SEARCH',
                queryParams,
                ...context
            });
        }
    }

    /**
     * Log une modification de dossier patient
     */
    static async logUpdate(
        userId: number,
        userRole: string,
        patientId: string,
        updatedFields: string[],
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<number | null> {
        return this.log({
            userId,
            userRole,
            patientId,
            action: 'UPDATE',
            accessedFields: updatedFields,
            ...context
        });
    }

    /**
     * Log une création de dossier patient
     */
    static async logCreate(
        userId: number,
        userRole: string,
        patientId: string,
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<number | null> {
        return this.log({
            userId,
            userRole,
            patientId,
            action: 'CREATE',
            ...context
        });
    }

    /**
     * Log un export de données patient
     */
    static async logExport(
        userId: number,
        userRole: string,
        patientId: string,
        exportedFields: string[],
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<number | null> {
        return this.log({
            userId,
            userRole,
            patientId,
            action: 'EXPORT',
            accessedFields: exportedFields,
            ...context
        });
    }

    /**
     * Log un échec d'accès (pour détection intrusions)
     */
    static async logAccessFailure(
        userId: number,
        userRole: string,
        patientId: string,
        action: PatientAccessAction,
        errorMessage: string,
        context?: { ipAddress?: string; userAgent?: string; sessionId?: string }
    ): Promise<number | null> {
        return this.log({
            userId,
            userRole,
            patientId,
            action,
            success: false,
            errorMessage,
            ...context
        });
    }
}

/**
 * Middleware Express pour extraire le contexte de requête
 */
export function extractRequestContext(req: any): {
    ipAddress: string;
    userAgent: string;
    sessionId?: string;
} {
    return {
        ipAddress: req.ip || req.connection?.remoteAddress || 'unknown',
        userAgent: req.get('User-Agent') || 'unknown',
        sessionId: req.sessionID || req.session?.id
    };
}
