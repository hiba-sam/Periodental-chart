import winston from 'winston';
import path from 'path';

/**
 * Security Logger for MyPresc Backend
 * 
 * Enregistre tous les événements de sécurité critiques :
 * - Chargement des secrets
 * - Rotation des secrets
 * - Tentatives d'authentification
 * - Rate limiting activé
 * - Accès non autorisés
 * 
 * Conformité : RGPD art. 32, ANPDP art. 25
 */

const logFormat = winston.format.combine(
    winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss'
    }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json()
);

const consoleFormat = winston.format.combine(
    winston.format.colorize(),
    winston.format.timestamp({
        format: 'YYYY-MM-DD HH:mm:ss'
    }),
    winston.format.printf(({ timestamp, level, message, ...metadata }) => {
        let msg = `${timestamp} [${level}] : ${message}`;
        if (Object.keys(metadata).length > 0) {
            msg += ` ${JSON.stringify(metadata)}`;
        }
        return msg;
    })
);

// ============================================
// SECURITY LOGGER
// ============================================
export const securityLogger = winston.createLogger({
    level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
    format: logFormat,
    transports: [
        // Log de sécurité persistant (fichier)
        new winston.transports.File({
            filename: path.join(process.cwd(), 'logs', 'security.log'),
            level: 'info',
            maxsize: 5242880, // 5MB
            maxFiles: 10,
            tailable: true
        }),
        // Errors critiques séparés
        new winston.transports.File({
            filename: path.join(process.cwd(), 'logs', 'security-error.log'),
            level: 'error',
            maxsize: 5242880,
            maxFiles: 5
        })
    ]
});

// Console uniquement en développement
if (process.env.NODE_ENV !== 'production') {
    securityLogger.add(new winston.transports.Console({
        format: consoleFormat
    }));
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Enregistre le chargement des secrets
 */
export function logSecretsLoaded(source: 'env' | 'vault') {
    securityLogger.info('[SECRETS] Secrets loaded successfully', {
        source,
        timestamp: new Date().toISOString(),
        event: 'SECRETS_LOADED'
    });
}

/**
 * Enregistre une rotation de secrets
 */
export function logSecretsRotation(rotatedKeys: string[]) {
    securityLogger.warn('[SECRETS] Secrets rotation performed', {
        rotatedKeys,
        timestamp: new Date().toISOString(),
        event: 'SECRETS_ROTATED'
    });
}

/**
 * Enregistre un échec de chargement de secrets
 */
export function logSecretsLoadFailure(error: Error, source: 'env' | 'vault') {
    securityLogger.error('[SECRETS] Failed to load secrets', {
        source,
        error: error.message,
        stack: error.stack,
        timestamp: new Date().toISOString(),
        event: 'SECRETS_LOAD_FAILED'
    });
}

/**
 * Enregistre une tentative d'authentification échouée
 */
export function logAuthenticationFailure(email: string, ip: string, reason: string) {
    securityLogger.warn('[AUTH] Authentication failed', {
        email,
        ip,
        reason,
        timestamp: new Date().toISOString(),
        event: 'AUTH_FAILED'
    });
}

/**
 * Enregistre un rate limiting activé
 */
export function logRateLimitHit(ip: string, endpoint: string, limit: number) {
    securityLogger.warn('[RATE_LIMIT] Rate limit exceeded', {
        ip,
        endpoint,
        limit,
        timestamp: new Date().toISOString(),
        event: 'RATE_LIMIT_HIT'
    });
}

/**
 * Enregistre une tentative d'accès non autorisé
 */
export function logUnauthorizedAccess(userId: string | null, resource: string, ip: string) {
    securityLogger.warn('[ACCESS] Unauthorized access attempt', {
        userId: userId || 'anonymous',
        resource,
        ip,
        timestamp: new Date().toISOString(),
        event: 'UNAUTHORIZED_ACCESS'
    });
}

/**
 * Enregistre le démarrage sécurisé du serveur
 */
export function logServerStartup(port: number, env: string) {
    securityLogger.info('[SERVER] Server started securely', {
        port,
        environment: env,
        timestamp: new Date().toISOString(),
        event: 'SERVER_STARTED'
    });
}

export default securityLogger;
