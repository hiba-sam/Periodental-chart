import PdfPrinter from "pdfmake";
import type { Response } from "express";
import { PrescriptionModel } from "../models/prescription.model";
import { DoctorModel } from "../models/doctor.model";
import { PatientModel } from "../models/patient.model";
import fs from "fs";
import path from "path";
import { UserModel, type User } from "../models/user.model";

const fonts = {
  Roboto: {
    normal: "node_modules/roboto-fontface/fonts/roboto/Roboto-Regular.woff",
    bold: "node_modules/roboto-fontface/fonts/roboto/Roboto-Medium.woff",
    italics: "node_modules/roboto-fontface/fonts/roboto/Roboto-RegularItalic.woff",
    bolditalics: "node_modules/roboto-fontface/fonts/roboto/Roboto-MediumItalic.woff"
  },
};

const printer = new PdfPrinter(fonts);

const logoPath = path.join(__dirname, "logo.png");
const logoBase64 = fs.readFileSync(logoPath).toString("base64");

export const generatePrescriptionExport = async (doctorUserId: number, res: Response) => {
  try {
    if (!doctorUserId || isNaN(doctorUserId)) {
      return res.status(400).json({ success: false, error: "Invalid doctor ID" });
    }

    // Get doctor information
    const doctorProfile = await DoctorModel.findByUserId(doctorUserId);
    const user = await UserModel.findById(doctorUserId);
    if (!doctorProfile || !user) {
      return res.status(404).json({ success: false, error: "Doctor profile not found" });
    }

    // Get doctor user information
    const doctor = {
      name: `Dr. ${user?.name ?? ""} ${user?.family_name ?? ""}`.trim(),
      speciality: doctorProfile.speciality || "Médecin généraliste",
      order: doctorProfile.order_num || "",
      establishment: doctorProfile.work_location || "",
      address: doctorProfile.home_location || "",
      tel: doctorProfile.phone_number || "",
      email: user?.email || "",
    };

    // Get all prescriptions for this doctor (limit to 1000 for performance)
    const prescriptions = await PrescriptionModel.findByDoctorId(doctorUserId, 1000, 0);

    // Fetch patient details for each prescription
    const prescriptionsWithPatients = await Promise.all(
      prescriptions.map(async (prescription) => {
        const patient = await PatientModel.findById(prescription.patient_id);
        return {
          id: prescription.id,
          created_at: prescription.created_at,
          patient: patient ? `${patient.name} ${patient.family_name}`.trim() : "Patient inconnu",
        };
      })
    );

    // Sort by date (most recent first)
    prescriptionsWithPatients.sort((a, b) =>
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );

    const today = new Date().toLocaleDateString("fr-FR", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    // Create table rows for prescriptions
    const tableBody = [
      // Header row
      [
        { text: "N° Ordonnance", style: "tableHeader", bold: true },
        { text: "Nom du patient", style: "tableHeader", bold: true },
        { text: "Date de création", style: "tableHeader", bold: true }
      ],
      // Data rows
      ...prescriptionsWithPatients.map((presc) => [
        { text: `#${presc.id}`, alignment: "center" },
        { text: presc.patient },
        {
          text: new Date(presc.created_at).toLocaleDateString("fr-FR", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          }),
          alignment: "center"
        }
      ])
    ];

    const docDefinition = {
      pageMargins: [40, 100, 40, 60],
      header: {
        margin: [40, 20, 40, 0],
        columns: [
          [
            { text: doctor.name, style: "header", fontSize: 14, bold: true },
            { text: doctor.speciality, fontSize: 11 },
            ...(doctor.order ? [{ text: `N° d'ordre ${doctor.order}`, fontSize: 10 }] : []),
            ...(doctor.establishment ? [{ text: doctor.establishment, bold: true, fontSize: 10 }] : []),
          ],
          {
            image: 'data:image/png;base64,' + logoBase64,
            width: 100,
            alignment: 'right',
          }
        ]
      },
      footer: (currentPage: number, pageCount: number) => {
        return {
          margin: [40, 0, 40, 20],
          columns: [
            {
              text: `${doctor.address || ""}\nTel : ${doctor.tel || ""}\nCourriel : ${doctor.email || ""}`,
              fontSize: 9,
              color: "#666666"
            },
            {
              text: `Page ${currentPage} / ${pageCount}`,
              alignment: "right",
              fontSize: 9,
              color: "#666666"
            }
          ]
        };
      },
      content: [
        // Title
        {
          text: "Export des Ordonnances",
          style: "title",
          fontSize: 18,
          bold: true,
          alignment: "center",
          margin: [0, 0, 0, 10]
        },
        {
          text: `Généré le ${today}`,
          alignment: "center",
          fontSize: 11,
          color: "#666666",
          margin: [0, 0, 0, 20]
        },

        // Summary
        {
          text: [
            { text: "Nombre total d'ordonnances : ", bold: true },
            { text: prescriptionsWithPatients.length.toString() }
          ],
          margin: [0, 0, 0, 20]
        },

        // Table
        {
          table: {
            headerRows: 1,
            widths: [80, "*", 120],
            body: tableBody
          },
          layout: {
            fillColor: (rowIndex: number) => {
              return rowIndex === 0 ? "#667eea" : (rowIndex % 2 === 0 ? "#f3f4f6" : null);
            },
            hLineWidth: () => 0.5,
            vLineWidth: () => 0.5,
            hLineColor: () => "#e5e7eb",
            vLineColor: () => "#e5e7eb",
            paddingLeft: () => 8,
            paddingRight: () => 8,
            paddingTop: () => 6,
            paddingBottom: () => 6,
          }
        }
      ],
      styles: {
        header: {
          fontSize: 14,
          bold: true,
          color: "#1a202c"
        },
        tableHeader: {
          fontSize: 11,
          color: "#ffffff",
          bold: true,
          alignment: "center"
        },
        title: {
          fontSize: 18,
          bold: true,
          color: "#1a202c"
        }
      },
    } as any;

    const pdfDoc = printer.createPdfKitDocument(docDefinition);

    const filename = `export_ordonnances_${new Date().getTime()}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename=${filename}`);

    pdfDoc.pipe(res);
    pdfDoc.end();
  } catch (error) {
    console.error("Error generating prescription export PDF:", error);
    return res.status(500).json({
      success: false,
      error: "Internal server error while generating PDF export"
    });
  }
};