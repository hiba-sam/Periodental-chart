import { Router } from 'express';
import { getPrivacyChoice, setPrivacyChoice, getDoctorsWithSharedChoice } from '../controllers/doctorPatientPrivacy.controller';
import { requireDoctorAuth } from '../middlewares/auth';

const router = Router();

// Get privacy choice for current doctor and a patient
router.get('/patient/:patientId', requireDoctorAuth, getPrivacyChoice);

// Set privacy choice for current doctor and a patient
router.post('/patient/:patientId', requireDoctorAuth, setPrivacyChoice);

// Get doctors with shared choice for a patient
router.get('/patient/:patientId/shared-doctors', requireDoctorAuth, getDoctorsWithSharedChoice);

export default router;
