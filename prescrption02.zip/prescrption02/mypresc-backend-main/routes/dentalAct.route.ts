import express from 'express';
import { requireAuth } from '../middlewares/auth.js';
import {
    searchCatalog,
    getCatalogAct,
    getCatalogChapters,
    getCatalogFamilies,
    getPatientDentalActs,
    createDentalAct,
    getDentalAct,
    updateDentalAct,
    deleteDentalAct,
    getPatientDentalStats
} from '../controllers/dentalAct.controller.js';

const router = express.Router();

// ============================================
// ACT CATALOG ROUTES (public for authenticated users)
// ============================================

// Search acts in catalog
router.get('/catalog/acts', requireAuth, searchCatalog);

// Get act by ID
router.get('/catalog/acts/:id', requireAuth, getCatalogAct);

// Get chapters for filtering
router.get('/catalog/chapters', requireAuth, getCatalogChapters);

// Get families for filtering
router.get('/catalog/families', requireAuth, getCatalogFamilies);

// ============================================
// PATIENT DENTAL ACTS ROUTES
// ============================================

// Get dental acts for a patient
router.get('/patients/:patientId/dental-acts', requireAuth, getPatientDentalActs);

// Create dental act for a patient
router.post('/patients/:patientId/dental-acts', requireAuth, createDentalAct);

// Get patient dental statistics
router.get('/patients/:patientId/dental-stats', requireAuth, getPatientDentalStats);

// ============================================
// DENTAL ACT CRUD ROUTES
// ============================================

// Get dental act details
router.get('/dental-acts/:id', requireAuth, getDentalAct);

// Update dental act
router.patch('/dental-acts/:id', requireAuth, updateDentalAct);

// Delete dental act
router.delete('/dental-acts/:id', requireAuth, deleteDentalAct);

export default router;
