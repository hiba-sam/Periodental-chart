import express from 'express';
import { createWaitingEntry, deleteWaitingEntry, getWaitingEntries, getWaitingEntry, updateWaitingEntry } from '../controllers/waiting_room.controller';
import { getTodaySchedule, nextPatient, getCurrentCall, peekNextPatient } from '../controllers/schedule.controller';

const router = express.Router();

router.route('/')
        .post(createWaitingEntry)
        .get(getWaitingEntries);

router.get('/schedule', getTodaySchedule);
router.get('/schedule/peek-next-patient', peekNextPatient);
router.post('/schedule/next-patient', nextPatient);
router.get('/schedule/current-call', getCurrentCall);

router.route('/:id')
        .get(getWaitingEntry)
        .put(updateWaitingEntry)
        .delete(deleteWaitingEntry);


export default router;