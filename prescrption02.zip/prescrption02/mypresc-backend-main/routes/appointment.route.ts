import express from "express";
import { createAppointment, deleteAppointment, getAllAppointments, getAppointment, getAppointmentsByDate, getAppointmentsByPatient, updateAppointment } from "../controllers/appointment.controller";
import { createAppointmentValidator, paginationValidator, validateRequest } from "../middlewares/validation";
import { param, query } from "express-validator";
import { requireDoctorFromQuery, requireDoctor } from "../middlewares/doctor";

const router = express.Router();

router.route("/")
        .post(requireDoctor, createAppointmentValidator, validateRequest, createAppointment)
        .get(requireDoctorFromQuery, paginationValidator, validateRequest, getAllAppointments);

router.get('/date', requireDoctorFromQuery, query('date').isISO8601(), validateRequest, getAppointmentsByDate);
router.get('/patient/:patientId', requireDoctorFromQuery, validateRequest, getAppointmentsByPatient);
        
router.route("/:id")
        .get(requireDoctorFromQuery, validateRequest, getAppointment)
        .put(requireDoctor, validateRequest, updateAppointment)
        .delete(requireDoctorFromQuery, validateRequest, deleteAppointment);

export default router;
