import express from 'express';

const router = express.Router();

// TODO: Add patient call notification routes for assistant functionality

export default router;
