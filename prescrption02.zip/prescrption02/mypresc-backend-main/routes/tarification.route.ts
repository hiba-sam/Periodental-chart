import express from 'express';
import {
    getTarificationsByDoctor,
    getTarificationById,
    createTarification,
    updateTarification,
    deleteTarification,
    getAllTarifications
} from '../controllers/tarification.controller';
import {
    createTarificationValidator,
    updateTarificationValidator,
    getTarificationValidator,
    doctorUserIdQueryValidator,
    paginationValidator,
    validateRequest
} from '../middlewares/validation';
import { requireDoctorFromQuery } from '../middlewares/doctor';

const router = express.Router();

// Get tarifications by doctor (with auto-initialization)
// Uses requireDoctorFromQuery middleware to validate and extract doctorUserId from query
router.get(
    '/doctor',
    validateRequest,
    getTarificationsByDoctor
);

// Main tarification routes
router.route('/')
    .post(createTarificationValidator, validateRequest, createTarification)
    .get(paginationValidator, validateRequest, getAllTarifications);

// Individual tarification routes
router.get('/:id', getTarificationValidator, validateRequest, getTarificationById);
router.put('/:id', updateTarificationValidator, validateRequest, updateTarification);
router.delete('/:id', getTarificationValidator, validateRequest, deleteTarification);

export default router;
