import { Router } from 'express';
import { MessagingController } from '../controllers/messaging.controller';
import { requireAuth } from '../middlewares/auth';
import { uploadMessageAttachment, handleMulterError } from '../config/multer';

const router = Router();

// All messaging routes require authentication
router.use(requireAuth);

/**
 * Search for doctors
 * GET /messaging/users/search?query=John&limit=20
 */
router.get('/users/search', MessagingController.searchDoctors);

/**
 * Get conversation partner based on user role
 * GET /messaging/conversation-partner
 * For assistants: returns their doctor
 * For doctors: returns their assistant
 */
router.get('/conversation-partner', MessagingController.getConversationPartner);

/**
 * Get user presence status
 * GET /messaging/users/:id/presence
 */
router.get('/users/:id/presence', MessagingController.getUserPresence);

/**
 * Get all conversations for current user
 * GET /messaging/conversations
 */
router.get('/conversations', MessagingController.getConversations);

/**
 * Create or get direct conversation
 * POST /messaging/conversations
 * Body: { peerUserId: number }
 */
router.post('/conversations', MessagingController.createConversation);

/**
 * Get messages for a conversation (paginated)
 * GET /messaging/conversations/:id/messages?page=1&pageSize=50
 */
router.get('/conversations/:id/messages', MessagingController.getMessages);

/**
 * Search messages in a conversation
 * GET /messaging/conversations/:id/search?q=keyword&limit=50
 */
router.get('/conversations/:id/search', MessagingController.searchMessages);

/**
 * Send a message in a conversation
 * POST /messaging/conversations/:id/messages
 * Body: { content: string }
 */
router.post('/conversations/:id/messages', MessagingController.sendMessage);

/**
 * Mark message as read
 * POST /messaging/messages/:id/read
 */
router.post('/messages/:id/read', MessagingController.markAsRead);

/**
 * Mark all messages in conversation as read
 * POST /messaging/conversations/:id/read
 */
router.post('/conversations/:id/read', MessagingController.markConversationAsRead);

/**
 * Send a message with an attachment (doctors only)
 * POST /messaging/conversations/:id/attachment
 * Body: FormData with 'attachment' file and optional 'content' text
 */
router.post(
  '/conversations/:id/attachment',
  uploadMessageAttachment,
  handleMulterError,
  MessagingController.sendAttachment
);

export default router;
