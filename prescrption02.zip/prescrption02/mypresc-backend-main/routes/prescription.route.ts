import express from 'express';
import {
  createPrescription,
  getPrescriptionById,
  getPrescriptionsByPatient,
  getPrescriptionsByDoctor,
  getAllPrescriptions,
  generateThePdf,
  exportPrescriptions,
} from '../controllers/prescription.controller';
import { createPrescriptionValidator, getPrescriptionValidator, paginationValidator, validateRequest } from '../middlewares/validation';
import { param } from 'express-validator';

const router = express.Router();

// Main prescription routes
router.route('/')
  .post(createPrescriptionValidator, validateRequest, createPrescription)
  .get(paginationValidator, validateRequest, getAllPrescriptions);

// Get prescriptions by patient
router.get('/patient/:patientId', validateRequest, getPrescriptionsByPatient);

// Get prescriptions by doctor
router.get('/doctor/:doctorId', validateRequest, getPrescriptionsByDoctor);

// Export all prescriptions for authenticated doctor as PDF
router.post('/export/data', exportPrescriptions);

// generate the pdf
router.get('/pdf/:id', validateRequest, generateThePdf);

// Individual prescription routes (avec validation pour la sécurité)
router.get('/:id', getPrescriptionValidator, validateRequest, getPrescriptionById);

export default router;