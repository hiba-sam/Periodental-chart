import { Router } from 'express';
import { getMe, updateMe, changeLanguage } from '../controllers/user.controller';
import { updateMeValidator, validateRequest } from '../middlewares/validation';

const router = Router();

router.route('/')
        .get(getMe)
        .put(validateRequest, updateMe);

router.put('/language', validateRequest, changeLanguage);

export default router; 