import express from 'express';
import {
    createType,
    getMyTypes,
    getTypeById,
    updateType,
    deleteType,
    createFromPrescription,
} from '../controllers/prescriptionType.controller';

const router = express.Router();

// List / Create
router.route('/')
    .get(getMyTypes)
    .post(createType);

// Save as model from an existing prescription (before /:id to avoid conflict)
router.post('/from-prescription/:prescriptionId', createFromPrescription);

// Single type (get / update / delete)
router.route('/:id')
    .get(getTypeById)
    .put(updateType)
    .delete(deleteType);

export default router;
