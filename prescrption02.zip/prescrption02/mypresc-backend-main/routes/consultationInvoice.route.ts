import { Router } from 'express';
import { create, getByPatientId, updateStatus, addPayment, distributePayment, deleteInvoice, getTodayInvoices, getStatistics, getUnpaidByPatient } from '../controllers/consultationInvoice.controller';
import { requireAuth } from '../middlewares/auth';

const router = Router();

// Base path: /consultation-invoice

// Create invoice (doctor ID from token, patient ID in body)
router.post('/', requireAuth, create);

// Get today's invoices (for assistant/doctor)
router.get('/today', requireAuth, getTodayInvoices);

// Get unpaid invoices grouped by patient (with optional search)
router.get('/unpaid-by-patient', requireAuth, getUnpaidByPatient);

// Get invoices for a patient
router.get('/patient/:patientId', requireAuth, getByPatientId);

// Update invoice status
router.patch('/:id/status', requireAuth, updateStatus);

// Add payment to invoice (partial payments)
router.post('/:id/payment', requireAuth, addPayment);

// Distribute payment across multiple invoices for a patient
router.post('/distribute-payment', requireAuth, distributePayment);

// Delete invoice
router.delete('/:id', requireAuth, deleteInvoice);

// Statistics route
router.get('/statistics', getStatistics);

export default router;
