import express from "express";
import { getDashboardStats } from "../controllers/dashboard.controller";
import { requireDoctorFromAuth } from "../middlewares/doctor";

const router = express.Router();

// GET /dashboard/stats - Get all dashboard data in one request
router.get("/stats", requireDoctorFromAuth, getDashboardStats);

export default router;
