import express from 'express';
import paymentController from '../controllers/payment.controller';
import { requireDoctorAuth } from '../middlewares/auth';
import { standardAuthLimiter } from '../middlewares/protections';
import { validateRequest } from '../middlewares/validation';

const router = express.Router();

// ============================================
// PAYMENT ROUTES
// ============================================

// POST /api/payment/subscribe - Create a new subscription checkout
// Requires authentication (doctor only)
// Rate limited to 10 attempts per 15 minutes
router.post(
    '/subscribe',
    standardAuthLimiter,
    requireDoctorAuth,
    validateRequest,
    paymentController.Subscription
);

// NOTE: /payment/webhook is registered directly in index.ts (line 110)
// before express.json() middleware to preserve raw body for signature verification

export default router;
