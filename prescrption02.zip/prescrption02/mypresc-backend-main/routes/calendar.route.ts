import express from "express";
import {
    createCalendarEvent,
    updateCalendarEvent,
    deleteCalendarEvent,
    getCalendarEvent,
    getAllCalendarEvents,
    getCalendarEventsByDate,
    getCalendarEventsByDateRange,
    getAppointmentLinkedEvents,
    getStandaloneEvents
} from "../controllers/calendar.controller";
import {
    updateCalendarEventValidator,
    paginationValidator,
    validateRequest
} from "../middlewares/validation";
import { requireDoctorFromQuery, requireDoctor } from "../middlewares/doctor";

const router = express.Router();

// Create and list calendar events
router.route("/")
    .post(requireDoctor, validateRequest, createCalendarEvent)
    .get(requireDoctorFromQuery, paginationValidator, validateRequest, getAllCalendarEvents);

// Get calendar events by date
router.get('/date',
    requireDoctorFromQuery,
    paginationValidator,
    validateRequest,
    getCalendarEventsByDate
);

// Get calendar events by date range
router.get('/date-range',
    requireDoctorFromQuery,
    paginationValidator,
    validateRequest,
    getCalendarEventsByDateRange
);

// Get only appointment-linked events
router.get('/appointment-linked',
    requireDoctorFromQuery,
    paginationValidator,
    validateRequest,
    getAppointmentLinkedEvents
);

// Get only standalone events
router.get('/standalone',
    requireDoctorFromQuery,
    paginationValidator,
    validateRequest,
    getStandaloneEvents
);

// Get, update, and delete a specific calendar event
router.route("/:id")
    .get(requireDoctorFromQuery, validateRequest, getCalendarEvent)
    .put(requireDoctor, updateCalendarEventValidator, validateRequest, updateCalendarEvent)
    .delete(requireDoctorFromQuery, validateRequest, deleteCalendarEvent);

export default router;
