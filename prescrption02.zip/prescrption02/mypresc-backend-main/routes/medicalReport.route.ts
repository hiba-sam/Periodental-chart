import express from "express";
import {
    createMedicalReport,
    getMedicalReportById,
    getMedicalReportsByPatient,
    updateMedicalReport,
    deleteMedicalReport,
    getMyMedicalReports,
    generateMedicalReportPdfController
} from "../controllers/medicalReport.controller";
import { requireDoctorAuth } from "../middlewares/auth";

const router = express.Router();

// ============================================
// MEDICAL REPORTS ROUTES
// ============================================

// IMPORTANT: Routes spécifiques AVANT les routes génériques (:id)

// Get all medical reports created by the authenticated doctor
router.get("/my/reports", requireDoctorAuth, getMyMedicalReports);

// Get all medical reports for a specific patient
router.get("/patient/:patientId", requireDoctorAuth, getMedicalReportsByPatient);

// Create a new medical report (Doctor only)
router.post("/", requireDoctorAuth, createMedicalReport);

// Generate PDF for a medical report (AVANT /:id pour éviter les conflits)
router.get("/:id/pdf", requireDoctorAuth, generateMedicalReportPdfController);

// Get a specific medical report by ID
router.get("/:id", requireDoctorAuth, getMedicalReportById);

// Update a medical report (Author only)
router.put("/:id", requireDoctorAuth, updateMedicalReport);

// Delete a medical report (Author only)
router.delete("/:id", requireDoctorAuth, deleteMedicalReport);

export default router;
