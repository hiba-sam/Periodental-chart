import { Router } from 'express';
import { 
    getCharts, 
    createChart, 
    updateChart, 
    getChartById,
    getSites, 
    batchSites 
} from '../controllers/perio.controller';

const router = Router();

router.get('/charts', getCharts);
router.post('/charts', createChart);
router.get('/charts/:id', getChartById);
router.put('/charts/:id', updateChart);
router.get('/sites', getSites);
router.post('/sites/batch', batchSites);

export default router;
