import express from 'express';
import {
    createPatient,
    updatePatient,
    getPatient,
    getAllPatients,
    searchPatients,
    deletePatient,
    getDoctorPatients,
    exportPatients,
    checkPrimaryCareStatus,
    assignPrimaryCarePhysician,
    getTransitionHistory,
    toggleShareWithPrimaryCare,
    getPrimaryCareInfo,
    getPatientHistory,
    getPatientVisitCount,
    getPatientMedications
} from "../controllers/patient.controller";
import { getPatientStatistics, getPatientStatisticsSummary, getPatientGrowthRate } from '../controllers/patientStatistics.controller';
import { createPatientValidator, searchValidator, paginationValidator, validateRequest, doctorUserIdQueryValidator } from '../middlewares/validation';
import { param } from 'express-validator';
import { requireDoctorFromQuery } from '../middlewares/doctor';

const router = express.Router();

// Create and list patients
router.route('/')
        .post(validateRequest, createPatient)
        .get(paginationValidator, validateRequest, getAllPatients);

// Search patients
router.get('/search', searchValidator, validateRequest, searchPatients);

// Get patients related to doctor (have prescriptions)
router.get('/related', validateRequest, getDoctorPatients);

// Export all patients for authenticated doctor as CSV
router.get('/export/data', exportPatients);

// Patient statistics endpoints
router.get('/stat', validateRequest, requireDoctorFromQuery, getPatientStatistics);

// Primary care physician management
router.get('/:patientId/primary-care/status', validateRequest, checkPrimaryCareStatus);
router.post('/:patientId/primary-care/assign', validateRequest, assignPrimaryCarePhysician);
router.get('/:patientId/primary-care/history', validateRequest, getTransitionHistory);

// Share with primary care physician
router.post('/:patientId/share-primary-care', validateRequest, toggleShareWithPrimaryCare);
router.get('/:patientId/primary-care-info', validateRequest, getPrimaryCareInfo);

// Patient interaction history - MUST be before /:id route
router.get('/:patientId/history', validateRequest, getPatientHistory);

// Visit count for a patient by the doctor (works for both doctor and assistant)
router.get('/:id/visit-count', validateRequest, getPatientVisitCount);

// Patient medications aggregated from prescriptions
router.get('/:patientId/medications', validateRequest, getPatientMedications);

// Get, update, delete specific patient - KEEP THIS LAST
router.route('/:id')
        .get(validateRequest, getPatient)
        .put(validateRequest, updatePatient)
        .delete(validateRequest, deletePatient);

export default router;