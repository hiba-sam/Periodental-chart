import express from 'express';
import multer from 'multer';
import fs from 'fs';
import { requireDoctorAuth } from '../middlewares/auth';
import {
    generateMedicalReportFromAudio,
    generateCardiologyReportFromAudio,
    getQuotaStatus,
    getUsageStats
} from '../controllers/aiMedicalReport.controller';

const router = express.Router();

// Créer le répertoire temporaire de manière compatible Bun/Node
const AUDIO_TEMP_DIR = 'temp/audio';
try { fs.mkdirSync(AUDIO_TEMP_DIR, { recursive: true }); } catch (e: any) { if (e.code !== 'EEXIST') throw e; }

/**
 * Configuration Multer pour upload audio temporaire
 * 
 * Sécurité:
 * - Stockage temporaire uniquement
 * - Limite de taille: 20 MB
 * - Formats autorisés: webm, m4a, wav, mp3, mp4, ogg
 * - Fichiers supprimés immédiatement après transcription
 */
const upload = multer({
    // destination en fonction (pas string) pour éviter le bug Bun mkdirSync EEXIST
    storage: multer.diskStorage({ destination: (_req: any, _file: any, cb: any) => cb(null, AUDIO_TEMP_DIR) }),
    limits: {
        fileSize: 20 * 1024 * 1024, // 20 MB max
        files: 1 // Un seul fichier à la fois
    },
    fileFilter: (req, file, cb) => {
        const allowedMimes = [
            'audio/webm',
            'audio/m4a',
            'audio/wav',
            'audio/mpeg',
            'audio/mp3',
            'audio/mp4',
            'audio/ogg',
            'audio/x-m4a'
        ];

        const allowedExtensions = ['webm', 'm4a', 'wav', 'mp3', 'mp4', 'ogg'];
        const ext = file.originalname.toLowerCase().split('.').pop();

        if (allowedMimes.includes(file.mimetype) && ext && allowedExtensions.includes(ext)) {
            cb(null, true);
        } else {
            cb(new Error(`Invalid file type. Allowed: ${allowedExtensions.join(', ')}`));
        }
    }
});

/**
 * POST /api/ai/medical-report
 * Générer un compte rendu médical structuré depuis une dictée vocale
 * 
 * Body (multipart/form-data):
 * - audio: fichier audio (webm, m4a, wav, mp3)
 * 
 * Headers:
 * - Authorization: session cookie (doctor auth required)
 * 
 * Response 200:
 * {
 *   success: true,
 *   data: {
 *     transcription: string,
 *     medical_report: {
 *       titre: string,
 *       date_consultation: string,
 *       motif_consultation: string,
 *       anamnese: string,
 *       examen_clinique: string,
 *       diagnostic: string,
 *       traitement_prescrit: string,
 *       recommandations: string,
 *       suivi_propose: string
 *     },
 *     quota: {
 *       remaining: number,
 *       max: number,
 *       period: string
 *     }
 *   }
 * }
 * 
 * Errors:
 * - 401: Unauthorized (not logged in)
 * - 403: Quota exceeded
 * - 413: File too large
 * - 415: Unsupported media type
 * - 422: Transcription empty
 * - 502: OpenAI service error
 */
router.post(
    '/',
    requireDoctorAuth,
    upload.single('audio'),
    generateMedicalReportFromAudio
);

/**
 * POST /api/ai/medical-report/cardiology
 * Générer un rapport cardiologique structuré depuis une dictée vocale
 * Retourne les champs CardiologyFormData mappés + additional_info
 */
router.post(
    '/cardiology',
    requireDoctorAuth,
    upload.single('audio'),
    generateCardiologyReportFromAudio
);

/**
 * GET /api/ai/medical-report/quota
 * Obtenir le statut du quota actuel
 * 
 * Response 200:
 * {
 *   success: true,
 *   data: {
 *     used: number,
 *     max: number,
 *     remaining: number,
 *     period: string,
 *     percentage_used: number
 *   }
 * }
 */
router.get(
    '/quota',
    requireDoctorAuth,
    getQuotaStatus
);

/**
 * GET /api/ai/medical-report/usage-stats
 * Obtenir l'historique d'utilisation
 * 
 * Query params:
 * - months: number (default: 6)
 * 
 * Response 200:
 * {
 *   success: true,
 *   data: {
 *     history: Array<{
 *       period: string,
 *       used_count: number,
 *       max_quota: number
 *     }>,
 *     total_used: number
 *   }
 * }
 */
router.get(
    '/usage-stats',
    requireDoctorAuth,
    getUsageStats
);

export default router;
