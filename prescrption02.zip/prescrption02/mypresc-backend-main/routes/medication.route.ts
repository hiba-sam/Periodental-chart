import express from 'express';
import {
  getMedicationById,
  searchMedications,
  getAllMedications,
} from '../controllers/medication.controller';
import { searchValidator, paginationValidator, validateRequest } from '../middlewares/validation';
import { param } from 'express-validator';

const router = express.Router();

// Main medication routes
router.route('/')
  .get(paginationValidator, validateRequest, getAllMedications);

// Search medications
router.get('/search', searchValidator, validateRequest, searchMedications);

// Individual medication routes
router.route('/:id')
  .get(param('id').isInt({ min: 1 }), validateRequest, getMedicationById);

export default router;