import { Router } from 'express';
import {
    getAllNotifications,
    getNotificationById,
    createNotification,
    updateNotification,
    deleteNotification,
    markAsSeen,
    markAsUnseen,
    markAllAsSeen,
    getNotificationStats,
    searchNotifications
} from '../controllers/notification.controller';

const router = Router();

// GET /notification - Get all notifications (with optional filters)
router.get('/', getAllNotifications);

// GET /notification/stats - Get notification statistics
router.get('/stats', getNotificationStats);

// GET /notification/search - Search notifications
router.get('/search', searchNotifications);


// DELETE /notification/:id - Delete notification
router.delete('/:id', deleteNotification);

// PATCH /notification/:id/seen - Mark notification as seen
router.patch('/:id/seen', markAsSeen);

// PATCH /notification/:id/unseen - Mark notification as unseen
router.patch('/:id/unseen', markAsUnseen);

// PATCH /notification/mark-all-seen - Mark all notifications as seen
router.patch('/mark-all-seen', markAllAsSeen);

// GET /notification/:id - Get notification by ID
router.get('/:id', getNotificationById);

// POST /notification - Create new notification
router.post('/', createNotification);

// PUT /notification/:id - Update notification
router.put('/:id', updateNotification);

export default router;
