import { Router } from "express";
import {
  createOpticalCorrection,
  getOpticalCorrectionById,
  getOpticalCorrectionsByPatient,
  generateThePdf,
} from "../controllers/opticalCorrection.controller";

const router = Router();

// Route to create a new optical correction
router.post("/", createOpticalCorrection);

// Route to get all optical corrections for a specific patient
router.get("/patient/:patientId", getOpticalCorrectionsByPatient);

// Route to get a specific optical correction by ID
router.get("/:id", getOpticalCorrectionById);

// Route to generate PDF for an optical correction by ID
router.get("/:id/pdf", generateThePdf);

export default router;
