import express from 'express';
import { requireAuth } from '../middlewares/auth.js';
import {
    xmlUpload,
    uploadOphthoReport,
    getPatientOphthoReports,
    getOphthoReport,
    updateOphthoReport,
    deleteOphthoReport,
    generateOphthoReportPdfController,
} from '../controllers/ophthoReport.controller.js';

const router = express.Router();

// ── Patient-scoped routes ─────────────────────────────────────────────────────

// Upload XML → parse → store
router.post('/patients/:patientId/ophtho-reports/upload', requireAuth, xmlUpload.single('file'), uploadOphthoReport);

// List all reports for a patient
router.get('/patients/:patientId/ophtho-reports', requireAuth, getPatientOphthoReports);

// ── Report-scoped routes ──────────────────────────────────────────────────────

// PDF generation BEFORE /:id to avoid route conflicts
router.get('/ophtho-reports/:id/pdf', requireAuth, generateOphthoReportPdfController);

// Single report
router.get('/ophtho-reports/:id', requireAuth, getOphthoReport);

// Update annotations (clinical_notes, diagnosis)
router.patch('/ophtho-reports/:id', requireAuth, updateOphthoReport);

// Delete
router.delete('/ophtho-reports/:id', requireAuth, deleteOphthoReport);

export default router;
