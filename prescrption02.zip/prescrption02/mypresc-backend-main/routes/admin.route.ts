import express from "express";
import {
    adminLogin,
    adminLogout,
    checkAdminSession,
    getPendingRegistrations,
    getRegistrationDetails,
    approveRegistration,
    rejectRegistration,
    getAuditLogs,
    getAuditStats
} from "../controllers/admin.controller";
import { requireAdmin, requireSuperAdmin } from "../middlewares/adminAuth";
import { standardAuthLimiter } from "../middlewares/protections";

const router = express.Router();

// ============================================
// ADMIN AUTHENTICATION ROUTES
// ============================================

// Login (public)
router.post("/login", standardAuthLimiter, adminLogin);

// Logout (requires admin auth)
router.post("/logout", requireAdmin, adminLogout);

// Check session (requires admin auth)
router.get("/session", requireAdmin, checkAdminSession);

// ============================================
// REGISTRATION MANAGEMENT ROUTES
// ============================================

// Get pending registrations
router.get("/registrations/pending", requireAdmin, getPendingRegistrations);

// Get registration details by ID
router.get("/registrations/:id", requireAdmin, getRegistrationDetails);

// Approve registration
router.post("/registrations/:id/approve", requireAdmin, approveRegistration);

// Reject registration
router.post("/registrations/:id/reject", requireAdmin, rejectRegistration);

// ============================================
// AUDIT LOGS ROUTES
// ============================================

// Get audit logs (requires admin)
router.get("/audit-logs", requireAdmin, getAuditLogs);

// Get audit statistics (requires super admin)
router.get("/audit-logs/stats", requireSuperAdmin, getAuditStats);

// ============================================
// ADMIN MANAGEMENT ROUTES (Future)
// ============================================

// TODO: Add routes for admin CRUD operations
// - GET /admins - List all admins
// - POST /admins - Create new admin
// - PUT /admins/:id - Update admin
// - DELETE /admins/:id - Delete admin

export default router;
