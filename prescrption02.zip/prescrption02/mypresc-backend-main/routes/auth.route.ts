import express from "express";
import { checkUserLogging, completeRegistration, login, logout, register, checkAssistantInvitation, assistantRegistration, resetPassword, changePassword } from "../controllers/auth.controller";
import { criticalAuthLimiter, sessionCheckLimiter, standardAuthLimiter } from "../middlewares/protections";
import { validateRequest } from "../middlewares/validation";
import { uploadRegistrationFiles, handleMulterError } from "../config/multer";
import '../strategies/localStrategy'

const router = express.Router();

// ============================================
// AUTHENTICATION ROUTES WITH RATE LIMITING & VALIDATION
// ============================================

// CRITICAL: Login and registration (5 attempts / 15 min)
// Protects against brute force, credential stuffing, and injection attacks
// Note: multer middleware handles file uploads and validation
router.post("/register", criticalAuthLimiter, uploadRegistrationFiles, register);
router.post("/login", criticalAuthLimiter, validateRequest, login);

// SESSION CHECK: Frequent navigation (30 attempts / 15 min)
// Allows legitimate medical workflow (1-2 patients per 15min)
router.get('/', sessionCheckLimiter, checkUserLogging);

// STANDARD: Logout and token validation (10 attempts / 15 min)
router.post("/logout", standardAuthLimiter, logout);
router.get("/complete-registration/:token", standardAuthLimiter, completeRegistration);

// ASSISTANT INVITATION: Check and register assistant
router.get("/assistant/check-invitation/:token", standardAuthLimiter, checkAssistantInvitation);
router.post("/assistant/register", criticalAuthLimiter, validateRequest, assistantRegistration);

// PASSWORD RESET: Request password reset (5 attempts / 15 min)
// Protects against email enumeration and spam
router.post("/reset-password", criticalAuthLimiter, validateRequest, resetPassword);

// PASSWORD CHANGE: Update password with reset token (10 attempts / 15 min)
// Allows legitimate password updates while preventing brute force
router.post("/change-password", standardAuthLimiter, validateRequest, changePassword);

// Error handler for multer (must be after routes)
router.use(handleMulterError);

export default router;