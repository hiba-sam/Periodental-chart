import express from "express";
import {
    transcribeAudio,
    checkWhisperStatus,
    uploadAudio
} from "../controllers/transcription.controller";
import { requireDoctorAuth } from "../middlewares/auth";

const router = express.Router();

// ============================================
// TRANSCRIPTION ROUTES (Whisper)
// ============================================

// Vérifier le statut de l'API Whisper
router.get("/status", requireDoctorAuth, checkWhisperStatus);

// Transcrire un fichier audio uploadé
router.post("/audio", requireDoctorAuth, uploadAudio, transcribeAudio);

export default router;
