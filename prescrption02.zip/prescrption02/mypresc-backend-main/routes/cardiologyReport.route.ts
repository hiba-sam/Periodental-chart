import express from 'express';
import { requireAuth } from '../middlewares/auth.js';
import {
    getPatientCardiologyReports,
    createCardiologyReport,
    getCardiologyReport,
    updateCardiologyReport,
    deleteCardiologyReport,
    generateCardiologyReportPdfController
} from '../controllers/cardiologyReport.controller.js';

const router = express.Router();

// ============================================
// PATIENT CARDIOLOGY REPORTS
// ============================================

// Get all cardiology reports for a patient
router.get('/patients/:patientId/cardiology-reports', requireAuth, getPatientCardiologyReports);

// Create a cardiology report for a patient
router.post('/patients/:patientId/cardiology-reports', requireAuth, createCardiologyReport);

// ============================================
// CARDIOLOGY REPORT CRUD
// ============================================

// Generate PDF for a cardiology report (BEFORE /:id to avoid conflicts)
router.get('/cardiology-reports/:id/pdf', requireAuth, generateCardiologyReportPdfController);

// Get cardiology report by ID
router.get('/cardiology-reports/:id', requireAuth, getCardiologyReport);

// Update cardiology report
router.patch('/cardiology-reports/:id', requireAuth, updateCardiologyReport);

// Delete cardiology report
router.delete('/cardiology-reports/:id', requireAuth, deleteCardiologyReport);

export default router;
