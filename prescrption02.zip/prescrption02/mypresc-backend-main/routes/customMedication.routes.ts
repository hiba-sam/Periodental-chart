import { Router } from 'express';
import { 
    createCustomMedication, 
    searchCustomMedications,
    getPendingCustomMedications,
    updateCustomMedicationStatus,
    getMyCustomMedications
} from '../controllers/customMedication.controller';
import { requireAuth } from '../middlewares/auth';

const router = Router();

// All routes require authentication
router.use(requireAuth);

// Create custom medication
router.post('/', createCustomMedication);

// Search custom medications
router.get('/search', searchCustomMedications);

// Get my custom medications
router.get('/my', getMyCustomMedications);

// Admin routes
router.get('/pending', getPendingCustomMedications);
router.put('/:id/status', updateCustomMedicationStatus);

export default router;
