import express from 'express';
import { 
    createShare, 
    getSharesByPatient, 
    getReceivedShares, 
    revokeShare, 
    deleteShare,
    searchDoctorsForShare,
    getShareByToken,
    getSharedPrescriptions,
    getSharedMedicalReports,
    getSharedDentalActs
} from '../controllers/medicalShare.controller';
import { requireAuth } from '../middlewares/auth';

const router = express.Router();

// Toutes les routes nécessitent une authentification
router.use(requireAuth);

// Rechercher des médecins pour le partage
router.get('/search-doctors', searchDoctorsForShare);

// Créer un partage
router.post('/', createShare);

// Lister les partages reçus par le médecin connecté
router.get('/received', getReceivedShares);

// Lister les partages d'un patient
router.get('/patient/:patientId', getSharesByPatient);

// Révoquer un partage
router.put('/:id/revoke', revokeShare);

// Supprimer un partage
router.delete('/:id', deleteShare);

// Accéder à un partage via token unique (lien sécurisé)
router.get('/access/:token', getShareByToken);

// Récupérer les prescriptions partagées via token
router.get('/access/:token/prescriptions', getSharedPrescriptions);

// Récupérer les comptes rendus partagés via token
router.get('/access/:token/reports', getSharedMedicalReports);

// Récupérer les actes dentaires partagés via token
router.get('/access/:token/dental-acts', getSharedDentalActs);

export default router;
