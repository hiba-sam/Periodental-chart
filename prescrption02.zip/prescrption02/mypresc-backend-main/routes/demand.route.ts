import express from "express";
import { demandRegistration, getAllDemands, getDemandById, deleteDemand } from "../controllers/demand.controller";
import { criticalAuthLimiter, standardAuthLimiter } from "../middlewares/protections";
import { requireAuth } from "../middlewares/auth";

const router = express.Router();

// ============================================
// DEMAND ROUTES WITH RATE LIMITING
// ============================================

// PUBLIC ROUTE: Demand registration (with rate limiting to prevent abuse)
// 5 attempts per 15 minutes to prevent spam
router.post("/register", criticalAuthLimiter, demandRegistration);

// PROTECTED ROUTES: Require authentication (can be further restricted to admin only)
// Get all demands
router.get("/", requireAuth, getAllDemands);

// Get demand by ID
router.get("/:id", requireAuth, standardAuthLimiter, getDemandById);

// Delete demand
router.delete("/:id", requireAuth, standardAuthLimiter, deleteDemand);

export default router;
