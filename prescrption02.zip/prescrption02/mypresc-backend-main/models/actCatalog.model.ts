import pool from '../db.js';

// Remove accents from string for search
function normalizeSearch(str: string): string {
    return str
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase();
}

export interface ActCatalog {
    id: number;
    code_ccam: string;
    code_short: string;
    label: string;
    chapter_code: string | null;
    chapter_label: string | null;
    parent_code: string | null;
    parent_label: string | null;
    topography: string | null;
    topography_label: string | null;
    action: string | null;
    action_label: string | null;
    mode_access: string | null;
    mode_access_label: string | null;
    family_code: string | null;
    family_label: string | null;
    source: string;
    is_dental: boolean;
    created_at: Date;
    updated_at: Date;
}

export interface ActCatalogSearchParams {
    q?: string;
    chapter?: string;
    family?: string;
    isDental?: boolean;
    page?: number;
    limit?: number;
}

export class ActCatalogModel {
    /**
     * Search acts in catalog with text search and filters
     */
    static async search(params: ActCatalogSearchParams): Promise<{ acts: ActCatalog[]; total: number }> {
        const { q, chapter, family, isDental, page = 1, limit = 20 } = params;
        const offset = (page - 1) * limit;
        
        let whereConditions: string[] = [];
        let queryParams: any[] = [];
        let paramIndex = 1;

        // Text search on label and code (accent-insensitive)
        if (q && q.trim()) {
            const normalizedQuery = normalizeSearch(q.trim());
            whereConditions.push(`(
                LOWER(TRANSLATE(label, 'àâäéèêëïîôùûüç', 'aaaeeeeiioouuc')) LIKE $${paramIndex} 
                OR LOWER(code_ccam) LIKE $${paramIndex} 
                OR LOWER(code_short) LIKE $${paramIndex}
            )`);
            queryParams.push(`%${normalizedQuery}%`);
            paramIndex++;
        }

        // Filter by chapter
        if (chapter) {
            whereConditions.push(`chapter_code = $${paramIndex}`);
            queryParams.push(chapter);
            paramIndex++;
        }

        // Filter by family
        if (family) {
            whereConditions.push(`family_code = $${paramIndex}`);
            queryParams.push(family);
            paramIndex++;
        }

        // Filter dental acts only
        if (isDental !== undefined) {
            whereConditions.push(`is_dental = $${paramIndex}`);
            queryParams.push(isDental);
            paramIndex++;
        }

        const whereClause = whereConditions.length > 0 
            ? `WHERE ${whereConditions.join(' AND ')}` 
            : '';

        // Count total
        const countQuery = `SELECT COUNT(*) FROM act_catalog ${whereClause}`;
        const countResult = await pool.query(countQuery, queryParams);
        const total = parseInt(countResult.rows[0].count);

        // Get paginated results
        const dataQuery = `
            SELECT * FROM act_catalog 
            ${whereClause}
            ORDER BY label ASC
            LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
        `;
        queryParams.push(limit, offset);
        
        const result = await pool.query(dataQuery, queryParams);

        return {
            acts: result.rows,
            total
        };
    }

    /**
     * Get act by ID
     */
    static async findById(id: number): Promise<ActCatalog | null> {
        const result = await pool.query(
            'SELECT * FROM act_catalog WHERE id = $1',
            [id]
        );
        return result.rows[0] || null;
    }

    /**
     * Get act by CCAM code
     */
    static async findByCode(code: string): Promise<ActCatalog | null> {
        const result = await pool.query(
            'SELECT * FROM act_catalog WHERE code_ccam = $1 OR code_short = $1',
            [code]
        );
        return result.rows[0] || null;
    }

    /**
     * Get distinct chapters for filtering
     */
    static async getChapters(): Promise<{ code: string; label: string }[]> {
        const result = await pool.query(`
            SELECT DISTINCT chapter_code as code, chapter_label as label 
            FROM act_catalog 
            WHERE chapter_code IS NOT NULL 
            ORDER BY chapter_label
        `);
        return result.rows;
    }

    /**
     * Get distinct families for filtering
     */
    static async getFamilies(): Promise<{ code: string; label: string }[]> {
        const result = await pool.query(`
            SELECT DISTINCT family_code as code, family_label as label 
            FROM act_catalog 
            WHERE family_code IS NOT NULL 
            ORDER BY family_label
        `);
        return result.rows;
    }

    /**
     * Mark acts as dental by code patterns or chapter
     */
    static async markDentalActs(patterns: string[]): Promise<number> {
        // Build OR conditions for patterns
        const conditions = patterns.map((_, i) => `code_ccam LIKE $${i + 1}`).join(' OR ');
        const query = `
            UPDATE act_catalog 
            SET is_dental = true, updated_at = CURRENT_TIMESTAMP
            WHERE ${conditions}
        `;
        const result = await pool.query(query, patterns.map(p => `${p}%`));
        return result.rowCount || 0;
    }
}
