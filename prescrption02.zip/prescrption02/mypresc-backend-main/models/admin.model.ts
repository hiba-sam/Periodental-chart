import pool from "../db";

// ============================================
// TYPES & INTERFACES
// ============================================

export interface Admin {
    id: number;
    name: string;
    email: string;
    password: string;
    role: 'admin' | 'super_admin';
    is_active: boolean;
    phone_number?: string;
    created_at: Date;
    updated_at: Date;
    last_login?: Date;
    created_by?: number;
}

export interface CreateAdminData {
    name: string;
    email: string;
    password: string;
    role?: 'admin' | 'super_admin';
    phone_number?: string;
    created_by?: number;
}

export interface UpdateAdminData {
    name?: string;
    email?: string;
    password?: string;
    role?: 'admin' | 'super_admin';
    is_active?: boolean;
    phone_number?: string;
    last_login?: Date;
}

// ============================================
// ADMIN MODEL
// ============================================

export class AdminModel {
    
    /**
     * Find admin by ID
     */
    static async findById(id: number): Promise<Admin | null> {
        const query = `
            SELECT id, name, email, password, role, is_active, phone_number, 
                   created_at, updated_at, last_login, created_by
            FROM admins 
            WHERE id = $1
        `;
        
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Find admin by email
     */
    static async findByEmail(email: string): Promise<Admin | null> {
        const query = `
            SELECT id, name, email, password, role, is_active, phone_number, 
                   created_at, updated_at, last_login, created_by
            FROM admins 
            WHERE email = $1
        `;
        
        const result = await pool.query(query, [email]);
        return result.rows[0] || null;
    }

    /**
     * Create new admin
     */
    static async create(data: CreateAdminData): Promise<Admin> {
        const query = `
            INSERT INTO admins (name, email, password, role, phone_number, created_by)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, name, email, role, is_active, phone_number, 
                      created_at, updated_at, last_login, created_by
        `;
        
        const values = [
            data.name,
            data.email,
            data.password,
            data.role || 'admin',
            data.phone_number || null,
            data.created_by || null
        ];
        
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    /**
     * Update admin
     */
    static async update(id: number, data: UpdateAdminData): Promise<Admin | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let paramCount = 1;

        if (data.name !== undefined) {
            fields.push(`name = $${paramCount}`);
            values.push(data.name);
            paramCount++;
        }
        if (data.email !== undefined) {
            fields.push(`email = $${paramCount}`);
            values.push(data.email);
            paramCount++;
        }
        if (data.password !== undefined) {
            fields.push(`password = $${paramCount}`);
            values.push(data.password);
            paramCount++;
        }
        if (data.role !== undefined) {
            fields.push(`role = $${paramCount}`);
            values.push(data.role);
            paramCount++;
        }
        if (data.is_active !== undefined) {
            fields.push(`is_active = $${paramCount}`);
            values.push(data.is_active);
            paramCount++;
        }
        if (data.phone_number !== undefined) {
            fields.push(`phone_number = $${paramCount}`);
            values.push(data.phone_number);
            paramCount++;
        }
        if (data.last_login !== undefined) {
            fields.push(`last_login = $${paramCount}`);
            values.push(data.last_login);
            paramCount++;
        }

        if (fields.length === 0) {
            return this.findById(id);
        }

        values.push(id);
        const query = `
            UPDATE admins 
            SET ${fields.join(', ')}
            WHERE id = $${paramCount}
            RETURNING id, name, email, role, is_active, phone_number, 
                      created_at, updated_at, last_login, created_by
        `;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    /**
     * Get all admins (paginated)
     */
    static async getAll(limit: number = 50, offset: number = 0): Promise<Admin[]> {
        const query = `
            SELECT id, name, email, role, is_active, phone_number, 
                   created_at, updated_at, last_login, created_by
            FROM admins 
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        `;
        
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    /**
     * Get active admins count
     */
    static async getActiveCount(): Promise<number> {
        const query = `SELECT COUNT(*) as count FROM admins WHERE is_active = true`;
        const result = await pool.query(query);
        return parseInt(result.rows[0].count);
    }

    /**
     * Delete admin (soft delete - set inactive)
     */
    static async delete(id: number): Promise<boolean> {
        const query = `
            UPDATE admins 
            SET is_active = false 
            WHERE id = $1
            RETURNING id
        `;
        
        const result = await pool.query(query, [id]);
        return result.rows.length > 0;
    }

    /**
     * Hard delete admin (use with caution)
     */
    static async hardDelete(id: number): Promise<boolean> {
        const query = `DELETE FROM admins WHERE id = $1 RETURNING id`;
        const result = await pool.query(query, [id]);
        return result.rows.length > 0;
    }

    /**
     * Update last login timestamp
     */
    static async updateLastLogin(id: number): Promise<void> {
        const query = `UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE id = $1`;
        await pool.query(query, [id]);
    }
}
