import pool from '../db';
import { createHash } from 'crypto';

export interface QuotaRecord {
    id: number;
    doctor_user_id: number;
    period: string;
    used_count: number;
    max_quota: number;
    created_at: Date;
    updated_at: Date;
}

export interface LogRecord {
    request_id: string;
    doctor_user_id_hash: string;
    period: string;
    audio_duration_seconds?: number;
    audio_size_bytes?: number;
    transcription_duration_ms?: number;
    generation_duration_ms?: number;
    total_duration_ms?: number;
    status: 'success' | 'quota_exceeded' | 'error' | 'invalid_format' | 'timeout';
    error_code?: string;
}

export class AIMedicalReportQuotaModel {
    /**
     * Obtenir la période courante (YYYY-MM)
     */
    static getCurrentPeriod(): string {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        return `${year}-${month}`;
    }

    /**
     * Hash anonyme du doctor_user_id pour les logs
     */
    static hashDoctorId(doctorId: number): string {
        return createHash('sha256')
            .update(`${doctorId}_${process.env.SESSION_SECRET}`)
            .digest('hex');
    }

    /**
     * Vérifier et réserver un crédit (transaction atomique)
     * Retourne true si crédit disponible et réservé, false sinon
     */
    static async checkAndReserveQuota(doctorUserId: number): Promise<{
        success: boolean;
        remaining: number;
        period: string;
    }> {
        const client = await pool.connect();
        const period = this.getCurrentPeriod();
        const maxQuota = 30;

        try {
            await client.query('BEGIN');

            // Créer ou récupérer l'enregistrement de quota
            const upsertQuery = `
                INSERT INTO ai_medical_report_quota (doctor_user_id, period, used_count, max_quota)
                VALUES ($1, $2, 0, $3)
                ON CONFLICT (doctor_user_id, period)
                DO NOTHING
            `;
            
            await client.query(upsertQuery, [doctorUserId, period, maxQuota]);
            
            // Récupérer avec verrou exclusif
            const selectQuery = `
                SELECT * FROM ai_medical_report_quota
                WHERE doctor_user_id = $1 AND period = $2
                FOR UPDATE
            `;
            
            const { rows: [quota] } = await client.query<QuotaRecord>(
                selectQuery,
                [doctorUserId, period]
            );

            // Vérifier si quota disponible
            if (!quota || quota.used_count >= quota.max_quota) {
                await client.query('ROLLBACK');
                return {
                    success: false,
                    remaining: 0,
                    period
                };
            }

            // Réserver 1 crédit (incrémenter)
            const updateQuery = `
                UPDATE ai_medical_report_quota
                SET used_count = used_count + 1,
                    updated_at = CURRENT_TIMESTAMP
                WHERE doctor_user_id = $1 AND period = $2
                RETURNING *
            `;

            const { rows: [updated] } = await client.query<QuotaRecord>(
                updateQuery,
                [doctorUserId, period]
            );

            await client.query('COMMIT');

            if (!updated) {
                throw new Error('Failed to update quota');
            }

            return {
                success: true,
                remaining: updated.max_quota - updated.used_count,
                period
            };

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    /**
     * Annuler la réservation (en cas d'erreur avant génération)
     */
    static async cancelReservation(doctorUserId: number, period: string): Promise<void> {
        const query = `
            UPDATE ai_medical_report_quota
            SET used_count = GREATEST(0, used_count - 1),
                updated_at = CURRENT_TIMESTAMP
            WHERE doctor_user_id = $1 AND period = $2
        `;
        await pool.query(query, [doctorUserId, period]);
    }

    /**
     * Obtenir le quota restant pour un médecin
     */
    static async getRemainingQuota(doctorUserId: number): Promise<{
        used: number;
        max: number;
        remaining: number;
        period: string;
    }> {
        const period = this.getCurrentPeriod();
        const maxQuota = 30;

        const query = `
            SELECT used_count, max_quota
            FROM ai_medical_report_quota
            WHERE doctor_user_id = $1 AND period = $2
        `;

        const { rows } = await pool.query<QuotaRecord>(query, [doctorUserId, period]);

        if (rows.length === 0) {
            return {
                used: 0,
                max: maxQuota,
                remaining: maxQuota,
                period
            };
        }

        const quota = rows[0];
        return {
            used: quota.used_count,
            max: quota.max_quota,
            remaining: quota.max_quota - quota.used_count,
            period
        };
    }

    /**
     * Logger une opération (sans données médicales)
     */
    static async logOperation(logData: LogRecord): Promise<void> {
        const query = `
            INSERT INTO ai_medical_report_logs (
                request_id,
                doctor_user_id_hash,
                period,
                audio_duration_seconds,
                audio_size_bytes,
                transcription_duration_ms,
                generation_duration_ms,
                total_duration_ms,
                status,
                error_code
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `;

        await pool.query(query, [
            logData.request_id,
            logData.doctor_user_id_hash,
            logData.period,
            logData.audio_duration_seconds || null,
            logData.audio_size_bytes || null,
            logData.transcription_duration_ms || null,
            logData.generation_duration_ms || null,
            logData.total_duration_ms || null,
            logData.status,
            logData.error_code || null
        ]);
    }

    /**
     * Obtenir les statistiques d'usage par médecin
     */
    static async getDoctorUsageStats(doctorUserId: number, months: number = 6): Promise<Array<{
        period: string;
        used_count: number;
        max_quota: number;
    }>> {
        const query = `
            SELECT period, used_count, max_quota
            FROM ai_medical_report_quota
            WHERE doctor_user_id = $1
            ORDER BY period DESC
            LIMIT $2
        `;

        const { rows } = await pool.query(query, [doctorUserId, months]);
        return rows;
    }
}
