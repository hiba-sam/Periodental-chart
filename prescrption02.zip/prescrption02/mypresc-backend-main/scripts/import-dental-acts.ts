import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: false
});

// Liste complète des actes dentaires courants
const DENTAL_ACTS = [
    // ═══════════════════════════════════════════
    // SOINS CONSERVATEURS
    // ═══════════════════════════════════════════
    { code: 'SC01', label: 'Détartrage', category: 'Soins conservateurs', scope: 'MOUTH' },
    { code: 'SC02', label: 'Détartrage sous-gingival', category: 'Soins conservateurs', scope: 'TOOTH' },
    { code: 'SC03', label: 'Surfaçage radiculaire', category: 'Soins conservateurs', scope: 'TOOTH' },
    { code: 'SC04', label: 'Polissage dentaire', category: 'Soins conservateurs', scope: 'MOUTH' },
    { code: 'SC05', label: 'Application de fluor', category: 'Soins conservateurs', scope: 'MOUTH' },
    { code: 'SC06', label: 'Scellement de sillons (sealant)', category: 'Soins conservateurs', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // OBTURATIONS (SOINS CARIES)
    // ═══════════════════════════════════════════
    { code: 'OB01', label: 'Obturation composite 1 face', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB02', label: 'Obturation composite 2 faces', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB03', label: 'Obturation composite 3 faces', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB04', label: 'Obturation composite 4 faces et plus', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB05', label: 'Obturation amalgame 1 face', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB06', label: 'Obturation amalgame 2 faces', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB07', label: 'Obturation amalgame 3 faces et plus', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB08', label: 'Obturation provisoire', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB09', label: 'Reconstitution coronaire au composite', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB10', label: 'Inlay/Onlay céramique', category: 'Obturations', scope: 'TOOTH' },
    { code: 'OB11', label: 'Inlay/Onlay composite', category: 'Obturations', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // ENDODONTIE (TRAITEMENT CANALAIRE)
    // ═══════════════════════════════════════════
    { code: 'EN01', label: 'Pulpotomie', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN02', label: 'Pulpectomie', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN03', label: 'Traitement canalaire monoradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN04', label: 'Traitement canalaire biradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN05', label: 'Traitement canalaire multiradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN06', label: 'Retraitement canalaire monoradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN07', label: 'Retraitement canalaire biradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN08', label: 'Retraitement canalaire multiradiculé', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN09', label: 'Coiffage pulpaire direct', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN10', label: 'Coiffage pulpaire indirect', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN11', label: 'Drainage d\'abcès', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN12', label: 'Apexification', category: 'Endodontie', scope: 'TOOTH' },
    { code: 'EN13', label: 'Résection apicale', category: 'Endodontie', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // EXTRACTIONS
    // ═══════════════════════════════════════════
    { code: 'EX01', label: 'Extraction simple', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX02', label: 'Extraction complexe', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX03', label: 'Extraction dent de sagesse incluse', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX04', label: 'Extraction dent de sagesse semi-incluse', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX05', label: 'Extraction dent incluse (autre)', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX06', label: 'Extraction racine résiduelle', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX07', label: 'Extraction multiple (2-3 dents)', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX08', label: 'Extraction multiple (4+ dents)', category: 'Extractions', scope: 'MOUTH' },
    { code: 'EX09', label: 'Alvéolectomie', category: 'Extractions', scope: 'TOOTH' },
    { code: 'EX10', label: 'Germectomie', category: 'Extractions', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // PROTHÈSES FIXES
    // ═══════════════════════════════════════════
    { code: 'PF01', label: 'Couronne céramique', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF02', label: 'Couronne céramo-métallique', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF03', label: 'Couronne métallique', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF04', label: 'Couronne zircone', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF05', label: 'Couronne provisoire', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF06', label: 'Bridge 3 éléments', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF07', label: 'Bridge 4 éléments et plus', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF08', label: 'Facette céramique', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF09', label: 'Facette composite', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF10', label: 'Inlay-core', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF11', label: 'Inlay-core à clavette', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF12', label: 'Tenon fibré', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF13', label: 'Rescellement de couronne', category: 'Prothèses fixes', scope: 'TOOTH' },
    { code: 'PF14', label: 'Dépose de couronne', category: 'Prothèses fixes', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // PROTHÈSES AMOVIBLES
    // ═══════════════════════════════════════════
    { code: 'PA01', label: 'Prothèse amovible complète maxillaire', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA02', label: 'Prothèse amovible complète mandibulaire', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA03', label: 'Prothèse amovible partielle résine', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA04', label: 'Prothèse amovible partielle métallique (stellite)', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA05', label: 'Réparation prothèse amovible', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA06', label: 'Rebasage prothèse amovible', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA07', label: 'Adjonction dent sur prothèse', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA08', label: 'Adjonction crochet sur prothèse', category: 'Prothèses amovibles', scope: 'MOUTH' },
    { code: 'PA09', label: 'Prothèse immédiate', category: 'Prothèses amovibles', scope: 'MOUTH' },

    // ═══════════════════════════════════════════
    // IMPLANTOLOGIE
    // ═══════════════════════════════════════════
    { code: 'IM01', label: 'Pose implant dentaire', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM02', label: 'Pose pilier implantaire', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM03', label: 'Couronne sur implant', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM04', label: 'Bridge sur implants', category: 'Implantologie', scope: 'MOUTH' },
    { code: 'IM05', label: 'Prothèse complète sur implants (All-on-4)', category: 'Implantologie', scope: 'MOUTH' },
    { code: 'IM06', label: 'Greffe osseuse pré-implantaire', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM07', label: 'Sinus lift (élévation sinusienne)', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM08', label: 'Régénération osseuse guidée (ROG)', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM09', label: 'Extraction-implantation immédiate', category: 'Implantologie', scope: 'TOOTH' },
    { code: 'IM10', label: 'Dépose implant', category: 'Implantologie', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // PARODONTOLOGIE
    // ═══════════════════════════════════════════
    { code: 'PR01', label: 'Curetage parodontal', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR02', label: 'Surfaçage parodontal', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR03', label: 'Gingivectomie', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR04', label: 'Gingivoplastie', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR05', label: 'Lambeau d\'assainissement', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR06', label: 'Greffe gingivale', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR07', label: 'Greffe conjonctive', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR08', label: 'Régénération tissulaire guidée', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR09', label: 'Contention parodontale', category: 'Parodontologie', scope: 'TOOTH' },
    { code: 'PR10', label: 'Frénectomie labiale', category: 'Parodontologie', scope: 'MOUTH' },
    { code: 'PR11', label: 'Frénectomie linguale', category: 'Parodontologie', scope: 'MOUTH' },
    { code: 'PR12', label: 'Allongement coronaire', category: 'Parodontologie', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // ORTHODONTIE
    // ═══════════════════════════════════════════
    { code: 'OR01', label: 'Consultation orthodontique', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR02', label: 'Pose appareil multi-attaches (bagues)', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR03', label: 'Pose aligneurs (type Invisalign)', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR04', label: 'Pose appareil amovible', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR05', label: 'Pose mainteneur d\'espace', category: 'Orthodontie', scope: 'TOOTH' },
    { code: 'OR06', label: 'Pose arc de contention', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR07', label: 'Dépose appareil orthodontique', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR08', label: 'Activation appareil', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR09', label: 'Réparation appareil orthodontique', category: 'Orthodontie', scope: 'MOUTH' },
    { code: 'OR10', label: 'Contention orthodontique', category: 'Orthodontie', scope: 'MOUTH' },

    // ═══════════════════════════════════════════
    // PÉDODONTIE (DENTISTERIE PÉDIATRIQUE)
    // ═══════════════════════════════════════════
    { code: 'PE01', label: 'Examen bucco-dentaire enfant', category: 'Pédodontie', scope: 'MOUTH' },
    { code: 'PE02', label: 'Obturation dent de lait', category: 'Pédodontie', scope: 'TOOTH' },
    { code: 'PE03', label: 'Extraction dent de lait', category: 'Pédodontie', scope: 'TOOTH' },
    { code: 'PE04', label: 'Pulpotomie dent de lait', category: 'Pédodontie', scope: 'TOOTH' },
    { code: 'PE05', label: 'Coiffe pédodontique (couronne préformée)', category: 'Pédodontie', scope: 'TOOTH' },
    { code: 'PE06', label: 'Traitement MIH (Hypominéralisation)', category: 'Pédodontie', scope: 'TOOTH' },
    { code: 'PE07', label: 'Mainteneur d\'espace pédiatrique', category: 'Pédodontie', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // CHIRURGIE BUCCALE
    // ═══════════════════════════════════════════
    { code: 'CH01', label: 'Biopsie buccale', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH02', label: 'Exérèse kyste dentaire', category: 'Chirurgie buccale', scope: 'TOOTH' },
    { code: 'CH03', label: 'Exérèse granulome', category: 'Chirurgie buccale', scope: 'TOOTH' },
    { code: 'CH04', label: 'Incision et drainage abcès', category: 'Chirurgie buccale', scope: 'TOOTH' },
    { code: 'CH05', label: 'Régularisation crête alvéolaire', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH06', label: 'Exérèse épulis', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH07', label: 'Exérèse mucocèle', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH08', label: 'Exérèse torus', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH09', label: 'Plastie vestibulaire', category: 'Chirurgie buccale', scope: 'MOUTH' },
    { code: 'CH10', label: 'Suture plaie buccale', category: 'Chirurgie buccale', scope: 'MOUTH' },

    // ═══════════════════════════════════════════
    // URGENCES DENTAIRES
    // ═══════════════════════════════════════════
    { code: 'UR01', label: 'Consultation urgence', category: 'Urgences', scope: 'MOUTH' },
    { code: 'UR02', label: 'Traitement douleur aiguë', category: 'Urgences', scope: 'TOOTH' },
    { code: 'UR03', label: 'Réimplantation dentaire (avulsion)', category: 'Urgences', scope: 'TOOTH' },
    { code: 'UR04', label: 'Contention post-traumatique', category: 'Urgences', scope: 'TOOTH' },
    { code: 'UR05', label: 'Traitement fracture dentaire', category: 'Urgences', scope: 'TOOTH' },
    { code: 'UR06', label: 'Réparation prothèse urgence', category: 'Urgences', scope: 'MOUTH' },
    { code: 'UR07', label: 'Rescellement urgence', category: 'Urgences', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // RADIOLOGIE DENTAIRE
    // ═══════════════════════════════════════════
    { code: 'RA01', label: 'Radiographie rétro-alvéolaire', category: 'Radiologie', scope: 'TOOTH' },
    { code: 'RA02', label: 'Radiographie panoramique', category: 'Radiologie', scope: 'MOUTH' },
    { code: 'RA03', label: 'Radiographie bite-wing', category: 'Radiologie', scope: 'TOOTH' },
    { code: 'RA04', label: 'Cone beam (CBCT)', category: 'Radiologie', scope: 'MOUTH' },
    { code: 'RA05', label: 'Téléradiographie', category: 'Radiologie', scope: 'MOUTH' },
    { code: 'RA06', label: 'Status radiographique complet', category: 'Radiologie', scope: 'MOUTH' },

    // ═══════════════════════════════════════════
    // ESTHÉTIQUE DENTAIRE
    // ═══════════════════════════════════════════
    { code: 'ES01', label: 'Blanchiment ambulatoire (gouttières)', category: 'Esthétique', scope: 'MOUTH' },
    { code: 'ES02', label: 'Blanchiment au fauteuil', category: 'Esthétique', scope: 'MOUTH' },
    { code: 'ES03', label: 'Blanchiment interne (dent dévitalisée)', category: 'Esthétique', scope: 'TOOTH' },
    { code: 'ES04', label: 'Microabrasion amélaire', category: 'Esthétique', scope: 'TOOTH' },
    { code: 'ES05', label: 'Stripping (réduction inter-proximale)', category: 'Esthétique', scope: 'TOOTH' },
    { code: 'ES06', label: 'Reconstitution esthétique composite', category: 'Esthétique', scope: 'TOOTH' },
    { code: 'ES07', label: 'Fermeture diastème', category: 'Esthétique', scope: 'TOOTH' },

    // ═══════════════════════════════════════════
    // CONSULTATIONS & EXAMENS
    // ═══════════════════════════════════════════
    { code: 'CO01', label: 'Première consultation', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO02', label: 'Consultation de contrôle', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO03', label: 'Examen bucco-dentaire complet', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO04', label: 'Bilan parodontal', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO05', label: 'Devis prothétique', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO06', label: 'Plan de traitement', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO07', label: 'Empreinte diagnostic', category: 'Consultations', scope: 'MOUTH' },
    { code: 'CO08', label: 'Photographies intra-orales', category: 'Consultations', scope: 'MOUTH' },

    // ═══════════════════════════════════════════
    // OCCLUSODONTIE / ATM
    // ═══════════════════════════════════════════
    { code: 'OC01', label: 'Analyse occlusale', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC02', label: 'Gouttière occlusale', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC03', label: 'Équilibration occlusale', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC04', label: 'Traitement bruxisme', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC05', label: 'Traitement dysfonction ATM', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC06', label: 'Gouttière de protection sportive', category: 'Occlusodontie', scope: 'MOUTH' },
    { code: 'OC07', label: 'Orthèse d\'avancée mandibulaire (apnée)', category: 'Occlusodontie', scope: 'MOUTH' },
];

async function importDentalActs() {
    try {
        console.log('🔄 Import des actes dentaires simplifiés...\n');

        // Clear existing data
        console.log('🗑️  Suppression des anciennes données CCAM...');
        await pool.query('TRUNCATE TABLE act_catalog RESTART IDENTITY CASCADE');

        // Insert new acts
        let inserted = 0;
        for (const act of DENTAL_ACTS) {
            await pool.query(`
                INSERT INTO act_catalog (code_ccam, code_short, label, chapter_code, chapter_label, family_code, family_label)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            `, [
                act.code,
                act.code,
                act.label,
                act.category.substring(0, 2).toUpperCase(),
                act.category,
                act.scope,
                act.category
            ]);
            inserted++;
        }

        console.log('');
        console.log('═══════════════════════════════════════════');
        console.log('📊 Import terminé');
        console.log('═══════════════════════════════════════════');
        console.log(`   ✅ Actes importés: ${inserted}`);
        console.log('');

        // Show categories
        const categories = await pool.query(`
            SELECT chapter_label as category, COUNT(*) as count 
            FROM act_catalog 
            GROUP BY chapter_label 
            ORDER BY chapter_label
        `);
        
        console.log('📋 Catégories:');
        for (const cat of categories.rows) {
            console.log(`   - ${cat.category}: ${cat.count} actes`);
        }

        console.log('');
        console.log('✅ Import des actes dentaires terminé!');

    } catch (error) {
        console.error('❌ Erreur:', error);
    } finally {
        await pool.end();
    }
}

importDentalActs();
