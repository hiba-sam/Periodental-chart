import pool from '../db.js';

async function runMigration() {
    try {
        console.log('Running migration 044: Add free status to invoices...');
        
        await pool.query(`
            ALTER TABLE consultation_invoices DROP CONSTRAINT IF EXISTS consultation_invoices_status_check
        `);
        
        await pool.query(`
            ALTER TABLE consultation_invoices ADD CONSTRAINT consultation_invoices_status_check 
            CHECK (status IN ('paid', 'unpaid', 'partial', 'free'))
        `);
        
        console.log('✅ Migration 044 completed: free status added to invoices');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
}

runMigration();
