import pool from '../db';
import dotenv from 'dotenv';

dotenv.config();

async function fixAssistantUserId() {
    console.log('🔍 Recherche des informations médecin/assistant...\n');

    try {
        // 1. Trouver le médecin Kheiri Ahmed
        console.log('=== MÉDECIN ===');
        const doctorResult = await pool.query(`
            SELECT u.id as user_id, u.name, u.family_name, u.email, u.role, d.user_id as doctor_user_id
            FROM users u
            LEFT JOIN doctors d ON d.user_id = u.id
            WHERE u.role = 'doctor' AND (u.name ILIKE '%Kheiri%' OR u.family_name ILIKE '%Ahmed%')
        `);
        
        if (doctorResult.rows.length > 0) {
            console.log('Médecin trouvé:');
            doctorResult.rows.forEach(doc => {
                console.log(`  - users.id: ${doc.user_id}`);
                console.log(`  - Nom: ${doc.name} ${doc.family_name}`);
                console.log(`  - Email: ${doc.email}`);
                console.log(`  - doctors.user_id: ${doc.doctor_user_id}`);
            });
        } else {
            console.log('Aucun médecin trouvé avec ce nom');
        }

        // 2. Trouver l'assistant Sarah
        console.log('\n=== ASSISTANT (table users) ===');
        const assistantUserResult = await pool.query(`
            SELECT id, name, family_name, email, role
            FROM users
            WHERE role = 'assistant' AND (name ILIKE '%Sarah%' OR family_name ILIKE '%kadri%')
        `);
        
        if (assistantUserResult.rows.length > 0) {
            console.log('Assistant trouvé dans users:');
            assistantUserResult.rows.forEach(asst => {
                console.log(`  - users.id: ${asst.id}`);
                console.log(`  - Nom: ${asst.name} ${asst.family_name}`);
                console.log(`  - Email: ${asst.email}`);
            });
        } else {
            console.log('Aucun assistant trouvé avec ce nom dans users');
        }

        // 3. Voir tous les assistants dans la table assistants
        console.log('\n=== ASSISTANTS (table assistants) ===');
        const assistantsResult = await pool.query(`
            SELECT id, user_id, assistant_name, assistant_email, doctor_id, is_active
            FROM assistants
            ORDER BY id
        `);
        
        if (assistantsResult.rows.length > 0) {
            console.log('Assistants trouvés:');
            assistantsResult.rows.forEach(asst => {
                console.log(`  - assistants.id: ${asst.id}`);
                console.log(`    user_id: ${asst.user_id}`);
                console.log(`    Nom: ${asst.assistant_name}`);
                console.log(`    Email: ${asst.assistant_email}`);
                console.log(`    doctor_id: ${asst.doctor_id}`);
                console.log(`    is_active: ${asst.is_active}`);
                console.log('');
            });
        } else {
            console.log('Aucun assistant trouvé dans la table assistants');
        }

        // 4. Diagnostic
        console.log('\n=== DIAGNOSTIC ===');
        const sarahUser = assistantUserResult.rows.find(u => u.name?.toLowerCase().includes('sarah') || u.family_name?.toLowerCase().includes('kadri'));
        const sarahAssistant = assistantsResult.rows.find(a => a.assistant_name?.toLowerCase().includes('sarah'));
        
        if (sarahUser && sarahAssistant) {
            console.log(`L'assistant Sarah est connecté avec users.id = ${sarahUser.id}`);
            console.log(`Dans la table assistants, user_id = ${sarahAssistant.user_id}`);
            
            if (sarahUser.id !== sarahAssistant.user_id) {
                console.log('\n⚠️  INCOHÉRENCE DÉTECTÉE!');
                console.log(`Le user_id dans assistants (${sarahAssistant.user_id}) ne correspond pas à users.id (${sarahUser.id})`);
                console.log('\n🔧 CORRECTION NÉCESSAIRE:');
                console.log(`UPDATE assistants SET user_id = ${sarahUser.id} WHERE id = ${sarahAssistant.id};`);
                
                // Demander confirmation avant de corriger
                console.log('\n📝 Application de la correction...');
                await pool.query(`UPDATE assistants SET user_id = $1 WHERE id = $2`, [sarahUser.id, sarahAssistant.id]);
                console.log('✅ Correction appliquée avec succès!');
                
                // Vérification
                const verifyResult = await pool.query(`SELECT id, user_id, assistant_name FROM assistants WHERE id = $1`, [sarahAssistant.id]);
                console.log('\n📋 Vérification:');
                console.log(`  assistants.id: ${verifyResult.rows[0].id}`);
                console.log(`  user_id: ${verifyResult.rows[0].user_id}`);
                console.log(`  assistant_name: ${verifyResult.rows[0].assistant_name}`);
            } else {
                console.log('\n✅ Les IDs correspondent déjà. Pas de correction nécessaire.');
            }
        }

    } catch (error) {
        console.error('❌ Erreur:', error);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

fixAssistantUserId();
