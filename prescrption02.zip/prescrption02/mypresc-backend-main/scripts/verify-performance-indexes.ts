/**
 * Verify all Phase 2 performance indexes exist in the database
 */
import pool from '../db.ts';

const expectedIndexes = [
    'idx_patients_created_by_doctor',
    'idx_medical_shares_access',
    'idx_doctor_patient_privacy_lookup',
    'idx_patients_created_at_id_desc',
    'idx_prescriptions_doctor_patient',
    'idx_appointments_doctor_done_patient',
];

async function verify() {
    const result = await pool.query(`
        SELECT indexname, tablename
        FROM pg_indexes
        WHERE indexname = ANY($1::text[])
        ORDER BY indexname
    `, [expectedIndexes]);

    console.log('\n📋 Phase 2 Index Verification:\n');
    for (const expected of expectedIndexes) {
        const found = result.rows.find(r => r.indexname === expected);
        if (found) {
            console.log(`  ✅ ${expected} (table: ${found.tablename})`);
        } else {
            console.log(`  ❌ MISSING: ${expected}`);
        }
    }

    const missing = expectedIndexes.filter(name => !result.rows.find(r => r.indexname === name));
    if (missing.length === 0) {
        console.log('\n🎉 All Phase 2 indexes are present!\n');
    } else {
        console.log(`\n⚠️  ${missing.length} index(es) missing. Re-run apply-performance-indexes.ts\n`);
    }

    process.exit(0);
}

verify().catch(err => { console.error(err); process.exit(1); });
