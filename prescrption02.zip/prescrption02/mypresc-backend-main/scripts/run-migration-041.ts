import pool from '../db';

async function runMigration() {
    try {
        console.log('Running migration 041_add_share_dental_acts...');
        await pool.query(`
            ALTER TABLE medical_shares 
            ADD COLUMN IF NOT EXISTS share_dental_acts BOOLEAN DEFAULT true;
        `);
        console.log('✅ Migration completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
}

runMigration();
