import pool from '../db';

async function checkTableStructure() {
    try {
        console.log('Checking medical_reports table structure...\n');
        
        // Check column types
        const columnsResult = await pool.query(`
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_name = 'medical_reports'
            ORDER BY ordinal_position
        `);
        
        console.log('Columns:');
        console.table(columnsResult.rows);
        
        // Check if there's data
        const countResult = await pool.query('SELECT COUNT(*) as count FROM medical_reports');
        console.log(`\nTotal records: ${countResult.rows[0].count}`);
        
        // Sample data (first record)
        if (parseInt(countResult.rows[0].count) > 0) {
            const sampleResult = await pool.query(`
                SELECT id, 
                       pg_typeof(title) as title_type,
                       pg_typeof(content) as content_type,
                       octet_length(title) as title_bytes,
                       octet_length(content) as content_bytes
                FROM medical_reports 
                LIMIT 1
            `);
            console.log('\nSample record info:');
            console.table(sampleResult.rows);
            
            // Try to read as text
            try {
                const textResult = await pool.query(`
                    SELECT id, title::text as title_text, content::text as content_text
                    FROM medical_reports LIMIT 1
                `);
                console.log('\nTitle/Content as text:');
                console.log('Title:', textResult.rows[0]?.title_text?.substring(0, 100));
                console.log('Content:', textResult.rows[0]?.content_text?.substring(0, 100));
            } catch (e: any) {
                console.log('\nCannot read as text:', e.message);
            }
        }
        
        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

checkTableStructure();
