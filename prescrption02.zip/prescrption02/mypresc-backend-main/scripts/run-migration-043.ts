import pool from '../db.js';

async function runMigration043() {
    try {
        console.log('Running migration 043: Add amount_paid to consultation_invoices...');
        
        // Add amount_paid column
        await pool.query(`
            ALTER TABLE consultation_invoices 
            ADD COLUMN IF NOT EXISTS amount_paid DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (amount_paid >= 0)
        `);
        console.log('✅ Added amount_paid column');

        // Update status constraint to include 'partial'
        await pool.query(`
            ALTER TABLE consultation_invoices DROP CONSTRAINT IF EXISTS consultation_invoices_status_check
        `);
        await pool.query(`
            ALTER TABLE consultation_invoices ADD CONSTRAINT consultation_invoices_status_check 
            CHECK (status IN ('paid', 'unpaid', 'partial'))
        `);
        console.log('✅ Updated status constraint to include partial');

        // Add comment
        await pool.query(`
            COMMENT ON COLUMN consultation_invoices.amount_paid IS 'Total amount paid so far (supports partial payments)'
        `);
        console.log('✅ Added column comment');

        // Record migration as done
        await pool.query(`
            INSERT INTO migrations (filename) VALUES ('043_add_amount_paid_to_invoices.sql')
            ON CONFLICT (filename) DO NOTHING
        `);
        console.log('✅ Migration 043 recorded');

        console.log('🎉 Migration 043 completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
}

runMigration043();
