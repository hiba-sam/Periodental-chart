import pool from '../db';

async function addColumns() {
    console.log('🔄 Adding is_custom and custom_medication_id columns to prescription_medications...');
    
    try {
        await pool.query(`
            ALTER TABLE prescription_medications 
            ADD COLUMN IF NOT EXISTS is_custom BOOLEAN DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS custom_medication_id INTEGER REFERENCES custom_medications(id);
        `);
        console.log('✅ Columns added successfully!');
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

addColumns();
