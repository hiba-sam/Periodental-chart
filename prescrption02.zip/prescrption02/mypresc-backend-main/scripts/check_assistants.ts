
import pool from '../db';
import { AssistantModel } from '../models/assistant.model';

async function checkAssistants() {
    console.log("Checking assistants status...");
    const result = await pool.query("SELECT id, name, family_name, email, role FROM users WHERE role = 'assistant'");
    const assistants = result.rows;

    console.log(`Found ${assistants.length} users with role 'assistant'.`);

    for (const ast of assistants) {
        const profile = await AssistantModel.findByUserId(ast.id);
        if (profile) {
            console.log(`✅ [${ast.id}] ${ast.name} ${ast.family_name} (${ast.email}) has a profile linked to doctor ${profile.doctor_id}.`);
        } else {
            console.log(`❌ [${ast.id}] ${ast.name} ${ast.family_name} (${ast.email}) is MISSING a profile!`);
        }
    }
}

checkAssistants().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
