/**
 * Phase 2: Apply patient performance indexes directly (outside transaction block)
 * CONCURRENTLY cannot run inside a transaction.
 */
import pool from '../db.ts';

const indexes = [
    {
        name: 'idx_patients_created_by_doctor',
        sql: `CREATE INDEX IF NOT EXISTS idx_patients_created_by_doctor
              ON patients(created_by_doctor_id)
              WHERE created_by_doctor_id IS NOT NULL`
    },
    {
        name: 'idx_medical_shares_access',
        sql: `CREATE INDEX IF NOT EXISTS idx_medical_shares_access
              ON medical_shares(patient_id, shared_with_doctor_id, expires_at)
              WHERE status = 'active'`
    },
    {
        name: 'idx_doctor_patient_privacy_lookup',
        sql: `CREATE INDEX IF NOT EXISTS idx_doctor_patient_privacy_lookup
              ON doctor_patient_privacy(patient_id, doctor_id)`
    },
    {
        name: 'idx_patients_created_at_id_desc',
        sql: `CREATE INDEX IF NOT EXISTS idx_patients_created_at_id_desc
              ON patients(created_at DESC, id DESC)`
    },
    {
        name: 'idx_prescriptions_doctor_patient',
        sql: `CREATE INDEX IF NOT EXISTS idx_prescriptions_doctor_patient
              ON prescriptions(doctor_user_id, patient_id)`
    },
    {
        name: 'idx_appointments_doctor_done_patient',
        sql: `CREATE INDEX IF NOT EXISTS idx_appointments_doctor_done_patient
              ON appointments(doctor_user_id, patient_id)
              WHERE is_done = true`
    }
];

async function applyIndexes() {
    console.log('⚡ Phase 2: Applying patient performance indexes...\n');

    for (const index of indexes) {
        try {
            console.log(`  → Creating ${index.name}...`);
            const start = Date.now();
            await pool.query(index.sql);
            const ms = Date.now() - start;
            console.log(`  ✅ ${index.name} (${ms}ms)\n`);
        } catch (err: any) {
            if (err.message?.includes('already exists')) {
                console.log(`  ⚠️  ${index.name} already exists, skipping\n`);
            } else {
                console.error(`  ❌ Failed to create ${index.name}:`, err.message, '\n');
            }
        }
    }

    console.log('🎉 Phase 2 indexes complete. Restart the server and retest.');
    process.exit(0);
}

applyIndexes().catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
});
