import { readFileSync } from 'fs';
import pool from '../db';

async function runMigration() {
    try {
        console.log('📊 Connecting to database...');
        
        const sql = readFileSync('migrations/020_create_ai_medical_report_quota.sql', 'utf-8');
        
        console.log('🔄 Executing AI Medical Report migration...');
        await pool.query(sql);
        
        console.log('✅ Migration completed successfully!');
        
        // Vérifier les tables créées
        const tables = await pool.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('ai_medical_report_quota', 'ai_medical_report_logs')
            ORDER BY table_name;
        `);
        
        console.log('\n📋 Tables créées:');
        tables.rows.forEach(row => {
            console.log(`  ✓ ${row.table_name}`);
        });
        
        process.exit(0);
    } catch (error: any) {
        console.error('❌ Migration failed:', error.message);
        process.exit(1);
    }
}

runMigration();
