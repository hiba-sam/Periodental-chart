/**
 * Check Environment Variables Changes
 * 
 * Script pour détecter les différences entre .env et .env.example
 * À exécuter après un git pull
 */

import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const ENV_FILE = join(__dirname, '..', '.env');
const ENV_EXAMPLE_FILE = join(__dirname, '..', '.env.example');

function parseEnvFile(filePath: string): Set<string> {
    if (!existsSync(filePath)) {
        return new Set();
    }

    const content = readFileSync(filePath, 'utf-8');
    const variables = new Set<string>();

    content.split('\n').forEach(line => {
        // Ignorer les commentaires et lignes vides
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) {
            return;
        }

        // Extraire le nom de la variable
        const match = trimmed.match(/^([A-Z_][A-Z0-9_]*)=/);
        if (match) {
            variables.add(match[1]);
        }
    });

    return variables;
}

function checkEnvChanges() {
    console.log('\n🔍 Vérification des variables d\'environnement...\n');
    console.log('─'.repeat(60));

    // Charger les variables
    const envVars = parseEnvFile(ENV_FILE);
    const exampleVars = parseEnvFile(ENV_EXAMPLE_FILE);

    if (envVars.size === 0) {
        console.log('\n❌ ERREUR : Fichier .env introuvable !');
        console.log('\n💡 Solution :');
        console.log('   cp .env.example .env');
        console.log('   # Puis remplir avec vos valeurs\n');
        process.exit(1);
    }

    // Trouver les variables manquantes dans .env
    const missingInEnv = Array.from(exampleVars).filter(v => !envVars.has(v));

    // Trouver les variables obsolètes dans .env (présentes dans .env mais pas dans .env.example)
    const obsoleteInEnv = Array.from(envVars).filter(v => !exampleVars.has(v));

    // Afficher le résumé
    console.log(`📊 Variables dans .env.example : ${exampleVars.size}`);
    console.log(`📊 Variables dans .env         : ${envVars.size}`);
    console.log('─'.repeat(60));

    let hasIssues = false;

    // Variables manquantes
    if (missingInEnv.length > 0) {
        hasIssues = true;
        console.log('\n⚠️  VARIABLES MANQUANTES dans votre .env :\n');
        missingInEnv.forEach(v => {
            console.log(`   ❌ ${v}`);
        });
        console.log('\n💡 Action requise :');
        console.log('   1. Ouvrez .env.example');
        console.log('   2. Copiez ces variables dans votre .env');
        console.log('   3. Remplissez avec VOS valeurs\n');
    }

    // Variables obsolètes
    if (obsoleteInEnv.length > 0) {
        console.log('\n⚠️  VARIABLES OBSOLÈTES dans votre .env :\n');
        obsoleteInEnv.forEach(v => {
            console.log(`   ⚠️  ${v}`);
        });
        console.log('\n💡 Ces variables ne sont plus utilisées.');
        console.log('   Vous pouvez les supprimer ou les garder.\n');
    }

    // Tout est OK
    if (!hasIssues && obsoleteInEnv.length === 0) {
        console.log('\n✅ Votre .env est à jour !\n');
        console.log('   Toutes les variables requises sont présentes.\n');
    }

    console.log('─'.repeat(60));

    if (hasIssues) {
        console.log('\n🚫 ATTENTION : Variables manquantes détectées !');
        console.log('   L\'application peut ne pas démarrer correctement.\n');
        process.exit(1);
    } else {
        console.log('\n✅ Vérification terminée avec succès\n');
        process.exit(0);
    }
}

// Exécution
checkEnvChanges();
