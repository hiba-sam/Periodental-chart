import pool from '../db.js';
import { readFileSync } from 'fs';
import { join } from 'path';

async function runMigration() {
    try {
        console.log('Running migration 045: Create cardiology_reports table...');
        
        const sql = readFileSync(
            join(import.meta.dir, '..', 'migrations', '045_create_cardiology_reports.sql'),
            'utf-8'
        );
        
        await pool.query(sql);
        
        console.log('✅ Migration 045 completed: cardiology_reports table created');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration 045 failed:', error);
        process.exit(1);
    }
}

runMigration();
