import pg from 'pg';
const { Pool } = pg;
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function testLogin(): Promise<void> {
  const email = 'rayanetahar75@gmail.com';
  const password = 'Abdelali47';
  
  // Force set new password
  const newHash = await bcrypt.hash(password, 10);
  await pool.query("UPDATE users SET password = $1 WHERE email = $2", [newHash, email]);
  console.log('✅ Mot de passe:', password);
  console.log('✅ Hash mis à jour dans la DB');
  
  // Verify
  const isValid = await bcrypt.compare(password, newHash);
  console.log('✅ Test bcrypt.compare:', isValid);
  
  await pool.end();
}

testLogin().catch((e: Error) => { console.error(e); pool.end(); });
