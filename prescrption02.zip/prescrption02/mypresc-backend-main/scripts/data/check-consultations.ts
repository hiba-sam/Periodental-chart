import pg from 'pg';
const { Client } = pg;
import dotenv from 'dotenv';

dotenv.config();

interface ConsultationRow {
  id: string;
  name: string;
  family_name: string;
  compteur_patient: number;
  consultations_reelles: string;
}

async function checkConsultations(): Promise<void> {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    
    console.log('📊 Vérification des compteurs de consultations\n');
    
    const query = `
      SELECT 
        p.id,
        p.name,
        p.family_name,
        p.consultations as compteur_patient,
        COUNT(c.id) as consultations_reelles
      FROM patients p
      LEFT JOIN consultations c ON p.id = c.patient_id
      GROUP BY p.id, p.name, p.family_name, p.consultations
      HAVING p.consultations > 0 OR COUNT(c.id) > 0
      ORDER BY p.consultations DESC
      LIMIT 10;
    `;
    
    const result = await client.query<ConsultationRow>(query);
    
    if (result.rows.length === 0) {
      console.log('❌ Aucun patient avec consultations trouvé');
      return;
    }
    
    console.log('Patient                          | Compteur | Réel');
    console.log('─────────────────────────────────┼──────────┼──────');
    
    for (const row of result.rows) {
      const name = `${row.name} ${row.family_name}`.padEnd(32);
      const compteur = String(row.compteur_patient).padStart(8);
      const reel = String(row.consultations_reelles).padStart(5);
      const status = row.compteur_patient === parseInt(row.consultations_reelles) ? '✅' : '⚠️';
      console.log(`${name}| ${compteur} | ${reel} ${status}`);
    }
    
    console.log('\n✅ = Compteur correct');
    console.log('⚠️  = Différence détectée (peut être normal si backfill récent)');
    
  } catch (error) {
    console.error('❌ Erreur:', (error as Error).message);
  } finally {
    await client.end();
  }
}

checkConsultations();
