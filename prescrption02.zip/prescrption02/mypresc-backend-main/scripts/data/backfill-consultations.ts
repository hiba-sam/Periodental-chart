import pg from 'pg';
const { Client } = pg;
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

console.log('🔧 DATABASE_URL:', process.env.DATABASE_URL ? 'Loaded ✅' : 'Missing ❌');

interface BackfillStats {
  total_patients: string;
  total_consultations: string;
  consultations_with_prescriptions: string;
  consultations_with_reports: string;
}

async function backfillConsultations(): Promise<void> {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: {
      rejectUnauthorized: false
    }
  });

  try {
    await client.connect();
    console.log('✅ Connected to database\n');

    console.log('📊 Analyzing existing prescriptions and medical reports...\n');

    // Create consultations from existing prescriptions and medical reports
    const backfillQuery = `
      WITH existing_interactions AS (
        -- Get all prescriptions with their dates
        SELECT 
          patient_id,
          doctor_user_id,
          DATE(created_at) as consultation_date,
          'prescription' as type,
          id as interaction_id,
          created_at
        FROM prescriptions
        
        UNION ALL
        
        -- Get all medical reports with their dates
        SELECT 
          patient_id,
          doctor_user_id,
          DATE(created_at) as consultation_date,
          'medical_report' as type,
          id as interaction_id,
          created_at
        FROM medical_reports
      ),
      unique_consultations AS (
        -- Group by patient, doctor, and date to get unique consultations
        SELECT DISTINCT
          ei.patient_id,
          ei.doctor_user_id,
          ei.consultation_date,
          MIN(ei.created_at) as first_interaction_time
        FROM existing_interactions ei
        -- Only include if patient still exists
        INNER JOIN patients p ON ei.patient_id = p.id
        -- Only include if doctor still exists
        INNER JOIN users u ON ei.doctor_user_id = u.id
        GROUP BY ei.patient_id, ei.doctor_user_id, ei.consultation_date
      )
      -- Insert unique consultations (ignore if already exists)
      INSERT INTO consultations (patient_id, doctor_user_id, consultation_date, created_at)
      SELECT 
        patient_id,
        doctor_user_id,
        consultation_date,
        first_interaction_time
      FROM unique_consultations
      ON CONFLICT (patient_id, doctor_user_id, consultation_date) DO NOTHING
      RETURNING id, patient_id, doctor_user_id, consultation_date;
    `;

    console.log('🔄 Creating consultations from historical data...');
    const result = await client.query(backfillQuery);
    console.log(`✅ Created ${result.rowCount} consultations from historical data\n`);

    // Update prescriptions to link them to consultations
    console.log('🔗 Linking prescriptions to consultations...');
    const linkPrescriptionsQuery = `
      UPDATE prescriptions p
      SET consultation_id = c.id
      FROM consultations c
      WHERE p.patient_id = c.patient_id
        AND p.doctor_user_id = c.doctor_user_id
        AND DATE(p.created_at) = c.consultation_date
        AND p.consultation_id IS NULL;
    `;
    const prescriptionsResult = await client.query(linkPrescriptionsQuery);
    console.log(`✅ Linked ${prescriptionsResult.rowCount} prescriptions to consultations\n`);

    // Update medical reports to link them to consultations
    console.log('🔗 Linking medical reports to consultations...');
    const linkReportsQuery = `
      UPDATE medical_reports mr
      SET consultation_id = c.id
      FROM consultations c
      WHERE mr.patient_id = c.patient_id
        AND mr.doctor_user_id = c.doctor_user_id
        AND DATE(mr.created_at) = c.consultation_date
        AND mr.consultation_id IS NULL;
    `;
    const reportsResult = await client.query(linkReportsQuery);
    console.log(`✅ Linked ${reportsResult.rowCount} medical reports to consultations\n`);

    // Mark consultations that have prescriptions
    console.log('📝 Marking consultations with prescriptions...');
    const markPrescriptionsQuery = `
      UPDATE consultations c
      SET has_prescription = true
      WHERE EXISTS (
        SELECT 1 FROM prescriptions p
        WHERE p.consultation_id = c.id
      )
      AND has_prescription = false;
    `;
    const markPrescriptionsResult = await client.query(markPrescriptionsQuery);
    console.log(`✅ Marked ${markPrescriptionsResult.rowCount} consultations as having prescriptions\n`);

    // Mark consultations that have medical reports
    console.log('📋 Marking consultations with medical reports...');
    const markReportsQuery = `
      UPDATE consultations c
      SET has_medical_report = true
      WHERE EXISTS (
        SELECT 1 FROM medical_reports mr
        WHERE mr.consultation_id = c.id
      )
      AND has_medical_report = false;
    `;
    const markReportsResult = await client.query(markReportsQuery);
    console.log(`✅ Marked ${markReportsResult.rowCount} consultations as having medical reports\n`);

    // Get statistics
    console.log('📊 Statistics:\n');
    const statsQuery = `
      SELECT 
        COUNT(DISTINCT patient_id) as total_patients,
        COUNT(*) as total_consultations,
        SUM(CASE WHEN has_prescription THEN 1 ELSE 0 END) as consultations_with_prescriptions,
        SUM(CASE WHEN has_medical_report THEN 1 ELSE 0 END) as consultations_with_reports
      FROM consultations;
    `;
    const stats = await client.query<BackfillStats>(statsQuery);
    const stat = stats.rows[0];
    
    if (stat) {
      console.log(`   👥 Patients with consultations: ${stat.total_patients}`);
      console.log(`   📅 Total consultations: ${stat.total_consultations}`);
      console.log(`   📝 Consultations with prescriptions: ${stat.consultations_with_prescriptions}`);
      console.log(`   📋 Consultations with medical reports: ${stat.consultations_with_reports}`);
    }

    console.log('\n🎉 Backfill completed successfully!');
    console.log('💡 Patient consultation counters have been updated automatically via triggers.');

  } catch (error) {
    console.error('❌ Backfill failed:', error);
    throw error;
  } finally {
    await client.end();
  }
}

backfillConsultations();
