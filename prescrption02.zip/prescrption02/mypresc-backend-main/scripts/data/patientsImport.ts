/**
 * XLSX → Encrypted PostgreSQL Patient Import (TypeScript)
 * =========================================================
 * Script location : /scripts/data/import_patients.ts
 * XLSX location   : /scripts/data/Feuille_de_calcul_sans_titre.xlsx  ← same folder
 *
 * Fields imported:
 *   name             ← Nom
 *   family_name      ← Prénom
 *   date_naissance   ← D.D.N
 *   telephone        ← Tél
 *   adresse          ← Adresse
 *   chronicDiseases  ← Important à signaler
 *
 * Requirements:
 *   npm install xlsx pg @types/pg tsx
 *
 * Usage:
 *   export PATIENT_ENC_KEY="your-strong-secret"
 *   export DATABASE_URL="postgresql://user:password@localhost:5432/yourdb"
 *   npx tsx import_patients.ts
 */

import { createRequire } from "module";
const require = createRequire(import.meta.url);
const XLSX = require("xlsx");
import { Pool } from "pg";
import { createHash } from "crypto";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ─── CONFIGURATION ────────────────────────────────────────────────────────────

// XLSX must sit in the same folder as this script (/scripts/data/)
const XLSX_FILE   = path.join(__dirname, "bessaid_patients.xlsx");
const SHEET_INDEX = 0;
const BATCH_SIZE  = 500;

// ↓↓↓ Update these two IDs before each import run ↓↓↓
const CREATED_BY_DOCTOR_ID: number = 22;        // doctor who is running the import
const MEDECIN_TRAITANT_ID:  number | null = null; // treating doctor (or null)
// ↑↑↑ ─────────────────────────────────────────── ↑↑↑

const DB_CONFIG = {
  connectionString: process.env.DATABASE_URL,
  ssl: false
};

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;
// ⚠️  Always use env var in production:  export ENCRYPTION_KEY="..."

// ─── COLUMN MAPPING ───────────────────────────────────────────────────────────
// DB column → exact XLSX header (case-insensitive match)

const COLUMN_MAP: Record<string, string> = {
  name:            "Nom",
  family_name:     "Prénom",
  date_naissance:  "D.D.N",
  telephone:       "Tél",
  adresse:         "Adresse",
  chronicDiseases: "Important à signaler",
};

// ─── TYPES ────────────────────────────────────────────────────────────────────

type PatientRow = {
  name:                    string;
  family_name:             string;
  age:                     string;
  date_naissance:          string;
  telephone:               string;
  adresse:                 string;
  chronicdiseases:         string;
  name_blind_index:        string | null;
  family_name_blind_index: string | null;
  full_name_blind_index:   string | null;
  nin_blind_index:         string;
  medecin_traitant_id:     number | null;
  created_by_doctor_id:    number | null;
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function blindIndex(value: string | null): string | null {
  if (!value?.trim()) return null;
  return createHash("sha256").update(value.trim().toLowerCase()).digest("hex");
}

function safeStr(val: unknown): string {
  if (val === null || val === undefined) return "";
  return String(val).trim();
}

function cleanName(val: string): string {
  // 1. Replace underscores in the CENTER with a space  (e.g. ahmed_ali → ahmed ali)
  let cleaned = val.replace(/(?<=\S)_(?=\S)/g, " ");
  // 2. Strip any remaining leading / trailing underscores
  cleaned = cleaned.replace(/^_+|_+$/g, "");
  return cleaned.trim();
}

function calculateAge(dateStr: string): string {
  if (!dateStr) return "";
  let day: number, month: number, year: number;
  // Support both DD/MM/YYYY and YYYY-MM-DD
  if (dateStr.includes("/")) {
    [day, month, year] = dateStr.split("/").map(Number);
  } else if (dateStr.includes("-")) {
    [year, month, day] = dateStr.split("-").map(Number);
  } else {
    return "";
  }
  if (!day || !month || !year) return "";
  const today    = new Date();
  let age        = today.getFullYear() - year;
  const monthDiff = today.getMonth() + 1 - month;
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < day)) age--;
  return age > 0 && age < 150 ? String(age) : "";
}

function buildRow(rawRow: Record<string, unknown>): PatientRow {
  // Normalize raw row keys for case-insensitive + trimmed lookup
  const normalized: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(rawRow)) {
    normalized[k.trim().toLowerCase()] = v;
  }

  const get = (xlsxHeader: string): string =>
    safeStr(normalized[xlsxHeader.trim().toLowerCase()]);

  const name        = cleanName(get(COLUMN_MAP.name!));
  const familyName  = cleanName(get(COLUMN_MAP.family_name!));
  const fullName    = [name, familyName].filter(Boolean).join(" ");
  const dateNaiss   = get(COLUMN_MAP.date_naissance!);

  return {
    name,
    family_name:             familyName,
    age:                     calculateAge(dateNaiss),
    date_naissance:          dateNaiss,
    telephone:               get(COLUMN_MAP.telephone!),
    adresse:                 get(COLUMN_MAP.adresse!),
    chronicdiseases:         COLUMN_MAP.chronicdiseases ? get(COLUMN_MAP.chronicdiseases!).trim() : "",
    name_blind_index:        blindIndex(name),
    family_name_blind_index: blindIndex(familyName),
    full_name_blind_index:   blindIndex(fullName),
    nin_blind_index:         "",
    medecin_traitant_id:     MEDECIN_TRAITANT_ID,
    created_by_doctor_id:    CREATED_BY_DOCTOR_ID,
  };
}

// ─── SQL ──────────────────────────────────────────────────────────────────────
// NOT NULL columns (genre, nin) get empty encrypted string placeholders

const INSERT_SQL = `
INSERT INTO patients (
  name, family_name, age, genre, telephone, nin,
  adresse, date_naissance, chronicdiseases,
  name_blind_index, family_name_blind_index,
  full_name_blind_index, nin_blind_index,
  medecin_traitant_id, created_by_doctor_id
) VALUES (
  pgp_sym_encrypt($1,  $9),
  pgp_sym_encrypt($2,  $9),
  pgp_sym_encrypt($14, $9),
  pgp_sym_encrypt('',  $9),
  pgp_sym_encrypt($3,  $9),
  pgp_sym_encrypt('',  $9),
  pgp_sym_encrypt($4,  $9),
  pgp_sym_encrypt($5,  $9),
  pgp_sym_encrypt($6,  $9),
  $7, $8, $10, $13,
  $11, $12
)
ON CONFLICT DO NOTHING;
`;

function rowToParams(r: PatientRow, key: string): unknown[] {
  return [
    r.name,                    // $1
    r.family_name,             // $2
    r.telephone,               // $3
    r.adresse,                 // $4
    r.date_naissance,          // $5
    r.chronicdiseases,         // $6
    r.name_blind_index,        // $7
    r.family_name_blind_index, // $8
    key,                       // $9  — encryption key
    r.full_name_blind_index,   // $10
    r.medecin_traitant_id,     // $11
    r.created_by_doctor_id,    // $12
    r.nin_blind_index,         // $13
    r.age,                     // $14
  ];
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log(`📂  Reading ${XLSX_FILE} …`);

  const workbook  = XLSX.readFile(XLSX_FILE);
  const sheetName = workbook.SheetNames[SHEET_INDEX];
  const rawData   = XLSX.utils.sheet_to_json<Record<string, unknown>>(
    workbook.Sheets[sheetName],
    { defval: null, raw: false }
  );

  const total = rawData.length;
  console.log(`✅  ${total.toLocaleString()} rows loaded from sheet "${sheetName}"\n`);

  if (total === 0) {
    console.log("⚠️  No rows found. Check your XLSX file.");
    process.exit(1);
  }

  // Preview first row to confirm mapping
  const preview = buildRow(rawData[0]!);
  console.log("🔍  First row preview (before encryption):");
  console.table({
    name:                 preview.name                || "(empty)",
    family_name:          preview.family_name         || "(empty)",
    age:                  preview.age                 || "(empty)",
    date_naissance:       preview.date_naissance      || "(empty)",
    telephone:            preview.telephone           || "(empty)",
    adresse:              preview.adresse             || "(empty)",
    chronicDiseases:      preview.chronicdiseases     || "(empty)",
    created_by_doctor_id: preview.created_by_doctor_id,
    medecin_traitant_id:  preview.medecin_traitant_id ?? "(null)",
  });
  console.log();

  const pool = new Pool(DB_CONFIG);
  let inserted = 0, errors = 0, skipped = 0;

  for (let i = 0; i < total; i += BATCH_SIZE) {
    const chunk  = rawData.slice(i, i + BATCH_SIZE);
    const client = await pool.connect();

    try {
      await client.query("BEGIN");

      for (const rawRow of chunk) {
        const patient = buildRow(rawRow);

        // Skip rows with no name at all
        if (!patient.name && !patient.family_name) {
          skipped++;
          continue;
        }

        await client.query(INSERT_SQL, rowToParams(patient, ENCRYPTION_KEY!));
      }

      await client.query("COMMIT");
      inserted += chunk.length - skipped;
    } catch (err) {
      await client.query("ROLLBACK");
      errors += chunk.length;
      console.error(`\n⚠️  Batch ${i}–${i + chunk.length} failed:`, (err as Error).message);
    } finally {
      client.release();
    }

    const done = Math.min(i + BATCH_SIZE, total);
    const pct  = Math.round((done / total) * 100);
    process.stdout.write(`\r⏳  Progress: ${pct}% (${done.toLocaleString()} / ${total.toLocaleString()})`);
  }

  await pool.end();

  console.log(`\n
╔══════════════════════════════════════╗
║           Import Summary             ║
╠══════════════════════════════════════╣
║  Total rows          : ${String(total).padStart(10)}  ║
║  ✅ Inserted         : ${String(inserted).padStart(10)}  ║
║  ⏭️  Skipped (empty)  : ${String(skipped).padStart(10)}  ║
║  ❌ Errors           : ${String(errors).padStart(10)}  ║
║  👨‍⚕️ Created by doctor: ${String(CREATED_BY_DOCTOR_ID).padStart(10)}  ║
╚══════════════════════════════════════╝`);

  if (errors > 0) process.exit(1);
}

main().catch(err => {
  console.error("Fatal error:", err);
  process.exit(1);
});
