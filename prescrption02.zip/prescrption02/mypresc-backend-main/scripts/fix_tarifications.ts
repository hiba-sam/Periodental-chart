
import pool from '../db';

async function checkTarifications() {
    console.log("Checking tarifications status...");
    const result = await pool.query("SELECT id, email FROM users WHERE role = 'doctor'");
    const doctors = result.rows;

    for (const doc of doctors) {
        const tResult = await pool.query("SELECT COUNT(*) FROM tarifications WHERE doctor_user_id = $1", [doc.id]);
        const count = parseInt(tResult.rows[0].count);
        if (count === 0) {
            console.log(`❌ Doctor ${doc.email} (ID: ${doc.id}) has NO tarifications!`);
            
            // Fix it
            const DEFAULT_SERVICES = [
                { service_label: "Consultation générale", price: 2000 },
                { service_label: "Consultation de suivi", price: 2500 },
                { service_label: "Consultation durgence", price: 3000 }
            ];

            for (const service of DEFAULT_SERVICES) {
                await pool.query(
                    "INSERT INTO tarifications (doctor_user_id, service_label, price) VALUES ($1, $2, $3)",
                    [doc.id, service.service_label, service.price]
                );
            }
            console.log(`✅ Created default tarifications for ${doc.email}`);
        } else {
            console.log(`✅ Doctor ${doc.email} has ${count} tarifications.`);
        }
    }
}

checkTarifications().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
