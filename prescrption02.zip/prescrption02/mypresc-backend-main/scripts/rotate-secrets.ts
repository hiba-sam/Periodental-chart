/**
 * Secrets Rotation Script for MyPresc Backend
 * 
 * Génère et remplace les secrets cryptographiques
 * Compatible avec .env ET HashiCorp Vault
 * 
 * Usage:
 *   bun run scripts/rotate-secrets.ts
 * 
 * Conformité : RGPD art. 32, ANPDP art. 25
 */

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { securityLogger, logSecretsRotation } from '../utils/securityLogger';
import { writeSecretsToVault } from '../config/vault';
import dotenv from 'dotenv';

// Load current .env
dotenv.config();

// ============================================
// SECRET GENERATION
// ============================================

/**
 * Génère un secret cryptographiquement fort
 */
function generateSecret(bytes: number, encoding: 'base64' | 'hex' = 'base64'): string {
    return crypto.randomBytes(bytes).toString(encoding);
}

/**
 * Génère tous les secrets
 */
function generateNewSecrets() {
    return {
        JWT_SECRET: generateSecret(64, 'base64'),        // 512 bits
        SESSION_SECRET: generateSecret(64, 'base64'),    // 512 bits
        ENCRYPTION_KEY: generateSecret(32, 'hex'),       // 256 bits
    };
}

// ============================================
// .ENV FILE UPDATE
// ============================================

/**
 * Met à jour le fichier .env avec les nouveaux secrets
 */
function updateEnvFile(newSecrets: Record<string, string>): void {
    const envPath = path.join(process.cwd(), '.env');

    if (!fs.existsSync(envPath)) {
        throw new Error('.env file not found');
    }

    let envContent = fs.readFileSync(envPath, 'utf-8');

    // Remplacer chaque secret
    for (const [key, value] of Object.entries(newSecrets)) {
        const regex = new RegExp(`^${key}=.*$`, 'm');
        
        if (regex.test(envContent)) {
            envContent = envContent.replace(regex, `${key}=${value}`);
            securityLogger.info(`[ROTATION] Updated ${key} in .env`);
        } else {
            securityLogger.warn(`[ROTATION] ${key} not found in .env, adding it`);
            envContent += `\n${key}=${value}`;
        }
    }

    // Mettre à jour la date de rotation
    const rotationDate = new Date().toISOString();
    const rotationRegex = /^SECRETS_LAST_ROTATION=.*$/m;
    
    if (rotationRegex.test(envContent)) {
        envContent = envContent.replace(rotationRegex, `SECRETS_LAST_ROTATION=${rotationDate}`);
    } else {
        envContent += `\nSECRETS_LAST_ROTATION=${rotationDate}`;
    }

    // Sauvegarder
    fs.writeFileSync(envPath, envContent, 'utf-8');
    securityLogger.info('[ROTATION] .env file updated successfully');
}

// ============================================
// VAULT UPDATE
// ============================================

/**
 * Met à jour les secrets dans Vault
 */
async function updateVaultSecrets(newSecrets: Record<string, string>): Promise<void> {
    try {
        await writeSecretsToVault(newSecrets);
        securityLogger.info('[ROTATION] Vault secrets updated successfully');
    } catch (error) {
        securityLogger.error('[ROTATION] Failed to update Vault secrets', { error });
        throw error;
    }
}

// ============================================
// BACKUP
// ============================================

/**
 * Crée une sauvegarde du .env actuel
 */
function backupEnvFile(): void {
    const envPath = path.join(process.cwd(), '.env');
    const backupPath = path.join(process.cwd(), '.env.backup.' + Date.now());

    if (fs.existsSync(envPath)) {
        fs.copyFileSync(envPath, backupPath);
        securityLogger.info(`[ROTATION] Backup created: ${backupPath}`);
        console.log(`✅ Backup créé : ${backupPath}`);
    }
}

// ============================================
// MAIN ROTATION FUNCTION
// ============================================

async function rotateSecrets() {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║           ROTATION DES SECRETS - MyPresc Backend          ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    const vaultEnabled = process.env.VAULT_ENABLED === 'true';

    try {
        // 1. Backup du .env actuel
        console.log('📦 Création du backup...');
        backupEnvFile();

        // 2. Générer les nouveaux secrets
        console.log('🔐 Génération des nouveaux secrets...');
        const newSecrets = generateNewSecrets();

        console.log('\n✅ Nouveaux secrets générés :');
        console.log(`   • JWT_SECRET: ${newSecrets.JWT_SECRET.substring(0, 20)}...`);
        console.log(`   • SESSION_SECRET: ${newSecrets.SESSION_SECRET.substring(0, 20)}...`);
        console.log(`   • ENCRYPTION_KEY: ${newSecrets.ENCRYPTION_KEY.substring(0, 20)}...`);

        // 3. Mettre à jour selon la configuration
        if (vaultEnabled) {
            console.log('\n🏦 Mode Vault activé - Mise à jour dans Vault...');
            await updateVaultSecrets(newSecrets);
        } else {
            console.log('\n📝 Mode .env - Mise à jour du fichier .env...');
            updateEnvFile(newSecrets);
        }

        // 4. Log de sécurité
        logSecretsRotation(Object.keys(newSecrets));

        console.log('\n╔════════════════════════════════════════════════════════════╗');
        console.log('║               ✅ ROTATION TERMINÉE AVEC SUCCÈS              ║');
        console.log('╚════════════════════════════════════════════════════════════╝\n');

        console.log('⚠️  IMPORTANT :');
        console.log('   1. Redémarrez le serveur backend immédiatement');
        console.log('   2. Invalidez toutes les sessions utilisateurs existantes');
        console.log('   3. Les tokens JWT existants seront invalides');
        console.log('   4. Vérifiez les logs : logs/security.log\n');

        if (!vaultEnabled) {
            console.log('💡 Conseil : En production, utilisez HashiCorp Vault');
            console.log('   Configurez VAULT_ENABLED=true dans .env\n');
        }

    } catch (error) {
        console.error('\n❌ ERREUR lors de la rotation des secrets :');
        console.error(error);
        securityLogger.error('[ROTATION] Secrets rotation failed', { error });
        process.exit(1);
    }
}

// ============================================
// EXECUTION
// ============================================

// Confirmation avant rotation
console.log('\n⚠️  ATTENTION : Vous êtes sur le point de ROTATIONNER TOUS LES SECRETS');
console.log('   Cela invalidera toutes les sessions et tokens existants.\n');

if (process.argv.includes('--force')) {
    rotateSecrets().then(() => process.exit(0));
} else {
    console.log('Pour continuer, relancez avec : bun run scripts/rotate-secrets.ts --force\n');
    process.exit(0);
}
