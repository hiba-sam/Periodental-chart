import { Pool } from 'pg';

const DATABASE_URL = process.env.DATABASE_URL;

async function checkAssistant() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: false
    });

    try {
        console.log('📊 Checking assistant data...\n');
        
        // Check assistant record
        const assistantResult = await pool.query(`
            SELECT a.id, a.user_id, a.doctor_id, a.assistant_email, a.is_active,
                   u.id as user_table_id, u.email as user_email, u.role
            FROM assistants a
            LEFT JOIN users u ON u.id = a.user_id
            WHERE a.assistant_email = 'assistant.laouaj@mypresc.com'
        `);
        
        console.log('📋 Assistant record:');
        console.log(JSON.stringify(assistantResult.rows, null, 2));
        
        // Check doctor
        const doctorResult = await pool.query(`
            SELECT u.id, u.name, u.family_name, u.email, u.role
            FROM users u
            WHERE u.id = 61
        `);
        
        console.log('\n👨‍⚕️ Doctor record:');
        console.log(JSON.stringify(doctorResult.rows, null, 2));
        
        // Check conversation members
        const convResult = await pool.query(`
            SELECT cm.*, c.type 
            FROM conversation_members cm
            JOIN conversations c ON c.id = cm.conversation_id
            WHERE cm.user_id IN (61, 62)
        `);
        
        console.log('\n💬 Conversation members:');
        console.log(JSON.stringify(convResult.rows, null, 2));

    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        await pool.end();
    }
}

checkAssistant();
