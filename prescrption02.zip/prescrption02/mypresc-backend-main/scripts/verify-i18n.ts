
import axios from 'axios';

const BASE_URL = 'http://localhost:3333';

async function verifyI18n() {
    console.log('Starting I18n Verification...');

    // 1. Verify LocalStrategy (Login) - English
    try {
        console.log('\n--- Testing Login (EN) ---');
        const resEn = await axios.post(`${BASE_URL}/auth/login`, {
            email: 'nonexistent@example.com',
            password: 'password123'
        }, {
            headers: { 'Accept-Language': 'en' },
            validateStatus: () => true
        });

        console.log(`Status: ${resEn.status}`);
        console.log(`Response:`, resEn.data);

        if (resEn.data.error === 'Incorrect email.') {
            console.log('✅ English Login Error confirmed');
        } else {
            console.log('❌ English Login Error Mismatch');
        }

    } catch (e: any) {
        console.error('Error testing EN login:', e.message);
    }

    // 2. Verify LocalStrategy (Login) - French
    try {
        console.log('\n--- Testing Login (FR) ---');
        const resFr = await axios.post(`${BASE_URL}/auth/login`, {
            email: 'nonexistent@example.com',
            password: 'password123'
        }, {
            headers: { 'Accept-Language': 'fr' },
            validateStatus: () => true
        });

        console.log(`Status: ${resFr.status}`);
        console.log(`Response:`, resFr.data);

        if (resFr.data.error === 'Email incorrect.') {
            console.log('✅ French Login Error confirmed');
        } else {
            console.log('❌ French Login Error Mismatch');
        }

    } catch (e: any) {
        console.error('Error testing FR login:', e.message);
    }

    // 3. Verify Registration Validation (Controller) - French
    try {
        console.log('\n--- Testing Registration Validation (FR) ---');
        // Missing required fields
        const resReg = await axios.post(`${BASE_URL}/auth/register`, {
            // Empty body to trigger validation
        }, {
            headers: { 'Accept-Language': 'fr' },
            validateStatus: () => true
        });

        console.log(`Status: ${resReg.status}`);
        console.log(`Response:`, resReg.data);

        // Key: auth.missing_fields_step1
        // FR Value: "Champs obligatoires manquants à l'étape 1 (prénom, nom, email, téléphone, spécialité)"

        if (resReg.data.error && resReg.data.error.includes("Champs obligatoires manquants à l'étape 1")) {
            console.log('✅ French Registration Validation confirmed');
        } else {
            console.log('❌ French Registration Validation Mismatch');
        }

    } catch (e: any) {
        console.error('Error testing Registration:', e.message);
    }
    // 4. Verify LocalStrategy (Login) - Arabic
    try {
        console.log('\n--- Testing Login (AR) ---');
        const resAr = await axios.post(`${BASE_URL}/auth/login`, {
            email: 'nonexistent@example.com',
            password: 'password123'
        }, {
            headers: { 'Accept-Language': 'ar' },
            validateStatus: () => true
        });

        console.log(`Status: ${resAr.status}`);
        console.log(`Response:`, resAr.data);

        if (resAr.data.error === 'البريد الإلكتروني غير صحيح.') {
            console.log('✅ Arabic Login Error confirmed');
        } else {
            console.log('❌ Arabic Login Error Mismatch');
        }

    } catch (e: any) {
        console.error('Error testing AR login:', e.message);
    }
}

verifyI18n();
