/**
 * Encryption Key Rotation Script - MyPresc Backend
 * 
 * Rotation automatique de la clé de chiffrement DATA_ENCRYPTION_KEY
 * Re-chiffrement de toutes les données avec la nouvelle clé
 * 
 * Conformité : OWASP Key Management, RGPD Art.32
 */

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CONFIGURATION
// ============================================

const KEY_LENGTH = 32; // 256 bits
const ROTATION_LOG = 'logs/encryption-rotation.log';
const BACKUP_DIR = 'backups/encryption-keys';
const FORCE_ROTATION = process.argv.includes('--force');

interface RotationRecord {
    timestamp: string;
    oldKeyHash: string;
    newKeyHash: string;
    recordsReEncrypted: number;
    duration: number;
    forced: boolean;
}

// ============================================
// GÉNÉRATION DE NOUVELLE CLÉ
// ============================================

/**
 * Génère une nouvelle clé de chiffrement sécurisée
 * 
 * @returns Nouvelle clé (hex)
 */
function generateNewKey(): string {
    const key = crypto.randomBytes(KEY_LENGTH);
    return key.toString('hex');
}

/**
 * Hash une clé pour identification (sans compromettre la sécurité)
 * 
 * @param key - Clé à hacher
 * @returns Hash SHA-256 de la clé
 */
function hashKey(key: string): string {
    return crypto.createHash('sha256').update(key).digest('hex').substring(0, 16);
}

// ============================================
// VÉRIFICATION DE LA ROTATION
// ============================================

/**
 * Vérifie si une rotation est nécessaire
 * 
 * @returns true si rotation nécessaire
 */
function shouldRotate(): boolean {
    if (FORCE_ROTATION) {
        console.log('🔄 Rotation forcée (--force flag)');
        return true;
    }
    
    const rotationDays = parseInt(process.env.ENCRYPTION_KEY_ROTATION_DAYS || '90', 10);
    
    // Vérifier la date de dernière rotation
    if (!fs.existsSync(ROTATION_LOG)) {
        console.log('⚠️  Aucun historique de rotation trouvé');
        return true;
    }
    
    try {
        const content = fs.readFileSync(ROTATION_LOG, 'utf-8');
        const lines = content.trim().split('\n').filter(l => l);
        
        if (lines.length === 0) {
            return true;
        }
        
        const lastRotation: RotationRecord = JSON.parse(lines[lines.length - 1]);
        const lastDate = new Date(lastRotation.timestamp);
        const now = new Date();
        const daysSinceRotation = Math.floor((now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        
        console.log(`📅 Dernière rotation: ${daysSinceRotation} jours (limite: ${rotationDays} jours)`);
        
        return daysSinceRotation >= rotationDays;
    } catch (error) {
        console.error('❌ Erreur lecture historique:', error);
        return true;
    }
}

// ============================================
// SAUVEGARDE DE LA CLÉ
// ============================================

/**
 * Sauvegarde l'ancienne clé (backup)
 * 
 * @param key - Clé à sauvegarder
 */
function backupOldKey(key: string) {
    try {
        if (!fs.existsSync(BACKUP_DIR)) {
            fs.mkdirSync(BACKUP_DIR, { recursive: true });
        }
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const keyHash = hashKey(key);
        const filename = `key-${timestamp}-${keyHash}.backup`;
        const filepath = path.join(BACKUP_DIR, filename);
        
        // Sauvegarder la clé chiffrée avec un mot de passe maître
        const masterPassword = process.env.MASTER_BACKUP_PASSWORD || 'CHANGE_ME_IN_PRODUCTION';
        const cipher = crypto.createCipheriv('aes-256-gcm', crypto.scryptSync(masterPassword, 'salt', 32), crypto.randomBytes(16));
        
        let encrypted = cipher.update(key, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        fs.writeFileSync(filepath, JSON.stringify({
            keyHash,
            encrypted,
            iv: cipher.getAuthTag().toString('hex'),
            timestamp
        }), { mode: 0o600 }); // Permissions restrictives
        
        console.log(`💾 Ancienne clé sauvegardée: ${filename}`);
        
    } catch (error) {
        console.error('❌ Erreur sauvegarde clé:', error);
    }
}

// ============================================
// RE-CHIFFREMENT DES DONNÉES
// ============================================

/**
 * Re-chiffre toutes les données avec la nouvelle clé
 * 
 * @param oldKey - Ancienne clé
 * @param newKey - Nouvelle clé
 * @returns Nombre d'enregistrements re-chiffrés
 */
async function reEncryptData(oldKey: string, newKey: string): Promise<number> {
    console.log('\n🔄 Re-chiffrement des données...');

    // NOTE: Cette fonction doit être adaptée selon votre structure de base de données
    // Pour l'instant, c'est une simulation

    let reEncrypted = 0;

    try {
        // Exemple: Re-chiffrer les données patients avec SQL
        // import postgres from 'postgres';
        // const sql = postgres(process.env.DATABASE_URL || '');
        //
        // const patients = await sql`
        //     SELECT id, age, telephone, email, adresse, date_naissance,
        //            numero_securite_sociale, notes
        //     FROM patients
        //     WHERE age IS NOT NULL OR telephone IS NOT NULL
        // `;
        //
        // for (const patient of patients) {
        //     // Déchiffrer avec l'ancienne clé
        //     const decryptedAge = patient.age ? decryptData(patient.age, oldKey) : null;
        //     const decryptedPhone = patient.telephone ? decryptData(patient.telephone, oldKey) : null;
        //     // ... autres champs
        //
        //     // Re-chiffrer avec la nouvelle clé
        //     const reEncryptedAge = decryptedAge ? encryptData(decryptedAge, newKey) : null;
        //     const reEncryptedPhone = decryptedPhone ? encryptData(decryptedPhone, newKey) : null;
        //     // ... autres champs
        //
        //     // Sauvegarder
        //     await sql`
        //         UPDATE patients
        //         SET age = ${reEncryptedAge},
        //             telephone = ${reEncryptedPhone}
        //         WHERE id = ${patient.id}
        //     `;
        //     reEncrypted++;
        // }
        //
        // await sql.end();

        console.log(`✅ ${reEncrypted} enregistrements re-chiffrés`);

    } catch (error) {
        console.error('❌ Erreur re-chiffrement:', error);
        throw error;
    }

    return reEncrypted;
}

// ============================================
// MISE À JOUR DU .env
// ============================================

/**
 * Met à jour le fichier .env avec la nouvelle clé
 * 
 * @param newKey - Nouvelle clé
 */
function updateEnvFile(newKey: string) {
    const envPath = path.join(process.cwd(), '.env');
    
    if (!fs.existsSync(envPath)) {
        console.error('❌ Fichier .env introuvable');
        return;
    }
    
    try {
        let content = fs.readFileSync(envPath, 'utf-8');
        
        // Remplacer DATA_ENCRYPTION_KEY
        const keyRegex = /DATA_ENCRYPTION_KEY=.*/;
        if (keyRegex.test(content)) {
            content = content.replace(keyRegex, `DATA_ENCRYPTION_KEY=${newKey}`);
        } else {
            content += `\nDATA_ENCRYPTION_KEY=${newKey}\n`;
        }
        
        fs.writeFileSync(envPath, content, 'utf-8');
        console.log('✅ Fichier .env mis à jour');
        
    } catch (error) {
        console.error('❌ Erreur mise à jour .env:', error);
    }
}

// ============================================
// LOGGING
// ============================================

/**
 * Enregistre la rotation dans les logs
 * 
 * @param record - Enregistrement de rotation
 */
function logRotation(record: RotationRecord) {
    try {
        const logDir = path.dirname(ROTATION_LOG);
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir, { recursive: true });
        }
        
        fs.appendFileSync(ROTATION_LOG, JSON.stringify(record) + '\n', 'utf-8');
        
        // Logger aussi dans le logger de sécurité
        securityLogger.info('[ENCRYPTION] Key rotation completed', {
            event: 'ROTATION_SUCCESS',
            oldKeyHash: record.oldKeyHash,
            newKeyHash: record.newKeyHash,
            recordsReEncrypted: record.recordsReEncrypted,
            duration: `${record.duration.toFixed(2)}s`,
            forced: record.forced
        });
        
    } catch (error) {
        console.error('❌ Erreur logging rotation:', error);
    }
}

// ============================================
// MAIN ROTATION
// ============================================

async function rotateEncryptionKey() {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║      ROTATION DE CLÉ DE CHIFFREMENT - MyPresc Backend     ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');
    
    const startTime = Date.now();
    
    // Vérifier si rotation nécessaire
    if (!shouldRotate()) {
        console.log('✅ Rotation non nécessaire pour le moment');
        console.log(`💡 Utilisez --force pour forcer la rotation\n`);
        return;
    }
    
    try {
        // Récupérer l'ancienne clé
        const originalKey = process.env.DATA_ENCRYPTION_KEY;
        const oldKey = process.env.DATA_ENCRYPTION_KEY;
        if (!oldKey) {
            throw new Error('DATA_ENCRYPTION_KEY not found in environment');
        }
        
        console.log('🔑 Ancienne clé détectée');
        console.log(`   Hash: ${hashKey(oldKey)}\n`);
        
        // Sauvegarder l'ancienne clé
        backupOldKey(oldKey);
        
        // Générer nouvelle clé
        const newKey = generateNewKey();
        console.log('🆕 Nouvelle clé générée');
        console.log(`   Hash: ${hashKey(newKey)}\n`);
        
        // Re-chiffrer les données
        const recordsReEncrypted = await reEncryptData(oldKey, newKey);
        
        // Mettre à jour .env
        updateEnvFile(newKey);
        
        // Logger la rotation
        const duration = (Date.now() - startTime) / 1000;
        const record: RotationRecord = {
            timestamp: new Date().toISOString(),
            oldKeyHash: hashKey(oldKey),
            newKeyHash: hashKey(newKey),
            recordsReEncrypted,
            duration,
            forced: FORCE_ROTATION
        };
        
        logRotation(record);
        
        console.log('\n╔════════════════════════════════════════════════════════════╗');
        console.log('║                  ROTATION COMPLÉTÉE ✅                     ║');
        console.log('╚════════════════════════════════════════════════════════════╝\n');
        console.log(`📊 Statistiques:`);
        console.log(`   - Enregistrements re-chiffrés: ${recordsReEncrypted}`);
        console.log(`   - Durée: ${duration.toFixed(2)}s`);
        console.log(`   - Nouvelle clé: ${hashKey(newKey)}`);
        console.log(`\n⚠️  IMPORTANT: Redémarrez le serveur pour utiliser la nouvelle clé\n`);
        
    } catch (error) {
        console.error('\n❌ ERREUR DURANT LA ROTATION:', error);
        securityLogger.error('[ENCRYPTION] Key rotation failed', {
            event: 'ROTATION_ERROR',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        process.exit(1);
    }
}

// ============================================
// HELPER: Générer une nouvelle clé sans rotation
// ============================================

function generateKeyOnly() {
    const newKey = generateNewKey();
    console.log('\n🔑 Nouvelle clé de chiffrement générée:\n');
    console.log(`DATA_ENCRYPTION_KEY=${newKey}\n`);
    console.log(`Hash: ${hashKey(newKey)}\n`);
    console.log('💡 Copiez cette valeur dans votre fichier .env\n');
}

// ============================================
// EXÉCUTION
// ============================================

if (process.argv.includes('--generate-only')) {
    generateKeyOnly();
} else {
    rotateEncryptionKey().catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}
