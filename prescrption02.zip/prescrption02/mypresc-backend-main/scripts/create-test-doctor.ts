import pool from '../db';
import bcrypt from 'bcrypt';

async function createTestDoctor() {
    const client = await pool.connect();
    
    try {
        await client.query('BEGIN');
        
        // Données du docteur de test
        const email = 'docteur.test@mypresc.dz';
        const password = 'Test1234!';
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Vérifier si le docteur existe déjà
        const existingUser = await client.query(
            'SELECT id FROM users WHERE email = $1',
            [email]
        );
        
        if (existingUser.rows.length > 0) {
            console.log('❌ Le docteur de test existe déjà avec cet email');
            console.log('📧 Email:', email);
            console.log('🔑 Mot de passe:', password);
            console.log('🆔 User ID:', existingUser.rows[0].id);
            await client.query('ROLLBACK');
            return;
        }
        
        // Créer l'utilisateur
        const trialEndDate = new Date();
        trialEndDate.setDate(trialEndDate.getDate() + 14);

        const userResult = await client.query(`
            INSERT INTO users (email, password, name, family_name, role, is_active, plan, end_date)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        `, [email, hashedPassword, 'Docteur', 'Test', 'doctor', true, 'test', trialEndDate]);
        
        const userId = userResult.rows[0].id;
        
        // Créer le profil docteur
        await client.query(`
            INSERT INTO doctors (
                user_id, birth_date, birth_place, work_location,
                home_location, diploma_file, certificates, order_num,
                order_num_file, id_card_file, phone_number, work_time,
                languages, about, speciality, experience, nin
            ) VALUES (
                $1, $2, $3, $4,
                $5, $6, $7, $8,
                $9, $10, $11, $12,
                $13, $14, $15, $16,
                $17
            )
        `, [
            userId,
            '1985-01-15', // birth_date
            'Alger', // birth_place
            'Alger Centre', // work_location
            'Alger', // home_location
            ['diploma_test.pdf'], // diploma_file
            [], // certificates
            'ORD-TEST-001', // order_num
            'ordre_test.pdf', // order_num_file
            'id_card_test.pdf', // id_card_file
            '0555123456', // phone_number
            {}, // work_time
            ["arabic", "français"], // languages
            '', // about
            'Médecine Générale', // speciality
            0, // experience
            '123456789012345' // nin
        ]);

        // Créer les tarifications par défaut
        const DEFAULT_SERVICES = [
            { service_label: "Consultation générale", price: 2000 },
            { service_label: "Consultation de suivi", price: 2500 },
            { service_label: "Consultation durgence", price: 3000 }
        ];

        for (const service of DEFAULT_SERVICES) {
            await client.query(`
                INSERT INTO tarifications (doctor_user_id, service_label, price)
                VALUES ($1, $2, $3)
            `, [userId, service.service_label, service.price]);
        }
        
        await client.query('COMMIT');
        
        console.log('✅ Docteur de test créé avec succès!');
        console.log('');
        console.log('📧 Email:', email);
        console.log('🔑 Mot de passe:', password);
        console.log('🆔 User ID:', userId);
        console.log('');
        console.log('Vous pouvez maintenant vous connecter avec ces identifiants.');
        
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Erreur lors de la création du docteur:', error);
    } finally {
        client.release();
        process.exit(0);
    }
}

createTestDoctor();
