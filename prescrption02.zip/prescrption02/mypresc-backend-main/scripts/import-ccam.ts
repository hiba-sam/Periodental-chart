import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATABASE_URL = process.env.DATABASE_URL;

interface CCAMRow {
    code_ccam: string;
    code_short: string;
    label: string;
    chapter_code: string;
    chapter_label: string;
    parent_code: string;
    parent_label: string;
    topography: string;
    topography_label: string;
    action: string;
    action_label: string;
    mode_access: string;
    mode_access_label: string;
    family_code: string;
    family_label: string;
}

// Dental keywords for filtering
const DENTAL_KEYWORDS = [
    'dent', 'dentaire', 'dental',
    'extraction', 'avulsion',
    'obturation', 'composite', 'amalgame',
    'parodont', 'gencive', 'gingiv',
    'pulpe', 'pulpaire', 'endodont', 'canal radiculaire',
    'couronne', 'bridge', 'prothèse dentaire',
    'implant dentaire', 'implant oral',
    'orthodont', 'appareil dentaire',
    'détartrage', 'prophylaxie',
    'carie', 'cavité',
    'maxillaire', 'mandibul',
    'occlus', 'articulé',
    'stomatolog', 'bucco', 'buccal',
    'incisive', 'canine', 'prémolaire', 'molaire',
    'racine dentaire', 'apex', 'apical',
    'émail', 'dentine', 'cément',
    'kyste dentaire', 'granulome',
    'alvéol', 'alvéole'
];

function isDentalAct(row: CCAMRow): boolean {
    // 1. Check topography_label
    const topographyLower = row.topography_label.toLowerCase();
    if (topographyLower.includes('dent') || 
        topographyLower.includes('parodonte') || 
        topographyLower.includes('gencive')) {
        return true;
    }

    // 2. Check for dental keywords in label, family_label, chapter_label
    const searchText = [
        row.label,
        row.family_label,
        row.chapter_label,
        row.parent_label,
        row.action_label
    ].join(' ').toLowerCase();

    for (const keyword of DENTAL_KEYWORDS) {
        if (searchText.includes(keyword.toLowerCase())) {
            return true;
        }
    }

    return false;
}

function parseCSVLine(line: string): string[] {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        
        if (char === '"') {
            if (inQuotes && line[i + 1] === '"') {
                current += '"';
                i++;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    result.push(current.trim());
    
    return result;
}

async function importCCAM() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: false
    });

    try {
        console.log('🔄 Starting CCAM import...');
        console.log('');

        // Read CSV file
        const csvPath = path.join(__dirname, '..', 'jsons', 'ccam-acts.csv');
        
        if (!fs.existsSync(csvPath)) {
            throw new Error(`CSV file not found at: ${csvPath}`);
        }

        const fileContent = fs.readFileSync(csvPath, 'utf8');
        const lines = fileContent.split('\n').filter(line => line.trim());
        
        console.log(`📄 Found ${lines.length} lines in CSV`);

        // Skip header
        const dataLines = lines.slice(1);
        console.log(`📊 Processing ${dataLines.length} data rows...`);

        // Check existing count
        const existingResult = await pool.query('SELECT COUNT(*) FROM act_catalog');
        const existingCount = parseInt(existingResult.rows[0].count);
        
        if (existingCount > 0) {
            console.log(`⚠️  Found ${existingCount} existing acts in catalog.`);
            console.log('   Use --force to clear and reimport.');
            
            if (!process.argv.includes('--force')) {
                console.log('');
                console.log('✅ Import skipped (data already exists)');
                return;
            }
            
            console.log('🗑️  Clearing existing data (--force flag detected)...');
            await pool.query('TRUNCATE TABLE act_catalog RESTART IDENTITY CASCADE');
        }

        // Prepare batch insert
        const batchSize = 500;
        let inserted = 0;
        let errors = 0;
        let batch: CCAMRow[] = [];

        const insertBatch = async (rows: CCAMRow[]) => {
            if (rows.length === 0) return;

            const values: any[] = [];
            const placeholders: string[] = [];
            let paramIndex = 1;

            for (const row of rows) {
                placeholders.push(`($${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++}, $${paramIndex++})`);
                values.push(
                    row.code_ccam,
                    row.code_short,
                    row.label,
                    row.chapter_code,
                    row.chapter_label,
                    row.parent_code,
                    row.parent_label,
                    row.topography,
                    row.topography_label,
                    row.action,
                    row.action_label,
                    row.mode_access,
                    row.mode_access_label,
                    row.family_code,
                    row.family_label
                );
            }

            const query = `
                INSERT INTO act_catalog (
                    code_ccam, code_short, label, chapter_code, chapter_label,
                    parent_code, parent_label, topography, topography_label,
                    action, action_label, mode_access, mode_access_label,
                    family_code, family_label
                ) VALUES ${placeholders.join(', ')}
                ON CONFLICT (code_ccam) DO NOTHING
            `;

            await pool.query(query, values);
        };

        for (let i = 0; i < dataLines.length; i++) {
            try {
                const fields = parseCSVLine(dataLines[i]);
                
                if (fields.length < 16) {
                    errors++;
                    continue;
                }

                const row: CCAMRow = {
                    code_ccam: fields[0] || '',
                    code_short: fields[1] || '',
                    label: fields[2] || '',
                    chapter_code: fields[3] || '',
                    chapter_label: fields[4] || '',
                    parent_code: fields[5] || '',
                    parent_label: fields[6] || '',
                    topography: fields[7] || '',
                    topography_label: fields[8] || '',
                    action: fields[9] || '',
                    action_label: fields[10] || '',
                    mode_access: fields[11] || '',
                    mode_access_label: fields[12] || '',
                    family_code: fields[14] || '',
                    family_label: fields[15] || ''
                };

                if (!row.code_ccam || !row.label) {
                    errors++;
                    continue;
                }

                // Filter: only dental acts
                const isDental = isDentalAct(row);
                if (!isDental) {
                    continue; // Skip non-dental acts
                }

                batch.push(row);

                if (batch.length >= batchSize) {
                    await insertBatch(batch);
                    inserted += batch.length;
                    batch = [];
                    process.stdout.write(`\r   Inserted: ${inserted} rows...`);
                }
            } catch (err) {
                errors++;
            }
        }

        // Insert remaining batch
        if (batch.length > 0) {
            await insertBatch(batch);
            inserted += batch.length;
        }

        console.log('');
        console.log('');
        console.log('═══════════════════════════════════════════');
        console.log('📊 CCAM Import Summary');
        console.log('═══════════════════════════════════════════');
        console.log(`   ✅ Rows inserted: ${inserted}`);
        console.log(`   ❌ Rows skipped (errors): ${errors}`);
        console.log('');

        // Verify
        const finalCount = await pool.query('SELECT COUNT(*) FROM act_catalog');
        console.log(`📈 Total acts in catalog: ${finalCount.rows[0].count}`);
        console.log('');
        console.log('✅ CCAM import completed successfully!');

    } catch (error) {
        console.error('❌ CCAM import failed:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

// Run import
importCCAM();
