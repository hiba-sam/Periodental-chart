
import pool from '../db';
import { UserModel } from '../models/user.model';
import { DoctorModel } from '../models/doctor.model';

async function checkDoctors() {
    console.log("Checking doctors status...");
    const result = await pool.query("SELECT id, name, family_name, email, role FROM users WHERE role = 'doctor'");
    const doctors = result.rows;

    console.log(`Found ${doctors.length} users with role 'doctor'.`);

    for (const doc of doctors) {
        const profile = await DoctorModel.findByUserId(doc.id);
        if (profile) {
            console.log(`✅ [${doc.id}] ${doc.name} ${doc.family_name} (${doc.email}) has a profile.`);
        } else {
            console.log(`❌ [${doc.id}] ${doc.name} ${doc.family_name} (${doc.email}) is MISSING a profile!`);
        }
    }
}

checkDoctors().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
