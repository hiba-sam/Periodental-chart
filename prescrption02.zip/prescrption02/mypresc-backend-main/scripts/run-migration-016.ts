/**
 * Script pour exécuter la migration 016 - Création de la table medical_reports
 */

import pkg from 'pg';
const { Pool } = pkg;
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false,
    },
});

async function runMigration(): Promise<void> {
    const client = await pool.connect();
    
    try {
        console.log('🚀 Exécution de la migration 016_create_medical_reports_table.sql...\n');
        
        // Lire le fichier SQL
        const migrationPath = path.join(__dirname, '../migrations/016_create_medical_reports_table.sql');
        const sql = fs.readFileSync(migrationPath, 'utf8');
        
        // Exécuter la migration
        await client.query('BEGIN');
        await client.query(sql);
        await client.query('COMMIT');
        
        console.log('✅ Migration 016 exécutée avec succès!\n');
        console.log('📋 Table créée: medical_reports');
        console.log('📋 Indexes créés:');
        console.log('   - idx_medical_reports_patient_id');
        console.log('   - idx_medical_reports_doctor_user_id');
        console.log('   - idx_medical_reports_examination_date');
        console.log('   - idx_medical_reports_created_at');
        console.log('\n✨ Le système de comptes rendus médicaux est maintenant opérationnel!\n');
        
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('❌ Erreur lors de l\'exécution de la migration:', (error as Error).message);
        console.error('\nDétails:', error);
        process.exit(1);
    } finally {
        client.release();
        await pool.end();
    }
}

runMigration();
