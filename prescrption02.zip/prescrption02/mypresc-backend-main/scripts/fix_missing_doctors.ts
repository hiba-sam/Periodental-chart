
import pool from '../db';
import { DoctorModel, type CreateDoctorData } from '../models/doctor.model';

async function fixMissingDoctors() {
    console.log("Fixing missing doctor profiles...");
    
    // Get all doctors from users table
    const result = await pool.query("SELECT id, name, family_name, email FROM users WHERE role = 'doctor'");
    const doctors = result.rows;

    for (const doc of doctors) {
        const profile = await DoctorModel.findByUserId(doc.id);
        
        if (!profile) {
            console.log(`Creating profile for: ${doc.name} ${doc.family_name} (${doc.email})...`);
            
            const doctorData: CreateDoctorData = {
                user_id: doc.id,
                birth_date: new Date('1980-01-01'),
                birth_place: 'Unknown',
                work_location: 'Default Cabinet',
                home_location: 'Default Address',
                diploma_file: ['default_diploma.pdf'],
                order_num: `PENDING-${doc.id}`,
                order_num_file: 'default_order.pdf',
                id_card_file: 'default_id.pdf',
                phone_number: '0000000000',
                about: 'Profil généré automatiquement.',
                speciality: 'Généraliste',
                experience: 0,
                nin: `NIN-${doc.id}`
            };

            try {
                await DoctorModel.create(doctorData);
                console.log(`✅ Successfully created profile for ${doc.email}`);
            } catch (err) {
                console.error(`❌ Failed to create profile for ${doc.email}:`, err);
            }
        }
    }
    
    console.log("Finished fixing doctor profiles.");
}

fixMissingDoctors().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
