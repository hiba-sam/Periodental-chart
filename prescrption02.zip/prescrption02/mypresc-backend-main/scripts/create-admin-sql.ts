/**
 * Create Admin Account (SQL Version) - MyPresc Backend
 * 
 * Script pour créer un compte administrateur avec SQL direct
 * Fonctionne avec votre structure de base de données existante
 */

import postgres from 'postgres';
import bcrypt from 'bcrypt';

// ============================================
// CONNEXION BASE DE DONNÉES
// ============================================

const sql = postgres(process.env.DATABASE_URL || '');

// ============================================
// COMPTES À CRÉER
// ============================================

const ADMIN_ACCOUNTS = [
    {
        email: 'admin@mypresc.dz',
        password: 'Admin@MyPresc2025!',
        firstName: 'Admin',
        lastName: 'System',
        role: 'admin'
    },
    {
        email: 'dev@mypresc.dz',
        password: 'Dev@MyPresc2025!',
        firstName: 'Developer',
        lastName: 'Team',
        role: 'admin'
    }
];

const TEST_ACCOUNTS = [
    {
        email: 'doctor@test.dz',
        password: 'Doctor@Test2025!',
        firstName: 'Dr. Ahmed',
        lastName: 'Benali',
        role: 'doctor'
    },
    {
        email: 'assistant@test.dz',
        password: 'Assistant@Test2025!',
        firstName: 'Fatima',
        lastName: 'Kaci',
        role: 'assistant'
    },
    {
        email: 'patient@test.dz',
        password: 'Patient@Test2025!',
        firstName: 'Mohammed',
        lastName: 'Saidi',
        role: 'patient'
    }
];

// ============================================
// FONCTIONS
// ============================================

async function createUser(userData: any) {
    try {
        // Vérifier si l'utilisateur existe déjà
        const existing = await sql`
            SELECT id, email FROM users 
            WHERE email = ${userData.email}
        `;

        if (existing.length > 0) {
            console.log(`⚠️  ${userData.email} existe déjà (ID: ${existing[0].id})`);
            return existing[0];
        }

        // Hacher le mot de passe
        const hashedPassword = await bcrypt.hash(userData.password, 12);

        // Insérer l'utilisateur (avec la structure réelle de votre DB)
        const result = await sql`
            INSERT INTO users (
                email, 
                password, 
                name, 
                family_name, 
                role,
                is_active,
                created_at,
                updated_at
            )
            VALUES (
                ${userData.email},
                ${hashedPassword},
                ${userData.firstName},
                ${userData.lastName},
                ${userData.role},
                true,
                NOW(),
                NOW()
            )
            RETURNING id, email, role
        `;

        const user = result[0];
        console.log(`✅ ${userData.role.toUpperCase().padEnd(10)} créé: ${userData.email}`);
        console.log(`   ID: ${user.id}`);
        console.log(`   Mot de passe: ${userData.password}`);
        
        return user;
        
    } catch (error: any) {
        console.error(`❌ Erreur création ${userData.email}:`, error.message);
        return null;
    }
}

// ============================================
// MAIN
// ============================================

async function main() {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║          CRÉATION COMPTES ADMIN & TEST - MyPresc           ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    try {
        // Tester la connexion DB
        await sql`SELECT 1`;
        console.log('✅ Connexion base de données OK\n');

        // Créer les comptes admin
        console.log('📋 CRÉATION COMPTES ADMIN\n');
        console.log('─'.repeat(60));
        
        for (const admin of ADMIN_ACCOUNTS) {
            await createUser(admin);
        }

        console.log('\n📋 CRÉATION COMPTES TEST\n');
        console.log('─'.repeat(60));
        
        for (const test of TEST_ACCOUNTS) {
            await createUser(test);
        }

        // Afficher le récapitulatif
        console.log('\n╔════════════════════════════════════════════════════════════╗');
        console.log('║                    RÉCAPITULATIF                           ║');
        console.log('╚════════════════════════════════════════════════════════════╝\n');

        console.log('🔐 COMPTES ADMIN (Production):\n');
        ADMIN_ACCOUNTS.forEach(admin => {
            console.log(`   Email:    ${admin.email}`);
            console.log(`   Password: ${admin.password}`);
            console.log('');
        });

        console.log('🧪 COMPTES TEST (Développement):\n');
        TEST_ACCOUNTS.forEach(test => {
            console.log(`   [${test.role.toUpperCase()}] ${test.email}`);
            console.log(`   Password: ${test.password}`);
            console.log('');
        });

        console.log('⚠️  IMPORTANT:\n');
        console.log('   1. Changez les mots de passe admin en production !');
        console.log('   2. Supprimez les comptes test en production !');
        console.log('   3. Sauvegardez ces identifiants dans un endroit sûr.\n');

        console.log('✅ Tous les comptes ont été créés avec succès !\n');

    } catch (error: any) {
        console.error('\n❌ ERREUR:', error.message);
        process.exit(1);
    } finally {
        await sql.end();
    }
}

// Exécuter
main().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
