
import pool from '../db';
import { DoctorModel } from '../models/doctor.model';

async function setSpecialty() {
    const emails = ['perio@test.com', 'parodontologie@test.com', 'paro@test.com'];
    
    console.log("Setting specialty to Parodontologie for specialized accounts...");

    for (const email of emails) {
        const result = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
        if (result.rows.length > 0) {
            const userId = result.rows[0].id;
            console.log(`Updating user ${email} (ID: ${userId})...`);
            
            await pool.query(
                "UPDATE doctors SET speciality = $1 WHERE user_id = $2",
                ['Parodontologie', userId]
            );
            console.log(`✅ Specialty updated for ${email}`);
        } else {
            console.log(`⚠️ User ${email} not found.`);
        }
    }
}

setSpecialty().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
