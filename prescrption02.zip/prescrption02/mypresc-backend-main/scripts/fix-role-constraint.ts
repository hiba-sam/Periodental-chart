/**
 * Fix Role Constraint - MyPresc Backend
 * 
 * Ajoute les rôles 'admin' et 'patient' à la contrainte users_role_check
 */

import postgres from 'postgres';

const sql = postgres(process.env.DATABASE_URL || '');

async function fixRoleConstraint() {
    console.log('\n🔧 Modification de la contrainte users_role_check...\n');
    
    try {
        // 1. Supprimer l'ancienne contrainte
        console.log('📌 Étape 1: Suppression de l\'ancienne contrainte...');
        await sql`
            ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check
        `;
        console.log('✅ Ancienne contrainte supprimée\n');
        
        // 2. Ajouter la nouvelle contrainte avec tous les rôles
        console.log('📌 Étape 2: Ajout de la nouvelle contrainte...');
        await sql`
            ALTER TABLE users 
            ADD CONSTRAINT users_role_check 
            CHECK (role IN ('doctor', 'assistant', 'admin', 'patient'))
        `;
        console.log('✅ Nouvelle contrainte ajoutée\n');
        
        console.log('╔════════════════════════════════════════════════════════════╗');
        console.log('║                    SUCCÈS ✅                               ║');
        console.log('╚════════════════════════════════════════════════════════════╝\n');
        console.log('Les rôles autorisés sont maintenant:');
        console.log('   ✅ doctor');
        console.log('   ✅ assistant');
        console.log('   ✅ admin');
        console.log('   ✅ patient\n');
        console.log('Vous pouvez maintenant exécuter: bun run create-admin\n');
        
    } catch (error: any) {
        console.error('❌ ERREUR:', error.message);
        process.exit(1);
    } finally {
        await sql.end();
    }
}

fixRoleConstraint();
