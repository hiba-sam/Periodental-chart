import pool from '../db';

async function updateSpecialty() {
    try {
        // Check current state
        const find = await pool.query(`
            SELECT u.id, u.name, u.family_name, d.speciality 
            FROM users u 
            JOIN doctors d ON d.user_id = u.id 
            WHERE u.role = 'doctor'
            ORDER BY u.id
        `);
        console.log('Current doctors:', find.rows);
        process.exit(0);
    } catch (error) {
        console.error('❌ Erreur:', error);
        process.exit(1);
    }
}

updateSpecialty();
