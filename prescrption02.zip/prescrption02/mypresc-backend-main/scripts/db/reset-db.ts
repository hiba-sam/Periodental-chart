import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;

// Tables to EXCLUDE from reset (preserve user data)
const EXCLUDED_TABLES = ['users', 'admins', 'assistants', 'doctors', 'medications'];

// All application tables in the correct order for truncation (respecting foreign key dependencies)
// Order matters: child tables first, then parent tables
const TABLES_TO_RESET = [
    // Audit and logging tables
    'patient_access_logs',
    'medical_share_audit_logs',

    // Medical sharing
    'medical_shares',

    // Messaging
    'messages',
    'message_attachments',
    'conversation_participants',
    'conversations',

    // Prescriptions and medications
    'prescription_history',
    'prescription_medications',
    'prescriptions',
    'custom_medications',

    // Medical reports
    'ai_medical_report_quota',
    'medical_reports',

    // Financial tables
    'consultation_invoices',
    'invoices',
    'payments',

    // Appointments and waiting room
    'waiting_room',
    'appointments',

    // Calendar and notifications
    'calendar',
    'notifications',

    // Demands and tarifications
    'demands',
    'tarifications',

    // Doctor-patient relationship
    'doctor_patient_privacy',
    'doctor_transitions',

    // Presence tracking
    'presence',

    // Tokens (for password reset, etc.)
    'tokens',

    // Main entities (order matters due to FK constraints)
    'patients',
];

async function resetDatabase() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: false
    });

    try {
        console.log('🔄 Connecting to database...');
        console.log('');
        console.log('⚠️  WARNING: This will DELETE ALL DATA from the following tables:');
        console.log('');
        TABLES_TO_RESET.forEach(table => console.log(`   - ${table}`));
        console.log('');
        console.log(`✅ Tables that will be PRESERVED: ${EXCLUDED_TABLES.join(', ')}`);
        console.log('');

        // Safety prompt - wait 5 seconds
        console.log('⏳ Starting in 5 seconds... Press Ctrl+C to cancel.');
        await new Promise(resolve => setTimeout(resolve, 5000));

        console.log('');
        console.log('🚀 Starting database reset...');
        console.log('');

        // Start a transaction
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            let successCount = 0;
            let skippedCount = 0;
            const errors: string[] = [];

            for (const table of TABLES_TO_RESET) {
                try {
                    // Check if table exists
                    const tableExistsResult = await client.query(`
                        SELECT EXISTS (
                            SELECT FROM information_schema.tables 
                            WHERE table_schema = 'public' 
                            AND table_name = $1
                        );
                    `, [table]);

                    if (!tableExistsResult.rows[0].exists) {
                        console.log(`   ⏭️  Skipping ${table} (table does not exist)`);
                        skippedCount++;
                        continue;
                    }

                    // Get row count before truncation
                    const countResult = await client.query(`SELECT COUNT(*) as count FROM "${table}"`);
                    const rowCount = parseInt(countResult.rows[0].count, 10);

                    // Truncate the table and reset identity (CASCADE handles FK constraints)
                    await client.query(`TRUNCATE TABLE "${table}" RESTART IDENTITY CASCADE`);

                    console.log(`   ✅ Cleared ${table} (${rowCount} rows deleted)`);
                    successCount++;
                } catch (tableError: any) {
                    console.log(`   ❌ Error clearing ${table}: ${tableError.message}`);
                    errors.push(`${table}: ${tableError.message}`);
                }
            }

            await client.query('COMMIT');

            console.log('');
            console.log('═══════════════════════════════════════════');
            console.log('📊 Database Reset Summary');
            console.log('═══════════════════════════════════════════');
            console.log(`   ✅ Tables cleared: ${successCount}`);
            console.log(`   ⏭️  Tables skipped: ${skippedCount}`);
            console.log(`   ❌ Errors: ${errors.length}`);
            console.log('');

            if (errors.length > 0) {
                console.log('⚠️  Errors encountered:');
                errors.forEach(err => console.log(`   - ${err}`));
                console.log('');
            }

            console.log(`🔐 Preserved tables: ${EXCLUDED_TABLES.join(', ')}`);
            console.log('');
            console.log('✅ Database reset completed successfully!');
            console.log('');

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }

    } catch (error) {
        console.error('❌ Failed to reset database:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

// Run the reset
resetDatabase();
