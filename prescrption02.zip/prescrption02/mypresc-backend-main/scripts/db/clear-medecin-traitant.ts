import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function clearMedecinTraitant(): Promise<void> {
  try {
    console.log('🔄 Clearing medecin_traitant_id for all patients...');
    
    const result = await pool.query('UPDATE patients SET medecin_traitant_id = NULL');
    
    console.log(`✅ Done! ${result.rowCount} patients updated.`);
  } catch (error) {
    console.error('❌ Error:', (error as Error).message);
  } finally {
    await pool.end();
  }
}

clearMedecinTraitant();
