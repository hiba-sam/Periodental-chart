import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function createDoctorTransitionsTable(): Promise<void> {
  try {
    console.log('🔄 Creating doctor_transitions table...');
    
    const query = `
      CREATE TABLE IF NOT EXISTS doctor_transitions (
        id SERIAL PRIMARY KEY,
        patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
        previous_doctor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        new_doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        comment TEXT NOT NULL,
        transition_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      
      CREATE INDEX IF NOT EXISTS idx_doctor_transitions_patient_id ON doctor_transitions(patient_id);
      CREATE INDEX IF NOT EXISTS idx_doctor_transitions_previous_doctor ON doctor_transitions(previous_doctor_id);
      CREATE INDEX IF NOT EXISTS idx_doctor_transitions_new_doctor ON doctor_transitions(new_doctor_id);
    `;
    
    await pool.query(query);
    
    console.log('✅ Table doctor_transitions created successfully!');
  } catch (error) {
    console.error('❌ Error:', (error as Error).message);
  } finally {
    await pool.end();
  }
}

createDoctorTransitionsTable();
