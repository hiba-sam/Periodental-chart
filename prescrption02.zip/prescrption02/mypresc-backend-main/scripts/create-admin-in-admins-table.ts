/**
 * Create Admin in ADMINS table - MyPresc Backend
 * Crée les comptes admin dans la table 'admins' (pas 'users')
 */

import pool from '../db';
import bcrypt from 'bcrypt';
import { BCRYPT_ROUNDS } from '../config/security';

const ADMIN_ACCOUNTS = [
    {
        email: 'admin@mypresc.dz',
        password: 'Admin@MyPresc2025!',
        name: 'Admin System',
        role: 'super_admin'
    },
    {
        email: 'dev@mypresc.dz',
        password: 'Dev@MyPresc2025!',
        name: 'Developer Team',
        role: 'admin'
    }
];

async function createAdminInAdminsTable() {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║        CRÉATION COMPTES ADMIN (table admins)               ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');

    try {
        for (const admin of ADMIN_ACCOUNTS) {
            // Vérifier si existe déjà
            const checkQuery = 'SELECT id, email FROM admins WHERE email = $1';
            const existing = await pool.query(checkQuery, [admin.email]);

            if (existing.rows.length > 0) {
                console.log(`⚠️  ${admin.email} existe déjà dans la table admins (ID: ${existing.rows[0].id})`);
                continue;
            }

            // Hacher le mot de passe
            const hashedPassword = await bcrypt.hash(admin.password, BCRYPT_ROUNDS);

            // Insérer dans la table admins
            const insertQuery = `
                INSERT INTO admins (name, email, password, role, is_active)
                VALUES ($1, $2, $3, $4, true)
                RETURNING id, email, role
            `;

            const result = await pool.query(insertQuery, [
                admin.name,
                admin.email,
                hashedPassword,
                admin.role
            ]);

            const newAdmin = result.rows[0];
            console.log(`✅ Admin créé: ${admin.email}`);
            console.log(`   ID: ${newAdmin.id}`);
            console.log(`   Role: ${newAdmin.role}`);
            console.log(`   Password: ${admin.password}\n`);
        }

        console.log('\n╔════════════════════════════════════════════════════════════╗');
        console.log('║                    RÉCAPITULATIF                           ║');
        console.log('╚════════════════════════════════════════════════════════════╝\n');

        console.log('🔐 IDENTIFIANTS ADMIN:\n');
        ADMIN_ACCOUNTS.forEach(admin => {
            console.log(`   Email:    ${admin.email}`);
            console.log(`   Password: ${admin.password}`);
            console.log(`   Role:     ${admin.role}`);
            console.log('');
        });

        console.log('✅ Comptes admin créés avec succès dans la table "admins"!\n');
        console.log('🔗 Vous pouvez maintenant vous connecter sur:');
        console.log('   http://localhost:3000/admin/login\n');

    } catch (error: any) {
        console.error('\n❌ ERREUR:', error.message);
        throw error;
    } finally {
        await pool.end();
    }
}

// Exécuter
createAdminInAdminsTable().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
