import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: false
});

// Mots-clés qui indiquent des actes NON dentaires
const NON_DENTAL_KEYWORDS = [
    'oreille', 'auriculaire', 'tympan', 'otite',
    'césarienne', 'cesarienne', 'accouchement', 'foetus', 'fœtus', 'utérus', 'uterus', 'ovaire', 'vagin',
    'oeil', 'œil', 'cornée', 'rétine', 'paupière', 'cristallin', 'cataracte',
    'cardiaque', 'coeur', 'cœur', 'coronaire', 'artère', 'veine', 'aorte',
    'poumon', 'pulmonaire', 'bronche', 'trachée',
    'rein', 'rénal', 'urinaire', 'vessie', 'prostate',
    'foie', 'hépatique', 'vésicule biliaire',
    'intestin', 'colon', 'rectum', 'estomac', 'gastrique', 'appendice',
    'cerveau', 'cérébral', 'crâne', 'méninges', 'neurologique',
    'genou', 'hanche', 'épaule', 'cheville', 'poignet', 'coude', 'vertèbre', 'rachis',
    'sein', 'mammaire', 'mastectomie',
    'thyroïde', 'thyroide',
    'rate', 'pancréas',
    'testicule', 'pénis', 'scrotum',
    'hernie inguinale', 'hernie abdominale',
    'thorax', 'thoracique', 'plèvre',
    'larynx', 'pharynx nasal', 'nez', 'nasal', 'sinus frontal', 'sinus ethmoïdal'
];

// Mots-clés qui CONFIRMENT un acte dentaire (ne pas supprimer)
const DENTAL_CONFIRM = [
    'dent', 'dentaire', 'dental', 'odonto',
    'maxillaire', 'mandibul', 'mâchoire',
    'gencive', 'gingiv', 'parodont',
    'pulpe', 'pulpaire', 'endodont',
    'racine dentaire', 'canal radiculaire',
    'couronne dentaire', 'bridge dentaire',
    'extraction dentaire', 'avulsion dentaire',
    'obturation', 'amalgame', 'composite dentaire',
    'carie', 'cavité dentaire',
    'implant dentaire', 'implant oral',
    'orthodont', 'appareil dentaire',
    'détartrage', 'prophylaxie dentaire',
    'incisive', 'canine', 'prémolaire', 'molaire',
    'émail', 'dentine', 'cément',
    'alvéol', 'apex dentaire', 'apical',
    'stomatolog', 'bucco-dent', 'oral'
];

async function cleanCCAM() {
    try {
        console.log('🔍 Analyse des actes CCAM...\n');

        // Get all acts
        const result = await pool.query('SELECT id, code_ccam, label, topography_label, family_label FROM act_catalog ORDER BY id');
        console.log(`📊 Total actes en base: ${result.rows.length}\n`);

        const toDelete: number[] = [];
        const suspicious: any[] = [];

        for (const row of result.rows) {
            const searchText = [row.label, row.topography_label, row.family_label].join(' ').toLowerCase();
            
            // Check if it's confirmed dental
            let isDentalConfirmed = false;
            for (const keyword of DENTAL_CONFIRM) {
                if (searchText.includes(keyword.toLowerCase())) {
                    isDentalConfirmed = true;
                    break;
                }
            }

            // If not confirmed dental, check if it matches non-dental keywords
            if (!isDentalConfirmed) {
                for (const keyword of NON_DENTAL_KEYWORDS) {
                    if (searchText.includes(keyword.toLowerCase())) {
                        toDelete.push(row.id);
                        suspicious.push({
                            id: row.id,
                            code: row.code_ccam,
                            label: row.label.substring(0, 60),
                            reason: keyword
                        });
                        break;
                    }
                }
            }
        }

        console.log('═══════════════════════════════════════════');
        console.log('🗑️  Actes NON dentaires à supprimer:');
        console.log('═══════════════════════════════════════════\n');

        for (const item of suspicious) {
            console.log(`[${item.id}] ${item.code} - ${item.label}...`);
            console.log(`    Raison: contient "${item.reason}"\n`);
        }

        console.log(`\n📊 Total à supprimer: ${toDelete.length} actes`);

        if (toDelete.length > 0) {
            // Delete non-dental acts
            const deleteResult = await pool.query(
                'DELETE FROM act_catalog WHERE id = ANY($1) RETURNING id',
                [toDelete]
            );
            console.log(`\n✅ Supprimés: ${deleteResult.rowCount} actes`);
        }

        // Final count
        const finalCount = await pool.query('SELECT COUNT(*) FROM act_catalog');
        console.log(`\n📈 Actes restants (dentaires uniquement): ${finalCount.rows[0].count}`);

    } catch (error) {
        console.error('❌ Erreur:', error);
    } finally {
        await pool.end();
    }
}

cleanCCAM();
