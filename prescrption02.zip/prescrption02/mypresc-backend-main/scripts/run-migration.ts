import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';

const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://neondb_owner:npg_bQICjopUJi53@ep-polished-tooth-add9hzy4-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require';

async function runMigration() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: {
            rejectUnauthorized: false
        }
    });

    try {
        console.log('📊 Connecting to database...');
        
        // Read migration file
        const migrationPath = path.join(__dirname, '../migrations/004_admin_system.sql');
        const sql = fs.readFileSync(migrationPath, 'utf8');

        console.log('🔄 Executing migration...');
        
        // Execute migration
        await pool.query(sql);

        console.log('✅ Migration completed successfully!');
        
        // Verify tables were created
        const result = await pool.query(`
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('admins', 'audit_logs')
            ORDER BY table_name;
        `);

        console.log('\n📋 Tables created:');
        result.rows.forEach(row => {
            console.log(`  ✓ ${row.table_name}`);
        });

    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

runMigration();
