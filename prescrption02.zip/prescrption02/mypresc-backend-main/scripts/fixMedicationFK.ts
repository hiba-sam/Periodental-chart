import pool from '../db';

async function fixFK() {
    console.log('🔄 Fixing medication_id foreign key constraint...');
    
    try {
        // Drop the existing foreign key constraint
        await pool.query(`
            ALTER TABLE prescription_medications 
            DROP CONSTRAINT IF EXISTS prescription_medications_medication_id_fkey;
        `);
        console.log('✅ Dropped existing FK constraint');

        // Make medication_id nullable
        await pool.query(`
            ALTER TABLE prescription_medications 
            ALTER COLUMN medication_id DROP NOT NULL;
        `);
        console.log('✅ Made medication_id nullable');

        // Add a new constraint that allows NULL (no constraint needed, just remove NOT NULL)
        console.log('🎉 FK constraint fixed! Custom medications can now use medication_id = NULL');
    } catch (error) {
        console.error('❌ Error:', error);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

fixFK();
