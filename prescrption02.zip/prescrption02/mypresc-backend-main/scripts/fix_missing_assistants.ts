
import pool from '../db';
import { AssistantModel } from '../models/assistant.model';

async function fixMissingAssistants() {
    console.log("Fixing missing assistant profiles...");
    
    // Get first doctor ID to use as placeholder
    const docResult = await pool.query("SELECT id FROM users WHERE role = 'doctor' LIMIT 1");
    if (docResult.rows.length === 0) {
        console.error("No doctors found! Cannot fix assistants.");
        return;
    }
    const defaultDoctorId = docResult.rows[0].id;
    console.log(`Using doctor ID ${defaultDoctorId} as default for missing assistants.`);

    // Get all assistants from users table
    const result = await pool.query("SELECT id, name, family_name, email FROM users WHERE role = 'assistant'");
    const assistants = result.rows;

    for (const ast of assistants) {
        const profile = await AssistantModel.findByUserId(ast.id);
        
        if (!profile) {
            console.log(`Creating profile for assistant: ${ast.name} ${ast.family_name} (${ast.email})...`);
            
            try {
                // Manually insert into assistants table since model might not have a simple 'create' for existing user
                await pool.query(
                    "INSERT INTO assistants (user_id, doctor_id, assistant_name, assistant_email, phone_number) VALUES ($1, $2, $3, $4, $5)",
                    [ast.id, defaultDoctorId, `${ast.family_name} ${ast.name}`, ast.email, '0000000000']
                );
                console.log(`✅ Successfully created profile for ${ast.email}`);
            } catch (err) {
                console.error(`❌ Failed to create profile for ${ast.email}:`, err);
            }
        }
    }
    
    console.log("Finished fixing assistant profiles.");
}

fixMissingAssistants().then(() => process.exit(0)).catch(err => {
    console.error(err);
    process.exit(1);
});
