import pool from '../db';

async function runMigration() {
    console.log('🔄 Running migration 035: Create custom_medications table...');
    
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS custom_medications (
                id SERIAL PRIMARY KEY,
                nom_de_marque VARCHAR(255) NOT NULL,
                denomination_commune_internationale VARCHAR(255),
                dosage VARCHAR(100),
                forme VARCHAR(100),
                laboratoire VARCHAR(255),
                added_by_doctor_id INTEGER NOT NULL,
                status VARCHAR(50) DEFAULT 'pending',
                approved_at TIMESTAMP,
                approved_by_admin_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT fk_custom_med_doctor FOREIGN KEY (added_by_doctor_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT fk_custom_med_admin FOREIGN KEY (approved_by_admin_id) REFERENCES users(id) ON DELETE SET NULL
            );
        `);
        console.log('✅ Table custom_medications created');

        await pool.query(`CREATE INDEX IF NOT EXISTS idx_custom_medications_doctor ON custom_medications(added_by_doctor_id);`);
        await pool.query(`CREATE INDEX IF NOT EXISTS idx_custom_medications_status ON custom_medications(status);`);
        await pool.query(`CREATE INDEX IF NOT EXISTS idx_custom_medications_name ON custom_medications(nom_de_marque);`);
        console.log('✅ Indexes created');

        await pool.query(`ALTER TABLE prescription_medication_items ADD COLUMN IF NOT EXISTS custom_medication_id INTEGER REFERENCES custom_medications(id);`);
        await pool.query(`ALTER TABLE prescription_medication_items ADD COLUMN IF NOT EXISTS is_custom BOOLEAN DEFAULT FALSE;`);
        console.log('✅ prescription_medication_items columns added');

        console.log('🎉 Migration 035 completed successfully!');
    } catch (error) {
        console.error('❌ Migration error:', error);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

runMigration();
