/**
 * Decrypt Audit Log Script - MyPresc
 * 
 * Déchiffre et affiche les logs d'audit chiffrés
 * Usage: bun run scripts/decrypt-audit-log.ts [--tail=100] [--filter=role:doctor]
 */

import * as fs from 'fs';
import { decryptJSON } from '../utils/dataEncryption';
import type { EncryptedPayload } from '../utils/dataEncryption';

// ============================================
// CONFIGURATION
// ============================================

const AUDIT_LOG_ENCRYPTED_PATH = 'logs/audit-access-encrypted.log';
const AUDIT_LOG_PLAIN_PATH = 'logs/audit-access.log';

// ============================================
// TYPES
// ============================================

interface AuditLogEntry {
    event: string;
    userId: number | string;
    email: string;
    role: string;
    method: string;
    endpoint: string;
    action: string;
    targetType: string;
    targetId?: string | number;
    ip: string;
    userAgent?: string;
    timestamp: string;
    duration?: number;
    statusCode?: number;
}

interface FilterOptions {
    role?: string;
    action?: string;
    event?: string;
    userId?: string;
    email?: string;
    startDate?: Date;
    endDate?: Date;
}

// ============================================
// PARSING ARGUMENTS
// ============================================

function parseArgs(): { tail?: number; filter?: FilterOptions; source: 'encrypted' | 'plain' } {
    const args = process.argv.slice(2);
    const result: { tail?: number; filter?: FilterOptions; source: 'encrypted' | 'plain' } = {
        source: 'plain'
    };
    
    for (const arg of args) {
        if (arg.startsWith('--tail=')) {
            result.tail = parseInt(arg.split('=')[1], 10);
        } else if (arg.startsWith('--filter=')) {
            const filterStr = arg.split('=')[1];
            const [key, value] = filterStr.split(':');
            
            if (!result.filter) result.filter = {};
            
            if (key === 'role') result.filter.role = value;
            else if (key === 'action') result.filter.action = value;
            else if (key === 'event') result.filter.event = value;
            else if (key === 'userId') result.filter.userId = value;
            else if (key === 'email') result.filter.email = value;
        } else if (arg === '--encrypted') {
            result.source = 'encrypted';
        } else if (arg === '--plain') {
            result.source = 'plain';
        }
    }
    
    return result;
}

// ============================================
// LECTURE DES LOGS
// ============================================

/**
 * Lit et déchiffre les logs d'audit
 */
function readAuditLogs(source: 'encrypted' | 'plain' = 'plain'): AuditLogEntry[] {
    const logPath = source === 'encrypted' ? AUDIT_LOG_ENCRYPTED_PATH : AUDIT_LOG_PLAIN_PATH;
    
    if (!fs.existsSync(logPath)) {
        console.error(`❌ Fichier de log introuvable: ${logPath}`);
        return [];
    }
    
    const content = fs.readFileSync(logPath, 'utf-8');
    const lines = content.split('\n').filter(l => l.trim());
    
    const entries: AuditLogEntry[] = [];
    let errors = 0;
    
    for (const line of lines) {
        try {
            if (source === 'encrypted') {
                // Déchiffrer la ligne
                const encrypted = JSON.parse(line) as EncryptedPayload;
                const decrypted = decryptJSON(encrypted);
                entries.push(decrypted);
            } else {
                // Ligne en clair
                entries.push(JSON.parse(line));
            }
        } catch (error) {
            errors++;
        }
    }
    
    if (errors > 0) {
        console.warn(`⚠️  ${errors} entrées n'ont pas pu être déchiffrées/parsées`);
    }
    
    return entries;
}

// ============================================
// FILTRAGE
// ============================================

/**
 * Filtre les entrées selon les critères
 */
function filterEntries(entries: AuditLogEntry[], filter?: FilterOptions): AuditLogEntry[] {
    if (!filter) return entries;
    
    return entries.filter(entry => {
        if (filter.role && entry.role !== filter.role) return false;
        if (filter.action && entry.action !== filter.action) return false;
        if (filter.event && entry.event !== filter.event) return false;
        if (filter.userId && entry.userId.toString() !== filter.userId) return false;
        if (filter.email && !entry.email.includes(filter.email)) return false;
        
        if (filter.startDate) {
            const entryDate = new Date(entry.timestamp);
            if (entryDate < filter.startDate) return false;
        }
        
        if (filter.endDate) {
            const entryDate = new Date(entry.timestamp);
            if (entryDate > filter.endDate) return false;
        }
        
        return true;
    });
}

// ============================================
// AFFICHAGE
// ============================================

/**
 * Affiche les entrées de manière formatée
 */
function displayEntries(entries: AuditLogEntry[]): void {
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║              AUDIT LOG - ACCÈS SÉCURISÉS                   ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');
    
    if (entries.length === 0) {
        console.log('Aucune entrée trouvée.\n');
        return;
    }
    
    console.log(`📊 Total: ${entries.length} entrées\n`);
    console.log('─'.repeat(60) + '\n');
    
    entries.forEach((entry, index) => {
        const color = entry.event === 'ACCESS_DENIED' ? '\x1b[31m' : '\x1b[32m';
        const reset = '\x1b[0m';
        
        console.log(`${color}[${index + 1}] ${entry.event}${reset}`);
        console.log(`    👤 User: ${entry.email} (${entry.role})`);
        console.log(`    🔑 ID: ${entry.userId}`);
        console.log(`    📍 ${entry.method} ${entry.endpoint}`);
        console.log(`    🎯 Action: ${entry.action} on ${entry.targetType}${entry.targetId ? ` #${entry.targetId}` : ''}`);
        console.log(`    🌐 IP: ${entry.ip}`);
        console.log(`    🕐 ${entry.timestamp}`);
        
        if (entry.duration !== undefined) {
            console.log(`    ⚡ Duration: ${entry.duration}ms`);
        }
        
        if (entry.statusCode !== undefined) {
            const statusColor = entry.statusCode >= 400 ? '\x1b[31m' : '\x1b[32m';
            console.log(`    📊 Status: ${statusColor}${entry.statusCode}${reset}`);
        }
        
        console.log('');
    });
    
    console.log('─'.repeat(60) + '\n');
}

// ============================================
// STATISTIQUES
// ============================================

/**
 * Affiche des statistiques sur les logs
 */
function displayStats(entries: AuditLogEntry[]): void {
    const stats = {
        total: entries.length,
        byRole: {} as Record<string, number>,
        byAction: {} as Record<string, number>,
        byEvent: {} as Record<string, number>,
        denied: 0,
        granted: 0
    };
    
    entries.forEach(entry => {
        // Par rôle
        stats.byRole[entry.role] = (stats.byRole[entry.role] || 0) + 1;
        
        // Par action
        stats.byAction[entry.action] = (stats.byAction[entry.action] || 0) + 1;
        
        // Par événement
        stats.byEvent[entry.event] = (stats.byEvent[entry.event] || 0) + 1;
        
        // Accès refusés/accordés
        if (entry.event === 'ACCESS_DENIED') {
            stats.denied++;
        } else {
            stats.granted++;
        }
    });
    
    console.log('\n╔════════════════════════════════════════════════════════════╗');
    console.log('║                     STATISTIQUES                           ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');
    
    console.log(`📊 Total des accès: ${stats.total}`);
    console.log(`   ✅ Accordés: ${stats.granted}`);
    console.log(`   ❌ Refusés: ${stats.denied}\n`);
    
    console.log('👥 Par rôle:');
    Object.entries(stats.byRole)
        .sort((a, b) => b[1] - a[1])
        .forEach(([role, count]) => {
            console.log(`   ${role.padEnd(15)}: ${count}`);
        });
    
    console.log('\n🎯 Par action:');
    Object.entries(stats.byAction)
        .sort((a, b) => b[1] - a[1])
        .forEach(([action, count]) => {
            console.log(`   ${action.padEnd(15)}: ${count}`);
        });
    
    console.log('\n📋 Par événement:');
    Object.entries(stats.byEvent)
        .sort((a, b) => b[1] - a[1])
        .forEach(([event, count]) => {
            console.log(`   ${event.padEnd(15)}: ${count}`);
        });
    
    console.log('');
}

// ============================================
// MAIN
// ============================================

async function main() {
    console.clear();
    
    const { tail, filter, source } = parseArgs();
    
    console.log('\n🔐 Lecture des logs d\'audit...');
    console.log(`📂 Source: ${source === 'encrypted' ? 'Chiffrés (AES-256-GCM)' : 'En clair'}\n`);
    
    // Lire les logs
    let entries = readAuditLogs(source);
    
    if (entries.length === 0) {
        console.log('❌ Aucun log trouvé.\n');
        process.exit(1);
    }
    
    console.log(`✅ ${entries.length} entrées chargées`);
    
    // Filtrer
    if (filter) {
        console.log(`🔍 Application des filtres...`);
        entries = filterEntries(entries, filter);
        console.log(`   → ${entries.length} entrées après filtrage`);
    }
    
    // Tail (afficher les N dernières)
    if (tail && tail < entries.length) {
        console.log(`📄 Affichage des ${tail} dernières entrées`);
        entries = entries.slice(-tail);
    }
    
    // Afficher
    displayEntries(entries);
    
    // Statistiques
    displayStats(entries);
    
    console.log('═'.repeat(60) + '\n');
}

// ============================================
// HELP
// ============================================

if (process.argv.includes('--help') || process.argv.includes('-h')) {
    console.log(`
╔════════════════════════════════════════════════════════════╗
║        DECRYPT AUDIT LOG - MyPresc Backend                 ║
╚════════════════════════════════════════════════════════════╝

Usage:
  bun run scripts/decrypt-audit-log.ts [options]

Options:
  --encrypted           Lire les logs chiffrés (AES-256-GCM)
  --plain               Lire les logs en clair (défaut)
  --tail=N              Afficher les N dernières entrées
  --filter=key:value    Filtrer les entrées
  --help, -h            Afficher cette aide

Filtres disponibles:
  role:ROLE             Filtrer par rôle (doctor, assistant, patient, admin)
  action:ACTION         Filtrer par action (READ, CREATE, UPDATE, DELETE)
  event:EVENT           Filtrer par événement (ACCESS_LOG, ACCESS_DENIED)
  userId:ID             Filtrer par ID utilisateur
  email:EMAIL           Filtrer par email (recherche partielle)

Exemples:
  # Afficher les 50 dernières entrées
  bun run scripts/decrypt-audit-log.ts --tail=50

  # Afficher uniquement les accès des docteurs
  bun run scripts/decrypt-audit-log.ts --filter=role:doctor

  # Afficher les accès refusés
  bun run scripts/decrypt-audit-log.ts --filter=event:ACCESS_DENIED

  # Lire les logs chiffrés
  bun run scripts/decrypt-audit-log.ts --encrypted --tail=100

  # Combiner plusieurs filtres
  bun run scripts/decrypt-audit-log.ts --filter=role:doctor --tail=20

`);
    process.exit(0);
}

// Exécuter
main().catch(error => {
    console.error('❌ Erreur:', error);
    process.exit(1);
});
