import bcrypt from 'bcryptjs';
import { Pool } from 'pg';

const DATABASE_URL = process.env.DATABASE_URL;

async function createAdmin() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: false
    });

    try {
        console.log('📊 Connecting to database...');
        
        // Admin details
        const name = 'Hicham Laouaj';
        const email = 'hicham.laouaj.pro@gmail.com';
        const password = bcrypt.hashSync('Admin@MyPresc2025!', 10);
        const role = 'super_admin';

        // Check if admin already exists
        const checkResult = await pool.query(
            'SELECT id, email FROM admins WHERE email = $1',
            [email]
        );

        if (checkResult.rows.length > 0) {
            console.log('⚠️  Admin already exists:');
            console.log(`   ID: ${checkResult.rows[0].id}`);
            console.log(`   Email: ${checkResult.rows[0].email}`);
            console.log('\n✅ You can login with:');
            console.log(`   Email: ${email}`);
            console.log(`   Password: Admin123!`);
            return;
        }

        // Insert admin
        console.log('🔄 Creating admin...');
        
        const result = await pool.query(
            `INSERT INTO admins (name, email, password, role) 
             VALUES ($1, $2, $3, $4)
             RETURNING id, name, email, role, is_active, created_at`,
            [name, email, password, role]
        );

        const admin = result.rows[0];

        console.log('\n✅ Admin created successfully!');
        console.log('\n📋 Admin details:');
        console.log(`   ID: ${admin.id}`);
        console.log(`   Name: ${admin.name}`);
        console.log(`   Email: ${admin.email}`);
        console.log(`   Role: ${admin.role}`);
        console.log(`   Active: ${admin.is_active}`);
        console.log(`   Created: ${admin.created_at}`);
        
        console.log('\n🔐 Login credentials:');
        console.log(`   Email: ${email}`);
        
        console.log('\n🚀 Next steps:');
        console.log('   1. Restart backend: bun run dev');
        console.log('   2. Restart frontend: npm run dev');
        console.log('   3. Open: http://localhost:3000/admin/login');

    } catch (error) {
        console.error('❌ Failed to create admin:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

createAdmin();
