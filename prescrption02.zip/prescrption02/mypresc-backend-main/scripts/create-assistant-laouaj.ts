import bcrypt from 'bcryptjs';
import { Pool } from 'pg';

const DATABASE_URL = process.env.DATABASE_URL;

async function createAssistantForDrLaouaj() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: false
    });

    try {
        console.log('📊 Connecting to database...');
        
        // Assistant details for Dr. Laouaj Hicham
        const assistantName = 'Assistant';
        const assistantFamilyName = 'Dr. Laouaj';
        const assistantEmail = 'assistant.laouaj@mypresc.com';
        const assistantPassword = 'Assistant@Laouaj2025!';
        const hashedPassword = bcrypt.hashSync(assistantPassword, 10);

        // Find Dr. Laouaj Hicham in users table
        console.log('🔍 Searching for Dr. Laouaj Hicham...');
        const doctorResult = await pool.query(
            `SELECT u.id, u.name, u.family_name, u.email 
             FROM users u 
             WHERE u.role = 'doctor' 
             AND (LOWER(u.name) LIKE '%laouaj%' OR LOWER(u.family_name) LIKE '%laouaj%' OR LOWER(u.name) LIKE '%hicham%' OR LOWER(u.family_name) LIKE '%hicham%')`
        );

        if (doctorResult.rows.length === 0) {
            console.log('⚠️  Dr. Laouaj Hicham not found in the database.');
            console.log('   Please make sure the doctor account exists first.');
            
            // List all doctors for reference
            const allDoctors = await pool.query(
                `SELECT u.id, u.name, u.family_name, u.email 
                 FROM users u WHERE u.role = 'doctor' LIMIT 10`
            );
            if (allDoctors.rows.length > 0) {
                console.log('\n📋 Available doctors:');
                allDoctors.rows.forEach(doc => {
                    console.log(`   - ID: ${doc.id}, Name: ${doc.family_name} ${doc.name}, Email: ${doc.email}`);
                });
            }
            return;
        }

        const doctor = doctorResult.rows[0];
        console.log(`✅ Found doctor: ${doctor.family_name} ${doctor.name} (ID: ${doctor.id})`);

        // Check if assistant already exists
        const existingAssistant = await pool.query(
            'SELECT id, assistant_email FROM assistants WHERE assistant_email = $1',
            [assistantEmail]
        );

        if (existingAssistant.rows.length > 0) {
            console.log('⚠️  Assistant already exists with this email.');
            console.log('\n🔐 Login credentials:');
            console.log(`   Email: ${assistantEmail}`);
            console.log(`   Password: ${assistantPassword}`);
            return;
        }

        // Check if user with this email already exists
        const existingUser = await pool.query(
            'SELECT id FROM users WHERE email = $1',
            [assistantEmail]
        );

        let userId: number;

        if (existingUser.rows.length > 0) {
            userId = existingUser.rows[0].id;
            console.log(`ℹ️  User already exists with ID: ${userId}`);
        } else {
            // Create user account for assistant
            console.log('🔄 Creating user account for assistant...');
            const userResult = await pool.query(
                `INSERT INTO users (name, family_name, email, password, role, is_active) 
                 VALUES ($1, $2, $3, $4, 'assistant', true)
                 RETURNING id, name, family_name, email, role`,
                [assistantName, assistantFamilyName, assistantEmail, hashedPassword]
            );
            userId = userResult.rows[0].id;
            console.log(`✅ User created with ID: ${userId}`);
        }

        // Create assistant record
        console.log('🔄 Creating assistant record...');
        const assistantResult = await pool.query(
            `INSERT INTO assistants (assistant_name, assistant_email, doctor_id, user_id, is_active) 
             VALUES ($1, $2, $3, $4, true)
             RETURNING id, assistant_name, assistant_email, doctor_id`,
            [`${assistantFamilyName} ${assistantName}`, assistantEmail, doctor.id, userId]
        );

        const assistant = assistantResult.rows[0];

        console.log('\n✅ Assistant created successfully!');
        console.log('\n📋 Assistant details:');
        console.log(`   ID: ${assistant.id}`);
        console.log(`   Name: ${assistant.assistant_name}`);
        console.log(`   Email: ${assistant.assistant_email}`);
        console.log(`   Doctor ID: ${assistant.doctor_id}`);
        console.log(`   Doctor: ${doctor.family_name} ${doctor.name}`);
        
        console.log('\n🔐 Login credentials:');
        console.log(`   Email: ${assistantEmail}`);
        console.log(`   Password: ${assistantPassword}`);
        
        console.log('\n🚀 The assistant can now login at the application.');

    } catch (error) {
        console.error('❌ Failed to create assistant:', error);
        process.exit(1);
    } finally {
        await pool.end();
    }
}

createAssistantForDrLaouaj();
