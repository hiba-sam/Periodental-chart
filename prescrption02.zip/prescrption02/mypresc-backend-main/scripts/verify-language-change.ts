
import axios from 'axios';
import fs from 'fs';

const BASE_URL = 'http://localhost:3333';
const LOG_FILE = 'verification_result.log';

function log(message: string) {
    console.log(message);
    fs.appendFileSync(LOG_FILE, message + '\n');
}

// Clear log file
fs.writeFileSync(LOG_FILE, '');

async function verifyLanguageChange() {
    log('Starting Language Change Verification...');

    let token = '';

    // 1. Login to get token
    try {
        log('\n--- Login ---');
        const resLogin = await axios.post(`${BASE_URL}/auth/login`, {
            email: 'admin@mypresc.dz',
            password: 'Admin@MyPresc2025!'
        });

        const cookie = resLogin.headers['set-cookie'];
        log(`Headers: ${JSON.stringify(resLogin.headers)}`);
        if (cookie) {
            // Find sessionId cookie
            const sessionCookie = cookie.find(c => c.startsWith('sessionId='));
            token = sessionCookie || cookie[0] || '';
            log(`Extracted Token: ${token}`);
        }
        log('Login successful');

    } catch (e: any) {
        log(`Login failed. Ensure admin@mypresc.dz / Admin@MyPresc2025! exists. ${e.message}`);
        return;
    }

    if (!token) {
        log('No token found in login response.');
        return;
    }

    const axiosConfig = {
        headers: {
            Cookie: token
        },
        validateStatus: () => true
    };

    // 2. Change Language to 'ar'
    try {
        log('\n--- Change Language to AR ---');
        const resAr = await axios.put(`${BASE_URL}/user/language`, {
            language: 'ar'
        }, axiosConfig);

        log(`Status: ${resAr.status}`);
        log(`Response: ${JSON.stringify(resAr.data)}`);

        if (resAr.status === 200 && resAr.data.data.language === 'ar') {
            log('✅ Language changed to Arabic successfully');
        } else {
            log('❌ Failed to change language to Arabic');
        }

    } catch (e: any) {
        log(`Error changing language: ${e.message}`);
    }

    // 3. Verify Persistence (Get User)
    try {
        log('\n--- Verify Persistence ---');
        const resGet = await axios.get(`${BASE_URL}/user`, axiosConfig);

        log(`User Language: ${resGet.data.data.language}`);

        if (resGet.data.data.language === 'ar') {
            log('✅ Language persistence confirmed');
        } else {
            log('❌ Language persistence failed');
        }

    } catch (e: any) {
        log(`Error getting user: ${e.message}`);
        if (e.response) {
            log(`Error Response: ${JSON.stringify(e.response.data)}`);
        }
    }

    // 4. Revert to 'fr'
    try {
        log('\n--- Revert Language to FR ---');
        await axios.put(`${BASE_URL}/user/language`, { language: 'fr' }, axiosConfig);
        log('Language reverted to FR');
    } catch (e: any) {
        log(`Error reverting language: ${e.message}`);
    }
}

verifyLanguageChange();
