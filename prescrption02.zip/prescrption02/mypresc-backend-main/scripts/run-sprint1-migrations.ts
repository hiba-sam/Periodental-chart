/**
 * Script de migration Sprint 1
 * Exécute les migrations de sécurité prioritaires
 * 
 * Usage: npx ts-node scripts/run-sprint1-migrations.ts
 *    ou: bun run scripts/run-sprint1-migrations.ts
 */

import { Pool } from 'pg';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false,
    },
});

const MIGRATIONS_DIR = path.join(__dirname, '..', 'migrations');

interface MigrationResult {
    file: string;
    success: boolean;
    error?: string;
    duration: number;
}

async function runMigration(filename: string): Promise<MigrationResult> {
    const filepath = path.join(MIGRATIONS_DIR, filename);
    const startTime = Date.now();
    
    console.log(`\n📄 Exécution: ${filename}`);
    console.log('─'.repeat(50));
    
    try {
        const sql = fs.readFileSync(filepath, 'utf-8');
        await pool.query(sql);
        
        const duration = Date.now() - startTime;
        console.log(`✅ Succès (${duration}ms)`);
        
        return { file: filename, success: true, duration };
    } catch (error: any) {
        const duration = Date.now() - startTime;
        console.error(`❌ Erreur: ${error.message}`);
        
        return { file: filename, success: false, error: error.message, duration };
    }
}

async function migrateExistingData(): Promise<void> {
    const encryptionKey = process.env.ENCRYPTION_KEY;
    
    if (!encryptionKey) {
        console.error('❌ ENCRYPTION_KEY non définie dans .env');
        return;
    }
    
    console.log('\n🔐 Migration des données medical_reports existantes...');
    console.log('─'.repeat(50));
    
    try {
        // Vérifier si la fonction existe
        const checkFunc = await pool.query(`
            SELECT EXISTS (
                SELECT 1 FROM pg_proc WHERE proname = 'migrate_medical_reports_encryption'
            ) as exists
        `);
        
        if (!checkFunc.rows[0].exists) {
            console.log('⚠️  Fonction de migration non trouvée - exécutez d\'abord migration 025');
            return;
        }
        
        // Exécuter la migration des données
        const result = await pool.query(
            'SELECT * FROM migrate_medical_reports_encryption($1)',
            [encryptionKey]
        );
        
        console.log(`✅ Données migrées: ${result.rows[0]?.migrated_count || 0} enregistrements`);
        
        // Vérifier la migration
        const verify = await pool.query('SELECT * FROM verify_medical_reports_encryption()');
        const stats = verify.rows[0];
        
        console.log(`\n📊 Vérification:`);
        console.log(`   Total: ${stats.total_records}`);
        console.log(`   Chiffrés: ${stats.encrypted_records}`);
        console.log(`   En attente: ${stats.pending_records}`);
        console.log(`   Complète: ${stats.migration_complete ? '✅ OUI' : '❌ NON'}`);
        
    } catch (error: any) {
        console.error(`❌ Erreur migration données: ${error.message}`);
    }
}

async function runSprint1Migrations(): Promise<void> {
    console.log('🚀 SPRINT 1 - Migrations de Sécurité');
    console.log('═'.repeat(50));
    console.log('Conformité: Loi 18-07 / 25-11 Algérie\n');
    
    const migrations = [
        '025_encrypt_medical_reports.sql',
        '027_enable_rls_patients.sql',
        '028_create_patient_access_logs.sql'
    ];
    
    const results: MigrationResult[] = [];
    
    // Exécuter chaque migration
    for (const migration of migrations) {
        const result = await runMigration(migration);
        results.push(result);
        
        if (!result.success) {
            console.log(`\n⚠️  Arrêt après erreur sur ${migration}`);
            break;
        }
    }
    
    // Si toutes les migrations ont réussi, migrer les données
    if (results.every(r => r.success)) {
        await migrateExistingData();
    }
    
    // Résumé
    console.log('\n' + '═'.repeat(50));
    console.log('📋 RÉSUMÉ');
    console.log('═'.repeat(50));
    
    const successful = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;
    
    console.log(`✅ Réussies: ${successful}`);
    console.log(`❌ Échouées: ${failed}`);
    
    if (failed > 0) {
        console.log('\n⚠️  Certaines migrations ont échoué.');
        console.log('Vérifiez les erreurs ci-dessus et relancez après correction.');
    } else {
        console.log('\n✅ Toutes les migrations Sprint 1 ont été appliquées!');
        console.log('\n📝 Prochaines étapes:');
        console.log('   1. Tester l\'application');
        console.log('   2. Intégrer le middleware RLS dans les routes');
        console.log('   3. Après validation, exécuter 026_finalize_medical_reports_encryption.sql');
    }
    
    // Fermer la connexion
    await pool.end();
}

// Exécuter
runSprint1Migrations().catch(console.error);
