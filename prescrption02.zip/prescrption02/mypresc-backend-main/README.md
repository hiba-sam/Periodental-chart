# MyPresc Backend API

A secure Node.js backend API for a medical prescription management system built with Express.js, TypeScript, and PostgreSQL.

## 🚀 Features

- **User Authentication**: Registration and login with role-based access
- **Doctor Management**: Complete doctor profile management
- **Security**: XSS protection, rate limiting, CORS, Helmet.js
- **Email Notifications**: Automated email system for registration
- **Database Migrations**: Automated database schema management
- **Session Management**: Secure session handling with Passport.js
- **Password Security**: Bcrypt password hashing

## 🛠️ Tech Stack

- **Runtime**: Node.js with Bun
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: PostgreSQL
- **Authentication**: Passport.js with Local Strategy
- **Security**: Helmet.js, CORS, Rate Limiting, XSS Clean
- **Email**: Nodemailer
- **Password Hashing**: Bcrypt

## 📋 Prerequisites

- Node.js (v18 or higher)
- Bun (latest version)
- PostgreSQL (v12 or higher)
- SMTP email service (Gmail, SendGrid, etc.)

## 🚀 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd mypresc-nextjs/backend
   ```

2. **Install dependencies**
   ```bash
   bun install
   ```

3. **Environment Setup**
   Create a `.env` file in the root directory:
   ```env
   # Database Configuration
   DATABASE_URL=postgresql://username:password@localhost:5432/mypresc_db
   
   # JWT Configuration
   JWT_SECRET=your-super-secret-jwt-key
   
   # Session Configuration
   SESSION_SECRET=your-super-secret-session-key
   
   # Email Configuration
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-app-password
   APP_NAME=MyPresc
   TEAM_EMAIL=admin@mypresc.com
   
   # Frontend URL
   FRONTEND_URL=http://localhost:3000
   
   # Server Configuration
   PORT=3000
   NODE_ENV=development
   ```

4. **Database Setup**
   ```bash
   # Run migrations to create tables
   bun run migrate
   ```

5. **Start the server**
   ```bash
   bun run dev
   ```

## 📁 Project Structure

```
backend/
├── controllers/          # Route controllers
│   └── auth.controller.ts
├── models/              # Database models
│   ├── user.model.ts
│   ├── doctor.model.ts
│   └── token.model.ts
├── routes/              # API routes
│   └── auth.ts
├── strategies/          # Passport strategies
│   ├── localStrategy.ts
│   └── config.ts
├── utils/               # Utility functions
│   └── email.ts
├── migrations/          # Database migrations
│   ├── 001_create_users_table.sql
│   ├── 002_create_doctors_table.sql
│   ├── 003_create_tokens_table.sql
│   └── migrationRunner.ts
├── middlewares/         # Custom middlewares
├── db.ts               # Database connection
├── index.ts            # Main application file
└── package.json
```

This comprehensive README includes:

- **Project overview** and features
- **Installation instructions** with prerequisites
- **Environment setup** with all required variables
- **Project structure** explanation
- **API documentation** with examples
- **Database schema** details
- **Security features** overview
- **Development guidelines**
- **Troubleshooting** section
- **Contributing guidelines**

The documentation is detailed enough for new developers to understand and contribute to the project.

## 🔐 Authentication Flow

### 1. User Registration
```http
POST /auth/register
Content-Type: application/json

{
  "name": "John",
  "family_name": "Doe",
  "email": "john@example.com",
  "role": "doctor",
  "birth_date": "1990-01-01",
  "birth_place": "New York",
  "work_location": "Hospital ABC",
  "home_location": "123 Main St",
  "certificate": "CERT123456",
  "order_num": "ORD789",
  "id_card": "ID123456789"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully. Registration pending team confirmation.",
  "data": {
    "user": {
      "id": 1,
      "name": "John",
      "family_name": "Doe",
      "email": "john@example.com",
      "role": "doctor",
      "is_active": false
    },
    "token": "jwt-token-here"
  }
}
```

### 2. Complete Registration
```http
POST /auth/complete-registration/:token
Content-Type: application/json

{
  "password": "securePassword123"
}
```

### 3. User Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securePassword123"
}
```

### 4. Check User Session
```http
GET /auth/me
```

## 🗄️ Database Schema

### Users Table
| Column | Type | Description |
|--------|------|-------------|
| id | SERIAL PRIMARY KEY | User ID |
| name | VARCHAR(100) | First name |
| family_name | VARCHAR(100) | Last name |
| email | VARCHAR(255) UNIQUE | Email address |
| password | VARCHAR(255) | Hashed password |
| role | VARCHAR(50) | User role (doctor/assistant) |
| is_active | BOOLEAN | Account status |
| created_at | TIMESTAMP | Creation date |
| updated_at | TIMESTAMP | Last update |

### Doctors Table
| Column | Type | Description |
|--------|------|-------------|
| user_id | INT PRIMARY KEY | Foreign key to users |
| birth_date | DATE | Date of birth |
| birth_place | VARCHAR(200) | Place of birth |
| work_location | VARCHAR(200) | Work address |
| home_location | VARCHAR(200) | Home address |
| certificate | VARCHAR(255) | Certificate number |
| order_num | VARCHAR(255) | Order number |
| id_card | VARCHAR(255) | ID card number |
| created_at | TIMESTAMP | Creation date |
| updated_at | TIMESTAMP | Last update |

### Tokens Table
| Column | Type | Description |
|--------|------|-------------|
| id | SERIAL PRIMARY KEY | Token ID |
| user_id | INT | Foreign key to users |
| token | VARCHAR(500) UNIQUE | Token string |
| type | VARCHAR(20) | Token type (registration/verify/reset) |
| expires_at | TIMESTAMP | Expiration date |
| is_used | BOOLEAN | Usage status |
| created_at | TIMESTAMP | Creation date |

## 🔒 Security Features

- **XSS Protection**: XSS-Clean middleware
- **Rate Limiting**: 100 requests per 15 minutes
- **CORS**: Configurable cross-origin resource sharing
- **Helmet.js**: Security headers
- **Password Hashing**: Bcrypt with salt rounds
- **Session Security**: Secure session configuration
- **Input Validation**: Express-validator for request validation

## 📧 Email System

The system includes automated email notifications:

- **Welcome Email**: Sent to new users
- **Registration Confirmation**: Sent to team for approval
- **Password Reset**: For future password recovery

## 🚀 API Endpoints

### Authentication
- `POST /auth/register` - User registration
- `POST /auth/complete-registration/:token` - Complete registration
- `POST /auth/login` - User login
- `POST /auth/logout` - User logout
- `GET /auth/me` - Get current user data

### Health Check
- `GET /health` - Server health status

## 🛠️ Development

### Running Migrations
```bash
bun run migrate
```

### Development Mode
```bash
bun run dev
```

### Production Mode
```bash
bun run start
```

## 📝 Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| DATABASE_URL | PostgreSQL connection string | Yes |
| JWT_SECRET | JWT signing secret | Yes |
| SESSION_SECRET | Session secret key | Yes |
| SMTP_HOST | SMTP server host | Yes |
| SMTP_USER | SMTP username | Yes |
| SMTP_PASS | SMTP password | Yes |
| TEAM_EMAIL | Team notification email | Yes |
| FRONTEND_URL | Frontend application URL | Yes |

## 🔧 Configuration

### Rate Limiting
- General: 100 requests per 15 minutes
- Auth endpoints: 5 requests per 15 minutes
- Health check: No rate limiting

### CORS
- Configurable allowed origins
- Credentials enabled
- Specific headers allowed

### Session
- Secure cookies in production
- HttpOnly cookies
- SameSite strict
- 24-hour expiration

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check DATABASE_URL in .env
   - Ensure PostgreSQL is running
   - Verify database exists

2. **Email Not Sending**
   - Check SMTP credentials
   - Verify SMTP settings
   - Check firewall settings

3. **Migration Errors**
   - Check SQL syntax
   - Verify database permissions
   - Run migrations in order

## 📄 License

This project is licensed under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📞 Support

For support, email support@mypresc.com or create an issue in the repository.
