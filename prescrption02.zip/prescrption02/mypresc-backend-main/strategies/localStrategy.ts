import passport from "passport";
import { Strategy as LocalStrategy } from 'passport-local';
import { UserModel } from "../models/user.model";
import bcrypt from 'bcrypt';

import './config';

// Passport Local Strategy
passport.use(new LocalStrategy(
    {
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true
    },
    async (req, email, password, done) => {
        try {
            // Find user by email
            const user = await UserModel.findByEmail(email);

            if (!user) {
                return done(null, false, { message: req.t('auth.incorrect_email') });
            }

            // Check if user is active
            if (!user.is_active) {
                return done(null, false, { message: req.t('auth.registration_not_completed') });
            }

            // Compare password using bcrypt
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return done(null, false, { message: req.t('auth.incorrect_password') });
            }

            return done(null, user);
        } catch (error) {
            return done(error);
        }
    }
));

export default passport;