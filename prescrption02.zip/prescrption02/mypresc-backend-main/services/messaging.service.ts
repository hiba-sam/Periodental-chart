import { ConversationModel } from '../models/conversation.model';
import { MessageModel } from '../models/message.model';
import { PresenceModel, type PresenceStatus } from '../models/presence.model';
import { UserModel, type User } from '../models/user.model';
import { AssistantModel } from '../models/assistant.model';
import pool from '../db';
import xss from 'xss';

export interface DoctorSearchResult {
  id: number;
  name: string;
  family_name: string;
  full_name: string;
  speciality?: string;
  avatar_url?: string;
}

export class MessagingService {
  /**
   * Search for doctors (excluding current user)
   */
  static async searchDoctors(
    query: string,
    currentUserId: number,
    limit: number = 20
  ): Promise<DoctorSearchResult[]> {
    const searchPattern = `%${query}%`;

    const result = await pool.query(
      `SELECT 
        u.id,
        u.name,
        u.family_name,
        u.name || ' ' || u.family_name AS full_name,
        d.speciality
      FROM users u
      JOIN doctors d ON d.user_id = u.id
      WHERE u.role = 'doctor'
        AND u.is_active = true
        AND u.id != $1
        AND (
          u.name ILIKE $2 
          OR u.family_name ILIKE $2
          OR (u.name || ' ' || u.family_name) ILIKE $2
          OR d.speciality ILIKE $2
        )
      ORDER BY 
        CASE 
          WHEN u.name ILIKE $3 THEN 1
          WHEN u.family_name ILIKE $3 THEN 2
          ELSE 3
        END,
        u.name
      LIMIT $4`,
      [currentUserId, searchPattern, `${query}%`, limit]
    );

    return result.rows;
  }

  /**
   * Get conversation with partner based on user role
   * - For assistants: returns conversation with their doctor
   * - For doctors: returns conversation with their assistant
   * - Automatically creates conversation if it doesn't exist
   */
  static async getConversationPartner(userId: number): Promise<any | null> {
    // Get user information
    const user = await UserModel.findById(userId);
    if (!user) {
      return null;
    }

    let partnerId: number | null = null;

    if (user.role === 'assistant') {
      // Get assistant's doctor
      const assistant = await AssistantModel.findByUserId(userId);
      if (!assistant) {
        return null;
      }

      const result = await pool.query(
        `SELECT u.id
        FROM users u
        WHERE u.id = $1 AND u.role = 'doctor' AND u.is_active = true`,
        [assistant.doctor_id]
      );

      if (result.rows.length === 0) {
        return null;
      }

      partnerId = assistant.doctor_id;
    } else if (user.role === 'doctor') {
      // Get doctor's assistant
      const result = await pool.query(
        `SELECT u.id
        FROM assistants a
        JOIN users u ON u.id = a.user_id
        WHERE a.doctor_id = $1 AND u.is_active = true`,
        [userId]
      );

      if (result.rows.length === 0) {
        return null;
      }

      partnerId = result.rows[0].id;
    }

    if (!partnerId) {
      return null;
    }

    // Automatically create or get conversation
    try {
      const conversationId = await ConversationModel.getOrCreateDirectConversation(userId, partnerId);

      // Get conversation details efficiently (single query instead of fetching all)
      const result = await pool.query(
        `SELECT
          c.id,
          c.type,
          c.created_at,
          c.updated_at,
          CASE
            WHEN cm1.user_id = $1 THEN cm2.user_id
            ELSE cm1.user_id
          END AS other_user_id,
          CASE
            WHEN cm1.user_id = $1 THEN u2.name || ' ' || u2.family_name
            ELSE u1.name || ' ' || u1.family_name
          END AS other_user_name,
          (SELECT content FROM messages WHERE conversation_id = c.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1) AS last_message,
          (SELECT created_at FROM messages WHERE conversation_id = c.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1) AS last_message_at,
          (SELECT COUNT(*)::int FROM messages m LEFT JOIN message_reads mr ON m.id = mr.message_id AND mr.user_id = $1 WHERE m.conversation_id = c.id AND m.sender_id != $1 AND m.deleted_at IS NULL AND mr.message_id IS NULL) AS unread_count
        FROM conversations c
        JOIN conversation_members cm1 ON cm1.conversation_id = c.id
        JOIN conversation_members cm2 ON cm2.conversation_id = c.id AND cm2.user_id != cm1.user_id
        JOIN users u1 ON u1.id = cm1.user_id
        JOIN users u2 ON u2.id = cm2.user_id
        WHERE c.id = $2 AND (cm1.user_id = $1 OR cm2.user_id = $1)`,
        [userId, conversationId]
      );

      return result.rows.length > 0 ? result.rows[0] : null;
    } catch (error) {
      console.error('Failed to create or get conversation:', error);
      return null;
    }
  }

  /**
   * Create or get direct conversation
   * Supports:
   * - Doctor to Doctor conversations
   * - Assistant to their Doctor conversations
   */
  static async createOrGetConversation(
    userId1: number,
    userId2: number
  ): Promise<number> {
    // Verify both users exist and are active
    const usersResult = await pool.query(
      `SELECT id, role FROM users WHERE id = ANY($1) AND is_active = true`,
      [[userId1, userId2]]
    );

    if (usersResult.rows.length !== 2) {
      throw new Error('One or both users not found or inactive');
    }

    const user1 = usersResult.rows.find((u) => u.id === userId1);
    const user2 = usersResult.rows.find((u) => u.id === userId2);

    // Check valid conversation combinations
    const bothDoctors = user1?.role === 'doctor' && user2?.role === 'doctor';
    const assistantAndDoctor =
      (user1?.role === 'assistant' && user2?.role === 'doctor') ||
      (user1?.role === 'doctor' && user2?.role === 'assistant');

    if (!bothDoctors && !assistantAndDoctor) {
      throw new Error('Invalid conversation participants. Only doctor-doctor or doctor-assistant conversations are allowed');
    }

    // If assistant-doctor conversation, verify they are linked
    if (assistantAndDoctor) {
      const assistantId = user1?.role === 'assistant' ? userId1 : userId2;
      const doctorId = user1?.role === 'doctor' ? userId1 : userId2;

      const assistant = await AssistantModel.findByUserId(assistantId);
      if (!assistant || assistant.doctor_id !== doctorId) {
        throw new Error('Assistant can only message their associated doctor');
      }
    }

    return await ConversationModel.getOrCreateDirectConversation(userId1, userId2);
  }

  /**
   * Send message with sanitization
   */
  static async sendMessage(
    conversationId: number,
    senderId: number,
    content: string
  ): Promise<any> {
    // Verify user is member
    const isMember = await ConversationModel.isUserMember(conversationId, senderId);
    if (!isMember) {
      throw new Error('User is not a member of this conversation');
    }

    // Sanitize content (XSS protection)
    const sanitizedContent = xss(content.trim(), {
      whiteList: {}, // No HTML allowed
      stripIgnoreTag: true,
      stripIgnoreTagBody: ['script', 'style'],
    });

    if (!sanitizedContent) {
      throw new Error('Message content is empty after sanitization');
    }

    if (sanitizedContent.length > 5000) {
      throw new Error('Message too long (max 5000 characters)');
    }

    // Create message
    const message = await MessageModel.create(
      conversationId,
      senderId,
      sanitizedContent
    );

    // Get sender info
    const senderResult = await pool.query(
      'SELECT name, family_name FROM users WHERE id = $1',
      [senderId]
    );

    return {
      ...message,
      sender_name: `${senderResult.rows[0].name} ${senderResult.rows[0].family_name}`,
      is_read: false,
    };
  }

  /**
   * Get conversation messages with pagination
   */
  static async getMessages(
    conversationId: number,
    userId: number,
    page: number = 1,
    pageSize: number = 50
  ): Promise<any> {
    // Verify user is member
    const isMember = await ConversationModel.isUserMember(conversationId, userId);
    if (!isMember) {
      throw new Error('User is not a member of this conversation');
    }

    const messages = await MessageModel.getByConversation(
      conversationId,
      userId,
      page,
      pageSize
    );

    return {
      messages,
      page,
      pageSize,
      hasMore: messages.length === pageSize,
    };
  }

  /**
   * Mark message as read
   */
  static async markMessageAsRead(
    messageId: number,
    userId: number
  ): Promise<void> {
    const message = await MessageModel.getById(messageId);
    if (!message) {
      throw new Error('Message not found');
    }

    // Verify user is member of conversation
    const isMember = await ConversationModel.isUserMember(
      message.conversation_id,
      userId
    );
    if (!isMember) {
      throw new Error('User is not a member of this conversation');
    }

    // Don't mark own messages as read
    if (message.sender_id === userId) {
      return;
    }

    await MessageModel.markAsRead(messageId, userId);
  }

  /**
   * Mark all messages in conversation as read
   */
  static async markAllAsRead(
    conversationId: number,
    userId: number
  ): Promise<void> {
    const isMember = await ConversationModel.isUserMember(conversationId, userId);
    if (!isMember) {
      throw new Error('User is not a member of this conversation');
    }

    await MessageModel.markAllAsRead(conversationId, userId);
  }

  /**
   * Update user presence
   */
  static async updatePresence(
    userId: number,
    status: PresenceStatus,
    socketId?: string
  ): Promise<void> {
    await PresenceModel.updateStatus(userId, status, socketId);
  }

  /**
   * Get user presence
   */
  static async getUserPresence(userId: number) {
    return await PresenceModel.getStatus(userId);
  }
}
