import { PatientModel } from "../models/patient.model";

/**
 * Get patients who have prescriptions from a specific doctor
 * @param doctorId The ID of the doctor
 * @returns List of related patients
 */
export const getRelatedPatients = async (doctorId: number) => {
    return await PatientModel.findByDoctorPrescriptions(doctorId);
};
