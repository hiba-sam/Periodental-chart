import OpenAI, { toFile } from 'openai';
import { readFileSync } from 'fs';
import type { Readable } from 'stream';

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
    timeout: 30000, // 30s timeout
});

export interface TranscriptionResult {
    text: string;
    duration_ms: number;
}

export interface MedicalReportResult {
    report: StructuredMedicalReport;
    duration_ms: number;
}

export interface StructuredMedicalReport {
    titre: string;
    date_consultation: string;
    motif_consultation: string;
    anamnese: string;
    examen_clinique: string;
    diagnostic: string;
    traitement_prescrit: string;
    recommandations: string;
    suivi_propose: string;
    observations_complementaires?: string;
}

export interface StructuredCardiologyReport {
    // Clinical exam
    heart_rate?: number | null;
    systolic_bp?: number | null;
    diastolic_bp?: number | null;
    spo2?: number | null;
    auscultation?: string | null;
    lower_limb_edema?: string | null;
    nyha_class?: number | null;
    chest_pain?: string | null;
    heart_failure_signs?: string[] | null;
    // History
    has_hta?: boolean;
    has_diabetes?: boolean;
    has_diabetes_insulin?: boolean;
    has_afib?: boolean;
    has_mi?: boolean;
    has_stroke?: boolean;
    has_heart_failure?: boolean;
    has_arteriopathy?: boolean;
    has_valvulopathy?: boolean;
    has_active_smoking?: boolean;
    has_stopped_smoking?: boolean;
    has_dyslipidemia?: boolean;
    has_endocarditis?: boolean;
    has_prior_cardiac_surgery?: boolean;
    has_chronic_lung_disease?: boolean;
    has_reduced_mobility?: boolean;
    known_lvef?: number | null;
    creatinine?: number | null;
    // Exams - ECG
    ecg_result?: string | null;
    ecg_detail?: string | null;
    // Exams - Echo
    echo_lvef?: number | null;
    echo_lvedd?: number | null;
    echo_la_size?: number | null;
    echo_valvulopathies?: string[] | null;
    echo_pulmonary_htn?: number | null;
    echo_lvesd?: number | null;
    echo_ivs_thickness?: number | null;
    echo_pw_thickness?: number | null;
    echo_tapse?: number | null;
    echo_wall_motion?: string | null;
    echo_wall_motion_detail?: string | null;
    echo_diastolic_function?: string | null;
    echo_pericardial_effusion?: string | null;
    echo_valvulopathy_severity?: Record<string, string> | null;
    // Biology
    bio_bnp?: number | null;
    bio_troponin?: number | null;
    bio_ldl?: number | null;
    bio_hdl?: number | null;
    bio_total_cholesterol?: number | null;
    bio_triglycerides?: number | null;
    bio_hba1c?: number | null;
    bio_creatinine?: number | null;
    bio_inr?: number | null;
    // Patient info (if mentioned)
    patient_weight?: number | null;
    patient_height?: number | null;
    // Notes & unmapped info
    free_notes?: string | null;
    additional_info?: string | null;
}

export interface CardiologyReportResult {
    report: StructuredCardiologyReport;
    duration_ms: number;
}

export class OpenAIService {
    /**
     * Transcrire un fichier audio en texte
     */
    static async transcribeAudio(
        audioPath: string,
        filename: string
    ): Promise<TranscriptionResult> {
        const startTime = Date.now();

        try {
            // Lire le fichier et créer un objet File avec toFile()
            // OpenAI a besoin du nom de fichier avec extension pour détecter le format
            const audioBuffer = readFileSync(audioPath);
            const audioFile = await toFile(audioBuffer, filename, {
                type: this.getMimeType(filename)
            });

            const transcription = await openai.audio.transcriptions.create({
                file: audioFile,
                model: 'whisper-1',
                language: 'fr',
                response_format: 'text',
                temperature: 0.2, // Plus bas = plus précis
            });

            const duration_ms = Date.now() - startTime;

            return {
                text: transcription as string,
                duration_ms
            };

        } catch (error: any) {
            console.error('❌ OpenAI Transcription Error:', {
                message: error.message,
                type: error.type,
                code: error.code,
                status: error.status
            });
            throw new Error(`Transcription failed: ${error.message}`);
        }
    }

    /**
     * Générer un compte rendu médical structuré à partir d'une transcription
     */
    static async generateMedicalReport(
        transcription: string,
        sanitizedTranscription: string
    ): Promise<MedicalReportResult> {
        const startTime = Date.now();

        try {
            const completion = await openai.chat.completions.create({
                model: 'gpt-4o', // ou gpt-4-turbo
                messages: [
                    {
                        role: 'system',
                        content: this.getSystemPrompt()
                    },
                    {
                        role: 'user',
                        content: this.getUserPrompt(sanitizedTranscription)
                    }
                ],
                temperature: 0.3,
                max_tokens: 2000,
                response_format: { type: 'json_object' }
            });

            const content = completion.choices[0]?.message?.content;
            
            if (!content) {
                throw new Error('Empty response from OpenAI');
            }

            const report = JSON.parse(content) as StructuredMedicalReport;
            
            // Validation basique
            this.validateReport(report);

            const duration_ms = Date.now() - startTime;

            return {
                report,
                duration_ms
            };

        } catch (error: any) {
            console.error('❌ OpenAI Generation Error:', {
                message: error.message,
                type: error.type
            });
            throw new Error(`Report generation failed: ${error.message}`);
        }
    }

    /**
     * Générer un rapport cardiologique structuré à partir d'une transcription vocale
     */
    static async generateCardiologyReport(
        transcription: string,
        sanitizedTranscription: string
    ): Promise<CardiologyReportResult> {
        const startTime = Date.now();

        try {
            const completion = await openai.chat.completions.create({
                model: 'gpt-4o',
                messages: [
                    {
                        role: 'system',
                        content: this.getCardiologySystemPrompt()
                    },
                    {
                        role: 'user',
                        content: this.getCardiologyUserPrompt(sanitizedTranscription)
                    }
                ],
                temperature: 0.2,
                max_tokens: 3000,
                response_format: { type: 'json_object' }
            });

            const content = completion.choices[0]?.message?.content;

            if (!content) {
                throw new Error('Empty response from OpenAI');
            }

            const report = JSON.parse(content) as StructuredCardiologyReport;
            const duration_ms = Date.now() - startTime;

            return { report, duration_ms };

        } catch (error: any) {
            console.error('❌ OpenAI Cardiology Generation Error:', {
                message: error.message,
                type: error.type
            });
            throw new Error(`Cardiology report generation failed: ${error.message}`);
        }
    }

    /**
     * Prompt système cardio pour GPT
     */
    private static getCardiologySystemPrompt(): string {
        return `Tu es un assistant cardiologique expert. Le cardiologue te dicte les résultats d'examen d'un patient. Tu dois extraire UNIQUEMENT les valeurs explicitement mentionnées et les mapper dans un JSON structuré.

**RÈGLES STRICTES:**
1. JAMAIS inventer ou déduire une valeur non mentionnée explicitement
2. Les champs non mentionnés doivent être null (nombres) ou false (booléens) ou null (strings)
3. Extraire les valeurs numériques avec précision (PA, FC, FEVG, etc.)
4. Reconnaître les abréviations médicales courantes (PA, FC, FEVG, DTDVG, TAPSE, BNP, etc.)
5. Les antécédents sont des booléens : true si mentionné comme présent, false sinon
6. Toute information qui ne correspond à aucun champ va dans "additional_info"

**CHAMPS ATTENDUS (JSON):**

EXAMEN CLINIQUE:
- "heart_rate": nombre (FC en bpm) ou null
- "systolic_bp": nombre (PAS en mmHg) ou null
- "diastolic_bp": nombre (PAD en mmHg) ou null
- "spo2": nombre (SpO2 en %) ou null
- "auscultation": une valeur parmi ["normal","souffle_systolique","souffle_diastolique","souffle_continu","galop_b3","galop_b4","frottement_pericardique","arythmie"] ou null
- "lower_limb_edema": une valeur parmi ["absent","discrets","moderes","importants"] ou null
- "nyha_class": nombre 1-4 ou null
- "chest_pain": une valeur parmi ["absent","typique","atypique","non_cardiaque"] ou null
- "heart_failure_signs": tableau parmi ["Dyspnée","Orthopnée","DPN","Turgescence jugulaire","Râles crépitants","Hépatomégalie","Reflux hépato-jugulaire"] ou null

ANTÉCÉDENTS (booléens, false si non mentionné):
- "has_hta", "has_diabetes", "has_diabetes_insulin", "has_afib", "has_mi", "has_stroke"
- "has_heart_failure", "has_arteriopathy", "has_valvulopathy"
- "has_active_smoking", "has_stopped_smoking", "has_dyslipidemia"
- "has_endocarditis", "has_prior_cardiac_surgery", "has_chronic_lung_disease", "has_reduced_mobility"
- "known_lvef": nombre ou null (FEVG connue antérieurement)
- "creatinine": nombre ou null

ECG:
- "ecg_result": une valeur parmi ["sinusal_normal","fa","flutter","bbg","bbd","bav","hvg","ischemie","lesion","necrose","autre"] ou null
- "ecg_detail": texte libre pour précisions ECG ou null

ÉCHOGRAPHIE:
- "echo_lvef": nombre (FEVG en %) ou null
- "echo_lvedd": nombre (DTDVG en mm) ou null
- "echo_lvesd": nombre (DTSVG en mm) ou null
- "echo_ivs_thickness": nombre (SIV en mm) ou null
- "echo_pw_thickness": nombre (PP en mm) ou null
- "echo_la_size": nombre (OG en mm) ou null
- "echo_pulmonary_htn": nombre (PAPS/HTAP en mmHg) ou null
- "echo_tapse": nombre (TAPSE en mm) ou null
- "echo_wall_motion": une valeur parmi ["normal","hypokinesia","akinesia","dyskinesia"] ou null
- "echo_wall_motion_detail": texte libre ou null
- "echo_diastolic_function": une valeur parmi ["normal","relaxation_impaired","pseudonormal","restrictive"] ou null
- "echo_pericardial_effusion": une valeur parmi ["absent","minime","modere","important"] ou null
- "echo_valvulopathies": tableau parmi ["IM","IA","RM","RA","IT","IP"] ou null
- "echo_valvulopathy_severity": objet {"IM":"legere","RA":"severe",...} avec valeurs parmi ["legere","moderee","severe"] ou null

BIOLOGIE:
- "bio_bnp": nombre ou null
- "bio_troponin": nombre ou null
- "bio_ldl": nombre ou null
- "bio_hdl": nombre ou null
- "bio_total_cholesterol": nombre ou null
- "bio_triglycerides": nombre ou null
- "bio_hba1c": nombre ou null
- "bio_creatinine": nombre ou null
- "bio_inr": nombre ou null

PATIENT:
- "patient_weight": nombre (kg) ou null
- "patient_height": nombre (cm) ou null

NOTES:
- "free_notes": texte libre pour observations ou null
- "additional_info": TOUTE information mentionnée qui ne correspond à aucun champ ci-dessus. C'est le champ poubelle intelligent. null si vide.

**EXEMPLES DE RECONNAISSANCE VOCALE:**
- "tension 14/8" → systolic_bp: 140, diastolic_bp: 80
- "tension 140 sur 80" → systolic_bp: 140, diastolic_bp: 80
- "PA 13/7" → systolic_bp: 130, diastolic_bp: 70
- "fréquence cardiaque 72" → heart_rate: 72
- "FC 85 battements par minute" → heart_rate: 85
- "FEVG 55%" → echo_lvef: 55
- "fraction d'éjection à 45" → echo_lvef: 45
- "NYHA 2" ou "stade 2 NYHA" → nyha_class: 2
- "patient hypertendu diabétique sous insuline" → has_hta: true, has_diabetes: true, has_diabetes_insulin: true
- "saturation 97" → spo2: 97
- "BNP à 450" → bio_bnp: 450
- "troponine négative" → bio_troponin: 0
- "LDL 1.2" → bio_ldl: 1.2
- "HbA1c 7.5" → bio_hba1c: 7.5
- "créatinine 12" → bio_creatinine: 12
- "INR 2.5" → bio_inr: 2.5

Retourne UNIQUEMENT le JSON, sans texte avant ou après.`;
    }

    /**
     * Prompt utilisateur cardio
     */
    private static getCardiologyUserPrompt(transcription: string): string {
        return `Voici la transcription d'une dictée vocale d'un cardiologue décrivant l'examen d'un patient. Extrais TOUTES les valeurs mentionnées et mappe-les dans le JSON structuré.

**TRANSCRIPTION:**
${transcription}

**INSTRUCTIONS:**
- Extrais chaque valeur numérique et associe-la au bon champ
- Attention aux tensions artérielles raccourcies (14/8 = 140/80)
- Les antécédents mentionnés comme présents → true
- Les antécédents non mentionnés → false (ne PAS mettre true par défaut)
- Tout texte qui ne correspond à aucun champ structuré → additional_info
- Si le médecin donne des recommandations ou un diagnostic textuel → free_notes
- Retourne UNIQUEMENT le JSON valide`;
    }

    /**
     * Prompt système pour GPT
     */
    private static getSystemPrompt(): string {
        return `Tu es un assistant médical expert spécialisé dans la rédaction de comptes rendus médicaux conformes aux standards hospitaliers français.

**RÈGLES STRICTES - IMPÉRATIF:**
1. JAMAIS inventer, déduire ou extrapoler d'informations non mentionnées explicitement
2. JAMAIS ajouter de détails, conseils ou recommandations supplémentaires
3. UNIQUEMENT retranscrire et structurer ce qui a été dit par le médecin
4. Si une information n'est pas mentionnée, écrire "Non précisé"
5. Langage médical professionnel strict, terminologie médicale appropriée
6. Style factuel, objectif, sans interprétation personnelle
7. Pas de formulations familières, uniquement un style médical formel
8. Respecter EXACTEMENT la structure JSON sans ajout

**INTERDICTIONS:**
- Pas d'emoji ou symboles
- Pas de conseils généraux non mentionnés
- Pas d'informations déduites ou supposées
- Pas de formulations subjectives
- Pas de détails ajoutés pour "compléter" le dossier

**FORMAT DE SORTIE:**
Retourne uniquement un objet JSON valide avec ces champs:
{
  "titre": "Consultation pour [motif]" (utilise le motif de consultation comme titre principal, exemple: "Consultation pour douleurs abdominales"),
  "date_consultation": "Date exacte mentionnée au format JJ/MM/AAAA, ou date du jour si non précisée explicitement",
  "motif_consultation": "Raison exacte mentionnée par le médecin",
  "anamnese": "Uniquement les antécédents et symptômes mentionnés",
  "examen_clinique": "Uniquement les observations cliniques énoncées",
  "diagnostic": "Diagnostic exact formulé par le médecin",
  "traitement_prescrit": "Prescriptions exactes avec posologie mentionnée",
  "recommandations": "Uniquement les recommandations explicitement données",
  "suivi_propose": "Plan de suivi tel que mentionné",
  "observations_complementaires": "Autres éléments mentionnés ou 'Non précisé'"
}

**EXEMPLE DE RÉSULTAT ATTENDU:**
{
  "titre": "Consultation pour douleurs abdominales",
  "date_consultation": "14/12/2024",
  "motif_consultation": "Douleurs abdominales",
  "anamnese": "Douleurs évoluant depuis 3 jours, localisées en région épigastrique.",
  "examen_clinique": "Abdomen sensible à la palpation épigastrique, pas de défense.",
  "diagnostic": "Gastrite aiguë",
  "traitement_prescrit": "Oméprazole 20 mg, une prise quotidienne pendant 14 jours.",
  "recommandations": "Alimentation légère, éviter les épices et l'alcool.",
  "suivi_propose": "Consultation de contrôle à J+7.",
  "observations_complementaires": "Patient informé des signes d'alerte."
}`;
    }

    /**
     * Prompt utilisateur
     */
    private static getUserPrompt(transcription: string): string {
        return `Voici la transcription exacte d'une dictée médicale. Restructure UNIQUEMENT les informations présentes dans cette transcription selon le format JSON demandé.

**TRANSCRIPTION:**
${transcription}

**INSTRUCTIONS STRICTES:**
- Retranscris UNIQUEMENT ce qui est explicitement dit dans la transcription
- N'ajoute AUCUNE information supplémentaire, même si cela semble logique
- N'invente AUCUN détail médical, conseil ou recommandation
- Si une section n'est pas mentionnée du tout, écris "Non précisé"
- Utilise la terminologie médicale professionnelle appropriée
- Reste strictement factuel, pas d'interprétation
- Format médical formel uniquement

Retourne uniquement l'objet JSON structuré, sans texte avant ou après.`;
    }

    /**
     * Valider la structure du rapport
     */
    private static validateReport(report: StructuredMedicalReport): void {
        const requiredFields = [
            'titre',
            'date_consultation',
            'motif_consultation',
            'anamnese',
            'examen_clinique',
            'diagnostic',
            'traitement_prescrit',
            'recommandations',
            'suivi_propose'
        ];

        for (const field of requiredFields) {
            if (!report[field as keyof StructuredMedicalReport]) {
                throw new Error(`Missing required field: ${field}`);
            }
        }
    }

    /**
     * Obtenir le type MIME basé sur l'extension
     */
    private static getMimeType(filename: string): string {
        const ext = filename.toLowerCase().split('.').pop();
        const mimeTypes: Record<string, string> = {
            'webm': 'audio/webm',
            'm4a': 'audio/m4a',
            'mp3': 'audio/mpeg',
            'wav': 'audio/wav',
            'mp4': 'audio/mp4',
            'mpeg': 'audio/mpeg',
            'mpga': 'audio/mpeg',
            'ogg': 'audio/ogg',
        };
        return mimeTypes[ext || ''] || 'audio/webm';
    }
}
