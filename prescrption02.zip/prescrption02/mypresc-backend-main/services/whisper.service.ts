/**
 * Service de transcription audio avec Whisper Open Source Local
 * Transcrit l'audio médical en texte pour les comptes rendus
 * Utilise whisper.cpp (C++) ou whisper Python en local - 100% GRATUIT
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';

const execAsync = promisify(exec);

// Configuration Whisper local
const WHISPER_MODEL = process.env.WHISPER_MODEL || 'base'; // tiny, base, small, medium, large
const WHISPER_LANGUAGE = process.env.WHISPER_LANGUAGE || 'fr';
const WHISPER_EXECUTABLE = process.env.WHISPER_EXECUTABLE || 'whisper'; // ou 'main' pour whisper.cpp

interface TranscriptionOptions {
    language?: string;
    prompt?: string;
    temperature?: number;
}

export class WhisperService {
    /**
     * Transcrit un fichier audio en texte avec Whisper Local (Open Source)
     * @param audioFilePath - Chemin vers le fichier audio
     * @param options - Options de transcription
     * @returns Texte transcrit
     */
    static async transcribeAudio(
        audioFilePath: string,
        options: TranscriptionOptions = {}
    ): Promise<string> {
        try {
            console.log(`🎤 Transcription locale avec Whisper ${WHISPER_MODEL}...`);
            
            const language = options.language || WHISPER_LANGUAGE;
            const model = WHISPER_MODEL;
            
            // Construire la commande Whisper
            // Supporte whisper (Python) ou whisper.cpp
            let command: string;
            
            if (WHISPER_EXECUTABLE === 'whisper') {
                // Whisper Python CLI
                command = `whisper "${audioFilePath}" --model ${model} --language ${language} --output_format txt --output_dir "${path.dirname(audioFilePath)}"`;
            } else {
                // whisper.cpp (plus rapide)
                command = `${WHISPER_EXECUTABLE} -m models/ggml-${model}.bin -f "${audioFilePath}" -l ${language} -otxt`;
            }
            
            console.log(`📝 Commande: ${command}`);
            
            // Exécuter la transcription
            const { stdout, stderr } = await execAsync(command, {
                maxBuffer: 10 * 1024 * 1024, // 10MB buffer
                timeout: 120000, // 2 minutes max
            });
            
            // Lire le fichier de sortie .txt
            const outputFile = audioFilePath.replace(/\.[^.]+$/, '.txt');
            
            if (fs.existsSync(outputFile)) {
                const transcription = fs.readFileSync(outputFile, 'utf-8').trim();
                
                // Nettoyer le fichier temporaire
                fs.unlinkSync(outputFile);
                
                if (!transcription) {
                    throw new Error('Transcription vide');
                }
                
                console.log(`✅ Transcription réussie: ${transcription.substring(0, 100)}...`);
                return transcription;
            } else {
                // Fallback: lire depuis stdout si disponible
                const transcription = stdout.trim() || stderr.trim();
                if (!transcription) {
                    throw new Error('Aucune transcription générée');
                }
                return transcription;
            }
            
        } catch (error: any) {
            console.error('❌ Erreur de transcription Whisper local:', error.message);
            
            if (error.message.includes('command not found') || error.message.includes('not recognized')) {
                throw new Error('Whisper n\'est pas installé. Installez-le avec: pip install openai-whisper');
            }
            
            throw new Error(`Échec de la transcription: ${error.message}`);
        }
    }

    /**
     * Vérifie si Whisper est installé et disponible
     */
    static async checkInstallation(): Promise<{ installed: boolean; version?: string; error?: string }> {
        try {
            const { stdout } = await execAsync('whisper --help');
            return {
                installed: true,
                version: stdout.includes('whisper') ? 'Python CLI' : 'Unknown'
            };
        } catch (error: any) {
            return {
                installed: false,
                error: 'Whisper n\'est pas installé. Installez avec: pip install openai-whisper'
            };
        }
    }

}
