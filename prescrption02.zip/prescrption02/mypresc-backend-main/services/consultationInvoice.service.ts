import { ConsultationInvoiceModel } from '../models/consultationInvoice.model';

type InvoiceStatus = 'paid' | 'unpaid' | 'partial' | 'free';

interface InvoiceWithFinancials {
    id: number;
    total_price: number | string;
    amount_paid: number | string;
    status: InvoiceStatus;
    [key: string]: any;
}

/**
 * Single source of truth for deriving the correct invoice status
 * from financial data (total_price and amount_paid).
 */
export function computeCorrectStatus(
    totalPrice: number | string,
    amountPaid: number | string
): InvoiceStatus {
    const price = typeof totalPrice === 'string' ? parseFloat(totalPrice) : totalPrice;
    const paid = typeof amountPaid === 'string' ? parseFloat(amountPaid) : amountPaid;

    if (price === 0) return 'free';
    if (paid >= price) return 'paid';
    if (paid > 0) return 'partial';
    return 'unpaid';
}

/**
 * Verifies and fixes invoice statuses on read.
 * For each invoice, recomputes the correct status from financial data.
 * If the stored status differs, it:
 *   1. Fixes the status in-memory (so the response is correct immediately)
 *   2. Fires a background DB UPDATE to persist the fix (non-blocking)
 * 
 * @param invoices - Array of invoices to verify
 * @returns The same array with corrected statuses
 */
export function verifyAndFixInvoiceStatuses<T extends InvoiceWithFinancials>(
    invoices: T[]
): T[] {
    for (const invoice of invoices) {
        const correctStatus = computeCorrectStatus(invoice.total_price, invoice.amount_paid);

        if (invoice.status !== correctStatus) {
            console.warn(
                `[InvoiceStatusFix] Invoice #${invoice.id}: status was '${invoice.status}' ` +
                `but should be '${correctStatus}' (total_price=${invoice.total_price}, ` +
                `amount_paid=${invoice.amount_paid}). Fixing...`
            );

            // Fix in-memory for immediate correct response
            invoice.status = correctStatus;

            // Fire background DB fix (non-blocking, errors are logged)
            ConsultationInvoiceModel.fixStatus(invoice.id, correctStatus).catch((err) => {
                console.error(`[InvoiceStatusFix] Failed to persist fix for invoice #${invoice.id}:`, err);
            });
        }
    }

    return invoices;
}

/**
 * Validates a manual status transition request against financial data.
 * Ensures the requested status is consistent with amount_paid / total_price.
 * 
 * @returns { ok: true } if valid, or { ok: false, error: string } if invalid
 */
export async function validateStatusTransition(
    invoiceId: number,
    requestedStatus: string,
    doctorUserId: number
): Promise<{ ok: true } | { ok: false; error: string }> {
    const validStatuses = ['paid', 'unpaid', 'partial', 'free'];
    if (!validStatuses.includes(requestedStatus)) {
        return { ok: false, error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` };
    }

    const invoice = await ConsultationInvoiceModel.findById(invoiceId, doctorUserId);
    if (!invoice) {
        return { ok: false, error: 'Invoice not found' };
    }

    const totalPrice = typeof invoice.total_price === 'string'
        ? parseFloat(invoice.total_price) : invoice.total_price;
    const amountPaid = typeof invoice.amount_paid === 'string'
        ? parseFloat(invoice.amount_paid) : invoice.amount_paid;

    // Validate requested status against financial reality
    switch (requestedStatus as InvoiceStatus) {
        case 'paid':
            if (amountPaid < totalPrice) {
                return {
                    ok: false,
                    error: `Cannot mark as 'paid': amount_paid (${amountPaid}) is less than total_price (${totalPrice}). Use 'Add Payment' to record a payment first.`
                };
            }
            break;

        case 'unpaid':
            if (amountPaid > 0) {
                return {
                    ok: false,
                    error: `Cannot mark as 'unpaid': amount_paid is ${amountPaid}. Invoice has existing payments.`
                };
            }
            break;

        case 'partial':
            if (amountPaid <= 0 || amountPaid >= totalPrice) {
                return {
                    ok: false,
                    error: `Cannot mark as 'partial': amount_paid (${amountPaid}) must be between 0 and total_price (${totalPrice}).`
                };
            }
            break;

        case 'free':
            if (totalPrice !== 0) {
                return {
                    ok: false,
                    error: `Cannot mark as 'free': total_price is ${totalPrice}. Only invoices with total_price = 0 can be free.`
                };
            }
            break;
    }

    return { ok: true };
}