import { AppointmentModel, type CreateAppointmentData, type UpdateAppointmentData } from "../models/appointment.model";

type CreateAppointmentInput = {
    patient_id: string;
    date: string | Date;
    time: string;
    duration?: number | null;
    notes?: string;
    color?: string;
    confirmed_coming?: boolean;
    is_done?: boolean;
};

export async function createAppointmentValidated(
    doctorUserId: number,
    input: CreateAppointmentInput
) {
    const { patient_id, date, time, duration, notes, color, confirmed_coming, is_done } = input;

    if (!patient_id || !date || !time) {
        return {
            ok: false as const,
            status: 400,
            error: "Missing required fields: patient_id, date, time"
        };
    }

    const parsedDate = new Date(date);
    if (isNaN(parsedDate.getTime())) {
        return {
            ok: false as const,
            status: 400,
            error: "Invalid date format"
        };
    }

    if (color && !/^#([0-9A-F]{3}){1,2}$/i.test(color)) {
        return {
            ok: false as const,
            status: 400,
            error: "Invalid color format. Use hex color (e.g., #2563eb)"
        };
    }

    const now = new Date();
    const [hoursStr, minutesStr, secondsStr] = (time || "").split(":");
    const hours = parseInt(hoursStr || "0", 10);
    const minutes = parseInt(minutesStr || "0", 10);
    const seconds = parseInt(secondsStr || "0", 10);
    const scheduled = new Date(parsedDate);
    scheduled.setHours(hours, minutes, seconds, 0);
    if (scheduled <= now) {
        return {
            ok: false as const,
            status: 400,
            error: "Appointment date/time must be in the future"
        };
    }

    // Range-based overlap check using duration
    const durationMinutes = (duration ?? 30) as number;
    const [th, tm, ts] = (time || "00:00:00").split(":").map((v) => parseInt(v || "0", 10));
    const startDateTime = new Date(parsedDate);
    startDateTime.setHours(th || 0, tm || 0, ts || 0, 0);
    const endDateTime = new Date(startDateTime.getTime() + durationMinutes * 60000);
    const toTimeString = (d: Date) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
    const startTimeStr = toTimeString(startDateTime);
    const endTimeStr = toTimeString(endDateTime);

    const exists = await AppointmentModel.existsInRange(Number(doctorUserId), parsedDate, startTimeStr, endTimeStr);
    if (exists) {
        return {
            ok: false as const,
            status: 409,
            error: "You already have an appointment during this time"
        };
    }

    const data: CreateAppointmentData = {
        patient_id: String(patient_id),
        doctor_user_id: Number(doctorUserId),
        date: parsedDate,
        time,
        duration: duration ?? undefined,
        notes: notes ?? undefined,
        color: color ?? undefined,
        confirmed_coming: confirmed_coming ?? false,
        is_done: is_done ?? false
    };

    const appointment = await AppointmentModel.create(data);
    return { ok: true as const, appointment };
}

export type UpdateAppointmentInput = Partial<{
    date: string | Date;
    time: string;
    duration: number | null;
    notes: string;
    color: string;
    confirmed_coming: boolean;
    is_done: boolean;
    venue_confirmed: boolean;
    arrived_at: string | Date | null;
}>;

export async function updateAppointmentValidated(
    doctorUserId: number,
    appointmentId: string,
    input: UpdateAppointmentInput
) {
    const existing = await AppointmentModel.findById(appointmentId);
    if (!existing) {
        return { ok: false as const, status: 404, error: "Appointment not found" };
    }
    if (existing.doctor_user_id !== Number(doctorUserId)) {
        return { ok: false as const, status: 400, error: "You are not allowed to update this appointment" };
    }

    const updateData: UpdateAppointmentData = {};

    // Vérifier si la date ou l'heure change (pour reset arrived_at)
    const dateChanged = input.date !== undefined && new Date(input.date).toDateString() !== new Date(existing.date).toDateString();
    const timeChanged = input.time !== undefined && input.time !== existing.time;
    
    if (input.date !== undefined) {
        const parsed = new Date(input.date);
        if (isNaN(parsed.getTime())) {
            return { ok: false as const, status: 400, error: "Invalid date format" };
        }
        updateData.date = parsed;
    }
    if (input.time !== undefined) updateData.time = input.time;
    
    // Si date ou heure change, reset le statut arrivé (le patient doit re-confirmer son arrivée)
    if (dateChanged || timeChanged) {
        updateData.arrived_at = null;
        updateData.confirmed_coming = false;
    }
    if (input.duration !== undefined) updateData.duration = input.duration ?? undefined;
    if (input.notes !== undefined) updateData.notes = input.notes;
    if (input.color !== undefined) {
        if (!/^#([0-9A-F]{3}){1,2}$/i.test(input.color)) {
            return { ok: false as const, status: 400, error: "Invalid color format. Use hex color (e.g., #2563eb)" };
        }
        updateData.color = input.color;
    }
    if (input.confirmed_coming !== undefined) updateData.confirmed_coming = input.confirmed_coming;
    if (input.is_done !== undefined) updateData.is_done = input.is_done;
    if (input.venue_confirmed !== undefined) updateData.venue_confirmed = input.venue_confirmed;
    if (input.arrived_at !== undefined) {
        updateData.arrived_at = input.arrived_at ? new Date(input.arrived_at) : null;
    }

    if (Object.keys(updateData).length === 0) {
        return { ok: false as const, status: 400, error: "No update fields provided" };
    }

    const updated = await AppointmentModel.update(appointmentId, updateData);
    if (!updated) {
        return { ok: false as const, status: 404, error: "Appointment not found or no changes provided" };
    }
    return { ok: true as const, appointment: updated };
}


