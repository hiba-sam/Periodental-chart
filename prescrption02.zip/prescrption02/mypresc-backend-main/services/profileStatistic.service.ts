import pool from '../db';

export class ProfileStatisticService {
    /**
     * Get statistics for a doctor's profile
     * @param doctorUserId The user ID of the doctor (from users table)
     */
    static async getDoctorStatistics(doctorUserId: number) {
        // Query 1: Count distinct patients followed
        const patientsQuery = `
            SELECT COUNT(DISTINCT patient_id)::int as count
            FROM consultations
            WHERE doctor_user_id = $1
        `;

        // Query 2: Count consultations this month
        const consultationsQuery = `
            SELECT COUNT(id)::int as count
            FROM consultations
            WHERE doctor_user_id = $1
            AND consultation_date >= DATE_TRUNC('month', CURRENT_DATE)
            AND consultation_date < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
        `;

        try {
            const [patientsResult, consultationsResult] = await Promise.all([
                pool.query(patientsQuery, [doctorUserId]),
                pool.query(consultationsQuery, [doctorUserId])
            ]);

            return {
                patientsFollowed: patientsResult.rows[0]?.count || 0,
                consultationsThisMonth: consultationsResult.rows[0]?.count || 0
            };
        } catch (error) {
            console.error('Error fetching doctor statistics:', error);
            // Return zeros on error to prevent breaking the profile page
            return {
                patientsFollowed: 0,
                consultationsThisMonth: 0
            };
        }
    }
}
