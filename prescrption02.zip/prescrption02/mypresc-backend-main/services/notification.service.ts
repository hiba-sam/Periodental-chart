/**
 * Notification Service
 *
 * Centralized service for creating notifications across the application.
 * Prevents code duplication and ensures consistent notification structure.
 *
 * Usage:
 *   import { notifyUser } from '../services/notification.service';
 *   await notifyUser(userId, 'Title', 'Description', 'info', '/link');
 */

import { NotificationModel, type CreateNotificationData } from '../models/notification.model';

/**
 * Create a notification for a user
 * @param userId - Target user ID
 * @param title - Notification title
 * @param description - Notification description
 * @param type - Notification type: 'alert' | 'check' | 'error' | 'info'
 * @param link - Optional link/URL for the notification
 * @returns Created notification or null if failed
 */
export async function notifyUser(
    userId: number,
    title: string,
    description: string,
    type: 'alert' | 'check' | 'error' | 'info' = 'info',
    link: string | null = null
) {
    try {
        const notificationData: CreateNotificationData = {
            user_id: userId,
            title,
            description,
            link,
            type,
            is_seen: false
        };

        const notification = await NotificationModel.create(notificationData);
        return notification;
    } catch (error) {
        console.error('[NotificationService] Error creating notification:', error);
        // Don't throw - notifications should not break main flow
        return null;
    }
}

/**
 * Create notifications for multiple users (bulk)
 * @param userIds - Array of user IDs
 * @param title - Notification title
 * @param description - Notification description
 * @param type - Notification type
 * @param link - Optional link
 * @returns Array of created notifications
 */
export async function notifyMultipleUsers(
    userIds: number[],
    title: string,
    description: string,
    type: 'alert' | 'check' | 'error' | 'info' = 'info',
    link: string | null = null
) {
    try {
        const notifications = await Promise.allSettled(
            userIds.map(userId => notifyUser(userId, title, description, type, link))
        );

        return notifications
            .filter(result => result.status === 'fulfilled' && result.value !== null)
            .map(result => (result as PromiseFulfilledResult<any>).value);
    } catch (error) {
        console.error('[NotificationService] Error creating bulk notifications:', error);
        return [];
    }
}

// ============================================
// PREDEFINED NOTIFICATION TEMPLATES
// ============================================

/**
 * User registration notification
 */
export async function notifyUserRegistration(userId: number, userName: string) {
    return notifyUser(
        userId,
        'Bienvenue sur MyPresc',
        `Bonjour ${userName}, votre compte a été créé avec succès. Bienvenue dans notre plateforme !`,
        'check',
        '/profile'
    );
}

/**
 * Profile update notification
 */
export async function notifyProfileUpdate(userId: number) {
    return notifyUser(
        userId,
        'Profil mis à jour',
        'Votre profil a été mis à jour avec succès.',
        'check',
        '/profile'
    );
}

/**
 * Appointment created notification (for patient)
 */
export async function notifyAppointmentCreated(
    patientUserId: number,
    doctorName: string,
    appointmentDate: string,
    appointmentTime: string,
    appointmentId: string
) {
    return notifyUser(
        patientUserId,
        'Nouveau rendez-vous',
        `Votre rendez-vous avec Dr. ${doctorName} a été programmé pour le ${appointmentDate} à ${appointmentTime}.`,
        'info',
        `/appointments/${appointmentId}`
    );
}

/**
 * Appointment updated notification (for patient)
 */
export async function notifyAppointmentUpdated(
    patientUserId: number,
    appointmentDate: string,
    appointmentTime: string,
    appointmentId: string
) {
    return notifyUser(
        patientUserId,
        'Rendez-vous modifié',
        `Votre rendez-vous a été modifié. Nouvelle date: ${appointmentDate} à ${appointmentTime}.`,
        'alert',
        `/appointments/${appointmentId}`
    );
}

/**
 * Appointment cancelled notification (for patient)
 */
export async function notifyAppointmentCancelled(
    patientUserId: number,
    doctorName: string,
    appointmentId: string
) {
    return notifyUser(
        patientUserId,
        'Rendez-vous annulé',
        `Votre rendez-vous avec Dr. ${doctorName} a été annulé.`,
        'alert',
        `/appointments`
    );
}

/**
 * Appointment confirmation notification (for doctor)
 */
export async function notifyDoctorAppointmentConfirmed(
    doctorUserId: number,
    patientName: string,
    appointmentDate: string,
    appointmentTime: string,
    appointmentId: string
) {
    return notifyUser(
        doctorUserId,
        'Rendez-vous confirmé',
        `${patientName} a confirmé le rendez-vous du ${appointmentDate} à ${appointmentTime}.`,
        'check',
        `/appointments/${appointmentId}`
    );
}

/**
 * Patient created notification (for doctor/assistant)
 */
export async function notifyPatientCreated(
    doctorUserId: number,
    patientName: string,
    patientId: string
) {
    return notifyUser(
        doctorUserId,
        'Nouveau patient',
        `Le patient ${patientName} a été ajouté avec succès.`,
        'check',
        `/patients/${patientId}`
    );
}

/**
 * Patient updated notification (for doctor/assistant)
 */
export async function notifyPatientUpdated(
    doctorUserId: number,
    patientName: string,
    patientId: string
) {
    return notifyUser(
        doctorUserId,
        'Patient mis à jour',
        `Les informations du patient ${patientName} ont été mises à jour.`,
        'info',
        `/patients/${patientId}`
    );
}

/**
 * Prescription created notification (for patient)
 */
export async function notifyPrescriptionCreated(
    patientUserId: number,
    doctorName: string,
    prescriptionId: number
) {
    return notifyUser(
        patientUserId,
        'Nouvelle ordonnance',
        `Dr. ${doctorName} vous a délivré une nouvelle ordonnance.`,
        'check',
        `/prescriptions/${prescriptionId}`
    );
}

/**
 * Password reset notification
 */
export async function notifyPasswordReset(userId: number) {
    return notifyUser(
        userId,
        'Mot de passe réinitialisé',
        'Votre mot de passe a été réinitialisé avec succès. Si vous n\'êtes pas à l\'origine de cette action, contactez-nous immédiatement.',
        'alert',
        '/settings/security'
    );
}

/**
 * Email verification notification
 */
export async function notifyEmailVerification(userId: number, email: string) {
    return notifyUser(
        userId,
        'Vérification email requise',
        `Un email de vérification a été envoyé à ${email}. Veuillez vérifier votre boîte de réception.`,
        'info',
        null
    );
}

/**
 * System error notification (for admins)
 */
export async function notifySystemError(
    adminUserIds: number[],
    errorMessage: string,
    errorContext: string
) {
    return notifyMultipleUsers(
        adminUserIds,
        'Erreur système',
        `Une erreur s'est produite: ${errorMessage} (Contexte: ${errorContext})`,
        'error',
        '/admin/logs'
    );
}

/**
 * Data sync error notification
 */
export async function notifySyncError(
    userId: number,
    resourceType: string,
    errorDetails: string
) {
    return notifyUser(
        userId,
        'Erreur de synchronisation',
        `Échec de synchronisation des données (${resourceType}): ${errorDetails}`,
        'error',
        null
    );
}

/**
 * Waiting room notification (for doctor)
 */
export async function notifyWaitingRoomEntry(
    doctorUserId: number,
    patientName: string,
    waitingRoomId: string
) {
    return notifyUser(
        doctorUserId,
        'Nouveau patient en attente',
        `${patientName} est arrivé et attend en salle d'attente.`,
        'info',
        `/waiting-room/${waitingRoomId}`
    );
}

/**
 * Calendar event notification
 */
export async function notifyCalendarEvent(
    userId: number,
    eventTitle: string,
    eventDate: string,
    eventTime: string,
    eventId: string
) {
    return notifyUser(
        userId,
        'Rappel d\'événement',
        `${eventTitle} prévu le ${eventDate} à ${eventTime}.`,
        'info',
        `/calendar/${eventId}`
    );
}

/**
 * Account deactivation notification
 */
export async function notifyAccountDeactivation(userId: number) {
    return notifyUser(
        userId,
        'Compte désactivé',
        'Votre compte a été désactivé. Contactez l\'administrateur pour plus d\'informations.',
        'alert',
        '/contact'
    );
}

/**
 * Account reactivation notification
 */
export async function notifyAccountReactivation(userId: number) {
    return notifyUser(
        userId,
        'Compte réactivé',
        'Votre compte a été réactivé avec succès. Bienvenue de retour !',
        'check',
        '/dashboard'
    );
}
