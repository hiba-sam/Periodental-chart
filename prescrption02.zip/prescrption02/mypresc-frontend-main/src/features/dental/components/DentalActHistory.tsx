'use client';

import { useState, useEffect } from 'react';
import {
    CalendarIcon,
    UserIcon,
    EyeIcon,
} from '@heroicons/react/24/outline';
import type { DentalActHistoryProps, DentalAct, DentalActStatus } from '../types';
import { STATUS_COLORS } from '../types';
import { fetchPatientDentalActs, updateDentalActStatus } from '../api';

// Tooth icon component
const ToothIcon = ({ className }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
    </svg>
);

const STATUS_ORDER: DentalActStatus[] = ['NON_COMMENCE', 'EN_COURS', 'TERMINE', 'ANNULE'];

export default function DentalActHistory({ patientId, onAddClick, onViewDetail, refreshTrigger }: DentalActHistoryProps) {
    const [acts, setActs] = useState<DentalAct[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [statusMenuOpen, setStatusMenuOpen] = useState<number | null>(null);

    // Close menu when clicking outside
    useEffect(() => {
        const handleClickOutside = () => setStatusMenuOpen(null);
        if (statusMenuOpen !== null) {
            document.addEventListener('click', handleClickOutside);
            return () => document.removeEventListener('click', handleClickOutside);
        }
    }, [statusMenuOpen]);

    useEffect(() => {
        const loadActs = async () => {
            setLoading(true);
            const result = await fetchPatientDentalActs(patientId);
            if (result.success && result.data) {
                setActs(result.data);
                setError(null);
            } else {
                setError(result.error || 'Erreur lors du chargement des actes dentaires');
            }
            setLoading(false);
        };

        if (patientId) {
            loadActs();
        }
    }, [patientId, refreshTrigger]);

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        });
    };

    const formatTeeth = (teeth: string[] | null, scope: string) => {
        if (scope === 'MOUTH') return 'Bouche entière';
        if (!teeth || teeth.length === 0) return '-';
        if (teeth.length <= 3) return teeth.join(', ');
        return `${teeth.slice(0, 3).join(', ')} +${teeth.length - 3}`;
    };

    const formatSurfaces = (surfaces: string[] | null) => {
        if (!surfaces || surfaces.length === 0) return '-';
        return surfaces.join(', ');
    };

    const handleStatusChange = async (actId: number, newStatus: DentalActStatus) => {
        const result = await updateDentalActStatus(actId, newStatus);
        if (result.success) {
            // Update local state
            setActs(prev => prev.map(act =>
                act.id === actId ? { ...act, status: newStatus } : act
            ));
        }
        setStatusMenuOpen(null);
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors">
            <div className="flex items-center justify-between mb-4">
                <div className="flex-1"></div>
                <button
                    onClick={onAddClick}
                    className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-lg hover:bg-cyan-700 transition-colors flex items-center gap-2"
                >
                    <span className="text-lg leading-none">+</span>
                    Nouvel acte
                </button>
            </div>

            {loading ? (
                <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-600 mx-auto"></div>
                </div>
            ) : error ? (
                <div className="text-center py-8 text-red-500">{error}</div>
            ) : acts.length === 0 ? (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <ToothIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                    <p className="text-sm font-medium">Aucun acte enregistré</p>
                    <p className="text-xs mt-1">Cliquez sur "Nouvel acte" pour ajouter</p>
                </div>
            ) : (
                <div className="overflow-visible">
                    <table className="w-full">
                        <thead>
                            <tr className="border-b border-gray-200 dark:border-gray-700">
                                <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Date</th>
                                <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Praticien</th>
                                <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Acte</th>
                                <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Dent(s)</th>
                                <th className="text-left py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Surfaces</th>
                                <th className="text-center py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Statut</th>
                                <th className="text-center py-3 px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                            {acts.map((act) => {
                                const status = STATUS_COLORS[act.status] || STATUS_COLORS.NON_COMMENCE;
                                return (
                                    <tr key={act.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <td className="py-3 px-3 text-sm text-gray-600 dark:text-gray-400">
                                            <div className="flex items-center gap-1">
                                                <CalendarIcon className="w-4 h-4" />
                                                {formatDate(act.date_act)}
                                            </div>
                                        </td>
                                        <td className="py-3 px-3 text-sm text-gray-700 dark:text-gray-300">
                                            <div className="flex items-center gap-1">
                                                <UserIcon className="w-4 h-4 text-gray-400" />
                                                Dr. {act.doctor_family_name || '-'}
                                            </div>
                                        </td>
                                        <td className="py-3 px-3">
                                            <div className="text-sm font-medium text-gray-800 dark:text-gray-200 max-w-[200px] truncate" title={act.act_label || act.act_label_cache || '-'}>
                                                {act.act_label || act.act_label_cache || '-'}
                                            </div>
                                            {act.act_code && (
                                                <div className="text-xs text-gray-500 dark:text-gray-400">{act.act_code}</div>
                                            )}
                                        </td>
                                        <td className="py-3 px-3 text-sm text-gray-600 dark:text-gray-400">
                                            {formatTeeth(act.teeth, act.scope)}
                                        </td>
                                        <td className="py-3 px-3 text-sm text-gray-600 dark:text-gray-400">
                                            {formatSurfaces(act.surfaces)}
                                        </td>
                                        <td className="py-3 px-3 text-center relative">
                                            <button
                                                onClick={() => setStatusMenuOpen(statusMenuOpen === act.id ? null : act.id)}
                                                className={`inline-flex px-2 py-1 text-xs font-medium rounded-full cursor-pointer hover:ring-2 hover:ring-offset-1 hover:ring-cyan-400 transition-all ${status.bg} ${status.text}`}
                                            >
                                                {status.label}
                                            </button>
                                            {statusMenuOpen === act.id && (
                                                <div className="absolute z-50 mt-1 right-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-1 min-w-[120px]">
                                                    {STATUS_ORDER.map((s) => {
                                                        const sColor = STATUS_COLORS[s];
                                                        return (
                                                            <button
                                                                key={s}
                                                                onClick={() => handleStatusChange(act.id, s)}
                                                                className={`w-full px-3 py-1.5 text-left text-xs hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2 ${act.status === s ? 'font-bold' : ''}`}
                                                            >
                                                                <span className={`w-2 h-2 rounded-full ${sColor.bg.replace('bg-', 'bg-').replace('/30', '')}`}></span>
                                                                <span className={sColor.text}>{sColor.label}</span>
                                                            </button>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                        </td>
                                        <td className="py-3 px-3 text-center">
                                            <button
                                                onClick={() => onViewDetail(act)}
                                                className="p-1.5 text-gray-500 hover:text-cyan-600 hover:bg-cyan-50 dark:hover:bg-cyan-900/20 rounded-lg transition-colors"
                                                title="Voir détails"
                                            >
                                                <EyeIcon className="w-4 h-4" />
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
