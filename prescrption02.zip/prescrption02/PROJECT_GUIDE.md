# Guide de Fonctionnement - MyPrescription (Version Parodontale)

Ce document explique l'architecture et le fonctionnement du projet MyPrescription, avec un focus sur l'intégration du module de Parodontologie et de gestion des Actes Dentaires.

## 1. Architecture Globale

Le projet est divisé en trois piliers principaux :

*   **Frontend (`mypresc-frontend-main`)** : Application Next.js (React) gérant l'interface utilisateur.
*   **Backend (`mypresc-backend-main`)** : Serveur Bun + Express gérant l'API, la sécurité et la base de données.
*   **Infrastructure (`mypresc-infrastructure-main`)** : Configuration Docker (Postgres, Redis, Nginx) pour le déploiement.

---

## 2. Le Module Dentaire (Dental Acts)

Ce module permet de suivre les interventions dentaires pour chaque patient.

*   **Interface** : Situé dans l'onglet "Actes Dentaires" de la fiche patient.
*   **Fonctionnement** : 
    *   Affiche un historique des actes (Date, Praticien, Libellé, Dents, Statut).
    *   Permet d'ajouter des nouveaux actes via une modal dynamique (`DentalActModal`).
    *   Synchronisation en temps réel avec le backend via l'API `/api/dental-acts`.

---

## 3. Le Module de Parodontologie (Statut Parodontal)

Module avancé pour le diagnostic et le suivi des maladies parodontales.

### A. Graphiques de KPI (Dashboard)
Le dashboard (`PerioKpiDashboard.tsx`) utilise **Recharts** pour visualiser l'évolution clinique du patient :
*   **Indice de Plaque (PI)**.
*   **Saignement au Sondage (BOP)**.
*   **Poches Profondes (Deep Pockets >= 5mm)**.
*   **Perte d'Attache (CAL)**.
*   **Mobilité dentaire**.

Les données sont extraites historiquement pour permettre une comparaison entre les examens.

### B. Charting Parodontal (Éditeur)
L'éditeur (`PeriodontalChartEditor.tsx`) permet une saisie précise site par site (6 sites par dent) :
*   Profondeur de sondage (PD) et Marge Gingivale (MG).
*   Calcul automatique du CAL (PD - MG).
*   Gestion des implants, furcations et mobilité.
*   **Sauvegarde intelligente** : Seuls les examens finalisés apparaissent dans l'historique pour éviter d'encombrer le dossier patient avec des ébauches vides.

### C. Rapports PDF
Génération de rapports professionnels automatisés :
*   Utilise `html2canvas` et `jsPDF`.
*   Inclut le logo, les informations du patient, le tableau des KPI interprété et le schéma graphique complet.

---

## 4. Configuration & Sécurité

### Validation des Secrets
Le backend possède une validation de sécurité stricte (`secretsValidator.ts`). 
*   **Condition** : Les clés `JWT_SECRET` et `SESSION_SECRET` doivent comporter au moins **64 caractères** et avoir une entropie suffisante (mélange de caractères).
*   Si cette condition n'est pas remplie, le serveur refuse de démarrer (Fatal Error).

### Proxy API
Pour éviter les problèmes de CORS et simplifier le déploiement, le frontend Next.js utilise des **Route Handlers** (`src/app/api/...`) qui servent de proxy vers le backend (Port 3333). Cela permet de propager les sessions de manière sécurisée.

---

## 5. Comment Démarrer le Projet

1.  **Infrastructure** :
    ```bash
    cd mypresc-infrastructure-main
    docker-compose up -d
    ```
2.  **Backend** :
    ```bash
    cd mypresc-backend-main
    bun install
    bun run dev
    ```
3.  **Frontend** :
    ```bash
    cd mypresc-frontend-main
    npm install
    npm run dev
    ```

---

*Note : Assurez-vous que le port 3333 est libre sur votre machine hôte pour permettre la communication entre les modules.*
