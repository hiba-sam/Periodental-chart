#!/bin/bash
# ============================================
# MyPrescription - Rollback Script
# Usage: ./rollback.sh <timestamp> [--db]
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$SCRIPT_DIR/backups"
COMPOSE_FILE="docker-compose.yml"

# Parse arguments
TIMESTAMP=""
RESTORE_DB=false

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --db) RESTORE_DB=true ;;
        *) TIMESTAMP="$1" ;;
    esac
    shift
done

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   MyPrescription Rollback Script${NC}"
echo -e "${BLUE}============================================${NC}"

# List available backups if no timestamp provided
if [ -z "$TIMESTAMP" ]; then
    echo -e "${YELLOW}Available backups:${NC}"
    ls -la "$BACKUP_DIR"/*.sql 2>/dev/null | while read line; do
        echo "  $line"
    done
    echo ""
    echo -e "${YELLOW}Usage: ./rollback.sh <timestamp> [--db]${NC}"
    echo -e "Example: ./rollback.sh 20241218_143000 --db"
    exit 0
fi

# Check backup exists
COMPOSE_BACKUP="$BACKUP_DIR/compose_$TIMESTAMP.yml"
DB_BACKUP="$BACKUP_DIR/db_$TIMESTAMP.sql"

if [ ! -f "$COMPOSE_BACKUP" ]; then
    echo -e "${RED}ERROR: Compose backup not found: $COMPOSE_BACKUP${NC}"
    exit 1
fi

echo -e "${YELLOW}Rolling back to: $TIMESTAMP${NC}"
echo ""

# Stop current containers
echo -e "${YELLOW}[1/4] Stopping current containers...${NC}"
docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" down --remove-orphans 2>/dev/null || true
echo -e "${GREEN}✓ Containers stopped${NC}"

# Restore database if requested
if [ "$RESTORE_DB" = true ]; then
    if [ -f "$DB_BACKUP" ]; then
        echo -e "${YELLOW}[2/4] Restoring database...${NC}"
        
        # Start only postgres
        docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" up -d postgres
        sleep 10
        
        # Restore
        docker exec -i mypresc-db psql -U mypresc_user mypresc_db < "$DB_BACKUP"
        
        echo -e "${GREEN}✓ Database restored${NC}"
    else
        echo -e "${RED}WARNING: Database backup not found: $DB_BACKUP${NC}"
    fi
else
    echo -e "${YELLOW}[2/4] Skipping database restore (use --db to enable)${NC}"
fi

# Start containers with backed up config
echo -e "${YELLOW}[3/4] Starting containers...${NC}"
docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" up -d
echo -e "${GREEN}✓ Containers started${NC}"

# Health check
echo -e "${YELLOW}[4/4] Running health checks...${NC}"
sleep 10

RUNNING=$(docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" ps --status running -q | wc -l)
echo -e "${GREEN}✓ $RUNNING containers running${NC}"

echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}   Rollback Complete!${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""
echo -e "View logs: ${BLUE}docker compose logs -f${NC}"
echo ""
