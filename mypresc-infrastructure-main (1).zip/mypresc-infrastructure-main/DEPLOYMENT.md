# MyPrescription - Guide de Déploiement Docker

## 📋 Prérequis

- VPS Ubuntu 22.04+ avec:
  - Docker 24+ installé
  - Docker Compose v2+
  - UFW firewall actif (ports 22, 80, 443)
  - Utilisateur non-root avec sudo
  - Fail2ban configuré

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        INTERNET                             │
└─────────────────────────┬───────────────────────────────────┘
                          │ :80/:443
┌─────────────────────────▼───────────────────────────────────┐
│                     NGINX (edge)                             │
│  - TLS termination                                           │
│  - Rate limiting                                             │
│  - Security headers                                          │
│  - Reverse proxy                                             │
└────────┬─────────────────────────────────┬──────────────────┘
         │                                 │
┌────────▼────────┐               ┌────────▼────────┐
│    FRONTEND     │               │     BACKEND     │
│   (Next.js)     │               │  (Bun/Express)  │
│    :3000        │               │     :3333       │
└─────────────────┘               └────────┬────────┘
                                           │
                              ┌────────────▼────────────┐
                              │      POSTGRESQL         │
                              │    (internal only)      │
                              │         :5432           │
                              └─────────────────────────┘
```

## 📁 Structure des fichiers

```
deploy/
├── docker-compose.yml          # Production
├── docker-compose.staging.yml  # Staging
├── .env.example                # Template variables
├── .env                        # Actual variables (gitignored)
├── deploy.sh                   # Deployment script
├── rollback.sh                 # Rollback script
├── init-ssl.sh                 # SSL setup
├── nginx/
│   ├── nginx.conf              # Production nginx config
│   ├── nginx.staging.conf      # Staging nginx config
│   ├── ssl/                    # SSL certificates
│   └── logs/                   # Nginx logs
└── backups/                    # Automatic backups
```

## 🔐 Variables d'environnement

### Variables STANDARD (peuvent être en .env):

| Variable | Description | Exemple |
|----------|-------------|---------|
| `ENVIRONMENT` | Environnement | `production` |
| `DOMAIN` | Domaine principal | `app.mypresc.dz` |
| `POSTGRES_USER` | Utilisateur DB | `mypresc_user` |
| `POSTGRES_DB` | Nom de la DB | `mypresc_db` |
| `SMTP_HOST` | Serveur SMTP | `smtp.gmail.com` |
| `SMTP_PORT` | Port SMTP | `587` |
| `FRONTEND_URL` | URL frontend | `https://app.mypresc.dz` |
| `BASE_URL` | URL API | `https://app.mypresc.dz` |

### Variables SECRETS (🔐 VAULT OBLIGATOIRE en production):

| Variable | Source | Génération |
|----------|--------|------------|
| `POSTGRES_PASSWORD` | Vault | `openssl rand -base64 32` |
| `JWT_SECRET` | Vault | `node -e "console.log(require('crypto').randomBytes(64).toString('base64'))"` |
| `SESSION_SECRET` | Vault | `node -e "console.log(require('crypto').randomBytes(64).toString('base64'))"` |
| `ENCRYPTION_KEY` | Vault | `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `DATA_ENCRYPTION_KEY` | Vault | `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `HASH_SALT` | Vault | `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `CHARGILY_API_KEY` | Vault | Fourni par Chargily |
| `CHARGILY_SECRET_KEY` | Vault | Fourni par Chargily |
| `SMTP_PASS` | Vault | App password Gmail |

## 🚀 Déploiement

### 1. Préparation sur le VPS

```bash
# Connexion
ssh mypresc@votre-ip

# Créer le dossier
mkdir -p ~/mypresc && cd ~/mypresc

# Cloner le repository
git clone https://github.com/votre-repo/mypresc-nextjs.git .

# Aller dans le dossier deploy
cd deploy
```

### 2. Configuration

```bash
# Copier le template
cp .env.example .env

# Éditer les variables
nano .env
```

### 3. Premier déploiement

```bash
# Rendre les scripts exécutables
chmod +x deploy.sh rollback.sh init-ssl.sh

# Déployer avec build
./deploy.sh --build
```

### 4. Configuration SSL (après premier déploiement)

```bash
./init-ssl.sh app.mypresc.dz admin@mypresc.dz
```

## 📊 Commandes utiles

```bash
# Voir les logs
docker compose logs -f

# Logs d'un service spécifique
docker compose logs -f backend

# Status des conteneurs
docker compose ps

# Redémarrer un service
docker compose restart backend

# Accéder au conteneur
docker compose exec backend sh

# Accéder à PostgreSQL
docker compose exec postgres psql -U mypresc_user mypresc_db

# Backup manuel de la DB
docker compose exec postgres pg_dump -U mypresc_user mypresc_db > backup.sql
```

## ✅ Checklist de validation

```bash
# 1. Vérifier les conteneurs
docker compose ps

# 2. Vérifier le health du backend
curl -s http://localhost:3333/health

# 3. Vérifier nginx
curl -I http://localhost

# 4. Vérifier les headers de sécurité
curl -I https://app.mypresc.dz | grep -E "(Strict-Transport|X-Frame|X-Content-Type)"

# 5. Vérifier les ports exposés (seulement 80, 443)
sudo ss -tulpen | grep LISTEN

# 6. Test de connexion DB
docker compose exec backend bun run scripts/test-db-connection.ts

# 7. Vérifier les logs d'erreur
docker compose logs backend | grep -i error
```

## 🔄 Rollback

```bash
# Lister les backups disponibles
./rollback.sh

# Rollback sans restaurer la DB
./rollback.sh 20241218_143000

# Rollback avec restauration DB
./rollback.sh 20241218_143000 --db
```

## 🛡️ Sécurité

- ✅ PostgreSQL accessible uniquement en interne (réseau `internal`)
- ✅ Backend accessible uniquement via nginx (réseau `edge`)
- ✅ Conteneurs en user non-root
- ✅ Headers OWASP configurés (HSTS, X-Frame-Options, etc.)
- ✅ Rate limiting sur /auth/login (5 req/min)
- ✅ TLS 1.2/1.3 uniquement
- ✅ Secrets via HashiCorp Vault (production)

## 📞 Support

En cas de problème:
1. Vérifier les logs: `docker compose logs -f`
2. Vérifier le status: `docker compose ps`
3. Consulter ce guide
