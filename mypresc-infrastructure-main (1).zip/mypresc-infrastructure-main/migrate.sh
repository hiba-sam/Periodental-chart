#!/bin/bash
# ============================================
# MyPrescription - Migration Script
# Usage: ./migrate.sh
# ============================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(dirname "$SCRIPT_DIR")"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Repository URLs (Update these)
REPO_INFRASTRUCTURE=https://github.com/myprescription2026/mypresc-infrastructure.git
REPO_BACKEND=https://github.com/myprescription2026/mypresc-backend.git
REPO_FRONTEND=https://github.com/myprescription2026/mypresc-frontend.git

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   MyPrescription Migration Script${NC}"
echo -e "${BLUE}============================================${NC}"

echo -e "${RED}WARNING: This script will stop services and reorganize directories.${NC}"
read -p "Are you sure you want to continue? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
fi

# 1. Stop existing services
echo -e "${YELLOW}[1/5] Stopping services...${NC}"
if [ -d "deploy" ]; then
    echo -e "Stopping services in 'deploy' folder..."
    (cd deploy && docker compose down --remove-orphans || true)
elif [ -f "docker-compose.yml" ]; then
    docker compose down --remove-orphans || true
fi

# 2. Backup/Rename old directories
echo -e "${YELLOW}[2/5] Renaming old directories to *_legacy...${NC}"

# Helper function to rename if exists
rename_legacy() {
    if [ -d "$1" ]; then
        mv "$1" "${1}_legacy_$TIMESTAMP"
        echo -e "${GREEN}✓ $1 -> ${1}_legacy_$TIMESTAMP${NC}"
    fi
}

rename_legacy "backend"
rename_legacy "frontend"
rename_legacy "website"
rename_legacy "testsprite_tests"
rename_legacy "deploy" 
# Note: 'deploy' contains our previous config, we need to extract .env later

# 3. Clone new repositories
echo -e "${YELLOW}[3/5] Cloning new repositories...${NC}"

clone_repo() {
    NAME=$1
    URL=$2
    if [ ! -d "$NAME" ]; then
        if [[ "$URL" == *"<REPO_URL"* ]]; then
            echo -e "${RED}SKIPPING $NAME: URL not set in script${NC}"
        else
            echo -e "Cloning $NAME..."
            git clone "$URL" "$NAME"
        fi
    else
        echo -e "${GREEN}✓ $NAME already exists${NC}"
    fi
}

clone_repo "mypresc-infrastructure" "$REPO_INFRASTRUCTURE"
clone_repo "mypresc-backend" "$REPO_BACKEND"
clone_repo "mypresc-frontend" "$REPO_FRONTEND"

# 4. Restore Configuration
echo -e "${YELLOW}[4/5] Restoring configuration...${NC}"

# Find the latest deploy_legacy folder
LATEST_DEPLOY_BACKUP=$(ls -td deploy_legacy_* | head -1)

if [ -n "$LATEST_DEPLOY_BACKUP" ] && [ -d "mypresc-infrastructure" ]; then
    if [ -f "$LATEST_DEPLOY_BACKUP/.env" ]; then
        echo -e "Copying .env from $LATEST_DEPLOY_BACKUP to mypresc-infrastructure..."
        cp "$LATEST_DEPLOY_BACKUP/.env" "mypresc-infrastructure/.env"
        echo -e "${GREEN}✓ .env restored${NC}"
    else
        echo -e "${RED}WARNING: .env not found in $LATEST_DEPLOY_BACKUP${NC}"
    fi
else
    echo -e "${RED}WARNING: Could not locate backup or new infrastructure folder to restore .env${NC}"
fi

# 5. Final Instructions
echo -e "${YELLOW}[5/5] Migration structure setup complete.${NC}"
echo -e "Next steps:"
echo -e "1. cd mypresc-infrastructure"
echo -e "2. ./deploy.sh --build"
