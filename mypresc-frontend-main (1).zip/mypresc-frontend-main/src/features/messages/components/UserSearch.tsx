'use client';

import React, { useState, useCallback } from 'react';
import { Search } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useMessaging } from '../hooks';

interface Doctor {
    id: number;
    name: string;
    family_name: string;
    full_name: string;
    speciality?: string;
}

interface UserSearchProps {
    onSelectConversation?: (conversationId: number) => void;
}

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

export default function UserSearch({ onSelectConversation }: UserSearchProps) {
    const router = useRouter();
    const { refreshConversations } = useMessaging();
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<Doctor[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isOpen, setIsOpen] = useState(false);

    const searchDoctors = useCallback(async (searchQuery: string) => {
        if (searchQuery.trim().length < 2) {
            setResults([]);
            return;
        }

        setIsLoading(true);
        try {
            const res = await fetch(
                `${API_URL}/messaging/users/search?query=${encodeURIComponent(searchQuery)}`,
                {
                    credentials: 'include', // Envoie les cookies HTTP-only
                }
            );

            if (res.ok) {
                const data = await res.json();
                setResults(data.data || []);
                setIsOpen(true);
            }
        } catch (error) {
            console.error('Search error:', error);
        } finally {
            setIsLoading(false);
        }
    }, []);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setQuery(value);
        searchDoctors(value);
    };

    const handleSelectDoctor = async (doctor: Doctor) => {
        try {
            const res = await fetch(`${API_URL}/messaging/conversations`, {
                method: 'POST',
                credentials: 'include', // Envoie les cookies HTTP-only
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ peerUserId: doctor.id }),
            });

            if (res.ok) {
                const data = await res.json();
                const conversationId = data.data.conversationId;

                // Refresh conversation list
                refreshConversations();

                // Select conversation (or navigate if no callback)
                if (onSelectConversation) {
                    onSelectConversation(conversationId);
                } else {
                    router.push(`/messages/${conversationId}`);
                }

                // Reset search
                setQuery('');
                setResults([]);
                setIsOpen(false);
            }
        } catch (error) {
            console.error('Failed to create conversation:', error);
        }
    };

    return (
        <div className="relative">
            <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                    type="text"
                    placeholder="Rechercher un médecin..."
                    value={query}
                    onChange={handleInputChange}
                    onFocus={() => query.length >= 2 && setIsOpen(true)}
                    onBlur={() => setTimeout(() => setIsOpen(false), 200)}
                    className="w-full pl-11 pr-4 py-2.5 md:py-3 bg-white/90 dark:bg-gray-800 md:bg-white md:dark:bg-gray-700 rounded-xl text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-400 md:placeholder-gray-500 md:dark:placeholder-gray-400 transition-all duration-200 outline-none"
                />
                {isLoading && (
                    <div className="absolute right-4 top-1/2 -translate-y-1/2">
                        <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                )}
            </div>

            {/* Results dropdown */}
            {isOpen && results.length > 0 && (
                <div className="absolute z-50 w-full mt-2 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl shadow-xl max-h-80 overflow-y-auto">
                    {results.map((doctor) => (
                        <button
                            key={doctor.id}
                            onClick={() => handleSelectDoctor(doctor)}
                            className="w-full px-4 py-3.5 text-left hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 dark:hover:from-blue-900/20 dark:hover:to-purple-900/20 border-b border-gray-100 dark:border-gray-700 last:border-0 transition-all duration-200 group"
                        >
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-md">
                                    {doctor.full_name.charAt(0).toUpperCase()}
                                </div>
                                <div className="flex-1">
                                    <div className="font-semibold text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                                        {doctor.full_name}
                                    </div>
                                    {doctor.speciality && (
                                        <div className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                                            {doctor.speciality}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </button>
                    ))}
                </div>
            )}

            {isOpen && query.length >= 2 && results.length === 0 && !isLoading && (
                <div className="absolute z-50 w-full mt-2 bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-xl shadow-xl p-6 text-center">
                    <div className="text-gray-400 mb-2">😕</div>
                    <div className="text-gray-600 dark:text-gray-300 font-medium">Aucun médecin trouvé</div>
                    <div className="text-sm text-gray-400 mt-1">Essayez un autre nom</div>
                </div>
            )}
        </div>
    );
}
