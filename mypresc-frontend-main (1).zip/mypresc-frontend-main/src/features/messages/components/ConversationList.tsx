'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useMessaging } from '../hooks';
import { MessageCircle } from 'lucide-react';
import PresenceIndicator from './PresenceIndicator';

interface ConversationListProps {
    selectedId?: number | null;
    onSelectConversation?: (conversationId: number) => void;
}

export default function ConversationList({ selectedId, onSelectConversation }: ConversationListProps) {
    const pathname = usePathname();
    const { conversations, conversationPartner, isLoading } = useMessaging();

    const getActiveConversationId = () => {
        if (selectedId !== undefined) return selectedId;
        const match = pathname.match(/\/messages\/(\d+)/);
        return match ? parseInt(match[1]!) : null;
    };

    const activeId = getActiveConversationId();

    if (isLoading) {
        return (
            <div className="p-4 space-y-2">
                {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded-lg animate-pulse" />
                ))}
            </div>
        );
    }

    if (conversations.length === 0) {
        return (
            <div className="p-8 text-center">
                <MessageCircle className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                <p className="text-gray-500 dark:text-gray-400">
                    Aucune conversation
                </p>
                <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                    Recherchez un médecin pour commencer
                </p>
            </div>
        );
    }

    const handleClick = (conversationId: number) => {
        if (onSelectConversation) {
            onSelectConversation(conversationId);
        }
    };

    // Separate assistant conversation from other conversations
    const assistantConversation = conversationPartner
        ? conversations.find(conv => conv.id === conversationPartner.id)
        : null;

    const regularConversations = conversationPartner
        ? conversations.filter(conv => conv.id !== conversationPartner.id)
        : conversations;

    const renderConversation = (conversation: typeof conversations[0], isAssistant = false) => {
        const isActive = conversation.id === activeId;

        const conversationContent = (
            <div className="flex items-start gap-3">
                {/* Avatar with presence indicator */}
                <div className="relative flex-shrink-0">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold shadow-md ${isAssistant
                        ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                        : 'bg-gradient-to-br from-blue-500 to-purple-600'
                        }`}>
                        {conversation.other_user_name.charAt(0).toUpperCase()}
                    </div>
                    <div className="absolute -bottom-1 -right-1">
                        <PresenceIndicator userId={conversation.other_user_id} />
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                        <h3 className={`font-semibold truncate ${conversation.unread_count > 0 ? 'text-gray-900 dark:text-gray-100' : 'text-gray-700 dark:text-gray-300'
                            }`}>
                            {conversation.other_user_name}
                        </h3>
                        {conversation.last_message_at && (
                            <span className="text-xs text-gray-500 flex-shrink-0">
                                {formatDistanceToNow(new Date(conversation.last_message_at), {
                                    locale: fr,
                                    addSuffix: true,
                                })}
                            </span>
                        )}
                    </div>

                    <p className={`text-sm truncate mt-1 ${conversation.last_message
                            ? conversation.unread_count > 0
                                ? 'text-gray-900 dark:text-gray-100 font-medium'
                                : 'text-gray-600 dark:text-gray-400'
                            : 'text-gray-400 dark:text-gray-500 italic'
                        }`}>
                        {conversation.last_message || 'Aucun message — dites bonjour ! 👋'}
                    </p>

                    {conversation.unread_count > 0 && (
                        <div className="mt-2">
                            <span className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 text-xs font-bold text-white rounded-full shadow-md ${isAssistant
                                ? 'bg-gradient-to-r from-green-600 to-emerald-600'
                                : 'bg-gradient-to-r from-blue-600 to-purple-600 animate-pulse'
                                }`}>
                                {conversation.unread_count}
                            </span>
                        </div>
                    )}
                </div>
            </div>
        );

        const className = `block p-4 transition-all duration-200 cursor-pointer ${isAssistant
            ? `hover:bg-gradient-to-r hover:from-green-50 hover:to-emerald-50 dark:hover:from-green-900/20 dark:hover:to-emerald-900/20 ${isActive ? 'bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 border-l-4 border-green-500 shadow-sm' : ''
            }`
            : `hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 dark:hover:from-blue-900/20 dark:hover:to-purple-900/20 ${isActive ? 'bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 border-l-4 border-blue-500 shadow-sm' : ''
            }`
            }`;

        return onSelectConversation ? (
            <button
                key={conversation.id}
                onClick={() => handleClick(conversation.id)}
                className={`${className} w-full text-left`}
            >
                {conversationContent}
            </button>
        ) : (
            <Link
                key={conversation.id}
                href={`/messages/${conversation.id}`}
                className={className}
            >
                {conversationContent}
            </Link>
        );
    };

    return (
        <div className="flex flex-col h-full">
            {/* Regular Conversations */}
            <div className="flex-1 divide-y divide-gray-100 dark:divide-gray-800 overflow-y-auto">
                {regularConversations.length === 0 && !assistantConversation && (
                    <div className="p-8 text-center">
                        <MessageCircle className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                        <p className="text-gray-500 dark:text-gray-400">
                            Aucune conversation
                        </p>
                        <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
                            Recherchez un médecin pour commencer
                        </p>
                    </div>
                )}
                {regularConversations.map((conversation) => renderConversation(conversation, false))}
            </div>

            {/* Assistant Conversation Section - Fixed at bottom */}
            {assistantConversation && (
                <div className="border-t-2 border-green-200 dark:border-green-800/50 bg-gradient-to-r from-green-50/50 to-emerald-50/50 dark:from-green-900/10 dark:to-emerald-900/10">
                    <div className="px-4 py-2 bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30">
                        <h4 className="text-xs font-bold text-green-800 dark:text-green-300 uppercase tracking-wide flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Votre Assistant(e)
                        </h4>
                    </div>
                    <div className="divide-y divide-green-100 dark:divide-green-800/30">
                        {renderConversation(assistantConversation, true)}
                    </div>
                </div>
            )}
        </div>
    );
}
