'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Paperclip, X, FileText, Image as ImageIcon, Loader2, Share2 } from 'lucide-react';
import socketClient from '@/utils/socketClient';
import { useAuth } from '@/contexts/AuthContext';
import axios from 'axios';
import ShareMedicalFileModal from './ShareMedicalFileModal';

interface MessageInputProps {
    conversationId: number;
    recipientDoctorId?: number;
    recipientDoctorName?: string;
    recipientIsDoctor?: boolean; // Only show share button when recipient is a doctor
    onMessageSent?: (optimisticMessage: any) => void;
}

export default function MessageInput({ conversationId, recipientDoctorId, recipientDoctorName, recipientIsDoctor = false, onMessageSent }: MessageInputProps) {
    const [message, setMessage] = useState('');
    const [isSending, setIsSending] = useState(false);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [isUploadingFile, setIsUploadingFile] = useState(false);
    const [isShareModalOpen, setIsShareModalOpen] = useState(false);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { user } = useAuth();

    const isDoctor = user?.role === 'doctor';
    // Only allow medical file sharing between doctors (doctor-to-doctor)
    const canShareMedicalFile = isDoctor && recipientIsDoctor;

    // Typing indicator debounce
    const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const isTypingRef = useRef(false);

    // Send typing stop when unmounting or conversation changes
    useEffect(() => {
        return () => {
            if (isTypingRef.current) {
                socketClient.stopTyping(conversationId);
                isTypingRef.current = false;
            }
            if (typingTimeoutRef.current) {
                clearTimeout(typingTimeoutRef.current);
            }
        };
    }, [conversationId]);

    const handleTyping = useCallback(() => {
        // Start typing if not already typing
        if (!isTypingRef.current) {
            socketClient.startTyping(conversationId);
            isTypingRef.current = true;
        }

        // Clear existing timeout
        if (typingTimeoutRef.current) {
            clearTimeout(typingTimeoutRef.current);
        }

        // Stop typing after 2 seconds of inactivity
        typingTimeoutRef.current = setTimeout(() => {
            if (isTypingRef.current) {
                socketClient.stopTyping(conversationId);
                isTypingRef.current = false;
            }
        }, 2000);
    }, [conversationId]);

    const handleSend = async () => {
        const trimmedMessage = message.trim();

        if (!trimmedMessage || isSending || !user) {
            return;
        }

        setIsSending(true);

        // Clear input immediately for instant feedback
        setMessage('');

        // Reset textarea height
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
        }

        // Get correct sender ID
        // For assistants: user.id = doctor_id, user.assistant_id = assistant's actual ID
        // For doctors: user.id = doctor's actual ID
        const isAssistant = user.role === 'assistant';
        const senderId = isAssistant && user.assistant_id ? Number(user.assistant_id) : Number(user.id);

        // Get full name (name + family_name)
        const senderName = `${user.name || ''} ${user.family_name || ''}`.trim() || user.email.split('@')[0];

        // Send with optimistic update
        const optimisticMsg = socketClient.sendMessageOptimistic(
            conversationId,
            trimmedMessage,
            senderId,
            senderName!,
            (update) => {
                if (update.confirmed) {
                    //  Message saved to database
                    console.log('Message confirmed with ID:', update.realId);
                } else if (update.failed) {
                    //  Show error
                    console.error('Message failed:', update.error);
                    alert('Échec de l\'envoi du message. Veuillez réessayer.');
                }
                setIsSending(false);
            }
        );

        // Notify parent immediately with optimistic message
        onMessageSent?.(optimisticMsg);
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setMessage(e.target.value);

        // Emit typing indicator
        if (e.target.value.trim()) {
            handleTyping();
        } else if (isTypingRef.current) {
            // Stop typing if input is empty
            socketClient.stopTyping(conversationId);
            isTypingRef.current = false;
        }

        // Auto-resize textarea
        e.target.style.height = 'auto';
        e.target.style.height = e.target.scrollHeight + 'px';
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // Validate file type
            const validTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
            if (!validTypes.includes(file.type)) {
                alert('Type de fichier non supporté. Veuillez sélectionner une image ou un PDF.');
                return;
            }
            // Validate file size (10MB max)
            if (file.size > 10 * 1024 * 1024) {
                alert('Le fichier est trop volumineux. Taille maximum: 10MB');
                return;
            }
            setSelectedFile(file);
        }
        // Reset input to allow selecting the same file again
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const handleSendWithAttachment = async () => {
        if (!selectedFile || isUploadingFile || !user) return;

        setIsUploadingFile(true);

        try {
            const formData = new FormData();
            formData.append('attachment', selectedFile);
            if (message.trim()) {
                formData.append('content', message.trim());
            }

            const response = await axios.post(
                `${process.env.NEXT_PUBLIC_BACKEND_URL}/messaging/conversations/${conversationId}/attachment`,
                formData,
                {
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                }
            );

            if (response.data?.success) {
                // Clear message and file
                setMessage('');
                setSelectedFile(null);
                if (textareaRef.current) {
                    textareaRef.current.style.height = 'auto';
                }
                // Notify parent
                onMessageSent?.(response.data.data);
            }
        } catch (error: any) {
            console.error('Error uploading attachment:', error);
            alert(error.response?.data?.error || 'Erreur lors de l\'envoi du fichier');
        } finally {
            setIsUploadingFile(false);
        }
    };

    const removeSelectedFile = () => {
        setSelectedFile(null);
    };

    const getFileIcon = () => {
        if (!selectedFile) return null;
        const isImage = selectedFile.type.startsWith('image/');
        return isImage ? <ImageIcon className="w-4 h-4" /> : <FileText className="w-4 h-4" />;
    };

    const handleShareComplete = (shareMessage: string) => {
        setIsShareModalOpen(false);

        // Send the message directly
        if (!user) return;

        const isAssistant = user.role === 'assistant';
        const senderId = isAssistant && user.assistant_id ? Number(user.assistant_id) : Number(user.id);
        const senderName = `${user.name || ''} ${user.family_name || ''}`.trim() || user.email.split('@')[0];

        const optimisticMsg = socketClient.sendMessageOptimistic(
            conversationId,
            shareMessage,
            senderId,
            senderName,
            (update) => {
                if (update.confirmed) {
                    console.log('Share message confirmed with ID:', update.realId);
                } else if (update.failed) {
                    console.error('Share message failed:', update.error);
                    alert('Échec de l\'envoi du message de partage.');
                }
            }
        );

        onMessageSent?.(optimisticMsg);
    };

    return (
        <>
            {/* Share Medical File Modal */}
            {canShareMedicalFile && (
                <ShareMedicalFileModal
                    isOpen={isShareModalOpen}
                    onClose={() => setIsShareModalOpen(false)}
                    recipientDoctorId={recipientDoctorId}
                    recipientDoctorName={recipientDoctorName}
                    conversationId={conversationId}
                    onShareComplete={handleShareComplete}
                />
            )}

            {/* Hidden file input — shared between both layouts */}
            {isDoctor && (
                <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,image/*,application/pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                />
            )}

            {/* ── MOBILE LAYOUT ──────────────────────────────────────────── */}
            <div className="md:hidden bg-white dark:bg-gray-900 px-3 py-2 border-t border-gray-100 dark:border-gray-800 safe-area-inset-bottom">
                {/* File preview */}
                {selectedFile && (
                    <div className="mb-2 px-1 py-1.5 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
                        <div className="flex items-center justify-between px-2">
                            <div className="flex items-center gap-2 text-xs text-blue-700 dark:text-blue-300">
                                {getFileIcon()}
                                <span className="truncate max-w-[180px]">{selectedFile.name}</span>
                                <span className="text-blue-400">({(selectedFile.size / 1024 / 1024).toFixed(1)} MB)</span>
                            </div>
                            <button onClick={removeSelectedFile} className="p-1 rounded-full hover:bg-blue-100 dark:hover:bg-blue-800 transition-colors">
                                <X className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                            </button>
                        </div>
                    </div>
                )}

                <div className="flex items-center gap-2">
                    {/* Pill input */}
                    <div className="flex-1 flex items-center bg-gray-100 dark:bg-gray-800 rounded-full px-3 min-h-[40px]">
                        <textarea
                            ref={textareaRef}
                            value={message}
                            onChange={handleInput}
                            onKeyDown={handleKeyDown}
                            placeholder="Tapez votre message..."
                            disabled={isSending || isUploadingFile}
                            rows={1}
                            className="flex-1 bg-transparent text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 resize-none focus:outline-none max-h-24 py-2 disabled:opacity-50"
                        />
                        {/* Attachment icon inside pill — right */}
                        {isDoctor && (
                            <button
                                onClick={() => fileInputRef.current?.click()}
                                disabled={isUploadingFile}
                                className="flex-shrink-0 w-7 h-7 flex items-center justify-center text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 disabled:opacity-50 transition-colors"
                                title="Joindre un fichier"
                            >
                                <Paperclip className="w-4 h-4" />
                            </button>
                        )}
                    </div>

                    {/* Send button — slides in only when there's content */}
                    <div
                        className="flex-shrink-0 overflow-hidden transition-all duration-200"
                        style={{ width: (message.trim() || selectedFile) ? '36px' : '0px', opacity: (message.trim() || selectedFile) ? 1 : 0 }}
                    >
                        <button
                            onClick={selectedFile ? handleSendWithAttachment : handleSend}
                            disabled={selectedFile ? isUploadingFile : (!message.trim() || isSending)}
                            className="w-9 h-9 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center text-white shadow-md disabled:opacity-50 transition-all"
                        >
                            {isUploadingFile ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                                <Send className={`w-4 h-4 ${isSending ? 'animate-pulse' : ''}`} />
                            )}
                        </button>
                    </div>
                </div>
            </div>

            {/* ── DESKTOP LAYOUT (unchanged) ─────────────────────────────── */}
            <div className="hidden md:block bg-white dark:bg-gray-900 px-4 py-3 border-t border-gray-100 dark:border-gray-800">
                <div className="max-w-5xl mx-auto">
                    {/* Selected file preview */}
                    {selectedFile && (
                        <div className="mb-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2 text-sm text-blue-700 dark:text-blue-300">
                                    {getFileIcon()}
                                    <span className="truncate max-w-[200px]">{selectedFile.name}</span>
                                    <span className="text-xs text-blue-500 dark:text-blue-400">
                                        ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                                    </span>
                                </div>
                                <button
                                    onClick={removeSelectedFile}
                                    className="p-1 hover:bg-blue-100 dark:hover:bg-blue-800 rounded-full transition-colors"
                                >
                                    <X className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                                </button>
                            </div>
                        </div>
                    )}

                    <div className="flex items-center gap-3">
                        {canShareMedicalFile && (
                            <button
                                onClick={() => setIsShareModalOpen(true)}
                                disabled={isUploadingFile || isSending}
                                className="flex-shrink-0 h-12 w-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center shadow-md hover:shadow-lg"
                                title="Partager un dossier médical"
                            >
                                <Share2 className="w-5 h-5" />
                            </button>
                        )}

                        {isDoctor && (
                            <button
                                onClick={() => fileInputRef.current?.click()}
                                disabled={isUploadingFile}
                                className="flex-shrink-0 h-12 w-12 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center border-2 border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
                                title="Joindre un document (PDF ou image)"
                            >
                                <Paperclip className="w-5 h-5" />
                            </button>
                        )}

                        <div className="flex-1 min-w-0">
                            <textarea
                                ref={textareaRef}
                                value={message}
                                onChange={handleInput}
                                onKeyDown={handleKeyDown}
                                placeholder="Tapez votre message..."
                                disabled={isSending || isUploadingFile}
                                rows={1}
                                className="w-full px-4 py-3 border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none max-h-32 bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 disabled:opacity-50 transition-all duration-200 hover:border-gray-300 dark:hover:border-gray-600"
                            />
                        </div>

                        <button
                            onClick={selectedFile ? handleSendWithAttachment : handleSend}
                            disabled={selectedFile ? isUploadingFile : (!message.trim() || isSending)}
                            className="flex-shrink-0 h-12 w-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center"
                        >
                            {isUploadingFile ? (
                                <Loader2 className="w-5 h-5 animate-spin" />
                            ) : (
                                <Send className={`w-5 h-5 ${isSending ? 'animate-pulse' : ''}`} />
                            )}
                        </button>
                    </div>

                    <div className="hidden md:block mt-1.5 text-xs text-gray-400 ml-1">
                        ⏎ Entrée pour envoyer • Shift+⏎ nouvelle ligne
                        {isDoctor && ' • 📎 Joindre un document'}
                        {canShareMedicalFile && ' • 📋 Partager dossier'}
                    </div>
                </div>
            </div>
        </>
    );
}

