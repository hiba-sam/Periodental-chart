'use client';

import React, { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import { formatDistanceToNow, format, isToday, isYesterday } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Check, CheckCheck, Loader2, FileText, Download } from 'lucide-react';
import socketClient from '@/utils/socketClient';
import useSWR from 'swr';
import { useMessaging, useMessagingSafe } from '../hooks';

interface Message {
    id: number | null;
    conversation_id: number;
    sender_id: number;
    sender_name: string;
    content: string;
    is_read: boolean;
    read_at?: string; // Timestamp when message was read
    created_at: string;
    is_edited?: boolean;
    tempId?: string;
    isPending?: boolean;
    isFailed?: boolean;
    attachment_url?: string;
    attachment_type?: 'image' | 'pdf';
    attachment_name?: string;
}

interface MessageThreadProps {
    conversationId: number;
    currentUserId: number;
    optimisticMessage?: any;
}

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

const fetcher = async (url: string) => {
    const res = await fetch(url, {
        credentials: 'include', // Envoie les cookies HTTP-only
    });

    if (!res.ok) throw new Error('Failed to fetch');

    const data = await res.json();
    return data.data || [];
};

export default function MessageThread({ conversationId, currentUserId, optimisticMessage }: MessageThreadProps) {
    const { resetUnread, setActiveConversationId } = useMessaging();
    const [messages, setMessages] = useState<Message[]>([]);

    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const scrollRef = useRef<HTMLDivElement>(null);
    const bottomRef = useRef<HTMLDivElement>(null);
    const isFirstLoad = useRef(true);
    const lastMessageCount = useRef(0);
    const isNearBottomRef = useRef(true);

    // Typing indicator state
    const [typingUser, setTypingUser] = useState<{ userId: number; userName: string } | null>(null);
    const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const lastMessageReceivedRef = useRef<number>(0); // Timestamp of last received message

    //  Handle optimistic message from parent
    useEffect(() => {
        if (optimisticMessage && optimisticMessage.conversation_id === conversationId) {
            setMessages(prev => {
                // Avoid duplicates
                if (prev.some(msg => msg.tempId === optimisticMessage.tempId)) {
                    return prev;
                }
                return [...prev, optimisticMessage];
            });
        }
    }, [optimisticMessage, conversationId]);

    // Reset messages and page when conversation changes
    useEffect(() => {
        setMessages([]);
        setPage(1);
        setHasMore(true);
        isFirstLoad.current = true;

        // Mark this conversation as active (prevents unread badge flash)
        setActiveConversationId(conversationId);

        // Optimistic update: reset unread count immediately in UI
        resetUnread(conversationId);

        // Then persist to backend (async, no waiting)
        fetch(`${API_URL}/messaging/conversations/${conversationId}/read`, {
            method: 'POST',
            credentials: 'include',
        }).catch(err => console.error('[MessageThread] Failed to mark as read:', err));

        // Cleanup: clear active conversation when unmounting
        return () => {
            setActiveConversationId(null);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [conversationId]);

    // Fetch messages - always fetch on mount to ensure fresh data
    const { data, error, isLoading, mutate } = useSWR<Message[]>(
        `${API_URL}/messaging/conversations/${conversationId}/messages?page=${page}&pageSize=50`,
        fetcher,
        {
            revalidateOnFocus: false,
            revalidateOnReconnect: false,
        }
    );

    // Combine SWR data with local messages (for real-time updates)
    const displayMessages = useMemo(() => {
        const allMessages = [...(data || []), ...messages];
        // Deduplicate by id or tempId
        const messageMap = new Map();
        allMessages.forEach(msg => {
            const key = msg.id || msg.tempId;
            if (key && !messageMap.has(key)) {
                messageMap.set(key, msg);
            } else if (key && messageMap.has(key)) {
                // Keep the one with more data (has id)
                const existing = messageMap.get(key);
                if (msg.id && !existing.id) {
                    messageMap.set(key, msg);
                }
            }
        });
        return Array.from(messageMap.values()).sort(
            (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        );
    }, [data, messages]);

    // Update hasMore when data changes
    useEffect(() => {
        if (data) {
            setHasMore(data.length === 50);
        }
    }, [data]);

    // Join conversation room and listen for new messages
    useEffect(() => {
        socketClient.joinConversation(conversationId);

        const handleNewMessage = (data: { message: Message; conversationId: number; tempId?: string }) => {
            if (data.conversationId === conversationId) {
                // Clear typing indicator when message is received from other user
                if (data.message.sender_id !== currentUserId) {
                    lastMessageReceivedRef.current = Date.now(); // Track when message was received
                    setTypingUser(null);
                    if (typingTimeoutRef.current) {
                        clearTimeout(typingTimeoutRef.current);
                        typingTimeoutRef.current = null;
                    }
                }

                // Add to local messages for immediate display
                setMessages(prev => {
                    // Skip if this is our own optimistic message (already in the list)
                    if (data.tempId && prev.some(msg => msg.tempId === data.tempId)) {
                        return prev;
                    }
                    // Avoid duplicates by ID
                    if (data.message.id && prev.some(msg => msg.id === data.message.id)) {
                        return prev;
                    }
                    return [...prev, data.message];
                });

                // Mark conversation as read if message is from other user
                // Use HTTP API instead of socket to avoid issues with undefined message IDs
                if (data.message.sender_id !== currentUserId) {
                    fetch(`${API_URL}/messaging/conversations/${conversationId}/read`, {
                        method: 'POST',
                        credentials: 'include',
                    }).catch(() => { });
                }
            }
        };

        const handleMessageConfirmed = (data: { tempId: string; realId: number; message: any; conversationId: number }) => {
            if (data.conversationId === conversationId) {
                setMessages(prev =>
                    prev.map(msg =>
                        msg.tempId === data.tempId
                            ? { ...msg, id: data.realId, isPending: false, tempId: data.tempId }
                            : msg
                    )
                );
            }
        };

        const handleMessageFailed = (data: { tempId: string; error: string; conversationId: number }) => {
            if (data.conversationId === conversationId) {
                setMessages(prev =>
                    prev.map(msg =>
                        msg.tempId === data.tempId
                            ? { ...msg, isFailed: true, isPending: false }
                            : msg
                    )
                );
            }
        };

        const handleMessageRead = (readData: { messageId?: number; messageIds?: number[]; conversationId?: number; userId: number; readAt?: string }) => {
            // Skip if it's our own read event
            if (readData.userId === currentUserId) return;

            // Check if this event is for our conversation
            if (readData.conversationId && readData.conversationId !== conversationId) return;

            const readTimestamp = readData.readAt || new Date().toISOString();

            // If conversationId is provided, mark ALL messages from current user as read
            // If messageIds/messageId is provided, mark only those specific messages
            const markAllFromUser = !!readData.conversationId;
            const specificIds = readData.messageIds || (readData.messageId ? [readData.messageId] : []);

            // Update local messages
            setMessages(prev =>
                prev.map(msg => {
                    if (markAllFromUser && msg.sender_id === currentUserId && !msg.is_read) {
                        return { ...msg, is_read: true, read_at: readTimestamp };
                    }
                    if (specificIds.length > 0 && msg.id && specificIds.includes(msg.id)) {
                        return { ...msg, is_read: true, read_at: readTimestamp };
                    }
                    return msg;
                })
            );

            // Also update SWR cache for immediate VV blue display
            mutate((currentData: Message[] | undefined) => {
                if (!currentData) return currentData;
                return currentData.map(msg => {
                    if (markAllFromUser && msg.sender_id === currentUserId && !msg.is_read) {
                        return { ...msg, is_read: true, read_at: readTimestamp };
                    }
                    if (specificIds.length > 0 && msg.id && specificIds.includes(msg.id)) {
                        return { ...msg, is_read: true, read_at: readTimestamp };
                    }
                    return msg;
                });
            }, false); // false = don't revalidate
        };

        const handleTypingUpdate = (data: {
            conversationId: number;
            userId: number;
            userName?: string;
            isTyping: boolean;
        }) => {
            if (data.conversationId === conversationId && data.userId !== currentUserId) {
                if (data.isTyping) {
                    // Ignore typing events that arrive within 500ms after receiving a message
                    // This prevents showing "typing" indicator after the message already arrived
                    const timeSinceLastMessage = Date.now() - lastMessageReceivedRef.current;
                    if (timeSinceLastMessage < 500) {
                        return;
                    }

                    setTypingUser({ userId: data.userId, userName: data.userName || 'Utilisateur' });

                    // Clear existing timeout
                    if (typingTimeoutRef.current) {
                        clearTimeout(typingTimeoutRef.current);
                    }

                    // Auto-clear typing after 3 seconds (in case stop event is missed)
                    typingTimeoutRef.current = setTimeout(() => {
                        setTypingUser(null);
                    }, 3000);
                } else {
                    setTypingUser(null);
                }
            }
        };

        // Attach listeners when socket connects
        const attachListeners = () => {
            const socket = socketClient.getSocket();
            if (!socket) return;

            socket.off('message:new', handleNewMessage);
            socket.on('message:new', handleNewMessage);
            socket.off('message:confirmed', handleMessageConfirmed);
            socket.on('message:confirmed', handleMessageConfirmed);
            socket.off('message:failed', handleMessageFailed);
            socket.on('message:failed', handleMessageFailed);
            socket.off('message:read', handleMessageRead);
            socket.on('message:read', handleMessageRead);
            socket.off('typing:update', handleTypingUpdate);
            socket.on('typing:update', handleTypingUpdate);
        };

        // Use onConnect to ensure listeners are attached after socket connects
        const cleanupOnConnect = socketClient.onConnect(attachListeners);

        return () => {
            cleanupOnConnect();
            socketClient.leaveConversation(conversationId);
            if (typingTimeoutRef.current) {
                clearTimeout(typingTimeoutRef.current);
            }
            const socket = socketClient.getSocket();
            if (socket) {
                socket.off('message:new', handleNewMessage);
                socket.off('message:confirmed', handleMessageConfirmed);
                socket.off('message:failed', handleMessageFailed);
                socket.off('message:read', handleMessageRead);
                socket.off('typing:update', handleTypingUpdate);
            }
        };
    }, [conversationId, currentUserId]);

    // Auto-scroll to bottom on new messages or initial load
    useEffect(() => {
        if (displayMessages.length > 0) {
            const lastMessage = displayMessages[displayMessages.length - 1];
            const isInitialLoad = lastMessageCount.current === 0;
            const hasNewMessages = displayMessages.length > lastMessageCount.current;

            // Only scroll on true initial load (first time seeing this conversation)
            // or when receiving new messages. Skip if returning to page with cached data.
            const shouldScroll = isFirstLoad.current ||
                (hasNewMessages && (lastMessage?.sender_id === currentUserId || isNearBottomRef.current));

            if (shouldScroll) {
                // Use 'auto' (no animation) for initial load, 'smooth' only for new real-time messages
                const behavior = isFirstLoad.current ? 'auto' : 'smooth';

                // Wait for DOM to fully render all messages before scrolling
                requestAnimationFrame(() => {
                    setTimeout(() => {
                        bottomRef.current?.scrollIntoView({ behavior });
                    }, 100);
                });
                isFirstLoad.current = false;
            }
        }

        lastMessageCount.current = displayMessages.length;
    }, [displayMessages, currentUserId]);

    // Messages are marked as read via HTTP API in the conversation change effect
    // and when new messages arrive - no need for socket-based marking here

    // Handle scroll for pagination
    const handleScroll = useCallback(() => {
        if (scrollRef.current) {
            const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;

            // Track if user is near bottom (within 150px)
            isNearBottomRef.current = scrollHeight - scrollTop - clientHeight < 150;

            // Load more when scrolled to top
            if (scrollTop === 0 && hasMore && !isLoading) {
                setPage(prev => prev + 1);
            }
        }
    }, [hasMore, isLoading]);

    const formatMessageDate = (date: string) => {
        const messageDate = new Date(date);

        if (isToday(messageDate)) {
            return format(messageDate, 'HH:mm');
        } else if (isYesterday(messageDate)) {
            return `Hier ${format(messageDate, 'HH:mm')}`;
        } else {
            return format(messageDate, 'dd/MM/yyyy HH:mm');
        }
    };

    // Convert URLs in text to clickable links
    const renderMessageContent = (content: string, isOwnMessage: boolean) => {
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        const parts = content.split(urlRegex);

        return parts.map((part, index) => {
            if (part.match(urlRegex)) {
                return (
                    <a
                        key={index}
                        href={part}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`underline hover:opacity-80 ${isOwnMessage ? 'text-blue-200' : 'text-blue-600 dark:text-blue-400'
                            }`}
                        onClick={(e) => e.stopPropagation()}
                    >
                        {part}
                    </a>
                );
            }
            return <span key={index}>{part}</span>;
        });
    };

    const retryMessage = (message: Message) => {
        if (!message.tempId) return;

        // Remove failed message
        setMessages(prev => prev.filter(msg => msg.tempId !== message.tempId));

        // Resend using the original content
        // This will be handled by the parent component, so we just emit an event
        console.log('Retry not yet implemented - please resend manually');
    };

    const renderMessage = (message: Message, index: number) => {
        const isOwnMessage = message.sender_id === currentUserId;
        const prevMessage = displayMessages[index - 1];
        const showSender = !prevMessage || prevMessage.sender_id !== message.sender_id;

        return (
            <div
                key={message.id || message.tempId}
                className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4`}
            >
                <div className={`max-w-[70%] ${isOwnMessage ? 'items-end' : 'items-start'} flex flex-col`}>
                    {showSender && !isOwnMessage && (
                        <span className="text-xs text-gray-600 dark:text-gray-400 mb-1 px-3">
                            {message.sender_name}
                        </span>
                    )}

                    <div
                        className={`px-4 py-2 rounded-2xl transition-opacity ${message.isPending ? 'opacity-60' : 'opacity-100'
                            } ${message.isFailed ? 'border-2 border-red-500' : ''
                            } ${isOwnMessage
                                ? 'bg-blue-600 text-white rounded-br-sm'
                                : 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white rounded-bl-sm'
                            }`}
                    >
                        {/* Attachment display */}
                        {message.attachment_url && (
                            <div className="mb-2">
                                {message.attachment_type === 'image' ? (
                                    <a
                                        href={`${API_URL}${message.attachment_url}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="block"
                                    >
                                        <img
                                            src={`${API_URL}${message.attachment_url}`}
                                            alt={message.attachment_name || 'Image'}
                                            className="max-w-full max-h-64 rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                            loading="lazy"
                                        />
                                    </a>
                                ) : (
                                    <a
                                        href={`${API_URL}${message.attachment_url}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className={`flex items-center gap-2 p-3 rounded-lg transition-colors ${isOwnMessage
                                            ? 'bg-blue-500 hover:bg-blue-400'
                                            : 'bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500'
                                            }`}
                                    >
                                        <FileText className="w-8 h-8 flex-shrink-0" />
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium truncate">
                                                {message.attachment_name || 'Document PDF'}
                                            </p>
                                            <p className={`text-xs ${isOwnMessage ? 'text-blue-200' : 'text-gray-500 dark:text-gray-400'}`}>
                                                Cliquez pour ouvrir
                                            </p>
                                        </div>
                                        <Download className="w-5 h-5 flex-shrink-0" />
                                    </a>
                                )}
                            </div>
                        )}
                        {message.content && (
                            <p className="whitespace-pre-wrap break-words">{renderMessageContent(message.content, isOwnMessage)}</p>
                        )}
                    </div>

                    <div className="flex items-center gap-1 mt-1 px-3">
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatMessageDate(message.created_at)}
                        </span>

                        {isOwnMessage && (
                            <span className="text-gray-500 dark:text-gray-400">
                                {message.isPending ? (
                                    <Loader2 className="w-3 h-3 animate-spin" />
                                ) : message.isFailed ? (
                                    <button
                                        onClick={() => retryMessage(message)}
                                        className="text-red-500 hover:text-red-700 text-xs underline ml-1"
                                    >
                                        Réessayer
                                    </button>
                                ) : message.is_read ? (
                                    <span
                                        className="relative group cursor-help"
                                        title={message.read_at ? `Vu ${format(new Date(message.read_at), 'HH:mm', { locale: fr })}` : 'Lu'}
                                    >
                                        <CheckCheck className="w-3 h-3 text-blue-500" />
                                    </span>
                                ) : (
                                    <Check className="w-3 h-3" />
                                )}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        );
    };

    // Show loading only on very first load
    if (isLoading && displayMessages.length === 0 && !data) {
        return (
            <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex items-center justify-center h-full text-red-500">
                Erreur de chargement des messages
            </div>
        );
    }


    console.log('displayMessages', displayMessages);

    return (
        <div
            ref={scrollRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto p-4 space-y-2"
        >
            {page > 1 && isLoading && (
                <div className="flex justify-center py-4">
                    <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                </div>
            )}

            {displayMessages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                    <div className="flex flex-col items-center gap-3 text-center px-6 max-w-xs">
                        {/* Wave icon */}
                        <div className="text-4xl select-none animate-bounce">👋</div>
                        {/* Heading */}
                        <h3 className="text-base font-semibold text-gray-700 dark:text-gray-200">
                            Commencez la conversation
                        </h3>
                        {/* Subtitle */}
                        <p className="text-sm text-gray-400 dark:text-gray-500">
                            Aucun message pour l'instant. Dites bonjour !
                        </p>
                        {/* Pulsing dots */}
                        <div className="flex items-center gap-1.5 mt-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 dark:bg-blue-600 animate-pulse" style={{ animationDelay: '0ms' }} />
                            <span className="w-1.5 h-1.5 rounded-full bg-purple-400 dark:bg-purple-600 animate-pulse" style={{ animationDelay: '200ms' }} />
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 dark:bg-blue-600 animate-pulse" style={{ animationDelay: '400ms' }} />
                        </div>
                    </div>
                </div>
            ) : (
                <>
                    {displayMessages.map((message, index) => renderMessage(message, index))}

                    {/* Typing indicator */}
                    {typingUser && (
                        <div className="flex justify-start mb-4">
                            <div className="max-w-[70%] flex flex-col items-start">
                                <span className="text-xs text-gray-600 dark:text-gray-400 mb-1 px-3">
                                    {typingUser.userName}
                                </span>
                                <div className="px-4 py-3 rounded-2xl rounded-bl-sm bg-gray-200 dark:bg-gray-700">
                                    <div className="flex items-center gap-1">
                                        <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                        <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                        <span className="w-2 h-2 bg-gray-500 dark:bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    <div ref={bottomRef} />
                </>
            )}
        </div>
    );
}
