/**
 * messaging.api.ts
 * ────────────────
 * All API calls and SWR fetchers for the messages feature.
 * Extracted from MessagingContext.tsx and component-level fetch calls.
 */

export const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// ─── SWR Fetchers ──────────────────────────────────────────────────────────

/** SWR fetcher for the conversations list. Returns array or throws. */
export const conversationsFetcher = async (url: string) => {
    const res = await fetch(url, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
    });

    if (!res.ok) throw new Error('Failed to fetch conversations');

    const data = await res.json();
    return data.data || [];
};

/** SWR fetcher for the conversation partner (assistant↔doctor). Returns null on 404. */
export const partnerFetcher = async (url: string) => {
    const res = await fetch(url, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
    });

    // 404 = no partner (valid state, not an error)
    if (res.status === 404) return null;

    if (!res.ok) throw new Error('Failed to fetch conversation partner');

    const data = await res.json();
    return data.data || null;
};

/** Generic SWR fetcher for messages within a conversation. */
export const messagesFetcher = async (url: string) => {
    const res = await fetch(url, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
    });

    if (!res.ok) throw new Error('Failed to fetch messages');

    const data = await res.json();
    return data.data || [];
};

// ─── User / Doctor Search ──────────────────────────────────────────────────

/**
 * Search for doctors by name query.
 * Returns an array of Doctor objects.
 */
export const searchDoctors = async (query: string): Promise<any[]> => {
    if (query.trim().length < 2) return [];

    const res = await fetch(
        `${API_URL}/messaging/users/search?query=${encodeURIComponent(query)}`,
        { credentials: 'include' }
    );

    if (!res.ok) throw new Error('Doctor search failed');

    const data = await res.json();
    return data.data || [];
};

/**
 * Create (or retrieve existing) conversation with the given peer user.
 * Returns the conversationId.
 */
export const createConversation = async (peerUserId: number): Promise<number> => {
    const res = await fetch(`${API_URL}/messaging/conversations`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ peerUserId }),
    });

    if (!res.ok) throw new Error('Failed to create conversation');

    const data = await res.json();
    return data.data.conversationId;
};

// ─── Message Search ────────────────────────────────────────────────────────

/**
 * Search messages within a conversation.
 * Returns an array of MessageSearchResult objects.
 */
export const searchMessages = async (
    conversationId: number,
    query: string
): Promise<any[]> => {
    if (query.length < 2) return [];

    const response = await fetch(
        `${API_URL}/messaging/conversations/${conversationId}/search?q=${encodeURIComponent(query)}`,
        { credentials: 'include' }
    );

    if (!response.ok) throw new Error('Message search failed');

    const data = await response.json();
    return data.data || [];
};

// ─── Presence ──────────────────────────────────────────────────────────────

/**
 * Fetch the current presence status for a user.
 * Returns `{ status, last_seen_at }` or null on failure.
 */
export const fetchPresence = async (
    userId: number,
    bustCache = false
): Promise<{ status: 'online' | 'away' | 'offline'; last_seen_at?: string } | null> => {
    try {
        const url = bustCache
            ? `${API_URL}/messaging/users/${userId}/presence?_t=${Date.now()}`
            : `${API_URL}/messaging/users/${userId}/presence`;

        const res = await fetch(url, {
            credentials: 'include',
            ...(bustCache ? { cache: 'no-store' } : {}),
        });

        if (!res.ok) return null;

        const data = await res.json();
        return data.data || null;
    } catch {
        return null;
    }
};
