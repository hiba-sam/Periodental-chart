// Invoice Types - Core type definitions for invoice-related data

/**
 * Invoice item (line item in an invoice)
 */
export interface InvoiceItem {
    id?: number;
    tarification_id?: number;
    label: string;
    price: number;
}

/**
 * Invoice status
 */
export type InvoiceStatus = 'paid' | 'unpaid' | 'partial' | 'free';

/**
 * Core Invoice interface
 */
export interface Invoice {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    total_price: string;
    amount_paid: string;
    status: InvoiceStatus;
    created_at: string;
    updated_at: string;
    items: InvoiceItem[];
    patient_name?: string;
    patient_family_name?: string;
}

/**
 * Payload for creating a new invoice
 */
export interface CreateInvoicePayload {
    patient_id: string;
    total_price: number;
    items: InvoiceItem[];
}

/**
 * Payload for adding a payment
 */
export interface AddPaymentPayload {
    invoice_id: number;
    amount: number;
}

/**
 * Payload for distributing payment across invoices
 */
export interface DistributePaymentPayload {
    patient_id: string;
    amount: number;
}

/**
 * Result of distribute payment operation
 */
export interface DistributePaymentResult {
    success: boolean;
    updatedInvoices: Invoice[];
    remainingAmount?: number;
}

/**
 * Invoice statistics data structure
 */
export interface InvoiceStatistics {
    weeklyData: Array<{ period: string; paiements: number }>;
    monthlyData: Array<{ period: string; paiements: number }>;
    yearlyData: Array<{ period: string; paiements: number }>;
}

/**
 * Patient unpaid summary
 */
export interface PatientUnpaidSummary {
    patient_id: string;
    patient_name: string;
    patient_family_name: string;
    total_unpaid: string;
    invoice_count: string;
    invoices: Invoice[];
}

/**
 * Invoice filters
 */
export interface InvoiceFilters {
    patientId?: string;
    status?: InvoiceStatus | 'all';
    dateFrom?: string;
    dateTo?: string;
}

/**
 * Tarification (service price template)
 */
export interface Tarification {
    id: number;
    doctor_user_id: number;
    service_label: string;
    price: string;
    created_at: string;
    updated_at: string;
}
