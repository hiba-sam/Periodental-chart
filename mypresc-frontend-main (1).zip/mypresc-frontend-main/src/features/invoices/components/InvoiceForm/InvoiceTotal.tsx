'use client';

// InvoiceTotal Component - Display invoice totals
// Subcomponent of InvoiceForm

import React from 'react';

interface InvoiceTotalProps {
    tarificationTotal: number;
    customTotal: number;
    calculatedTotal: number;
}

/**
 * Format price with currency
 */
function formatPrice(price: number): string {
    return `${price.toLocaleString('fr-DZ')} DA`;
}

/**
 * InvoiceTotal - Displays breakdown and total
 */
export function InvoiceTotal({
    tarificationTotal,
    customTotal,
    calculatedTotal,
}: InvoiceTotalProps) {
    const hasCustomItems = customTotal !== 0;
    const isNegative = calculatedTotal < 0;

    return (
        <div className="bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20 border-2 border-emerald-200 dark:border-emerald-800 rounded-xl p-4 space-y-2">
            {/* Breakdown */}
            {(tarificationTotal > 0 || hasCustomItems) && (
                <div className="space-y-1 pb-2 border-b border-emerald-200 dark:border-emerald-800">
                    {tarificationTotal > 0 && (
                        <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">Services</span>
                            <span className="font-medium text-gray-900 dark:text-white">
                                {formatPrice(tarificationTotal)}
                            </span>
                        </div>
                    )}
                    {customTotal !== 0 && (
                        <div className="flex justify-between text-sm">
                            <span className="text-gray-600 dark:text-gray-400">Personnalisés</span>
                            <span className={`font-medium ${customTotal < 0
                                    ? 'text-red-600 dark:text-red-400'
                                    : 'text-gray-900 dark:text-white'
                                }`}>
                                {customTotal < 0 ? '-' : ''}{formatPrice(Math.abs(customTotal))}
                            </span>
                        </div>
                    )}
                </div>
            )}

            {/* Total */}
            <div className="flex justify-between items-center pt-1">
                <span className="text-lg font-semibold text-gray-800 dark:text-gray-200">
                    Total
                </span>
                <span className={`text-2xl font-bold ${isNegative
                        ? 'text-red-600 dark:text-red-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }`}>
                    {isNegative && '-'}{formatPrice(Math.abs(calculatedTotal))}
                </span>
            </div>

            {/* Warning for negative */}
            {isNegative && (
                <p className="text-xs text-red-600 dark:text-red-400 text-center">
                    ⚠️ Le montant total ne peut pas être négatif
                </p>
            )}
        </div>
    );
}

export default InvoiceTotal;
