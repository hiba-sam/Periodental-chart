'use client';

// CustomItemsSection Component - Add custom line items to invoice
// Subcomponent of InvoiceForm

import React from 'react';
import { PlusIcon, TrashIcon } from '@heroicons/react/24/outline';

interface CustomItem {
    label: string;
    price: string;
}

interface CustomItemsSectionProps {
    items: CustomItem[];
    onRemove: (index: number) => void;
    onUpdate: (index: number, field: 'label' | 'price', value: string) => void;
    // New item form
    newLabel: string;
    newPrice: string;
    onNewLabelChange: (value: string) => void;
    onNewPriceChange: (value: string) => void;
    onAdd: () => void;
}

/**
 * CustomItemsSection - Add custom items to invoice
 */
export function CustomItemsSection({
    items,
    onRemove,
    onUpdate,
    newLabel,
    newPrice,
    onNewLabelChange,
    onNewPriceChange,
    onAdd,
}: CustomItemsSectionProps) {
    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && newLabel.trim() && newPrice.trim()) {
            e.preventDefault();
            onAdd();
        }
    };

    return (
        <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Articles personnalisés
            </h4>

            {/* Existing items */}
            {items.length > 0 && (
                <div className="space-y-2">
                    {items.map((item, index) => (
                        <div
                            key={index}
                            className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
                        >
                            <input
                                type="text"
                                value={item.label}
                                onChange={(e) => onUpdate(index, 'label', e.target.value)}
                                placeholder="Description"
                                className="flex-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            />
                            <input
                                type="number"
                                value={item.price}
                                onChange={(e) => onUpdate(index, 'price', e.target.value)}
                                placeholder="Prix"
                                className="w-28 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-right"
                                step="0.01"
                            />
                            <span className="text-sm text-gray-500 dark:text-gray-400">DA</span>
                            <button
                                type="button"
                                onClick={() => onRemove(index)}
                                className="p-2 text-red-500 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-lg transition-colors"
                            >
                                <TrashIcon className="w-4 h-4" />
                            </button>
                        </div>
                    ))}
                </div>
            )}

            {/* Add new item */}
            <div className="flex items-center gap-3 p-3 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
                <input
                    type="text"
                    value={newLabel}
                    onChange={(e) => onNewLabelChange(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Nouvelle description..."
                    className="flex-1 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
                <input
                    type="number"
                    value={newPrice}
                    onChange={(e) => onNewPriceChange(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Prix"
                    className="w-28 px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-right"
                    step="0.01"
                />
                <span className="text-sm text-gray-500 dark:text-gray-400">DA</span>
                <button
                    type="button"
                    onClick={onAdd}
                    disabled={!newLabel.trim() || !newPrice.trim()}
                    className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                    <PlusIcon className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
}

export default CustomItemsSection;
