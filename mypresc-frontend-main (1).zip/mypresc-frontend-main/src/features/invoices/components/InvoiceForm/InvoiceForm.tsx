'use client';

// InvoiceForm Component - Main invoice creation form
// Uses subcomponents for tarification, custom items, and total

import React from 'react';
import { BanknotesIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import { useInvoiceForm } from '../../hooks/useInvoiceForm';
import { TarificationSelector } from './TarificationSelector';
import { CustomItemsSection } from './CustomItemsSection';
import { InvoiceTotal } from './InvoiceTotal';

interface Tarification {
    id: number;
    service_label: string;
    price: string | number;
    description?: string;
}

interface InvoiceFormProps {
    patientId: string;
    patientName: string;
    tarifications: Tarification[];
    isCreating: boolean;
    onSubmit: (items: any[], total: number) => Promise<void>;
    onCancel: () => void;
}

/**
 * InvoiceForm - Complete invoice creation form
 */
export function InvoiceForm({
    patientId,
    patientName,
    tarifications,
    isCreating,
    onSubmit,
    onCancel,
}: InvoiceFormProps) {
    const { t } = useLanguage();

    const {
        // Tarification
        selectedTarificationIds,
        toggleTarification,
        selectAllTarifications,
        clearTarifications,
        // Custom items
        customItems,
        removeCustomItem,
        updateCustomItem,
        // New item
        newItemLabel,
        newItemPrice,
        setNewItemLabel,
        setNewItemPrice,
        handleAddNewItem,
        // Calculations
        tarificationTotal,
        customTotal,
        calculatedTotal,
        // Validation
        isValid,
        // Build payload
        buildPayload,
        resetForm,
    } = useInvoiceForm({ tarifications });

    const handleSubmit = async () => {
        if (!isValid || calculatedTotal < 0) return;
        const items = buildPayload();
        await onSubmit(items, calculatedTotal);
        resetForm();
    };

    return (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
            {/* Backdrop */}
            <div className="fixed inset-0 bg-black/75" onClick={onCancel} />

            {/* Modal */}
            <div className="flex min-h-full items-center justify-center p-4">
                <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-5">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/20 rounded-full">
                                <BanknotesIcon className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-white">
                                    {t('invoice.title')}
                                </h2>
                                <p className="text-sm text-white/80">{patientName}</p>
                            </div>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="p-6 max-h-[60vh] overflow-y-auto space-y-6">
                        {/* Tarifications */}
                        <TarificationSelector
                            tarifications={tarifications}
                            selectedIds={selectedTarificationIds}
                            onToggle={toggleTarification}
                            onSelectAll={selectAllTarifications}
                            onClearAll={clearTarifications}
                        />

                        {/* Divider */}
                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-gray-200 dark:border-gray-700" />
                            </div>
                            <div className="relative flex justify-center">
                                <span className="px-3 bg-white dark:bg-gray-800 text-xs text-gray-500 dark:text-gray-400">
                                    ou ajoutez des articles
                                </span>
                            </div>
                        </div>

                        {/* Custom items */}
                        <CustomItemsSection
                            items={customItems}
                            onRemove={removeCustomItem}
                            onUpdate={updateCustomItem}
                            newLabel={newItemLabel}
                            newPrice={newItemPrice}
                            onNewLabelChange={setNewItemLabel}
                            onNewPriceChange={setNewItemPrice}
                            onAdd={handleAddNewItem}
                        />

                        {/* Total */}
                        <InvoiceTotal
                            tarificationTotal={tarificationTotal}
                            customTotal={customTotal}
                            calculatedTotal={calculatedTotal}
                        />
                    </div>

                    {/* Footer */}
                    <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex flex-row-reverse gap-3 rounded-b-lg">
                        <button
                            type="button"
                            disabled={isCreating || calculatedTotal < 0 || !isValid}
                            onClick={handleSubmit}
                            className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                            {isCreating ? (
                                <>
                                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                                    Création...
                                </>
                            ) : (
                                <>
                                    <BanknotesIcon className="w-5 h-5" />
                                    {t('invoice.confirm')}
                                </>
                            )}
                        </button>
                        <button
                            type="button"
                            onClick={onCancel}
                            className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-300 font-semibold rounded-xl ring-1 ring-gray-300 dark:ring-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                        >
                            {t('invoice.cancel')}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default InvoiceForm;
