'use client';

// InvoiceList Component - Table-based layout matching original design
// Synced with page.original.tsx lines 1249-1391
// Mobile: card view per invoice | Desktop: full table (unchanged)

import React, { useMemo, useState } from 'react';
import { BanknotesIcon, PlusIcon, TrashIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import type { Invoice } from '../types';

interface InvoiceListProps {
    invoices: Invoice[];
    isLoading?: boolean;
    totalUnpaid?: number;
    onToggleStatus?: (id: number, currentStatus: Invoice['status']) => void;
    onOpenPayment: (invoice: Invoice) => void;
    onDelete: (id: number) => void;
    onCreateInvoice: () => void;
    onOpenGlobalPayment: () => void;
    isDeleting?: boolean;
    isUpdatingStatus?: boolean;
    isDoctorUser?: boolean;
}

/**
 * Loading skeleton for invoice table
 */
function InvoiceTableSkeleton() {
    return (
        <div className="space-y-3">
            {[1, 2, 3].map(i => (
                <div key={i} className="animate-pulse flex items-center justify-between py-3">
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-20" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-32" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-16" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-16" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-16" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-16" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded w-12" />
                </div>
            ))}
        </div>
    );
}

/**
 * Empty state when no invoices - matches original design
 */
function EmptyState() {
    const { t } = useLanguage();
    return (
        <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <BanknotesIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
            <p className="text-sm font-medium">{t('invoice.card.noInvoices')}</p>
            <p className="text-xs mt-1">Cliquez sur &quot;Nouvelle facture&quot; pour créer</p>
        </div>
    );
}

/**
 * Get status badge styling - matches original
 */
function getStatusBadge(status: Invoice['status']) {
    switch (status) {
        case 'paid':
            return {
                color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
                label: 'Payée',
            };
        case 'partial':
            return {
                color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400',
                label: 'Partiel',
            };
        case 'free':
            return {
                color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
                label: 'Gratuit',
            };
        default:
            return {
                color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
                label: 'Non payée',
            };
    }
}

/* ─────────────────────────────────────────────────────────────
   Mobile card – one card per invoice
───────────────────────────────────────────────────────────── */
function MobileInvoiceCard({
    invoice,
    onOpenPayment,
    onDelete,
    isDeleting,
}: {
    invoice: Invoice;
    onOpenPayment: (invoice: Invoice) => void;
    onDelete: (id: number) => void;
    isDeleting?: boolean;
}) {
    const totalPrice = parseFloat(invoice.total_price);
    const amountPaid = parseFloat(invoice.amount_paid || '0');
    const remaining = totalPrice - amountPaid;
    const statusBadge = getStatusBadge(invoice.status);
    const canPay = invoice.status !== 'paid' && invoice.status !== 'free';

    return (
        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 space-y-3 border border-gray-100 dark:border-gray-700">
            {/* Top row: date + status badge */}
            <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500 dark:text-gray-400">
                    {new Date(invoice.created_at).toLocaleDateString('fr-FR', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                    })}
                </span>
                <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${statusBadge.color}`}>
                    {statusBadge.label}
                </span>
            </div>

            {/* Description */}
            <div>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100 leading-snug">
                    {invoice.items?.[0]?.label || 'Consultation'}
                </p>
                {invoice.items && invoice.items.length > 1 && (
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5">
                        +{invoice.items.length - 1} autre(s)
                    </p>
                )}
            </div>

            {/* Amounts row */}
            <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-white dark:bg-gray-800 rounded-lg py-2 px-1">
                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-0.5">Montant</p>
                    <p className="text-sm font-bold text-gray-900 dark:text-white">
                        {totalPrice.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                    </p>
                </div>
                <div className="bg-white dark:bg-gray-800 rounded-lg py-2 px-1">
                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-0.5">Payé</p>
                    <p className={`text-sm font-bold ${amountPaid > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-400'}`}>
                        {amountPaid.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                    </p>
                </div>
                <div className="bg-white dark:bg-gray-800 rounded-lg py-2 px-1">
                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-0.5">Reste</p>
                    <p className={`text-sm font-bold ${remaining > 0 ? 'text-red-500 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                        {remaining.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                    </p>
                </div>
            </div>

            {/* Action buttons */}
            <div className="flex justify-end items-center gap-2 pt-1">
                {canPay && (
                    <button
                        onClick={() => onOpenPayment(invoice)}
                        className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white text-sm font-medium transition-colors"
                    >
                        <BanknotesIcon className="w-4 h-4" />
                        Encaisser
                    </button>
                )}
                <button
                    onClick={() => onDelete(invoice.id)}
                    disabled={isDeleting}
                    className="p-2 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/40 transition-colors disabled:opacity-50"
                    title="Supprimer"
                >
                    <TrashIcon className="w-4 h-4" />
                </button>
            </div>
        </div>
    );
}

/**
 * InvoiceList - Main component with table layout matching original
 */
type StatusFilter = 'all' | 'paid' | 'unpaid' | 'partial' | 'free';

const STATUS_FILTERS: { key: StatusFilter; label: string; color: string; activeColor: string }[] = [
    { key: 'all', label: 'Tous', color: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300', activeColor: 'bg-gray-700 text-white dark:bg-gray-200 dark:text-gray-900' },
    { key: 'paid', label: 'Payée', color: 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400', activeColor: 'bg-green-600 text-white dark:bg-green-500 dark:text-white' },
    { key: 'unpaid', label: 'Non payée', color: 'bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400', activeColor: 'bg-red-600 text-white dark:bg-red-500 dark:text-white' },
    { key: 'partial', label: 'Partiel', color: 'bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400', activeColor: 'bg-amber-500 text-white dark:bg-amber-400 dark:text-white' },
    { key: 'free', label: 'Gratuit', color: 'bg-blue-50 text-blue-700 dark:bg-blue-900/20 dark:text-blue-400', activeColor: 'bg-blue-600 text-white dark:bg-blue-500 dark:text-white' },
];

export function InvoiceList({
    invoices,
    isLoading,
    onOpenPayment,
    onDelete,
    onCreateInvoice,
    onOpenGlobalPayment,
    isDeleting,
    isDoctorUser = true,
}: InvoiceListProps) {
    const { t } = useLanguage();
    const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');

    // Filtered invoices based on active badge
    const filteredInvoices = useMemo(() => {
        if (statusFilter === 'all') return invoices;
        if (statusFilter === 'unpaid') return invoices.filter(inv => inv.status === 'unpaid');
        return invoices.filter(inv => inv.status === statusFilter);
    }, [invoices, statusFilter]);

    // Count per status for badge indicators
    const counts = useMemo(() => ({
        all: invoices.length,
        paid: invoices.filter(inv => inv.status === 'paid').length,
        unpaid: invoices.filter(inv => inv.status === 'unpaid').length,
        partial: invoices.filter(inv => inv.status === 'partial').length,
        free: invoices.filter(inv => inv.status === 'free').length,
    }), [invoices]);

    // Calculate totals from the filtered set
    const totalInvoices = filteredInvoices.reduce((sum, inv) => sum + parseFloat(inv.total_price), 0);
    const totalPaid = filteredInvoices.reduce((sum, inv) => sum + parseFloat(inv.amount_paid || '0'), 0);
    const totalRemaining = totalInvoices - totalPaid;
    const hasUnpaidInvoices = filteredInvoices.some(inv => inv.status !== 'paid' && inv.status !== 'free');

    const isMobile = useMemo(() => {
        return typeof window !== 'undefined' && window.innerWidth < 768;
    }, []);

    if (isLoading) {
        return (
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors mb-6">
                <div className="flex items-center justify-between mb-4">
                    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-32 animate-pulse" />
                    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-40 animate-pulse" />
                </div>
                <InvoiceTableSkeleton />
            </div>
        );
    }

    return (
        <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-2xl shadow-sm transition-colors mb-6">
            {/* Header - matches original */}
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                    <BanknotesIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-500" />
                    {t('invoice.card.header')}
                </h2>
                {isDoctorUser && (
                    <button
                        onClick={onCreateInvoice}
                        className="px-3 sm:px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors flex items-center gap-1.5 sm:gap-2"
                    >
                        <PlusIcon className="w-4 h-4" />
                        <span className="hidden xs:inline">{t('invoice.card.invoice')}</span>
                        <span className="xs:hidden">Invoice</span>
                    </button>
                )}
            </div>

            {/* ── Status filter badges ── */}
            {invoices.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-4">
                    {STATUS_FILTERS.map(f => (
                        <button
                            key={f.key}
                            onClick={() => setStatusFilter(f.key)}
                            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition-all ${statusFilter === f.key ? f.activeColor : f.color
                                }`}
                        >
                            {f.label}
                            <span className={`inline-flex items-center justify-center w-4 h-4 rounded-full text-[10px] font-bold ${statusFilter === f.key
                                    ? 'bg-white/25 text-inherit'
                                    : 'bg-black/10 dark:bg-white/10'
                                }`}>
                                {counts[f.key]}
                            </span>
                        </button>
                    ))}
                </div>
            )}

            {filteredInvoices.length > 0 ? (
                <>
                    {/* ── MOBILE: card list (hidden on sm+) ── */}
                    <div className="md:hidden space-y-3">
                        {filteredInvoices.map(invoice => (
                            <MobileInvoiceCard
                                key={invoice.id}
                                invoice={invoice}
                                onOpenPayment={onOpenPayment}
                                onDelete={onDelete}
                                isDeleting={isDeleting}
                            />
                        ))}
                    </div>

                    {/* ── DESKTOP: table (hidden below sm) — UNCHANGED ── */}
                    {!isMobile &&
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-gray-200 dark:border-gray-700">
                                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Date</th>
                                    <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Description</th>
                                    <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Montant</th>
                                    <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Payé</th>
                                    <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Reste</th>
                                    <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Statut</th>
                                    <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                                {filteredInvoices.map((invoice) => {
                                    const totalPrice = parseFloat(invoice.total_price);
                                    const amountPaid = parseFloat(invoice.amount_paid || '0');
                                    const remaining = totalPrice - amountPaid;
                                    const statusBadge = getStatusBadge(invoice.status);

                                    return (
                                        <tr key={invoice.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                            {/* Date */}
                                            <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                                                {new Date(invoice.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                                            </td>
                                            {/* Description */}
                                            <td className="py-3 px-4">
                                                <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                                    {invoice.items?.[0]?.label || 'Consultation'}
                                                </span>
                                                {invoice.items && invoice.items.length > 1 && (
                                                    <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">+{invoice.items.length - 1} autre(s)</span>
                                                )}
                                            </td>
                                            {/* Montant */}
                                            <td className="py-3 px-4 text-right">
                                                <span className="text-sm font-bold text-gray-900 dark:text-white">
                                                    {totalPrice.toLocaleString('fr-DZ')} DA
                                                </span>
                                            </td>
                                            {/* Payé */}
                                            <td className="py-3 px-4 text-right">
                                                <span className={`text-sm font-medium ${amountPaid > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-400'}`}>
                                                    {amountPaid.toLocaleString('fr-DZ')} DA
                                                </span>
                                            </td>
                                            {/* Reste */}
                                            <td className="py-3 px-4 text-right">
                                                <span className={`text-sm font-bold ${remaining > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                                                    {remaining.toLocaleString('fr-DZ')} DA
                                                </span>
                                            </td>
                                            {/* Statut */}
                                            <td className="py-3 px-4">
                                                <div className="flex items-center justify-center">
                                                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusBadge.color}`}>
                                                        {statusBadge.label}
                                                    </span>
                                                </div>
                                            </td>
                                            {/* Actions */}
                                            <td className="py-3 px-4">
                                                <div className="flex items-center justify-center gap-1">
                                                    {invoice.status !== 'paid' && invoice.status !== 'free' && (
                                                        <button
                                                            onClick={() => onOpenPayment(invoice)}
                                                            className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors p-1"
                                                            title="Encaisser"
                                                        >
                                                            <BanknotesIcon className="w-4 h-4" />
                                                        </button>
                                                    )}
                                                    <button
                                                        onClick={() => onDelete(invoice.id)}
                                                        disabled={isDeleting}
                                                        className="text-gray-400 hover:text-red-500 transition-colors p-1 disabled:opacity-50"
                                                        title="Supprimer"
                                                    >
                                                        <TrashIcon className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>}

                    {/* Invoice Totals - matches original */}
                    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                        {/* Mobile: stacked layout */}
                        <div className="md:hidden space-y-3">
                            {hasUnpaidInvoices && (
                                <button
                                    onClick={onOpenGlobalPayment}
                                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-emerald-600 text-white font-semibold rounded-xl hover:bg-emerald-700 active:bg-emerald-800 transition-colors shadow-sm"
                                >
                                    <BanknotesIcon className="w-5 h-5" />
                                    Encaisser un montant global
                                </button>
                            )}
                            <div className="grid grid-cols-3 gap-2 text-center">
                                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl py-3 px-2">
                                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-1">Total</p>
                                    <p className="text-sm font-bold text-gray-900 dark:text-white">
                                        {totalInvoices.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                                    </p>
                                </div>
                                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl py-3 px-2">
                                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-1">Payé</p>
                                    <p className="text-sm font-bold text-green-600 dark:text-green-400">
                                        {totalPaid.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                                    </p>
                                </div>
                                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl py-3 px-2">
                                    <p className="text-[10px] text-gray-400 dark:text-gray-500 uppercase font-medium mb-1">Reste</p>
                                    <p className="text-sm font-bold text-red-600 dark:text-red-400">
                                        {totalRemaining.toLocaleString('fr-DZ')} <span className="text-[10px] font-normal">DA</span>
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Desktop: original layout (unchanged) */}
                        <div className="hidden md:flex items-center justify-between">
                            {/* Global Payment Button */}
                            {hasUnpaidInvoices && (
                                <button
                                    onClick={onOpenGlobalPayment}
                                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-colors shadow-sm"
                                >
                                    <BanknotesIcon className="w-5 h-5" />
                                    Encaisser un montant global
                                </button>
                            )}
                            <div className="flex gap-8 ml-auto">
                                <div className="text-right">
                                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Total Factures</p>
                                    <p className="text-lg font-bold text-gray-900 dark:text-white">
                                        {totalInvoices.toLocaleString('fr-DZ')} DA
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Total Payé</p>
                                    <p className="text-lg font-bold text-green-600 dark:text-green-400">
                                        {totalPaid.toLocaleString('fr-DZ')} DA
                                    </p>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Reste à Payer</p>
                                    <p className="text-lg font-bold text-red-600 dark:text-red-400">
                                        {totalRemaining.toLocaleString('fr-DZ')} DA
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            ) : (
                <EmptyState />
            )}
        </div>
    );
}

export default InvoiceList;
