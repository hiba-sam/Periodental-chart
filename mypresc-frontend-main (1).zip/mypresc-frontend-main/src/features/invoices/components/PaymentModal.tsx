'use client';

// PaymentModal Component - Add payment to single invoice
// Modal for processing individual invoice payments

import React, { useState, useEffect } from 'react';
import { BanknotesIcon } from '@heroicons/react/24/outline';
import type { Invoice } from '../types';

interface PaymentModalProps {
    isOpen: boolean;
    invoice: Invoice | null;
    isProcessing: boolean;
    onSubmit: (invoiceId: number, amount: number) => Promise<void>;
    onClose: () => void;
}

/**
 * Format price for display
 */
function formatPrice(price: number): string {
    return `${price.toLocaleString('fr-DZ')} DA`;
}

/**
 * PaymentModal - Process single invoice payment
 */
export function PaymentModal({
    isOpen,
    invoice,
    isProcessing,
    onSubmit,
    onClose,
}: PaymentModalProps) {
    const [amount, setAmount] = useState('');

    // Calculate remaining amount
    const total = invoice ? parseFloat(invoice.total_price) : 0;
    const paid = invoice ? parseFloat(invoice.amount_paid || '0') : 0;
    const remaining = total - paid;

    // Reset amount when invoice changes
    useEffect(() => {
        if (invoice && remaining > 0) {
            setAmount(remaining.toString());
        } else {
            setAmount('');
        }
    }, [invoice?.id, remaining]);

    if (!isOpen || !invoice) return null;

    const handleSubmit = async () => {
        const parsedAmount = parseFloat(amount);
        if (isNaN(parsedAmount) || parsedAmount <= 0) {
            alert('Veuillez entrer un montant valide');
            return;
        }
        await onSubmit(invoice.id, parsedAmount);
    };

    const handlePayFull = () => {
        setAmount(remaining.toString());
    };

    const handleClose = () => {
        setAmount('');
        onClose();
    };

    return (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
            {/* Backdrop */}
            <div className="fixed inset-0 bg-black bg-opacity-75" onClick={handleClose} />

            {/* Modal */}
            <div className="flex min-h-full items-center justify-center p-4">
                <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-5">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white/20 rounded-full">
                                <BanknotesIcon className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-white">Encaisser un paiement</h2>
                                <p className="text-sm text-white/80">Facture #{invoice.id}</p>
                            </div>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="p-6">
                        {/* Invoice Summary */}
                        <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl space-y-2">
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500 dark:text-gray-400">Total facture</span>
                                <span className="font-bold text-gray-900 dark:text-white">
                                    {formatPrice(total)}
                                </span>
                            </div>
                            <div className="flex justify-between text-sm">
                                <span className="text-gray-500 dark:text-gray-400">Déjà payé</span>
                                <span className="font-medium text-green-600 dark:text-green-400">
                                    {formatPrice(paid)}
                                </span>
                            </div>
                            <div className="flex justify-between text-sm pt-2 border-t border-gray-200 dark:border-gray-600">
                                <span className="text-gray-700 dark:text-gray-300 font-medium">Reste à payer</span>
                                <span className="font-bold text-red-600 dark:text-red-400">
                                    {formatPrice(remaining)}
                                </span>
                            </div>
                        </div>

                        {/* Payment Amount Input */}
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Montant reçu (DA)
                            </label>
                            <input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="Entrez le montant..."
                                className="w-full px-4 py-3 text-lg font-bold border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                                min="0"
                                step="0.01"
                            />
                            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                                Vous pouvez encaisser un montant partiel ou le total restant
                            </p>
                        </div>

                        {/* Quick Amount Button */}
                        <div className="mb-6">
                            <button
                                type="button"
                                onClick={handlePayFull}
                                className="w-full px-4 py-3 text-sm font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-lg hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors"
                            >
                                Payer la totalité ({formatPrice(remaining)})
                            </button>
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                        <button
                            onClick={handleClose}
                            className="flex-1 px-4 py-3 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                        >
                            Annuler
                        </button>
                        <button
                            onClick={handleSubmit}
                            disabled={isProcessing || !amount || parseFloat(amount) <= 0}
                            className="flex-1 px-4 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                        >
                            {isProcessing ? (
                                <>
                                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" />
                                    Enregistrement...
                                </>
                            ) : (
                                <>
                                    <BanknotesIcon className="w-5 h-5" />
                                    Encaisser
                                </>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PaymentModal;
