'use client';

// InvoiceListItem Component - Individual invoice display
// Self-contained component for single invoice row

import React from 'react';
import {
    BanknotesIcon,
    TrashIcon,
    CheckCircleIcon,
    ClockIcon,
    XCircleIcon,
} from '@heroicons/react/24/outline';
import type { Invoice } from '../../types';

interface InvoiceListItemProps {
    invoice: Invoice;
    onToggleStatus: (id: number, currentStatus: Invoice['status']) => void;
    onOpenPayment: (invoice: Invoice) => void;
    onDelete: (id: number) => void;
    isDeleting?: boolean;
    isUpdatingStatus?: boolean;
}

/**
 * Get status badge color and icon
 */
function getStatusBadge(status: Invoice['status']) {
    switch (status) {
        case 'paid':
            return {
                icon: CheckCircleIcon,
                color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
                label: 'Payée',
            };
        case 'partial':
            return {
                icon: ClockIcon,
                color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
                label: 'Partielle',
            };
        case 'free':
            return {
                icon: CheckCircleIcon,
                color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
                label: 'Gratuite',
            };
        default:
            return {
                icon: XCircleIcon,
                color: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
                label: 'Non payée',
            };
    }
}

/**
 * Format price with currency
 */
function formatPrice(price: string | number): string {
    const numPrice = typeof price === 'string' ? parseFloat(price) : price;
    return `${numPrice.toFixed(2)} DA`;
}

/**
 * Format date for display
 */
function formatDate(date: string): string {
    try {
        return new Date(date).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
        });
    } catch {
        return 'Date inconnue';
    }
}

export function InvoiceListItem({
    invoice,
    onToggleStatus,
    onOpenPayment,
    onDelete,
    isDeleting,
    isUpdatingStatus,
}: InvoiceListItemProps) {
    const statusBadge = getStatusBadge(invoice.status);
    const StatusIcon = statusBadge.icon;
    const remaining = parseFloat(invoice.total_price) - parseFloat(invoice.amount_paid || '0');
    const isPaidOrFree = invoice.status === 'paid' || invoice.status === 'free';

    return (
        <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            {/* Left: Info */}
            <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-gray-900 dark:text-white truncate">
                        Facture #{invoice.id}
                    </span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${statusBadge.color}`}>
                        <StatusIcon className="w-3 h-3" />
                        {statusBadge.label}
                    </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                    <span>{formatDate(invoice.created_at)}</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                        {formatPrice(invoice.total_price)}
                    </span>
                    {invoice.status === 'partial' && (
                        <span className="text-yellow-600 dark:text-yellow-400">
                            Reste: {formatPrice(remaining)}
                        </span>
                    )}
                </div>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-2 ml-4">
                {/* Toggle status button */}
                <button
                    onClick={() => onToggleStatus(invoice.id, invoice.status)}
                    disabled={isUpdatingStatus || invoice.status === 'free'}
                    className={`p-2 rounded-lg transition-colors ${isPaidOrFree
                            ? 'bg-green-100 text-green-600 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400'
                            : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-600 dark:text-gray-300'
                        } disabled:opacity-50 disabled:cursor-not-allowed`}
                    title={isPaidOrFree ? 'Marquer comme non payée' : 'Marquer comme payée'}
                >
                    <CheckCircleIcon className="w-5 h-5" />
                </button>

                {/* Add payment button (only for unpaid/partial) */}
                {!isPaidOrFree && (
                    <button
                        onClick={() => onOpenPayment(invoice)}
                        className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400 transition-colors"
                        title="Ajouter un paiement"
                    >
                        <BanknotesIcon className="w-5 h-5" />
                    </button>
                )}

                {/* Delete button */}
                <button
                    onClick={() => onDelete(invoice.id)}
                    disabled={isDeleting}
                    className="p-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 transition-colors disabled:opacity-50"
                    title="Supprimer la facture"
                >
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
}

export default InvoiceListItem;
