import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
    BanknotesIcon,
    PlusIcon,
    TrashIcon,
    DocumentTextIcon,
    UserCircleIcon,
} from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface Tarification {
    id: number;
    service_label: string;
    price: string | number;
}

interface CustomItem {
    label: string;
    price: string;
}

interface InvoiceCreateModalProps {
    isOpen: boolean;
    tarifications: Tarification[];
    onClose: () => void;
    onCreate: (selectedTarificationIds: number[], customItems: CustomItem[]) => Promise<void>;
}

/**
 * Invoice Creation Modal
 * Allows doctors to create invoices by selecting tarifications or adding custom items
 */
export function InvoiceCreateModal({
    isOpen,
    tarifications,
    onClose,
    onCreate,
}: InvoiceCreateModalProps) {
    const { t } = useLanguage();

    const [selectedTarificationIds, setSelectedTarificationIds] = useState<number[]>([]);
    const [customItems, setCustomItems] = useState<CustomItem[]>([]);
    const [newItemLabel, setNewItemLabel] = useState('');
    const [newItemPrice, setNewItemPrice] = useState('');
    const [creatingInvoice, setCreatingInvoice] = useState(false);

    if (!isOpen) return null;

    // Calculate total
    const calculatedTotal = selectedTarificationIds.reduce((sum, id) => {
        const tarif = tarifications.find((t) => t.id === id);
        return sum + (tarif ? parseFloat(tarif.price.toString()) : 0);
    }, 0) + customItems.reduce((sum, item) => sum + parseFloat(item.price || '0'), 0);

    // Handle create invoice
    const handleCreate = async () => {
        setCreatingInvoice(true);
        try {
            onCreate(selectedTarificationIds, customItems);
            // Reset form
            onClose();
            setSelectedTarificationIds([]);
            setCustomItems([]);
            setNewItemLabel('');
            setNewItemPrice('');
            setCreatingInvoice(false);
        } catch (error) {
            console.error('Error creating invoice:', error);
        }
    };

    // Handle add custom item
    const handleAddCustomItem = () => {
        if (newItemLabel && newItemPrice) {
            setCustomItems((prev) => [...prev, { label: newItemLabel, price: newItemPrice }]);
            setNewItemLabel('');
            setNewItemPrice('');
        }
    };

    return (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
            <div className="fixed inset-0 bg-black bg-opacity-75" onClick={onClose}></div>
            <div className="flex min-h-full items-center justify-center p-4">
                <div className="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl sm:max-w-4xl sm:w-full">
                    <div className="px-6 py-6">
                        {/* Header */}
                        <div className="flex items-center gap-4 mb-6">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100">
                                <BanknotesIcon className="h-6 w-6 text-emerald-600" />
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                                    {t('invoice.title') || 'Nouvelle facture'}
                                </h3>
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                    {t('invoice.subtitle') || 'Créer une facture pour ce patient'}
                                </p>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Left: Custom Items & Invoice Details */}
                            <div className="space-y-4">
                                {/* Add Custom Item */}
                                <div className="bg-gray-50 dark:bg-gray-700/30 p-4 rounded-xl">
                                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-3 flex items-center gap-2">
                                        <PlusIcon className="w-4 h-4 text-emerald-600" />
                                        {t('invoice.addCustomItem') || 'Article personnalisé'}
                                    </h4>
                                    <div className="flex gap-3 items-end">
                                        <div className="flex-1">
                                            <input
                                                type="text"
                                                placeholder={t('invoice.label') || 'Libellé'}
                                                value={newItemLabel}
                                                onChange={(e) => setNewItemLabel(e.target.value)}
                                                className="w-full rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm"
                                            />
                                        </div>
                                        <div className="w-28">
                                            <input
                                                type="number"
                                                placeholder="0"
                                                value={newItemPrice}
                                                onChange={(e) => setNewItemPrice(e.target.value)}
                                                className="w-full rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm"
                                            />
                                        </div>
                                        <button
                                            type="button"
                                            onClick={handleAddCustomItem}
                                            className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
                                        >
                                            <PlusIcon className="w-5 h-5" />
                                        </button>
                                    </div>
                                </div>

                                {/* Invoice Details */}
                                <div className="space-y-2 max-h-60 overflow-y-auto">
                                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm">
                                        {t('invoice.invoiceDetail') || 'Détail de la facture'}
                                    </h4>

                                    {/* Tarifications */}
                                    {selectedTarificationIds.map((id) => {
                                        const tarif = tarifications.find((t) => t.id === id);
                                        if (!tarif) return null;
                                        return (
                                            <div
                                                key={`t-${id}`}
                                                className="flex items-center justify-between p-3 bg-white dark:bg-gray-700/50 rounded-lg border border-gray-100 dark:border-gray-700"
                                            >
                                                <div>
                                                    <p className="font-medium text-gray-800 dark:text-gray-200 text-sm">
                                                        {tarif.service_label}
                                                    </p>
                                                    <span className="text-xs text-blue-600">Tarification</span>
                                                </div>
                                                <div className="flex items-center gap-4">
                                                    <span className="font-bold text-gray-900 dark:text-white">
                                                        {Number(tarif.price).toLocaleString('fr-DZ')} DA
                                                    </span>
                                                    <button
                                                        onClick={() =>
                                                            setSelectedTarificationIds((prev) => prev.filter((tid) => tid !== id))
                                                        }
                                                        className="text-gray-400 hover:text-red-500"
                                                    >
                                                        <TrashIcon className="w-4 h-4" />
                                                    </button>
                                                </div>
                                            </div>
                                        );
                                    })}

                                    {/* Custom Items */}
                                    {customItems.map((item, index) => (
                                        <div
                                            key={`c-${index}`}
                                            className="flex items-center justify-between p-3 bg-white dark:bg-gray-700/50 rounded-lg border border-gray-100 dark:border-gray-700"
                                        >
                                            <div>
                                                <p className="font-medium text-gray-800 dark:text-gray-200 text-sm">
                                                    {item.label}
                                                </p>
                                                <span className="text-xs text-amber-600">Personnalisé</span>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <span className="font-bold text-gray-900 dark:text-white">
                                                    {Number(item.price).toLocaleString('fr-DZ')} DA
                                                </span>
                                                <button
                                                    onClick={() => setCustomItems((prev) => prev.filter((_, i) => i !== index))}
                                                    className="text-gray-400 hover:text-red-500"
                                                >
                                                    <TrashIcon className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}

                                    {/* Empty State */}
                                    {selectedTarificationIds.length === 0 && customItems.length === 0 && (
                                        <div className="text-center py-8 text-gray-400 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg">
                                            <DocumentTextIcon className="w-8 h-8 mx-auto mb-2 opacity-40" />
                                            <p className="text-sm">{t('invoice.noItems') || 'Aucun article'}</p>
                                        </div>
                                    )}
                                </div>

                                {/* Total */}
                                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                                    <div className="flex items-center justify-between">
                                        <span className="text-lg font-bold text-gray-800 dark:text-gray-200">
                                            {t('invoice.netAmount') || 'Montant net'}
                                        </span>
                                        <span className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
                                            {calculatedTotal.toLocaleString('fr-DZ')} DA
                                        </span>
                                    </div>
                                </div>
                            </div>

                            {/* Right: Available Tarifications */}
                            <div>
                                <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-3 flex items-center gap-2">
                                    <UserCircleIcon className="w-4 h-4 text-blue-600" />
                                    {t('invoice.availableTarifications') || 'Tarifications disponibles'}
                                </h4>
                                <div className="space-y-2 max-h-80 overflow-y-auto bg-gray-50 dark:bg-gray-800/50 p-3 rounded-xl">
                                    {tarifications.length > 0 ? (
                                        tarifications.map((tarif) => (
                                            <label
                                                key={tarif.id}
                                                className={`flex items-center justify-between p-3 rounded-lg cursor-pointer border-2 ${selectedTarificationIds.includes(tarif.id)
                                                        ? 'bg-blue-50 border-blue-500 dark:bg-blue-900/20'
                                                        : 'bg-white border-transparent hover:border-gray-200 dark:bg-gray-700'
                                                    }`}
                                            >
                                                <div className="flex items-center gap-3">
                                                    <input
                                                        type="checkbox"
                                                        className="w-4 h-4 text-blue-600 rounded"
                                                        checked={selectedTarificationIds.includes(tarif.id)}
                                                        onChange={(e) => {
                                                            if (e.target.checked)
                                                                setSelectedTarificationIds((prev) => [...prev, tarif.id]);
                                                            else
                                                                setSelectedTarificationIds((prev) =>
                                                                    prev.filter((id) => id !== tarif.id)
                                                                );
                                                        }}
                                                    />
                                                    <span className="font-medium text-gray-700 dark:text-gray-300">
                                                        {tarif.service_label}
                                                    </span>
                                                </div>
                                                <span className="font-bold text-gray-900 dark:text-white">
                                                    {Number(tarif.price).toLocaleString('fr-DZ')} DA
                                                </span>
                                            </label>
                                        ))
                                    ) : (
                                        <div className="text-center py-8 text-gray-500">
                                            <UserCircleIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                                            <p>{t('invoice.noTarifications') || 'Aucune tarification'}</p>
                                            <Link href="/profile" className="text-blue-600 hover:underline text-sm">
                                                {t('invoice.configureProfile') || 'Configurer le profil'}
                                            </Link>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Footer */}
                    <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex flex-row-reverse gap-3 rounded-b-lg">
                        <button
                            type="button"
                            onClick={handleCreate}
                            className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 disabled:opacity-50"
                        >
                            {creatingInvoice ? (
                                <>
                                    <div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div>{' '}
                                    Création...
                                </>
                            ) : (
                                <>
                                    <BanknotesIcon className="w-5 h-5" /> {t('invoice.confirm') || 'Confirmer'}
                                </>
                            )}
                        </button>
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-300 font-semibold rounded-xl ring-1 ring-gray-300 dark:ring-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700"
                        >
                            {t('invoice.cancel') || 'Annuler'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default InvoiceCreateModal;