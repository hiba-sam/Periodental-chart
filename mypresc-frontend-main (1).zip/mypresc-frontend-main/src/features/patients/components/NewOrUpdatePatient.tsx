"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import Link from "next/link";
import { ArrowLeftIcon, PlusIcon, PencilSquareIcon, CalendarIcon, ClockIcon, UserIcon } from "@heroicons/react/24/outline";
import { ApiPatient, usePatients } from "@/contexts/PatientsContext";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useWaitingRoom } from "@/contexts/WaitingRoomContext";
import { DatePicker } from "@/components/ui/date-picker";

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

export function NewOrUpdatePatient({ backPath, nextPath }: { backPath: string, nextPath: string }) {
  const router = useRouter();
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  const searchParams = useSearchParams();
  const { addPatient, updatePatient, getPatient, loading: addLoading, error } = usePatients();
  const [formData, setFormData] = useState({
    name: "",
    family_name: "",
    dateNaissance: "",
    age: "",
    telephone: "",
    email: "",
    address: "",
    genre: "homme",
    allergies: "",
    chronicDiseases: "",
    emergencyContact: "",
    emergencyPhone: "",
    numero_securite_sociale: "",
    nin: "",
  });
  const [showConfirmAdd, setShowConfirmAdd] = useState(false);
  const [duplicatePatient, setDuplicatePatient] = useState(null);
  const [checkingDuplicate, setCheckingDuplicate] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [editPatientId, setEditPatientId] = useState<string | null>(null);
  const [isPrivate, setIsPrivate] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [hasInformedPatient, setHasInformedPatient] = useState(false);
  const [editStep, setEditStep] = useState(1); // Step pour mode édition
  const [becomePrimaryCare, setBecomePrimaryCare] = useState<boolean | null>(null);
  const [transitionComment, setTransitionComment] = useState('');
  const [primaryCareInfo, setPrimaryCareInfo] = useState<any>(null);
  const [showPrimaryCareConfirm, setShowPrimaryCareConfirm] = useState(false);
  const [showPostCreationOptions, setShowPostCreationOptions] = useState(false);
  const [createdPatient, setCreatedPatient] = useState<ApiPatient | null>(null);
  const [addingToWaitingRoom, setAddingToWaitingRoom] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false); // Local loading state for update button
  const { createEntry } = useWaitingRoom();

  const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL;

  const handleChange = async (e) => {
    const { name, value } = e.target;

    // Phone validation: only digits, max 10 characters (Algerian format)
    if (name === 'telephone' || name === 'emergencyPhone') {
      const digitsOnly = value.replace(/\D/g, '').slice(0, 10);
      setFormData((prev) => ({ ...prev, [name]: digitsOnly }));
      return;
    }

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // this fucntion submit the form and open the confirm modal
  const handleSubmit = async (e) => {
    e.preventDefault();
    setCurrentStep(1);
    setEditStep(1);
    setHasInformedPatient(false);
    setBecomePrimaryCare(null);
    setTransitionComment('');

    // For doctors creating a new patient, skip the 4-step popup and save directly
    if (user?.role === 'doctor' && !isEditMode) {
      const payload = {
        ...formData,
        is_private: false, // Default to shared for doctors
      };
      const res = await addPatient(payload) as ApiPatient;
      if (res) {
        router.push(`/patients/${res.id}`);
      }
      return;
    }

    // Fetch primary care info before showing popup (for edit mode)
    if (isEditMode && editPatientId) {
      try {
        const response = await fetch(`${API_URL}/patient/${editPatientId}/primary-care-info`, {
          credentials: 'include',
        });
        if (response.ok) {
          const data = await response.json();
          if (data.success) {
            setPrimaryCareInfo(data.data);
            console.log('📋 Primary care info loaded:', data.data);
          }
        }
      } catch (error) {
        console.error('Error fetching primary care info:', error);
      }
    }

    setShowConfirmAdd(true);
  };

  // Function to handle primary care physician assignment
  const handlePrimaryCareAssignment = async () => {
    if (!editPatientId || becomePrimaryCare === null) return;

    // Si l'utilisateur choisit "Non", simplement fermer et rediriger
    if (becomePrimaryCare === false) {
      setShowConfirmAdd(false);
      router.push(`/patients/${editPatientId}`);
      return;
    }

    try {
      const payload: any = {
        becomePrimaryCare
      };

      // Si transition avec commentaire requis
      if (primaryCareInfo?.needsTransitionComment && becomePrimaryCare && !transitionComment.trim()) {
        alert(t('patients.primaryCare.commentRequired'));
        return;
      }

      if (transitionComment.trim()) {
        payload.transitionComment = transitionComment.trim();
      }
      
      const response = await fetch(`${API_URL}/patient/${editPatientId}/primary-care/assign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        setShowConfirmAdd(false);
        router.push(`/patients/${editPatientId}`);
      } else {
        const errorData = await response.json();
        alert(errorData.error || t('patients.primaryCare.assignmentFailed'));
      }
    } catch (error) {
      console.error('Error assigning primary care:', error);
      alert(t('patients.primaryCare.assignmentError'));
    }
  };

  // this fucntion that create or update the patient
  const handleSaveAdd = async () => {
    // Prevent double-click
    if (isUpdating) return;
    
    if (isEditMode && editPatientId) {
      setIsUpdating(true); // Block button immediately
      
      const payload = {
        name: formData.name,
        family_name: formData.family_name,
        dateNaissance: formData.dateNaissance || undefined,
        age: formData.age ? parseInt(formData.age, 10) : undefined,
        genre: formData.genre === "Homme" ? "homme" : formData.genre === "Femme" ? "femme" : formData.genre,
        telephone: formData.telephone,
        email: formData.email,
        adresse: formData.address,
        numeroSecuriteSociale: formData.numero_securite_sociale,
        chronicDiseases: formData.chronicDiseases,
        allergies: formData.allergies,
        nin: formData.nin,
        is_private: isPrivate,
      };
      
      try {
        // Use context updatePatient directly (it already calls the API)
        const result = await updatePatient(editPatientId, payload);
        
        if (!result) {
          throw new Error('Erreur lors de la mise à jour');
        }
        
        // Also save to doctor_patient_privacy table
        const privacyChoice = isPrivate ? 'private' : 'shared';
        try {
          await fetch(`${API_URL}/doctor-patient-privacy/patient/${editPatientId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ privacy_choice: privacyChoice }),
          });
        } catch { /* ignore */ }

        // 2. Gérer le médecin traitant si l'utilisateur a choisi "Oui"
        if (becomePrimaryCare === true) {
          // Vérifier que le commentaire est fourni si passation nécessaire
          if (primaryCareInfo?.hasPrimaryCare && !transitionComment.trim()) {
            alert('Veuillez indiquer la raison de la passation du médecin traitant.');
            setIsUpdating(false);
            return;
          }

          console.log('📤 Assigning primary care physician...');

          const primaryCarePayload: any = { becomePrimaryCare: true };
          if (transitionComment.trim()) {
            primaryCarePayload.transitionComment = transitionComment.trim();
          }
          
          const primaryCareResponse = await fetch(`${API_URL}/patient/${editPatientId}/primary-care/assign`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify(primaryCarePayload),
          });

          if (!primaryCareResponse.ok) {
            const errorData = await primaryCareResponse.json();
            alert(errorData.error || 'Erreur lors de l\'assignation du médecin traitant');
            setIsUpdating(false);
            return;
          }
        }

        // Fermer et rediriger
        setShowConfirmAdd(false);
        router.push(`/patients/${editPatientId}`);
      } catch (error: any) {
        console.error('Error updating patient:', error);
        alert('Erreur lors de la mise à jour du patient: ' + (error.message || 'Erreur inconnue'));
      } finally {
        setIsUpdating(false);
      }
      return;
    }
    const payload = {
      ...formData,
      is_private: isPrivate,
    };
    const res = await addPatient(payload) as ApiPatient;
    setShowConfirmAdd(false);
    if (res) {
      // For assistants, show post-creation options
      if (user?.role === 'assistant') {
        setCreatedPatient(res);
        setShowPostCreationOptions(true);
      } else {
        router.push(`/patients/${res.id}`);
      }
    }
  };

  // detect edit mode and load patient data
  useEffect(() => {
    const mode = searchParams?.get("mode");
    const id = searchParams?.get("id");
    if (mode === "edit" && id) {
      setIsEditMode(true);
      setEditPatientId(id);
      // Try to load from context first (async with fallback API)
      const fillFromPatient = (patient: any) => {
        if (!patient) return;
        // Normalize date to yyyy-mm-dd for <input type="date">
        const rawDate: string | undefined = patient.dateNaissance;
        const normalizedDate = rawDate
          ? (/^\d{4}-\d{2}-\d{2}/.test(rawDate)
            ? rawDate.slice(0, 10)
            : new Date(rawDate).toISOString().slice(0, 10))
          : "";
        setFormData({
          name: patient.name || "",
          family_name: patient.family_name || "",
          dateNaissance: normalizedDate,
          age: patient.age ? patient.age.toString() : "",
          telephone: patient.telephone || "",
          email: patient.email || "",
          address: patient.adresse || "",
          genre: patient.genre,
          allergies: Array.isArray(patient.allergies) ? patient.allergies.join(", ") : (patient.allergies || ""),
          chronicDiseases: patient.chronicDiseases || "",
          emergencyContact: patient.emergencyContact || "",
          emergencyPhone: patient.emergencyPhone || "",
          numero_securite_sociale: patient.numeroSecuriteSociale || "",
          nin: patient.nin || "",
        });
        setIsPrivate(patient.is_private || false);
      };
      getPatient(id).then(fillFromPatient).catch(() => { });
    } else {
      setIsEditMode(false);
      setEditPatientId(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden transition-colors">
      <div className="flex">
        <div className="ml-[100px] p-4 flex flex-col h-screen flex-1">
          <Header />
          <div className="mt-4 flex-1 overflow-auto">
            {/* Bouton de retour */}
            <Link
              href={isEditMode ? `/patients/${editPatientId}` : `/${backPath}`}
              className="inline-flex gap-2 items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 mb-6 transition-colors"
            >
              <ArrowLeftIcon className={`w-4 h-4 ${isRTL ? "rotate-180" : ""} mr-2`} />
              {t('patients.form.back')}
            </Link>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                {isEditMode ? (
                  <PencilSquareIcon className="w-5 h-5 text-white" />
                ) : (
                  <PlusIcon className="w-5 h-5 text-white" />
                )}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100">
                  {isEditMode ? t('patients.form.editPatient') : t('patients.form.addNew')}
                </h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {isEditMode ? t('patients.form.updateInfo') : t('patients.form.fillInfo')}
                </p>
              </div>
            </div>

            {/* Messages de notification */}
            {error && (
              <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg
                      className="h-5 w-5 text-red-400"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Avertissement de patient en doublon */}
            {duplicatePatient && (
              <div className="mb-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg
                      className="h-5 w-5 text-yellow-400"
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            )}
            {/* Formulaire */}
            <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-lg p-6 transition-colors">
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Informations personnelles */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                      {t('patients.form.personalInfo')}
                    </h3>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="name"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.name')} {t('patients.form.required')}
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            name="name"
                            id="name"
                            value={formData.name}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 dark:bg-gray-700 dark:text-white transition-colors ${duplicatePatient
                              ? "border-yellow-400 focus:ring-yellow-500 dark:border-yellow-500"
                              : "border-gray-300 dark:border-gray-600 focus:ring-green-500"
                              }`}
                            placeholder={t('patients.form.lastNamePlaceholder')}
                            required
                          />
                          {checkingDuplicate && (
                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                              <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-yellow-500"></div>
                            </div>
                          )}
                        </div>
                      </div>
                      <div>
                        <label
                          htmlFor="family_name"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.firstName')} {t('patients.form.required')}
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            name="family_name"
                            id="family_name"
                            value={formData.family_name}
                            onChange={handleChange}
                            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 dark:bg-gray-700 dark:text-white transition-colors ${duplicatePatient
                              ? "border-yellow-400 focus:ring-yellow-500 dark:border-yellow-500"
                              : "border-gray-300 dark:border-gray-600 focus:ring-green-500"
                              }`}
                            placeholder={t('patients.form.firstNamePlaceholder')}
                            required
                          />
                          {checkingDuplicate && (
                            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                              <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-yellow-500"></div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label
                          htmlFor="dateNaissance"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.dateOfBirth')}
                        </label>
                        <DatePicker
                          id="dateNaissance"
                          value={formData.dateNaissance}
                          onChange={(date) => setFormData((prev) => ({ ...prev, dateNaissance: date, age: '' }))}
                          placeholder={t('patients.form.selectDate')}
                          maxYear={new Date().getFullYear()}
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="age"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.age') || 'Âge'}
                        </label>
                        <input
                          type="number"
                          name="age"
                          id="age"
                          min="0"
                          max="120"
                          value={formData.age}
                          onChange={(e) => setFormData((prev) => ({ ...prev, age: e.target.value, dateNaissance: '' }))}
                          disabled={!!formData.dateNaissance}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors disabled:bg-gray-100 dark:disabled:bg-gray-800 disabled:cursor-not-allowed"
                          placeholder={formData.dateNaissance ? 'Auto' : '0-120'}
                        />
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {t('patients.form.ageOrBirthdate') || 'Âge ou date de naissance requis'}
                        </p>
                      </div>
                      <div>
                        <label
                          htmlFor="genre"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.gender')} {t('patients.form.required')}
                        </label>
                        <select
                          name="genre"
                          id="genre"
                          value={formData.genre}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                        >
                          <option value="homme">{t('patients.form.male')}</option>
                          <option value="femme">{t('patients.form.female')}</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="telephone"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.phone')}
                        </label>
                        <input
                          type="tel"
                          name="telephone"
                          id="telephone"
                          value={formData.telephone}
                          onChange={handleChange}
                          maxLength={10}
                          pattern="[0-9]*"
                          inputMode="numeric"
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.phonePlaceholder')}
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="email"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.email')}
                        </label>
                        <input
                          type="email"
                          name="email"
                          id="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.emailPlaceholder')}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label
                          htmlFor="nin"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.nin')}
                        </label>
                        <input
                          type="number"
                          name="nin"
                          id="nin"
                          value={formData.nin}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.ninPlaceholder')}
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="numero_securite_sociale"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.socialSecurityNumber')}
                        </label>
                        <input
                          type="number"
                          name="numero_securite_sociale"
                          id="numero_securite_sociale"
                          value={formData.numero_securite_sociale}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.ssnPlaceholder')}
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="address"
                        className="block text-sm font-medium text-gray-700 mb-2"
                      >
                        {t('patients.form.address')}
                      </label>
                      <textarea
                        name="address"
                        id="address"
                        value={formData.address}
                        onChange={handleChange}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                        placeholder={t('patients.form.addressPlaceholder')}
                      />
                    </div>
                  </div>

                  {/* Informations médicales */}
                  <div className="space-y-4">
                    {user?.role === 'doctor' && (
                      <>
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                          {t('patients.form.medicalInfo')}
                        </h3>

                        <div>
                          <label
                            htmlFor="allergies"
                            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                          >
                            {t('patients.form.allergies')}
                          </label>
                          <textarea
                            name="allergies"
                            id="allergies"
                            value={formData.allergies}
                            onChange={handleChange}
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                            placeholder={t('patients.form.allergiesPlaceholder')}
                          />
                        </div>

                        <div>
                          <label
                            htmlFor="chronicDiseases"
                            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                          >
                            {t('patients.form.chronicDiseases')}
                          </label>
                          <textarea
                            name="chronicDiseases"
                            id="chronicDiseases"
                            value={formData.chronicDiseases}
                            onChange={handleChange}
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                            placeholder={t('patients.form.chronicDiseasesPlaceholder')}
                          />
                        </div>
                      </>
                    )}
                    {/* Contact d'urgence */}
                    <div className={`${user?.role === 'doctor' ? 'border-t' : ''} pt-3`}>
                      <h4 className="text-md font-semibold text-gray-900 dark:text-white mb-3">
                        {t('patients.form.emergencyContact')}
                      </h4>

                      <div>
                        <label
                          htmlFor="emergencyContact"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.emergencyContactName')}
                        </label>
                        <input
                          type="text"
                          name="emergencyContact"
                          id="emergencyContact"
                          value={formData.emergencyContact}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.emergencyContactPlaceholder')}
                        />
                      </div>

                      <div className="mt-3">
                        <label
                          htmlFor="emergencyPhone"
                          className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
                        >
                          {t('patients.form.emergencyPhone')}
                        </label>
                        <input
                          type="tel"
                          name="emergencyPhone"
                          id="emergencyPhone"
                          value={formData.emergencyPhone}
                          onChange={handleChange}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 dark:bg-gray-700 dark:text-white transition-colors"
                          placeholder={t('patients.form.emergencyPhonePlaceholder')}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex justify-end gap-3">
                  <Link
                    href={`/${backPath}`}
                    className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    {t('patients.form.cancel')}
                  </Link>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md"
                  >
                    {isEditMode ? t('patients.form.update') : t('patients.form.addPatientBtn')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Modal multi-étapes pour l'ajout de patient */}
      {showConfirmAdd && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 overflow-hidden transition-colors">
            {/* Simple confirmation modal for assistants */}
            {user?.role === 'assistant' ? (
              <div className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    {isEditMode ? (
                      <PencilSquareIcon className="w-8 h-8 text-green-600" />
                    ) : (
                      <PlusIcon className="w-8 h-8 text-green-600" />
                    )}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    {isEditMode ? t('patients.confirmation.confirmUpdate') : t('patients.confirmation.confirmAdd')}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {isEditMode
                      ? t('patients.confirmation.confirmUpdateMessage').replace('{name}', `${formData.family_name} ${formData.name}`)
                      : t('patients.confirmation.confirmAddMessage').replace('{name}', `${formData.family_name} ${formData.name}`)
                    }
                  </p>
                </div>

                {duplicatePatient && (
                  <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                    <p className="text-sm text-yellow-800">
                      {t('patients.form.duplicateWarning')}
                    </p>
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowConfirmAdd(false)}
                    className="flex-1 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium"
                  >
                    {t('patients.form.cancel')}
                  </button>
                  <button
                    onClick={handleSaveAdd}
                    disabled={addLoading}
                    className="flex-1 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 disabled:opacity-50 transition-colors font-medium"
                  >
                    {addLoading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                        {isEditMode ? t('patients.form.updating') : t('patients.form.saving')}
                      </div>
                    ) : (
                      isEditMode ? t('patients.form.update') : t('patients.form.confirm')
                    )}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Progress Bar - Only show for creation */}
                {!isEditMode && (
                  <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
                    <div className="flex items-center justify-between mb-2">
                      <h2 className="text-white font-semibold text-lg">
                        {t('patients.confirmation.addingNewPatient')}
                      </h2>
                      <span className="text-white text-sm">{t('patients.confirmation.step').replace('{current}', currentStep.toString()).replace('{total}', '4')}</span>
                    </div>
                    <div className="w-full bg-blue-400 rounded-full h-2">
                      <div
                        className="bg-white h-2 rounded-full transition-all duration-300"
                        style={{ width: `${(currentStep / 4) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                <div className="p-6">
                  {/* Edit Mode - Single unified popup */}
                  {isEditMode ? (
                    <div>
                      <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <PencilSquareIcon className="w-8 h-8 text-blue-600" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                          {t('patients.confirmation.confirmUpdate')}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {t('patients.confirmation.confirmUpdateMessage').replace('{name}', `${formData.family_name} ${formData.name}`)}
                        </p>
                      </div>

                      {/* Privacy option */}
                      <div className="bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 rounded-lg p-4 mb-4 transition-colors">
                        <h4 className="font-semibold text-gray-900 dark:text-white mb-3 text-sm">{t('patients.confirmation.fileConfidentiality')}</h4>
                        <div className="space-y-2.5">
                          {/* Option 1: Private */}
                          <label className={`block border-2 rounded-lg p-3 cursor-pointer transition-all ${isPrivate ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:border-blue-500' : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}`}>
                            <div className="flex items-start gap-2.5">
                              <input
                                type="radio"
                                name="privacy"
                                checked={isPrivate}
                                onChange={() => setIsPrivate(true)}
                                className="mt-0.5 w-4 h-4 text-blue-600 flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-semibold text-sm text-gray-900 dark:text-gray-100">{t('patients.confirmation.privateFile')}</span>
                                </div>
                                <p className="text-xs text-gray-600 dark:text-gray-300">
                                  {t('patients.confirmation.privateFileShort')}
                                </p>
                              </div>
                            </div>
                          </label>

                          {/* Option 2: Shared */}
                          <label className={`block border-2 rounded-lg p-3 cursor-pointer transition-all ${!isPrivate ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:border-blue-500' : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}`}>
                            <div className="flex items-start gap-2.5">
                              <input
                                type="radio"
                                name="privacy"
                                checked={!isPrivate}
                                onChange={() => setIsPrivate(false)}
                                className="mt-0.5 w-4 h-4 text-blue-600 flex-shrink-0"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="font-semibold text-sm text-gray-900 dark:text-white mb-1">{t('patients.confirmation.sharedFile')}</div>
                                <p className="text-xs text-gray-600 dark:text-gray-400">
                                  {t('patients.confirmation.sharedFileShort')}
                                </p>
                              </div>
                            </div>
                          </label>
                        </div>
                      </div>

                      {/* Médecin traitant option - Masqué si l'utilisateur est déjà le médecin traitant */}
                      {primaryCareInfo?.isCurrentDoctor ? (
                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg p-4 mb-6">
                          <div className="flex items-center gap-2">
                            <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <p className="text-sm font-medium text-green-800 dark:text-green-300">
                              Vous êtes le médecin traitant de ce patient
                            </p>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg p-4 mb-6">
                          <h4 className="font-semibold text-gray-900 dark:text-white mb-3 text-sm flex items-center gap-2">
                            <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Médecin traitant
                          </h4>
                          <div className="space-y-2.5">
                            {/* Option Oui - Ouvre popup de confirmation */}
                            <button
                              type="button"
                              onClick={() => setShowPrimaryCareConfirm(true)}
                              className={`w-full block border-2 rounded-lg p-2.5 cursor-pointer transition-all text-left ${becomePrimaryCare === true ? 'border-green-500 bg-green-100 dark:bg-green-900/40' : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 hover:border-gray-300'}`}
                            >
                              <div className="flex items-center gap-2.5">
                                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${becomePrimaryCare === true ? 'border-green-600 bg-green-600' : 'border-gray-400'}`}>
                                  {becomePrimaryCare === true && <div className="w-2 h-2 bg-white rounded-full" />}
                                </div>
                                <div className="flex-1">
                                  <div className="font-medium text-sm text-gray-900 dark:text-white">Oui, devenir médecin traitant</div>
                                </div>
                              </div>
                            </button>

                            {/* Option Non */}
                            <label className={`block border-2 rounded-lg p-2.5 cursor-pointer transition-all ${becomePrimaryCare === false ? 'border-blue-500 bg-blue-100 dark:bg-blue-900/40' : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 hover:border-gray-300'}`}>
                              <div className="flex items-center gap-2.5">
                                <input
                                  type="radio"
                                  name="primaryCare"
                                  checked={becomePrimaryCare === false}
                                  onChange={() => setBecomePrimaryCare(false)}
                                  className="w-4 h-4 text-blue-600"
                                />
                                <div className="flex-1">
                                  <div className="font-medium text-sm text-gray-900 dark:text-white">Non, pas pour le moment</div>
                                </div>
                              </div>
                            </label>
                          </div>

                          {/* Afficher médecin traitant actuel si existant */}
                          {primaryCareInfo?.hasPrimaryCare && primaryCareInfo?.primaryCareDoctor && (
                            <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
                              <p className="text-xs text-blue-800 dark:text-blue-300 font-medium">
                                ℹ️ Médecin traitant actuel :
                                <span className="block mt-1 text-sm font-semibold">
                                  Dr. {primaryCareInfo.primaryCareDoctor.name} {primaryCareInfo.primaryCareDoctor.family_name}
                                </span>
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      {duplicatePatient && (
                        <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                          <p className="text-sm text-yellow-800">
                            {t('patients.form.duplicateWarning')}
                          </p>
                        </div>
                      )}

                      {/* Action buttons */}
                      <div className="flex gap-3">
                        <button
                          onClick={() => setShowConfirmAdd(false)}
                          className="flex-1 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={handleSaveAdd}
                          disabled={isUpdating || addLoading || (!primaryCareInfo?.isCurrentDoctor && becomePrimaryCare === null)}
                          className="flex-1 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 disabled:opacity-50 transition-colors font-medium"
                        >
                          {isUpdating || addLoading ? (
                            <div className="flex items-center justify-center gap-2">
                              <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                              Mise à jour...
                            </div>
                          ) : (
                            'Mettre à jour'
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      {/* Step 1: Introduction - Creation only */}
                      {currentStep === 1 && (
                        <div className="text-center">
                          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg className="w-10 h-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          </div>
                          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                            {t('patients.confirmation.beforeFirstConsultation')}
                          </h3>
                          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4 text-left">
                            <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                              {t('patients.confirmation.mustInformPatient').replace('{name}', `${formData.family_name} ${formData.name}`)}
                            </p>
                            <p className="text-xs text-gray-600 dark:text-gray-400 italic">
                              {t('patients.confirmation.legalRequirement')}
                            </p>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                            {t('patients.confirmation.presNextToSee')}
                          </p>
                        </div>
                      )}

                      {/* Step 2: Security and Confidentiality */}
                      {currentStep === 2 && (
                        <div>
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                              </svg>
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('patients.confirmation.securityAndConfidentiality')}</h3>
                              <p className="text-xs text-gray-500 dark:text-gray-400">{t('patients.confirmation.point1of3')}</p>
                            </div>
                          </div>

                          <div className="bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 rounded-lg p-5 space-y-4">
                            <div>
                              <h4 className="font-semibold text-gray-900 dark:text-white mb-2 flex items-center gap-2">
                                {t('patients.confirmation.dataProtectionAndStorage')}
                              </h4>
                              <ul className="space-y-2 ml-7 text-sm text-gray-700 dark:text-gray-300">
                                <li className="flex items-center gap-2">
                                  <span className="text-green-600">✓</span>
                                  <span>{t('patients.confirmation.medicalDataEncrypted')}</span>
                                </li>
                                <li className="flex items-center gap-2">
                                  <span className="text-green-600">✓</span>
                                  <span>{t('patients.confirmation.hostingInAlgeria')}</span>
                                </li>
                                <li className="flex items-center gap-2">
                                  <span className="text-green-600">✓</span>
                                  <span>{t('patients.confirmation.accessLimited')}</span>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Step 3: Private File and Treating Doctor */}
                      {currentStep === 3 && (
                        <div>
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                              </svg>
                            </div>
                            <div className="flex-1">
                              <h3 className="text-base font-bold text-gray-900 dark:text-white">{t('patients.confirmation.medicalFileConfidentiality')}</h3>
                              <p className="text-xs text-gray-500 dark:text-gray-400">{t('patients.confirmation.point2of3')}</p>
                            </div>
                          </div>

                          <p className="text-sm text-gray-700 dark:text-gray-300 mb-3 px-1">
                            {t('patients.confirmation.patientCanChoose')}
                          </p>

                          <div className="space-y-2.5">

                            {/* Option 1: Shared */}
                            <label className={`block border-2 rounded-lg p-3 cursor-pointer transition-all ${!isPrivate ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:border-blue-500' : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}`}>
                              <div className="flex items-start gap-2.5">
                                <input
                                  type="radio"
                                  name="privacy"
                                  checked={!isPrivate}
                                  onChange={() => setIsPrivate(false)}
                                  className="mt-0.5 w-4 h-4 text-blue-600 flex-shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="font-semibold text-sm text-gray-900 dark:text-gray-100 mb-1.5">{t('patients.confirmation.sharedFile')}</div>
                                  <p className="text-xs text-gray-600 dark:text-gray-300">
                                    {t('patients.confirmation.sharedFileDesc')}
                                  </p>
                                </div>
                              </div>
                            </label>

                            {/* Option 2: Private */}
                            <label className={`block border-2 rounded-lg p-3 cursor-pointer transition-all ${isPrivate ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 dark:border-blue-500' : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}`}>
                              <div className="flex items-start gap-2.5">
                                <input
                                  type="radio"
                                  name="privacy"
                                  checked={isPrivate}
                                  onChange={() => setIsPrivate(true)}
                                  className="mt-0.5 w-4 h-4 text-blue-600 flex-shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                    <span className="font-semibold text-sm text-gray-900 dark:text-gray-100">{t('patients.confirmation.privateFile')}</span>
                                  </div>
                                  <p className="text-xs text-gray-600 dark:text-gray-300">
                                    {t('patients.confirmation.privateFileDesc')}
                                  </p>
                                </div>
                              </div>
                            </label>
                          </div>
                        </div>
                      )}

                      {/* Step 4: Patient Consent - Creation only */}
                      {currentStep === 4 && (
                        <div>
                          <div className="flex items-center gap-3 mb-4">
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                            </div>
                            <div>
                              <h3 className="text-lg font-bold text-gray-900 dark:text-white">{t('patients.confirmation.oralConsent')}</h3>
                              <p className="text-xs text-gray-500 dark:text-gray-400">{t('patients.confirmation.point3of3')}</p>
                            </div>
                          </div>

                          <div className="bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 rounded-lg p-5 mb-4 transition-colors">
                            <h4 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                              {t('patients.confirmation.infoToCommunicate')}
                            </h4>
                            <ul className="space-y-2 ml-7 text-sm text-gray-700 dark:text-gray-300">
                              <li className="flex items-center gap-2">
                                <span className="text-blue-600">→</span>
                                <span>{t('patients.confirmation.rightToAccess')}</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <span className="text-blue-600">→</span>
                                <span>{t('patients.confirmation.rightToWithdraw')}</span>
                              </li>
                            </ul>
                          </div>

                          <div className="bg-blue-50 dark:bg-blue-900/20 border-2 border-blue-300 dark:border-blue-700 rounded-lg p-5 mb-4 transition-colors">
                            <p className="text-sm text-gray-700 dark:text-gray-300 mb-4">
                              {t('patients.confirmation.onceInformed').replace('{name}', `${formData.family_name} ${formData.name}`)}
                            </p>
                            <label className="flex items-start gap-3 cursor-pointer group">
                              <input
                                type="checkbox"
                                checked={hasInformedPatient}
                                onChange={(e) => setHasInformedPatient(e.target.checked)}
                                className="mt-1 w-5 h-5 text-green-600 rounded focus:ring-2 focus:ring-green-500"
                              />
                              <span className="text-sm font-semibold text-gray-900 dark:text-white group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                                {t('patients.confirmation.iHaveInformed')}
                              </span>
                            </label>
                          </div>

                          {duplicatePatient && (
                            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                              <p className="text-sm text-yellow-800">
                                {t('patients.form.duplicateWarning')}
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Navigation Buttons - Creation only */}
                      <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-200">
                        <button
                          onClick={() => {
                            if (currentStep === 1) {
                              setShowConfirmAdd(false);
                            } else {
                              setCurrentStep(currentStep - 1);
                            }
                          }}
                          className="px-5 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium flex items-center gap-2"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                          </svg>
                          {currentStep === 1 ? t('patients.form.cancel') : t('patients.form.back')}
                        </button>

                        {currentStep < 4 ? (
                          <button
                            onClick={() => setCurrentStep(currentStep + 1)}
                            className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-colors font-medium flex items-center gap-2"
                          >
                            {t('patients.form.next')}
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                            </svg>
                          </button>
                        ) : (
                          <button
                            onClick={handleSaveAdd}
                            disabled={addLoading || !hasInformedPatient}
                            className="px-5 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center gap-2"
                          >
                            {addLoading ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                                {t('patients.form.creating')}
                              </>
                            ) : (
                              <>
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                                {t('patients.form.confirmAndCreate')}
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Modal de confirmation pour devenir médecin traitant */}
      {showPrimaryCareConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-md w-full overflow-hidden">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-6 py-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                Confirmer médecin traitant
              </h3>
            </div>

            <div className="p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Êtes-vous sûr de vouloir devenir le <strong>médecin traitant</strong> de ce patient ?
                </p>

                {/* Afficher le médecin traitant actuel si existant */}
                {primaryCareInfo?.hasPrimaryCare && primaryCareInfo?.primaryCareDoctor && (
                  <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-lg mb-4 text-left">
                    <p className="text-xs text-yellow-800 dark:text-yellow-300 font-medium">
                      ⚠️ Ce patient a déjà un médecin traitant :
                      <span className="block mt-1 text-sm font-semibold">
                        Dr. {primaryCareInfo.primaryCareDoctor.name} {primaryCareInfo.primaryCareDoctor.family_name}
                      </span>
                    </p>
                  </div>
                )}

                {/* Champ commentaire si passation */}
                {primaryCareInfo?.hasPrimaryCare && (
                  <div className="text-left">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Raison de la passation (obligatoire) :
                    </label>
                    <textarea
                      value={transitionComment}
                      onChange={(e) => setTransitionComment(e.target.value)}
                      rows={3}
                      placeholder="Ex: Changement de résidence, meilleure proximité géographique..."
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      required
                    />
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowPrimaryCareConfirm(false);
                    setTransitionComment('');
                  }}
                  className="flex-1 px-4 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors font-medium"
                >
                  Annuler
                </button>
                <button
                  onClick={() => {
                    // Vérifier le commentaire si passation nécessaire
                    if (primaryCareInfo?.hasPrimaryCare && !transitionComment.trim()) {
                      alert('Veuillez indiquer la raison de la passation.');
                      return;
                    }
                    setBecomePrimaryCare(true);
                    setShowPrimaryCareConfirm(false);
                  }}
                  disabled={primaryCareInfo?.hasPrimaryCare && !transitionComment.trim()}
                  className="flex-1 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 disabled:opacity-50 transition-colors font-medium"
                >
                  Confirmer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal des options après création de patient (pour les assistants) */}
      {showPostCreationOptions && createdPatient && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[70] p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden transition-colors">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-6 py-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {t('patients.postCreation.patientCreated') || 'Patient créé avec succès !'}
                  </h3>
                  <p className="text-sm text-white/80">
                    {createdPatient.family_name} {createdPatient.name}
                  </p>
                </div>
              </div>
            </div>

            {/* Options */}
            <div className="p-6">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                {t('patients.postCreation.whatNext') || 'Que souhaitez-vous faire maintenant ?'}
              </p>

              <div className="space-y-3">
                {/* Option 1: Ajouter en salle d'attente */}
                <button
                  onClick={async () => {
                    if (!createdPatient || !user?.id) return;
                    setAddingToWaitingRoom(true);
                    try {
                      const entry = await createEntry(
                        { patient_id: createdPatient.id },
                        user.id
                      );
                      if (entry) {
                        setShowPostCreationOptions(false);
                        setCreatedPatient(null);
                        router.push('/dashboard');
                      }
                    } finally {
                      setAddingToWaitingRoom(false);
                    }
                  }}
                  disabled={addingToWaitingRoom}
                  className="w-full flex items-center gap-4 p-4 border-2 border-gray-200 dark:border-gray-600 rounded-xl hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all group"
                >
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center group-hover:bg-blue-200 dark:group-hover:bg-blue-900/50 transition-colors">
                    <ClockIcon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      {t('patients.postCreation.addToWaitingRoom') || 'Ajouter en salle d\'attente'}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {t('patients.postCreation.addToWaitingRoomDesc') || 'Le patient sera ajouté à la file d\'attente du jour'}
                    </p>
                  </div>
                  {addingToWaitingRoom && (
                    <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-blue-600"></div>
                  )}
                </button>

                {/* Option 2: Prendre un rendez-vous */}
                <button
                  onClick={() => {
                    if (!createdPatient) return;
                    setShowPostCreationOptions(false);
                    setCreatedPatient(null);
                    // Redirect to calendar with patient pre-selected
                    const params = new URLSearchParams({
                      patientId: createdPatient.id,
                      patientName: createdPatient.name,
                      patientFamilyName: createdPatient.family_name,
                      eventType: 'patient'
                    });
                    router.push(`/calendar?${params.toString()}`);
                  }}
                  className="w-full flex items-center gap-4 p-4 border-2 border-gray-200 dark:border-gray-600 rounded-xl hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-all group"
                >
                  <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center group-hover:bg-green-200 dark:group-hover:bg-green-900/50 transition-colors">
                    <CalendarIcon className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      {t('patients.postCreation.takeAppointment') || 'Prendre un rendez-vous'}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {t('patients.postCreation.takeAppointmentDesc') || 'Ouvrir le calendrier avec ce patient sélectionné'}
                    </p>
                  </div>
                </button>

                {/* Option 3: Voir le dossier patient */}
                <button
                  onClick={() => {
                    if (!createdPatient) return;
                    setShowPostCreationOptions(false);
                    router.push(`/patients/${createdPatient.id}`);
                    setCreatedPatient(null);
                  }}
                  className="w-full flex items-center gap-4 p-4 border-2 border-gray-200 dark:border-gray-600 rounded-xl hover:border-purple-500 hover:bg-purple-50 dark:hover:bg-purple-900/20 transition-all group"
                >
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center group-hover:bg-purple-200 dark:group-hover:bg-purple-900/50 transition-colors">
                    <UserIcon className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      {t('patients.postCreation.viewPatientFile') || 'Voir le dossier patient'}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {t('patients.postCreation.viewPatientFileDesc') || 'Accéder directement à la fiche du patient'}
                    </p>
                  </div>
                </button>
              </div>

              {/* Close button */}
              <button
                onClick={() => {
                  setShowPostCreationOptions(false);
                  setCreatedPatient(null);
                  router.push(`/${backPath}`);
                }}
                className="w-full mt-4 px-4 py-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 text-sm transition-colors"
              >
                {t('patients.postCreation.backToList') || 'Retourner à la liste des patients'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default NewOrUpdatePatient;

