'use client';

// PrivacyChoiceModal - Privacy choice selection modal
// Synced with page.original.tsx styling (vertical buttons layout)

import React from 'react';
import { LockClosedIcon, ShareIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface PrivacyChoiceModalProps {
    isOpen: boolean;
    patientName: string;
    isLoading?: boolean;
    onChoosePrivate: () => void;
    onChooseShared: () => void;
    onCancel: () => void;
}

/**
 * PrivacyChoiceModal - Let doctor choose privacy setting for patient
 * Matches the exact layout from page.original.tsx
 */
export function PrivacyChoiceModal({
    isOpen,
    patientName,
    isLoading,
    onChoosePrivate,
    onChooseShared,
    onCancel,
}: PrivacyChoiceModalProps) {
    const { t } = useLanguage();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
            {/* Backdrop */}
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={onCancel} />

            {/* Modal */}
            <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
                {/* Header - blue/indigo gradient with LockClosedIcon (from original) */}
                <div className="bg-gradient-to-r from-blue-500 to-indigo-600 px-6 py-5">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-white/20 rounded-full">
                            <LockClosedIcon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-white">
                                Choix de confidentialité
                            </h2>
                            <p className="text-sm text-white/80">
                                Ce dossier est marqué privé
                            </p>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="p-6">
                    {/* Info box - from original */}
                    <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
                        <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
                            C'est un <strong>nouveau patient</strong> pour vous.
                            Comment souhaitez-vous gérer la confidentialité de ce dossier ?
                        </p>
                    </div>

                    {/* Vertical stacked buttons - from original */}
                    <div className="space-y-3">
                        {/* Private option */}
                        <button
                            onClick={onChoosePrivate}
                            disabled={isLoading}
                            className="w-full flex items-center gap-4 p-4 border-2 border-amber-200 dark:border-amber-700 rounded-xl hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors disabled:opacity-50"
                        >
                            <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-full">
                                <LockClosedIcon className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                            </div>
                            <div className="text-left">
                                <p className="font-medium text-gray-900 dark:text-white">Privé</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">Dossier confidentiel - étiquette "Privé" visible</p>
                            </div>
                        </button>

                        {/* Shared option */}
                        <button
                            onClick={onChooseShared}
                            disabled={isLoading}
                            className="w-full flex items-center gap-4 p-4 border-2 border-green-200 dark:border-green-700 rounded-xl hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors disabled:opacity-50"
                        >
                            <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
                                <ShareIcon className="w-5 h-5 text-green-600 dark:text-green-400" />
                            </div>
                            <div className="text-left">
                                <p className="font-medium text-gray-900 dark:text-white">Partagé</p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">Dossier standard - pas d'étiquette "Privé"</p>
                            </div>
                        </button>
                    </div>
                </div>

                {/* Footer */}
                <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700">
                    <button
                        onClick={onCancel}
                        className="w-full px-4 py-2.5 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                    >
                        Annuler
                    </button>
                </div>
            </div>
        </div>
    );
}

export default PrivacyChoiceModal;
