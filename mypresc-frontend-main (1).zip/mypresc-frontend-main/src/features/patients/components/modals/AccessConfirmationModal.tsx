'use client';

// AccessConfirmationModal - Patient presence confirmation modal
// Synced with page.original.tsx styling (amber/orange header, warning box, custom checkbox)

import React from 'react';
import { ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface AccessConfirmationModalProps {
    isOpen: boolean;
    patientName: string;
    patientPresent: boolean;
    onPatientPresentChange: (checked: boolean) => void;
    onConfirm: () => void;
    onCancel: () => void;
}

/**
 * AccessConfirmationModal - Confirms patient presence before record access
 * Matches the exact layout from page.original.tsx
 */
export function AccessConfirmationModal({
    isOpen,
    patientName,
    patientPresent,
    onPatientPresentChange,
    onConfirm,
    onCancel,
}: AccessConfirmationModalProps) {
    const { t } = useLanguage();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
            {/* Backdrop */}
            <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={onCancel} />

            {/* Modal */}
            <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
                {/* Header - amber/orange gradient with ExclamationTriangleIcon (from original) */}
                <div className="bg-gradient-to-r from-amber-500 to-orange-600 px-6 py-5">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-white/20 rounded-full">
                            <ExclamationTriangleIcon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-white">
                                {t('patients.accessConfirmation.title') || 'Confirmation d\'accès'}
                            </h2>
                            <p className="text-sm text-white/80">
                                {t('patients.accessConfirmation.subtitle') || 'Vérification requise'}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="p-6">
                    {/* Warning box - from original */}
                    <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                        <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                            {t('patients.accessConfirmation.warning') || 'Vous ne pouvez consulter ce dossier médical que si le patient est physiquement présent avec vous. L\'accès non autorisé aux dossiers médicaux est une violation de la confidentialité.'}
                        </p>
                    </div>

                    {/* Custom Checkbox - from original */}
                    <label className="flex items-start gap-3 cursor-pointer group">
                        <div className="relative flex-shrink-0 mt-0.5">
                            <input
                                type="checkbox"
                                checked={patientPresent}
                                onChange={(e) => onPatientPresentChange(e.target.checked)}
                                className="sr-only"
                            />
                            <div className={`w-5 h-5 border-2 rounded transition-all ${patientPresent ? 'bg-green-600 border-green-600' : 'border-gray-300 dark:border-gray-600 group-hover:border-green-500'}`}>
                                {patientPresent && (
                                    <svg className="w-full h-full text-white p-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                )}
                            </div>
                        </div>
                        <span className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                            {t('patients.accessConfirmation.checkbox') || 'Je confirme que le patient est présent avec moi et que j\'ai son consentement pour accéder à son dossier médical.'}
                        </span>
                    </label>
                </div>

                {/* Footer - green confirm button when checked (from original) */}
                <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                    <button
                        onClick={onCancel}
                        className="flex-1 px-4 py-2.5 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                    >
                        {t('common.cancel') || 'Annuler'}
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={!patientPresent}
                        className={`flex-1 px-4 py-2.5 font-medium rounded-xl transition-colors ${patientPresent ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'}`}
                    >
                        {t('patients.accessConfirmation.confirm') || 'Confirmer l\'accès'}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default AccessConfirmationModal;
