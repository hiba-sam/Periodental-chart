'use client';

// NinPopupModal - National Identification Number input modal
// Prompts to add NIN for patients without one

import React, { useState } from 'react';
import { UserIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';

interface NinPopupModalProps {
    isOpen: boolean;
    patientId: string;
    patientName: string;
    onSave: (nin: string) => Promise<void>;
    onSkip: () => void;
}

/**
 * NinPopupModal - Prompt to add missing NIN
 */
export function NinPopupModal({
    isOpen,
    patientId,
    patientName,
    onSave,
    onSkip,
}: NinPopupModalProps) {
    const [ninInput, setNinInput] = useState('');
    const [isSaving, setIsSaving] = useState(false);

    if (!isOpen) return null;

    const handleSave = async () => {
        if (!ninInput.trim()) {
            alert('Veuillez entrer un NIN valide');
            return;
        }

        setIsSaving(true);
        try {
            await onSave(ninInput.trim());
            setNinInput('');
        } catch (error) {
            console.error('Error saving NIN:', error);
            alert('Erreur lors de l\'enregistrement');
        } finally {
            setIsSaving(false);
        }
    };

    const handleSkip = () => {
        setNinInput('');
        onSkip();
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[70] p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
                {/* Header */}
                <div className="bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-4">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                        <ExclamationTriangleIcon className="w-6 h-6" />
                        NIN manquant
                    </h3>
                </div>

                {/* Content */}
                <div className="p-6">
                    {/* Info section */}
                    <div className="text-center mb-6">
                        <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                            <UserIcon className="w-8 h-8 text-amber-600 dark:text-amber-400" />
                        </div>
                        <p className="text-gray-700 dark:text-gray-300 mb-2">
                            Le patient <strong>{patientName}</strong> n'a pas de NIN.
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                            Le NIN est important pour centraliser les données médicales.
                        </p>
                    </div>

                    {/* NIN Input */}
                    <div className="mb-6">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Numéro d'Identification National (NIN)
                        </label>
                        <input
                            type="text"
                            value={ninInput}
                            onChange={(e) => setNinInput(e.target.value)}
                            placeholder="Entrez le NIN..."
                            className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3">
                        <button
                            onClick={handleSkip}
                            className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 font-medium transition-colors"
                        >
                            Prochaine fois
                        </button>
                        <button
                            onClick={handleSave}
                            disabled={isSaving || !ninInput.trim()}
                            className="flex-1 px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 font-medium transition-colors"
                        >
                            {isSaving ? 'Enregistrement...' : 'Enregistrer le NIN'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default NinPopupModal;
