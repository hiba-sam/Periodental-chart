// Modal components barrel export
export { AccessConfirmationModal } from './AccessConfirmationModal';
export { PrivacyChoiceModal } from './PrivacyChoiceModal';
export { NinPopupModal } from './NinPopupModal';
export { PatientHistoryModal } from './PatientHistoryModal';
