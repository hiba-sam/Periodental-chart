// Components barrel export for patients feature
export * from './modals';


export { NewOrUpdatePatient } from './NewOrUpdatePatient';
export { PatientsList } from './PatientsList';