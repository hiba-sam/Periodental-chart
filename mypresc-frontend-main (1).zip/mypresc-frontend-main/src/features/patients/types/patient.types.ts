// Patient Types - Core type definitions for patient-related data
// This follows a feature-based architecture for self-contained components

/**
 * Core Patient interface (aligned with backend ApiPatient)
 */
export interface Patient {
    id: string;
    name: string;
    family_name: string;
    age: number;
    genre: 'homme' | 'femme';
    telephone: string;
    email?: string;
    adresse?: string;
    dateNaissance: string;
    numeroSecuriteSociale?: string;
    medecinTraitant?: string;
    allergies?: string[] | null;
    notes?: string | null;
    nin?: string;
    emergencyPhone?: string;
    emergencyContact?: string;
    is_private?: boolean;
    assignedDoctor?: {
        name: string;
        phone: string;
    } | null;
    assistant_id?: number | null;
    is_chart_readed?: boolean;
    created_at?: string;
    updated_at?: string;
    is_shared_with_me?: boolean;
}

/**
 * Data required to create or update a patient
 */
export interface PatientFormData {
    name: string;
    family_name: string;
    dateNaissance?: string;
    genre: 'homme' | 'femme';
    telephone?: string;
    email?: string;
    adresse?: string;
    numeroSecuriteSociale?: string;
    medecinTraitant?: string;
    allergies?: string[] | string | null;
    notes?: string | null;
    nin?: string;
    age?: number | string;
    is_private?: boolean;
    emergencyPhone?: string;
    emergencyContact?: string;
}

/**
 * Filters for searching/filtering patients
 */
export interface PatientFilters {
    searchTerm?: string;
    limit?: number;
    includeAll?: boolean;
    genre?: 'homme' | 'femme' | 'all';
    hasNin?: boolean;
    isPrivate?: boolean;
    dateFrom?: string;
    dateTo?: string;
}

/**
 * Patient list item (minimal data for lists)
 */
export interface PatientListItem {
    id: string;
    name: string;
    family_name: string;
    telephone: string;
    age: number;
    genre: 'homme' | 'femme';
    is_private?: boolean;
}

/**
 * Patient statistics data structure
 */
export interface PatientStatistics {
    weeklyData: Array<{ period: string; patients: number }>;
    monthlyData: Array<{ period: string; patients: number }>;
    yearlyData: Array<{ period: string; patients: number }>;
}

/**
 * Patient history entry
 */
export interface PatientHistoryEntry {
    id: string;
    date: string;
    type: 'prescription' | 'appointment' | 'medical_report' | 'invoice';
    description: string;
    doctor_name?: string;
}

/**
 * Patient with medical data
 */
export interface PatientWithMedicalData extends Patient {
    prescriptions?: number;
    appointments?: number;
    medicalReports?: number;
    unpaidInvoices?: number;
}
