// Hooks barrel export
export {
    usePatient,
    usePatientVisitCount,
    usePatientHistory as usePatientHistoryQuery,
    useUpdatePatient,
    useUpdatePatientNin,
    useMarkChartAsRead,
    patientKeys,
} from './usePatient';

export { usePatientAccess } from './usePatientAccess';

export {
    usePatientPrivacy,
    usePrivacyChoice,
    usePrimaryCareInfo as usePrimaryCareInfoQuery,
    usePatientShares as usePatientSharesQuery,
    useSavePrivacyChoice,
    useTogglePrimaryCareSharing,
    privacyKeys,
} from './usePatientPrivacy';

export {
    usePrimaryCare,
    usePrimaryCareInfo,
    useActiveShares,
    useReceivedShares,
    primaryCareKeys,
} from './usePrimaryCare';

export {
    usePatientHistory,
    patientHistoryKeys,
    type HistoryEntry,
    type HistoryMetadata,
} from './usePatientHistory';

export {
    useVisitCounter,
    visitCounterKeys,
} from './useVisitCounter';

export { usePatientDetail } from './usePatientDetail';
