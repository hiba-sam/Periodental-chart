// usePatientAccess Hook - Manages access confirmation and popup logic
// Self-contained hook for patient access verification

import { useState, useRef, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import type { Patient, PrimaryCareInfo, PrivacyChoice } from '../types';

interface UsePatientAccessProps {
    patient: Patient | null;
    userRole?: string;
    isLoading: boolean;
    isPrescriptionLoading: boolean;
    isReportsLoading: boolean;
    primaryCareInfo: PrimaryCareInfo | null;
    myPrivacyChoice: PrivacyChoice | null;
    privacyChoiceLoaded: boolean;
    onMarkChartAsRead: (isPrivate: boolean) => Promise<boolean>;
    onSavePrivacyChoice: (choice: PrivacyChoice) => Promise<boolean>;
}

interface UsePatientAccessReturn {
    // State
    showAccessConfirmation: boolean;
    showPrivacyChoicePopup: boolean;
    accessConfirmed: boolean;
    patientPresentCheckbox: boolean;

    // Setters
    setPatientPresentCheckbox: (value: boolean) => void;

    // Handlers
    handleAccessConfirm: () => void;
    handleAccessCancel: () => void;
    handlePrivacyChoice: (choice: PrivacyChoice) => Promise<void>;

    // Modal control
    closeAccessConfirmation: () => void;
    closePrivacyChoicePopup: () => void;
}

/**
 * Hook to manage patient access confirmation and privacy choice popups
 * 
 * Logic flow:
 * 1. If patient is shared with current doctor → show Access Confirmation only, skip Privacy Choice
 * 2. If owner AND no choice made → show Privacy Choice popup
 * 3. If NOT owner → show Access Confirmation popup, then Privacy Choice
 */
export function usePatientAccess({
    patient,
    userRole,
    isLoading,
    isPrescriptionLoading,
    isReportsLoading,
    primaryCareInfo,
    myPrivacyChoice,
    privacyChoiceLoaded,
    onMarkChartAsRead,
    onSavePrivacyChoice,
}: UsePatientAccessProps): UsePatientAccessReturn {
    const router = useRouter();

    // Access state
    const [showAccessConfirmation, setShowAccessConfirmation] = useState(false);
    const [accessConfirmed, setAccessConfirmed] = useState(false);
    const [patientPresentCheckbox, setPatientPresentCheckbox] = useState(false);

    // Privacy choice popup state
    const [showPrivacyChoicePopup, setShowPrivacyChoicePopup] = useState(false);

    // Ref to prevent popup useEffect from triggering multiple times
    const popupTriggeredRef = useRef(false);

    /**
     * Handle access confirmation (patient present checkbox confirmed)
     */
    const handleAccessConfirm = useCallback(() => {
        if (!patientPresentCheckbox) return;
        setShowAccessConfirmation(false);

        // If patient is shared with current doctor, skip Privacy Choice popup
        // Shared doctors only need to confirm patient presence, not set privacy
        if ((patient as any)?.is_shared_with_me === true) {
            setAccessConfirmed(true);
            return;
        }

        // For non-shared patients, show privacy choice popup
        setShowPrivacyChoicePopup(true);
    }, [patientPresentCheckbox, patient]);

    /**
     * Handle access cancellation (redirect to patients list)
     */
    const handleAccessCancel = useCallback(() => {
        router.push('/patients');
    }, [router]);

    /**
     * Handle privacy choice (private or shared)
     * Saves to API and updates patient.is_private
     */
    const handlePrivacyChoice = useCallback(async (choice: PrivacyChoice) => {
        const isPrivateChoice = choice === 'private';

        // Update patient.is_private in database
        if (patient) {
            await onMarkChartAsRead(isPrivateChoice);
        }

        // Save to doctor_patient_privacy table
        await onSavePrivacyChoice(choice);

        setShowPrivacyChoicePopup(false);
        setAccessConfirmed(true);
    }, [patient, onMarkChartAsRead, onSavePrivacyChoice]);

    /**
     * Close access confirmation modal
     */
    const closeAccessConfirmation = useCallback(() => {
        setShowAccessConfirmation(false);
    }, []);

    /**
     * Close privacy choice popup
     */
    const closePrivacyChoicePopup = useCallback(() => {
        setShowPrivacyChoicePopup(false);
    }, []);

    /**
     * Effect to check if popup is needed after data is loaded
     */
    useEffect(() => {
        // Early returns for loading states or already confirmed
        if (!patient || userRole !== 'doctor' || isLoading || isReportsLoading || isPrescriptionLoading) return;
        if (!privacyChoiceLoaded) return; // Wait for privacy choice to be loaded from API
        if (accessConfirmed) return; // Already confirmed in this session

        // Prevent popup from triggering multiple times during data reloads
        if (popupTriggeredRef.current) return;

        // Check if current doctor is the patient owner (created by doctor or their assistant)
        const isPatientOwner = primaryCareInfo?.isPatientOwner === true;

        // Check if current doctor is the primary care doctor
        const isPrimaryCareDoctor = primaryCareInfo?.isCurrentDoctor === true;

        // If patient owner or primary care → check if privacy choice already made
        if (isPatientOwner || isPrimaryCareDoctor) {
            if (myPrivacyChoice) {
                setAccessConfirmed(true); // Auto-confirm access since choice was already made
                return;
            }
            popupTriggeredRef.current = true; // Mark as triggered
            setShowPrivacyChoicePopup(true);
            return;
        }

        // Not owner → check if privacy choice already made
        if (myPrivacyChoice) {
            setAccessConfirmed(true); // Auto-confirm access since choice was already made
            return;
        }

        // No choice made yet → show access confirmation popup
        popupTriggeredRef.current = true; // Mark as triggered
        setShowAccessConfirmation(true);
    }, [
        patient,
        userRole,
        isLoading,
        isReportsLoading,
        isPrescriptionLoading,
        primaryCareInfo,
        accessConfirmed,
        privacyChoiceLoaded,
        myPrivacyChoice,
    ]);

    /**
     * Effect to auto-confirm access for non-doctor roles
     */
    useEffect(() => {
        if (patient && userRole !== 'doctor' && !accessConfirmed) {
            setAccessConfirmed(true);
        }
    }, [patient, userRole, accessConfirmed]);

    return {
        // State
        showAccessConfirmation,
        showPrivacyChoicePopup,
        accessConfirmed,
        patientPresentCheckbox,

        // Setters
        setPatientPresentCheckbox,

        // Handlers
        handleAccessConfirm,
        handleAccessCancel,
        handlePrivacyChoice,

        // Modal control
        closeAccessConfirmation,
        closePrivacyChoicePopup,
    };
}
