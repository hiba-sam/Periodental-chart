'use client';

// usePatientDetail - Combines all patient page hooks
// Single hook for orchestrating the complete patient detail page

import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useProfile } from '@/contexts/ProfileContext';
import { usePatients, ApiPatient } from '@/contexts/PatientsContext';
import { usePrescription } from '@/contexts/PrescriptionContext';
import { useAppointments, Appointment } from '@/contexts/AppointmentContext';
import axios from 'axios';
import { safeStorage } from '@/utils/safeStorage';

// Feature hooks
import { usePatientHistory, HistoryEntry, HistoryMetadata } from './usePatientHistory';
import { usePrimaryCare } from './usePrimaryCare';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

interface UsePatientDetailProps {
    patientId: string;
}

/**
 * Dental specialties that show dental acts section
 */
const DENTAL_SPECIALTIES = [
    'Chirurgie dentaire',
    'Orthodontie',
    'Parodontologie',
    'Implantologie',
    'Médecine bucco-dentaire'
];

/**
 * Cardiology specialties that show cardiology reports section
 */
const CARDIOLOGY_SPECIALTIES = [
    'Cardiologie',
    'Chirurgie cardiaque',
    'Cardiologie interventionnelle',
];

/**
 * Optical specialties that show optical corrections section
 */
const OPTICAL_SPECIALTIES = [
    'Ophtalmologie',
    'ORL (Oto-Rhino-Laryngologie)',
    'Audiologie',
    'Phoniatrie',
];

/**
 * usePatientDetail - Main orchestration hook for patient detail page
 * Combines all feature hooks into a single, clean interface
 */
export function usePatientDetail({
    patientId,
}: UsePatientDetailProps) {
    const router = useRouter();
    const { isAuthenticated, user } = useAuth();
    const { t } = useLanguage();
    const { profile } = useProfile();

    // Context hooks
    const { getPatient, markChartAsRead, loading: patientsLoading } = usePatients();
    const { prescriptions, fetchPrescriptions, loading: prescriptionLoading } = usePrescription();
    const { fetchAppointmentsByPatient } = useAppointments();

    // Local state
    const [patient, setPatient] = useState<ApiPatient | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);
    const [appointments, setAppointments] = useState<Appointment[]>([]);
    const [prescriptionFilter, setPrescriptionFilter] = useState<'all' | 'mine'>('all');
    const [showShareModal, setShowShareModal] = useState(false);

    // Access control state
    const [accessConfirmed, setAccessConfirmed] = useState(false);
    const [showAccessConfirmation, setShowAccessConfirmation] = useState(false);
    const [patientPresentCheckbox, setPatientPresentCheckbox] = useState(false);
    const [showPrivacyChoicePopup, setShowPrivacyChoicePopup] = useState(false);
    const [myPrivacyChoice, setMyPrivacyChoice] = useState<'private' | 'shared' | null>(null);
    const [privacyChoiceLoaded, setPrivacyChoiceLoaded] = useState(false);

    // Ref to prevent popup useEffect from triggering multiple times
    const popupTriggeredRef = useRef(false);
    // Ref to track loaded privacy choice synchronously (avoids race condition with state)
    const loadedPrivacyChoiceRef = useRef<'private' | 'shared' | null>(null);

    // NIN popup state
    const [showNinPopup, setShowNinPopup] = useState(false);

    // Role checks
    const isDoctor = user?.role === 'doctor';
    const isAssistant = user?.role === 'assistant';
    const isDentalSpecialist = isDoctor && profile?.speciality
        ? DENTAL_SPECIALTIES.some(spec =>
            profile.speciality?.toLowerCase().includes(spec.toLowerCase())
        )
        : false;
    const isCardiologist = isDoctor && profile?.speciality
        ? CARDIOLOGY_SPECIALTIES.some(spec =>
            profile.speciality?.toLowerCase().includes(spec.toLowerCase())
        )
        : false;
    const isOptometrist = isDoctor && profile?.speciality
        ? OPTICAL_SPECIALTIES.some(spec =>
            profile.speciality?.toLowerCase().includes(spec.toLowerCase())
        )
        : false;

    // Feature hooks
    const historyHook = usePatientHistory(patientId);
    const primaryCareHook = usePrimaryCare(patientId);

    // Derived state
    const uniqueDoctorIds = useMemo(() => {
        return Array.from(new Set(prescriptions.map(p => p.doctor_user_id)));
    }, [prescriptions]);
    const hasMultipleDoctors = uniqueDoctorIds.length > 1;
    const canSeeOtherDoctorsPrescriptions =
        primaryCareHook.primaryCareInfo?.isCurrentDoctor === true ||
        primaryCareHook.primaryCareInfo?.shared === true;
    const isSharedPatient = canSeeOtherDoctorsPrescriptions || hasMultipleDoctors;

    // Filtered prescriptions
    const filteredPrescriptions = useMemo(() => {
        if (!user?.id) return prescriptions;
        const currentUserId = parseInt(user.id);
        if (prescriptionFilter === 'mine') {
            return prescriptions.filter(p => p.doctor_user_id === currentUserId);
        }
        return prescriptions;
    }, [prescriptions, prescriptionFilter, user?.id]);

    // Calculate visit count for doctors
    const visitCount = useMemo(() => {
        if (!isDoctor || !user?.id) {
            return patient?.consultations ?? 0;
        }

        // Get unique days from prescriptions by this doctor
        const toLocalDate = (date: Date) => {
            const d = new Date(date);
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        };

        const prescriptionDates = prescriptions
            .filter(p => p.doctor_user_id === parseInt(user.id))
            .map(p => toLocalDate(new Date(p.created_at)));

        return new Set(prescriptionDates).size;
    }, [isDoctor, user?.id, prescriptions, patient?.consultations]);

    // Fetch patient data (without showing access modals directly)
    useEffect(() => {
        let isMounted = true;

        const loadData = async () => {
            if (!isAuthenticated || !patientId) return;

            setLoading(true);
            try {
                const patientData = await getPatient(patientId);
                if (!isMounted) return;

                if (patientData) {
                    setPatient(patientData);

                    // Fetch related data
                    await fetchPrescriptions({ patientId });
                    const appointmentsData = await fetchAppointmentsByPatient(patientId);
                    setAppointments(appointmentsData || []);

                    // Auto-confirm for non-doctors (assistants, etc.)
                    if (user?.role !== 'doctor') {
                        setAccessConfirmed(true);
                    }
                    // For doctors, the popup logic is handled in a separate useEffect
                }
            } catch (err) {
                if (isMounted) {
                    setError(err instanceof Error ? err : new Error('Failed to load patient'));
                }
            } finally {
                if (isMounted) {
                    setLoading(false);
                }
            }
        };

        loadData();

        return () => {
            isMounted = false;
        };
    }, [patientId, isAuthenticated, user?.role]);

    // Fetch privacy choice from API
    useEffect(() => {
        const loadPrivacyChoice = async () => {
            let loadedChoice: 'private' | 'shared' | null = null;
            if (patient && user?.role === 'doctor') {
                try {
                    const response = await axios.get(
                        `${API_URL}/doctor-patient-privacy/patient/${patientId}`,
                        { withCredentials: true }
                    );
                    if (response.data.success && response.data.data.privacy_choice) {
                        loadedChoice = response.data.data.privacy_choice;
                    }
                } catch { /* ignore - no choice saved yet */ }
            }
            // Store in ref synchronously to avoid race condition with state
            loadedPrivacyChoiceRef.current = loadedChoice;
            if (loadedChoice) {
                setMyPrivacyChoice(loadedChoice);
            }
            setPrivacyChoiceLoaded(true);
        };
        loadPrivacyChoice();
    }, [patient, user, patientId]);

    // Determine which popup to show based on loaded data (matches original page logic)
    // Logic:
    // 1. If patient is shared with current doctor (via medical_shares) → show Access Confirmation only, skip Privacy Choice
    // 2. If owner AND no choice made → show Privacy Choice popup
    // 3. If NOT owner → show Access Confirmation popup, then Privacy Choice
    useEffect(() => {
        if (!patient || user?.role !== 'doctor' || loading || prescriptionLoading) return;
        if (!privacyChoiceLoaded) return; // Wait for privacy choice to be loaded from API
        if (accessConfirmed) return; // Already confirmed in this session

        // Prevent popup from triggering multiple times during data reloads
        if (popupTriggeredRef.current) return;

        // Check if current doctor is the patient owner (created by doctor or their assistant)
        const isPatientOwner = primaryCareHook.primaryCareInfo?.isPatientOwner === true;

        // Check if current doctor is the primary care doctor
        const isPrimaryCareDoctor = primaryCareHook.primaryCareInfo?.isCurrentDoctor === true;

        // If patient owner or primary care → check if privacy choice already made
        if (isPatientOwner || isPrimaryCareDoctor) {
            // If privacy choice already exists (check both state and ref for race condition), skip the popup
            if (myPrivacyChoice || loadedPrivacyChoiceRef.current) {
                setAccessConfirmed(true); // Auto-confirm access since choice was already made
                return;
            }
            popupTriggeredRef.current = true; // Mark as triggered
            setShowPrivacyChoicePopup(true);
            return;
        }

        // Not owner (including shared doctors) → check if privacy choice already made
        // If doctor already made a privacy choice for this patient, skip both popups
        if (myPrivacyChoice || loadedPrivacyChoiceRef.current) {
            setAccessConfirmed(true); // Auto-confirm access since choice was already made
            return;
        }

        // No choice made yet → show access confirmation popup
        // Shared doctors will see the confirmation modal but NOT the Privacy Choice popup
        popupTriggeredRef.current = true; // Mark as triggered
        setShowAccessConfirmation(true);
    }, [patient, user, loading, prescriptionLoading, primaryCareHook.primaryCareInfo, accessConfirmed, privacyChoiceLoaded, myPrivacyChoice]);

    // NIN popup logic for doctors
    useEffect(() => {
        if (!patient || !isDoctor || patient.nin) return;

        const storageKey = `nin_popup_${patientId}`;
        const today = new Date().toISOString().split('T')[0];

        try {
            const storedData = safeStorage.getItem(storageKey);
            let visitData = storedData ? JSON.parse(storedData) : { visits: 0, lastPopupDate: '', lastVisitDate: '' };

            // Reset visits if it's a new day
            if (visitData.lastVisitDate !== today) {
                visitData.visits = 0;
                visitData.lastVisitDate = today;
            }

            visitData.visits += 1;

            // Show popup after 2nd visit, but only once per day
            if (visitData.visits >= 2 && visitData.lastPopupDate !== today) {
                setShowNinPopup(true);
                visitData.lastPopupDate = today;
            }

            safeStorage.setItem(storageKey, JSON.stringify(visitData));
        } catch {
            // Ignore localStorage errors
        }
    }, [patient, patientId, isDoctor]);

    // Access control handlers
    const handleAccessConfirm = useCallback(() => {
        if (!patientPresentCheckbox) return;
        setShowAccessConfirmation(false);

        // If patient is shared with current doctor, skip Privacy Choice popup
        // Shared doctors only need to confirm patient presence, not set privacy
        if ((patient as any)?.is_shared_with_me === true) {
            setAccessConfirmed(true);
            return;
        }

        // For non-shared patients, show privacy choice popup
        setShowPrivacyChoicePopup(true);
    }, [patientPresentCheckbox, patient]);

    const handlePrivacyChoice = useCallback(async (choice: 'private' | 'shared') => {
        const isPrivateChoice = choice === 'private';

        // Update patient.is_private in database (like PatientChartModal does)
        if (patient) {
            await markChartAsRead(patient.id, isPrivateChoice);
            setPatient(prev => prev ? { ...prev, is_private: isPrivateChoice } : null);
        }

        // Also save to doctor_patient_privacy table
        try {
            await axios.post(
                `${API_URL}/doctor-patient-privacy/patient/${patientId}`,
                { privacy_choice: choice },
                { withCredentials: true }
            );
        } catch { /* ignore */ }

        setMyPrivacyChoice(choice);
        setShowPrivacyChoicePopup(false);
        // After privacy choice, confirm access
        setAccessConfirmed(true);
    }, [patient, patientId, markChartAsRead]);

    const handleCancelAccess = useCallback(() => {
        router.push('/patients');
    }, [router]);

    // NIN handlers
    const onSaveNin = useCallback(async (nin: string) => {
        try {
            const response = await axios.put(`${API_URL}/patient/${patientId}`, { nin: nin.trim() }, { withCredentials: true });
            if (response.data.success) {
                setPatient(prev => prev ? { ...prev, nin: nin.trim() } : null);
                setShowNinPopup(false);
                safeStorage.removeItem(`nin_popup_${patientId}`);
            }
        } catch {
            throw new Error('Error saving NIN');
        }
    }, [patientId]);

    const onSkipNin = useCallback(() => {
        setShowNinPopup(false);
    }, []);

    return {
        // Patient data
        patient,
        loading: loading || patientsLoading,
        error,

        // Auth & user
        user,
        isDoctor,
        isAssistant,
        isDentalSpecialist,
        isCardiologist,
        isOptometrist,

        // Access control
        accessControl: {
            showAccessConfirmation,
            accessConfirmed,
            patientPresentCheckbox,
            showPrivacyChoicePopup,
            myPrivacyChoice,
            setPatientPresentCheckbox,
            handleAccessConfirm,
            handlePrivacyChoice,
            handleCancelAccess,
        },

        // Prescriptions
        prescriptions,
        filteredPrescriptions,
        prescriptionFilter,
        setPrescriptionFilter,
        isSharedPatient,
        hasMultipleDoctors,

        // Appointments
        appointments,

        // History
        history: {
            data: historyHook.history,
            metadata: historyHook.metadata,
            isLoading: historyHook.isLoading,
            showModal: historyHook.showHistoryModal,
            openModal: historyHook.openHistoryModal,
            closeModal: historyHook.closeHistoryModal,
        },

        // Primary care
        primaryCare: {
            info: primaryCareHook.primaryCareInfo,
            isCurrentDoctor: primaryCareHook.primaryCareInfo?.isCurrentDoctor ?? false,
            shared: primaryCareHook.primaryCareInfo?.shared ?? false,
            toggleSharing: primaryCareHook.togglePrimaryCareSharing,
            isLoading: primaryCareHook.isLoadingPrimaryCare,
        },

        // Visit counter & NIN popup
        visitCount,
        showNinPopup,
        onSaveNin,
        onSkipNin,

        // Share modal
        showShareModal,
        setShowShareModal,

        // Navigation
        router,

        // Translation
        t,
    };
}

export default usePatientDetail;
