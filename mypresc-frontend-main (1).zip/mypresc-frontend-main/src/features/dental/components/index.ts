export { default as DentalActHistory } from './DentalActHistory';
export { default as DentalActModal } from './DentalActModal';
export { default as Odontogram } from './Odontogram';
