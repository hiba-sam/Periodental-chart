// Dental API - Centralized API functions for dental operations
import axios from 'axios';
import type { DentalAct, DentalActPayload, CatalogAct } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Axios instance for dental acts
const dentalApi = axios.create({
    baseURL: `${API_URL}/api`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

/**
 * Fetch dental acts for a patient
 */
export async function fetchPatientDentalActs(
    patientId: string
): Promise<{ success: boolean; data?: DentalAct[]; error?: string }> {
    try {
        const response = await dentalApi.get(`/patients/${patientId}/dental-acts`);
        if (response.data.success) {
            return { success: true, data: response.data.data };
        }
        return { success: false, error: 'Erreur lors du chargement des actes dentaires' };
    } catch (err: any) {
        console.error('Error fetching dental acts:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors du chargement des actes dentaires',
        };
    }
}

/**
 * Create a new dental act
 */
export async function createDentalAct(
    patientId: string,
    payload: DentalActPayload
): Promise<{ success: boolean; data?: DentalAct; error?: string }> {
    try {
        const response = await dentalApi.post(`/patients/${patientId}/dental-acts`, payload);
        if (response.data.success) {
            return { success: true, data: response.data.data };
        }
        return { success: false, error: 'Erreur lors de la création de l\'acte dentaire' };
    } catch (err: any) {
        console.error('Error creating dental act:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors de la création de l\'acte dentaire',
        };
    }
}

/**
 * Update an existing dental act
 */
export async function updateDentalAct(
    actId: number,
    payload: Partial<DentalActPayload>
): Promise<{ success: boolean; data?: DentalAct; error?: string }> {
    try {
        const response = await dentalApi.patch(`/dental-acts/${actId}`, payload);
        if (response.data.success) {
            return { success: true, data: response.data.data };
        }
        return { success: false, error: 'Erreur lors de la modification de l\'acte dentaire' };
    } catch (err: any) {
        console.error('Error updating dental act:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors de la modification de l\'acte dentaire',
        };
    }
}

/**
 * Update dental act status only
 */
export async function updateDentalActStatus(
    actId: number,
    status: DentalActPayload['status']
): Promise<{ success: boolean; error?: string }> {
    try {
        await dentalApi.patch(`/dental-acts/${actId}`, { status });
        return { success: true };
    } catch (err: any) {
        console.error('Error updating dental act status:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors de la mise à jour du statut',
        };
    }
}

/**
 * Search catalog acts
 */
export async function searchCatalogActs(
    query: string,
    limit: number = 20
): Promise<{ success: boolean; data?: CatalogAct[]; error?: string }> {
    try {
        const response = await dentalApi.get('/catalog/acts', {
            params: { q: query, limit },
        });
        if (response.data.success) {
            return { success: true, data: response.data.data.acts };
        }
        return { success: false, error: 'Erreur lors de la recherche d\'actes' };
    } catch (err: any) {
        console.error('Catalog search error:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors de la recherche d\'actes',
        };
    }
}
