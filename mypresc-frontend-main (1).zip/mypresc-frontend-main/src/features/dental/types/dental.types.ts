// Dental Types - Core type definitions for dental-related data

/**
 * Tooth surface identifiers (FDI notation)
 */
export type ToothSurface = 'O' | 'M' | 'D' | 'B' | 'L';

/**
 * Surface labels for display
 */
export const SURFACE_LABELS: Record<ToothSurface, string> = {
    'O': 'Occlusale',
    'M': 'Mésiale',
    'D': 'Distale',
    'B': 'Buccale/Vestibulaire',
    'L': 'Linguale/Palatine'
};

/**
 * FDI tooth numbering system - Quadrants
 */
export const TOOTH_QUADRANTS = {
    UPPER_RIGHT: ['18', '17', '16', '15', '14', '13', '12', '11'],
    UPPER_LEFT: ['21', '22', '23', '24', '25', '26', '27', '28'],
    LOWER_LEFT: ['31', '32', '33', '34', '35', '36', '37', '38'],
    LOWER_RIGHT: ['48', '47', '46', '45', '44', '43', '42', '41']
} as const;

/**
 * Dental act scope
 */
export type DentalActScope = 'TOOTH' | 'MOUTH';

/**
 * Dental act status
 */
export type DentalActStatus = 'NON_COMMENCE' | 'EN_COURS' | 'TERMINE' | 'ANNULE';

/**
 * Status options for UI
 */
export const STATUS_OPTIONS: { value: DentalActStatus; label: string }[] = [
    { value: 'NON_COMMENCE', label: 'Non commencé' },
    { value: 'EN_COURS', label: 'En cours' },
    { value: 'TERMINE', label: 'Terminé' },
    { value: 'ANNULE', label: 'Annulé' }
];

/**
 * Status colors for UI
 */
export const STATUS_COLORS: Record<DentalActStatus, { bg: string; text: string; label: string }> = {
    NON_COMMENCE: { bg: 'bg-gray-100 dark:bg-gray-700', text: 'text-gray-600 dark:text-gray-300', label: 'Non commencé' },
    EN_COURS: { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400', label: 'En cours' },
    TERMINE: { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-600 dark:text-green-400', label: 'Terminé' },
    ANNULE: { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-600 dark:text-red-400', label: 'Annulé' }
};

/**
 * Catalog act from database
 */
export interface CatalogAct {
    id: number;
    code_ccam: string;
    code_short: string;
    label: string;
    chapter_label: string | null;
    family_label: string | null;
}

/**
 * Dental act record from database
 */
export interface DentalAct {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    scope: DentalActScope;
    teeth: string[] | null;
    surfaces: string[] | null;
    act_catalog_id: number | null;
    act_label_cache: string | null;
    act_code_cache: string | null;
    status: DentalActStatus;
    date_act: string;
    notes: string | null;
    created_at: string;
    doctor_name?: string;
    doctor_family_name?: string;
    act_label?: string;
    act_code?: string;
}

/**
 * Payload for creating/updating a dental act
 */
export interface DentalActPayload {
    scope: DentalActScope;
    teeth: string[] | null;
    surfaces: string[] | null;
    act_catalog_id: number | null;
    custom_act_label: string | null;
    status: DentalActStatus;
    date_act: string;
    notes: string | null;
}

/**
 * Props for Odontogram component
 */
export interface OdontogramProps {
    selectedTeeth: string[];
    selectedSurfaces: Record<string, string[]>;
    onToothSelect: (tooth: string) => void;
    onSurfaceSelect: (tooth: string, surface: string) => void;
    disabled?: boolean;
    showSurfaces?: boolean;
    readOnly?: boolean;
}

/**
 * Props for individual Tooth component
 */
export interface ToothProps {
    number: string;
    isSelected: boolean;
    selectedSurfaces: string[];
    onSelect: () => void;
    onSurfaceSelect: (surface: string) => void;
    disabled?: boolean;
    showSurfaces?: boolean;
    position: 'upper' | 'lower';
}

/**
 * Props for DentalActModal component
 */
export interface DentalActModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    onSuccess: () => void;
    editAct?: DentalAct;
    readOnly?: boolean;
}

/**
 * Props for DentalActHistory component
 */
export interface DentalActHistoryProps {
    patientId: string;
    onAddClick: () => void;
    onViewDetail: (act: DentalAct) => void;
    refreshTrigger?: number;
}
