// Types barrel export
export * from './dental.types';
