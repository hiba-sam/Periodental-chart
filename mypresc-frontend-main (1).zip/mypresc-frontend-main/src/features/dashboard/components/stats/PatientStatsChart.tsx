'use client';

import React, { useState, useMemo, memo, useCallback, useEffect } from 'react';
import { ArrowTopRightOnSquareIcon, XMarkIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import { createPortal } from 'react-dom';
import {
    ChartConfig,
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
} from '@/components/ui/chart';
import { Bar, BarChart, XAxis, YAxis, LabelList } from 'recharts';
import { usePatients } from '@/contexts/PatientsContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';
import type { ChartPeriod, PatientChartVariant, PatientChartDataPoint } from '../../types';

// ==================== Sub-components ====================

interface LoadingSkeletonProps {
    message: string;
    color: string;
}

const LoadingSkeleton = memo(function LoadingSkeleton({ message, color }: LoadingSkeletonProps) {
    return (
        <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
            <div className={`animate-spin rounded-full h-12 w-12 border-b-2 border-${color}-600`}></div>
            <p className="text-sm text-gray-500">{message}</p>
        </div>
    );
});

interface ErrorStateProps {
    message: string;
    error: string | null;
    retryLabel: string;
    onRetry: () => void;
    color: string;
}

const ErrorState = memo(function ErrorState({ message, error, retryLabel, onRetry, color }: ErrorStateProps) {
    return (
        <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
            <ExclamationTriangleIcon className="w-12 h-12 text-red-500" />
            <p className="text-sm text-gray-700 font-medium">{message}</p>
            <p className="text-xs text-gray-500 text-center">{error}</p>
            <button
                onClick={onRetry}
                className={`px-4 py-2 bg-${color}-600 text-white text-sm rounded-lg hover:bg-${color}-700 transition-colors`}
            >
                {retryLabel}
            </button>
        </div>
    );
});

interface EmptyStateProps {
    message: string;
    color: string;
}

const EmptyState = memo(function EmptyState({ message, color }: EmptyStateProps) {
    return (
        <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
            <div className={`w-16 h-16 bg-${color}-100 rounded-full flex items-center justify-center`}>
                <svg className={`w-8 h-8 text-${color}-600`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
            </div>
            <p className="text-sm text-gray-500">{message}</p>
        </div>
    );
});

// ==================== Period Selector ====================

interface PeriodSelectorProps {
    selectedPeriod: ChartPeriod;
    onPeriodChange: (period: ChartPeriod) => void;
    isLoading: boolean;
    labels: { week: string; month: string; year: string };
    compact?: boolean;
}

const PeriodSelector = memo(function PeriodSelector({
    selectedPeriod,
    onPeriodChange,
    isLoading,
    labels,
    compact = false,
}: PeriodSelectorProps) {
    const baseClasses = compact
        ? 'px-2 py-1 text-xs font-medium rounded transition-all'
        : 'px-4 py-2 text-sm font-medium rounded-md transition-all';

    const containerClasses = compact
        ? 'flex bg-gray-100 dark:bg-gray-700 rounded-md p-0.5'
        : 'flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1 mb-6 w-fit';

    return (
        <div className={containerClasses}>
            {(['week', 'month', 'year'] as ChartPeriod[]).map((period) => (
                <button
                    key={period}
                    onClick={() => onPeriodChange(period)}
                    disabled={isLoading}
                    className={`${baseClasses} ${selectedPeriod === period
                        ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                        : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                        } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                    {labels[period]}
                </button>
            ))}
        </div>
    );
});

// ==================== Main Component ====================

interface PatientStatsChartProps {
    variant: PatientChartVariant;
}

function PatientStatsChartBase({ variant }: PatientStatsChartProps) {
    const { t } = useLanguage();
    const { theme } = useTheme();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedPeriod, setSelectedPeriod] = useState<ChartPeriod>('month');

    // Get stats from context based on variant
    const {
        newPatientStat,
        oldPatientStat,
        fetchPatientStatistics,
        statisticsLoading,
        statisticsError,
    } = usePatients();

    // Determine variant-specific config
    const isNew = variant === 'new';
    const color = 'blue'; // Unified to blue for visibility
    const fillColor = '#3b82f6'; // Solid blue color

    // Translations
    const translationKey = isNew ? 'charts.newPatientsChart' : 'charts.oldPatientsChart';

    // Chart config with memoization
    const chartConfig = useMemo(() => ({
        patients: {
            label: t(`${translationKey}.${isNew ? 'newPatients' : 'oldPatients'}`),
            color: fillColor,
        },
    } satisfies ChartConfig), [t, translationKey, isNew, fillColor]);

    // Get relevant statistics
    const stats = isNew ? newPatientStat : oldPatientStat;
    const isLoading = isNew ? statisticsLoading.new : statisticsLoading.old;
    const error = isNew ? statisticsError.new : statisticsError.old;
    const hasData = stats && stats.weeklyData && stats.monthlyData && stats.yearlyData;

    // Fetch data on mount if not already loaded
    useEffect(() => {
        if (!hasData && !isLoading && !error) {
            fetchPatientStatistics(variant);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [variant]);

    // Data selection with memoization
    const getData = useCallback((): PatientChartDataPoint[] => {
        if (!hasData) return [];
        switch (selectedPeriod) {
            case 'week': return stats.weeklyData;
            case 'month': return stats.monthlyData;
            case 'year': return stats.yearlyData;
            default: return stats.monthlyData;
        }
    }, [hasData, selectedPeriod, stats]);

    const chartData = useMemo(() => getData(), [getData]);

    // Title based on period
    const getTitle = useCallback(() => {
        switch (selectedPeriod) {
            case 'week': return t(`${translationKey}.weekTitle`);
            case 'month': return t(`${translationKey}.monthTitle`);
            case 'year': return t(`${translationKey}.yearTitle`);
            default: return t(`${translationKey}.title`);
        }
    }, [selectedPeriod, t, translationKey]);

    // Period name translation
    const getFullPeriodName = useCallback((period: string) => {
        if (selectedPeriod === 'week') {
            const dayMap: Record<string, string> = {
                'Lun': t('daysFull.monday'),
                'Mar': t('daysFull.tuesday'),
                'Mer': t('daysFull.wednesday'),
                'Jeu': t('daysFull.thursday'),
                'Ven': t('daysFull.friday'),
                'Sam': t('daysFull.saturday'),
                'Dim': t('daysFull.sunday'),
            };
            return dayMap[period] || period;
        } else if (selectedPeriod === 'month') {
            const monthMap: Record<string, string> = {
                'Jan': t('monthsFull.january'),
                'Fév': t('monthsFull.february'),
                'Mar': t('monthsFull.march'),
                'Avr': t('monthsFull.april'),
                'Mai': t('monthsFull.may'),
                'Jui': t('monthsFull.june'),
                'Juil': t('monthsFull.july'),
                'Août': t('monthsFull.august'),
                'Sep': t('monthsFull.september'),
                'Oct': t('monthsFull.october'),
                'Nov': t('monthsFull.november'),
                'Déc': t('monthsFull.december'),
            };
            return monthMap[period] || period;
        }
        return period;
    }, [selectedPeriod, t]);

    // Retry handler
    const handleRetry = useCallback(() => {
        fetchPatientStatistics(variant);
    }, [fetchPatientStatistics, variant]);

    // Period selector labels
    const periodLabels = useMemo(() => ({
        week: t(`${translationKey}.periodWeekShort`),
        month: t(`${translationKey}.periodMonthShort`),
        year: t(`${translationKey}.periodYearShort`),
    }), [t, translationKey]);

    const periodLabelsLong = useMemo(() => ({
        week: t(`${translationKey}.periodWeek`),
        month: t(`${translationKey}.periodMonth`),
        year: t(`${translationKey}.periodYear`),
    }), [t, translationKey]);

    const isMobile = useMemo(() => {
        return typeof window !== 'undefined' && window.innerWidth < 768;
    }, []);

    // Modal component
    const Modal = () => (
        <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
            onClick={() => setIsModalOpen(false)}
        >
            <div
                className="p-6 m-4 bg-white dark:bg-gray-800 rounded-lg shadow-xl"
                style={{ width: '80vw', height: '70vh', maxWidth: '1000px' }}
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex items-center justify-between mb-4">
                    <div>
                        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">{getTitle()}</h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            {t(`${translationKey}.detailedView`)}
                        </p>
                    </div>
                    <button
                        onClick={() => setIsModalOpen(false)}
                        className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                        <XMarkIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
                    </button>
                </div>

                <PeriodSelector
                    selectedPeriod={selectedPeriod}
                    onPeriodChange={setSelectedPeriod}
                    isLoading={isLoading}
                    labels={periodLabelsLong}
                />

                <div style={{ height: 'calc(100% - 140px)', width: '100%' }}>
                    <ChartContainer config={chartConfig} className="h-full w-full">
                        <BarChart data={chartData} width={100} height={100} margin={{ top: 30, right: 20, left: 20, bottom: 20 }}>
                            <XAxis
                                dataKey="period"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                            />
                            <YAxis
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                                width={80}
                            />
                            <ChartTooltip
                                content={
                                    <ChartTooltipContent
                                        formatter={(value) => [`${value}`, ` ${t(`${translationKey}.${isNew ? 'newPatients' : 'oldPatients'}`)}`]}
                                        labelFormatter={(label) => getFullPeriodName(String(label))}
                                        className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                                        labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                                    />
                                }
                            />
                            <Bar dataKey="patients" fill={fillColor} radius={[4, 4, 0, 0]}>
                                <LabelList
                                    dataKey="patients"
                                    position="top"
                                    style={{
                                        fontSize: '12px',
                                        fontWeight: 'bold',
                                        fill: theme === 'dark' ? '#e5e7eb' : '#374151',
                                    }}
                                    offset={8}
                                />
                            </Bar>
                        </BarChart>
                    </ChartContainer>
                </div>
            </div>
        </div>
    );

    return (
        <>
            {isModalOpen && typeof window !== 'undefined' && createPortal(<Modal />, document.body)}

            <div className="h-[400px] overflow-hidden flex flex-col">
                {/* ── Header: always visible, does NOT scroll ── */}
                <div className="flex items-center justify-between md:p-4 pb-2 shrink-0">
                    <div className="flex flex-1 md:flex-none items-center justify-between gap-3">
                        <h3 className="mb-0 text-sm font-semibold text-gray-800 dark:text-gray-100">
                            {t(`${translationKey}.title`)}
                        </h3>

                        {hasData && (
                            <PeriodSelector
                                selectedPeriod={selectedPeriod}
                                onPeriodChange={setSelectedPeriod}
                                isLoading={isLoading}
                                labels={periodLabels}
                                compact
                            />
                        )}
                    </div>

                    {hasData && !isLoading && (
                        <ArrowTopRightOnSquareIcon
                            className="w-4 h-4 text-gray-400 cursor-pointer hover:text-gray-600 dark:hover:text-gray-300 hidden md:block"
                            onClick={() => setIsModalOpen(true)}
                        />
                    )}
                </div>

                {/* ── Chart canvas: scrolls horizontally, fills remaining height ── */}
                <div className="overflow-x-auto flex-1" dir="ltr">
                    <div className="min-w-[900px] h-full" style={{ padding: isMobile ? '0' : '0 16px 16px' }}>
                        {isLoading ? (
                            <LoadingSkeleton message={t(`${translationKey}.loading`)} color={color} />
                        ) : error ? (
                            <ErrorState
                                message={t(`${translationKey}.loadingError`)}
                                error={error}
                                retryLabel={t(`${translationKey}.retry`)}
                                onRetry={handleRetry}
                                color={color}
                            />
                        ) : !hasData || chartData.length === 0 ? (
                            <EmptyState message={t(`${translationKey}.noData`)} color={color} />
                        ) : (
                            <ChartContainer config={chartConfig} className="h-full w-full">
                                <BarChart
                                    data={chartData}
                                    margin={{ top: 30, right: 45, left: 0, bottom: 20 }}
                                >
                                    <XAxis
                                        dataKey="period"
                                        tickLine={false}
                                        axisLine={false}
                                        tickMargin={8}
                                        tick={{ fontSize: 11, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                                        interval={0}
                                    />
                                    <YAxis
                                        tickLine={false}
                                        axisLine={false}
                                        tickMargin={8}
                                        tick={{ fontSize: 11, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                                        width={65}
                                    />
                                    <ChartTooltip
                                        content={
                                            <ChartTooltipContent
                                                formatter={(value) => [`${value}`, ` ${t(`${translationKey}.${isNew ? 'newPatients' : 'oldPatients'}`)}`]}
                                                labelFormatter={(label) => getFullPeriodName(String(label))}
                                                className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                                                labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                                            />
                                        }
                                    />
                                    <Bar dataKey="patients" fill={fillColor} radius={[2, 2, 0, 0]}>
                                        <LabelList
                                            dataKey="patients"
                                            position="top"
                                            style={{
                                                fontSize: '10px',
                                                fontWeight: 'bold',
                                                fill: theme === 'dark' ? '#e5e7eb' : '#374151',
                                            }}
                                            offset={8}
                                        />
                                    </Bar>
                                </BarChart>
                            </ChartContainer>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}

// Memoized export to prevent unnecessary re-renders
export const PatientStatsChart = memo(PatientStatsChartBase);
