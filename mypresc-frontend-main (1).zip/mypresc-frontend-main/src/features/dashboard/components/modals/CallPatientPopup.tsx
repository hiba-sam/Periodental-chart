'use client';

import React, { memo } from 'react';
import { UsersIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface CallPatientPopupProps {
    isOpen: boolean;
    patientName: string;
    isConfirming: boolean;
    onCancel: () => void;
    onConfirm: () => void;
}

function CallPatientPopupBase({
    isOpen,
    patientName,
    isConfirming,
    onCancel,
    onConfirm,
}: CallPatientPopupProps) {
    const { t } = useLanguage();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50">
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 text-center">
                <div className="mb-4">
                    <div className="w-16 h-16 mx-auto bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                        <UsersIcon className="w-8 h-8 text-green-600 dark:text-green-400" />
                    </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-2">
                    {t('dashboard.callPatient') || 'Appeler le patient'}
                </h2>
                <p className="text-3xl font-extrabold text-green-600 dark:text-green-400 mb-6">
                    {patientName}
                </p>
                <div className="flex gap-3 justify-center">
                    <button
                        onClick={onCancel}
                        className="px-6 py-3 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold rounded-full hover:bg-gray-300 dark:hover:bg-gray-600 transition-all"
                    >
                        {t('common.cancel') || 'Annuler'}
                    </button>
                    <button
                        disabled={isConfirming}
                        onClick={onConfirm}
                        className="px-6 py-3 bg-green-600 text-white font-bold rounded-full hover:bg-green-700 transition-all disabled:opacity-50"
                    >
                        {isConfirming ? '...' : (t('common.confirm') || 'Confirmer')}
                    </button>
                </div>
            </div>
        </div>
    );
}

export const CallPatientPopup = memo(CallPatientPopupBase);
