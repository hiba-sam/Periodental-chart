'use client';

import React, { memo, useMemo, useState } from 'react';
import dynamic from 'next/dynamic';
import { useLanguage } from '@/contexts/LanguageContext';
import { PatientStatsChart } from '../stats/PatientStatsChart';

const ChartSkeleton = () => (
    <div className="animate-pulse min-h-[320px]">
        <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>
        <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
    </div>
);

const PaymentChart = dynamic(
    () => import('@/components/dashboard/PaymentChart'),
    { loading: () => <ChartSkeleton />, ssr: false }
);

type ChartTab = 'paiements' | 'nouveaux-patients' | 'anciens-patients';

function DoctorChartsSectionBase() {
    const { t } = useLanguage();
    const [activeTab, setActiveTab] = useState<ChartTab>('paiements');

    const tabs: { key: ChartTab; label: string }[] = [
        { key: 'paiements', label: t('dashboard.payments') },
        { key: 'nouveaux-patients', label: t('dashboard.newPatients') },
        { key: 'anciens-patients', label: t('dashboard.oldPatients') },
    ];

    const isMobile = useMemo(() => {
        return typeof window !== 'undefined' && window.innerWidth < 768;
    }, []);

    return (
        <div className="w-full rounded-2xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 shadow-sm mb-4">
            <div className="flex flex-col p-4 sm:p-6">
                {/* Tabs */}
                <div className="mb-6 border-b border-gray-200 dark:border-gray-700 ">
                    <div className="flex w-full space-x-2">
                        {tabs.map(({ key, label }) => (
                            <button
                                key={key}
                                className={`flex-none whitespace-nowrap py-2 px-2 sm:py-3 md:px-4 ${isMobile ? 'text-xs' : 'text-md'} font-medium transition-all duration-300 ${activeTab === key
                                        ? 'border-b-4 border-blue-600 text-blue-700 dark:text-blue-400 font-bold'
                                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
                                    }`}
                                onClick={() => setActiveTab(key)}
                            >
                                {label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Chart (CLIPPED ONLY HERE) */}
                <div className="w-full min-w-0 overflow-hidden">
                    {activeTab === 'paiements' && <PaymentChart />}
                    {activeTab === 'nouveaux-patients' && (
                        <PatientStatsChart variant="new" />
                    )}
                    {activeTab === 'anciens-patients' && (
                        <PatientStatsChart variant="old" />
                    )}
                </div>

            </div>
        </div>
    );
}

export const DoctorChartsSection = memo(DoctorChartsSectionBase);