// Dashboard API - All dashboard-related API calls
// Self-contained API layer for the dashboard feature

import axios from 'axios';
import type { DashboardStatsResponse, DashboardStats } from '../types';
import { Appointment } from '@/contexts/AppointmentContext';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// Create axios instance for dashboard API
const dashboardApi = axios.create({
    baseURL: `${API_URL}/dashboard`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

// ==================== Dashboard Stats ====================

/**
 * Fetch dashboard stats and today's appointments
 * Combines multiple stats into a single optimized call
 */
export async function fetchDashboardStats(): Promise<{
    stats: DashboardStats;
    todayAppointments: Appointment[];
}> {
    const response = await dashboardApi.get<DashboardStatsResponse>('/stats');

    if (response.data?.success) {
        const { stats, todayAppointments } = response.data.data;

        return {
            stats: {
                totalAppointments: stats.totalAppointmentsToday,
                completedAppointments: stats.completedAppointments,
                waitingPatients: stats.waitingPatients,
            },
            todayAppointments: todayAppointments || [],
        };
    }

    throw new Error('Failed to fetch dashboard stats');
}
