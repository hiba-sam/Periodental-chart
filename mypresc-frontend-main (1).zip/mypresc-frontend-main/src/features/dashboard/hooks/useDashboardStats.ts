// useDashboardStats Hook - Fetches dashboard stats with React Query
// Self-contained hook for dashboard page

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { fetchDashboardStats } from '../api';

// Query keys for cache management
export const dashboardKeys = {
    all: ['dashboard'] as const,
    stats: () => ['dashboard', 'stats'] as const,
};

/**
 * Hook to fetch dashboard stats
 * Uses React Query for caching and automatic refetching
 */
export function useDashboardStats(userId?: string) {
    const queryClient = useQueryClient();

    const query = useQuery({
        queryKey: dashboardKeys.stats(),
        queryFn: fetchDashboardStats,
        staleTime: 5 * 60 * 1000, // 5 minutes
        enabled: !!userId,
        refetchOnWindowFocus: true,
    });

    // Note: We removed the useEffect that synced context data to React Query cache
    // because it caused infinite loops. The initial API call provides the stats,
    // and socket events should trigger refetches via invalidateQueries instead.

    // Refetch function
    const refetch = () => {
        queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    return {
        // Data
        stats: query.data?.stats ?? null,
        todayAppointments: query.data?.todayAppointments ?? [],

        // Loading state
        isLoading: query.isLoading,

        // Error state
        error: query.error,

        // Utilities
        refetch,
    };
}

/**
 * Hook to get computed stats from dashboard data
 */
export function useQuickStats(userId?: string) {
    const { stats, isLoading, error } = useDashboardStats(userId);

    return {
        totalAppointments: stats?.totalAppointments ?? 0,
        completedAppointments: stats?.completedAppointments ?? 0,
        waitingPatients: stats?.waitingPatients ?? 0,
        isLoading,
        error,
    };
}
