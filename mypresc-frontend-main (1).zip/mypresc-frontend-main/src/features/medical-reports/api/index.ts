// API barrel export
export * from './medical-reports.api';
