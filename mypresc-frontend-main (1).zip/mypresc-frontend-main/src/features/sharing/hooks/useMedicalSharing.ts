// useMedicalSharing Hook - Manages medical record sharing
// Self-contained hook for sharing functionality

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';
import axios from 'axios';
import type { MedicalShare, CreateShareRequest } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Query keys
export const sharingKeys = {
    patientShares: (patientId: string) => ['shares', 'patient', patientId] as const,
    receivedShares: () => ['shares', 'received'] as const,
    sentShares: () => ['shares', 'sent'] as const,
};

// ==================== API FUNCTIONS ====================

async function fetchPatientShares(patientId: string): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/patient/${patientId}`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

async function fetchReceivedShares(): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/received`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

async function fetchSentShares(): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/sent`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

async function createShareApi(payload: CreateShareRequest): Promise<MedicalShare[]> {
    const response = await axios.post(`${API_URL}/medical-shares`, payload, { withCredentials: true });
    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to create share');
}

async function revokeShareApi(shareId: number): Promise<boolean> {
    const response = await axios.put(`${API_URL}/medical-shares/${shareId}/revoke`, {}, { withCredentials: true });
    return response.data.success;
}

// ==================== INDIVIDUAL HOOKS ====================

/**
 * Hook to fetch all shares for a patient
 */
export function usePatientShares(patientId: string) {
    return useQuery({
        queryKey: sharingKeys.patientShares(patientId),
        queryFn: () => fetchPatientShares(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId,
    });
}

/**
 * Hook to fetch shares received by current doctor
 */
export function useReceivedShares() {
    return useQuery({
        queryKey: sharingKeys.receivedShares(),
        queryFn: fetchReceivedShares,
        staleTime: 5 * 60 * 1000,
    });
}

/**
 * Hook to fetch shares sent by current doctor
 */
export function useSentShares() {
    return useQuery({
        queryKey: sharingKeys.sentShares(),
        queryFn: fetchSentShares,
        staleTime: 5 * 60 * 1000,
    });
}

// ==================== COMBINED HOOK ====================

interface UseMedicalSharingProps {
    patientId: string;
}

interface UseMedicalSharingReturn {
    // Data
    patientShares: MedicalShare[];
    activeShares: MedicalShare[];
    receivedShares: MedicalShare[];
    receivedSharesForPatient: MedicalShare[];

    // Loading
    isLoadingPatientShares: boolean;
    isLoadingReceivedShares: boolean;

    // Computed
    sharedDoctorIds: number[];
    isSharedWithMe: boolean;

    // Mutations
    createShare: (payload: CreateShareRequest) => Promise<MedicalShare[]>;
    revokeShare: (shareId: number) => Promise<boolean>;

    // Mutation states
    isCreatingShare: boolean;
    isRevokingShare: boolean;

    // Refetch
    refetchPatientShares: () => void;
    refetchReceivedShares: () => void;
}

/**
 * Combined hook for medical sharing management
 * Handles patient shares, received shares, and CRUD operations
 */
export function useMedicalSharing({ patientId }: UseMedicalSharingProps): UseMedicalSharingReturn {
    const queryClient = useQueryClient();

    // Queries
    const patientSharesQuery = usePatientShares(patientId);
    const receivedSharesQuery = useReceivedShares();

    // Create share mutation
    const createShareMutation = useMutation({
        mutationFn: createShareApi,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: sharingKeys.patientShares(patientId) });
            queryClient.invalidateQueries({ queryKey: sharingKeys.sentShares() });
        },
    });

    // Revoke share mutation
    const revokeShareMutation = useMutation({
        mutationFn: revokeShareApi,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: sharingKeys.patientShares(patientId) });
            queryClient.invalidateQueries({ queryKey: sharingKeys.sentShares() });
            queryClient.invalidateQueries({ queryKey: sharingKeys.receivedShares() });
        },
    });

    // Handlers
    const handleCreateShare = useCallback(async (payload: CreateShareRequest) => {
        return await createShareMutation.mutateAsync(payload);
    }, [createShareMutation]);

    const handleRevokeShare = useCallback(async (shareId: number) => {
        return await revokeShareMutation.mutateAsync(shareId);
    }, [revokeShareMutation]);

    // Refetch functions
    const refetchPatientShares = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: sharingKeys.patientShares(patientId) });
    }, [queryClient, patientId]);

    const refetchReceivedShares = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: sharingKeys.receivedShares() });
    }, [queryClient]);

    // Computed values
    const patientShares = patientSharesQuery.data ?? [];
    const activeShares = patientShares.filter(s => s.status === 'active');
    const receivedShares = receivedSharesQuery.data ?? [];

    // Filter received shares for this specific patient
    const receivedSharesForPatient = receivedShares.filter(
        s => String(s.patient_id) === String(patientId) && s.status === 'active'
    );

    // Get list of doctor IDs who have shared with current doctor for this patient
    const sharedDoctorIds = receivedSharesForPatient
        .filter(s => s.share_prescriptions)
        .map(s => Number(s.shared_by_doctor_id));

    // Check if this patient has been shared with the current doctor
    const isSharedWithMe = receivedSharesForPatient.length > 0;

    return {
        // Data
        patientShares,
        activeShares,
        receivedShares,
        receivedSharesForPatient,

        // Loading
        isLoadingPatientShares: patientSharesQuery.isLoading,
        isLoadingReceivedShares: receivedSharesQuery.isLoading,

        // Computed
        sharedDoctorIds,
        isSharedWithMe,

        // Mutations
        createShare: handleCreateShare,
        revokeShare: handleRevokeShare,

        // Mutation states
        isCreatingShare: createShareMutation.isPending,
        isRevokingShare: revokeShareMutation.isPending,

        // Refetch
        refetchPatientShares,
        refetchReceivedShares,
    };
}
