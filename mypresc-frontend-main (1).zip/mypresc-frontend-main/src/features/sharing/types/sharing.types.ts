// Medical Sharing Feature - Types
// Type definitions for medical sharing functionality

/**
 * Status of a medical share
 */
export type ShareStatus = 'active' | 'revoked' | 'expired';

/**
 * Medical share record
 */
export interface MedicalShare {
    id: number;
    patient_id: string;
    shared_by_doctor_id: number;
    shared_with_doctor_id: number;
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date: string | null;
    expires_at: string | null;
    status: ShareStatus;
    reason?: string;
    created_at: string;
    updated_at: string;
    shared_by_doctor?: {
        id: number;
        name: string;
        family_name: string;
    };
    shared_with_doctor?: {
        id: number;
        name: string;
        family_name: string;
    };
}

/**
 * Request payload for creating a share
 */
export interface CreateShareRequest {
    patient_id: string;
    shared_with_doctor_ids: number[];
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date?: string | null;
    expires_at?: string;
    reason?: string;
}

/**
 * Filters for fetching shares
 */
export interface ShareFilters {
    patientId?: string;
    status?: ShareStatus;
}
