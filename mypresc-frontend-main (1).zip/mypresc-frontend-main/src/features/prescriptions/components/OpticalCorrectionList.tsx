import React, { useEffect, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchOpticalCorrectionsByPatient, generateOpticalCorrectionPdf } from '../api/opticalCorrection.api';
import type { OpticalCorrection } from '../types/opticalCorrection.types';
import { Eye, Printer, Calendar, RefreshCcw } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { ListSkeleton } from '@/components/feedback';

interface OpticalCorrectionListProps {
    patientId: string;
    refreshTrigger: number;
}

export function OpticalCorrectionList({ patientId, refreshTrigger }: OpticalCorrectionListProps) {
    const { t } = useLanguage();
    const { toast } = useToast();
    const [corrections, setCorrections] = useState<OpticalCorrection[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isDownloading, setIsDownloading] = useState<number | null>(null);

    useEffect(() => {
        loadData();
    }, [patientId, refreshTrigger]);

    const loadData = async () => {
        try {
            setIsLoading(true);
            const data = await fetchOpticalCorrectionsByPatient(patientId);
            setCorrections(data);
        } catch (error) {
            console.error('Failed to load optical corrections:', error);
            toast({
                title: 'Erreur',
                description: 'Erreur lors du chargement des ordonnances optiques',
                variant: 'destructive',
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownload = async (id: number) => {
        try {
            setIsDownloading(id);
            await generateOpticalCorrectionPdf(id);
            toast({
                title: 'Succès',
                description: 'Téléchargement démarré',
                variant: 'default',
            });
        } catch (error) {
            console.error('Error downloading pdf:', error);
            toast({
                title: 'Erreur',
                description: 'Erreur lors du téléchargement',
                variant: 'destructive',
            });
        } finally {
            setIsDownloading(null);
        }
    };

    const formatDate = (dateStr: string | Date) => {
        return new Date(dateStr).toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    };

    if (isLoading) {
        return (
            <div className="py-2">
                <ListSkeleton count={2} />
            </div>
        );
    }

    if (corrections.length === 0) {
        return (
            <div className="text-center py-8 bg-gray-50 dark:bg-gray-900/50 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                <Eye className="w-10 h-10 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                <h3 className="text-sm font-medium text-gray-900 dark:text-gray-300">Aucune ordonnance optique</h3>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Ce patient n'a pas encore de correction enregistrée.</p>
            </div>
        );
    }

    return (
        <div className="space-y-4 py-4 overflow-y-auto pr-2 custom-scrollbar"
        style={{ maxHeight: '540px' }}
        >
            {corrections.map((correction) => (
                <div key={correction.id} className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm flex flex-col hover:shadow-md transition-all duration-200">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center w-full gap-4">
                        <div className="flex items-start">
                            <div className="p-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-lg mr-4 border border-blue-100 dark:border-blue-800/50 shadow-sm">
                                <Eye className="w-5 h-5" />
                            </div>
                            <div>
                                <h4 className="text-sm font-semibold text-gray-900 dark:text-white flex items-center">
                                    Ordonnance Optique
                                    {correction.remarks && (
                                        <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800/50">
                                            Avec remarques
                                        </span>
                                    )}
                                </h4>
                                <div className="flex items-center gap-2 mt-1 text-xs text-gray-500 dark:text-gray-400">
                                    <Calendar className="w-3.5 h-3.5" />
                                    <div>{formatDate(correction.created_at)}</div>
                                </div>
                            </div>
                        </div>

                        <button
                            onClick={() => handleDownload(correction.id)}
                            disabled={isDownloading === correction.id}
                            className="flex items-center w-full sm:w-auto justify-center px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 text-sm font-medium text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all shadow-sm disabled:opacity-50"
                        >
                            {isDownloading === correction.id ? (
                                <RefreshCcw className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                                <Printer className="w-4 h-4 mr-2" />
                            )}
                            Imprimer / PDF
                        </button>
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-700/60 overflow-x-auto">
                        <div className="w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
                            <table className="w-full text-sm text-left">
                                <thead className="text-xs text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-800/80 uppercase border-b border-gray-200 dark:border-gray-700">
                                    <tr>
                                        <th scope="col" className="px-4 py-3 font-semibold">Œil</th>
                                        <th scope="col" className="px-4 py-3 font-semibold text-center">Sphère (SPH)</th>
                                        <th scope="col" className="px-4 py-3 font-semibold text-center">Cylindre (CYL)</th>
                                        <th scope="col" className="px-4 py-3 font-semibold text-center">Axe</th>
                                        <th scope="col" className="px-4 py-3 font-semibold text-center">Addition (ADD)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                                        <td className="px-4 py-3.5 font-medium text-gray-900 dark:text-gray-100 flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full bg-blue-500 shadow-sm"></div>
                                            Droit (OD)
                                        </td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.od_sph || '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.od_cyl || '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.od_axis ? `${correction.od_axis}°` : '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.od_add || '-'}</td>
                                    </tr>
                                    <tr className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                                        <td className="px-4 py-3.5 font-medium text-gray-900 dark:text-gray-100 flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm"></div>
                                            Gauche (OG)
                                        </td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.os_sph || '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.os_cyl || '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.os_axis ? `${correction.os_axis}°` : '-'}</td>
                                        <td className="px-4 py-3.5 text-center text-gray-700 dark:text-gray-300 font-medium">{correction.os_add || '-'}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
}
