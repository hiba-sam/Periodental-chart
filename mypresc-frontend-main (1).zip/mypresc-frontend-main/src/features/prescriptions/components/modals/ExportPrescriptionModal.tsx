'use client';

import { useState, useMemo } from 'react';
import { XMarkIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import type { Patient } from '@/features/patients/types';
import type { ExportPrescriptionPayload } from '../../types';

interface ExportPrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: (data: ExportPrescriptionPayload) => void;
  isLoading?: boolean;
  patients: Patient[];
}

export function ExportPrescriptionModal({
  isOpen,
  onClose,
  onExport,
  isLoading = false,
  patients
}: ExportPrescriptionModalProps) {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatients, setSelectedPatients] = useState<Set<string>>(new Set());

  // Filter patients based on search query
  const filteredPatients = useMemo(() => {
    if (!searchQuery.trim()) return patients;

    const query = searchQuery.toLowerCase();
    return patients.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.family_name.toLowerCase().includes(query) ||
        p.telephone.includes(query) ||
        (p.nin && p.nin.includes(query))
    );
  }, [searchQuery, patients]);

  // Check if all visible patients are selected
  const isAllSelected = useMemo(() => {
    if (filteredPatients.length === 0) return false;
    return filteredPatients.every((p) => selectedPatients.has(p.id));
  }, [filteredPatients, selectedPatients]);

  // Toggle individual patient selection
  const togglePatient = (patientId: string) => {
    setSelectedPatients((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(patientId)) {
        newSet.delete(patientId);
      } else {
        newSet.add(patientId);
      }
      return newSet;
    });
  };

  // Toggle all patients selection
  const toggleAllPatients = () => {
    if (isAllSelected) {
      // Deselect all visible patients
      setSelectedPatients((prev) => {
        const newSet = new Set(prev);
        filteredPatients.forEach((p) => newSet.delete(p.id));
        return newSet;
      });
    } else {
      // Select all visible patients
      setSelectedPatients((prev) => {
        const newSet = new Set(prev);
        filteredPatients.forEach((p) => newSet.add(p.id));
        return newSet;
      });
    }
  };

  // Handle export
  const handleExport = () => {
    if (selectedPatients.size === patients.length) {
      // All patients selected
      onExport({ is_all: true });
    } else if (selectedPatients.size > 0) {
      // Specific patients selected - convert string IDs to numbers
      onExport({ patients: Array.from(selectedPatients) });
    }
  };

  // Reset state when modal closes
  const handleClose = () => {
    setSearchQuery('');
    setSelectedPatients(new Set());
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl mx-4 max-h-[80vh] flex flex-col">
        {/* Loading Overlay */}
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg z-10 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="h-8 w-8 bg-white dark:bg-gray-800 rounded-full"></div>
                </div>
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                  {t('settings.exportModal.exporting')}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {t('settings.exportModal.pleaseWait')}
                </p>
              </div>
            </div>
          </div>
        )}
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
              {t('settings.exportModal.title')}
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {t('settings.exportModal.subtitle')}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            disabled={isLoading}
          >
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder={t('settings.exportModal.searchPlaceholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
              disabled={isLoading}
            />
          </div>

          {/* Select All Checkbox */}
          <div className="flex items-center mt-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
            <input
              type="checkbox"
              id="select-all"
              checked={isAllSelected}
              onChange={toggleAllPatients}
              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              disabled={isLoading}
            />
            <label
              htmlFor="select-all"
              className="mx-3 text-sm font-medium text-gray-900 dark:text-gray-100 cursor-pointer"
            >
              {t('settings.exportModal.selectAll')} ({filteredPatients.length})
            </label>
            {selectedPatients.size > 0 && (
              <span className="mx-auto text-sm text-blue-600 dark:text-blue-400 font-medium">
                {selectedPatients.size} {t('settings.exportModal.selected')}
              </span>
            )}
          </div>
        </div>

        {/* Patient List */}
        <div className="flex-1 overflow-y-auto p-6">
          {filteredPatients.length === 0 ?
            <div className="absolute inset-0 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-lg z-10 flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-600"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-8 w-8 bg-white dark:bg-gray-800 rounded-full"></div>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    {t('settings.exportModal.pleaseWait')}
                  </p>
                </div>
              </div>
            </div>
            : (filteredPatients.length === 0 && patients.length === 0) ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                {t('settings.exportModal.noPatientFound')}
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {filteredPatients.map((patient) => (
                  <label
                    key={patient.id}
                    className="flex items-start p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors"
                  >
                    <input
                      type="checkbox"
                      checked={selectedPatients.has(patient.id)}
                      onChange={() => togglePatient(patient.id)}
                      className="mt-1 w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      disabled={isLoading}
                    />
                    <div className="mx-3 flex-1">
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-gray-100">
                          {patient.name} {patient.family_name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {patient.telephone}
                        </div>
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {patient.genre?.toUpperCase()} · {patient.age} {t('settings.exportModal.years')} · NIN:{' '}
                        {patient.nin || t('settings.exportModal.notProvided')}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            {selectedPatients.size === 0
              ? t('settings.exportModal.noPatientSelected')
              : selectedPatients.size === patients.length
                ? t('settings.exportModal.allPatientsSelected')
                : `${selectedPatients.size} ${selectedPatients.size > 1 ? t('settings.exportModal.patientsSelected') : t('settings.exportModal.patientSelected')}`}
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleClose}
              disabled={isLoading}
              className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {t('settings.exportModal.cancel')}
            </button>
            <button
              onClick={handleExport}
              disabled={selectedPatients.size === 0 || isLoading}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                  <span>{t('settings.exportModal.exporting')}</span>
                </>
              ) : (
                <span>{t('settings.exportModal.exportCSV')}</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ExportPrescriptionModal;