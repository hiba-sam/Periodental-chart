'use client';

import { useState, useEffect } from 'react';
import { XMarkIcon, DocumentTextIcon, PrinterIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePrescription } from '@/contexts/PrescriptionContext';
import type { PrescriptionPreviewModalProps } from '../../types';
import { safeStorage } from '@/utils/safeStorage';

export function PrescriptionPreviewModal({
  isOpen,
  onClose,
  prescription,
  patientName,
  patientFamilyName,
}: PrescriptionPreviewModalProps) {
  const { t } = useLanguage();
  const { generatePrescriptionPdf } = usePrescription();
  const [hasPrinted, setHasPrinted] = useState(false);

  // Vérifier si la prescription est d'aujourd'hui
  const isToday = (date: string | Date): boolean => {
    const prescriptionDate = new Date(date);
    const today = new Date();
    return (
      prescriptionDate.getDate() === today.getDate() &&
      prescriptionDate.getMonth() === today.getMonth() &&
      prescriptionDate.getFullYear() === today.getFullYear()
    );
  };

  // Vérifier si déjà imprimée (localStorage)
  useEffect(() => {
    if (prescription?.id) {
      const printedKey = `prescription_printed_${prescription.id}`;
      const printedData = safeStorage.getItem(printedKey);
      if (printedData) {
        const { date } = JSON.parse(printedData);
        // Vérifier si imprimée aujourd'hui
        if (isToday(date)) {
          setHasPrinted(true);
        } else {
          // Nettoyer les anciennes entrées
          safeStorage.removeItem(printedKey);
          setHasPrinted(false);
        }
      } else {
        setHasPrinted(false);
      }
    }
  }, [prescription?.id]);

  if (!isOpen || !prescription) return null;

  const prescriptionIsToday = isToday(prescription.created_at);
  const canPrint = prescriptionIsToday && !hasPrinted;

  const formattedDate = prescription.created_at
    ? new Date(prescription.created_at).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    })
    : '';

  const handlePrint = async () => {
    if (!canPrint) return;

    await generatePrescriptionPdf(prescription.id);

    // Marquer comme imprimée
    const printedKey = `prescription_printed_${prescription.id}`;
    safeStorage.setItem(printedKey, JSON.stringify({ date: new Date().toISOString() }));
    setHasPrinted(true);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[85vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-500 to-blue-600">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-full">
              <DocumentTextIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">
                {t('prescriptions.preview.title') || 'Ordonnance'}
              </h2>
              <p className="text-sm text-white/80">
                {patientName} {patientFamilyName} • {formattedDate}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <XMarkIcon className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Doctor info */}
          {prescription.doctor && (
            <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {t('prescriptions.preview.prescribedBy') || 'Prescrit par'}:
                <span className="font-medium text-gray-900 dark:text-white ml-1">
                  Dr. {prescription.doctor.name} {prescription.doctor.family_name}
                </span>
              </p>
            </div>
          )}

          {/* Medications */}
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wide">
              {t('prescriptions.preview.medications') || 'Médicaments'}
            </h3>

            {prescription.medications && prescription.medications.length > 0 ? (
              <div className="space-y-3">
                {prescription.medications.map((med, index) => (
                  <div
                    key={med.id || index}
                    className="p-4 border border-gray-200 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700/30"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">
                          {med.medication?.nom_de_marque || med.nom_de_marque}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {med.medication?.denomination_commune_internationale || med.denomination_commune_internationale}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
                            {med.dosage || med.med_dosage}
                          </span>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
                            Qté: {med.quantity}
                          </span>
                        </div>
                        {med.note && (
                          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 italic">
                            {med.note}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                {t('prescriptions.preview.noMedications') || 'Aucun médicament'}
              </p>
            )}
          </div>

          {/* Remarks */}
          {prescription.remarks && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wide mb-2">
                {t('prescriptions.preview.remarks') || 'Remarques'}
              </h3>
              <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  {prescription.remarks}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
          >
            {t('common.close') || 'Fermer'}
          </button>

          {/* Bouton imprimer : visible seulement si prescription d'aujourd'hui et pas encore imprimée */}
          {prescriptionIsToday && (
            <button
              onClick={handlePrint}
              disabled={hasPrinted}
              className={`inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${hasPrinted
                ? 'bg-gray-400 text-gray-200 cursor-not-allowed'
                : 'text-white bg-blue-600 hover:bg-blue-700'
                }`}
            >
              <PrinterIcon className="w-4 h-4" />
              {hasPrinted
                ? (t('prescriptions.preview.alreadyPrinted') || 'Déjà imprimée')
                : (t('prescriptions.preview.print') || 'Imprimer')
              }
            </button>
          )}

          {/* Message si prescription ancienne */}
          {!prescriptionIsToday && (
            <span className="text-sm text-gray-500 dark:text-gray-400 italic">
              {t('prescriptions.preview.cannotPrintOld') || 'Impression non disponible pour les anciennes ordonnances'}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

export default PrescriptionPreviewModal;
