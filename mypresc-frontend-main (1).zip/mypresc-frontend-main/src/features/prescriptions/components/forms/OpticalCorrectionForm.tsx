import React, { useState, useEffect } from 'react';
import type { CreateOpticalCorrectionPayload, OpticalCorrection } from '../../types/opticalCorrection.types';
import { useLanguage } from '@/contexts/LanguageContext';
import { fetchOpticalCorrectionsByPatient } from '../../api/opticalCorrection.api';
import { History, Minus } from 'lucide-react';

const fieldOrder = [
    'od_sph', 'od_cyl', 'od_axis', 'od_add', 'od_pd',
    'os_sph', 'os_cyl', 'os_axis', 'os_add', 'os_pd',
    'remarks'
];

interface EyeRowProps {
    title: string;
    prefix: 'od' | 'os';
    formData: any;
    handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    handleKeyDown: (e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    handleToggleSign: (fieldName: string) => void;
}

const EyeRow = ({ title, prefix, formData, handleChange, handleKeyDown, handleToggleSign }: EyeRowProps) => (
    <div className="mb-6">
        <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">{title}</h4>
        <div className="bg-gray-50 dark:bg-gray-900/50 p-4 rounded-xl border border-gray-200 dark:border-gray-700">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">SPH</label>
                    <div className="relative">
                        <input
                            type="text"
                            name={`${prefix}_sph`}
                            value={formData[`${prefix}_sph`] || ''}
                            onChange={handleChange}
                            onKeyDown={handleKeyDown}
                            placeholder="-1.25"
                            className="w-full px-2 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                        />
                        <button
                            type="button"
                            onClick={() => handleToggleSign(`${prefix}_sph`)}
                            className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center justify-center w-7 h-7 bg-gray-100 dark:bg-gray-600 text-gray-600 dark:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-gray-500 transition-colors border border-gray-200 dark:border-gray-500 shadow-sm"
                            title="Inverser le signe (+/-)"
                            tabIndex={-1}
                        >
                            <Minus className="w-4 h-4" />
                        </button>
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">CYL</label>
                    <div className="relative">
                        <input
                            type="text"
                            name={`${prefix}_cyl`}
                            value={formData[`${prefix}_cyl`] || ''}
                            onChange={handleChange}
                            onKeyDown={handleKeyDown}
                            placeholder="-0.50"
                            className="w-full px-2 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                        />
                        <button
                            type="button"
                            onClick={() => handleToggleSign(`${prefix}_cyl`)}
                            className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center justify-center w-7 h-7 bg-gray-100 dark:bg-gray-600 text-gray-600 dark:text-gray-300 rounded hover:bg-gray-200 dark:hover:bg-gray-500 transition-colors border border-gray-200 dark:border-gray-500 shadow-sm"
                            title="Inverser le signe (+/-)"
                            tabIndex={-1}
                        >
                            <Minus className="w-4 h-4" />
                        </button>
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">AXE (°)</label>
                    <input
                        type="text"
                        name={`${prefix}_axis`}
                        value={formData[`${prefix}_axis`] || ''}
                        onChange={handleChange}
                        onKeyDown={handleKeyDown}
                        placeholder="90"
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                    />
                </div>
                <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">ADD</label>
                    <input
                        type="text"
                        name={`${prefix}_add`}
                        value={formData[`${prefix}_add`] || ''}
                        onChange={handleChange}
                        onKeyDown={handleKeyDown}
                        placeholder="+1.50"
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                    />
                </div>
                <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">PD (mm)</label>
                    <input
                        type="text"
                        name={`${prefix}_pd`}
                        value={formData[`${prefix}_pd`] || ''}
                        onChange={handleChange}
                        onKeyDown={handleKeyDown}
                        placeholder="31"
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                    />
                </div>
            </div>
        </div>
    </div>
);

interface OpticalCorrectionFormProps {
    onSubmit: (data: CreateOpticalCorrectionPayload) => void;
    onCancel: () => void;
    patientId: string;
    isSubmitting: boolean;
}

export function OpticalCorrectionForm({ onSubmit, onCancel, patientId, isSubmitting }: OpticalCorrectionFormProps) {
    const { t } = useLanguage();

    const [formData, setFormData] = useState<Omit<CreateOpticalCorrectionPayload, 'patient_id'>>({
        od_sph: '', od_cyl: '', od_axis: '', od_add: '', od_pd: '',
        os_sph: '', os_cyl: '', os_axis: '', os_add: '', os_pd: '',
        remarks: ''
    });

    const [previousCorrection, setPreviousCorrection] = useState<OpticalCorrection | null>(null);

    useEffect(() => {
        const loadPreviousCorrection = async () => {
            try {
                const data = await fetchOpticalCorrectionsByPatient(patientId, { limit: 1 });
                if (data && data.length > 0 && data[0]) {
                    setPreviousCorrection(data[0]);
                }
            } catch (error) {
                console.error("Failed to fetch previous optical correction:", error);
            }
        };
        loadPreviousCorrection();
    }, [patientId]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const currentName = e.currentTarget.name || '';
            const currentIndex = fieldOrder.indexOf(currentName);
            if (currentIndex !== -1 && currentIndex < fieldOrder.length - 1) {
                const nextFieldName = fieldOrder[currentIndex + 1];
                if (nextFieldName) {
                    const elements = document.getElementsByName(nextFieldName);
                    if (elements.length > 0) {
                        (elements[0] as HTMLElement).focus();
                    }
                }
            }
        }
    };

    const handleToggleSign = (fieldName: string) => {
        const val = formData[fieldName as keyof typeof formData];
        const currentValue = typeof val === 'string' ? val : '';
        
        let newValue = currentValue;
        if (!currentValue) {
            newValue = '-';
        } else if (currentValue.startsWith('-')) {
            newValue = currentValue.substring(1);
        } else if (currentValue.startsWith('+')) {
            newValue = '-' + currentValue.substring(1);
        } else {
            newValue = '-' + currentValue;
        }
        
        setFormData(prev => ({ ...prev, [fieldName]: newValue }));
        
        setTimeout(() => {
            const inputElements = document.getElementsByName(fieldName);
            if (inputElements.length > 0) {
                const input = inputElements[0] as HTMLInputElement;
                input.focus();
                const valLength = input.value.length;
                input.setSelectionRange(valLength, valLength);
            }
        }, 0);
    };

    const handleRestore = () => {
        if (!previousCorrection) return;
        setFormData({
            od_sph: previousCorrection.od_sph || '',
            od_cyl: previousCorrection.od_cyl || '',
            od_axis: previousCorrection.od_axis || '',
            od_add: previousCorrection.od_add || '',
            od_pd: previousCorrection.od_pd || '',
            os_sph: previousCorrection.os_sph || '',
            os_cyl: previousCorrection.os_cyl || '',
            os_axis: previousCorrection.os_axis || '',
            os_add: previousCorrection.os_add || '',
            os_pd: previousCorrection.os_pd || '',
            remarks: previousCorrection.remarks || ''
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit({ ...formData, patient_id: patientId });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            
            {previousCorrection && (
                <div className="flex items-center justify-between mb-4 bg-gray-50 dark:bg-gray-900/50 p-3 rounded-xl border border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-2">
                        <History className="w-5 h-5 text-indigo-500 dark:text-indigo-400" />
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            Ordonnance récente du <span className="font-semibold text-gray-900 dark:text-gray-100">{new Date(previousCorrection.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                        </span>
                    </div>
                    <button
                        type="button"
                        onClick={handleRestore}
                        className="text-sm px-6 py-2 flex items-center gap-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                        title="Restaurer toutes les valeurs de la dernière ordonnance"
                    >
                        Restaurer
                    </button>
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <EyeRow title="Œil Droit (OD)" prefix="od" formData={formData} handleChange={handleChange} handleKeyDown={handleKeyDown} handleToggleSign={handleToggleSign} />
                <EyeRow title="Œil Gauche (OG)" prefix="os" formData={formData} handleChange={handleChange} handleKeyDown={handleKeyDown} handleToggleSign={handleToggleSign} />
            </div>

            <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Remarques / Recommandations</label>
                <textarea
                    name="remarks"
                    value={formData.remarks}
                    onChange={handleChange}
                    onKeyDown={handleKeyDown}
                    rows={3}
                    placeholder="Ex: Port permanent, travail sur écran..."
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm resize-none"
                />
            </div>

            <div className="flex gap-3 mt-8">
                <button
                    type="button"
                    onClick={onCancel}
                    disabled={isSubmitting}
                    className="flex-1 px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                >
                    {t('common.cancel')}
                </button>
                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isSubmitting ? (
                        <>
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                            <span>{t('prescription.create.creating')}</span>
                        </>
                    ) : (
                        t('prescription.create.createPrescription')
                    )}
                </button>
            </div>
        </form>
    );
}
