// Prescription Types - Core type definitions for prescription-related data

/**
 * Medication from database
 */
export interface Medication {
    id: number;
    nom_de_marque: string;
    denomination_commune_internationale: string;
    dosage: string;
    forme: string;
    created_at?: string | Date;
    updated_at?: string | Date;
}

/**
 * Medication in a prescription
 */
export interface PrescriptionMedication {
    id?: number;
    medication_id: number;
    denomination_commune_internationale: string;
    nom_de_marque: string;
    quantity: number;
    dosage: string;
    note?: string;
    med_dosage?: string;
    is_custom?: boolean;
    custom_medication_id?: number;
    medication?: Medication;
}

/**
 * Core Prescription interface
 */
export interface Prescription {
    id: number;
    patient_id: number;
    doctor_user_id: number;
    confirmed_count?: number;
    remarks?: string;
    medication_ids: number[];
    created_at: string | Date;
    updated_at?: string | Date;
    patient?: {
        id: number;
        name: string;
        family_name: string;
        age: number;
        genre: 'homme' | 'femme';
        adresse?: string;
        telephone: string;
        email?: string;
    };
    doctor?: {
        id: number;
        name: string;
        family_name: string;
        email: string;
    };
    medications?: PrescriptionMedication[];
}

/**
 * Payload for creating a prescription
 */
export interface CreatePrescriptionPayload {
    patient_id: number;
    confirmed_count?: number;
    remarks?: string;
    medications: PrescriptionMedication[];
}

/**
 * Filters for fetching prescriptions
 */
export interface PrescriptionFilters {
    patientId?: string;
    doctorId?: number;
    limit?: number;
    offset?: number;
}

/**
 * Filters for searching medications
 */
export interface MedicationSearchFilters {
    searchTerm?: string;
    limit?: number;
    offset?: number;
}

/**
 * Prescription list item (minimal data for lists)
 */
export interface PrescriptionListItem {
    id: number;
    patient_id: number;
    doctor_user_id: number;
    created_at: string | Date;
    patient_name?: string;
    patient_family_name?: string;
    medication_count?: number;
}

/**
 * Prescription filter type for UI
 */
export type PrescriptionFilterType = 'all' | 'mine';

/**
 * Payload for exporting prescriptions
 */
export interface ExportPrescriptionPayload {
    patients?: string[];
    is_all?: boolean;
}

/**
 * Props for PrescriptionPreviewModal component
 */
export interface PrescriptionPreviewModalProps {
    isOpen: boolean;
    onClose: () => void;
    prescription: Prescription | null;
    patientName?: string;
    patientFamilyName?: string;
}

/**
 * ───────────────────────────────────────────────────────────────────
 * PRESCRIPTION TYPES (REUSABLE MODELS/TEMPLATES)
 * ───────────────────────────────────────────────────────────────────
 */

export interface PrescriptionTypeMedication {
    id?: number;
    medication_id: number | null;
    custom_medication_id?: number | null;
    is_custom: boolean;
    nom_de_marque: string;
    denomination_commune_internationale: string;
    quantity: number;
    dosage: string;
    note?: string;
    med_dosage?: string;
    sort_order?: number;
}

export interface PrescriptionType {
    id: number;
    name: string;
    description?: string;
    doctor_user_id: number;
    medications?: PrescriptionTypeMedication[];
    medication_count?: number; // returned by the list endpoint
    created_at: string | Date;
    updated_at?: string | Date;
}

export interface CreatePrescriptionTypePayload {
    name: string;
    description?: string;
    medications: Omit<PrescriptionTypeMedication, 'id' | 'nom_de_marque' | 'denomination_commune_internationale' | 'med_dosage'>[];
}
