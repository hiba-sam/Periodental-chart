// Prescription Types API - For managing reusable prescription templates

import axios from 'axios';
import type { PrescriptionType, CreatePrescriptionTypePayload } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Create axios instance
const api = axios.create({
    baseURL: `${API_URL}/prescription-type`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

export async function fetchMyTypes(withMedications: boolean = true): Promise<PrescriptionType[]> {
    const res = await api.get<{ success: boolean; data: PrescriptionType[] }>(
        `?withMedications=${withMedications}`
    );
    return res.data.data;
}

export async function fetchTypeById(id: number): Promise<PrescriptionType> {
    const res = await api.get<{ success: boolean; data: PrescriptionType }>(`/${id}`);
    return res.data.data;
}

export async function createType(payload: CreatePrescriptionTypePayload): Promise<PrescriptionType> {
    const res = await api.post<{ success: boolean; data: PrescriptionType }>('/', payload);
    return res.data.data;
}

export async function updateType(id: number, payload: Partial<CreatePrescriptionTypePayload>): Promise<PrescriptionType> {
    const res = await api.put<{ success: boolean; data: PrescriptionType }>(`/${id}`, payload);
    return res.data.data;
}

export async function deleteType(id: number): Promise<boolean> {
    const res = await api.delete<{ success: boolean; message: string }>(`/${id}`);
    return res.data.success;
}

export async function createTypeFromPrescription(
    prescriptionId: number,
    name: string,
    description?: string
): Promise<PrescriptionType> {
    const res = await api.post<{ success: boolean; data: PrescriptionType }>(
        `/from-prescription/${prescriptionId}`,
        { name, description }
    );
    return res.data.data;
}
