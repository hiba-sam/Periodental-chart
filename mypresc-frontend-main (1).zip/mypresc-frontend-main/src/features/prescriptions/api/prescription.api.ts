// Prescription API - All prescription-related API calls
// Self-contained API layer for the prescriptions feature

import axios from 'axios';
import type {
    Prescription,
    CreatePrescriptionPayload,
    PrescriptionFilters,
    Medication,
    MedicationSearchFilters,
} from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Create axios instances
const prescriptionApi = axios.create({
    baseURL: `${API_URL}/prescription`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

const medicationApi = axios.create({
    baseURL: `${API_URL}/medication`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

// ==================== PRESCRIPTION CRUD ====================

/**
 * Fetch all prescriptions with optional filters
 */
export async function fetchPrescriptions(filters?: PrescriptionFilters): Promise<Prescription[]> {
    const params = new URLSearchParams();
    if (filters?.patientId) params.append('patientId', filters.patientId);
    if (filters?.doctorId) params.append('doctorId', filters.doctorId.toString());
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.offset) params.append('offset', filters.offset.toString());

    const url = params.toString() ? `/?${params.toString()}` : '/';
    const response = await prescriptionApi.get(url);

    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to fetch prescriptions');
}

/**
 * Fetch prescriptions for a specific patient
 */
export async function fetchPrescriptionsByPatient(patientId: string): Promise<Prescription[]> {
    return fetchPrescriptions({ patientId });
}

/**
 * Fetch a single prescription by ID
 */
export async function fetchPrescriptionById(id: number): Promise<Prescription> {
    const response = await prescriptionApi.get(`/${id}`);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Prescription not found');
}

/**
 * Create a new prescription
 */
export async function createPrescription(payload: CreatePrescriptionPayload): Promise<Prescription> {
    const response = await prescriptionApi.post('/', payload);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to create prescription');
}

/**
 * Update an existing prescription
 */
export async function updatePrescription(
    id: number,
    payload: Partial<CreatePrescriptionPayload>
): Promise<Prescription> {
    const response = await prescriptionApi.put(`/${id}`, payload);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to update prescription');
}

/**
 * Delete a prescription
 */
export async function deletePrescription(id: number): Promise<boolean> {
    const response = await prescriptionApi.delete(`/${id}`);
    return response.data.success;
}

// ==================== PDF GENERATION ====================

/**
 * Generate and download prescription PDF
 */
export async function generatePrescriptionPdf(id: number): Promise<void> {
    const response = await prescriptionApi.get(`/${id}/pdf`, {
        responseType: 'blob',
    });

    // Create download link
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `prescription_${id}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
}

/**
 * Export prescription data
 */
export async function exportPrescriptionData(options?: {
    patients?: string[];
    is_all?: boolean;
}): Promise<void> {
    const response = await prescriptionApi.post('/export', options || { is_all: true }, {
        responseType: 'blob',
    });

    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'prescriptions_export.xlsx');
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
}

// ==================== MEDICATIONS ====================

/**
 * Search medications
 */
export async function searchMedications(filters: MedicationSearchFilters): Promise<Medication[]> {
    const params = new URLSearchParams();
    if (filters.searchTerm) params.append('search', filters.searchTerm);
    if (filters.limit) params.append('limit', filters.limit.toString());
    if (filters.offset) params.append('offset', filters.offset.toString());

    const response = await medicationApi.get(`/search?${params.toString()}`);
    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to search medications');
}

/**
 * Fetch a single medication by ID
 */
export async function fetchMedicationById(id: number): Promise<Medication> {
    const response = await medicationApi.get(`/${id}`);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Medication not found');
}

/**
 * Create a custom medication
 */
export async function createCustomMedication(data: Partial<Medication>): Promise<Medication> {
    const response = await medicationApi.post('/custom', data);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to create custom medication');
}
