'use client';

import React from 'react';
import type { ActeCardiologueFormData } from '../../types/cardiologue';
import { BIO_REFS } from '../../types/cardiologue';
import { getBioColor } from '../../utils/cardioRisk';

interface Props {
    data: ActeCardiologueFormData;
    onChange: (field: keyof ActeCardiologueFormData, value: any) => void;
}

const BIO_FIELDS = Object.entries(BIO_REFS) as [keyof ActeCardiologueFormData, typeof BIO_REFS[string]][];

export default React.memo(function CardioBiologie({ data, onChange }: Props) {
    return (
        <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 0 1-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 0 1 4.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19 14.5M14.25 3.104c.251.023.501.05.75.082M19 14.5l-2.47 2.47" />
                </svg>
                Biologie
                <span className="text-[10px] font-normal text-gray-400">(tous optionnels)</span>
            </h3>

            {/* Date du bilan */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Date du bilan</label>
                <input type="date" value={data.bio_date || ''} onChange={e => onChange('bio_date', e.target.value || null)}
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-purple-500" />
            </div>

            {/* Bio fields grid */}
            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                {BIO_FIELDS.map(([key, ref]) => {
                    const val = data[key] as number | null;
                    const color = getBioColor(key as string, val);
                    const isAlert = color.includes('red');
                    return (
                        <div key={key} className="flex items-center gap-1.5">
                            <div className="flex-1 min-w-0">
                                <label className="text-[11px] text-gray-500 dark:text-gray-400 flex items-center justify-between">
                                    <span className="truncate">{ref.label}</span>
                                    <span className="text-[9px] opacity-50 ml-1 flex-shrink-0">{ref.ref}</span>
                                </label>
                                <div className="relative">
                                    <input
                                        type="number"
                                        step="any"
                                        value={val ?? ''}
                                        onChange={e => onChange(key, e.target.value ? Number(e.target.value) : null)}
                                        placeholder="—"
                                        className={`w-full px-2 py-1 text-sm border rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-purple-500 transition-colors ${
                                            isAlert ? 'border-red-300 dark:border-red-600 bg-red-50 dark:bg-red-900/10' : 'border-gray-200 dark:border-gray-600'
                                        } ${color}`}
                                    />
                                    <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-gray-400 pointer-events-none">
                                        {ref.unite}
                                    </span>
                                </div>
                            </div>
                            {isAlert && val != null && (
                                <span className="flex-shrink-0 w-2 h-2 rounded-full bg-red-500 animate-pulse mt-4" title="Hors norme" />
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
});
