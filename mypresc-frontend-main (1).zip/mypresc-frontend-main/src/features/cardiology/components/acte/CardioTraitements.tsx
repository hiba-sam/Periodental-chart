'use client';

import React, { useState } from 'react';
import type { Traitement } from '../../types/cardiologue';

interface Props {
    traitements: Traitement[];
    onChange: (traitements: Traitement[]) => void;
}

const COMMON_DRUGS = [
    'Aspirine 100mg', 'Clopidogrel 75mg', 'Bisoprolol 2.5mg', 'Bisoprolol 5mg',
    'Amlodipine 5mg', 'Amlodipine 10mg', 'Ramipril 5mg', 'Ramipril 10mg',
    'Atorvastatine 40mg', 'Rosuvastatine 20mg', 'Furosémide 40mg',
    'Spironolactone 25mg', 'Périndopril 5mg', 'Losartan 50mg',
    'Sacubitril/Valsartan 50mg', 'Rivaroxaban 20mg', 'Acenocoumarol',
    'Metformine 850mg', 'Insuline', 'Amiodarone 200mg',
];

export default React.memo(function CardioTraitements({ traitements, onChange }: Props) {
    const [newDrug, setNewDrug] = useState('');
    const [showSuggestions, setShowSuggestions] = useState(false);

    const filtered = newDrug.length >= 2
        ? COMMON_DRUGS.filter(d => d.toLowerCase().includes(newDrug.toLowerCase()) && !traitements.some(t => t.nom === d))
        : [];

    const addTraitement = (nom: string) => {
        if (!nom.trim() || traitements.some(t => t.nom === nom.trim())) return;
        onChange([...traitements, { nom: nom.trim(), dose: '', freq: '', actif: true }]);
        setNewDrug('');
        setShowSuggestions(false);
    };

    const removeTraitement = (index: number) => {
        onChange(traitements.filter((_, i) => i !== index));
    };

    const toggleActif = (index: number) => {
        const updated = [...traitements];
        updated[index] = { ...updated[index], actif: !updated[index].actif };
        onChange(updated);
    };

    const updateField = (index: number, field: keyof Traitement, value: string) => {
        const updated = [...traitements];
        updated[index] = { ...updated[index], [field]: value };
        onChange(updated);
    };

    return (
        <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <svg className="w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m8.25 3v6.75m0 0-3-3m3 3 3-3M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" />
                </svg>
                Traitements
                <span className="text-[10px] font-normal text-gray-400 ml-auto">{traitements.filter(t => t.actif).length} actif(s)</span>
            </h3>

            {/* Quick add */}
            <div className="relative">
                <input
                    type="text"
                    value={newDrug}
                    onChange={e => { setNewDrug(e.target.value); setShowSuggestions(true); }}
                    onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addTraitement(newDrug); } }}
                    placeholder="Ajouter un traitement..."
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-blue-500 pr-16"
                />
                <button onClick={() => addTraitement(newDrug)} disabled={!newDrug.trim()}
                    className="absolute right-1 top-1/2 -translate-y-1/2 px-2 py-0.5 text-xs font-medium text-white bg-blue-600 rounded hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                    + Ajouter
                </button>
                {showSuggestions && filtered.length > 0 && (
                    <div className="absolute z-20 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-40 overflow-y-auto">
                        {filtered.map(d => (
                            <button key={d} onClick={() => addTraitement(d)}
                                className="w-full px-3 py-1.5 text-sm text-left hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                                {d}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* Treatments list */}
            <div className="space-y-1 max-h-[200px] overflow-y-auto">
                {traitements.length === 0 && (
                    <p className="text-xs text-gray-400 dark:text-gray-500 text-center py-3">Aucun traitement</p>
                )}
                {traitements.map((t, i) => (
                    <div key={i} className={`flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-sm transition-colors ${
                        t.actif ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800' : 'bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-700 opacity-60'
                    }`}>
                        <button onClick={() => toggleActif(i)} className={`flex-shrink-0 w-4 h-4 rounded-full border-2 transition-colors ${
                            t.actif ? 'bg-blue-500 border-blue-500' : 'bg-transparent border-gray-400'
                        }`} title={t.actif ? 'Désactiver' : 'Activer'}>
                            {t.actif && <svg className="w-full h-full text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                        </button>
                        <span className={`flex-1 min-w-0 truncate font-medium ${t.actif ? 'text-gray-800 dark:text-gray-200' : 'text-gray-500 line-through'}`}>{t.nom}</span>
                        <input type="text" value={t.dose} onChange={e => updateField(i, 'dose', e.target.value)} placeholder="dose"
                            className="w-16 px-1 py-0.5 text-[11px] border border-gray-200 dark:border-gray-600 rounded bg-white dark:bg-gray-700" />
                        <input type="text" value={t.freq} onChange={e => updateField(i, 'freq', e.target.value)} placeholder="freq"
                            className="w-14 px-1 py-0.5 text-[11px] border border-gray-200 dark:border-gray-600 rounded bg-white dark:bg-gray-700" />
                        <button onClick={() => removeTraitement(i)} className="flex-shrink-0 p-0.5 text-gray-400 hover:text-red-500 transition-colors" title="Supprimer">
                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
});
