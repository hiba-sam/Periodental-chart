'use client';

import React, { useMemo } from 'react';
import type { ActeCardiologueFormData } from '../../types/cardiologue';
import { getConstanteColor } from '../../utils/cardioRisk';

interface Props {
    data: ActeCardiologueFormData;
    onChange: (field: keyof ActeCardiologueFormData, value: any) => void;
}

const FIELDS: { key: keyof ActeCardiologueFormData; label: string; unit: string; placeholder: string; colorKey?: string }[] = [
    { key: 'pa_systolique',         label: 'PAS',   unit: 'mmHg', placeholder: '120', colorKey: 'pa_systolique' },
    { key: 'pa_diastolique',        label: 'PAD',   unit: 'mmHg', placeholder: '80',  colorKey: 'pa_diastolique' },
    { key: 'frequence_cardiaque',   label: 'FC',    unit: 'bpm',  placeholder: '72',  colorKey: 'frequence_cardiaque' },
    { key: 'spo2',                  label: 'SpO₂',  unit: '%',    placeholder: '98',  colorKey: 'spo2' },
    { key: 'frequence_respiratoire',label: 'FR',    unit: '/min', placeholder: '16',  colorKey: 'frequence_respiratoire' },
    { key: 'poids',                 label: 'Poids', unit: 'kg',   placeholder: '75' },
    { key: 'taille',                label: 'Taille',unit: 'cm',   placeholder: '170' },
];

export default React.memo(function CardioConstantes({ data, onChange }: Props) {
    const imc = useMemo(() => {
        if (data.poids && data.taille && data.taille > 0) {
            const h = data.taille / 100;
            return (data.poids / (h * h)).toFixed(1);
        }
        return null;
    }, [data.poids, data.taille]);

    const imcColor = useMemo(() => {
        if (!imc) return '';
        const v = parseFloat(imc);
        if (v >= 30) return 'text-red-600 dark:text-red-400 font-bold';
        if (v >= 25) return 'text-orange-600 dark:text-orange-400 font-semibold';
        if (v < 18.5) return 'text-orange-600 dark:text-orange-400 font-semibold';
        return 'text-green-600 dark:text-green-400';
    }, [imc]);

    return (
        <div className="grid grid-cols-4 lg:grid-cols-8 gap-2">
            {FIELDS.map(f => {
                const val = data[f.key] as number | null;
                const color = f.colorKey ? getConstanteColor(f.colorKey, val) : '';
                return (
                    <div key={f.key} className="flex flex-col">
                        <label className="text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-0.5 truncate">
                            {f.label} <span className="text-[9px] opacity-60">{f.unit}</span>
                        </label>
                        <input
                            type="number"
                            value={val ?? ''}
                            onChange={e => onChange(f.key, e.target.value ? Number(e.target.value) : null)}
                            placeholder={f.placeholder}
                            className={`w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500 focus:border-transparent transition-colors ${color}`}
                        />
                    </div>
                );
            })}
            {/* IMC auto-calculated */}
            <div className="flex flex-col">
                <label className="text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-0.5">
                    IMC <span className="text-[9px] opacity-60">kg/m²</span>
                </label>
                <div className={`w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 ${imcColor}`}>
                    {imc || '—'}
                </div>
            </div>
        </div>
    );
});
