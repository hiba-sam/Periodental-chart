'use client';

import React from 'react';
import type { ActeCardiologueFormData, Pericarde } from '../../types/cardiologue';
import { PERICARDES } from '../../types/cardiologue';

interface Props {
    data: ActeCardiologueFormData;
    onChange: (field: keyof ActeCardiologueFormData, value: any) => void;
}

function FevgGauge({ value }: { value: number | null }) {
    if (value == null) return (
        <div className="flex items-center justify-center w-16 h-16 rounded-full border-4 border-dashed border-gray-300 dark:border-gray-600">
            <span className="text-xs text-gray-400">—</span>
        </div>
    );
    const pct = Math.min(Math.max(value, 0), 100);
    const r = 28;
    const circ = 2 * Math.PI * r;
    const offset = circ - (pct / 100) * circ;
    const color = value >= 55 ? '#22c55e' : value >= 40 ? '#f59e0b' : value >= 30 ? '#f97316' : '#ef4444';

    return (
        <div className="relative flex items-center justify-center w-16 h-16">
            <svg viewBox="0 0 64 64" className="w-16 h-16 -rotate-90">
                <circle cx="32" cy="32" r={r} fill="none" stroke="currentColor" strokeWidth="5" className="text-gray-200 dark:text-gray-700" />
                <circle cx="32" cy="32" r={r} fill="none" stroke={color} strokeWidth="5"
                    strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" className="transition-all duration-500" />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-sm font-bold" style={{ color }}>{value}%</span>
                <span className="text-[8px] text-gray-400">FEVG</span>
            </div>
        </div>
    );
}

export default React.memo(function CardioETT({ data, onChange }: Props) {
    return (
        <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </svg>
                ETT (Échocardiographie)
            </h3>

            {/* FEVG prominent row */}
            <div className="flex items-center gap-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <FevgGauge value={data.ett_fevg} />
                <div className="flex-1">
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">FEVG (%)</label>
                    <input type="number" min={0} max={100} value={data.ett_fevg ?? ''} onChange={e => onChange('ett_fevg', e.target.value ? Number(e.target.value) : null)}
                        placeholder="55" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                </div>
                <div className="flex-1">
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">PAPS <span className="opacity-60">mmHg</span></label>
                    <input type="number" value={data.ett_paps ?? ''} onChange={e => onChange('ett_paps', e.target.value ? Number(e.target.value) : null)}
                        placeholder="25" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                </div>
            </div>

            {/* Dimensions row */}
            <div className="grid grid-cols-2 gap-2">
                <div>
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">DTD VG <span className="opacity-60">mm</span></label>
                    <input type="number" value={data.ett_dtd_vg ?? ''} onChange={e => onChange('ett_dtd_vg', e.target.value ? Number(e.target.value) : null)}
                        placeholder="50" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                </div>
                <div>
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">OG <span className="opacity-60">mm</span></label>
                    <input type="number" value={data.ett_og ?? ''} onChange={e => onChange('ett_og', e.target.value ? Number(e.target.value) : null)}
                        placeholder="38" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                </div>
            </div>

            {/* Cinetique */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Cinétique segmentaire</label>
                <input type="text" value={data.ett_cinetique} onChange={e => onChange('ett_cinetique', e.target.value)}
                    placeholder="Globalement conservée..." className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
            </div>

            {/* Valves row */}
            <div className="grid grid-cols-3 gap-2">
                {[
                    { key: 'ett_valve_mitrale' as const, label: 'V. Mitrale' },
                    { key: 'ett_valve_aortique' as const, label: 'V. Aortique' },
                    { key: 'ett_valve_tricuspide' as const, label: 'V. Tricuspide' },
                ].map(v => (
                    <div key={v.key}>
                        <label className="text-[11px] text-gray-500 dark:text-gray-400">{v.label}</label>
                        <input type="text" value={data[v.key]} onChange={e => onChange(v.key, e.target.value)}
                            placeholder="IM, IA, IT..." className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                    </div>
                ))}
            </div>

            {/* Pericarde */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Péricarde</label>
                <select value={data.ett_pericarde} onChange={e => onChange('ett_pericarde', e.target.value as Pericarde)}
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500">
                    {PERICARDES.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
            </div>

            {/* Conclusion */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Conclusion ETT</label>
                <textarea value={data.ett_conclusion} onChange={e => onChange('ett_conclusion', e.target.value)}
                    rows={2} placeholder="Conclusion..." className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500 resize-none" />
            </div>
        </div>
    );
});
