'use client';

import React from 'react';
import type { ActeCardiologueFormData, EcgRythme, EcgAxe } from '../../types/cardiologue';
import { ECG_RYTHMES, ECG_AXES } from '../../types/cardiologue';

interface Props {
    data: ActeCardiologueFormData;
    onChange: (field: keyof ActeCardiologueFormData, value: any) => void;
}

export default React.memo(function CardioECG({ data, onChange }: Props) {
    const rythmeColor = data.ecg_rythme && data.ecg_rythme !== 'Sinusal'
        ? 'border-orange-300 dark:border-orange-600 bg-orange-50 dark:bg-orange-900/10'
        : '';

    return (
        <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <svg className="w-4 h-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h3l3-9 4 18 3-9h5" />
                </svg>
                ECG
            </h3>
            {/* Row 1: Rythme + FC */}
            <div className="grid grid-cols-2 gap-2">
                <div>
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">Rythme</label>
                    <select
                        value={data.ecg_rythme}
                        onChange={e => onChange('ecg_rythme', e.target.value as EcgRythme)}
                        className={`w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500 ${rythmeColor}`}
                    >
                        {ECG_RYTHMES.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                </div>
                <div>
                    <label className="text-[11px] text-gray-500 dark:text-gray-400">FC ECG <span className="opacity-60">bpm</span></label>
                    <input type="number" value={data.ecg_fc ?? ''} onChange={e => onChange('ecg_fc', e.target.value ? Number(e.target.value) : null)}
                        placeholder="72" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                </div>
            </div>
            {/* Row 2: PR, QRS, QTc */}
            <div className="grid grid-cols-3 gap-2">
                {(['ecg_pr', 'ecg_qrs', 'ecg_qtc'] as const).map(k => (
                    <div key={k}>
                        <label className="text-[11px] text-gray-500 dark:text-gray-400">{k.replace('ecg_', '').toUpperCase()} <span className="opacity-60">ms</span></label>
                        <input type="text" value={data[k]} onChange={e => onChange(k, e.target.value)}
                            placeholder="—" className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
                    </div>
                ))}
            </div>
            {/* Row 3: Axe */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Axe</label>
                <select value={data.ecg_axe} onChange={e => onChange('ecg_axe', e.target.value as EcgAxe)}
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500">
                    {ECG_AXES.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
            </div>
            {/* Row 4: Anomalies + Conclusion */}
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Anomalies</label>
                <input type="text" value={data.ecg_anomalies} onChange={e => onChange('ecg_anomalies', e.target.value)}
                    placeholder="ST, ondes T, BBG..." className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500" />
            </div>
            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Conclusion ECG</label>
                <textarea value={data.ecg_conclusion} onChange={e => onChange('ecg_conclusion', e.target.value)}
                    rows={2} placeholder="Conclusion..." className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500 resize-none" />
            </div>
        </div>
    );
});
