'use client';

import { useState, useEffect, useCallback } from 'react';
import Modal from '@/components/ui/Modal';
import { toast } from '@/components/ui/use-toast';
import type { ActeCardiologue, ActeCardiologueFormData } from '../../types/cardiologue';
import { DEFAULT_FORM_DATA } from '../../types/cardiologue';
import { createActeCardiologue, updateActeCardiologue } from '../../hooks/useActeCardiologue';
import CardioKpiSynthesis from './CardioKpiSynthesis';
import CardioConstantes from './CardioConstantes';
import CardioECG from './CardioECG';
import CardioETT from './CardioETT';
import CardioBiologie from './CardioBiologie';
import CardioTraitements from './CardioTraitements';
import CardioNotes from './CardioNotes';

interface ActeCardiologueModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    patientName: string;
    patientAge?: number;
    patientSex?: string;
    editActe?: ActeCardiologue | null;
    onSuccess: () => void;
}

function mapActeToForm(acte: ActeCardiologue): ActeCardiologueFormData {
    return {
        motif: acte.motif || '',
        pa_systolique: acte.pa_systolique,
        pa_diastolique: acte.pa_diastolique,
        frequence_cardiaque: acte.frequence_cardiaque,
        spo2: acte.spo2,
        frequence_respiratoire: acte.frequence_respiratoire,
        poids: acte.poids,
        taille: acte.taille,
        ecg_rythme: acte.ecg_rythme || 'Sinusal',
        ecg_fc: acte.ecg_fc,
        ecg_pr: acte.ecg_pr || '',
        ecg_qrs: acte.ecg_qrs || '',
        ecg_qtc: acte.ecg_qtc || '',
        ecg_axe: acte.ecg_axe || 'Normal',
        ecg_anomalies: acte.ecg_anomalies || '',
        ecg_conclusion: acte.ecg_conclusion || '',
        ett_fevg: acte.ett_fevg,
        ett_dtd_vg: acte.ett_dtd_vg,
        ett_og: acte.ett_og,
        ett_cinetique: acte.ett_cinetique || '',
        ett_valve_mitrale: acte.ett_valve_mitrale || '',
        ett_valve_aortique: acte.ett_valve_aortique || '',
        ett_valve_tricuspide: acte.ett_valve_tricuspide || '',
        ett_paps: acte.ett_paps,
        ett_pericarde: acte.ett_pericarde || 'Sec',
        ett_conclusion: acte.ett_conclusion || '',
        bio_glycemie: acte.bio_glycemie,
        bio_hba1c: acte.bio_hba1c,
        bio_cholesterol_total: acte.bio_cholesterol_total,
        bio_ldl: acte.bio_ldl,
        bio_hdl: acte.bio_hdl,
        bio_triglycerides: acte.bio_triglycerides,
        bio_creatinine: acte.bio_creatinine,
        bio_uree: acte.bio_uree,
        bio_potassium: acte.bio_potassium,
        bio_hemoglobine: acte.bio_hemoglobine,
        bio_date: acte.bio_date || null,
        traitements: acte.traitements || [],
        notes: acte.notes || '',
        conduite_a_tenir: acte.conduite_a_tenir || '',
        prochain_rdv: acte.prochain_rdv || null,
    };
}

export default function ActeCardiologueModal({
    isOpen, onClose, patientId, patientName, patientAge, patientSex, editActe, onSuccess
}: ActeCardiologueModalProps) {
    const [form, setForm] = useState<ActeCardiologueFormData>({ ...DEFAULT_FORM_DATA });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setForm(editActe ? mapActeToForm(editActe) : { ...DEFAULT_FORM_DATA });
        }
    }, [isOpen, editActe]);

    const handleChange = useCallback((field: keyof ActeCardiologueFormData, value: any) => {
        setForm(prev => ({ ...prev, [field]: value }));
    }, []);

    const handleTraitementsChange = useCallback((traitements: ActeCardiologueFormData['traitements']) => {
        setForm(prev => ({ ...prev, traitements }));
    }, []);

    const handleSubmit = async () => {
        setSubmitting(true);
        try {
            if (editActe) {
                await updateActeCardiologue(editActe.id, form);
                toast({ title: 'Succès', description: 'Acte cardiologique modifié' });
            } else {
                await createActeCardiologue(patientId, form);
                toast({ title: 'Succès', description: 'Acte cardiologique enregistré' });
            }
            onSuccess();
        } catch (err: any) {
            toast({ title: 'Erreur', description: err?.response?.data?.message || err?.message || 'Erreur', variant: 'destructive' });
        }
        setSubmitting(false);
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            className="max-w-[96vw] xl:max-w-[1400px] w-full"
            showCloseIcon={true}
            closeOnBackdrop={false}
        >
            {/* ── HEADER: Patient + KPI Synthesis ── */}
            <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                            <svg className="w-5 h-5 text-red-600 dark:text-red-400" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                            </svg>
                        </div>
                        <div>
                            <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                                {editActe ? 'Modifier l\'acte' : 'Nouvel acte cardiologique'}
                            </h2>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                                {patientName}
                                {patientAge ? ` · ${patientAge} ans` : ''}
                                {patientSex ? ` · ${patientSex}` : ''}
                            </p>
                        </div>
                    </div>
                </div>

                {/* KPI Synthesis strip */}
                <div className="p-2.5 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600">
                    <CardioKpiSynthesis data={form} />
                </div>
            </div>

            {/* ── MOTIF ── */}
            <div className="mb-3">
                <label className="text-[11px] font-medium text-gray-500 dark:text-gray-400">Motif de consultation</label>
                <input
                    type="text"
                    value={form.motif}
                    onChange={e => handleChange('motif', e.target.value)}
                    placeholder="Contrôle HTA, douleur thoracique, suivi IC..."
                    className="w-full px-3 py-2 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-red-500 focus:border-transparent"
                />
            </div>

            {/* ── CONSTANTES BAND ── */}
            <div className="mb-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wide">Constantes</div>
                <CardioConstantes data={form} onChange={handleChange} />
            </div>

            {/* ── 3-COLUMN LAYOUT ── */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                {/* COL 1: ECG + ETT */}
                <div className="space-y-4 p-3 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-y-auto max-h-[50vh]">
                    <CardioECG data={form} onChange={handleChange} />
                    <div className="border-t border-gray-200 dark:border-gray-700" />
                    <CardioETT data={form} onChange={handleChange} />
                </div>

                {/* COL 2: Biologie */}
                <div className="p-3 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-y-auto max-h-[50vh]">
                    <CardioBiologie data={form} onChange={handleChange} />
                </div>

                {/* COL 3: Traitements + Notes/CAT/RDV */}
                <div className="space-y-4 p-3 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-y-auto max-h-[50vh]">
                    <CardioTraitements traitements={form.traitements} onChange={handleTraitementsChange} />
                    <div className="border-t border-gray-200 dark:border-gray-700" />
                    <CardioNotes data={form} onChange={handleChange} />
                </div>
            </div>

            {/* ── FOOTER ── */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                <button
                    onClick={onClose}
                    className="px-5 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                    Annuler
                </button>
                <button
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="px-6 py-2.5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                    {submitting ? (
                        <>
                            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                            Enregistrement...
                        </>
                    ) : (
                        editActe ? 'Modifier' : 'Enregistrer'
                    )}
                </button>
            </div>
        </Modal>
    );
}
