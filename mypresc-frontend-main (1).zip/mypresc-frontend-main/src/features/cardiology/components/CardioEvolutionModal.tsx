'use client';

import { useState, useMemo } from 'react';
import { XMarkIcon } from '@heroicons/react/24/outline';
import {
    LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine
} from 'recharts';

// ============================================
// TYPES
// ============================================
interface CRCardio {
    id: number;
    created_at: string;
    heart_rate?: number | null;
    systolic_bp?: number | null;
    diastolic_bp?: number | null;
    spo2?: number | null;
    echo_lvef?: number | null;
    known_lvef?: number | null;
    echo_lvedd?: number | null;
    echo_lvesd?: number | null;
    echo_la_size?: number | null;
    echo_ivs_thickness?: number | null;
    echo_pw_thickness?: number | null;
    echo_tapse?: number | null;
    echo_pulmonary_htn?: number | null;
    bio_ldl?: number | null;
    bio_hdl?: number | null;
    bio_total_cholesterol?: number | null;
    bio_triglycerides?: number | null;
    bio_hba1c?: number | null;
    bio_creatinine?: number | null;
    bio_bnp?: number | null;
    bio_troponin?: number | null;
    score_cha2ds2_vasc?: number | null;
    score_has_bled?: number | null;
    score_grace?: number | null;
    score_framingham?: number | null;
    score_score2?: number | null;
    score_nyha?: number | null;
    patient_weight?: number | null;
    patient_age?: number | null;
}

interface CardioEvolutionModalProps {
    isOpen: boolean;
    onClose: () => void;
    reports: CRCardio[];
    patientName: string;
}

// ============================================
// CHART PALETTE (MyPresc design tokens)
// ============================================
const COLORS = {
    primary: '#1a237e',
    blue: '#4a69ff',
    red: '#EF4444',
    orange: '#F59E0B',
    green: '#22C55E',
    purple: '#a155ff',
    pink: '#ff55a5',
    teal: '#14b8a6',
};

// ============================================
// TABS CONFIG
// ============================================
type TabKey = 'constantes' | 'echo' | 'biologie' | 'scores';

interface ChartLine {
    key: string;
    label: string;
    color: string;
    unit: string;
    refLine?: { value: number; label: string; color: string };
}

const TABS: { key: TabKey; label: string; lines: ChartLine[] }[] = [
    {
        key: 'constantes',
        label: 'Constantes',
        lines: [
            { key: 'heart_rate', label: 'FC', color: COLORS.red, unit: 'bpm' },
            { key: 'systolic_bp', label: 'PAS', color: COLORS.primary, unit: 'mmHg' },
            { key: 'diastolic_bp', label: 'PAD', color: COLORS.blue, unit: 'mmHg' },
            { key: 'spo2', label: 'SpO₂', color: COLORS.green, unit: '%' },
            { key: 'patient_weight', label: 'Poids', color: COLORS.teal, unit: 'kg' },
        ]
    },
    {
        key: 'echo',
        label: 'Échographie',
        lines: [
            { key: 'fevg', label: 'FEVG', color: COLORS.red, unit: '%', refLine: { value: 55, label: 'Seuil normal', color: '#94a3b8' } },
            { key: 'echo_tapse', label: 'TAPSE', color: COLORS.green, unit: 'mm', refLine: { value: 17, label: 'Seuil TAPSE', color: '#94a3b8' } },
            { key: 'echo_lvedd', label: 'DTD VG', color: COLORS.blue, unit: 'mm' },
            { key: 'echo_lvesd', label: 'DTS VG', color: COLORS.teal, unit: 'mm' },
            { key: 'echo_la_size', label: 'OG', color: COLORS.purple, unit: 'mm' },
            { key: 'echo_ivs_thickness', label: 'SIV', color: COLORS.pink, unit: 'mm' },
            { key: 'echo_pw_thickness', label: 'PP', color: '#6366f1', unit: 'mm' },
            { key: 'echo_pulmonary_htn', label: 'HTAP', color: COLORS.orange, unit: 'mmHg' },
        ]
    },
    {
        key: 'biologie',
        label: 'Biologie',
        lines: [
            { key: 'bio_ldl', label: 'LDL', color: COLORS.red, unit: 'g/L' },
            { key: 'bio_hdl', label: 'HDL', color: COLORS.green, unit: 'g/L' },
            { key: 'bio_total_cholesterol', label: 'Chol. total', color: COLORS.orange, unit: 'g/L' },
            { key: 'bio_hba1c', label: 'HbA1c', color: COLORS.purple, unit: '%' },
            { key: 'bio_creatinine', label: 'Créatinine', color: COLORS.blue, unit: 'µmol/L' },
            { key: 'bio_bnp', label: 'BNP', color: COLORS.pink, unit: 'pg/mL' },
        ]
    },
    {
        key: 'scores',
        label: 'Scores',
        lines: [
            { key: 'score_cha2ds2_vasc', label: 'CHA₂DS₂-VASc', color: COLORS.red, unit: '/9' },
            { key: 'score_has_bled', label: 'HAS-BLED', color: COLORS.orange, unit: '/9' },
            { key: 'score_grace', label: 'GRACE', color: COLORS.primary, unit: '' },
            { key: 'score_framingham', label: 'Framingham', color: COLORS.green, unit: '%' },
            { key: 'score_score2', label: 'SCORE2_DYNAMIC', color: COLORS.purple, unit: '%' },
            { key: 'score_nyha', label: 'NYHA', color: COLORS.pink, unit: '' },
        ]
    },
];

// ============================================
// CUSTOM TOOLTIP
// ============================================
function CustomTooltip({ active, payload, label }: any) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-3 text-xs">
            <p className="font-semibold text-gray-800 dark:text-gray-200 mb-1">{label}</p>
            {payload.map((p: any) => (
                <div key={p.dataKey} className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                    <span className="text-gray-600 dark:text-gray-400">{p.name}:</span>
                    <span className="font-semibold" style={{ color: p.color }}>{p.value != null ? p.value : '—'}</span>
                </div>
            ))}
        </div>
    );
}

// ============================================
// COMPONENT
// ============================================
// Sanitize: treat negative or clearly invalid values as null
function sanitizeNum(v: number | null | undefined, min = 0): number | null {
    if (v == null || v < min) return null;
    return v;
}

export default function CardioEvolutionModal({ isOpen, onClose, reports, patientName }: CardioEvolutionModalProps) {
    const [activeTab, setActiveTab] = useState<TabKey>('constantes');
    const [hiddenLines, setHiddenLines] = useState<Set<string>>(new Set());

    // Dynamic SCORE2 / SCORE2-OP label based on latest report's patient age
    const latestAge = useMemo(() => {
        if (!reports || reports.length === 0) return null;
        const sorted = [...reports].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        return sorted[0]?.patient_age ?? null;
    }, [reports]);
    const score2Label = (latestAge ?? 0) >= 70 ? 'SCORE2-OP' : 'SCORE2';

    // Resolve dynamic labels in TABS
    const resolvedTabs = useMemo(() => TABS.map(tab => ({
        ...tab,
        lines: tab.lines.map(line =>
            line.label === 'SCORE2_DYNAMIC' ? { ...line, label: score2Label } : line
        ),
    })), [score2Label]);

    const toggleLine = (key: string) => {
        setHiddenLines((prev: Set<string>) => {
            const next = new Set(prev);
            if (next.has(key)) next.delete(key); else next.add(key);
            return next;
        });
    };

    const chartData = useMemo(() => {
        if (!reports || reports.length === 0) return [];
        // Sort by date ascending
        const sorted = [...reports].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
        // Deduplicate dates: if same day, append time
        const dateCounts: Record<string, number> = {};
        sorted.forEach(r => {
            const d = new Date(r.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: '2-digit' });
            dateCounts[d] = (dateCounts[d] || 0) + 1;
        });
        const hasDupes = Object.values(dateCounts).some(c => c > 1);
        return sorted.map(r => {
            const dt = new Date(r.created_at);
            let dateLabel = dt.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: '2-digit' });
            if (hasDupes) {
                dateLabel += ` ${dt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
            }
            return {
                date: dateLabel,
                heart_rate: sanitizeNum(r.heart_rate, 20),
                systolic_bp: sanitizeNum(r.systolic_bp, 30),
                diastolic_bp: sanitizeNum(r.diastolic_bp, 20),
                spo2: sanitizeNum(r.spo2, 50),
                patient_weight: sanitizeNum(r.patient_weight, 1),
                fevg: sanitizeNum(r.echo_lvef ?? r.known_lvef, 1),
                echo_lvedd: sanitizeNum(r.echo_lvedd, 1),
                echo_lvesd: sanitizeNum(r.echo_lvesd, 1),
                echo_la_size: sanitizeNum(r.echo_la_size, 1),
                echo_ivs_thickness: sanitizeNum(r.echo_ivs_thickness, 1),
                echo_pw_thickness: sanitizeNum(r.echo_pw_thickness, 1),
                echo_tapse: sanitizeNum(r.echo_tapse, 1),
                echo_pulmonary_htn: sanitizeNum(r.echo_pulmonary_htn, 1),
                bio_ldl: r.bio_ldl ?? null,
                bio_hdl: r.bio_hdl ?? null,
                bio_total_cholesterol: r.bio_total_cholesterol ?? null,
                bio_hba1c: r.bio_hba1c ?? null,
                bio_creatinine: r.bio_creatinine ?? null,
                bio_bnp: r.bio_bnp ?? null,
                score_cha2ds2_vasc: r.score_cha2ds2_vasc ?? null,
                score_has_bled: r.score_has_bled ?? null,
                score_grace: r.score_grace ?? null,
                score_framingham: r.score_framingham ?? null,
                score_score2: r.score_score2 ?? null,
                score_nyha: r.score_nyha ?? null,
            };
        });
    }, [reports]);

    const currentTab = resolvedTabs.find(t => t.key === activeTab)!;

    // Filter lines that have at least one data point and are not hidden
    const availableLines = currentTab.lines.filter(line =>
        chartData.some((d: Record<string, unknown>) => d[line.key] != null)
    );
    const activeLines = availableLines.filter(line => !hiddenLines.has(line.key));

    if (!isOpen) return null;

    const hasData = reports.length >= 2;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-5xl w-full mx-4 my-4 transform transition-all max-h-[90vh] flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                            <svg className="w-6 h-6 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
                            </svg>
                            Évolutions cardiologiques
                        </h2>
                        <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{patientName} — {reports.length} compte{reports.length > 1 ? 's' : ''}-rendu{reports.length > 1 ? 's' : ''}</p>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                        <XMarkIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex gap-1 px-5 pt-4 flex-shrink-0">
                    {resolvedTabs.map(tab => (
                        <button
                            key={tab.key}
                            onClick={() => setActiveTab(tab.key)}
                            className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors ${
                                activeTab === tab.key
                                    ? 'bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 border-b-2 border-indigo-600'
                                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/30'
                            }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Chart area */}
                <div className="flex-1 overflow-y-auto p-5">
                    {!hasData ? (
                        <div className="flex flex-col items-center justify-center py-16 text-center">
                            <svg className="w-16 h-16 text-gray-300 dark:text-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
                            </svg>
                            <p className="text-base font-medium text-gray-500 dark:text-gray-400">Pas assez de données pour afficher les évolutions</p>
                            <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Créez au moins 2 comptes-rendus cardiologiques pour voir les tendances</p>
                        </div>
                    ) : availableLines.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-16 text-center">
                            <p className="text-base font-medium text-gray-500 dark:text-gray-400">Aucune donnée pour cette catégorie</p>
                            <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Les données de « {currentTab.label} » ne sont pas renseignées dans les comptes-rendus</p>
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {/* Summary cards — click to toggle visibility */}
                            <div className="flex flex-wrap gap-2">
                                {availableLines.map(line => {
                                    const latestVal = [...chartData].reverse().find(d => (d as any)[line.key] != null);
                                    const val = latestVal ? (latestVal as any)[line.key] : null;
                                    const isHidden = hiddenLines.has(line.key);
                                    return (
                                        <button
                                            key={line.key}
                                            type="button"
                                            onClick={() => toggleLine(line.key)}
                                            className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all text-left ${
                                                isHidden
                                                    ? 'bg-gray-100 dark:bg-gray-700/20 opacity-50'
                                                    : 'bg-gray-50 dark:bg-gray-700/40'
                                            }`}
                                        >
                                            <span className={`w-3 h-3 rounded-full ${isHidden ? 'opacity-30' : ''}`} style={{ backgroundColor: line.color }} />
                                            <span className="text-xs text-gray-500 dark:text-gray-400">{line.label}</span>
                                            <span className={`text-sm font-bold ${isHidden ? 'line-through opacity-40' : ''}`} style={{ color: isHidden ? undefined : line.color }}>{val != null ? `${val} ${line.unit}` : '—'}</span>
                                        </button>
                                    );
                                })}
                            </div>
                            <p className="text-[10px] text-gray-400 dark:text-gray-500 -mt-1">Cliquez sur un indicateur pour l'afficher/masquer</p>

                            {/* Chart */}
                            <div className="bg-gray-50 dark:bg-gray-700/20 rounded-xl p-4 border border-gray-200 dark:border-gray-700">
                                <ResponsiveContainer width="100%" height={360}>
                                    <LineChart data={chartData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                        <XAxis
                                            dataKey="date"
                                            tick={{ fontSize: 11, fill: '#6b7280' }}
                                            tickLine={false}
                                            axisLine={{ stroke: '#d1d5db' }}
                                        />
                                        <YAxis
                                            tick={{ fontSize: 11, fill: '#6b7280' }}
                                            tickLine={false}
                                            axisLine={false}
                                            width={50}
                                        />
                                        <Tooltip content={<CustomTooltip />} />
                                        <Legend
                                            verticalAlign="bottom"
                                            height={36}
                                            iconType="circle"
                                            iconSize={8}
                                            wrapperStyle={{ fontSize: '12px' }}
                                        />
                                        {activeLines.map(line => (
                                            <Line
                                                key={line.key}
                                                type="monotone"
                                                dataKey={line.key}
                                                name={line.label}
                                                stroke={line.color}
                                                strokeWidth={2.5}
                                                dot={{ r: 4, fill: line.color, strokeWidth: 2, stroke: '#fff' }}
                                                activeDot={{ r: 6, strokeWidth: 0 }}
                                                connectNulls
                                            />
                                        ))}
                                        {activeLines.filter(l => l.refLine).map(line => (
                                            <ReferenceLine
                                                key={`ref-${line.key}`}
                                                y={line.refLine!.value}
                                                stroke={line.refLine!.color}
                                                strokeDasharray="6 4"
                                                label={{ value: line.refLine!.label, position: 'right', fill: line.refLine!.color, fontSize: 10 }}
                                            />
                                        ))}
                                    </LineChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex justify-end p-5 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
                    <button
                        onClick={onClose}
                        className="px-6 py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                    >
                        Fermer
                    </button>
                </div>
            </div>
        </div>
    );
}
