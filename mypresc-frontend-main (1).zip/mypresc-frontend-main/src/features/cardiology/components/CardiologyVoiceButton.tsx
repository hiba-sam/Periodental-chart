'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { MicrophoneIcon, StopIcon } from '@heroicons/react/24/outline';
import type { CardiologyFormData } from '@/utils/cardiologyScores';
import { fetchAIQuota, generateCardiologyReportFromAudio } from '@/features/medical-reports/api/medical-reports.api';
import type { AIQuotaInfo } from '@/features/medical-reports/types';

const MAX_RECORDING_SECONDS = 180; // 3 minutes

interface CardiologyVoiceButtonProps {
    onDataExtracted: (data: Partial<CardiologyFormData>, additionalInfo: string | null, transcription: string) => void;
    onError?: (error: string) => void;
    disabled?: boolean;
}

export default function CardiologyVoiceButton({ onDataExtracted, onError, disabled }: CardiologyVoiceButtonProps) {
    const [isRecording, setIsRecording] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const [quotaInfo, setQuotaInfo] = useState<AIQuotaInfo | null>(null);
    const [error, setError] = useState<string>('');
    const [filledCount, setFilledCount] = useState<number | null>(null);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        fetchAIQuota().then(q => { if (q) setQuotaInfo(q); });
    }, []);

    useEffect(() => {
        if (isRecording) {
            timerIntervalRef.current = setInterval(() => {
                setRecordingTime(prev => {
                    const newTime = prev + 1;
                    if (newTime >= MAX_RECORDING_SECONDS) {
                        stopRecording();
                        return MAX_RECORDING_SECONDS;
                    }
                    return newTime;
                });
            }, 1000);
        } else {
            if (timerIntervalRef.current) {
                clearInterval(timerIntervalRef.current);
                timerIntervalRef.current = null;
            }
            setRecordingTime(0);
        }
        return () => {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        };
    }, [isRecording]);

    const formatTime = useCallback((seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }, []);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });

            mediaRecorderRef.current = mediaRecorder;
            audioChunksRef.current = [];

            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) audioChunksRef.current.push(event.data);
            };

            mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                await processAudio(audioBlob);
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorder.start();
            setIsRecording(true);
            setError('');
            setFilledCount(null);
        } catch (err: any) {
            const errorMsg = 'Impossible d\'accéder au microphone. Vérifiez les permissions.';
            setError(errorMsg);
            if (onError) onError(errorMsg);
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const processAudio = async (audioBlob: Blob) => {
        setIsProcessing(true);
        setError('');

        const result = await generateCardiologyReportFromAudio(audioBlob);

        if (result.success && result.data) {
            const { cardiology_data, transcription, quota } = result.data;
            setQuotaInfo(quota);

            // Count how many fields were filled
            const { additional_info, ...formFields } = cardiology_data;
            const filled = Object.entries(formFields).filter(([, v]) => {
                if (v === null || v === undefined || v === false) return false;
                if (typeof v === 'string' && v === '') return false;
                if (Array.isArray(v) && v.length === 0) return false;
                return true;
            }).length;
            setFilledCount(filled);

            onDataExtracted(formFields as Partial<CardiologyFormData>, additional_info ?? null, transcription);
        } else {
            setError(result.error || 'Erreur lors de l\'extraction');
            if (onError) onError(result.error || 'Erreur');
        }

        setIsProcessing(false);
    };

    const isDisabled = disabled || isRecording || isProcessing || (quotaInfo?.remaining === 0);

    return (
        <div className="space-y-3">
            {/* Error */}
            {error && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-2.5">
                    <p className="text-xs text-red-800 dark:text-red-400">{error}</p>
                </div>
            )}

            {/* Success feedback */}
            {filledCount !== null && !isProcessing && !isRecording && !error && (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-2.5 flex items-center gap-2">
                    <span className="text-green-600 text-sm">✓</span>
                    <p className="text-xs text-green-800 dark:text-green-400">
                        <strong>{filledCount} champ{filledCount > 1 ? 's' : ''}</strong> rempli{filledCount > 1 ? 's' : ''} automatiquement
                    </p>
                </div>
            )}

            {/* Controls */}
            <div className="flex items-center gap-3">
                {!isRecording && !isProcessing && (
                    <button
                        onClick={startRecording}
                        disabled={isDisabled}
                        className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                            isDisabled
                                ? 'bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
                                : 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-md hover:shadow-lg transform hover:scale-[1.02] active:scale-95'
                        }`}
                    >
                        <MicrophoneIcon className="w-5 h-5" />
                        <span>Dicter les valeurs</span>
                        <span className="text-[10px] opacity-80 bg-white/20 rounded px-1.5 py-0.5">IA</span>
                    </button>
                )}

                {isRecording && (
                    <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2 bg-red-50 dark:bg-red-900/20 rounded-xl px-4 py-2.5">
                            <div className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
                            <span className="text-lg font-mono font-bold text-red-600 dark:text-red-400">
                                {formatTime(recordingTime)}
                            </span>
                            <span className="text-[10px] text-gray-400">/ {formatTime(MAX_RECORDING_SECONDS)}</span>
                        </div>
                        <button
                            onClick={stopRecording}
                            className="flex items-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-medium shadow-md transition-all"
                        >
                            <StopIcon className="w-5 h-5" />
                            Arrêter
                        </button>
                    </div>
                )}

                {isProcessing && (
                    <div className="flex items-center gap-3 px-4 py-2.5">
                        <div className="animate-spin rounded-full h-5 w-5 border-2 border-red-500 border-t-transparent" />
                        <div>
                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Extraction en cours...</p>
                            <p className="text-[10px] text-gray-400">Transcription + analyse IA des valeurs</p>
                        </div>
                    </div>
                )}

                {/* Quota mini badge */}
                {quotaInfo && !isRecording && !isProcessing && (
                    <span className={`text-[10px] px-2 py-1 rounded-full ${
                        quotaInfo.remaining > 5
                            ? 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
                            : quotaInfo.remaining > 0
                                ? 'bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-400'
                                : 'bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400'
                    }`}>
                        {quotaInfo.remaining}/{quotaInfo.max} restant{quotaInfo.remaining > 1 ? 's' : ''}
                    </span>
                )}
            </div>

            {!isRecording && !isProcessing && (
                <p className="text-[10px] text-gray-400 dark:text-gray-500">
                    Dictez les valeurs du patient : tension, FC, FEVG, antécédents, biologie... Les champs se remplissent automatiquement.
                </p>
            )}
            {isRecording && (
                <p className="text-[10px] text-gray-500 dark:text-gray-400 animate-pulse">
                    🎤 Parlez clairement... Ex: &quot;Tension 14/8, fréquence cardiaque 72, FEVG 55%, patient hypertendu diabétique, BNP à 450...&quot;
                </p>
            )}
        </div>
    );
}
