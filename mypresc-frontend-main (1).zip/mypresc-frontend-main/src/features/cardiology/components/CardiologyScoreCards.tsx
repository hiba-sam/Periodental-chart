'use client';

import { useState } from 'react';
import { ChevronDownIcon, ChevronUpIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';
import type { ScoreResult } from '@/utils/cardiologyScores';
import { RISK_LABELS } from '@/utils/cardiologyScores';

interface CardiologyScoreCardsProps {
    scores: ScoreResult[];
}

const COLOR_MAP: Record<string, { bg: string; text: string; border: string; dot: string }> = {
    green: {
        bg: 'bg-green-50 dark:bg-green-900/20',
        text: 'text-green-700 dark:text-green-400',
        border: 'border-green-200 dark:border-green-800',
        dot: 'bg-green-500',
    },
    yellow: {
        bg: 'bg-yellow-50 dark:bg-yellow-900/20',
        text: 'text-yellow-700 dark:text-yellow-400',
        border: 'border-yellow-200 dark:border-yellow-800',
        dot: 'bg-yellow-500',
    },
    orange: {
        bg: 'bg-orange-50 dark:bg-orange-900/20',
        text: 'text-orange-700 dark:text-orange-400',
        border: 'border-orange-200 dark:border-orange-800',
        dot: 'bg-orange-500',
    },
    red: {
        bg: 'bg-red-50 dark:bg-red-900/20',
        text: 'text-red-700 dark:text-red-400',
        border: 'border-red-200 dark:border-red-800',
        dot: 'bg-red-500',
    },
    gray: {
        bg: 'bg-gray-50 dark:bg-gray-800',
        text: 'text-gray-400 dark:text-gray-500',
        border: 'border-gray-200 dark:border-gray-700',
        dot: 'bg-gray-400',
    },
};

function ScoreCard({ score }: { score: ScoreResult }) {
    const [expanded, setExpanded] = useState(false);
    const colors = COLOR_MAP[score.color] || COLOR_MAP.gray;
    const isCalculable = score.value != null;

    return (
        <div className={`rounded-xl border ${colors.border} ${colors.bg} p-4 transition-all`}>
            {/* Header */}
            <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${colors.dot}`} />
                    <h4 className="text-sm font-semibold text-gray-800 dark:text-gray-200">{score.label}</h4>
                </div>
                {isCalculable && score.details.length > 0 && (
                    <button
                        onClick={() => setExpanded(!expanded)}
                        className="text-xs text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 flex items-center gap-1 transition-colors"
                    >
                        Détail
                        {expanded ? <ChevronUpIcon className="w-3 h-3" /> : <ChevronDownIcon className="w-3 h-3" />}
                    </button>
                )}
            </div>

            {/* Value */}
            {isCalculable ? (
                <div className="flex items-baseline gap-2">
                    <span className={`text-2xl font-bold ${colors.text}`}>
                        {score.label === 'Framingham' || score.label === 'SCORE2' || score.label === 'SCORE2-OP' || score.label === 'EuroSCORE II'
                            ? `${score.value}%`
                            : score.label === 'NYHA'
                            ? `Classe ${score.value}`
                            : `${score.value}`}
                    </span>
                    {score.maxValue && score.label !== 'NYHA' && score.label !== 'Framingham' && score.label !== 'SCORE2' && score.label !== 'SCORE2-OP' && score.label !== 'EuroSCORE II' && (
                        <span className="text-xs text-gray-400">/ {score.maxValue}</span>
                    )}
                </div>
            ) : (
                <div className="flex items-center gap-2 mt-1">
                    <ExclamationCircleIcon className="w-4 h-4 text-gray-400" />
                    <span className="text-xs text-gray-400">
                        Champs manquants : {score.missingFields.join(', ')}
                    </span>
                </div>
            )}

            {/* Risk level */}
            {isCalculable && score.level && (
                <div className={`mt-1 text-xs font-medium ${colors.text}`}>
                    Risque : {RISK_LABELS[score.level] || score.level}
                </div>
            )}

            {/* Expanded details */}
            {expanded && score.details.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700 space-y-1.5">
                    {score.details.map((detail, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs">
                            <span className={detail.present ? 'text-gray-700 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'}>
                                {detail.present ? '✓' : '○'} {detail.criterion}
                            </span>
                            <span className={`font-mono ${detail.present ? colors.text : 'text-gray-400'}`}>
                                +{detail.points}
                            </span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default function CardiologyScoreCards({ scores }: CardiologyScoreCardsProps) {
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 items-start">
            {scores.map((score, idx) => (
                <ScoreCard key={idx} score={score} />
            ))}
        </div>
    );
}
