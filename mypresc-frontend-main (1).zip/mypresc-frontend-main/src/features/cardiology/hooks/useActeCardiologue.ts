import axios from 'axios';
import type { ActeCardiologue, ActeCardiologueFormData } from '../types/cardiologue';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

export const acteCardiologueKeys = {
    all: ['actes-cardiologue'] as const,
    byPatient: (patientId: string) => ['actes-cardiologue', 'patient', patientId] as const,
    byId: (id: number) => ['actes-cardiologue', id] as const,
};

export async function fetchActesCardiologue(patientId: string): Promise<ActeCardiologue[]> {
    const { data } = await axios.get(`${API_URL}/api/patients/${patientId}/actes-cardiologue`, { withCredentials: true });
    return data.data || [];
}

export async function fetchActeCardiologue(id: number): Promise<ActeCardiologue> {
    const { data } = await axios.get(`${API_URL}/api/actes-cardiologue/${id}`, { withCredentials: true });
    return data.data;
}

export async function createActeCardiologue(patientId: string, formData: ActeCardiologueFormData): Promise<ActeCardiologue> {
    const { data } = await axios.post(`${API_URL}/api/patients/${patientId}/actes-cardiologue`, formData, { withCredentials: true });
    return data.data;
}

export async function updateActeCardiologue(id: number, formData: Partial<ActeCardiologueFormData>): Promise<ActeCardiologue> {
    const { data } = await axios.put(`${API_URL}/api/actes-cardiologue/${id}`, formData, { withCredentials: true });
    return data.data;
}

export async function deleteActeCardiologue(id: number): Promise<void> {
    await axios.delete(`${API_URL}/api/actes-cardiologue/${id}`, { withCredentials: true });
}
