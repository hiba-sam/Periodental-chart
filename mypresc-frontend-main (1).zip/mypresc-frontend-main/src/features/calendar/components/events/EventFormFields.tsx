// EventFormFields - Common form fields for all event types
'use client';

import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import ColorSelect from '@/components/ui/ColorSelect';
import type { EventFormData } from './useEventForm';

interface EventFormFieldsProps {
    formData: EventFormData;
    errors: Record<string, string>;
    timeOptions: { value: string; label: string }[];
    durationOptions: { value: number; label: string }[];
    eventType: 'patient' | 'free';
    hideDateInput?: boolean;
    onChange: (field: keyof EventFormData, value: unknown) => void;
}

/**
 * Get today's date in YYYY-MM-DD format for min date validation
 */
const getTodayDateString = (): string => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

/**
 * Common form fields component
 */
export function EventFormFields({
    formData,
    errors,
    timeOptions,
    durationOptions,
    eventType,
    hideDateInput = false,
    onChange,
}: EventFormFieldsProps) {
    const { t } = useLanguage();

    return (
        <>
            {/* Date and Time Row */}
            <div className={hideDateInput ? "grid grid-cols-1 gap-4" : "grid grid-cols-2 gap-4"}>
                {/* Date */}
                {!hideDateInput && (
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            {t('calendar.date')} <span className="text-red-500">*</span>
                        </label>
                        <input
                            type="date"
                            value={formData.date}
                            min={getTodayDateString()}
                            onChange={(e) => onChange('date', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        {errors.date && <p className="mt-1 text-sm text-red-600">{errors.date}</p>}
                    </div>
                )}

                {/* Time */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {t('calendar.time')} <span className="text-red-500">*</span>
                    </label>
                    <select
                        value={formData.time}
                        onChange={(e) => onChange('time', e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                        <option value="">{t('calendar.selectTime')}</option>
                        {timeOptions.map((option) => (
                            <option key={option.value} value={option.value}>
                                {option.label}
                            </option>
                        ))}
                    </select>
                    {errors.time && <p className="mt-1 text-sm text-red-600">{errors.time}</p>}
                </div>
            </div>

            {/* Duration */}
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('calendar.duration')}
                </label>
                <select
                    value={formData.duration}
                    onChange={(e) => onChange('duration', Number(e.target.value))}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                    {durationOptions.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>
            </div>

            {/* Color */}
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('calendar.color')}
                </label>
                <ColorSelect
                    color={formData.color}
                    setColor={(color) => onChange('color', color)}
                />
            </div>

            {/* Notes */}
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {eventType === 'patient' ? t('calendar.consultationNotes') : t('calendar.description')}
                </label>
                <textarea
                    value={formData.notes}
                    onChange={(e) => onChange('notes', e.target.value)}
                    placeholder={
                        eventType === 'patient'
                            ? t('calendar.consultationNotesPlaceholder')
                            : t('calendar.descriptionPlaceholder')
                    }
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
            </div>
        </>
    );
}

export default EventFormFields;
