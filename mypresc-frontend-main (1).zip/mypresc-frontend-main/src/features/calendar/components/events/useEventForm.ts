// useEventForm - Form state and validation hook for event creation/editing
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { useCalendar, type CalendarEvent, type CreateEventData, type UpdateEventData } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePatients, type ApiPatient } from '@/contexts/PatientsContext';
import { COLORS } from '@/components/ui/ColorSelect';

// =============================================================================
// TYPES
// =============================================================================

export type EventType = 'patient' | 'free' | null;

export interface EventFormData {
    // Common fields
    date: string;
    time: string;
    duration: number;
    color: string;
    notes: string;
    // Patient appointment fields
    patientId: string;
    patient_name: string;
    patient_family_name: string;
    confirmedComing: boolean;
    // Free event fields
    title: string;
}

export interface PreselectedPatient {
    id: string;
    name: string;
    familyName: string;
}

export interface UseEventFormOptions {
    isOpen: boolean;
    editEvent?: CalendarEvent | null;
    initialDate?: Date;
    initialTime?: string;
    preselectedPatient?: PreselectedPatient | null;
    preselectedEventType?: 'patient' | null;
    onSuccess?: (wasCreation: boolean) => void;
}

// =============================================================================
// HELPERS
// =============================================================================

const getRandomColor = (): string => {
    const randomIndex = Math.floor(Math.random() * COLORS.length);
    return COLORS[randomIndex]?.value || '#2563eb';
};

const formatDateString = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const parseLocalDate = (dateString: string): Date => {
    if (dateString.includes('T')) {
        const date = new Date(dateString);
        return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year!, month! - 1, day!);
};

const getInitialFormData = (): EventFormData => ({
    date: '',
    time: '',
    duration: 30,
    color: getRandomColor(),
    notes: '',
    patientId: '',
    patient_name: '',
    patient_family_name: '',
    confirmedComing: false,
    title: '',
});

// =============================================================================
// HOOK
// =============================================================================

export function useEventForm(options: UseEventFormOptions) {
    const {
        isOpen,
        editEvent,
        initialDate,
        initialTime,
        preselectedPatient,
        preselectedEventType,
        onSuccess,
    } = options;

    const { createEvent, updateEvent, loading } = useCalendar();
    const { t } = useLanguage();
    const { searchPatients, getPatient } = usePatients();

    // Form state
    const [eventType, setEventType] = useState<EventType>(null);
    const [formData, setFormData] = useState<EventFormData>(getInitialFormData());
    const [patientSearch, setPatientSearch] = useState('');
    const [serverResults, setServerResults] = useState<ApiPatient[] | null>(null);
    const [showPatientDropdown, setShowPatientDropdown] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Duration options with translations
    const durationOptions = useMemo(() => [
        { value: 15, label: t('calendar.duration15') },
        { value: 30, label: t('calendar.duration30') },
        { value: 45, label: t('calendar.duration45') },
        { value: 60, label: t('calendar.duration60') },
        { value: 90, label: t('calendar.duration90') },
        { value: 120, label: t('calendar.duration120') },
    ], [t]);

    // Time options (8:00 - 20:00, 15min intervals)
    const timeOptions = useMemo(() => {
        const options: { value: string; label: string }[] = [];
        for (let hour = 8; hour <= 20; hour++) {
            for (let minute = 0; minute < 60; minute += 15) {
                if (hour === 20 && minute > 0) break;
                const timeValue = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
                options.push({ value: timeValue, label: timeValue });
            }
        }
        return options;
    }, []);

    // Initialize form when modal opens
    useEffect(() => {
        const initializeForm = async () => {
            if (!isOpen) return;

            if (editEvent) {
                // Edit mode
                const isPatientAppointment = !!editEvent.patientId;
                setEventType(isPatientAppointment ? 'patient' : 'free');

                let patientName = editEvent.patientName || '';
                let patientFamilyName = editEvent.patientFamilyName || '';

                // Fetch patient data if missing
                if (isPatientAppointment && editEvent.patientId && (!patientName || !patientFamilyName)) {
                    try {
                        const patientData = await getPatient(editEvent.patientId);
                        if (patientData) {
                            patientName = patientData.name || '';
                            patientFamilyName = patientData.family_name || '';
                        }
                    } catch (error) {
                        console.error('Error fetching patient data:', error);
                    }
                }

                setFormData({
                    date: formatDateString(editEvent.date),
                    time: editEvent.time,
                    duration: editEvent.duration,
                    notes: editEvent.description || '',
                    color: editEvent.color,
                    patientId: editEvent.patientId || '',
                    patient_name: patientName,
                    patient_family_name: patientFamilyName,
                    confirmedComing: editEvent.confirmedComing as boolean,
                    title: isPatientAppointment ? `${patientName} ${patientFamilyName}` : editEvent.title,
                });
                setPatientSearch(isPatientAppointment ? `${patientName} ${patientFamilyName}`.trim() : '');
            } else {
                // Create mode
                const now = new Date();
                const defaultDate = initialDate || now;
                const defaultTime = initialTime || `${String(now.getHours()).padStart(2, '0')}:00`;

                if (preselectedPatient && preselectedEventType === 'patient') {
                    setEventType('patient');
                    setFormData({
                        ...getInitialFormData(),
                        date: formatDateString(defaultDate),
                        time: defaultTime,
                        patientId: preselectedPatient.id,
                        patient_name: preselectedPatient.name,
                        patient_family_name: preselectedPatient.familyName,
                    });
                    setPatientSearch(`${preselectedPatient.name} ${preselectedPatient.familyName}`);
                } else {
                    setEventType(null);
                    setFormData({
                        ...getInitialFormData(),
                        date: formatDateString(defaultDate),
                        time: defaultTime,
                    });
                    setPatientSearch('');
                }
            }
            setErrors({});
        };

        initializeForm();
    }, [isOpen, editEvent, initialDate, initialTime, getPatient, preselectedPatient, preselectedEventType]);

    // Debounced patient search
    useEffect(() => {
        if (!patientSearch.trim()) {
            setServerResults(null);
            return;
        }
        const id = setTimeout(async () => {
            const results = await searchPatients(patientSearch.trim(), 10);
            setServerResults(results);
        }, 300);
        return () => clearTimeout(id);
    }, [patientSearch, searchPatients]);

    // Handlers
    const handleInputChange = useCallback((field: keyof EventFormData, value: unknown) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        if (errors[field]) {
            setErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors[field];
                return newErrors;
            });
        }
    }, [errors]);

    const handlePatientSelect = useCallback((patient: ApiPatient) => {
        setFormData(prev => ({
            ...prev,
            patientId: patient.id,
            patient_name: patient.name || '',
            patient_family_name: patient.family_name || '',
        }));
        setPatientSearch(`${patient.name} ${patient.family_name}`);
        setShowPatientDropdown(false);
        if (errors.patientId) {
            setErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors.patientId;
                return newErrors;
            });
        }
    }, [errors.patientId]);

    const handlePatientClear = useCallback(() => {
        setFormData(prev => ({
            ...prev,
            patientId: '',
            patient_name: '',
            patient_family_name: '',
        }));
        setPatientSearch('');
        setShowPatientDropdown(false);
    }, []);

    const validateForm = useCallback((): boolean => {
        const newErrors: Record<string, string> = {};

        if (eventType === 'patient' && !formData.patientId) {
            newErrors.patientId = t('calendar.patientRequired');
        } else if (eventType === 'free' && !formData.title) {
            newErrors.title = t('calendar.titleRequired');
        }

        if (!formData.date) {
            newErrors.date = t('calendar.dateRequired');
        } else {
            const selectedDate = new Date(formData.date);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            selectedDate.setHours(0, 0, 0, 0);
            if (selectedDate < today) {
                newErrors.date = t('calendar.pastDateError');
            }
        }

        if (!formData.time) {
            newErrors.time = t('calendar.timeRequired');
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    }, [eventType, formData, t]);

    const handleSubmit = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validateForm()) return;

        setIsSubmitting(true);
        try {
            let result: CalendarEvent | null = null;

            if (editEvent) {
                const updateData: UpdateEventData = {
                    title: formData.title,
                    id: editEvent.id,
                    date: parseLocalDate(formData.date),
                    time: formData.time,
                    duration: formData.duration,
                    note: formData.notes,
                    color: formData.color,
                    confirmed_coming: formData.confirmedComing || false,
                    is_done: editEvent.isDone || false,
                };
                result = await updateEvent(updateData);
                if (result) onSuccess?.(false);
            } else {
                const createData: CreateEventData = eventType === 'patient'
                    ? {
                        patientId: formData.patientId,
                        date: parseLocalDate(formData.date),
                        time: formData.time,
                        duration: formData.duration,
                        notes: formData.notes,
                        color: formData.color,
                        confirmedComing: formData.confirmedComing,
                    }
                    : {
                        title: formData.title,
                        date: parseLocalDate(formData.date),
                        time: formData.time,
                        duration: formData.duration,
                        notes: `${formData.title}\n${formData.notes}`,
                        color: formData.color,
                        confirmedComing: false,
                    };
                result = await createEvent(createData);
                if (result) onSuccess?.(true);
            }
        } catch (error) {
            console.error('Error submitting event:', error);
        } finally {
            setIsSubmitting(false);
        }
    }, [editEvent, eventType, formData, validateForm, createEvent, updateEvent, onSuccess]);

    const resetForm = useCallback(() => {
        setEventType(null);
        setFormData(getInitialFormData());
        setPatientSearch('');
        setErrors({});
    }, []);

    return {
        // State
        eventType,
        formData,
        patientSearch,
        serverResults,
        showPatientDropdown,
        errors,
        isSubmitting,
        isLoading: loading,

        // Options
        durationOptions,
        timeOptions,

        // Computed
        isEditMode: !!editEvent,
        hasPreselectedPatient: !!preselectedPatient,

        // Setters
        setEventType,
        setPatientSearch,
        setShowPatientDropdown,

        // Handlers
        handleInputChange,
        handlePatientSelect,
        handlePatientClear,
        handleSubmit,
        resetForm,
    };
}

export default useEventForm;
