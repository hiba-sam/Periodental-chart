// PatientSearchField - Patient search input with dropdown
'use client';

import React from 'react';
import { MagnifyingGlassIcon, UserIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import type { ApiPatient } from '@/contexts/PatientsContext';

interface PatientSearchFieldProps {
    patientId: string;
    patientName: string;
    patientFamilyName: string;
    searchValue: string;
    searchResults: ApiPatient[] | null;
    showDropdown: boolean;
    error?: string;
    onSearchChange: (query: string) => void;
    onSearchFocus: () => void;
    onSelect: (patient: ApiPatient) => void;
    onClear: () => void;
}

/**
 * Patient search field with autocomplete dropdown
 */
export function PatientSearchField({
    patientId,
    patientName,
    patientFamilyName,
    searchValue,
    searchResults,
    showDropdown,
    error,
    onSearchChange,
    onSearchFocus,
    onSelect,
    onClear,
}: PatientSearchFieldProps) {
    const { t } = useLanguage();

    return (
        <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('calendar.patient')} <span className="text-red-500">*</span>
            </label>

            <div className="relative">
                {!patientId ? (
                    <>
                        {/* Search Input */}
                        <div className="relative">
                            <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                value={searchValue}
                                onChange={(e) => onSearchChange(e.target.value)}
                                onFocus={onSearchFocus}
                                placeholder={t('calendar.searchPatientPlaceholder')}
                                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                        </div>

                        {/* Patient Dropdown */}
                        {showDropdown && searchResults && searchResults.length > 0 && (
                            <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                {searchResults.map((patient) => (
                                    <button
                                        key={patient.id}
                                        type="button"
                                        onClick={() => onSelect(patient)}
                                        className="w-full px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 focus:bg-gray-50 dark:focus:bg-gray-700/50 focus:outline-none border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                                    >
                                        <div className="flex items-center gap-3">
                                            <UserIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                                            <div>
                                                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                                    {patient.name} {patient.family_name}
                                                </p>
                                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                                    {patient.age} {t('calendar.years')}
                                                </p>
                                            </div>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        )}
                    </>
                ) : (
                    /* Selected Patient Display */
                    <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-md">
                        <UserIcon className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                        <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                {patientName} {patientFamilyName}
                            </p>
                        </div>
                        <button
                            type="button"
                            onClick={onClear}
                            className="p-1 hover:bg-blue-100 dark:hover:bg-blue-800/30 rounded-full transition-colors"
                        >
                            <XMarkIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                        </button>
                    </div>
                )}
            </div>

            {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
        </div>
    );
}

export default PatientSearchField;
