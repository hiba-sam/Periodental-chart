/**
 * DraggableEvent.tsx
 *
 * Wrapper component that makes calendar events draggable.
 * Provides visual feedback during dragging and handles drag state.
 * Implements smart click vs drag detection using dnd-kit's PointerSensor.
 */

'use client';

import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import type { CalendarEvent } from '../../types';

interface DraggableEventProps {
    event: CalendarEvent;
    children: React.ReactNode;
    isDraggingAny: boolean;
    style?: React.CSSProperties;
    className?: string;
    onClick?: (e: React.MouseEvent) => void;
}

/**
 * Makes a calendar event draggable with smart click detection
 */
export function DraggableEvent({
    event,
    children,
    isDraggingAny,
    style = {},
    className = '',
    onClick,
}: DraggableEventProps) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        isDragging,
    } = useDraggable({
        id: event.id,
        data: {
            event,
            type: 'calendar-event',
        },
    });

    /**
     * Handle click on event
     */
    const handleClick = (e: React.MouseEvent) => {
        if (!isDragging && !isDraggingAny && onClick) {
            e.stopPropagation();
            onClick(e);
        }
    };

    // Apply transform for drag feedback
    const dragStyle: React.CSSProperties = {
        ...style,
        transform: CSS.Translate.toString(transform),
        opacity: isDragging ? 0.5 : 1,
        cursor: isDragging ? 'grabbing' : 'grab',
        zIndex: isDragging ? 1000 : style.zIndex || 30,
        transition: isDragging ? 'none' : 'all 150ms ease',
        userSelect: 'none',
        WebkitUserSelect: 'none',
    };

    return (
        <div
            ref={setNodeRef}
            style={dragStyle}
            {...listeners}
            {...attributes}
            className={className}
            onClick={handleClick}
        >
            {children}
        </div>
    );
}

export default DraggableEvent;
