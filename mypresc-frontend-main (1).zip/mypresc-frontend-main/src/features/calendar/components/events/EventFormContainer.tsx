// EventFormContainer - Main event modal container
'use client';

import React from 'react';
import Modal from '@/components/ui/Modal';
import { useLanguage } from '@/contexts/LanguageContext';
import { type CalendarEvent } from '@/contexts/CalendarContext';
import { useEventForm, type PreselectedPatient } from './useEventForm';
import { EventTypeSelector } from './EventTypeSelector';
import { AppointmentForm } from './AppointmentForm';
import { StandaloneEventForm } from './StandaloneEventForm';

interface EventFormContainerProps {
    isOpen: boolean;
    onClose: (wasSuccessfulCreation?: boolean) => void;
    initialDate?: Date;
    initialTime?: string;
    editEvent?: CalendarEvent | null;
    hideDateInput?: boolean;
    preselectedPatient?: PreselectedPatient | null;
    preselectedEventType?: 'patient' | null;
}

/**
 * Main event form container with type selection and form rendering
 */
export function EventFormContainer({
    isOpen,
    onClose,
    initialDate,
    initialTime,
    editEvent,
    hideDateInput = false,
    preselectedPatient = null,
    preselectedEventType = null,
}: EventFormContainerProps) {
    const { t } = useLanguage();

    const form = useEventForm({
        isOpen,
        editEvent,
        initialDate,
        initialTime,
        preselectedPatient,
        preselectedEventType,
        onSuccess: (wasCreation) => onClose(wasCreation),
    });

    // Show type selector for new events without preselected type
    if (!editEvent && form.eventType === null) {
        return (
            <EventTypeSelector
                isOpen={isOpen}
                onClose={() => onClose(false)}
                onSelect={form.setEventType}
            />
        );
    }

    // Get modal title
    const getTitle = () => {
        if (editEvent) return t('calendar.editAppointment');
        return form.eventType === 'patient'
            ? t('calendar.patientAppointment')
            : t('calendar.freeEvent');
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={() => onClose(false)}
            title={getTitle()}
            closeOnBackdrop={false}
        >
            <form onSubmit={form.handleSubmit} className="space-y-5">
                {form.eventType === 'patient' ? (
                    <AppointmentForm
                        formData={form.formData}
                        errors={form.errors}
                        timeOptions={form.timeOptions}
                        durationOptions={form.durationOptions}
                        patientSearch={form.patientSearch}
                        serverResults={form.serverResults}
                        showPatientDropdown={form.showPatientDropdown}
                        preselectedPatient={preselectedPatient}
                        isEditMode={form.isEditMode}
                        hideDateInput={hideDateInput}
                        onInputChange={form.handleInputChange}
                        onPatientSearchChange={(query) => {
                            form.setPatientSearch(query);
                            form.setShowPatientDropdown(true);
                        }}
                        onPatientSearchFocus={() => form.setShowPatientDropdown(true)}
                        onPatientSelect={form.handlePatientSelect}
                        onPatientClear={form.handlePatientClear}
                        onBack={() => form.setEventType(null)}
                    />
                ) : (
                    <StandaloneEventForm
                        formData={form.formData}
                        errors={form.errors}
                        timeOptions={form.timeOptions}
                        durationOptions={form.durationOptions}
                        isEditMode={form.isEditMode}
                        hideDateInput={hideDateInput}
                        onInputChange={form.handleInputChange}
                        onBack={() => form.setEventType(null)}
                    />
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <button
                        type="button"
                        onClick={() => onClose(false)}
                        className="flex-1 px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                        disabled={form.isSubmitting || form.isLoading}
                    >
                        {t('calendar.cancel')}
                    </button>
                    <button
                        type="submit"
                        className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={form.isSubmitting || form.isLoading}
                    >
                        {form.isSubmitting || form.isLoading
                            ? t('calendar.loading')
                            : editEvent
                                ? t('calendar.update')
                                : t('calendar.create')}
                    </button>
                </div>
            </form>
        </Modal>
    );
}

export default EventFormContainer;
