// UpdateConfirmModal.tsx - Confirmation dialog for event update notification
'use client';

import React from 'react';
import Modal from '@/components/ui/Modal';
import { useLanguage } from '@/contexts/LanguageContext';
import { InformationCircleIcon, PhoneIcon } from '@heroicons/react/24/outline';
import { usePatients } from '@/contexts/PatientsContext';
import type { CalendarEvent } from '../types';

interface UpdateConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSkip: () => void;
    event: CalendarEvent | null;
}

/**
 * Confirmation modal for updating calendar events (prompts to call patient)
 */
export function UpdateConfirmModal({
    isOpen,
    onClose,
    onSkip,
    event,
}: UpdateConfirmModalProps) {
    const { t, language } = useLanguage();
    const { patients } = usePatients();

    if (!event) return null;

    const patientData = patients.find((p) => p.id === event.patientId);
    const displayPhone = event.patientPhone || patientData?.telephone;

    const formatDate = (date: Date): string => {
        const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        return date.toLocaleDateString(locale, {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="" closeOnBackdrop={false}>
            <div className="space-y-5">
                {/* Info Icon */}
                <div className="flex justify-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                        <InformationCircleIcon className="w-10 h-10 text-blue-600" />
                    </div>
                </div>

                {/* Title */}
                <div className="text-center">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
                        {t('calendar.updateAppointmentTitle') || 'Modifier le rendez-vous ?'}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                        {t('calendar.patientNotNotifiedUpdate') || 'Le patient ne sera pas notifié de la modification. Pensez à le contacter si nécessaire.'}
                    </p>
                </div>

                {/* Event Details Summary */}
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 space-y-2">
                    <div className="flex items-start gap-3">
                        <div className="flex-1">
                            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{event.title}</p>
                            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{formatDate(event.date)}</p>
                            <p className="text-xs text-gray-600 dark:text-gray-400">
                                {event.time} - {event.endTime} ({event.duration} {t('calendar.min')})
                            </p>
                        </div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                        type="button"
                        onClick={onSkip}
                        className="flex-1 px-4 py-2.5 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors font-medium order-2 sm:order-1"
                    >
                        {t('calendar.skip') || 'Ignorer'}
                    </button>
                    {displayPhone && (
                        <a
                            href={`tel:${displayPhone}`}
                            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-green-500 text-white rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors font-medium order-1 sm:order-2"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <PhoneIcon className="w-5 h-5" />
                            <span>{t('calendar.callPatient') || 'Appeler le patient'}</span>
                        </a>
                    )}
                </div>
            </div>
        </Modal>
    );
}

export default UpdateConfirmModal;
