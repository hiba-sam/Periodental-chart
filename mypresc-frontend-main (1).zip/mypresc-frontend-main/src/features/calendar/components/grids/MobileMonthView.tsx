// MobileMonthView — Mobile-optimised calendar month grid
// Shows a compact Google Calendar–style grid with single-letter day headers.
// Tapping a day selects it and shows that day's events below the grid.
// No view switching or event-creation controls on mobile.
'use client';

import React, { useState, useCallback, useMemo } from 'react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';

// ─── Types ────────────────────────────────────────────────────────────────────

interface MobileMonthViewProps {
    /** Called when the user taps an event in the day events list */
    onEventClick: (event: CalendarEvent) => void;
}

interface MobileDayCell {
    date: Date;
    dayNumber: number;
    isCurrentMonth: boolean;
    isToday: boolean;
    isPast: boolean;
    events: CalendarEvent[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isSameDay(a: Date, b: Date) {
    return (
        a.getDate() === b.getDate() &&
        a.getMonth() === b.getMonth() &&
        a.getFullYear() === b.getFullYear()
    );
}

function isSameMonth(a: Date, b: Date) {
    return a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear();
}

/** Sunday-start week as shown in the screenshot */
const WEEK_DAY_LETTERS_EN = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
const WEEK_DAY_LETTERS_FR = ['D', 'L', 'M', 'M', 'J', 'V', 'S'];
const WEEK_DAY_LETTERS_AR = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

function getWeekDayLetters(language: string) {
    if (language === 'ar') return WEEK_DAY_LETTERS_AR;
    if (language === 'fr') return WEEK_DAY_LETTERS_FR;
    return WEEK_DAY_LETTERS_EN;
}

/** Abbreviated weekday label for selected day header (e.g., "FRI") */
function formatDayLabel(date: Date, language: string): string {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    return date
        .toLocaleDateString(locale, { weekday: 'short' })
        .toUpperCase()
        .replace(/\.$/, ''); // remove trailing dot (French)
}

/** Month-year label for the calendar header (e.g., "MAR", "MARCH 2026") */
function formatMonthLabel(date: Date, language: string): string {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    return date
        .toLocaleDateString(locale, { month: 'long', year: 'numeric' })
        .toUpperCase();
}

/** Build 42 calendar cells (6 weeks) starting from the Sunday before the month start */
function buildCells(
    selectedDate: Date,
    events: CalendarEvent[],
): MobileDayCell[] {
    const monthStart = new Date(
        selectedDate.getFullYear(),
        selectedDate.getMonth(),
        1,
    );
    // Sunday-start: getDay() returns 0 for Sunday → diff = 0
    const startDay = monthStart.getDay(); // 0=Sun
    const calStart = new Date(monthStart);
    calStart.setDate(1 - startDay);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const cells: MobileDayCell[] = [];
    const cur = new Date(calStart);

    for (let i = 0; i < 42; i++) {
        const dayEvents = events.filter((ev) => isSameDay(ev.date, cur));
        const d = new Date(cur);
        cells.push({
            date: d,
            dayNumber: d.getDate(),
            isCurrentMonth: isSameMonth(d, selectedDate),
            isToday: isSameDay(d, today),
            isPast: d < today,
            events: dayEvents,
        });
        cur.setDate(cur.getDate() + 1);
    }
    return cells;
}

/** Format time range for an event (e.g., "09:00 – 09:30") */
function formatEventTime(event: CalendarEvent, t: (k: string) => string): string {
    if (!event.time) return t('calendar.allDay');
    const end = event.endTime;
    if (end) return `${event.time} – ${end}`;
    return event.time;
}

// ─── Event colour dot ─────────────────────────────────────────────────────────

function ColorBar({ color }: { color: string }) {
    return (
        <div
            className="w-3 h-3 rounded-full flex-shrink-0"
            style={{ backgroundColor: color || '#2563eb' }}
        />
    );
}

// ─── Component ────────────────────────────────────────────────────────────────

export function MobileMonthView({ onEventClick }: MobileMonthViewProps) {
    const {
        selectedDate,
        setSelectedDate,
        getEventsForMonth,
        goToToday,
        goPrevious,
        goNext,
    } = useCalendar();
    const { t, language, isRTL } = useLanguage();

    // Which day's events to show below the grid (defaults to today or selectedDate)
    const [selectedDay, setSelectedDay] = useState<Date>(() => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return today;
    });

    const weekDayLetters = getWeekDayLetters(language);
    const monthLabel = useMemo(
        () => formatMonthLabel(selectedDate, language),
        [selectedDate, language],
    );

    // All events for this month
    const monthEvents = useMemo(
        () => getEventsForMonth(selectedDate),
        [getEventsForMonth, selectedDate],
    );

    // 42 calendar cells
    const cells = useMemo(
        () => buildCells(selectedDate, monthEvents),
        [selectedDate, monthEvents],
    );

    // Events for the selected day
    const selectedDayEvents = useMemo(
        () => monthEvents.filter((ev) => isSameDay(ev.date, selectedDay)),
        [monthEvents, selectedDay],
    );

    const handleDayPress = useCallback((cell: MobileDayCell) => {
        setSelectedDay(new Date(cell.date));
        // Also sync the context selected date so navigation stays coherent
        setSelectedDate(new Date(cell.date));
    }, [setSelectedDate]);

    const handlePrev = useCallback(() => {
        goPrevious();
        // Reset selected day to the 1st of the previous month
        const prev = new Date(selectedDate.getFullYear(), selectedDate.getMonth() - 1, 1);
        setSelectedDay(prev);
    }, [goPrevious, selectedDate]);

    const handleNext = useCallback(() => {
        goNext();
        const next = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 1);
        setSelectedDay(next);
    }, [goNext, selectedDate]);

    const handleToday = useCallback(() => {
        goToToday();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        setSelectedDay(today);
    }, [goToToday]);

    return (
        <div
            className="flex flex-col h-full bg-white dark:bg-gray-900"
            dir={isRTL ? 'rtl' : 'ltr'}
        >
            {/* ── Month header ─────────────────────────────────────────────── */}
            <div className="flex items-center justify-between px-4 pt-6 pb-3">
                <button
                    onClick={handlePrev}
                    className="w-9 h-9 flex items-center justify-center rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    aria-label={t('calendar.previous')}
                >
                    <svg className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                </button>

                <h2 className="text-base font-semibold tracking-widest text-gray-900 dark:text-white uppercase">
                    {monthLabel}
                </h2>

                <button
                    onClick={handleNext}
                    className="w-9 h-9 flex items-center justify-center rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                    aria-label={t('calendar.next')}
                >
                    <svg className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                </button>
            </div>

            {/* ── Week-day single-letter headers ───────────────────────────── */}
            <div className="grid grid-cols-7 px-2 pb-1">
                {weekDayLetters.map((letter, idx) => (
                    <div
                        key={idx}
                        className={`text-center text-[11px] font-semibold py-1
                            ${idx === 0 || idx === 6
                                ? 'text-red-500 dark:text-red-400'
                                : 'text-gray-500 dark:text-gray-400'
                            }`}
                    >
                        {letter}
                    </div>
                ))}
            </div>

            {/* ── Compact day grid ─────────────────────────────────────────── */}
            <div className="grid grid-cols-7 px-2 gap-y-1">
                {cells.map((cell, idx) => {
                    const isSelected = isSameDay(cell.date, selectedDay);
                    const isWeekend = idx % 7 === 0 || idx % 7 === 6;

                    return (
                        <button
                            key={idx}
                            onClick={() => handleDayPress(cell)}
                            className="flex flex-col items-center py-0.5 focus:outline-none"
                        >
                            {/* Day number circle */}
                            <span
                                className={`
                                    w-8 h-8 flex items-center justify-center rounded-full text-sm font-medium transition-colors
                                    ${cell.isToday && !isSelected
                                        ? 'bg-blue-600 text-white font-bold'
                                        : isSelected
                                            ? 'bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white font-bold ring-2 ring-gray-400 dark:ring-gray-500'
                                            : cell.isCurrentMonth
                                                ? isWeekend
                                                    ? 'text-red-500 dark:text-red-400'
                                                    : 'text-gray-900 dark:text-gray-100'
                                                : 'text-gray-300 dark:text-gray-600'
                                    }
                                `}
                            >
                                {cell.dayNumber}
                            </span>

                            {/* Event indicator bar(s) — up to 3 dots/bars */}
                            <div className="flex gap-0.5 mt-0.5 h-1.5 items-center justify-center">
                                {cell.events.slice(0, 3).map((ev, evIdx) => (
                                    <span
                                        key={evIdx}
                                        className="w-1 h-1 rounded-full"
                                        style={{ backgroundColor: ev.color || '#2563eb' }}
                                    />
                                ))}
                                {cell.events.length > 3 && (
                                    <span className="w-1 h-1 rounded-full bg-gray-400 dark:bg-gray-500" />
                                )}
                            </div>
                        </button>
                    );
                })}
            </div>

            {/* ── Divider ──────────────────────────────────────────────────── */}
            <div className="border-t border-gray-100 dark:border-gray-800 mt-2" />

            {/* ── Selected day header ──────────────────────────────────────── */}
            <div className="flex items-center justify-between px-4 py-3">
                <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-gray-900 dark:text-white">
                        {selectedDay.getDate()}
                    </span>
                    <span className="text-sm font-semibold text-gray-500 dark:text-gray-400 tracking-wide">
                        {formatDayLabel(selectedDay, language)}
                    </span>
                </div>

                {/* Today shortcut */}
                <button
                    onClick={handleToday}
                    className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors px-2 py-1 rounded"
                >
                    {t('calendar.today')}
                </button>
            </div>

            {/* ── Day events list ──────────────────────────────────────────── */}
            <div className="flex-1 overflow-y-auto px-4 pb-6 space-y-2">
                {selectedDayEvents.length === 0 ? (
                    <div className="flex items-center justify-center py-8">
                        <p className="text-sm text-gray-400 dark:text-gray-500">
                            {t('calendar.noAppointments')}
                        </p>
                    </div>
                ) : (
                    selectedDayEvents
                        .slice()
                        .sort((a, b) => a.time.localeCompare(b.time))
                        .map((event) => (
                            <button
                                key={event.id}
                                onClick={() => onEventClick(event)}
                                className="w-full group"
                            >
                                <div
                                    className="flex items-center gap-3 px-4 py-3 rounded-xl transition-colors text-left"
                                    style={{ backgroundColor: `${event.color}18` }}
                                >
                                    {/* Color indicator */}
                                    <ColorBar color={event.color} />

                                    {/* Event info */}
                                    <div className="flex-1 min-w-0">
                                        <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                                            {event.title}
                                        </p>
                                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                                            {formatEventTime(event, t)}
                                        </p>
                                    </div>

                                    {/* Chevron */}
                                    <svg
                                        className={`w-4 h-4 text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors flex-shrink-0 ${isRTL ? 'rotate-180' : ''}`}
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                    </svg>
                                </div>
                            </button>
                        ))
                )}
            </div>
        </div>
    );
}

export default MobileMonthView;
