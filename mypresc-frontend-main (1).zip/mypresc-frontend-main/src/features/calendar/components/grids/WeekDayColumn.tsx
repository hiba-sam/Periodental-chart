// WeekDayColumn - Single day column in week view with slots and events
'use client';

import React, { useCallback } from 'react';
import { AlertCircle, CheckCircle2, BadgeCheck } from 'lucide-react';
import { DraggableEvent } from '@/components/calendar/DraggableEvent';
import { DroppableSlot } from '@/components/calendar/DroppableSlot';
import type { CalendarEvent } from '../../types';
import { getEventColors } from './EventBlock';
import { SLOT_HEIGHT, QUARTER_SLOT_HEIGHT, type DayColumn, type TimeSlotData } from '../../hooks/useWeekGrid';

interface WeekDayColumnProps {
    column: DayColumn;
    colIdx: number;
    timeSlots: TimeSlotData[];
    selectedEventId?: string;
    isDragging: boolean;
    isDarkMode: boolean;
    isOutsideWorkingHours: (date: Date, hour: number) => boolean;
    getEventStyle: (event: CalendarEvent, eventsInSameDay: CalendarEvent[]) => {
        top: string;
        height: string;
        width: string;
        left: string;
    };
    onSlotClick: (date: Date, hour: number, minute: number) => void;
    onEventClick: (event: CalendarEvent, e: React.MouseEvent) => void;
}

/**
 * Single day column in week view
 */
export function WeekDayColumn({
    column,
    colIdx,
    timeSlots,
    selectedEventId,
    isDragging,
    isDarkMode,
    isOutsideWorkingHours,
    getEventStyle,
    onSlotClick,
    onEventClick,
}: WeekDayColumnProps) {
    const handleSlotClick = useCallback((hour: number, minute: number) => {
        onSlotClick(column.date, hour, minute);
    }, [column.date, onSlotClick]);

    return (
        <div className="relative border-e border-gray-200 dark:border-gray-700 last:border-e-0">
            {/* Layer 1: Background clickable slots */}
            <div className="relative w-full h-full">
                {timeSlots.map((slot) => (
                    <div key={slot.hour} className="relative w-full h-[80px]">
                        {/* 15-min slots (0, 15, 30, 45) */}
                        {[0, 15, 30, 45].map((minute, idx) => (
                            <DroppableSlot
                                key={minute}
                                id={`slot-${colIdx}-${column.date.toISOString()}-${String(slot.hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`}
                                disabled={false}
                                className={`absolute inset-x-0 w-full h-[20px]`}
                                style={{ top: `${idx * 20}px`, zIndex: 20 + idx }}
                            >
                                <div
                                    role="button"
                                    tabIndex={0}
                                    aria-label={`Create event at ${column.dayName} ${column.dayNumber} ${slot.label.replace(':00', `:${String(minute).padStart(2, '0')}`)}`}
                                    className={`w-full h-full transition-colors cursor-pointer ${isOutsideWorkingHours(column.date, slot.hour)
                                        ? 'bg-gray-100 dark:bg-gray-950/50 hover:bg-gray-200 dark:hover:bg-gray-900'
                                        : 'hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'
                                        }`}
                                    style={{ pointerEvents: 'auto' }}
                                    onClick={() => handleSlotClick(slot.hour, minute)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') {
                                            e.preventDefault();
                                            handleSlotClick(slot.hour, minute);
                                        }
                                    }}
                                />
                            </DroppableSlot>
                        ))}
                    </div>
                ))}
            </div>

            {/* Layer 2: Grid lines */}
            <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 25 }}>
                {timeSlots.map((slot, index) => (
                    <React.Fragment key={slot.hour}>
                        {/* Hour line */}
                        <div
                            className="absolute left-0 right-0 border-t border-gray-300 dark:border-gray-600 w-full"
                            style={{ top: `${index * SLOT_HEIGHT}px` }}
                        />
                        {/* 30-min line */}
                        <div
                            className="absolute left-0 right-0 border-t border-gray-200 dark:border-gray-700 w-full"
                            style={{ top: `${index * SLOT_HEIGHT + QUARTER_SLOT_HEIGHT * 2}px` }}
                        />
                    </React.Fragment>
                ))}
            </div>

            {/* Layer 3: Event blocks */}
            <div className="absolute inset-0 pointer-events-none">
                {column.events.map((event) => {
                    const eventStyle = getEventStyle(event, column.events);
                    const colors = getEventColors(event.color, isDarkMode);
                    const isSelected = selectedEventId === event.id;

                    return (
                        <DraggableEvent
                            key={event.id}
                            event={event}
                            isDraggingAny={isDragging}
                            style={{
                                top: eventStyle.top,
                                height: eventStyle.height,
                                width: eventStyle.width,
                                insetInlineStart: eventStyle.left,
                                zIndex: 30,
                                paddingLeft: '4px',
                                paddingRight: '4px',
                            }}
                            className={`
                                absolute rounded-md border-s-4
                                transition-all duration-150 pointer-events-auto overflow-hidden
                                ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'shadow-sm hover:shadow-md'}
                            `}
                            onClick={(e) => onEventClick(event, e)}
                        >
                            <div
                                className="w-full h-full p-2 flex items-center gap-2 rounded-md"
                                style={{
                                    backgroundColor: colors.bg,
                                    borderInlineStartColor: colors.border,
                                }}
                                title={`${event.time} - ${event.endTime}: ${event.title}`}
                            >
                                {/* Status Icon for appointments */}
                                {event.isAppointmentLinked && (
                                    <div className="flex-shrink-0 flex items-center">
                                        {event.isDone ? (
                                            <BadgeCheck className="w-4 h-4 text-blue-600" strokeWidth={2.5} />
                                        ) : !event.venueConfirmed ? (
                                            <AlertCircle className="w-4 h-4 text-yellow-500" strokeWidth={2.5} />
                                        ) : (
                                            <CheckCircle2 className="w-4 h-4 text-green-600" strokeWidth={2.5} />
                                        )}
                                    </div>
                                )}

                                {/* Event details */}
                                <div className={`flex-1 min-w-0 flex items-center gap-1.5 ${event.isDone ? 'relative' : ''}`}>
                                    <span
                                        className={`text-[11px] font-bold whitespace-nowrap ${event.isDone ? 'line-through opacity-60' : ''}`}
                                        style={{ color: colors.text }}
                                    >
                                        {event.time}
                                    </span>
                                    <span
                                        className={`text-[11px] font-medium truncate ${event.isDone ? 'line-through opacity-60' : ''}`}
                                        style={{ color: colors.text }}
                                    >
                                        {event.title}
                                    </span>
                                </div>
                            </div>
                        </DraggableEvent>
                    );
                })}
            </div>
        </div>
    );
}

export default WeekDayColumn;
