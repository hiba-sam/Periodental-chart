// CalendarGridContainer - Main orchestrator for calendar views
'use client';

import React from 'react';
import { useCalendar } from '@/contexts/CalendarContext';
import { DayGrid } from './DayGrid';
import { WeekGrid } from './WeekGrid';
import { MonthGrid } from './MonthGrid';
import type { CalendarEvent } from '../../types';

interface CalendarGridContainerProps {
    onSlotClick?: (date: Date, time: string) => void;
    onEventClick?: (event: CalendarEvent) => void;
    onDayClick?: (date: Date) => void;
    containerHeight?: number;
}

/**
 * Main calendar container that switches between Day, Week, and Month views
 */
export function CalendarGridContainer({
    onSlotClick,
    onEventClick,
    onDayClick,
    containerHeight
}: CalendarGridContainerProps) {
    const { calendarView } = useCalendar();

    switch (calendarView) {
        case 'day':
            return (
                <DayGrid
                    onSlotClick={onSlotClick}
                    onEventClick={onEventClick}
                    containerHeight={containerHeight}
                />
            );
        case 'month':
            return (
                <MonthGrid
                    onDayClick={onDayClick}
                    onEventClick={onEventClick}
                    containerHeight={containerHeight}
                />
            );
        case 'week':
        default:
            return (
                <WeekGrid
                    onSlotClick={onSlotClick}
                    onEventClick={onEventClick}
                    containerHeight={containerHeight}
                />
            );
    }
}

export default CalendarGridContainer;

