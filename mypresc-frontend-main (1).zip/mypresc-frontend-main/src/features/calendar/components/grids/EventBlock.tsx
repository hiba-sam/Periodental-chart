// EventBlock Component - Display a calendar event
'use client';

import React from 'react';
import type { CalendarEvent } from '../../types';
import { DraggableEvent } from '@/components/calendar/DraggableEvent';

// Color palette with transparency for event blocks
const COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
    '#2563eb': { bg: 'rgba(37, 99, 235, 0.15)', border: '#2563eb', text: '#1e40af' },
    '#10b981': { bg: 'rgba(16, 185, 129, 0.15)', border: '#10b981', text: '#047857' },
    '#ef4444': { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#b91c1c' },
    '#f59e0b': { bg: 'rgba(245, 158, 11, 0.15)', border: '#f59e0b', text: '#d97706' },
    '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#6d28d9' },
    '#6b7280': { bg: 'rgba(107, 114, 128, 0.15)', border: '#6b7280', text: '#4b5563' },
};

const DARK_COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
    '#2563eb': { bg: 'rgba(59, 130, 246, 0.25)', border: '#3b82f6', text: '#dbeafe' },
    '#10b981': { bg: 'rgba(16, 185, 129, 0.25)', border: '#10b981', text: '#d1fae5' },
    '#ef4444': { bg: 'rgba(239, 68, 68, 0.25)', border: '#ef4444', text: '#fee2e2' },
    '#f59e0b': { bg: 'rgba(245, 158, 11, 0.25)', border: '#f59e0b', text: '#fef3c7' },
    '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.25)', border: '#8b5cf6', text: '#ede9fe' },
    '#6b7280': { bg: 'rgba(107, 114, 128, 0.25)', border: '#6b7280', text: '#f3f4f6' },
};

export interface EventBlockProps {
    event: CalendarEvent;
    style: {
        top: string;
        height: string;
        width: string;
        left: string;
    };
    isSelected?: boolean;
    isDragging?: boolean;
    isDarkMode?: boolean;
    onClick: (event: CalendarEvent, e: React.MouseEvent) => void;
}

/**
 * Get color styling for event
 */
export function getEventColors(color: string, isDarkMode: boolean = false) {
    const variants = isDarkMode ? DARK_COLOR_VARIANTS : COLOR_VARIANTS;
    const defaultColor = isDarkMode ? DARK_COLOR_VARIANTS['#2563eb']! : COLOR_VARIANTS['#2563eb']!;
    return variants[color] ?? defaultColor;
}

/**
 * Calendar event block with drag support
 */
export function EventBlock({
    event,
    style,
    isSelected = false,
    isDragging = false,
    isDarkMode = false,
    onClick,
}: EventBlockProps) {
    const colors = getEventColors(event.color, isDarkMode);

    return (
        <DraggableEvent
            event={event}
            isDraggingAny={isDragging}
            style={{
                top: style.top,
                height: style.height,
                width: style.width,
                insetInlineStart: style.left,
                zIndex: 30,
                maxWidth: 'calc(100% - 8px)',
            }}
            className={`
                absolute rounded-lg border-s-4
                transition-all duration-150 pointer-events-auto overflow-hidden
                ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'shadow-md hover:shadow-lg'}
            `}
            onClick={(e) => onClick(event, e)}
        >
            <div
                className="w-full h-full px-3 py-1.5 flex flex-col justify-center"
                style={{
                    backgroundColor: colors.bg,
                    borderInlineStartColor: colors.border,
                }}
                title={`${event.time} - ${event.endTime}: ${event.title}${event.description ? ' - ' + event.description : ''}`}
            >
                {/* Compact event display */}
                <div className="flex items-center gap-2">
                    <span
                        className={`text-xs font-bold whitespace-nowrap ${event.isDone ? 'line-through opacity-60' : ''}`}
                        style={{ color: colors.text }}
                    >
                        {event.time}
                    </span>
                    <span
                        className={`text-xs font-semibold truncate flex-1 ${event.isDone ? 'line-through opacity-60' : ''}`}
                        style={{ color: colors.text }}
                    >
                        {event.title}
                    </span>
                    {/* Status indicator dots - Only for appointments */}
                    {event.isAppointmentLinked && (
                        <div className="flex items-center gap-1 flex-shrink-0">
                            {event.venueConfirmed && !event.isDone && (
                                <span className="w-2 h-2 rounded-full bg-green-500" title="Confirmé" />
                            )}
                            {!event.venueConfirmed && !event.isDone && (
                                <span className="w-2 h-2 rounded-full bg-yellow-500" title="Non confirmé" />
                            )}
                            {event.isDone && (
                                <span className="w-2 h-2 rounded-full bg-blue-600" title="Terminé" />
                            )}
                        </div>
                    )}
                    <span className="text-[10px] text-gray-600 dark:text-gray-300 font-medium">
                        {event.duration}min
                    </span>
                </div>
            </div>
        </DraggableEvent>
    );
}

export default EventBlock;
