// DayCell Component - Calendar day cell for month view
'use client';

import React from 'react';
import type { CalendarEvent, DayCellData } from '../../types';

// Color palette for event dots
const EVENT_COLORS: Record<string, string> = {
    '#2563eb': '#2563eb',
    '#10b981': '#10b981',
    '#ef4444': '#ef4444',
    '#f59e0b': '#f59e0b',
    '#8b5cf6': '#8b5cf6',
    '#6b7280': '#6b7280',
};

// Re-export type for convenience
export type { DayCellData };

export interface DayCellProps {
    cell: DayCellData;
    occupationColor: string;
    onClick: (date: Date) => void;
    onEventClick: (event: CalendarEvent, e: React.MouseEvent) => void;
}

/**
 * Day cell component for month view
 */
export function DayCell({ cell, occupationColor, onClick, onEventClick }: DayCellProps) {
    return (
        <div
            onClick={() => onClick(cell.date)}
            className={`
                relative min-h-[100px] p-2 border-2 rounded-lg cursor-pointer
                transition-all duration-150 hover:shadow-md
                ${cell.isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-900'}
                ${cell.isToday ? 'ring-2 ring-blue-500 border-blue-300 dark:border-blue-700' : 'border-gray-200 dark:border-gray-700'}
                ${cell.isPast && !cell.isToday ? 'opacity-60' : ''}
                ${occupationColor}
            `}
        >
            {/* Day number and count */}
            <div className="flex items-center justify-between mb-2">
                <span
                    className={`
                        text-sm font-semibold
                        ${cell.isToday
                            ? 'text-blue-600 dark:text-blue-400'
                            : cell.isCurrentMonth
                                ? 'text-gray-800 dark:text-gray-200'
                                : 'text-gray-400 dark:text-gray-600'
                        }
                    `}
                >
                    {cell.dayNumber}
                </span>

                {cell.events.length > 0 && (
                    <span className="text-xs px-2 py-0.5 bg-blue-600 text-white rounded-full font-medium">
                        {cell.events.length}
                    </span>
                )}
            </div>

            {/* Events list (max 3) */}
            <div className="space-y-1">
                {cell.events.slice(0, 3).map((event) => {
                    const eventColor = EVENT_COLORS[event.color] || EVENT_COLORS['#2563eb'];

                    return (
                        <div
                            key={event.id}
                            onClick={(e) => onEventClick(event, e)}
                            className="flex items-center gap-1 text-xs p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                            style={{ borderLeft: `3px solid ${eventColor}` }}
                        >
                            <span className="font-medium text-gray-700 dark:text-gray-300 truncate">
                                {event.time}
                            </span>
                            <span className="text-gray-600 dark:text-gray-400 truncate flex-1">
                                {event.title}
                            </span>
                        </div>
                    );
                })}

                {/* More indicator */}
                {cell.events.length > 3 && (
                    <div className="text-xs text-gray-500 font-medium pl-1">
                        +{cell.events.length - 3} de plus
                    </div>
                )}
            </div>

            {/* Empty day indicator */}
            {cell.events.length === 0 && cell.isCurrentMonth && !cell.isPast && (
                <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <span className="text-gray-400 text-xs">Cliquez pour ajouter</span>
                </div>
            )}
        </div>
    );
}

export default DayCell;
