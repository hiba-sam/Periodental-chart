// WeekGrid Component - Week view calendar grid with sticky headers
'use client';

import React, { useCallback } from 'react';
import { DndContext, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useCalendarDragDrop, customCollisionDetection } from '@/hooks/useCalendarDragDrop';
import { useTheme } from '@/contexts/ThemeContext';
import { WeekDayColumn } from './WeekDayColumn';
import { CurrentTimeIndicator } from './CurrentTimeIndicator';
import { useWeekGrid, SLOT_HEIGHT } from '../../hooks/useWeekGrid';

interface WeekGridProps {
    onSlotClick?: (date: Date, time: string) => void;
    onEventClick?: (event: CalendarEvent) => void;
    containerHeight?: number;
}

/**
 * Week view grid - displays 7 day columns with time slots
 * Features: Sticky date header, sticky time column, full width responsive
 */
export function WeekGrid({ onSlotClick, onEventClick, containerHeight }: WeekGridProps) {
    const { selectedDate, getEventsForWeek, selectEvent, selectedEvent } = useCalendar();
    const { actualTheme } = useTheme();
    const isDarkMode = actualTheme === 'dark';

    // Drag & drop
    const { dragState, handlers } = useCalendarDragDrop();

    // Configure pointer sensor
    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: { distance: 8 },
        })
    );

    // Week grid logic
    const {
        weekColumns,
        timeSlots,
        isRTL,
        horizontalScrollRef,
        verticalScrollRef,
        isOutsideWorkingHours,
        getEventStyle,
        getEventsInHour,
    } = useWeekGrid({ selectedDate, getEventsForWeek });

    // Handle slot click
    const handleSlotClick = useCallback((date: Date, hour: number, minute: number) => {
        const eventsInHour = getEventsInHour(date, hour);
        if (eventsInHour >= 4) return;
        const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        onSlotClick?.(date, time);
    }, [onSlotClick, getEventsInHour]);

    // Handle event click
    const handleEventClick = useCallback((event: CalendarEvent, e: React.MouseEvent) => {
        e.stopPropagation();
        selectEvent(event);
        onEventClick?.(event);
    }, [selectEvent, onEventClick]);

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={customCollisionDetection}
            onDragStart={handlers.onDragStart}
            onDragOver={handlers.onDragOver}
            onDragEnd={handlers.onDragEnd}
            onDragCancel={handlers.onDragCancel}
        >
            <div className="week-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
                {/* Horizontal scroll container */}
                <div
                    ref={horizontalScrollRef}
                    className="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600"
                >
                    {/* Inner container - full width */}
                    <div className="flex flex-col w-full" style={{ minWidth: `${50 + 250 * 7}px` }}>
                        {/* Header Row - Days */}
                        <div
                            className="me-3 grid border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 sticky top-0 z-40"
                            style={{
                                gridTemplateColumns: `50px repeat(7, 1fr)`,
                                direction: isRTL ? 'rtl' : 'ltr'
                            }}
                        >
                            {/* Empty corner cell */}
                            <div className="bg-gray-50 dark:bg-gray-900 border-e border-gray-200 dark:border-gray-700" />

                            {/* Day headers */}
                            {weekColumns.map((column, idx) => (
                                <div
                                    key={idx}
                                    className={`
                                        flex items-center justify-center gap-2  p-2 text-center
                                        border-e border-gray-200 dark:border-gray-700
                                        ${column.isToday ? 'bg-blue-50 dark:bg-blue-900/40' : ''}
                                    `}
                                >
                                    <div
                                        className={`text-xl font-bold ${column.isToday
                                            ? 'text-blue-600 dark:text-blue-400'
                                            : column.isPast
                                                ? 'text-gray-400 dark:text-gray-500'
                                                : 'text-gray-800 dark:text-gray-100'
                                            }`}
                                    >
                                        {column.dayNumber}
                                    </div>
                                    <div
                                        className={`text-sm font-medium ${column.isToday
                                            ? 'text-blue-600 dark:text-blue-400'
                                            : 'text-gray-600 dark:text-gray-400'
                                            }`}
                                    >
                                        {column.dayName}
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Time Grid Body */}
                        <div
                            ref={verticalScrollRef}
                            className="calendar-grid-body relative"
                            style={{
                                height: 'calc(100vh - 170px)',
                                overflowY: 'scroll',
                                overflowX: 'hidden'
                            }}
                        >
                            {/* Grid container */}
                            <div
                                className="grid"
                                style={{
                                    gridTemplateColumns: `50px repeat(7, 1fr)`,
                                    direction: isRTL ? 'rtl' : 'ltr'
                                }}
                            >
                                {/* Time labels column */}
                                <div className="border-e border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 relative">
                                    {timeSlots.map((slot) => (
                                        <div
                                            key={slot.hour}
                                            className="relative text-xs text-gray-500 dark:text-gray-400 text-end pe-2"
                                            style={{ height: `${SLOT_HEIGHT}px` }}
                                        >
                                            <span className={`absolute top-0 ${isRTL ? 'left-2' : 'right-2'} -translate-y-1/2`}>
                                                {slot.label}
                                            </span>
                                        </div>
                                    ))}
                                </div>

                                {/* Day columns */}
                                {weekColumns.map((column, colIdx) => (
                                    <WeekDayColumn
                                        key={colIdx}
                                        column={column}
                                        colIdx={colIdx}
                                        timeSlots={timeSlots}
                                        selectedEventId={selectedEvent?.id}
                                        isDragging={dragState.isDragging}
                                        isDarkMode={isDarkMode}
                                        isOutsideWorkingHours={isOutsideWorkingHours}
                                        getEventStyle={getEventStyle}
                                        onSlotClick={handleSlotClick}
                                        onEventClick={handleEventClick}
                                    />
                                ))}
                            </div>

                            {/* Current time indicator */}
                            <CurrentTimeIndicator isRTL={isRTL} />
                        </div>
                    </div>
                </div>
            </div>
        </DndContext>
    );
}

export default WeekGrid;
