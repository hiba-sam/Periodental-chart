// DayGrid Component - Main container for day view
'use client';

import React, { useCallback } from 'react';
import { DndContext, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useCalendarDragDrop, customCollisionDetection } from '@/hooks/useCalendarDragDrop';
import { useTheme } from '@/contexts/ThemeContext';
import { TimeSlot } from './TimeSlot';
import { EventBlock, getEventColors } from './EventBlock';
import { useDayGrid, SLOT_HEIGHT, QUARTER_SLOT_HEIGHT } from '../../hooks';

interface DayGridProps {
    onSlotClick?: (date: Date, time: string) => void;
    onEventClick?: (event: CalendarEvent) => void;
}

/**
 * Day view grid - displays single day with time slots and events
 */
export function DayGrid({ onSlotClick, onEventClick }: DayGridProps) {
    const { selectedDate, getEventsForDate, selectEvent, selectedEvent } = useCalendar();
    const { actualTheme } = useTheme();
    const isDarkMode = actualTheme === 'dark';

    // Drag & drop functionality
    const { dragState, handlers } = useCalendarDragDrop();

    // Configure pointer sensor
    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: { distance: 8 },
        })
    );

    // Get events for selected date
    const dayEvents = getEventsForDate(selectedDate);

    // Day grid logic
    const {
        isToday,
        timeSlots,
        dateLabel,
        currentTimePosition,
        getEventStyle,
        isTimeSlotPast,
    } = useDayGrid({ selectedDate, events: dayEvents });

    // Handle slot click
    const handleSlotClick = useCallback((hour: number, minute: number) => {
        if (isTimeSlotPast(hour)) return;

        let slotDate = new Date(selectedDate);
        let actualHour = hour;

        if (hour >= 24) {
            slotDate.setDate(slotDate.getDate() + 1);
            actualHour = hour - 24;
        }

        const time = `${String(actualHour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        onSlotClick?.(slotDate, time);
    }, [selectedDate, onSlotClick, isTimeSlotPast]);

    // Handle event click
    const handleEventClick = useCallback((event: CalendarEvent, e: React.MouseEvent) => {
        e.stopPropagation();
        selectEvent(event);
        onEventClick?.(event);
    }, [selectEvent, onEventClick]);

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={customCollisionDetection}
            onDragStart={handlers.onDragStart}
            onDragOver={handlers.onDragOver}
            onDragEnd={handlers.onDragEnd}
            onDragCancel={handlers.onDragCancel}
        >
            <div className="day-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
                {/* Day Header */}
                <div className={`p-4 border-b border-gray-200 dark:border-gray-700 ${isToday ? 'bg-blue-50 dark:bg-blue-900/40' : 'bg-gray-50 dark:bg-gray-900'}`}>
                    <h3 className={`text-lg font-semibold capitalize ${isToday ? 'text-blue-600 dark:text-blue-400' : 'text-gray-800 dark:text-gray-100'}`}>
                        {dateLabel}
                    </h3>
                    {isToday && <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">Aujourd'hui</p>}
                    {dayEvents.length > 0 && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {dayEvents.length} rendez-vous
                        </p>
                    )}
                </div>

                {/* Time Grid */}
                <div className="day-grid-body relative overflow-y-auto" style={{ height: 'calc(100vh - 220px)' }}>
                    <div className="relative">
                        <div className="grid grid-cols-[80px_1fr]">
                            {/* Time labels column */}
                            <div className="border-e border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 relative z-10">
                                {timeSlots.map((slot) => (
                                    <div
                                        key={slot.hour}
                                        className="relative text-sm font-medium text-gray-600 dark:text-gray-400 text-end pe-3"
                                        style={{ height: `${SLOT_HEIGHT}px`, lineHeight: `${SLOT_HEIGHT}px` }}
                                    >
                                        <span dir="ltr">{slot.label}</span>
                                    </div>
                                ))}
                            </div>

                            {/* Day column with slots */}
                            <div className="relative overflow-hidden">
                                {/* Time slot cells */}
                                {timeSlots.map((slot) => {
                                    const slotIsPast = isTimeSlotPast(slot.hour);
                                    const displayHour = slot.hour >= 24 ? slot.hour - 24 : slot.hour;

                                    return (
                                        <div key={slot.hour} className="relative h-[80px]">
                                            {/* First 30min slot */}
                                            <TimeSlot
                                                slotId={`slot-${selectedDate.toISOString()}-${String(displayHour).padStart(2, '0')}:00`}
                                                hour={slot.hour}
                                                minute={0}
                                                isPast={slotIsPast}
                                                onClick={handleSlotClick}
                                                height={40}
                                                className="absolute top-0 left-0 right-0"
                                            />
                                            {/* Second 30min slot */}
                                            <TimeSlot
                                                slotId={`slot-${selectedDate.toISOString()}-${String(displayHour).padStart(2, '0')}:30`}
                                                hour={slot.hour}
                                                minute={30}
                                                isPast={slotIsPast}
                                                onClick={handleSlotClick}
                                                height={40}
                                                className="absolute top-[40px] left-0 right-0"
                                            />
                                        </div>
                                    );
                                })}

                                {/* Event blocks */}
                                <div className="absolute top-0 left-0 right-0 pointer-events-none px-2" style={{ zIndex: 30 }}>
                                    {dayEvents.map((event) => (
                                        <EventBlock
                                            key={event.id}
                                            event={event}
                                            style={getEventStyle(event)}
                                            isSelected={selectedEvent?.id === event.id}
                                            isDragging={dragState.isDragging}
                                            isDarkMode={isDarkMode}
                                            onClick={handleEventClick}
                                        />
                                    ))}
                                </div>

                                {/* Grid lines */}
                                <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 25 }}>
                                    {timeSlots.map((slot, index) => (
                                        <React.Fragment key={slot.hour}>
                                            <div
                                                className="absolute left-0 right-0 border-t border-gray-300 dark:border-gray-600"
                                                style={{ top: `${index * SLOT_HEIGHT}px` }}
                                            />
                                            <div
                                                className="absolute left-0 right-0 border-t border-gray-200 dark:border-gray-700"
                                                style={{ top: `${index * SLOT_HEIGHT + QUARTER_SLOT_HEIGHT * 2}px` }}
                                            />
                                        </React.Fragment>
                                    ))}

                                    {/* Current time indicator */}
                                    {currentTimePosition !== null && (
                                        <div
                                            className="absolute left-0 right-0 h-[2px] bg-red-500"
                                            style={{ top: `${currentTimePosition}px`, zIndex: 40 }}
                                        />
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* No events message */}
                {dayEvents.length === 0 && (
                    <div className="p-12 text-center">
                        <div className="text-gray-400 dark:text-gray-600 text-5xl mb-4">📅</div>
                        <p className="text-gray-500 dark:text-gray-400 text-lg font-medium">Aucun rendez-vous ce jour</p>
                        <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
                            Cliquez sur un créneau horaire pour créer un rendez-vous
                        </p>
                    </div>
                )}
            </div>
        </DndContext>
    );
}

export default DayGrid;
