// CurrentTimeIndicator - Red line showing current time across the week grid
'use client';

import React from 'react';
import { SLOT_HEIGHT, TIME_LABEL_WIDTH } from '../../hooks/useWeekGrid';

interface CurrentTimeIndicatorProps {
    isRTL: boolean;
}

/**
 * Current time indicator line that spans across the week grid
 */
export function CurrentTimeIndicator({ isRTL }: CurrentTimeIndicatorProps) {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTimeMinutes = currentHour * 60 + currentMinute;

    // Calculate position
    const topPosition = (currentTimeMinutes / 60) * SLOT_HEIGHT;

    // Don't render if outside reasonable bounds
    if (topPosition < 0) return null;

    const currentTimeText = `${String(currentHour).padStart(2, '0')}:${String(currentMinute).padStart(2, '0')}`;

    // Position styles based on direction
    const containerStyle = isRTL
        ? { right: `${TIME_LABEL_WIDTH}px`, left: 0 }
        : { left: `${TIME_LABEL_WIDTH}px`, right: 0 };

    const textStyle = isRTL
        ? { width: '45px', textAlign: 'left' as const, right: '-50px' }
        : { width: '45px', textAlign: 'right' as const, left: '-50px' };

    const circleStyle = isRTL
        ? { right: '-4px' }
        : { left: '-4px' };

    return (
        <div
            className="absolute pointer-events-none"
            style={{
                top: `${topPosition}px`,
                ...containerStyle,
                zIndex: 60
            }}
            dir={isRTL ? 'rtl' : 'ltr'}
        >
            {/* Current time label */}
            <div
                className="absolute -top-2 text-xs font-bold text-red-500"
                style={textStyle}
            >
                {currentTimeText}
            </div>

            {/* Red circle */}
            <div
                className="absolute -top-1.5 w-3 h-3 bg-red-500 rounded-full border-2 border-white shadow"
                style={circleStyle}
            />

            {/* Red horizontal line */}
            <div className="absolute inset-x-0 h-[2px] bg-red-500 shadow-sm" />
        </div>
    );
}

export default CurrentTimeIndicator;
