// Calendar Types - Core type definitions for calendar feature

/**
 * Calendar view mode
 */
export type CalendarView = 'day' | 'week' | 'month';

/**
 * Calendar event (appointment or standalone)
 */
export interface CalendarEvent {
    id: string;
    date: Date;
    time: string; // HH:mm format
    duration: number; // minutes
    title: string;
    description?: string; // note field from API
    color: string; // Hex color
    patientId?: string;
    patientName?: string;
    patientFamilyName?: string;
    patientPhone?: string;
    patientAge?: number;
    confirmedComing?: boolean;
    venueConfirmed?: boolean;
    isDone?: boolean;
    appointmentId?: string | null; // null for standalone events
    isAppointmentLinked: boolean;
    // Computed fields
    endTime?: string; // HH:mm format
}

/**
 * API response format for calendar event
 */
export interface ApiCalendarEvent {
    id: string;
    user_id: number;
    title: string;
    date: string;
    time: string;
    duration: number;
    note?: string;
    color: string;
    appointment_id?: string | null;
    patient_id?: string;
    patient_name?: string;
    patient_family_name?: string;
    patient_phone?: string;
    patient_date_of_birth?: string;
    confirmed_coming?: boolean;
    venue_confirmed?: boolean;
    is_done?: boolean;
    created_at: string;
    updated_at: string;
}

/**
 * Data for creating a new event
 */
export interface CreateEventData {
    // For appointment-linked events
    patientId?: string;
    confirmedComing?: boolean;

    // For standalone events
    title?: string;

    // Common fields
    date: Date;
    time: string;
    duration?: number;
    notes?: string;
    color?: string;

    // Flag to determine event type
    isAppointment?: boolean;
}

/**
 * Data for updating an existing event
 */
export interface UpdateEventData {
    id: string;

    // Calendar fields
    title?: string;
    note?: string;
    date?: Date;
    time?: string;
    duration?: number;
    color?: string;

    // Appointment-specific fields (only for appointment-linked events)
    appointment_notes?: string;
    is_done?: boolean;
    confirmed_coming?: boolean;
    venue_confirmed?: boolean;
}

/**
 * Time slot for calendar grid
 */
export interface TimeSlot {
    time: string; // HH:mm format
    label: string; // Display label (e.g., "09:00", "09:30")
    isHour: boolean; // true for full hours
}

/**
 * Week day info for calendar navigation
 */
export interface WeekDay {
    date: Date;
    dayName: string;
    dayNumber: number;
    isToday: boolean;
    isSelected: boolean;
}

/**
 * Drag-drop event data
 */
export interface DragDropData {
    eventId: string;
    originalDate: Date;
    originalTime: string;
    newDate: Date;
    newTime: string;
}

/**
 * Event filters for fetching
 */
export interface CalendarFilters {
    startDate?: Date;
    endDate?: Date;
    patientId?: string;
    view?: CalendarView;
}

// =============================================================================
// GRID CONSTANTS
// =============================================================================

export const HOURS_START = 0; // Midnight
export const HOURS_END = 23;
export const SLOT_HEIGHT = 80; // pixels per hour
export const QUARTER_SLOT_HEIGHT = 20; // pixels per 15-min
export const DAY_COLUMN_WIDTH = 220;
export const TIME_LABEL_WIDTH = 50;

// =============================================================================
// GRID TYPES
// =============================================================================

/**
 * Day column for week view
 */
export interface DayColumn {
    date: Date;
    dayName: string;
    dayNumber: number;
    isToday: boolean;
    isPast: boolean;
    events: CalendarEvent[];
}

/**
 * Time slot data for grid rendering
 */
export interface TimeSlotData {
    hour: number;
    minute?: number;
    label: string;
}

/**
 * Event positioning style
 */
export interface EventStyle {
    top: string;
    height: string;
    width: string;
    left: string;
}

/**
 * Day cell for month view
 */
export interface DayCellData {
    date: Date;
    dayNumber: number;
    isCurrentMonth: boolean;
    isToday: boolean;
    isPast: boolean;
    events: CalendarEvent[];
}

