// Event Formatters - Display formatting utilities for calendar events

import type { CalendarEvent, WeekDay } from '../types';
import { isToday, isSameDay } from './dateCalculations';

/**
 * Format date for display (e.g., "Lundi 15 Janvier")
 */
export function formatDateDisplay(date: Date, locale: string = 'fr-FR'): string {
    return date.toLocaleDateString(locale, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
    });
}

/**
 * Format date for short display (e.g., "15 Jan")
 */
export function formatDateShort(date: Date, locale: string = 'fr-FR'): string {
    return date.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'short',
    });
}

/**
 * Format time range (e.g., "09:00 - 09:30")
 */
export function formatTimeRange(startTime: string, endTime: string): string {
    return `${startTime} - ${endTime}`;
}

/**
 * Format duration in human readable form
 */
export function formatDuration(minutes: number): string {
    if (minutes < 60) {
        return `${minutes} min`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    if (remainingMinutes === 0) {
        return `${hours}h`;
    }
    return `${hours}h ${remainingMinutes}min`;
}

/**
 * Get event display title (patient name or event title)
 */
export function getEventDisplayTitle(event: CalendarEvent): string {
    if (event.isAppointmentLinked && event.patientName) {
        return `${event.patientName} ${event.patientFamilyName || ''}`.trim();
    }
    return event.title || 'Sans titre';
}

/**
 * Get event subtitle (patient info or description)
 */
export function getEventSubtitle(event: CalendarEvent): string | null {
    if (event.isAppointmentLinked) {
        const parts: string[] = [];
        if (event.patientAge) parts.push(`${event.patientAge} ans`);
        if (event.patientPhone) parts.push(event.patientPhone);
        return parts.length > 0 ? parts.join(' • ') : null;
    }
    return event.description || null;
}

/**
 * Get event status badge info
 */
export function getEventStatusBadge(event: CalendarEvent): { label: string; color: string } | null {
    if (!event.isAppointmentLinked) return null;

    if (event.isDone) {
        return { label: 'Terminé', color: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' };
    }
    if (event.venueConfirmed) {
        return { label: 'Arrivé', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400' };
    }
    if (event.confirmedComing) {
        return { label: 'Confirmé', color: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400' };
    }
    return { label: 'En attente', color: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-400' };
}

/**
 * Build WeekDay array for week header
 */
export function buildWeekDays(weekStart: Date, selectedDate: Date, locale: string = 'fr-FR'): WeekDay[] {
    const days: WeekDay[] = [];
    const dayNames = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

    for (let i = 0; i < 7; i++) {
        const date = new Date(weekStart);
        date.setDate(weekStart.getDate() + i);

        days.push({
            date,
            dayName: dayNames[i] as string,
            dayNumber: date.getDate(),
            isToday: isToday(date),
            isSelected: isSameDay(date, selectedDate),
        });
    }

    return days;
}

/**
 * Get month/year display string
 */
export function getMonthYearDisplay(date: Date, locale: string = 'fr-FR'): string {
    return date.toLocaleDateString(locale, {
        month: 'long',
        year: 'numeric',
    });
}

/**
 * Get week range display string (e.g., "15 - 21 Janvier 2024")
 */
export function getWeekRangeDisplay(weekStart: Date, locale: string = 'fr-FR'): string {
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);

    const startDay = weekStart.getDate();
    const endDay = weekEnd.getDate();
    const month = weekEnd.toLocaleDateString(locale, { month: 'long' });
    const year = weekEnd.getFullYear();

    return `${startDay} - ${endDay} ${month} ${year}`;
}
