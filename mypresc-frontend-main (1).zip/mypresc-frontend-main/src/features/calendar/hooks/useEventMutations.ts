// useEventMutations - CRUD mutations for calendar events
'use client';

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { calendarKeys } from './useCalendarEvents';
import { createCalendarEvent, updateCalendarEvent, deleteCalendarEvent } from '../api';
import type { CalendarEvent, CreateEventData, UpdateEventData } from '../types';
import { toast } from '@/components/ui/use-toast';

interface UseEventMutationsOptions {
    onCreateSuccess?: (event: CalendarEvent) => void;
    onUpdateSuccess?: (event: CalendarEvent) => void;
    onDeleteSuccess?: (eventId: string) => void;
    onError?: (error: Error) => void;
}

/**
 * Hook for calendar event CRUD mutations
 */
export function useEventMutations(options: UseEventMutationsOptions = {}) {
    const { onCreateSuccess, onUpdateSuccess, onDeleteSuccess, onError } = options;
    const queryClient = useQueryClient();

    // Create event mutation
    const createMutation = useMutation({
        mutationFn: createCalendarEvent,
        onSuccess: (newEvent) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
            toast({
                title: 'Événement créé',
                description: newEvent.title || 'Nouveau rendez-vous ajouté',
            });
            onCreateSuccess?.(newEvent);
        },
        onError: (error: Error) => {
            toast({
                title: 'Erreur',
                description: error.message || 'Impossible de créer l\'événement',
                variant: 'destructive',
            });
            onError?.(error);
        },
    });

    // Update event mutation
    const updateMutation = useMutation({
        mutationFn: updateCalendarEvent,
        onMutate: async (data: UpdateEventData) => {
            // Cancel outgoing refetches
            await queryClient.cancelQueries({ queryKey: calendarKeys.events() });

            // Snapshot previous value
            const previousEvents = queryClient.getQueryData<CalendarEvent[]>(calendarKeys.events());

            // Optimistic update
            queryClient.setQueriesData<CalendarEvent[]>(
                { queryKey: calendarKeys.events() },
                (old) => old?.map(event =>
                    event.id === data.id
                        ? { ...event, ...data, date: data.date || event.date }
                        : event
                )
            );

            return { previousEvents };
        },
        onSuccess: (updatedEvent) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
            onUpdateSuccess?.(updatedEvent);
        },
        onError: (error: Error, _, context) => {
            // Rollback on error
            if (context?.previousEvents) {
                queryClient.setQueriesData(
                    { queryKey: calendarKeys.events() },
                    context.previousEvents
                );
            }
            toast({
                title: 'Erreur',
                description: error.message || 'Impossible de modifier l\'événement',
                variant: 'destructive',
            });
            onError?.(error);
        },
    });

    // Delete event mutation
    const deleteMutation = useMutation({
        mutationFn: deleteCalendarEvent,
        onMutate: async (eventId: string) => {
            await queryClient.cancelQueries({ queryKey: calendarKeys.events() });

            const previousEvents = queryClient.getQueryData<CalendarEvent[]>(calendarKeys.events());

            // Optimistic removal
            queryClient.setQueriesData<CalendarEvent[]>(
                { queryKey: calendarKeys.events() },
                (old) => old?.filter(event => event.id !== eventId)
            );

            return { previousEvents, eventId };
        },
        onSuccess: (_, eventId) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
            toast({
                title: 'Événement supprimé',
                description: 'L\'événement a été supprimé',
            });
            onDeleteSuccess?.(eventId);
        },
        onError: (error: Error, _, context) => {
            if (context?.previousEvents) {
                queryClient.setQueriesData(
                    { queryKey: calendarKeys.events() },
                    context.previousEvents
                );
            }
            toast({
                title: 'Erreur',
                description: error.message || 'Impossible de supprimer l\'événement',
                variant: 'destructive',
            });
            onError?.(error);
        },
    });

    return {
        // Mutations
        createEvent: createMutation.mutateAsync,
        updateEvent: updateMutation.mutateAsync,
        deleteEvent: deleteMutation.mutateAsync,

        // Sync versions
        createEventSync: createMutation.mutate,
        updateEventSync: updateMutation.mutate,
        deleteEventSync: deleteMutation.mutate,

        // Loading states
        isCreating: createMutation.isPending,
        isUpdating: updateMutation.isPending,
        isDeleting: deleteMutation.isPending,
        isLoading: createMutation.isPending || updateMutation.isPending || deleteMutation.isPending,
    };
}

export default useEventMutations;
