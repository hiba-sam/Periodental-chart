// useWeekGrid Hook - Business logic for week view grid
'use client';

import { useMemo, useCallback, useRef, useEffect } from 'react';
import { useProfile } from '@/contexts/ProfileContext';
import { useLanguage } from '@/contexts/LanguageContext';
import type { CalendarEvent, DayColumn, TimeSlotData } from '../types';
import {
    HOURS_START,
    HOURS_END,
    SLOT_HEIGHT,
    QUARTER_SLOT_HEIGHT,
    DAY_COLUMN_WIDTH,
    TIME_LABEL_WIDTH,
} from '../types';

// Re-export constants for convenience
export {
    HOURS_START,
    HOURS_END,
    SLOT_HEIGHT,
    QUARTER_SLOT_HEIGHT,
    DAY_COLUMN_WIDTH,
    TIME_LABEL_WIDTH,
};

// Re-export types
export type { DayColumn, TimeSlotData };

interface UseWeekGridOptions {
    selectedDate: Date;
    getEventsForWeek: (weekStart: Date) => CalendarEvent[];
}

/**
 * Get start of week (Saturday) - for Algerian calendar
 * Note: For Monday-based week start, use getWeekStart from utils
 */
export function getSaturdayWeekStart(date: Date): Date {
    const d = new Date(date);
    const day = d.getDay();
    const diff = day === 6 ? 0 : -(day + 1);
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
}

/**
 * Hook for week grid business logic
 */
export function useWeekGrid({ selectedDate, getEventsForWeek }: UseWeekGridOptions) {
    const { profile } = useProfile();
    const { language, isRTL } = useLanguage();

    // Refs for scroll containers
    const horizontalScrollRef = useRef<HTMLDivElement>(null);
    const verticalScrollRef = useRef<HTMLDivElement>(null);
    const hasInitialScrolled = useRef(false);

    // Generate time slots (24 hours)
    const timeSlots = useMemo((): TimeSlotData[] => {
        const slots: TimeSlotData[] = [];
        for (let i = 0; i <= 23; i++) {
            slots.push({
                hour: i,
                label: `${String(i).padStart(2, '0')}:00`,
            });
        }
        return slots;
    }, []);

    // Parse working time string
    const parseWorkingTime = useCallback((timeString: string | undefined): { start: number; end: number } | null => {
        if (!timeString || timeString.toLowerCase() === 'closed' || timeString.toLowerCase() === 'fermé') {
            return null;
        }
        const match = timeString.match(/(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})/);
        if (!match) return null;
        const startHour = parseInt(match[1]!, 10);
        const endHour = parseInt(match[3]!, 10);
        const endMinute = parseInt(match[4]!, 10);
        const adjustedEndHour = (endHour === 23 && endMinute > 0) ? 24 : endHour;
        return { start: startHour, end: adjustedEndHour };
    }, []);

    // Get working hours for a day
    const getWorkingHoursForDay = useCallback((date: Date): { start: number; end: number } | null => {
        if (!profile?.work_time) {
            return { start: 8, end: 17 };
        }
        const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const dayName = dayNames[date.getDay()];
        return parseWorkingTime(profile.work_time[dayName!]);
    }, [profile, parseWorkingTime]);

    // Check if slot is outside working hours
    const isOutsideWorkingHours = useCallback((date: Date, hour: number): boolean => {
        const workingHours = getWorkingHoursForDay(date);
        if (!workingHours) return true;
        return hour < workingHours.start || hour >= workingHours.end;
    }, [getWorkingHoursForDay]);

    // Check if date is today
    const isToday = useCallback((date: Date): boolean => {
        const today = new Date();
        return (
            date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear()
        );
    }, []);

    // Check if date is in the past
    const isPast = useCallback((date: Date): boolean => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return date < today;
    }, []);

    // Generate week columns
    const weekColumns = useMemo((): DayColumn[] => {
        const weekStart = getSaturdayWeekStart(selectedDate);
        const weekEvents = getEventsForWeek(weekStart);

        return Array.from({ length: 7 }, (_, index) => {
            const date = new Date(weekStart);
            date.setDate(weekStart.getDate() + index);

            const dayEvents = weekEvents.filter(
                (event) =>
                    event.date.getDate() === date.getDate() &&
                    event.date.getMonth() === date.getMonth() &&
                    event.date.getFullYear() === date.getFullYear()
            );

            const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
            const dayName = date.toLocaleDateString(locale, { weekday: 'short' });

            return {
                date,
                dayName,
                dayNumber: date.getDate(),
                isToday: isToday(date),
                isPast: isPast(date),
                events: dayEvents,
            };
        });
    }, [selectedDate, getEventsForWeek, language, isToday, isPast]);

    // Check if events overlap
    const eventsOverlap = useCallback((event1: CalendarEvent, event2: CalendarEvent): boolean => {
        const getMinutes = (time: string) => {
            const [hours, minutes] = time.split(':').map(Number);
            return hours! * 60 + minutes!;
        };
        const start1 = getMinutes(event1.time);
        const end1 = start1 + (event1.duration || 30);
        const start2 = getMinutes(event2.time);
        const end2 = start2 + (event2.duration || 30);
        return start1 < end2 && start2 < end1;
    }, []);

    // Get event style
    const getEventStyle = useCallback((event: CalendarEvent, eventsInSameDay: CalendarEvent[]) => {
        const [hours, minutes] = event.time.split(':').map(Number);
        const startMinutes = hours! * 60 + minutes!;
        const top = (startMinutes / 15) * QUARTER_SLOT_HEIGHT;

        const durationInMinutes = event.duration || 30;
        const height = (durationInMinutes / 15) * QUARTER_SLOT_HEIGHT;

        // Find overlapping events
        const overlappingEvents = eventsInSameDay.filter(e =>
            e.id !== event.id && eventsOverlap(event, e)
        );

        let columnIndex = 0;
        let totalColumns = 1;

        if (overlappingEvents.length > 0) {
            const allOverlapping = [event, ...overlappingEvents].sort((a, b) => {
                const timeCompare = a.time.localeCompare(b.time);
                if (timeCompare !== 0) return timeCompare;
                const aDuration = a.duration || 30;
                const bDuration = b.duration || 30;
                if (aDuration !== bDuration) return bDuration - aDuration;
                return a.id.localeCompare(b.id);
            });

            // Greedy column placement
            const columns: CalendarEvent[][] = [];
            for (const evt of allOverlapping) {
                let placed = false;
                for (let col = 0; col < columns.length; col++) {
                    const hasOverlap = columns[col]!.some(colEvent => eventsOverlap(evt, colEvent));
                    if (!hasOverlap) {
                        columns[col]!.push(evt);
                        placed = true;
                        break;
                    }
                }
                if (!placed) {
                    columns.push([evt]);
                }
            }

            columnIndex = columns.findIndex(col => col.some(e => e.id === event.id));
            totalColumns = columns.length;
        }

        const widthPercent = 100 / totalColumns;
        const leftPercent = columnIndex * widthPercent;

        return {
            top: `${top}px`,
            height: `${height}px`,
            width: `${widthPercent}%`,
            left: `${leftPercent}%`,
        };
    }, [eventsOverlap]);

    // Get current time position
    const getCurrentTimePosition = useCallback((date: Date): number | null => {
        if (!isToday(date)) return null;
        const now = new Date();
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();
        const minutesFromStart = currentHour * 60 + currentMinute;
        if (minutesFromStart < 0) return null;
        return (minutesFromStart / 60) * SLOT_HEIGHT;
    }, [isToday]);

    // Scroll to current day
    const scrollToCurrentDay = useCallback(() => {
        if (horizontalScrollRef.current) {
            const todayIndex = weekColumns.findIndex(col => col.isToday);
            if (todayIndex !== -1) {
                const scrollLeft = (todayIndex * DAY_COLUMN_WIDTH) - (horizontalScrollRef.current.clientWidth / 2) + (DAY_COLUMN_WIDTH / 2);
                horizontalScrollRef.current.scrollTo({ left: Math.max(0, scrollLeft), behavior: 'smooth' });
            } else {
                horizontalScrollRef.current.scrollTo({ left: 0, behavior: 'smooth' });
            }
        }
    }, [weekColumns]);

    // Scroll to business hours
    const scrollToBusinessHours = useCallback(() => {
        if (verticalScrollRef.current) {
            const viewportHeight = verticalScrollRef.current.clientHeight;
            const today = new Date();
            const workingHours = getWorkingHoursForDay(today);
            const startHour = workingHours?.start ?? 8;
            const endHour = workingHours?.end ?? 17;
            const businessHoursDuration = endHour - startHour;
            const businessHoursHeight = businessHoursDuration * SLOT_HEIGHT;
            const businessHoursStartPosition = startHour * SLOT_HEIGHT;
            const availableSpace = viewportHeight - businessHoursHeight;
            const scrollTop = businessHoursStartPosition - (availableSpace / 2);
            verticalScrollRef.current.scrollTo({ top: Math.max(0, scrollTop), behavior: 'smooth' });
        }
    }, [getWorkingHoursForDay]);

    // Auto-scroll on mount and date change
    useEffect(() => {
        if (hasInitialScrolled.current) return;
        const timer = setTimeout(() => {
            scrollToCurrentDay();
            scrollToBusinessHours();
            hasInitialScrolled.current = true;
        }, 100);
        return () => clearTimeout(timer);
    }, [scrollToCurrentDay, scrollToBusinessHours]);

    useEffect(() => {
        hasInitialScrolled.current = false;
        const timer = setTimeout(() => {
            scrollToCurrentDay();
            scrollToBusinessHours();
            hasInitialScrolled.current = true;
        }, 100);
        return () => clearTimeout(timer);
    }, [selectedDate, scrollToCurrentDay, scrollToBusinessHours]);

    return {
        // State
        weekColumns,
        timeSlots,
        isRTL,

        // Refs
        horizontalScrollRef,
        verticalScrollRef,

        // Functions
        isOutsideWorkingHours,
        getEventStyle,
        getCurrentTimePosition,
        getEventsInHour: (date: Date, hour: number) => {
            const column = weekColumns.find(col =>
                col.date.getDate() === date.getDate() &&
                col.date.getMonth() === date.getMonth()
            );
            return column?.events.filter(e => parseInt(e.time.split(':')[0]!, 10) === hour).length || 0;
        },
    };
}

export default useWeekGrid;
