// useDayGrid Hook - Business logic for day view grid
'use client';

import { useMemo, useCallback } from 'react';
import type { CalendarEvent, TimeSlotData, EventStyle } from '../types';
import { HOURS_START, SLOT_HEIGHT, QUARTER_SLOT_HEIGHT } from '../types';

// Re-export for convenience
export { HOURS_START, SLOT_HEIGHT, QUARTER_SLOT_HEIGHT };
export type { TimeSlotData, EventStyle };

interface UseDayGridOptions {
    selectedDate: Date;
    events: CalendarEvent[];
}

/**
 * Hook for day grid business logic
 */
export function useDayGrid({ selectedDate, events }: UseDayGridOptions) {
    // Check if date is today
    const isToday = useMemo(() => {
        const today = new Date();
        return (
            selectedDate.getDate() === today.getDate() &&
            selectedDate.getMonth() === today.getMonth() &&
            selectedDate.getFullYear() === today.getFullYear()
        );
    }, [selectedDate]);

    // Check if date is in the past
    const isPast = useMemo(() => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return selectedDate < today;
    }, [selectedDate]);

    // Generate time slots for the day
    const timeSlots = useMemo((): TimeSlotData[] => {
        const slots: TimeSlotData[] = [];
        for (let i = 0; i < 24; i++) {
            const hour = (HOURS_START + i) % 24;
            slots.push({
                hour: HOURS_START + i,
                minute: 0,
                label: `${String(hour).padStart(2, '0')}:00`,
            });
        }
        return slots;
    }, []);

    // Date label for display
    const dateLabel = useMemo(() => {
        return selectedDate.toLocaleDateString('fr-FR', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    }, [selectedDate]);

    // Check if two events overlap
    const eventsOverlap = useCallback((event1: CalendarEvent, event2: CalendarEvent): boolean => {
        const getMinutes = (time: string) => {
            const [hours, minutes] = time.split(':').map(Number);
            return hours! * 60 + minutes!;
        };

        const start1 = getMinutes(event1.time);
        const end1 = start1 + (event1.duration || 30);
        const start2 = getMinutes(event2.time);
        const end2 = start2 + (event2.duration || 30);

        return start1 < end2 && start2 < end1;
    }, []);

    // Calculate event style (position, size)
    const getEventStyle = useCallback((event: CalendarEvent): EventStyle => {
        const [hours, minutes] = event.time.split(':').map(Number);
        const startMinutes = hours! * 60 + minutes!;
        let offsetMinutes = startMinutes - HOURS_START * 60;

        // Handle early morning events (00:00 - 07:59)
        if (startMinutes < HOURS_START * 60) {
            offsetMinutes = (24 * 60) + startMinutes - HOURS_START * 60;
        }

        // Calculate top position
        const top = (offsetMinutes / 15) * QUARTER_SLOT_HEIGHT;

        // Calculate height
        const durationInMinutes = event.duration || 30;
        const baseSlotHeight = QUARTER_SLOT_HEIGHT * 2; // 40px for 30 min
        const height = durationInMinutes === 15
            ? baseSlotHeight / 2
            : Math.min(baseSlotHeight, (durationInMinutes / 30) * baseSlotHeight);

        // Find overlapping events for horizontal positioning
        const overlappingEvents = events.filter(e =>
            e.id !== event.id && eventsOverlap(event, e)
        );

        let columnIndex = 0;
        let totalColumns = 1;

        if (overlappingEvents.length > 0) {
            const allOverlapping = [event, ...overlappingEvents].sort((a, b) => {
                const timeCompare = a.time.localeCompare(b.time);
                if (timeCompare !== 0) return timeCompare;
                return a.id.localeCompare(b.id);
            });

            columnIndex = allOverlapping.findIndex(e => e.id === event.id);
            totalColumns = allOverlapping.length;
        }

        const widthPercent = 100 / totalColumns;
        const leftPercent = columnIndex * widthPercent;

        return {
            top: `${top}px`,
            height: `${height}px`,
            width: `${widthPercent}%`,
            left: `${leftPercent}%`,
        };
    }, [events, eventsOverlap]);

    // Check if time slot is in the past
    const isTimeSlotPast = useCallback((hour: number): boolean => {
        const now = new Date();
        const slotDate = new Date(selectedDate);

        if (hour >= 24) {
            slotDate.setDate(slotDate.getDate() + 1);
            slotDate.setHours(hour - 24, 0, 0, 0);
        } else {
            slotDate.setHours(hour, 0, 0, 0);
        }

        return slotDate < now;
    }, [selectedDate]);

    // Get current time offset for indicator
    const getCurrentTimeOffset = useCallback((): number => {
        const now = new Date();
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const startMinutes = HOURS_START * 60;

        if (currentMinutes < startMinutes) {
            return 0;
        }

        return currentMinutes - startMinutes;
    }, []);

    // Get current time indicator position
    const currentTimePosition = useMemo(() => {
        if (!isToday) return null;
        const offset = getCurrentTimeOffset();
        return (offset / 60) * SLOT_HEIGHT;
    }, [isToday, getCurrentTimeOffset]);

    return {
        // State
        isToday,
        isPast,
        timeSlots,
        dateLabel,
        currentTimePosition,

        // Functions
        getEventStyle,
        isTimeSlotPast,
        eventsOverlap,
        getCurrentTimeOffset,
    };
}

export default useDayGrid;
