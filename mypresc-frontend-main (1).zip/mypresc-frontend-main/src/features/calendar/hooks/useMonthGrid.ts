// useMonthGrid Hook - Business logic for month view grid
'use client';

import { useMemo, useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import type { CalendarEvent, DayCellData } from '../types';

// Re-export type for convenience
export type { DayCellData as DayCell };

interface UseMonthGridOptions {
    selectedDate: Date;
    getEventsForMonth: (date: Date) => CalendarEvent[];
}

/**
 * Hook for month grid business logic
 */
export function useMonthGrid({ selectedDate, getEventsForMonth }: UseMonthGridOptions) {
    const { language, isRTL } = useLanguage();

    // Week day names
    const weekDays = useMemo(() => {
        const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        const days = [1, 2, 3, 4, 5, 6, 0]; // Monday to Sunday
        return days.map(day => {
            const date = new Date(2024, 0, day + 1);
            return date.toLocaleDateString(locale, { weekday: 'short' });
        });
    }, [language]);

    // Utility functions
    const getMonthStart = (date: Date): Date => new Date(date.getFullYear(), date.getMonth(), 1);
    const getMonthEnd = (date: Date): Date => new Date(date.getFullYear(), date.getMonth() + 1, 0);

    const getCalendarStart = (monthStart: Date): Date => {
        const day = monthStart.getDay();
        const diff = day === 0 ? -6 : 1 - day; // Monday start
        const start = new Date(monthStart);
        start.setDate(monthStart.getDate() + diff);
        return start;
    };

    const isToday = useCallback((date: Date): boolean => {
        const today = new Date();
        return (
            date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear()
        );
    }, []);

    const isPast = useCallback((date: Date): boolean => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return date < today;
    }, []);

    const isSameMonth = (date1: Date, date2: Date): boolean => {
        return date1.getMonth() === date2.getMonth() && date1.getFullYear() === date2.getFullYear();
    };

    const isSameDay = (date1: Date, date2: Date): boolean => {
        return (
            date1.getDate() === date2.getDate() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getFullYear() === date2.getFullYear()
        );
    };

    // Get events for the month
    const monthEvents = useMemo(() => getEventsForMonth(selectedDate), [selectedDate, getEventsForMonth]);

    // Generate calendar cells (42 cells = 6 weeks)
    const calendarCells = useMemo((): DayCellData[] => {
        const monthStart = getMonthStart(selectedDate);
        const calendarStart = getCalendarStart(monthStart);

        const cells: DayCellData[] = [];
        const current = new Date(calendarStart);

        for (let i = 0; i < 42; i++) {
            const dayEvents = monthEvents.filter((event) => isSameDay(event.date, current));

            cells.push({
                date: new Date(current),
                dayNumber: current.getDate(),
                isCurrentMonth: isSameMonth(current, selectedDate),
                isToday: isToday(current),
                isPast: isPast(current),
                events: dayEvents,
            });

            current.setDate(current.getDate() + 1);
        }

        return cells;
    }, [selectedDate, monthEvents, isToday, isPast]);

    // Month label
    const monthLabel = useMemo(() => {
        const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        return selectedDate.toLocaleDateString(locale, {
            month: 'long',
            year: 'numeric',
        });
    }, [selectedDate, language]);

    // Calculate occupation rate (0-100)
    const getOccupationRate = useCallback((events: CalendarEvent[]): number => {
        if (events.length === 0) return 0;
        if (events.length >= 8) return 100;
        return (events.length / 8) * 100;
    }, []);

    // Get occupation color class
    const getOccupationColor = useCallback((rate: number): string => {
        if (rate === 0) return '';
        if (rate < 40) return 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800';
        if (rate < 70) return 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
        if (rate < 90) return 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800';
        return 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
    }, []);

    return {
        // State
        weekDays,
        calendarCells,
        monthLabel,
        isRTL,

        // Functions
        getOccupationRate,
        getOccupationColor,
    };
}

export default useMonthGrid;
