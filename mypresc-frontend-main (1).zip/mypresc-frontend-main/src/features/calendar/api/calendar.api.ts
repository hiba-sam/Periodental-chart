// Calendar API - Centralized API functions for calendar operations
import axios from 'axios';
import type {
    CalendarEvent,
    ApiCalendarEvent,
    CreateEventData,
    UpdateEventData,
    CalendarFilters
} from '../types';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// Axios instance for calendar API
export const calendarApi = axios.create({
    baseURL: `${API_URL}/calendar`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

/**
 * Calculate age from date of birth
 */
function calculateAge(dateOfBirth: string): number {
    const birthDate = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

/**
 * Calculate end time from start time and duration
 */
function calculateEndTime(startTime: string, duration: number): string {
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours! * 60 + minutes! + duration;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${endHours.toString().padStart(2, '0')}:${endMinutes.toString().padStart(2, '0')}`;
}

/**
 * Parse date string to local Date object (handles timezone)
 */
export function parseLocalDate(dateString: string): Date {
    if (!dateString) return new Date();

    // For ISO timestamps with time component
    if (dateString.includes('T')) {
        return new Date(dateString);
    }

    // For YYYY-MM-DD format, parse as local date
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year!, month! - 1, day!);
}

/**
 * Format Date to YYYY-MM-DD string
 */
export function formatLocalDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Map API event to CalendarEvent
 */
export function mapApiEventToCalendarEvent(apiEvent: ApiCalendarEvent): CalendarEvent {
    const eventDate = parseLocalDate(apiEvent.date);
    const endTime = calculateEndTime(apiEvent.time, apiEvent.duration || 30);

    return {
        id: apiEvent.id,
        date: eventDate,
        time: apiEvent.time,
        duration: apiEvent.duration || 30,
        title: apiEvent.title || '',
        description: apiEvent.note,
        color: apiEvent.color || '#3B82F6',
        patientId: apiEvent.patient_id,
        patientName: apiEvent.patient_name,
        patientFamilyName: apiEvent.patient_family_name,
        patientPhone: apiEvent.patient_phone,
        patientAge: apiEvent.patient_date_of_birth
            ? calculateAge(apiEvent.patient_date_of_birth)
            : undefined,
        confirmedComing: apiEvent.confirmed_coming,
        venueConfirmed: apiEvent.venue_confirmed,
        isDone: apiEvent.is_done,
        appointmentId: apiEvent.appointment_id,
        isAppointmentLinked: !!apiEvent.appointment_id,
        endTime,
    };
}

/**
 * Fetch all calendar events
 */
export async function fetchCalendarEvents(filters?: CalendarFilters): Promise<CalendarEvent[]> {
    const params: Record<string, string> = {};

    if (filters?.startDate) {
        params.startDate = formatLocalDate(filters.startDate);
    }
    if (filters?.endDate) {
        params.endDate = formatLocalDate(filters.endDate);
    }
    if (filters?.patientId) {
        params.patientId = filters.patientId;
    }

    const response = await calendarApi.get('/events', { params });
    const events = response.data.data || response.data || [];
    return events.map(mapApiEventToCalendarEvent);
}

/**
 * Fetch single event by ID
 */
export async function fetchEventById(eventId: string): Promise<CalendarEvent | null> {
    const response = await calendarApi.get(`/event/${eventId}`);
    const event = response.data.data || response.data;
    return event ? mapApiEventToCalendarEvent(event) : null;
}

/**
 * Create a new calendar event
 */
export async function createCalendarEvent(data: CreateEventData): Promise<CalendarEvent> {
    const payload = {
        title: data.title || '',
        date: formatLocalDate(data.date),
        time: data.time,
        duration: data.duration || 30,
        note: data.notes,
        color: data.color || '#3B82F6',
        patient_id: data.patientId,
        is_appointment: data.isAppointment || false,
        confirmed_coming: data.confirmedComing,
    };

    const response = await calendarApi.post('/event', payload);
    const event = response.data.data || response.data;
    return mapApiEventToCalendarEvent(event);
}

/**
 * Update an existing calendar event
 */
export async function updateCalendarEvent(data: UpdateEventData): Promise<CalendarEvent> {
    const payload: Record<string, unknown> = {};

    if (data.title !== undefined) payload.title = data.title;
    if (data.note !== undefined) payload.note = data.note;
    if (data.date !== undefined) payload.date = formatLocalDate(data.date);
    if (data.time !== undefined) payload.time = data.time;
    if (data.duration !== undefined) payload.duration = data.duration;
    if (data.color !== undefined) payload.color = data.color;
    if (data.is_done !== undefined) payload.is_done = data.is_done;
    if (data.confirmed_coming !== undefined) payload.confirmed_coming = data.confirmed_coming;
    if (data.venue_confirmed !== undefined) payload.venue_confirmed = data.venue_confirmed;
    if (data.appointment_notes !== undefined) payload.appointment_notes = data.appointment_notes;

    const response = await calendarApi.put(`/event/${data.id}`, payload);
    const event = response.data.data || response.data;
    return mapApiEventToCalendarEvent(event);
}

/**
 * Delete a calendar event
 */
export async function deleteCalendarEvent(eventId: string): Promise<boolean> {
    await calendarApi.delete(`/event/${eventId}`);
    return true;
}
