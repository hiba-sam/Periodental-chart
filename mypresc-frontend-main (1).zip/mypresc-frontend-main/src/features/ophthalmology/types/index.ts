// ─── Ophthalmology Report Types ──────────────────────────────────────────────

export interface EyeRefraction {
    sph:   number | null;
    cyl:   number | null;
    axis:  number | null;
    hPri:  number | null;
    vPri:  number | null;
    prism: number | null;
    angle: number | null;
    vd:    number | null;
}

export interface PupillaryDistance {
    r: number | null;
    l: number | null;
    b: number | null;
}

export interface ExamDistanceData {
    distanceCm: number;
    right:      EyeRefraction;
    left:       EyeRefraction;
    pd:         PupillaryDistance;
}

export interface MeasurementType {
    typeNo:    number;
    typeName:  string;
    distances: ExamDistanceData[];
}

export interface OphthalmologyReport {
    id:             number;
    patient_id:     string;
    doctor_user_id: number;

    // Machine metadata
    machine_company?:     string | null;
    machine_model?:       string | null;
    machine_no?:          string | null;
    machine_rom_version?: string | null;
    schema_version?:      string | null;
    exam_date:            string;   // ISO date
    exam_time?:           string;
    exam_duration?:       string | null;

    // Prescription — Far
    rx_far_right_sph?:   number | null;
    rx_far_right_cyl?:   number | null;
    rx_far_right_axis?:  number | null;
    rx_far_right_h_pri?: number | null;
    rx_far_right_v_pri?: number | null;
    rx_far_left_sph?:    number | null;
    rx_far_left_cyl?:    number | null;
    rx_far_left_axis?:   number | null;
    rx_far_left_h_pri?:  number | null;
    rx_far_left_v_pri?:  number | null;
    rx_far_vd?:          number | null;
    rx_far_pd_r?:        number | null;
    rx_far_pd_l?:        number | null;
    rx_far_pd_b?:        number | null;

    // Prescription — Near
    rx_near_right_sph?:   number | null;
    rx_near_right_cyl?:   number | null;
    rx_near_right_axis?:  number | null;
    rx_near_right_h_pri?: number | null;
    rx_near_right_v_pri?: number | null;
    rx_near_left_sph?:    number | null;
    rx_near_left_cyl?:    number | null;
    rx_near_left_axis?:   number | null;
    rx_near_left_h_pri?:  number | null;
    rx_near_left_v_pri?:  number | null;
    rx_near_vd?:          number | null;
    rx_near_pd_r?:        number | null;
    rx_near_pd_l?:        number | null;
    rx_near_pd_b?:        number | null;

    // Doctor annotations
    clinical_notes?: string | null;
    diagnosis?:      string | null;

    // Raw dump
    raw_measurements?: MeasurementType[] | null;

    // Audit
    created_at: string;
    updated_at: string;
    doctor_name?:        string;
    doctor_family_name?: string;
}

export interface UpdateOphthoAnnotations {
    clinical_notes?: string;
    diagnosis?:      string;
}

/** Formatted diopter value with + prefix for positive.
 *  Coerces to number because pg returns NUMERIC cols as strings. */
export function formatDiop(v: number | string | null | undefined): string {
    if (v === null || v === undefined || v === '') return '—';
    const n = typeof v === 'number' ? v : parseFloat(String(v));
    if (isNaN(n)) return '—';
    return (n >= 0 ? '+' : '') + n.toFixed(2);
}

/** Compute ADD = near_sph - far_sph.
 *  Coerces to number because pg returns NUMERIC cols as strings. */
export function computeAdd(
    report: OphthalmologyReport,
    eye: 'right' | 'left',
): string {
    const nearRaw = eye === 'right' ? report.rx_near_right_sph : report.rx_near_left_sph;
    const farRaw  = eye === 'right' ? report.rx_far_right_sph  : report.rx_far_left_sph;
    if (nearRaw == null || farRaw == null) return '—';
    const near = typeof nearRaw === 'number' ? nearRaw : parseFloat(String(nearRaw));
    const far  = typeof farRaw  === 'number' ? farRaw  : parseFloat(String(farRaw));
    if (isNaN(near) || isNaN(far)) return '—';
    const add = near - far;
    return (add >= 0 ? '+' : '') + add.toFixed(2);
}
