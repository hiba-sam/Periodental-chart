'use client';

import React, { useMemo, useState } from 'react';
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    ReferenceLine,
} from 'recharts';
import { TrendingUp, ChevronDown, ChevronUp } from 'lucide-react';
import type { OphthalmologyReport } from '../types';

interface RefractionsEvolutionChartProps {
    reports: OphthalmologyReport[];
}

// ─── Palette ───────────────────────────────────────────────────────────────────
const C = {
    odSph:  '#1a7fa0',  // teal
    osSph:  '#0d9488',  // darker teal
    odCyl:  '#f59e0b',  // amber
    osCyl:  '#d97706',  // darker amber
    zero:   '#94a3b8',  // slate reference
};

type TabKey = 'far' | 'near';

// ─── Custom tooltip ────────────────────────────────────────────────────────────
function CustomTooltip({ active, payload, label }: any) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg p-3 text-xs min-w-[140px]">
            <p className="font-semibold text-gray-700 dark:text-gray-200 mb-2">{label}</p>
            {payload.map((p: any) => (
                <div key={p.dataKey} className="flex items-center justify-between gap-3 mb-0.5">
                    <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
                        <span className="text-gray-500 dark:text-gray-400">{p.name}</span>
                    </div>
                    <span className="font-semibold tabular-nums" style={{ color: p.color }}>
                        {p.value != null ? (p.value >= 0 ? `+${p.value.toFixed(2)}` : p.value.toFixed(2)) : '—'} D
                    </span>
                </div>
            ))}
        </div>
    );
}

// ─── toN helper ───────────────────────────────────────────────────────────────
function toN(v: any): number | null {
    if (v == null || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v));
    return isNaN(n) ? null : n;
}

// ─── Component ────────────────────────────────────────────────────────────────
export function RefractionsEvolutionChart({ reports }: RefractionsEvolutionChartProps) {
    const [expanded, setExpanded] = useState(false);
    const [tab, setTab] = useState<TabKey>('far');

    // Only show when ≥ 2 reports exist
    if (reports.length < 2) return null;

    // Sort ascending by exam date
    const sorted = useMemo(() =>
        [...reports].sort((a, b) => new Date(a.exam_date).getTime() - new Date(b.exam_date).getTime()),
    [reports]);

    const chartData = useMemo(() =>
        sorted.map(r => ({
            date: new Date(r.exam_date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: '2-digit' }),
            // Far
            odSphFar: toN(r.rx_far_right_sph),
            osSphFar: toN(r.rx_far_left_sph),
            odCylFar: toN(r.rx_far_right_cyl),
            osCylFar: toN(r.rx_far_left_cyl),
            // Near
            odSphNear: toN(r.rx_near_right_sph),
            osSphNear: toN(r.rx_near_left_sph),
            odCylNear: toN(r.rx_near_right_cyl),
            osCylNear: toN(r.rx_near_left_cyl),
        })),
    [sorted]);

    const lines = tab === 'far'
        ? [
            { key: 'odSphFar',  name: 'OD Sph',  color: C.odSph  },
            { key: 'osSphFar',  name: 'OG Sph',  color: C.osSph  },
            { key: 'odCylFar',  name: 'OD Cyl',  color: C.odCyl  },
            { key: 'osCylFar',  name: 'OG Cyl',  color: C.osCyl  },
        ]
        : [
            { key: 'odSphNear', name: 'OD Sph',  color: C.odSph  },
            { key: 'osSphNear', name: 'OG Sph',  color: C.osSph  },
            { key: 'odCylNear', name: 'OD Cyl',  color: C.odCyl  },
            { key: 'osCylNear', name: 'OG Cyl',  color: C.osCyl  },
        ];

    // Latest values summary
    const latestIdx = chartData.length - 1;
    const latest = chartData[latestIdx];

    return (
        <div className="rounded-xl border border-sky-200 dark:border-sky-800 bg-sky-50/60 dark:bg-sky-900/10 overflow-hidden">
            {/* Header row */}
            <button
                className="w-full flex items-center justify-between px-4 py-3 text-left"
                onClick={() => setExpanded(e => !e)}
            >
                <div className="flex items-center gap-2 text-sky-700 dark:text-sky-400">
                    <TrendingUp className="w-4 h-4" />
                    <span className="text-sm font-semibold">Évolution réfractive</span>
                    <span className="text-xs text-sky-500 dark:text-sky-500">({reports.length} bilans)</span>
                </div>
                {expanded
                    ? <ChevronUp className="w-4 h-4 text-sky-500" />
                    : <ChevronDown className="w-4 h-4 text-sky-500" />}
            </button>

            {expanded && (
                <div className="px-4 pb-5 space-y-4">
                    {/* Distance tabs */}
                    <div className="flex gap-2">
                        {(['far', 'near'] as TabKey[]).map(t => (
                            <button
                                key={t}
                                onClick={() => setTab(t)}
                                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                                    tab === t
                                        ? 'bg-sky-600 text-white'
                                        : 'bg-white dark:bg-gray-800 text-sky-700 dark:text-sky-400 border border-sky-200 dark:border-sky-700 hover:bg-sky-50'
                                }`}
                            >
                                {t === 'far' ? 'Loin' : 'Près'}
                            </button>
                        ))}
                    </div>

                    {/* Latest value badges */}
                    <div className="flex flex-wrap gap-2">
                        {lines.map(l => {
                            const v = (latest as any)[l.key];
                            return (
                                <div key={l.key} className="flex items-center gap-1.5 px-2.5 py-1 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 text-xs">
                                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: l.color }} />
                                    <span className="text-gray-500 dark:text-gray-400">{l.name}</span>
                                    <span className="font-bold tabular-nums" style={{ color: l.color }}>
                                        {v != null ? (v >= 0 ? `+${v.toFixed(2)}` : v.toFixed(2)) : '—'}
                                    </span>
                                </div>
                            );
                        })}
                    </div>

                    {/* Chart */}
                    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-3">
                        <ResponsiveContainer width="100%" height={240}>
                            <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                <XAxis
                                    dataKey="date"
                                    tick={{ fontSize: 10, fill: '#6b7280' }}
                                    tickLine={false}
                                    axisLine={{ stroke: '#d1d5db' }}
                                />
                                <YAxis
                                    tick={{ fontSize: 10, fill: '#6b7280' }}
                                    tickLine={false}
                                    axisLine={false}
                                    width={40}
                                    tickFormatter={(v: number) => (v >= 0 ? `+${v}` : String(v))}
                                />
                                <Tooltip content={<CustomTooltip />} />
                                <Legend
                                    verticalAlign="bottom"
                                    height={28}
                                    iconType="circle"
                                    iconSize={8}
                                    wrapperStyle={{ fontSize: '11px' }}
                                />
                                {/* Zero reference line */}
                                <ReferenceLine y={0} stroke={C.zero} strokeDasharray="4 3" />
                                {lines.map(l => (
                                    <Line
                                        key={l.key}
                                        type="monotone"
                                        dataKey={l.key}
                                        name={l.name}
                                        stroke={l.color}
                                        strokeWidth={2}
                                        dot={{ r: 3.5, fill: l.color, strokeWidth: 1.5, stroke: '#fff' }}
                                        activeDot={{ r: 5, strokeWidth: 0 }}
                                        connectNulls
                                    />
                                ))}
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            )}
        </div>
    );
}
