'use client';

import React, { useState } from 'react';
import { ChevronDown, ChevronUp, FileText, Trash2, Loader2 } from 'lucide-react';
import type { OphthalmologyReport } from '../types';
import { formatDiop, computeAdd } from '../types';
import { RxTable } from './RxTable';
import { AxisDial } from './AxisDial';
import { downloadOphthoReportPdf, deleteOphthoReport } from '../hooks/useOphthoReports';

interface OphthoReportCardProps {
    report: OphthalmologyReport;
    currentUserId?: number;
    onDeleted?: (id: number) => void;
}

export function OphthoReportCard({
    report,
    currentUserId,
    onDeleted,
}: OphthoReportCardProps) {
    const [expanded,   setExpanded]   = useState(false);
    const [deleting,   setDeleting]   = useState(false);
    const [confirmDel, setConfirmDel] = useState(false);

    const isOwner = currentUserId === report.doctor_user_id;

    const examDateLabel = report.exam_date
        ? new Date(report.exam_date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
        : '—';

    const machineStr = [report.machine_company, report.machine_model].filter(Boolean).join(' ');

    async function handleDelete() {
        setDeleting(true);
        try {
            await deleteOphthoReport(report.id);
            onDeleted?.(report.id);
        } catch (e) {
            console.error(e);
        } finally {
            setDeleting(false);
            setConfirmDel(false);
        }
    }

    return (
        <div className="rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 overflow-hidden transition-shadow hover:shadow-md">
            {/* ── Summary row ──────────────────────────────────────────── */}
            <div
                className="flex items-center justify-between px-4 py-3 cursor-pointer select-none"
                onClick={() => setExpanded(e => !e)}
            >
                <div className="flex items-center gap-3">
                    <span className="p-1.5 rounded-lg bg-sky-100 dark:bg-sky-900/30 text-sky-600 dark:text-sky-400">
                        <FileText className="w-4 h-4" />
                    </span>
                    <div>
                        <p className="text-sm font-semibold text-gray-800 dark:text-white">{examDateLabel}</p>
                        {machineStr && (
                            <p className="text-xs text-gray-400 dark:text-gray-500">{machineStr}</p>
                        )}
                    </div>
                </div>

                {/* Quick Rx summary */}
                <div className="hidden sm:flex gap-6 text-xs text-gray-600 dark:text-gray-400">
                    <span>
                        <strong className="text-sky-700 dark:text-sky-400">OD</strong>{' '}
                        Sph {formatDiop(report.rx_far_right_sph)} / Cyl {formatDiop(report.rx_far_right_cyl)}
                    </span>
                    <span>
                        <strong className="text-sky-700 dark:text-sky-400">OG</strong>{' '}
                        Sph {formatDiop(report.rx_far_left_sph)} / Cyl {formatDiop(report.rx_far_left_cyl)}
                    </span>
                </div>

                <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    {/* PDF */}
                    <button
                        onClick={() => downloadOphthoReportPdf(report.id)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-sky-900/20 transition-colors"
                        title="Télécharger PDF"
                    >
                        <FileText className="w-4 h-4" />
                    </button>
                    {/* Delete */}
                    {isOwner && (
                        <button
                            onClick={() => setConfirmDel(true)}
                            className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                            title="Supprimer"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                    )}
                    {expanded
                        ? <ChevronUp className="w-4 h-4 text-gray-400" onClick={() => setExpanded(e => !e)}/>
                        : <ChevronDown className="w-4 h-4 text-gray-400" onClick={() => setExpanded(e => !e)}/>}
                </div>
            </div>

            {/* ── Expanded detail ───────────────────────────────────────── */}
            {expanded && (
                <div className="border-t border-gray-100 dark:border-gray-700 px-4 py-3 space-y-3">

                    {/* Far + Near side by side */}
                    <div className="grid grid-cols-2 gap-3">
                        {/* Far */}
                        <div>
                            <p className="text-[10px] font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide mb-1.5">
                                Loin
                            </p>
                            <RxTable report={report} distance="far" />
                            <div className="flex gap-3 mt-2 justify-center">
                                <AxisDial axis={report.rx_far_right_axis} label="OD" size={52} />
                                <AxisDial axis={report.rx_far_left_axis}  label="OG" size={52} />
                            </div>
                        </div>

                        {/* Near */}
                        <div>
                            <div className="flex items-center justify-between mb-1.5">
                                <p className="text-[10px] font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide">
                                    Près
                                </p>
                                <div className="flex gap-2 text-[10px] font-semibold text-teal-700 dark:text-teal-400">
                                    <span>ADD OD {computeAdd(report, 'right')}</span>
                                    <span className="text-gray-300 dark:text-gray-600">|</span>
                                    <span>OG {computeAdd(report, 'left')}</span>
                                </div>
                            </div>
                            <RxTable report={report} distance="near" showAdd />
                            <div className="flex gap-3 mt-2 justify-center">
                                <AxisDial axis={report.rx_near_right_axis} label="OD" size={52} />
                                <AxisDial axis={report.rx_near_left_axis}  label="OG" size={52} />
                            </div>
                        </div>
                    </div>

                    {/* Diagnosis / Notes */}
                    {(report.diagnosis || report.clinical_notes) && (
                        <div className="rounded-lg bg-sky-50 dark:bg-sky-900/20 border border-sky-100 dark:border-sky-800 px-3 py-2 space-y-0.5">
                            {report.diagnosis && (
                                <p className="text-xs font-medium text-gray-800 dark:text-white">{report.diagnosis}</p>
                            )}
                            {report.clinical_notes && (
                                <p className="text-xs text-gray-500 dark:text-gray-400 italic">{report.clinical_notes}</p>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* ── Delete confirm overlay ────────────────────────────────── */}
            {confirmDel && (
                <div className="border-t border-red-100 dark:border-red-900 bg-red-50 dark:bg-red-900/20 px-4 py-3 flex items-center justify-between gap-3">
                    <p className="text-sm text-red-700 dark:text-red-400 font-medium">Supprimer ce rapport ?</p>
                    <div className="flex gap-2">
                        <button
                            onClick={() => setConfirmDel(false)}
                            className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                        >
                            Annuler
                        </button>
                        <button
                            onClick={handleDelete}
                            disabled={deleting}
                            className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg disabled:opacity-60"
                        >
                            {deleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                            Supprimer
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
