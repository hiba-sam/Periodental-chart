import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Routes that accept multipart/form-data (file uploads)
const MULTIPART_ALLOWED_ROUTES = [
  '/api/',
  '/messages',
];

export function middleware(request: NextRequest) {
  const contentType = request.headers.get('content-type') || '';
  const pathname = request.nextUrl.pathname;
  
  // Block multipart/form-data on routes that don't expect it
  if (contentType.includes('multipart/form-data')) {
    const isAllowed = MULTIPART_ALLOWED_ROUTES.some(route => pathname.startsWith(route));
    
    if (!isAllowed) {
      // Return 400 Bad Request for unexpected multipart requests
      return new NextResponse(
        JSON.stringify({ error: 'Invalid content type for this route' }),
        { 
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        }
      );
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    // Match all routes except static files and _next
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
