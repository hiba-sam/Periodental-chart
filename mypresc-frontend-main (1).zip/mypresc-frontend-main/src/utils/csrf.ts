/**
 * CSRF Token Helper - Frontend
 * 
 * Utilitaires pour lire et envoyer le token CSRF
 * Protection contre les attaques Cross-Site Request Forgery
 */

/**
 * Lit le token CSRF depuis les cookies
 */
export function getCsrfToken(): string | null {
    const name = 'XSRF-TOKEN=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const cookies = decodedCookie.split(';');
    
    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.indexOf(name) === 0) {
            return cookie.substring(name.length);
        }
    }
    
    return null;
}

/**
 * Crée les headers avec le token CSRF pour les requêtes
 */
export function getCsrfHeaders(): Record<string, string> {
    const csrfToken = getCsrfToken();
    
    if (!csrfToken) {
        console.warn('⚠️ CSRF token not found in cookies');
        return {};
    }
    
    return {
        'X-CSRF-Token': csrfToken
    };
}

/**
 * Vérifie si le token CSRF est présent
 */
export function hasCsrfToken(): boolean {
    return getCsrfToken() !== null;
}

export default {
    getCsrfToken,
    getCsrfHeaders,
    hasCsrfToken
};
