const logger = {
    log: (...args: unknown[]) => {
        if (process.env.NODE_ENV === 'development') {
            console.log(...args);
        }
    },
    error: (...args: unknown[]) => {
        console.error(...args); // Always log errors
    },
    warn: (...args: unknown[]) => {
        if (process.env.NODE_ENV === 'development') {
            console.warn(...args);
        }
    },
    debug: (...args: unknown[]) => {
        if (process.env.NODE_ENV === 'development') {
            console.debug(...args);
        }
    },
    info: (...args: unknown[]) => {
        if (process.env.NODE_ENV === 'development') {
            console.info(...args);
        }
    },
};

export default logger;
