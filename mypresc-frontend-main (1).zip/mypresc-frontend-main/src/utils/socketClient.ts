import { io, Socket } from 'socket.io-client';
import logger from './logger';

const SOCKET_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface OptimisticMessage {
  tempId: string;
  id: number | null;
  conversation_id: number;
  sender_id: number;
  content: string;
  created_at: Date | string;
  sender_name: string;
  is_read: boolean;
  is_edited: boolean;
  isPending?: boolean;
  isFailed?: boolean;
}

class SocketClient {
  private socket: Socket | null = null;
  private token: string | null = null;
  private messageCallbacks: Map<string, Function> = new Map();
  private pendingMessages: Map<string, OptimisticMessage> = new Map();
  private doctorAssistantsRoom: string | number | null = null;
  private onConnectCallbacks: Set<() => void> = new Set();

  // Connection state tracking
  private _isConnected: boolean = false;
  private _isReconnecting: boolean = false;
  private connectionCallbacks: {
    onConnect?: () => void;
    onDisconnect?: (reason: string) => void;
    onReconnecting?: (attempt: number) => void;
    onReconnectFailed?: () => void;
  } = {};

  /**
   * Initialize socket connection with cookies
   */
  connect(): Socket {
    if (this.socket?.connected) {
      return this.socket;
    }

    // Disconnect existing socket
    if (this.socket) {
      this.socket.disconnect();
    }

    this.socket = io(SOCKET_URL, {
      withCredentials: true, // Envoie les cookies HTTP-only
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    this.setupListeners();

    return this.socket;
  }

  /**
   * Setup default event listeners
   */
  private setupListeners(): void {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      logger.log('[Socket] Connected:', this.socket?.id);
      this._isConnected = true;
      this._isReconnecting = false;

      // Auto-join doctor-assistants room if set
      if (this.doctorAssistantsRoom) {
        logger.log('[Socket] Auto-joining doctor-assistants room:', this.doctorAssistantsRoom);
        this.socket?.emit('join:doctor-assistants', { doctorId: this.doctorAssistantsRoom }, (response: any) => {
          if (response?.error) {
            logger.error('[Socket] Failed to auto-join doctor-assistants room:', response.error);
          } else {
            logger.log('[Socket] Auto-joined doctor-assistants room:', this.doctorAssistantsRoom);
          }
        });
      }

      // Call all registered onConnect callbacks
      this.onConnectCallbacks.forEach(callback => {
        try {
          callback();
        } catch (e) {
          logger.error('[Socket] onConnect callback error:', e);
        }
      });

      this.connectionCallbacks.onConnect?.();
    });

    this.socket.on('disconnect', (reason) => {
      logger.log('[Socket] Disconnected:', reason);
      this._isConnected = false;
      this.connectionCallbacks.onDisconnect?.(reason);
    });

    this.socket.on('connect_error', (error) => {
      logger.error('[Socket] Connection error:', error.message);
    });

    this.socket.io.on('reconnect_attempt', (attempt) => {
      logger.log('[Socket] Reconnecting... attempt', attempt);
      this._isReconnecting = true;
      this.connectionCallbacks.onReconnecting?.(attempt);
    });

    this.socket.io.on('reconnect', () => {
      logger.log('[Socket] Reconnected successfully');
      this._isReconnecting = false;
    });

    this.socket.io.on('reconnect_failed', () => {
      logger.error('[Socket] Reconnection failed');
      this._isReconnecting = false;
      this.connectionCallbacks.onReconnectFailed?.();
    });

    this.socket.on('error', (error) => {
      logger.error('[Socket] Error:', error);
    });

    // Handle message confirmation (optimistic update)
    this.socket.on('message:confirmed', (data: {
      tempId: string;
      realId: number;
      message: any;
    }) => {
      const callback = this.messageCallbacks.get(data.tempId);
      if (callback) {
        callback({ confirmed: true, realId: data.realId, message: data.message });
        this.messageCallbacks.delete(data.tempId);
      }
      this.pendingMessages.delete(data.tempId);
    });

    // Handle message failure (rollback optimistic update)
    this.socket.on('message:failed', (data: {
      tempId: string;
      error: string;
    }) => {
      const callback = this.messageCallbacks.get(data.tempId);
      if (callback) {
        callback({ failed: true, error: data.error });
        this.messageCallbacks.delete(data.tempId);
      }

      const pending = this.pendingMessages.get(data.tempId);
      if (pending) {
        pending.isFailed = true;
      }
    });
  }

  /**
   * Get current socket instance
   */
  getSocket(): Socket | null {
    return this.socket;
  }

  /**
   * Check if socket is connected
   */
  isConnected(): boolean {
    return this.socket?.connected || false;
  }

  /**
   * Register a callback to be called when socket connects
   * If already connected, callback is called immediately
   */
  onConnect(callback: () => void): () => void {
    // If already connected, call immediately
    if (this.socket?.connected) {
      logger.log('[Socket] onConnect: Already connected, calling callback immediately');
      callback();
    }

    // Add to callbacks set to be called on future connects/reconnects
    this.onConnectCallbacks.add(callback);
    logger.log('[Socket] onConnect: Registered callback, total:', this.onConnectCallbacks.size);

    // Return cleanup function
    return () => {
      this.onConnectCallbacks.delete(callback);
    };
  }

  /**
   * Disconnect socket
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.token = null;
      this.messageCallbacks.clear();
      this.pendingMessages.clear();
    }
  }

  /**
   * Check if message is still pending
   */
  isPending(tempId: string): boolean {
    return this.pendingMessages.has(tempId);
  }

  /**
   * Get pending message by temp ID
   */
  getPendingMessage(tempId: string): OptimisticMessage | undefined {
    return this.pendingMessages.get(tempId);
  }

  /**
   * Join a conversation room
   */
  joinConversation(conversationId: number, callback?: (response: any) => void): void {
    if (!this.socket?.connected) {
      logger.warn('[Socket] Not connected, cannot join conversation');
      return;
    }

    this.socket.emit('conversation:join', { conversationId }, (response: any) => {
      if (response?.error) {
        logger.error('[Socket] Failed to join conversation:', response.error);
      } else {
        logger.log('[Socket] Joined conversation:', conversationId);
      }
      callback?.(response);
    });
  }

  /**
   * Leave a conversation room
   */
  leaveConversation(conversationId: number): void {
    if (!this.socket?.connected) return;

    this.socket.emit('conversation:leave', { conversationId }, (response: any) => {
      logger.log('[Socket] Left conversation:', conversationId);
    });
  }

  /**
   * Join doctor-assistants room for real-time waiting room updates
   * Stores the doctorId so it auto-joins on reconnect
   */
  joinDoctorAssistantsRoom(doctorId: number | string): void {
    // Store for auto-join on connect/reconnect
    this.doctorAssistantsRoom = doctorId;
    logger.log('[Socket] Set doctor-assistants room to:', doctorId);

    const doJoin = () => {
      if (this.socket?.connected) {
        logger.log('[Socket] Emitting join:doctor-assistants for room:', doctorId);
        this.socket.emit('join:doctor-assistants', { doctorId }, (response: any) => {
          if (response?.error) {
            logger.error('[Socket] Failed to join doctor-assistants room:', response.error);
          } else {
            logger.log('[Socket] Joined doctor-assistants room:', doctorId);
          }
        });
      }
    };

    // If already connected, join immediately
    if (this.socket?.connected) {
      logger.log('[Socket] Already connected, joining room now');
      doJoin();
    } else {
      logger.log('[Socket] Not connected yet, adding connect listener');
      // Add listener for when socket connects
      this.socket?.once('connect', () => {
        logger.log('[Socket] Connect event received, joining room');
        doJoin();
      });
    }
  }

  /**
   * ⚡ OPTIMIZED: Send message with instant UI update
   *
   * Returns immediately with temp ID for optimistic UI
   */
  sendMessageOptimistic(
    conversationId: number,
    content: string,
    senderId: number,
    senderName: string,
    onUpdate: (update: { confirmed?: boolean; failed?: boolean; realId?: number; message?: any; error?: string }) => void
  ): OptimisticMessage {
    const tempId = `temp_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
    const now = new Date();

    // Create optimistic message
    const optimisticMessage: OptimisticMessage = {
      tempId,
      id: null,
      conversation_id: conversationId,
      sender_id: senderId,
      content,
      created_at: now,
      sender_name: senderName,
      is_read: false,
      is_edited: false,
      isPending: true,
    };

    // Store callback for confirmation
    this.messageCallbacks.set(tempId, onUpdate);
    this.pendingMessages.set(tempId, optimisticMessage);

    // Send to server (non-blocking)
    this.socket?.emit('message:send', {
      conversationId,
      content,
      tempId,
    }, (response: any) => {
      if (response?.error) {
        logger.error('[Socket] Send failed:', response.error);
        onUpdate({ failed: true, error: response.error });
      }
    });

    // Return immediately for UI
    return optimisticMessage;
  }

  /**
   * Send a message (legacy method for backward compatibility)
   */
  sendMessage(
    conversationId: number,
    content: string,
    callback?: (response: any) => void
  ): void {
    if (!this.socket?.connected) {
      logger.error('[Socket] Not connected');
      callback?.({ error: 'Not connected to server' });
      return;
    }

    this.socket.emit(
      'message:send',
      { conversationId, content },
      (response: any) => {
        if (response?.error) {
          logger.error('[Socket] Send message error:', response.error);
        }
        callback?.(response);
      }
    );
  }

  /**
   * ⚡ OPTIMIZED: Batch mark messages as read
   */
  markMessagesAsRead(messageIds: number[]): void {
    // Filter out invalid IDs (null, undefined, non-numbers)
    const validIds = messageIds.filter(id => id && typeof id === 'number');
    if (!this.socket?.connected || validIds.length === 0) return;

    this.socket.emit('message:read', { messageIds: validIds }, (response: any) => {
      if (response?.error) {
        logger.error('[Socket] Mark read error:', response.error);
      }
    });
  }

  /**
   * Mark message as read (legacy method for backward compatibility)
   */
  markAsRead(messageId: number): void {
    if (!messageId || typeof messageId !== 'number') return;
    this.markMessagesAsRead([messageId]);
  }

  /**
   * Update presence status
   */
  updatePresence(status: 'online' | 'away' | 'offline'): void {
    if (!this.socket?.connected) return;

    this.socket.emit('presence:update', { status });
  }

  /**
   * Start typing indicator
   */
  startTyping(conversationId: number): void {
    if (!this.socket?.connected) return;
    this.socket.emit('typing:start', { conversationId });
  }

  /**
   * Stop typing indicator
   */
  stopTyping(conversationId: number): void {
    if (!this.socket?.connected) return;
    this.socket.emit('typing:stop', { conversationId });
  }

  /**
   * Listen to an event
   */
  on(event: string, handler: (...args: any[]) => void): void {
    this.socket?.on(event, handler);
  }

  /**
   * Stop listening to an event
   */
  off(event: string, handler?: (...args: any[]) => void): void {
    this.socket?.off(event, handler);
  }

  /**
   * Get current connection state
   */
  get connectionState(): { isConnected: boolean; isReconnecting: boolean } {
    return {
      isConnected: this._isConnected,
      isReconnecting: this._isReconnecting,
    };
  }

  /**
   * Set callbacks for connection events
   * Used by UI components to show connection status
   */
  setConnectionCallbacks(callbacks: {
    onConnect?: () => void;
    onDisconnect?: (reason: string) => void;
    onReconnecting?: (attempt: number) => void;
    onReconnectFailed?: () => void;
  }): void {
    this.connectionCallbacks = callbacks;
  }

  /**
   * Clear connection callbacks
   */
  clearConnectionCallbacks(): void {
    this.connectionCallbacks = {};
  }
}

// Singleton instance
const socketClient = new SocketClient();

export default socketClient;
