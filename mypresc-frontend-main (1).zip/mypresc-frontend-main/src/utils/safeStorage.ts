/**
 * Safe localStorage wrapper — prevents SecurityError crashes
 * when the browser blocks storage access (InPrivate mode,
 * strict privacy settings, enterprise policies, etc.)
 */

function isStorageAvailable(): boolean {
  try {
    const key = '__storage_test__';
    window.localStorage.setItem(key, '1');
    window.localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}

const available = typeof window !== 'undefined' && isStorageAvailable();

export const safeStorage = {
  getItem(key: string): string | null {
    if (!available) return null;
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },

  setItem(key: string, value: string): void {
    if (!available) return;
    try {
      localStorage.setItem(key, value);
    } catch {
      // Storage full or blocked — silently ignore
    }
  },

  removeItem(key: string): void {
    if (!available) return;
    try {
      localStorage.removeItem(key);
    } catch {
      // Blocked — silently ignore
    }
  },
};
