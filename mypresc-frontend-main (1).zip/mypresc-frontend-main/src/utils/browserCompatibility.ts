/**
 * Utilitaires pour améliorer la compatibilité avec les navigateurs obsolètes comme Internet Explorer
 */

interface Medicament {
  id: string;
  name: string;
  [key: string]: unknown;
}

type SearchMedicamentsFunction = (query: string) => Promise<Medicament[]>;

/**
 * Recherche un médicament directement dans la base de données par nom
 * Cette fonction est particulièrement utile pour Internet Explorer qui utilise l'auto-remplissage
 * @param medicamentSearch - Le texte de recherche du médicament
 * @param searchMedicaments - La fonction de recherche de médicaments
 * @returns Le médicament trouvé ou null
 */
export const findMedicamentByAutoFill = async (
  medicamentSearch: string | null | undefined,
  searchMedicaments: SearchMedicamentsFunction
): Promise<Medicament | null> => {
  if (!medicamentSearch || typeof medicamentSearch !== 'string' || medicamentSearch.trim() === '') {
    return null;
  }

  try {
    // Rechercher le médicament dans la base de données
    const results = await searchMedicaments(medicamentSearch);
    
    // Si des médicaments sont trouvés, retourner le premier
    if (results && results.length > 0) {
      console.log('Médicament trouvé via auto-remplissage:', results[0]);
      return results[0];
    }
  } catch (error) {
    console.error('Erreur lors de la recherche de médicament par auto-remplissage:', error);
  }

  return null;
};

/**
 * Détecte si le navigateur est Internet Explorer
 * @returns true si c'est Internet Explorer
 */
export const isInternetExplorer = (): boolean => {
  if (typeof window === 'undefined') return false;
  
  // Internet Explorer 6-11
  return /*@cc_on!@*/false || !!(document as Document & { documentMode?: number }).documentMode;
};
