/**
 * Date utility functions for formatting and manipulation
 */

/**
 * Format a date for display in French locale
 * @param date - Date to format
 * @returns Formatted date string or fallback text
 */
export const formattedDate = (date: Date | string): string => {
  try {
    const d = date instanceof Date ? date : new Date(date);
    return !isNaN(d.getTime())
      ? d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
      : 'Date non disponible';
  } catch {
    return 'Date non disponible';
  }
};

/**
 * Convert a date to local date string (YYYY-MM-DD) to avoid timezone issues
 * @param date - Date to convert
 * @returns Date string in YYYY-MM-DD format
 */
export const toLocalDate = (date: Date): string => {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

/**
 * Check if a date is today
 * @param date - Date to check
 * @returns true if date is today
 */
export const isToday = (date: Date | string): boolean => {
  const d = date instanceof Date ? date : new Date(date);
  const today = new Date();
  return toLocalDate(d) === toLocalDate(today);
};

/**
 * Get a date's start of day (midnight)
 * @param date - Date to process
 * @returns New date at midnight
 */
export const startOfDay = (date: Date): Date => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};
