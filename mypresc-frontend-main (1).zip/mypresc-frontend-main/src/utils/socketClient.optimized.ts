/**
 * ⚡ OPTIMIZED Socket Client with Optimistic Updates
 *
 * Key improvements:
 * 1. Messages show instantly with temp IDs
 * 2. Replace temp ID when DB confirms
 * 3. Rollback on failure
 * 4. Batch read receipts
 */

import { io, Socket } from 'socket.io-client';
import { v4 as uuidv4 } from 'uuid';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface OptimisticMessage {
  tempId: string;
  id: number | null;
  conversation_id: number;
  sender_id: number;
  content: string;
  created_at: Date | string;
  sender_name: string;
  is_read: boolean;
  is_edited: boolean;
  isPending?: boolean; // UI flag
  isFailed?: boolean; // UI flag
}

class OptimizedSocketClient {
  private socket: Socket | null = null;
  private messageCallbacks: Map<string, Function> = new Map();
  private pendingMessages: Map<string, OptimisticMessage> = new Map();

  connect(userId?: number) {
    if (this.socket?.connected) return;

    this.socket = io(API_URL, {
      withCredentials: true,
      transports: ['websocket', 'polling'], // Prefer websocket
      upgrade: true,
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
      timeout: 10000,
    });

    this.setupOptimizedListeners();
  }

  private setupOptimizedListeners() {
    if (!this.socket) return;

    // Handle message confirmation (replace temp ID with real ID)
    this.socket.on('message:confirmed', (data: {
      tempId: string;
      realId: number;
      message: any;
    }) => {
      console.log('✅ Message confirmed:', data.tempId, '→', data.realId);

      // Notify subscribers to update temp ID → real ID
      const callback = this.messageCallbacks.get(data.tempId);
      if (callback) {
        callback({ confirmed: true, realId: data.realId, message: data.message });
        this.messageCallbacks.delete(data.tempId);
      }

      this.pendingMessages.delete(data.tempId);
    });

    // Handle message failure (rollback optimistic update)
    this.socket.on('message:failed', (data: {
      tempId: string;
      error: string;
    }) => {
      console.error('❌ Message failed:', data.tempId, data.error);

      // Notify subscribers to show error or remove message
      const callback = this.messageCallbacks.get(data.tempId);
      if (callback) {
        callback({ failed: true, error: data.error });
        this.messageCallbacks.delete(data.tempId);
      }

      // Mark as failed in pending messages
      const pending = this.pendingMessages.get(data.tempId);
      if (pending) {
        pending.isFailed = true;
      }
    });

    // Regular message:new (for other users' messages)
    this.socket.on('message:new', (data: any) => {
      // Skip if this is our own optimistic message
      if (this.pendingMessages.has(data.tempId)) {
        return;
      }

      // New message from another user
      console.log('📨 New message from other user:', data.message);
    });

    // Batch read receipts
    this.socket.on('message:read', (data: {
      messageIds: number[];
      userId: number;
      readAt: Date;
    }) => {
      console.log('✅ Messages read:', data.messageIds);
    });

    this.socket.on('connect', () => {
      console.log('🟢 Socket connected (optimized)');
    });

    this.socket.on('disconnect', () => {
      console.log('🔴 Socket disconnected');
    });

    this.socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });
  }

  /**
   * ⚡ OPTIMIZED: Send message with instant UI update
   *
   * Returns immediately with temp ID for optimistic UI
   */
  sendMessageOptimistic(
    conversationId: number,
    content: string,
    senderId: number,
    senderName: string,
    onUpdate: (update: { confirmed?: boolean; failed?: boolean; realId?: number; message?: any; error?: string }) => void
  ): OptimisticMessage {
    const tempId = uuidv4();
    const now = new Date();

    // Create optimistic message
    const optimisticMessage: OptimisticMessage = {
      tempId,
      id: null, // Will be filled when confirmed
      conversation_id: conversationId,
      sender_id: senderId,
      content,
      created_at: now,
      sender_name: senderName,
      is_read: false,
      is_edited: false,
      isPending: true,
    };

    // Store callback for confirmation
    this.messageCallbacks.set(tempId, onUpdate);
    this.pendingMessages.set(tempId, optimisticMessage);

    // Send to server (non-blocking)
    this.socket?.emit('message:send', {
      conversationId,
      content,
      tempId,
    }, (response: any) => {
      if (response?.error) {
        console.error('❌ Send failed:', response.error);
        onUpdate({ failed: true, error: response.error });
      } else {
        console.log('⚡ Message sent (waiting for DB confirmation)');
      }
    });

    // Return immediately for UI
    return optimisticMessage;
  }

  /**
   * Legacy method (for backward compatibility)
   */
  sendMessage(conversationId: number, content: string, callback?: Function) {
    this.socket?.emit('message:send', { conversationId, content }, callback);
  }

  /**
   * ⚡ OPTIMIZED: Batch mark messages as read
   */
  markMessagesAsRead(messageIds: number[]) {
    if (messageIds.length === 0) return;

    this.socket?.emit('message:read', { messageIds }, (response: any) => {
      if (response?.error) {
        console.error('Failed to mark as read:', response.error);
      }
    });
  }

  /**
   * Legacy method
   */
  markAsRead(messageId: number) {
    this.markMessagesAsRead([messageId]);
  }

  joinConversation(conversationId: number) {
    this.socket?.emit('conversation:join', { conversationId });
  }

  leaveConversation(conversationId: number) {
    this.socket?.emit('conversation:leave', { conversationId });
  }

  updatePresence(status: 'online' | 'away' | 'offline') {
    this.socket?.emit('presence:update', { status });
  }

  /**
   * Start typing indicator
   */
  startTyping(conversationId: number): void {
    this.socket?.emit('typing:start', { conversationId });
  }

  /**
   * Stop typing indicator
   */
  stopTyping(conversationId: number): void {
    this.socket?.emit('typing:stop', { conversationId });
  }

  getSocket() {
    return this.socket;
  }

  disconnect() {
    this.socket?.disconnect();
    this.messageCallbacks.clear();
    this.pendingMessages.clear();
  }

  /**
   * Check if message is still pending
   */
  isPending(tempId: string): boolean {
    return this.pendingMessages.has(tempId);
  }

  /**
   * Get pending message by temp ID
   */
  getPendingMessage(tempId: string): OptimisticMessage | undefined {
    return this.pendingMessages.get(tempId);
  }
}

export default new OptimizedSocketClient();