'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { EnvelopeIcon, ClockIcon, CheckCircleIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

// LogoDonut component
function LogoDonut({ sizeClass = 'w-16 md:w-20', backgroundColor = '#2B2F98' }) {
    return (
        <div className={`${sizeClass} aspect-square shrink-0 flex-none`}>
            <svg viewBox="0 0 100 100" className="w-full h-full">
                <rect width="100" height="100" fill={backgroundColor} rx="50" ry="50" />
                <circle
                    cx="50" cy="50" r="40"
                    fill="none" stroke="#FFFFFF" strokeWidth="16"
                    strokeDasharray="260 6"
                    strokeLinecap="round"
                    transform="rotate(-90 50 50)"
                />
                <circle cx="50" cy="50" r="18" fill="#FFFFFF" />
            </svg>
        </div>
    );
}

export default function ResetPasswordPage() {
    const router = useRouter();
    const { resetPassword } = useAuth();
    const { t } = useLanguage();
    const [email, setEmail] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [emailSent, setEmailSent] = useState(false);
    const [countdown, setCountdown] = useState(60);
    const [canResend, setCanResend] = useState(false);
    const [error, setError] = useState('');

    // Countdown timer after email is sent
    useEffect(() => {
        if (emailSent && countdown > 0) {
            const timer = setTimeout(() => {
                setCountdown(countdown - 1);
            }, 1000);
            return () => clearTimeout(timer);
        } else if (countdown === 0) {
            setCanResend(true);
        }
    }, [emailSent, countdown]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setIsSubmitting(true);

        try {
            const result = await resetPassword(email);

            if (result.success) {
                setEmailSent(true);
                setCountdown(60);
                setCanResend(false);
            } else {
                setError(result.error || t('auth.resetPassword.error'));
            }
        } catch (err) {
            setError(t('auth.resetPassword.unexpectedError'));
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleResend = async () => {
        setError('');
        setIsSubmitting(true);

        try {
            const result = await resetPassword(email);

            if (result.success) {
                setCountdown(60);
                setCanResend(false);
            } else {
                setError(result.error || t('auth.resetPassword.error'));
            }
        } catch (err) {
            setError(t('auth.resetPassword.unexpectedError'));
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div dir='ltr' className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center justify-center p-4">
            {/* Logo and Title */}
            <div className="flex items-center mb-10 space-x-3">
                <LogoDonut sizeClass="w-12 sm:w-14" />
                <h1 className="text-4xl font-extrabold text-gray-800 dark:text-gray-100">MyPrescription</h1>
            </div>

            {/* Reset Password Card */}
            <div className="w-full max-w-xl overflow-hidden bg-white dark:bg-gray-800 shadow-xl rounded-xl border border-gray-200 dark:border-gray-700">
                {!emailSent ? (
                    <>
                        <div className="flex flex-col items-center p-8 pt-10 text-center">
                            <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">{t('auth.resetPassword.title')}</h3>
                            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                                {t('auth.resetPassword.description')}
                            </p>
                        </div>

                        <div className="border-t-2 border-[#2B2F98] rounded-t-xl" />

                        <div className="px-8 pt-6 pb-8">
                            {error && (
                                <div className="p-4 mb-4 text-sm text-red-700 dark:text-red-400 transition-all duration-300 transform border-l-4 border-red-500 dark:border-red-400 rounded-lg shadow-sm bg-red-50 dark:bg-red-900/20">
                                    <p>{error}</p>
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div>
                                    <label htmlFor="email" className="sr-only">{t('auth.resetPassword.emailLabel')}</label>
                                    <div className="relative">
                                        <div className="absolute inset-y-0 left-0 flex items-center px-3 pointer-events-none">
                                            <EnvelopeIcon className="w-5 h-5 text-gray-400" />
                                        </div>
                                        <input
                                            id="email"
                                            name="email"
                                            type="email"
                                            autoComplete="email"
                                            required
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                            className="block w-full py-2 px-10 leading-5 placeholder-gray-500 dark:placeholder-gray-400 transition duration-200 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-gray-100 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                            placeholder={t('auth.resetPassword.emailPlaceholder')}
                                            disabled={isSubmitting}
                                        />
                                    </div>
                                </div>

                                <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="relative flex justify-center w-full px-4 py-2 text-white font-semibold transition-all duration-300 bg-[#1a237e] hover:bg-blue-700 border border-transparent rounded-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    {isSubmitting && (
                                        <svg className="w-4 h-4 mr-2 -ml-1 text-white animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l-3-2.647z"></path>
                                        </svg>
                                    )}
                                    <span>{isSubmitting ? t('auth.resetPassword.sending') : t('auth.resetPassword.submit')}</span>
                                </button>
                            </form>

                            <div className="mt-6 text-center">
                                <button
                                    onClick={() => router.push('/')}
                                    className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                                >
                                    <ArrowLeftIcon className="w-4 h-4 mr-1" />
                                    {t('auth.resetPassword.backToLogin')}
                                </button>
                            </div>
                        </div>
                    </>
                ) : (
                    <>
                        <div className="flex flex-col items-center p-8 pt-10 text-center">
                            <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full mb-4">
                                <CheckCircleIcon className="w-10 h-10 text-green-600 dark:text-green-400" />
                            </div>
                            <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-2">{t('auth.resetPassword.successTitle')}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                                {t('auth.resetPassword.successDescription1')}
                            </p>
                            <p className="text-blue-600 dark:text-blue-400 font-semibold">{email}</p>
                        </div>

                        <div className="border-t-2 border-[#2B2F98] rounded-t-xl" />

                        <div className="px-8 pt-6 pb-8">
                            {error && (
                                <div className="p-4 mb-4 text-sm text-red-700 dark:text-red-400 transition-all duration-300 transform border-l-4 border-red-500 dark:border-red-400 rounded-lg shadow-sm bg-red-50 dark:bg-red-900/20">
                                    <p>{error}</p>
                                </div>
                            )}

                            {/* Timer and Instructions */}
                            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6">
                                <div className="flex items-start gap-3">
                                    <ClockIcon className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                                    <div className="flex-1">
                                        <p className="text-sm text-blue-900 dark:text-blue-200 font-medium mb-1">
                                            {t('auth.resetPassword.checkInbox')}
                                        </p>
                                        <p className="text-sm text-blue-700 dark:text-blue-300">
                                            {t('auth.resetPassword.checkInboxDesc')}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Resend Options */}
                            <div className="space-y-3">
                                {!canResend ? (
                                    <div className="text-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                        <p className="text-sm text-gray-600 dark:text-gray-400">
                                            {t('auth.resetPassword.resendValues')} {' '}
                                            <span className="font-semibold text-gray-900 dark:text-gray-100">{countdown}s</span>
                                        </p>
                                    </div>
                                ) : (
                                    <>
                                        <button
                                            onClick={handleResend}
                                            disabled={isSubmitting}
                                            className="relative flex justify-center w-full px-4 py-2 text-white font-semibold transition-all duration-300 bg-[#1a237e] hover:bg-blue-700 border border-transparent rounded-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            {isSubmitting && (
                                                <svg className="w-4 h-4 mr-2 -ml-1 text-white animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l-3-2.647z"></path>
                                                </svg>
                                            )}
                                            <span>{isSubmitting ? t('auth.resetPassword.sending') : t('auth.resetPassword.resend')}</span>
                                        </button>
                                        <div className="text-center">
                                            <p className="text-sm text-gray-600 dark:text-gray-400">
                                                {t('auth.resetPassword.notReceived')} {' '}
                                                <button
                                                    onClick={() => {
                                                        setEmailSent(false);
                                                        setEmail('');
                                                        setError('');
                                                    }}
                                                    className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
                                                >
                                                    {t('auth.resetPassword.tryAnother')}
                                                </button>
                                            </p>
                                        </div>
                                    </>
                                )}
                            </div>

                            <div className="mt-6 text-center pt-6 border-t border-gray-200 dark:border-gray-700">
                                <button
                                    onClick={() => router.push('/')}
                                    className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                                >
                                    <ArrowLeftIcon className="w-4 h-4 mr-1" />
                                    {t('auth.resetPassword.backToLogin')}
                                </button>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
}