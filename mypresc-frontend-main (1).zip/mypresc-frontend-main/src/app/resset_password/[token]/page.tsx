'use client';

import { useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { LockClosedIcon, EyeIcon, EyeSlashIcon, CheckCircleIcon, ExclamationCircleIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';

// LogoDonut component
function LogoDonut({ sizeClass = 'w-16 md:w-20', backgroundColor = '#2B2F98' }) {
    return (
        <div dir='ltr' className={`${sizeClass} aspect-square shrink-0 flex-none`}>
            <svg viewBox="0 0 100 100" className="w-full h-full">
                <rect width="100" height="100" fill={backgroundColor} rx="50" ry="50" />
                <circle
                    cx="50" cy="50" r="40"
                    fill="none" stroke="#FFFFFF" strokeWidth="16"
                    strokeDasharray="260 6"
                    strokeLinecap="round"
                    transform="rotate(-90 50 50)"
                />
                <circle cx="50" cy="50" r="18" fill="#FFFFFF" />
            </svg>
        </div>
    );
}

export default function ResetPasswordTokenPage() {
    const router = useRouter();
    const params = useParams();
    const token = params?.token as string;
    const { changePassword } = useAuth();
    const { t } = useLanguage();

    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    // Password validation
    const validatePassword = () => {
        if (password.length < 8) {
            setError(t('auth.resetToken.errors.passwordLength'));
            return false;
        }
        if (password !== confirmPassword) {
            setError(t('auth.resetToken.errors.passwordMatch'));
            return false;
        }
        return true;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!validatePassword()) {
            return;
        }

        if (!token) {
            setError(t('auth.resetToken.errors.tokenMissing'));
            return;
        }

        setIsSubmitting(true);

        try {
            const result = await changePassword(token, password, confirmPassword);

            if (result.success) {
                setSuccess(true);
            } else {
                setError(result.error || t('auth.resetToken.errors.generic'));
            }
        } catch (err) {
            setError(t('auth.resetToken.errors.unexpected'));
        } finally {
            setIsSubmitting(false);
        }
    };

    const getPasswordStrength = () => {
        if (password.length === 0) return { strength: 0, label: '', color: '' };
        if (password.length < 6) return { strength: 33, label: t('auth.resetToken.strength.weak'), color: 'bg-red-500' };
        if (password.length < 10) return { strength: 66, label: t('auth.resetToken.strength.medium'), color: 'bg-yellow-500' };
        return { strength: 100, label: t('auth.resetToken.strength.strong'), color: 'bg-green-500' };
    };

    const passwordStrength = getPasswordStrength();

    if (success) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center justify-center p-4">
                <div className="flex items-center mb-10 space-x-3">
                    <LogoDonut sizeClass="w-12 sm:w-14" />
                    <h1 className="text-4xl font-extrabold text-gray-800 dark:text-gray-100">MyPrescription</h1>
                </div>

                <div className="w-full max-w-xl overflow-hidden bg-white dark:bg-gray-800 shadow-xl rounded-xl border border-gray-200 dark:border-gray-700">
                    <div className="flex flex-col items-center p-8 pt-10 text-center">
                        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full mb-4">
                            <CheckCircleIcon className="w-10 h-10 text-green-600 dark:text-green-400" />
                        </div>
                        <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-100 mb-2">{t('auth.resetToken.successTitle')}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                            {t('auth.resetToken.successDescription')}
                        </p>
                        <button
                            onClick={() => router.push('/')}
                            className="w-full max-w-xs px-4 py-2 text-white font-semibold transition-all duration-300 bg-[#1a237e] hover:bg-blue-700 border border-transparent rounded-lg shadow-lg"
                        >
                            {t('auth.resetToken.goToLogin')}
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex flex-col items-center justify-center p-4">
            {/* Logo and Title */}
            <div className="flex items-center mb-10 space-x-3">
                <LogoDonut sizeClass="w-12 sm:w-14" />
                <h1 className="text-4xl font-extrabold text-gray-800 dark:text-gray-100">MyPrescription</h1>
            </div>

            {/* Reset Password Form Card */}
            <div className="w-full max-w-xl overflow-hidden bg-white dark:bg-gray-800 shadow-xl rounded-xl border border-gray-200 dark:border-gray-700">
                <div className="flex flex-col items-center p-8 pt-10 text-center">
                    <h3 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">{t('auth.resetToken.title')}</h3>
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        {t('auth.resetToken.description')}
                    </p>
                </div>

                <div className="border-t-2 border-[#2B2F98] rounded-t-xl" />

                <div className="px-8 pt-6 pb-8">
                    {error && (
                        <div className="p-4 mb-4 text-sm text-red-700 dark:text-red-400 transition-all duration-300 transform border-l-4 border-red-500 dark:border-red-400 rounded-lg shadow-sm bg-red-50 dark:bg-red-900/20">
                            <div className="flex items-start gap-2">
                                <ExclamationCircleIcon className="w-5 h-5 flex-shrink-0 mt-0.5" />
                                <p>{error}</p>
                            </div>
                        </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-6">
                        {/* New Password */}
                        <div>
                            <label htmlFor="password" className="sr-only">{t('auth.resetToken.passwordLabel')}</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 flex items-center px-3 pointer-events-none">
                                    <LockClosedIcon className="w-5 h-5 text-gray-400" />
                                </div>
                                <input
                                    id="password"
                                    name="password"
                                    type={showPassword ? 'text' : 'password'}
                                    required
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="block w-full py-2 px-10  leading-5 placeholder-gray-500 dark:placeholder-gray-400 transition duration-200 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-gray-100 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                    placeholder={t('auth.resetToken.passwordPlaceholder')}
                                    disabled={isSubmitting}
                                />
                                <button
                                    type="button"
                                    className="absolute inset-y-0 right-0 px-4 flex items-center  text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                                    onClick={() => setShowPassword(!showPassword)}
                                >
                                    {showPassword ? (
                                        <EyeSlashIcon className="w-5 h-5" />
                                    ) : (
                                        <EyeIcon className="w-5 h-5" />
                                    )}
                                </button>
                            </div>

                            {/* Password Strength Indicator */}
                            {password && (
                                <div className="mt-2">
                                    <div className="flex items-center gap-2 mb-1">
                                        <div className="flex-1 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                                            <div
                                                className={`h-full ${passwordStrength.color} transition-all duration-300`}
                                                style={{ width: `${passwordStrength.strength}%` }}
                                            />
                                        </div>
                                        <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                                            {passwordStrength.label}
                                        </span>
                                    </div>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">
                                        {t('auth.resetToken.errors.passwordLength')}
                                    </p>
                                </div>
                            )}
                        </div>

                        {/* Confirm Password */}
                        <div>
                            <label htmlFor="confirmPassword" className="sr-only">{t('auth.resetToken.confirmPasswordLabel')}</label>
                            <div className="relative">
                                <div className="absolute inset-y-0 left-0 flex items-center px-3 pointer-events-none">
                                    <LockClosedIcon className="w-5 h-5 text-gray-400" />
                                </div>
                                <input
                                    id="confirmPassword"
                                    name="confirmPassword"
                                    type={showConfirmPassword ? 'text' : 'password'}
                                    required
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    className="block w-full py-2 px-10  leading-5 placeholder-gray-500 dark:placeholder-gray-400 transition duration-200 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 dark:text-gray-100 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                                    placeholder={t('auth.resetToken.confirmPasswordPlaceholder')}
                                    disabled={isSubmitting}
                                />
                                <button
                                    type="button"
                                    className="absolute inset-y-0 right-0 px-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                >
                                    {showConfirmPassword ? (
                                        <EyeSlashIcon className="w-5 h-5" />
                                    ) : (
                                        <EyeIcon className="w-5 h-5" />
                                    )}
                                </button>
                            </div>
                            {confirmPassword && password !== confirmPassword && (
                                <p className="mt-1 text-xs text-red-600 dark:text-red-400">
                                    {t('auth.resetToken.errors.passwordMatch')}
                                </p>
                            )}
                        </div>

                        {/* Submit Button */}
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="relative flex justify-center w-full px-4 py-2 text-white font-semibold transition-all duration-300 bg-[#1a237e] hover:bg-blue-700 border border-transparent rounded-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isSubmitting && (
                                <svg className="w-4 h-4 mr-2 -ml-1 text-white animate-spin" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l-3-2.647z"></path>
                                </svg>
                            )}
                            <span>{isSubmitting ? t('auth.resetToken.submitting') : t('auth.resetToken.submit')}</span>
                        </button>
                    </form>

                    <div className="mt-6 text-center">
                        <button
                            onClick={() => router.push('/')}
                            className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors"
                        >
                            <ArrowLeftIcon className="w-4 h-4 mr-1" />
                            {t('auth.resetPassword.backToLogin')}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}