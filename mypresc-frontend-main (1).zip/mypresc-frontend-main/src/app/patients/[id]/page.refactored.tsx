'use client';
import { useState } from 'react';
import Header from '@/components/Header';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';

// Feature hooks & components
import { usePatientDetail } from '@/features/patients/hooks';
import {
    AccessConfirmationModal,
    PrivacyChoiceModal,
    NinPopupModal,
} from '@/features/patients/components';
import {
    useInvoices,
    useInvoiceMutations,
    InvoiceForm,
    PaymentModal,
    GlobalPaymentModal,
} from '@/features/invoices';

// Page section components
import {
    PatientProfile,
    PrescriptionsSection,
    InvoicesSection,
    MedicalReportsSection,
    AppointmentsSection,
    DentalActsSection,
} from './_components';

// Legacy components still needed
import PatientChartModal from '@/components/patients/PatientChartModal';
import PatientHistoryModal from '@/components/patients/PatientHistoryModal';
import ShareMedicalRecordModal from '@/features/sharing/components/ShareMedicalRecordModal';
import AddMedicalReportModal from '@/features/medical-reports/components/AddMedicalReportModal';
import PrescriptionPreviewModal from '@/features/prescriptions/components/modals/PrescriptionPreviewModal';

interface PageProps {
    params: { id: string };
}

/**
 * Loading skeleton for the page
 */
function PageSkeleton() {
    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <Header />
            <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
                <div className="animate-pulse space-y-6">
                    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-48" />
                    <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded-2xl" />
                    <div className="grid grid-cols-2 gap-6">
                        <div className="h-96 bg-gray-200 dark:bg-gray-700 rounded-2xl" />
                        <div className="h-96 bg-gray-200 dark:bg-gray-700 rounded-2xl" />
                    </div>
                </div>
            </main>
        </div>
    );
}

/**
 * Main Patient Detail Page Component
 */
export default function PatientDetailPage({ params }: PageProps) {
    const patientId = params.id;

    // Main hook - provides all state and handlers
    const {
        patient,
        loading,
        error,
        user,
        isDoctor,
        isAssistant,
        isDentalSpecialist,
        accessControl,
        prescriptions,
        filteredPrescriptions,
        prescriptionFilter,
        setPrescriptionFilter,
        isSharedPatient,
        hasMultipleDoctors,
        appointments,
        history,
        visitCount,
        showNinPopup,
        onSaveNin,
        onSkipNin,
        showShareModal,
        setShowShareModal,
        showChartModal,
        setShowChartModal,
        router,
        t,
    } = usePatientDetail({ patientId });

    // Invoice management
    const { invoices } = useInvoices(patientId);
    const invoiceMutations = useInvoiceMutations(patientId);

    // Modal states for invoices
    const [showInvoiceModal, setShowInvoiceModal] = useState(false);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
    const [showGlobalPaymentModal, setShowGlobalPaymentModal] = useState(false);

    // Modal states for other features
    const [showReportModal, setShowReportModal] = useState(false);
    const [showPrescriptionPreview, setShowPrescriptionPreview] = useState(false);
    const [selectedPrescription, setSelectedPrescription] = useState<any>(null);

    // Loading state
    if (loading) {
        return <PageSkeleton />;
    }

    // Error or no patient
    if (error || !patient) {
        return (
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
                <Header />
                <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
                    <div className="text-center py-12">
                        <p className="text-red-500">{error?.message || t('patients.detail.notFound')}</p>
                        <Link href="/patients" className="mt-4 inline-flex items-center text-blue-600 hover:underline">
                            <ArrowLeftIcon className="w-4 h-4 mr-2" />
                            {t('patients.detail.back')}
                        </Link>
                    </div>
                </main>
            </div>
        );
    }

    // Access not confirmed yet
    if (!accessControl.accessConfirmed) {
        return (
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
                <Header />
                <AccessConfirmationModal
                    isOpen={accessControl.showAccessConfirmation}
                    patientName={`${patient.name} ${patient.family_name}`}
                    patientPresent={accessControl.patientPresentCheckbox}
                    onPatientPresentChange={accessControl.setPatientPresentCheckbox}
                    onConfirm={accessControl.handleAccessConfirm}
                    onCancel={accessControl.handleCancelAccess}
                />
                <PrivacyChoiceModal
                    isOpen={accessControl.showPrivacyChoicePopup}
                    patientName={`${patient.name} ${patient.family_name}`}
                    onChoosePrivate={() => accessControl.handlePrivacyChoice('private')}
                    onChooseShared={() => accessControl.handlePrivacyChoice('shared')}
                    onCancel={accessControl.handleCancelAccess}
                />
            </div>
        );
    }

    const patientName = `${patient.name} ${patient.family_name}`;

    return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
            <Header />

            <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
                {/* Back button */}
                <Link
                    href="/patients"
                    className="inline-flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 mb-6 transition-colors"
                >
                    <ArrowLeftIcon className="w-5 h-5" />
                    <span className="font-medium">{t('patients.detail.back')}</span>
                </Link>

                {/* Patient Profile Card */}
                <PatientProfile
                    patient={patient as any}
                    visitCount={visitCount}
                    isPrivate={accessControl.myPrivacyChoice === 'private'}
                    isSharedWithMe={false}
                    isPrimaryCareDoctor={false}
                    myPrivacyChoice={accessControl.myPrivacyChoice}
                    isLoadingHistory={history.isLoading}
                    userRole={user?.role}
                    onFetchHistory={history.openModal}
                    onShare={() => setShowShareModal(true)}
                />

                {/* Dental Acts Section - Only for dental specialists */}
                <DentalActsSection
                    patientId={patientId}
                    isVisible={isDentalSpecialist}
                />

                {/* For Assistants: Only Appointments */}
                {isAssistant && (
                    <div className="mb-6">
                        <AppointmentsSection
                            appointments={appointments}
                            patientId={patientId}
                            onCreateAppointment={() => router.push(`/calendar?patient=${patientId}`)}
                        />
                    </div>
                )}

                {/* For Doctors: 2-Column Layout */}
                {isDoctor && (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                        {/* Left Column: Prescriptions */}
                        <PrescriptionsSection
                            prescriptions={filteredPrescriptions as any}
                            patientId={patientId}
                            currentUserId={parseInt(user?.id || '0')}
                            isSharedPatient={isSharedPatient}
                            onPreview={(p: any) => {
                                setSelectedPrescription(p);
                                setShowPrescriptionPreview(true);
                            }}
                        />

                        {/* Right Column: Appointments + Medical Reports */}
                        <div className="space-y-6">
                            <AppointmentsSection
                                appointments={appointments}
                                patientId={patientId}
                                onCreateAppointment={() => router.push(`/calendar?patient=${patientId}`)}
                            />
                            <MedicalReportsSection
                                patientId={patientId}
                                currentUserId={parseInt(user?.id || '0')}
                                isSharedPatient={isSharedPatient}
                                onAddReport={() => setShowReportModal(true)}
                            />
                        </div>
                    </div>
                )}

                {/* Invoices Section */}
                <InvoicesSection
                    patientId={patientId}
                    onCreateInvoice={() => setShowInvoiceModal(true)}
                    onOpenPayment={(invoice) => {
                        setSelectedInvoice(invoice);
                        setShowPaymentModal(true);
                    }}
                    onOpenGlobalPayment={() => setShowGlobalPaymentModal(true)}
                />
            </main>

            {/* ===== MODALS ===== */}

            {/* Invoice Form Modal */}
            {showInvoiceModal && (
                <InvoiceForm
                    patientId={patientId}
                    patientName={patientName}
                    tarifications={[]}
                    isCreating={invoiceMutations.isCreating}
                    onSubmit={async (items, total) => {
                        await invoiceMutations.createInvoice({ patient_id: patientId, items, total_price: total });
                        setShowInvoiceModal(false);
                    }}
                    onCancel={() => setShowInvoiceModal(false)}
                />
            )}

            {/* Payment Modal */}
            <PaymentModal
                isOpen={showPaymentModal}
                invoice={selectedInvoice}
                isProcessing={invoiceMutations.isAddingPayment}
                onSubmit={async (invoiceId, amount) => {
                    await invoiceMutations.addPayment(invoiceId, amount);
                    setShowPaymentModal(false);
                    setSelectedInvoice(null);
                }}
                onClose={() => {
                    setShowPaymentModal(false);
                    setSelectedInvoice(null);
                }}
            />

            {/* Global Payment Modal */}
            <GlobalPaymentModal
                isOpen={showGlobalPaymentModal}
                invoices={invoices}
                patientName={patientName}
                isProcessing={invoiceMutations.isDistributing}
                onSubmit={async (amount) => {
                    await invoiceMutations.distributePayment(amount);
                    setShowGlobalPaymentModal(false);
                }}
                onClose={() => setShowGlobalPaymentModal(false)}
            />

            {/* NIN Popup Modal */}
            <NinPopupModal
                isOpen={showNinPopup}
                patientId={patientId}
                patientName={patientName}
                onSave={onSaveNin}
                onSkip={onSkipNin}
            />

            {/* Chart Modal */}
            {showChartModal && (
                <PatientChartModal
                    isOpen={showChartModal}
                    patientName={patient.name}
                    patientFamilyName={patient.family_name}
                    isPrivate={accessControl.myPrivacyChoice === 'private'}
                    setIsPrivate={() => { }}
                    onConfirm={() => setShowChartModal(false)}
                    onCancel={() => setShowChartModal(false)}
                />
            )}

            {/* History Modal */}
            {history.showModal && (
                <PatientHistoryModal
                    isOpen={history.showModal}
                    onClose={history.closeModal}
                    history={history.data as any}
                    patientName={patientName}
                    currentUserId={parseInt(user?.id || '0')}
                    metadata={history.metadata ?? undefined}
                />
            )}

            {/* Share Modal */}
            {showShareModal && (
                <ShareMedicalRecordModal
                    patientId={patientId}
                    patientName={patientName}
                    isOpen={showShareModal}
                    onClose={() => setShowShareModal(false)}
                />
            )}

            {/* Add Medical Report Modal */}
            {showReportModal && (
                <AddMedicalReportModal
                    patientId={patientId}
                    patientName={patient.name}
                    patientFamilyName={patient.family_name}
                    isOpen={showReportModal}
                    onClose={() => setShowReportModal(false)}
                    onSuccess={() => setShowReportModal(false)}
                />
            )}

            {/* Prescription Preview Modal */}
            {showPrescriptionPreview && selectedPrescription && (
                <PrescriptionPreviewModal
                    prescription={selectedPrescription}
                    isOpen={showPrescriptionPreview}
                    onClose={() => {
                        setShowPrescriptionPreview(false);
                        setSelectedPrescription(null);
                    }}
                />
            )}
        </div>
    );
}
