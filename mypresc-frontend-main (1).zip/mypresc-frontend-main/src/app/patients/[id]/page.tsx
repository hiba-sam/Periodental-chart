'use client';

import { useState, useEffect } from 'react';

import { useQueryClient } from '@tanstack/react-query';

import Header from '@/components/Header';

import { ArrowLeftIcon } from '@heroicons/react/24/outline';

import Link from 'next/link';

import { CardSkeleton, ListSkeleton, TableSkeleton } from '@/components/feedback';



// Feature hooks & components

import { usePatientDetail } from '@/features/patients/hooks';

import {

  AccessConfirmationModal,

  PrivacyChoiceModal,

  NinPopupModal,

  PatientHistoryModal,

} from '@/features/patients/components';

import {

  useInvoices,

  useInvoiceMutations,

  PaymentModal,

  GlobalPaymentModal,

  InvoiceCreateModal,

} from '@/features/invoices';

import { ShareMedicalRecordModal } from '@/features/sharing/components';

import { PrescriptionPreviewModal } from '@/features/prescriptions/components';

import { useProfile } from '@/contexts/ProfileContext';
import { useHeaderContext } from '@/contexts/HeaderContext';

import dynamic from 'next/dynamic';



import {

  PatientProfile,

  PrescriptionsSection,

  InvoicesSection,

  MedicalReportsSection,

  AppointmentsSection,

  DentalActsSection,

  OpticalCorrectionsSection,

  CardiologieActsSection,

  medicalReportKeys,

  cardiologyReportKeys,

} from './_components';



// Lazy load the heavy cardiology modal

const CardiologyReportModal = dynamic(() => import('@/features/cardiology/components/CardiologyReportModal'), {

  loading: () => <div className="animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg h-96" />,

  ssr: false

});



// Legacy components still needed

import AddMedicalReportModal from '@/features/medical-reports/components/AddMedicalReportModal';



interface PageProps {

  params: { id: string };

}



/**

 * Loading skeleton for the page - uses standardized skeleton components

 */

function PageSkeleton() {

  return (

    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">

      <Header />

      <main className="mx-auto px-2 md:px-6 py-8">

        <div className="space-y-6">

          {/* Back link */}

          <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-40 animate-pulse hidden md:block" />


          {/* Patient info card */}

          <CardSkeleton />


          {/* Two column sections */}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <ListSkeleton count={2} />

            <ListSkeleton count={2} />

          </div>


          {/* Invoice section */}

          <TableSkeleton rows={3} />

        </div>

      </main>

    </div>

  );

}


/**


 * Main Patient Detail Page Component


 */


export default function PatientDetailPage({ params }: PageProps) {

  const patientId = params.id;


  // Main hook - provides all state and handlers

  const {

    patient,

    loading,

    error,

    user,

    isDoctor,

    isAssistant,

    isDentalSpecialist,

    isCardiologist,

    isOptometrist,

    accessControl,

    filteredPrescriptions,

    isSharedPatient,

    appointments,

    history,

    primaryCare,

    visitCount,

    showNinPopup,

    onSaveNin,

    onSkipNin,

    showShareModal,

    setShowShareModal,

    router,

    t,

  } = usePatientDetail({ patientId });


  // Query client for cache invalidation

  const queryClient = useQueryClient();


  // Invoice management

  const { invoices } = useInvoices(patientId);

  const invoiceMutations = useInvoiceMutations(patientId);


  // Tarifications from profile (for invoice modal)

  const { tarifications, getTarificationsByDoctor } = useProfile();

  // Mobile header: show back arrow with patient name

  const { setBackMode, clearBackMode } = useHeaderContext();

  // Activate back-arrow in mobile header when patient is loaded

  useEffect(() => {

    if (patient) {

      setBackMode({

        title: `${patient.name} ${patient.family_name}`,

        href: '/patients',

      });

    }

    return () => clearBackMode();

  }, [patient, setBackMode, clearBackMode]);


  // Fetch tarifications when page loads (for invoice modal)

  useEffect(() => {

    getTarificationsByDoctor();

  }, [getTarificationsByDoctor]);


  // Modal states for invoices

  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);

  const [showGlobalPaymentModal, setShowGlobalPaymentModal] = useState(false);


  // Modal states for other features

  const [showReportModal, setShowReportModal] = useState(false);

  const [showPrescriptionPreview, setShowPrescriptionPreview] = useState(false);

  const [selectedPrescription, setSelectedPrescription] = useState<any>(null);


  // Cardiology modal state

  const [showCardiologyModal, setShowCardiologyModal] = useState(false);

  const [selectedCardiologyReport, setSelectedCardiologyReport] = useState<any>(null);
  const [cardioRefreshKey, setCardioRefreshKey] = useState(0);

  const patientName = patient ? `${patient.name} ${patient.family_name}` : '';


  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Header />
      {loading ? (
        <main className="mx-auto px-2 md:px-6 py-8">
          <div className="space-y-6">
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-40 animate-pulse hidden md:block" />
            <CardSkeleton />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ListSkeleton count={2} />
              <ListSkeleton count={2} />
            </div>
            <TableSkeleton rows={3} />
          </div>
        </main>
      ) : (error || !patient) ? (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <div className="text-center py-12">
            <p className="text-red-500">{error?.message || t('patients.detail.notFound')}</p>
            <Link href="/patients" className="mt-4 inline-flex items-center text-blue-600 hover:underline">
              <ArrowLeftIcon className="w-4 h-4 mr-2" />
              {t('patients.detail.back')}
            </Link>
          </div>
        </main>
      ) : !accessControl.accessConfirmed ? (
        <>
          <AccessConfirmationModal
            isOpen={accessControl.showAccessConfirmation}
            patientName={patientName}
            patientPresent={accessControl.patientPresentCheckbox}
            onPatientPresentChange={accessControl.setPatientPresentCheckbox}
            onConfirm={accessControl.handleAccessConfirm}
            onCancel={accessControl.handleCancelAccess}
          />
          <PrivacyChoiceModal
            isOpen={accessControl.showPrivacyChoicePopup}
            patientName={patientName}
            onChoosePrivate={() => accessControl.handlePrivacyChoice('private')}
            onChooseShared={() => accessControl.handlePrivacyChoice('shared')}
            onCancel={accessControl.handleCancelAccess}
          />
        </>
      ) : (
        <>
          <main className="mx-auto px-2 sm:px-6 py-8">
            {/* Back button */}

            <Link
              href="/patients"
              className="hidden md:inline-flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 mb-6 transition-colors"
            >
              <ArrowLeftIcon className="w-5 h-5" />
              <span className="font-medium">{t('patients.detail.backToList')}</span>
            </Link>

            {/* Patient Profile Card */}

            <PatientProfile
              patient={patient as any}
              visitCount={visitCount}
              isPrivate={accessControl.myPrivacyChoice === 'private'}
              isSharedWithMe={isSharedPatient}
              isPrimaryCareDoctor={primaryCare.isCurrentDoctor}
              myPrivacyChoice={accessControl.myPrivacyChoice}
              isLoadingHistory={history.isLoading}
              userRole={user?.role}
              primaryCareInfo={primaryCare.info}
              loadingPrimaryCare={primaryCare.isLoading}
              activeShareWithPrimaryCare={primaryCare.shared}
              onFetchHistory={history.openModal}
              onShare={() => setShowShareModal(true)}
              onShareWithPrimaryCare={primaryCare.toggleSharing}
              onRevokeShare={primaryCare.toggleSharing}
            />

            {/* Dental Acts Section - Only for dental specialists */}

            <DentalActsSection
              patientId={patientId}
              currentUserId={parseInt(user?.id || '0')}
              isVisible={isDentalSpecialist}
            />

            {/* Cardiology Acts Section - Only for cardiologists */}

            <CardiologieActsSection
              patientId={patientId}
              patientName={patientName}
              patientAge={patient.dateNaissance ? Math.floor((Date.now() - new Date(patient.dateNaissance).getTime()) / (365.25 * 24 * 60 * 60 * 1000)) : undefined}
              patientSex={patient.genre === 'M' ? 'Homme' : patient.genre === 'F' ? 'Femme' : undefined}
              currentUserId={parseInt(user?.id || '0')}
              isVisible={isCardiologist}
              refreshKey={cardioRefreshKey}
            />

            {/* Optical Corrections - Below Dental Acts - Limited to specific specialties */}

            <OpticalCorrectionsSection
              patientId={patientId}
              patientName={patient.name}
              patientFamilyName={patient.family_name}
              patientDateNaissance={patient.dateNaissance}
              patientGenre={patient.genre}
              isVisible={isOptometrist}
              currentUserId={user?.id ? parseInt(String(user.id)) : undefined}
            />

            {/* For Assistants: Only Appointments */}

            {isAssistant && (
              <div className="mb-6">
                <AppointmentsSection
                  appointments={appointments}
                  patientId={patientId}
                  onCreateAppointment={() => router.push(`/calendar?patientId=${patientId}&patientName=${patientName}&patientFamilyName=${patient.family_name}&eventType=patient`)}
                />
              </div>
            )}

            {/* For Doctors: 2-Column Layout */}

            {isDoctor && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                {/* Left Column: Prescriptions */}

                <PrescriptionsSection
                  prescriptions={filteredPrescriptions as any}
                  patientId={patientId}
                  currentUserId={parseInt(user?.id || '0')}
                  isSharedPatient={isSharedPatient}
                  onPreview={(p: any) => {
                    setSelectedPrescription(p);
                    setShowPrescriptionPreview(true);
                  }}
                />

                {/* Right Column: Appointments + Medical Reports */}

                <div className="space-y-6">
                  <AppointmentsSection
                    appointments={appointments}
                    patientId={patientId}
                    onCreateAppointment={() => router.push(`/calendar?patientId=${patientId}&patientName=${patientName}&patientFamilyName=${patient.family_name}&eventType=patient`)}
                  />
                  <MedicalReportsSection
                    patientId={patientId}
                    currentUserId={parseInt(user?.id || '0')}
                    isSharedPatient={isSharedPatient}
                    isCardiologist={isCardiologist}
                    onAddReport={() => setShowReportModal(true)}
                    onAddCardiologyReport={() => { setSelectedCardiologyReport(null); setShowCardiologyModal(true); }}
                    onReuseCardiologyReport={(cr) => { const { id, ...rest } = cr; setSelectedCardiologyReport(rest); setShowCardiologyModal(true); }}
                  />
                </div>
              </div>
            )}

            {/* Invoices Section */}

            <InvoicesSection
              patientId={patientId}
              onCreateInvoice={() => setShowInvoiceModal(true)}
              onOpenPayment={(invoice) => {
                setSelectedInvoice(invoice);
                setShowPaymentModal(true);
              }}
              onOpenGlobalPayment={() => setShowGlobalPaymentModal(true)}
            />
          </main>
        </>
      )}

      {/* ===== MODALS ===== */}

      {/* Invoice Create Modal - Original */}

      <InvoiceCreateModal
        isOpen={showInvoiceModal}
        tarifications={tarifications}
        onClose={() => setShowInvoiceModal(false)}
        onCreate={async (selectedTarificationIds, customItems) => {
          // Build items array from selected tarifications + custom items
          const items = [
            ...selectedTarificationIds.map(id => {
              const tarif = tarifications.find(t => t.id === id);
              return tarif ? { tarification_id: id, label: tarif.service_label, price: Number(tarif.price) } : null;
            }).filter(Boolean),
            ...customItems.map(item => ({ label: item.label, price: Number(item.price) }))
          ];
          const total = items.reduce((sum, item) => sum + (item?.price || 0), 0);
          await invoiceMutations.createInvoice({ patient_id: patientId, items: items as any, total_price: total });
          setShowInvoiceModal(false);
        }}
      />

      {/* Payment Modal */}

      <PaymentModal
        isOpen={showPaymentModal}
        invoice={selectedInvoice}
        isProcessing={invoiceMutations.isAddingPayment}
        onSubmit={async (invoiceId, amount) => {
          await invoiceMutations.addPayment(invoiceId, amount);
          setShowPaymentModal(false);
          setSelectedInvoice(null);
        }}
        onClose={() => {
          setShowPaymentModal(false);
          setSelectedInvoice(null);
        }}
      />

      {/* Global Payment Modal */}

      <GlobalPaymentModal
        isOpen={showGlobalPaymentModal}
        invoices={invoices}
        patientName={patientName}
        isProcessing={invoiceMutations.isDistributing}
        onSubmit={async (amount) => {
          await invoiceMutations.distributePayment(amount);
          setShowGlobalPaymentModal(false);
        }}
        onClose={() => setShowGlobalPaymentModal(false)}
      />

      {/* NIN Popup Modal */}

      <NinPopupModal
        isOpen={showNinPopup}
        patientId={patientId}
        patientName={patientName}
        onSave={onSaveNin}
        onSkip={onSkipNin}
      />

      {/* History Modal */}

      {history.showModal && (
        <PatientHistoryModal
          isOpen={history.showModal}
          onClose={history.closeModal}
          patientId={patientId}
          patientName={patientName}
          currentUserId={parseInt(user?.id || '0')}
        />
      )}

      {/* Share Modal */}

      {showShareModal && (
        <ShareMedicalRecordModal
          patientId={patientId}
          patientName={patientName}
          isOpen={showShareModal}
          onClose={() => setShowShareModal(false)}
        />
      )}

      {/* Add Medical Report Modal */}

      {showReportModal && (
        <AddMedicalReportModal
          patientId={patientId}
          patientName={patient.name}
          patientFamilyName={patient.family_name}
          patientDateNaissance={patient.dateNaissance}
          patientGenre={patient.genre}
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          onSuccess={() => {
            // Invalidate cache to refresh the reports list
            queryClient.invalidateQueries({ queryKey: medicalReportKeys.byPatient(patientId) });
            setShowReportModal(false);
          }}
        />
      )}

      {/* Cardiology Report Modal */}

      {showCardiologyModal && isCardiologist && (
        <CardiologyReportModal
          isOpen={showCardiologyModal}
          onClose={() => { setShowCardiologyModal(false); setSelectedCardiologyReport(null); }}
          patientId={patientId}
          patientName={patient.family_name}
          patientFamilyName={patient.name}
          patientAge={patient.dateNaissance ? Math.floor((Date.now() - new Date(patient.dateNaissance).getTime()) / (365.25 * 24 * 60 * 60 * 1000)) : (patient.age ?? null)}
          patientSex={patient.genre ?? null}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: medicalReportKeys.byPatient(patientId) });
            queryClient.invalidateQueries({ queryKey: cardiologyReportKeys.byPatient(patientId) });
            setCardioRefreshKey(k => k + 1);
            setShowCardiologyModal(false);
            setSelectedCardiologyReport(null);
          }}
          editReport={selectedCardiologyReport}
        />
      )}

      {/* Prescription Preview Modal */}

      {showPrescriptionPreview && selectedPrescription && (
        <PrescriptionPreviewModal
          prescription={selectedPrescription}
          isOpen={showPrescriptionPreview}
          onClose={() => {
            setShowPrescriptionPreview(false);
            setSelectedPrescription(null);
          }}
        />
      )}
    </div>
  );
}