'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import Header from '@/components/Header';
import {
  ArrowLeftIcon,
  DocumentTextIcon,
  ArrowTopRightOnSquareIcon,
  CalendarIcon,
  ClockIcon,
  UserIcon,
  PhoneIcon,
  MapPinIcon,
  HeartIcon,
  ExclamationTriangleIcon,
  PencilSquareIcon,
  LockClosedIcon,
  UserCircleIcon,
  PlusIcon,
  BanknotesIcon,
  TrashIcon,
  ShareIcon
} from '@heroicons/react/24/outline';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ApiPatient, usePatients, Invoice, CreateInvoicePayload } from '@/contexts/PatientsContext';
import { usePrescription } from '@/contexts/PrescriptionContext';
import { Appointment, useAppointments } from '@/contexts/AppointmentContext';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useProfile } from '@/contexts/ProfileContext';
import AddMedicalReportModal from '@/features/medical-reports/components/AddMedicalReportModal';
import PatientChartModal from '@/components/patients/PatientChartModal';
import PatientHistoryModal from '@/components/patients/PatientHistoryModal';
import ShareMedicalRecordModal from '@/features/sharing/components/ShareMedicalRecordModal';
import PrescriptionPreviewModal from '@/features/prescriptions/components/modals/PrescriptionPreviewModal';
import socketClient from "@/utils/socketClient";
import axios from 'axios';
import dynamic from 'next/dynamic';
import { DentalActHistory } from '@/features/dental/components';

// Lazy load the heavy dental modal with SVG
const DentalActModal = dynamic(() => import('@/features/dental/components/DentalActModal'), {
  loading: () => <div className="animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg h-96" />,
  ssr: false
});

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

const formattedDate = (date: Date) => {
  try {
    const formatteddate = date instanceof Date ? date : new Date(date);
    return !isNaN(formatteddate.getTime())
      ? formatteddate.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
      : 'Date non disponible';
  } catch {
    return 'Date non disponible';
  }
};

const renderMedicationsPreview = (meds: any[] | undefined, displayAll?: boolean) => {
  if (!meds || !Array.isArray(meds) || meds.length === 0) {
    return <span className="text-sm text-gray-500">Aucun médicament listé</span>;
  }

  const preview = meds.slice(0, 3).map((m, i) => {
    const name = m.medication?.nom_de_marque || m.medication?.denomination_commune_internationale || 'Médicament';
    const qty = m.quantity ? `${m.quantity}x ` : '';
    const dose = m.dosage ? ` - ${m.dosage}` : '';
    const note = m.note ? ` (${m.note})` : '';
    return (
      <div key={i} className="text-sm text-gray-700 dark:text-gray-300">
        {qty}{name}{dose}{note}
      </div>
    );
  });

  const all = meds.map((m, i) => {
    const name = m.medication?.nom_de_marque || m.medication?.denomination_commune_internationale || 'Médicament';
    const qty = m.quantity ? `${m.quantity}x ` : '';
    const dose = m.dosage ? ` - ${m.dosage}` : '';
    const note = m.note ? ` (${m.note})` : '';
    return (
      <div key={i} className="text-sm text-gray-700 dark:text-gray-300">
        {qty}{name}{dose}{note}
      </div>
    );
  });

  return (
    <div className="space-y-1">
      {displayAll ? all : preview}
      {meds.length > 3 && !displayAll && (
        <div className="text-xs text-gray-500 dark:text-gray-400">et {meds.length - 3} autre(s)</div>
      )}
    </div>
  );
};

export default function PatientDetail({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { isAuthenticated, user } = useAuth();
  const { getPatient, markChartAsRead, loading: patientsLoading, getInvoicesByPatient, createInvoice, updateInvoiceStatus, addInvoicePayment, distributePayment, deleteInvoice } = usePatients();
  const { fetchAppointmentsByPatient } = useAppointments();
  const { prescriptions, fetchPrescriptions, loading: prescriptionLoading, generatePrescriptionPdf } = usePrescription();
  const [patient, setPatient] = useState<ApiPatient | null>(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLanguage();

  const [showChartModal, setShowChartModal] = useState(false);
  const [isPrivate, setIsPrivate] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [patientHistory, setPatientHistory] = useState<any[]>([]);
  const [historyMetadata, setHistoryMetadata] = useState<{ patientCount: number; searchMethod: 'nin' | 'demographic'; hasDuplicates: boolean } | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [primaryCareInfo, setPrimaryCareInfo] = useState<any>(null);
  const [loadingPrimaryCare, setLoadingPrimaryCare] = useState(false);
  const [activeShareWithPrimaryCare, setActiveShareWithPrimaryCare] = useState<any>(null);
  const [receivedShares, setReceivedShares] = useState<any[]>([]); // Shares received from other doctors for this patient
  const [prescriptionFilter, setPrescriptionFilter] = useState<'all' | 'mine'>('all');
  const [reportFilter, setReportFilter] = useState<'all' | 'mine'>('all');

  const uniqueDoctorIds = [...new Set(prescriptions.map(p => p.doctor_user_id))];
  const hasMultipleDoctors = uniqueDoctorIds.length > 1;

  // Get list of doctor IDs who have shared with current doctor for this patient
  const sharedDoctorIds = receivedShares
    .filter(s => s.status === 'active' && s.share_prescriptions)
    .map(s => Number(s.shared_by_doctor_id));

  // Check if current doctor can see other doctors' prescriptions
  // Only if: (1) current doctor is the primary care doctor, OR (2) file is explicitly shared with current doctor
  const canSeeOtherDoctorsPrescriptions = primaryCareInfo?.isCurrentDoctor === true || primaryCareInfo?.shared === true;
  const isSharedPatient = canSeeOtherDoctorsPrescriptions || hasMultipleDoctors || sharedDoctorIds.length > 0;

  const filteredPrescriptions = (() => {
    if (!user?.id) return prescriptions;
    const currentUserId = parseInt(user.id);

    // Backend already filters prescriptions based on visibility rules
    // Frontend only applies the "mine" filter if selected
    if (prescriptionFilter === 'mine') {
      return prescriptions.filter(p => p.doctor_user_id === currentUserId);
    }
    return prescriptions;
  })();

  const [showAllPrescriptions, setShowAllPrescriptions] = useState(false);
  const [modalAnimation, setModalAnimation] = useState('scale-95 opacity-0');
  const [appointments, setAppointments] = useState<Appointment[] | null>();
  const [printConfirm, setPrintConfirm] = useState(false);
  const [prescriptionId, setPrescriptionId] = useState<number | null>(null);
  const [showPrescriptionPreview, setShowPrescriptionPreview] = useState(false);
  const [previewPrescription, setPreviewPrescription] = useState<typeof filteredPrescriptions[0] | null>(null);
  const [showMedicalReportModal, setShowMedicalReportModal] = useState(false);
  const [medicalReports, setMedicalReports] = useState<any[]>([]);
  const [loadingReports, setLoadingReports] = useState(false);
  const [showNinPopup, setShowNinPopup] = useState(false);
  const [ninInput, setNinInput] = useState('');
  const [savingNin, setSavingNin] = useState(false);

  // Access confirmation state - for patients not created by current doctor
  const [showAccessConfirmation, setShowAccessConfirmation] = useState(false);
  const [accessConfirmed, setAccessConfirmed] = useState(false);
  const [patientPresentCheckbox, setPatientPresentCheckbox] = useState(false);

  // Privacy choice popup state - after access confirmation if patient is private by another doctor
  const [showPrivacyChoicePopup, setShowPrivacyChoicePopup] = useState(false);
  const [myPrivacyChoice, setMyPrivacyChoice] = useState<'private' | 'shared' | null>(null);
  const [privacyChoiceLoaded, setPrivacyChoiceLoaded] = useState(false);

  // Ref to prevent popup useEffect from triggering multiple times
  const popupTriggeredRef = useRef(false);
  // Ref to track loaded privacy choice synchronously (avoids race condition with state)
  const loadedPrivacyChoiceRef = useRef<'private' | 'shared' | null>(null);

  // Invoice state
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedInvoiceForPayment, setSelectedInvoiceForPayment] = useState<Invoice | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [showGlobalPaymentModal, setShowGlobalPaymentModal] = useState(false);
  const [globalPaymentAmount, setGlobalPaymentAmount] = useState('');
  const [isDistributing, setIsDistributing] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);

  // Dental acts state
  const [showDentalActModal, setShowDentalActModal] = useState(false);
  const [selectedDentalAct, setSelectedDentalAct] = useState<any>(null);
  const [dentalActRefresh, setDentalActRefresh] = useState(0);

  // Visit count for assistant (fetched from API to match doctor's calculation)
  const [visitCount, setVisitCount] = useState<number | null>(null);
  const { tarifications, getTarificationsByDoctor, profile } = useProfile();
  const [selectedTarificationIds, setSelectedTarificationIds] = useState<number[]>([]);
  const [customItems, setCustomItems] = useState<{ label: string; price: string }[]>([]);
  const [newItemLabel, setNewItemLabel] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [creatingInvoice, setCreatingInvoice] = useState(false);

  useEffect(() => {
    if (showInvoiceModal) {
      getTarificationsByDoctor();
    }
  }, [showInvoiceModal, getTarificationsByDoctor]);

  // Check if popup is needed after data is loaded
  // Logic:
  // 1. If patient is shared with current doctor (via medical_shares) → show Access Confirmation only, skip Privacy Choice
  // 2. If owner AND no choice made → show Privacy Choice popup
  // 3. If NOT owner → show Access Confirmation popup, then Privacy Choice
  useEffect(() => {
    if (!patient || user?.role !== 'doctor' || loading || loadingReports || prescriptionLoading) return;
    if (!privacyChoiceLoaded) return; // Wait for privacy choice to be loaded from API
    if (accessConfirmed) return; // Already confirmed in this session

    // Prevent popup from triggering multiple times during data reloads
    if (popupTriggeredRef.current) return;

    // Check if current doctor is the patient owner (created by doctor or their assistant)
    const isPatientOwner = primaryCareInfo?.isPatientOwner === true;

    // Check if current doctor is the primary care doctor
    const isPrimaryCareDoctor = primaryCareInfo?.isCurrentDoctor === true;

    // If patient owner or primary care → check if privacy choice already made
    if (isPatientOwner || isPrimaryCareDoctor) {
      // If privacy choice already exists (check both state and ref for race condition), skip the popup
      if (myPrivacyChoice || loadedPrivacyChoiceRef.current) {
        setAccessConfirmed(true); // Auto-confirm access since choice was already made
        return;
      }
      popupTriggeredRef.current = true; // Mark as triggered
      setShowPrivacyChoicePopup(true);
      return;
    }

    // Not owner (including shared doctors) → check if privacy choice already made
    // If doctor already made a privacy choice for this patient, skip both popups
    if (myPrivacyChoice || loadedPrivacyChoiceRef.current) {
      setAccessConfirmed(true); // Auto-confirm access since choice was already made
      return;
    }

    // No choice made yet → show access confirmation popup
    // Shared doctors will see the confirmation modal but NOT the Privacy Choice popup
    popupTriggeredRef.current = true; // Mark as triggered
    setShowAccessConfirmation(true);
  }, [patient, user, loading, loadingReports, prescriptionLoading, primaryCareInfo, accessConfirmed, privacyChoiceLoaded, myPrivacyChoice]);

  // Fetch active shares when primaryCareInfo is loaded
  useEffect(() => {
    if (primaryCareInfo?.primaryCareDoctor?.id && !primaryCareInfo.isCurrentDoctor) {
      fetchActiveShares();
    }
  }, [primaryCareInfo]);

  // Load saved privacy choice for this patient from API
  const fetchPrivacyChoice = async () => {
    try {
      const response = await axios.get(`${API_URL}/doctor-patient-privacy/patient/${params.id}`, { withCredentials: true });
      if (response.data.success && response.data.data.privacy_choice) {
        setMyPrivacyChoice(response.data.data.privacy_choice);
        return response.data.data.privacy_choice;
      }
    } catch { /* ignore */ }
    return null;
  };

  useEffect(() => {
    const loadPrivacyChoice = async () => {
      let loadedChoice: 'private' | 'shared' | null = null;
      if (patient && user?.role === 'doctor') {
        loadedChoice = await fetchPrivacyChoice();
      }
      // Store in ref synchronously to avoid race condition with state
      loadedPrivacyChoiceRef.current = loadedChoice;
      if (loadedChoice) {
        setMyPrivacyChoice(loadedChoice);
      }
      setPrivacyChoiceLoaded(true);
    };
    loadPrivacyChoice();
  }, [patient, user, params.id]);

  // Fetch visit count for assistant (uses same calculation as doctor)
  useEffect(() => {
    const fetchVisitCount = async () => {
      if (patient && user?.role === 'assistant') {
        try {
          const response = await axios.get(`${API_URL}/patient/${params.id}/visit-count`, { withCredentials: true });
          if (response.data.success) {
            setVisitCount(response.data.data.visitCount);
          }
        } catch (error) {
          console.error('Error fetching visit count:', error);
          setVisitCount(0);
        }
      }
    };
    fetchVisitCount();
  }, [patient, user, params.id]);

  const calculatedTotal = useMemo(() => {
    const tarificationTotal = tarifications
      .filter((t) => selectedTarificationIds.includes(t.id))
      .reduce((sum, t) => sum + Number(t.price), 0);
    const customTotal = customItems.reduce((sum, item) => {
      const price = parseFloat(item.price);
      return sum + (isNaN(price) ? 0 : price);
    }, 0);
    return tarificationTotal + customTotal;
  }, [selectedTarificationIds, tarifications, customItems]);

  const confirmationModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl max-w-md w-full mx-4">
        <div className="text-center">
          {prescriptionLoading ? (
            <>
              <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Création de l'ordonnance en cours...</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">Veuillez patienter.</p>
            </>
          ) : (
            <>
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <DocumentTextIcon className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Confirmer la création</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                Créer une ordonnance pour <strong>{patient?.name} {patient?.family_name}</strong> ?
              </p>
              <div className="flex gap-3">
                <button onClick={() => setPrintConfirm(false)} className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">Annuler</button>
                <button onClick={handleConfirmPrint} className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">Confirmer</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );

  const handleOpenConfirmationPrint = (id: number) => { setPrescriptionId(id); setPrintConfirm(true); };
  const handleConfirmPrint = async () => { if (!prescriptionId) return; await generatePrescriptionPdf(prescriptionId); setPrintConfirm(false); };

  // Ouvrir le popup de prévisualisation pour les anciennes ordonnances
  const handleOpenPrescriptionPreview = (prescription: typeof filteredPrescriptions[0]) => {
    setPreviewPrescription(prescription);
    setShowPrescriptionPreview(true);
  };

  const handleChartModalConfirm = async () => {
    if (!patient) return;
    const success = await markChartAsRead(patient.id, isPrivate);
    if (success) {
      // Also save to doctor_patient_privacy table
      const privacyChoice = isPrivate ? 'private' : 'shared';
      try {
        await axios.post(`${API_URL}/doctor-patient-privacy/patient/${patient.id}`,
          { privacy_choice: privacyChoice },
          { withCredentials: true }
        );
        setMyPrivacyChoice(privacyChoice);
      } catch { /* ignore */ }
      setShowChartModal(false);
      setPatient(prev => prev ? { ...prev, is_chart_readed: true, is_private: isPrivate } : null);
    }
  };

  // Handle access confirmation
  const handleAccessConfirm = () => {
    if (!patientPresentCheckbox) return;
    setShowAccessConfirmation(false);

    // If patient is shared with current doctor, skip Privacy Choice popup
    // Shared doctors only need to confirm patient presence, not set privacy
    if ((patient as any).is_shared_with_me === true) {
      setAccessConfirmed(true);
      return;
    }

    // For non-shared patients, show privacy choice popup
    setShowPrivacyChoicePopup(true);
  };

  const handleAccessCancel = () => {
    router.push('/patients');
  };

  // Handle privacy choice (private or shared) - save to API and update patient.is_private
  const handlePrivacyChoice = async (choice: 'private' | 'shared') => {
    const isPrivateChoice = choice === 'private';

    // Update patient.is_private in database (like PatientChartModal does)
    if (patient) {
      await markChartAsRead(patient.id, isPrivateChoice);
      setPatient(prev => prev ? { ...prev, is_private: isPrivateChoice } : null);
    }

    // Also save to doctor_patient_privacy table
    try {
      await axios.post(`${API_URL}/doctor-patient-privacy/patient/${params.id}`,
        { privacy_choice: choice },
        { withCredentials: true }
      );
    } catch { /* ignore */ }

    setMyPrivacyChoice(choice);
    setShowPrivacyChoicePopup(false);
    // After privacy choice, confirm access
    setAccessConfirmed(true);
  };

  const openPrescriptionsModal = () => { setShowAllPrescriptions(true); setTimeout(() => setModalAnimation('scale-100 opacity-100'), 50); };
  const closePrescriptionsModal = () => { setModalAnimation('scale-95 opacity-0'); setTimeout(() => setShowAllPrescriptions(false), 300); };
  const openAppointmentModal = () => {
    if (!patient) return;
    const searchParams = new URLSearchParams({ patientId: patient.id, patientName: patient.name, patientFamilyName: patient.family_name, eventType: 'patient' });
    router.push(`/calendar?${searchParams.toString()}`);
  };

  const fetchMedicalReports = async () => {
    setLoadingReports(true);
    try {
      const response = await axios.get(`${API_URL}/medical-reports/patient/${params.id}`, { withCredentials: true });
      if (response.data.success) setMedicalReports(response.data.data.reports || []);
    } catch { setMedicalReports([]); } finally { setLoadingReports(false); }
  };

  const fetchPatientHistory = async () => {
    setLoadingHistory(true);
    try {
      const response = await axios.get(`${API_URL}/patient/${params.id}/history`, { withCredentials: true });
      if (response.data.success) {
        setPatientHistory(response.data.data);
        setHistoryMetadata(response.data.metadata || null);
        setShowHistoryModal(true);
      }
    } catch { alert('Erreur lors du chargement de l\'historique'); } finally { setLoadingHistory(false); }
  };

  const fetchPrimaryCareInfo = async () => {
    try {
      const response = await axios.get(`${API_URL}/patient/${params.id}/primary-care-info`, { withCredentials: true });
      if (response.data.success) setPrimaryCareInfo(response.data.data);
    } catch { /* ignore */ }
  };

  const togglePrimaryCareSharing = async () => {
    if (!primaryCareInfo) return;
    const isCurrentlyShared = primaryCareInfo.shared;
    if (!confirm(`Êtes-vous sûr de vouloir ${isCurrentlyShared ? 'retirer' : 'activer'} le partage ?`)) return;
    setLoadingPrimaryCare(true);
    try {
      const response = await axios.post(`${API_URL}/patient/${params.id}/share-primary-care`, { share: !isCurrentlyShared }, { withCredentials: true });
      if (response.data.success) await fetchPrimaryCareInfo();
    } catch (error: any) { alert(error.response?.data?.error || 'Erreur'); } finally { setLoadingPrimaryCare(false); }
  };

  // Fetch active shares for this patient (to check if already shared with primary care doctor)
  const fetchActiveShares = async () => {
    if (!primaryCareInfo?.primaryCareDoctor?.id) return;
    try {
      const response = await axios.get(`${API_URL}/medical-shares/patient/${params.id}`, { withCredentials: true });
      if (response.data.success) {
        const shares = response.data.data || [];
        const shareWithPrimaryCare = shares.find((s: any) =>
          s.shared_with_doctor_id === primaryCareInfo.primaryCareDoctor.id && s.status === 'active'
        );
        setActiveShareWithPrimaryCare(shareWithPrimaryCare || null);
      }
    } catch { /* ignore */ }
  };

  // Fetch shares received from other doctors for this patient
  const fetchReceivedShares = async () => {
    try {
      const response = await axios.get(`${API_URL}/medical-shares/received`, { withCredentials: true });
      if (response.data.success) {
        // Filter only shares for this patient (patient_id is UUID string, not integer)
        const sharesForPatient = (response.data.data || []).filter((s: any) =>
          String(s.patient_id) === String(params.id) && s.status === 'active'
        );
        setReceivedShares(sharesForPatient);
      }
    } catch { /* ignore */ }
  };

  // Share directly with the primary care doctor (for non-primary-care doctors)
  const shareWithPrimaryCareDoctor = async () => {
    if (!primaryCareInfo?.primaryCareDoctor?.id) return;
    if (!confirm(`Partager le dossier avec Dr. ${primaryCareInfo.primaryCareDoctor.name} ${primaryCareInfo.primaryCareDoctor.family_name} ?`)) return;
    setLoadingPrimaryCare(true);
    try {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30); // 30 days default
      const response = await axios.post(`${API_URL}/medical-shares`, {
        patient_id: params.id,
        shared_with_doctor_ids: [primaryCareInfo.primaryCareDoctor.id],
        share_prescriptions: true,
        share_medical_reports: true,
        visible_until_date: null,
        expires_at: expiresAt.toISOString(),
        reason: 'Partage avec le médecin traitant'
      }, { withCredentials: true });
      if (response.data.success) {
        alert('Dossier partagé avec succès');
        await fetchActiveShares();
      }
    } catch (error: any) { alert(error.response?.data?.error || 'Erreur lors du partage'); } finally { setLoadingPrimaryCare(false); }
  };

  // Revoke share with primary care doctor
  const revokeShareWithPrimaryCareDoctor = async () => {
    if (!activeShareWithPrimaryCare?.id) return;
    if (!confirm('Arrêter le partage avec le médecin traitant ?')) return;
    setLoadingPrimaryCare(true);
    try {
      const response = await axios.put(`${API_URL}/medical-shares/${activeShareWithPrimaryCare.id}/revoke`, {}, { withCredentials: true });
      if (response.data.success) {
        alert('Partage arrêté');
        setActiveShareWithPrimaryCare(null);
      }
    } catch (error: any) { alert(error.response?.data?.error || 'Erreur'); } finally { setLoadingPrimaryCare(false); }
  };

  const fetchInvoices = async () => {
    if (!patient?.id) return;
    setLoadingInvoices(true);
    try { const data = await getInvoicesByPatient(patient.id); setInvoices(data); } catch { /* ignore */ } finally { setLoadingInvoices(false); }
  };

  useEffect(() => {
    if (!patient?.id) return;
    const socket = socketClient.connect();
    if (!socket) return;
    const handleCreated = (newInvoice: Invoice) => {
      if (newInvoice.patient_id === patient.id) {
        setInvoices(prev => { if (prev.some(inv => String(inv.id) === String(newInvoice.id))) return prev; return [newInvoice, ...prev]; });
      }
    };
    const handleUpdated = (updatedInvoice: Invoice) => { setInvoices(prev => prev.map(inv => inv.id === updatedInvoice.id ? { ...inv, ...updatedInvoice } : inv)); };
    const handleDeleted = ({ id }: { id: number }) => { setInvoices(prev => prev.filter(inv => inv.id !== id)); };
    socket.on('invoice:created', handleCreated);
    socket.on('invoice:updated', handleUpdated);
    socket.on('invoice:deleted', handleDeleted);
    return () => { socket.off('invoice:created', handleCreated); socket.off('invoice:updated', handleUpdated); socket.off('invoice:deleted', handleDeleted); };
  }, [patient?.id]);

  const handleCreateInvoice = async () => {
    if (!patient || calculatedTotal < 0) { alert("Le montant total ne peut pas être négatif"); return; }
    setCreatingInvoice(true);
    try {
      const itemsPayload = [
        ...tarifications.filter(t => selectedTarificationIds.includes(t.id)).map(t => ({ tarification_id: t.id, label: t.service_label, price: Number(t.price) })),
        ...customItems.filter(i => i.label && i.price).map(i => ({ label: i.label, price: parseFloat(i.price) }))
      ];
      const payload: CreateInvoicePayload = { patient_id: patient.id, total_price: calculatedTotal, items: itemsPayload };
      const newInvoice = await createInvoice(payload);
      if (newInvoice) {
        // Socket event 'invoice:created' will handle adding the invoice to state
        // to avoid duplicate entries
        setShowInvoiceModal(false);
        setSelectedTarificationIds([]);
        setCustomItems([]);
      }
    } finally { setCreatingInvoice(false); }
  };

  const handleToggleInvoiceStatus = async (id: number, currentStatus: 'paid' | 'unpaid' | 'partial') => {
    const newStatus = currentStatus === 'paid' ? 'unpaid' : 'paid';
    const success = await updateInvoiceStatus(id, newStatus);
    if (success) setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status: newStatus } : inv));
  };

  const handleOpenPaymentModal = (invoice: Invoice) => {
    setSelectedInvoiceForPayment(invoice);
    const remaining = parseFloat(invoice.total_price) - parseFloat(invoice.amount_paid || '0');
    setPaymentAmount(remaining > 0 ? remaining.toString() : '');
    setShowPaymentModal(true);
  };

  const handleAddPayment = async () => {
    if (!selectedInvoiceForPayment) return;
    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0) {
      alert('Veuillez entrer un montant valide');
      return;
    }
    setProcessingPayment(true);
    try {
      const updatedInvoice = await addInvoicePayment(selectedInvoiceForPayment.id, amount);
      if (updatedInvoice) {
        setInvoices(prev => prev.map(inv => inv.id === updatedInvoice.id ? updatedInvoice : inv));
        setShowPaymentModal(false);
        setSelectedInvoiceForPayment(null);
        setPaymentAmount('');
      }
    } finally {
      setProcessingPayment(false);
    }
  };

  const handleDeleteInvoice = async (id: number) => {
    if (!confirm("Supprimer cette facture ?")) return;
    const success = await deleteInvoice(id);
    if (success) setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  const handleOpenGlobalPaymentModal = () => {
    const totalUnpaid = invoices
      .filter(inv => inv.status !== 'paid' && inv.status !== 'free')
      .reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0);
    setGlobalPaymentAmount(totalUnpaid.toString());
    setShowGlobalPaymentModal(true);
  };

  const handleDistributePayment = async () => {
    if (!patient || isDistributing) return;
    const amount = parseFloat(globalPaymentAmount);
    if (isNaN(amount) || amount <= 0) return;

    setIsDistributing(true);
    const result = await distributePayment(patient.id, amount);
    setIsDistributing(false);

    if (result?.success) {
      // Update local invoices state with the updated invoices
      setInvoices(prev => {
        const updatedMap = new Map(result.updatedInvoices.map(inv => [inv.id, inv]));
        return prev.map(inv => updatedMap.get(inv.id) || inv);
      });
      setShowGlobalPaymentModal(false);
      setGlobalPaymentAmount('');
    }
  };

  useEffect(() => { if (patient?.id) fetchInvoices(); }, [patient?.id]);

  useEffect(() => {
    let isMounted = true;
    const loadData = async () => {
      try {
        const foundedPatient = await getPatient(params.id);
        if (!isMounted) return;
        setPatient(foundedPatient || null);
        if (foundedPatient) {
          await fetchPrescriptions({ patientId: params.id });
          const appointmentsResult = await fetchAppointmentsByPatient(params.id);
          setAppointments(appointmentsResult);
          fetchMedicalReports();
          fetchInvoices();
          if (user?.role === 'doctor') {
            await fetchPrimaryCareInfo();
            await fetchReceivedShares();
          }

          // Access confirmation will be checked after prescriptions and reports are loaded
          // via useEffect below
          if (user?.role !== 'doctor') {
            setAccessConfirmed(true); // Assistants don't need confirmation
          }

          // Chart modal disabled - no longer needed
          // if (user?.role === 'doctor' && foundedPatient.assistant_id && foundedPatient.is_chart_readed === false) {
          //   setShowChartModal(true);
          //   setIsPrivate(foundedPatient.is_private || false);
          // }
          if (user?.role === 'doctor' && !foundedPatient.nin) {
            const today = new Date().toISOString().split('T')[0];
            const storageKey = `nin_popup_${params.id}`;
            const storedData = localStorage.getItem(storageKey);
            let visitData = { visits: 0, lastPopupDate: '', lastVisitDate: '' };
            if (storedData) { try { visitData = JSON.parse(storedData); } catch { /* ignore */ } }
            if (visitData.lastVisitDate !== today) { visitData.visits = 0; visitData.lastVisitDate = today; }
            visitData.visits += 1;
            if (visitData.visits >= 2 && visitData.lastPopupDate !== today) { setShowNinPopup(true); visitData.lastPopupDate = today; }
            localStorage.setItem(storageKey, JSON.stringify(visitData));
          }
        }
      } catch { /* ignore */ } finally { if (isMounted) setLoading(false); }
    };
    loadData();
    return () => { isMounted = false; };
  }, [params.id, isAuthenticated]);

  if (loading || !isAuthenticated) {
    return (
      <div className="min-h-screen overflow-hidden bg-gray-50 dark:bg-gray-900 transition-colors">
        <div className="flex">
          <div className="ml-[100px] p-4 flex flex-col h-screen flex-1">
            <Header />
            <div className="flex items-center justify-center flex-1">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#2B2F98]"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="min-h-screen overflow-hidden bg-gray-50 dark:bg-gray-900 transition-colors">
        <div className="flex">
          <div className="ml-[100px] w-full flex flex-col h-screen p-4 flex-1">
            <Header />
            <div className="mt-4">
              <Link href="/patients" className="inline-flex items-center gap-2 mb-6 text-blue-600 dark:text-blue-400 hover:text-blue-800">
                <ArrowLeftIcon className="w-4 h-4" />
                {t('patients.detail.backToList')}
              </Link>
              <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
                <h2 className="mb-4 text-xl font-semibold text-gray-900 dark:text-white">Patient non trouvé</h2>
                <p className="text-gray-600 dark:text-gray-400">Le patient que vous recherchez n'existe pas.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="flex">
        <div className="ml-[100px] p-4 flex flex-col h-screen flex-1 overflow-hidden">
          <Header />

          <div className="flex-1 mt-4 overflow-auto">
            {/* Back Button */}
            <div className="mb-6">
              <Link href="/patients" className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors">
                <ArrowLeftIcon className="w-4 h-4" />
                {t('patients.detail.backToList')}
              </Link>
            </div>

            {/* Patient Information Card - Full Width */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors mb-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                    <UserIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    {t('patients.detail.patientInfo')}
                  </h2>
                  {/* Show "Privé" badge only if: current doctor is primary care (who set it private) OR current doctor chose "private" */}
                  {patient.is_private && (primaryCareInfo?.isCurrentDoctor || myPrivacyChoice === 'private') && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-amber-800 bg-amber-50 dark:bg-amber-900/30 dark:text-amber-200 border border-amber-200 dark:border-amber-800 rounded-full">
                      <LockClosedIcon className="w-3.5 h-3.5" />
                      {t('patients.detail.private')}
                    </span>
                  )}
                  {(patient as any).is_shared_with_me && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-purple-800 bg-purple-50 dark:bg-purple-900/30 dark:text-purple-200 border border-purple-200 dark:border-purple-800 rounded-full">
                      <ShareIcon className="w-3.5 h-3.5" />
                      {t('patients.detail.shared')}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {user?.role === 'doctor' && (
                    <>
                      <button onClick={fetchPatientHistory} disabled={loadingHistory} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-purple-600 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-300 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/40 transition-colors disabled:opacity-50">
                        <ClockIcon className="w-4 h-4" />
                        {loadingHistory ? 'Chargement...' : 'Historique'}
                      </button>
                      <button onClick={() => setShowShareModal(true)} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 dark:text-indigo-300 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors">
                        <ShareIcon className="w-4 h-4" />
                        Partager
                      </button>
                    </>
                  )}
                  <Link href={`/patients/new?mode=edit&id=${patient.id}`} className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 dark:bg-blue-900/20 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors">
                    <PencilSquareIcon className="w-4 h-4" />
                    {t('patients.detail.edit')}
                  </Link>
                </div>
              </div>

              {/* Patient Name and Visits */}
              <div className="pb-4 border-b-2 border-blue-100 dark:border-blue-900/30 flex items-start justify-between gap-4 mb-4">
                <div className="flex-1">
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">{patient.name} {patient.family_name}</h1>
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
                    <span className="flex items-center gap-1.5">
                      <UserIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span className="font-medium">{patient.age ? `${patient.age} ans` : 'Âge non renseigné'}</span>
                    </span>
                    <span>•</span>
                    <span className="font-medium">{patient.genre || 'Genre non renseigné'}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1.5">
                      <PhoneIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      <span className="font-medium">{patient.telephone || 'Non renseigné'}</span>
                    </span>
                  </div>
                </div>
                <div className="flex-shrink-0 flex flex-col items-center gap-1 px-4 py-2 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <span className="text-xs text-gray-600 dark:text-gray-400">{t('patients.detail.visits')}</span>
                  <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {user?.role === 'doctor'
                      ? (() => {
                        // Get unique days from prescriptions and reports by this doctor
                        // Use local date (not UTC) to avoid timezone issues
                        const toLocalDate = (date: Date) => {
                          return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
                        };
                        const prescriptionDates = prescriptions
                          .filter(p => p.doctor_user_id === parseInt(user.id))
                          .map(p => toLocalDate(new Date(p.created_at)));
                        const reportDates = medicalReports
                          .filter((r: any) => r.doctor_user_id === parseInt(user.id))
                          .map((r: any) => toLocalDate(new Date(r.created_at || r.examination_date)));
                        return new Set([...prescriptionDates, ...reportDates]).size;
                      })()
                      : (visitCount !== null ? visitCount : (patient.consultations || 0))}
                  </span>
                </div>
              </div>

              {/* Two Column Layout for Patient Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Personal Info */}
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">{t('patients.detail.personalInfo')}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-start">
                        <span className="text-gray-500 dark:text-gray-400 w-32">{t('patients.detail.dateOfBirth')}:</span>
                        <span className="font-medium text-gray-800 dark:text-gray-200">{patient.dateNaissance ? new Date(patient.dateNaissance).toLocaleDateString('fr-FR') : 'Non renseigné'}</span>
                      </div>
                      <div className="flex items-start">
                        <span className="text-gray-500 dark:text-gray-400 w-32">{t('patients.detail.email')}:</span>
                        <span className="font-medium text-gray-800 dark:text-gray-200">{patient.email || 'Non renseigné'}</span>
                      </div>
                      <div className="flex items-start">
                        <span className="text-gray-500 dark:text-gray-400 w-32">{t('patients.detail.nin')}:</span>
                        <span className="font-medium text-gray-800 dark:text-gray-200">{patient.nin || 'Non renseigné'}</span>
                      </div>
                      <div className="flex items-start">
                        <span className="text-gray-500 dark:text-gray-400 w-32">{t('patients.detail.socialSecurity')}:</span>
                        <span className="font-medium text-gray-800 dark:text-gray-200">{patient.numeroSecuriteSociale || 'Non renseigné'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center gap-1">
                      <MapPinIcon className="w-4 h-4" />
                      {t('patients.detail.address')}
                    </h3>
                    <p className="text-sm text-gray-800 dark:text-gray-200">{patient.adresse || 'Non renseigné'}</p>
                  </div>

                  {/* Primary Care Physician - Show to all doctors */}
                  {user?.role === 'doctor' && primaryCareInfo && primaryCareInfo.hasPrimaryCare && (
                    <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex-1">
                          <h3 className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1 flex items-center gap-1">
                            <UserCircleIcon className="w-3.5 h-3.5" />
                            Médecin Traitant
                          </h3>
                          {primaryCareInfo.isCurrentDoctor ? (
                            <p className="text-sm font-medium text-green-600 dark:text-green-400">Vous êtes le médecin traitant</p>
                          ) : (
                            <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                              {primaryCareInfo.primaryCareDoctor
                                ? `Dr. ${primaryCareInfo.primaryCareDoctor.name} ${primaryCareInfo.primaryCareDoctor.family_name}`
                                : 'Non renseigné'}
                            </p>
                          )}
                        </div>
                        {/* Share button - only show if doctor chose "private" (if "shared", data is already visible to everyone) */}
                        {!primaryCareInfo.isCurrentDoctor && primaryCareInfo.primaryCareDoctor && myPrivacyChoice === 'private' && (
                          activeShareWithPrimaryCare ? (
                            <button
                              onClick={revokeShareWithPrimaryCareDoctor}
                              disabled={loadingPrimaryCare}
                              className="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors bg-green-100 text-green-700 hover:bg-red-100 hover:text-red-700 dark:bg-green-900/30 dark:text-green-400 dark:hover:bg-red-900/30 dark:hover:text-red-400"
                            >
                              {loadingPrimaryCare ? '...' : 'Partage en cours ✓'}
                            </button>
                          ) : (
                            <button
                              onClick={shareWithPrimaryCareDoctor}
                              disabled={loadingPrimaryCare}
                              className="px-3 py-1.5 text-xs font-medium rounded-lg transition-colors bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400"
                            >
                              {loadingPrimaryCare ? '...' : 'Partager le dossier'}
                            </button>
                          )
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Medical Info - Always show medical info, never show "Dossier Privé" to other doctors */}
                {user?.role === 'doctor' && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2 flex items-center gap-1">
                        <HeartIcon className="w-4 h-4" />
                        {t('patients.detail.medicalInfo')}
                      </h3>
                      <div className="space-y-2">
                        <div>
                          <span className="text-xs font-medium text-gray-500 dark:text-gray-400">{t('patients.detail.chronicDiseases')}:</span>
                          <p className="text-sm text-gray-800 dark:text-gray-200 mt-1">{patient.chronicDiseases || 'Aucune'}</p>
                        </div>
                        <div>
                          <span className="text-xs font-medium text-gray-500 dark:text-gray-400">{t('patients.detail.allergies')}:</span>
                          <p className="text-sm text-gray-800 dark:text-gray-200 mt-1">{patient.allergies || 'Aucune'}</p>
                        </div>
                      </div>
                    </div>

                    {(patient.emergencyContact || patient.emergencyPhone) && (
                      <div className="pt-4 border-t border-gray-100 dark:border-gray-700">
                        <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-500 mb-2 flex items-center gap-1">
                          <ExclamationTriangleIcon className="w-4 h-4" />
                          {t('patients.detail.emergencyContact')}
                        </h3>
                        <div className="bg-yellow-50 dark:bg-yellow-900/20 p-3 rounded-lg space-y-1 text-sm">
                          <div className="flex items-start">
                            <span className="text-gray-600 dark:text-gray-400 w-24">Contact:</span>
                            <span className="font-medium text-gray-800 dark:text-gray-200">{patient.emergencyContact || 'Non renseigné'}</span>
                          </div>
                          <div className="flex items-start">
                            <span className="text-gray-600 dark:text-gray-400 w-24">Téléphone:</span>
                            <span className="font-medium text-gray-800 dark:text-gray-200">{patient.emergencyPhone || 'Non renseigné'}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* ACTES DENTAIRES - Full Width after Patient Info (only for dental specialities) */}
            {user?.role === 'doctor' && profile?.speciality && [
              'Chirurgie dentaire',
              'Orthodontie',
              'Parodontologie',
              'Implantologie',
              'Médecine bucco-dentaire'
            ].some(spec => profile.speciality?.toLowerCase().includes(spec.toLowerCase())) && (
                <div className="mb-6">
                  <DentalActHistory
                    patientId={params.id}
                    onAddClick={() => {
                      setSelectedDentalAct(null);
                      setShowDentalActModal(true);
                    }}
                    onViewDetail={(act) => {
                      setSelectedDentalAct(act);
                      setShowDentalActModal(true);
                    }}
                    refreshTrigger={dentalActRefresh}
                  />
                </div>
              )}

            {/* 2-Column Grid: Prescriptions (left) | RDV + Comptes Rendus (right) - For Doctor */}
            {/* For Assistant: Only RDV in full width */}
            {user?.role === 'assistant' && (
              <div className="mb-6">
                {/* Rendez-vous - Full Width for Assistant */}
                <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                      <CalendarIcon className="w-5 h-5 text-purple-600 dark:text-purple-500" />
                      {t('patients.detail.appointments')}
                    </h2>
                    <button onClick={openAppointmentModal} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                      {t('patients.detail.new')}
                    </button>
                  </div>

                  <div className="overflow-y-auto max-h-[400px]">
                    {appointments && appointments.length > 0 ? (
                      (() => {
                        const now = new Date(); now.setHours(0, 0, 0, 0);
                        const sorted = [...appointments].sort((a, b) => new Date(b.date as string).getTime() - new Date(a.date as string).getTime());
                        const future = sorted.filter(apt => { const d = new Date(apt.date as string); d.setHours(0, 0, 0, 0); return d >= now; }).reverse();
                        const past = sorted.filter(apt => { const d = new Date(apt.date as string); d.setHours(0, 0, 0, 0); return d < now; });

                        return (
                          <div className="w-full space-y-4">
                            {future.length > 0 && (
                              <div>
                                <div className="text-xs font-semibold text-green-600 dark:text-green-400 uppercase tracking-wide mb-3">À venir ({future.length})</div>
                                <div className="space-y-2">
                                  {future.map((apt) => (
                                    <div key={apt.id} className="w-full flex items-center justify-between border-2 border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 rounded-xl p-4 hover:shadow-md transition-shadow">
                                      <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 bg-green-100 dark:bg-green-800/50 rounded-full flex items-center justify-center">
                                          <CalendarIcon className="w-6 h-6 text-green-600 dark:text-green-400" />
                                        </div>
                                        <div>
                                          <div className="text-base font-semibold text-gray-800 dark:text-gray-200">
                                            {new Date(apt.date as string).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                                          </div>
                                          <div className="text-sm text-green-600 dark:text-green-400">Rendez-vous confirmé</div>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-2 bg-white dark:bg-gray-800 px-4 py-2 rounded-lg shadow-sm">
                                        <ClockIcon className="w-5 h-5 text-green-600 dark:text-green-400" />
                                        <span className="text-xl font-bold text-gray-800 dark:text-gray-200">{apt.time}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            {past.length > 0 && (
                              <div>
                                <div className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-3">Passés ({past.length})</div>
                                <div className="space-y-2">
                                  {past.slice(0, 10).map((apt) => (
                                    <div key={apt.id} className="w-full flex items-center justify-between border border-gray-200 dark:border-gray-700 rounded-lg p-3 opacity-70 hover:opacity-100 transition-opacity">
                                      <div className="flex items-center gap-3">
                                        <CalendarIcon className="w-5 h-5 text-gray-400" />
                                        <span className="text-sm text-gray-600 dark:text-gray-400">
                                          {new Date(apt.date as string).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}
                                        </span>
                                      </div>
                                      <span className="text-sm font-medium text-gray-600 dark:text-gray-400">{apt.time}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })()
                    ) : (
                      <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                        <CalendarIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                        <p className="text-sm font-medium">{t('patients.detail.noAppointments')}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Doctor view: 2-Column Grid */}
            <div className={`grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6 ${user?.role === 'assistant' ? 'hidden' : ''}`}>

              {/* LEFT COLUMN: Prescriptions - stretches to match right column height */}
              {user?.role === 'doctor' && (
                <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                      <DocumentTextIcon className="w-5 h-5 text-green-600 dark:text-green-500" />
                      {t('patients.detail.prescriptions')}
                    </h2>
                    <div className="flex gap-2">
                      <Link href={`/ordonnance/prescription/${patient.id}`} className="px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 transition-colors">
                        {t('patients.detail.new')}
                      </Link>
                      {filteredPrescriptions.length > 0 && (
                        <button className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 dark:bg-blue-900/20 dark:text-blue-300 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors" onClick={openPrescriptionsModal}>
                          {t('patients.detail.viewAll')}
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="mb-3 flex gap-2">
                    <button onClick={() => setPrescriptionFilter('all')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${prescriptionFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>
                      Tous ({prescriptions.length})
                    </button>
                    <button onClick={() => setPrescriptionFilter('mine')} className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${prescriptionFilter === 'mine' ? 'bg-blue-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>
                      Les miennes ({prescriptions.filter(p => p.doctor_user_id === parseInt(user?.id || '0')).length})
                    </button>
                  </div>

                  {/* Prescriptions list - flex-1 to fill available space */}
                  <div className="space-y-3 overflow-y-auto flex-1 pr-2">
                    {filteredPrescriptions.length > 0 ? (
                      filteredPrescriptions.map((prescription, index) => (
                        <div key={index} onClick={() => handleOpenPrescriptionPreview(prescription)} className="flex items-start gap-3 p-4 border border-gray-100 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer">
                          <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                            <DocumentTextIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-sm text-gray-900 dark:text-white">{formattedDate(prescription.created_at as Date)}</span>
                              {isSharedPatient && hasMultipleDoctors && prescription.doctor && (
                                <span className={`text-xs px-2 py-0.5 rounded-full ${prescription.doctor_user_id === parseInt(user?.id || '0') ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400'}`}>
                                  Dr. {prescription.doctor.name}
                                </span>
                              )}
                            </div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">{renderMedicationsPreview(prescription.medications)}</div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500 dark:text-gray-400 flex-1 flex flex-col items-center justify-center">
                        <DocumentTextIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                        <p className="text-sm font-medium">{t('patients.detail.noPrescriptions')}</p>
                        <p className="text-xs mt-1">Cliquez sur "Nouvelle" pour créer</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* RIGHT COLUMN: RDV + Comptes Rendus stacked */}
              <div className="flex flex-col gap-6">

                {/* Rendez-vous */}
                <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                      <CalendarIcon className="w-5 h-5 text-purple-600 dark:text-purple-500" />
                      {t('patients.detail.appointments')}
                    </h2>
                    <button onClick={openAppointmentModal} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                      {t('patients.detail.new')}
                    </button>
                  </div>

                  <div className="space-y-3 overflow-y-auto max-h-[200px] pr-2">
                    {appointments && appointments.length > 0 ? (
                      (() => {
                        const now = new Date(); now.setHours(0, 0, 0, 0);
                        const sorted = [...appointments].sort((a, b) => new Date(b.date as string).getTime() - new Date(a.date as string).getTime());
                        const future = sorted.filter(apt => { const d = new Date(apt.date as string); d.setHours(0, 0, 0, 0); return d >= now; }).reverse();
                        const past = sorted.filter(apt => { const d = new Date(apt.date as string); d.setHours(0, 0, 0, 0); return d < now; });

                        return (
                          <>
                            {future.length > 0 && (
                              <>
                                <div className="text-xs font-semibold text-green-600 dark:text-green-400 uppercase tracking-wide mb-2">À venir ({future.length})</div>
                                {future.map((apt) => (
                                  <div key={apt.id} className="border-2 border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20 rounded-lg p-3">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2 text-xs text-green-700 dark:text-green-400 font-medium">
                                        <CalendarIcon className="w-4 h-4" />
                                        {new Date(apt.date as string).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' })}
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <ClockIcon className="w-4 h-4 text-green-600 dark:text-green-400" />
                                        <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">{apt.time}</span>
                                      </div>
                                    </div>
                                  </div>
                                ))}
                              </>
                            )}
                            {past.length > 0 && (
                              <>
                                <div className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2 mt-3">Passés ({past.length})</div>
                                {past.slice(0, 3).map((apt) => (
                                  <div key={apt.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 opacity-60">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                                        <CalendarIcon className="w-4 h-4" />
                                        {new Date(apt.date as string).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}
                                      </div>
                                      <span className="text-sm text-gray-600 dark:text-gray-400">{apt.time}</span>
                                    </div>
                                  </div>
                                ))}
                              </>
                            )}
                          </>
                        );
                      })()
                    ) : (
                      <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                        <CalendarIcon className="w-10 h-10 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                        <p className="text-sm font-medium">{t('patients.detail.noAppointments')}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Comptes Rendus */}
                <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                      <DocumentTextIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                      {t('patients.detail.medicalReport')}
                    </h2>
                    <button onClick={() => setShowMedicalReportModal(true)} className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors">
                      {t('patients.detail.new')}
                    </button>
                  </div>

                  {(() => {
                    // Backend already filters medical reports based on visibility rules
                    const currentUserId = parseInt(user?.id || '0');

                    const uniqueReportDoctorIds = [...new Set(medicalReports.map((r: any) => r.doctor_user_id))];
                    const hasMultipleReportDoctors = uniqueReportDoctorIds.length > 1;
                    const filteredReports = reportFilter === 'mine' && user?.id ? medicalReports.filter((r: any) => r.doctor_user_id === currentUserId) : medicalReports;

                    return (
                      <>
                        <div className="mb-3 flex gap-2">
                          <button onClick={() => setReportFilter('all')} className={`px-3 py-1.5 text-xs font-medium rounded-lg ${reportFilter === 'all' ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>Tous ({medicalReports.length})</button>
                          <button onClick={() => setReportFilter('mine')} className={`px-3 py-1.5 text-xs font-medium rounded-lg ${reportFilter === 'mine' ? 'bg-indigo-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>Les miens ({medicalReports.filter((r: any) => r.doctor_user_id === currentUserId).length})</button>
                        </div>

                        {loadingReports ? (
                          <div className="text-center py-6"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div></div>
                        ) : filteredReports.length === 0 ? (
                          <div className="text-center py-6">
                            <DocumentTextIcon className="w-10 h-10 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                            <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{t('patients.detail.noMedicalReports')}</p>
                          </div>
                        ) : (
                          <div className="space-y-2 overflow-y-auto max-h-[150px]">
                            {filteredReports.map((report: any) => (
                              <div key={report.id} onClick={() => window.open(`${API_URL}/medical-reports/${report.id}/pdf`, '_blank')} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors cursor-pointer">
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex-1 min-w-0">
                                    <h4 className="font-medium text-sm text-gray-900 dark:text-white truncate">{report.title}</h4>
                                    <p className="text-xs text-gray-500 dark:text-gray-400">{new Date(report.examination_date).toLocaleDateString('fr-FR')}</p>
                                  </div>
                                  <ArrowTopRightOnSquareIcon className="w-4 h-4 text-gray-400 flex-shrink-0" />
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    );
                  })()}
                </div>
              </div>
            </div>

            {/* FACTURES - Full Width at Bottom */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                  <BanknotesIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-500" />
                  {t('invoice.card.header')}
                </h2>
                {user?.role === 'doctor' && (
                  <button onClick={() => setShowInvoiceModal(true)} className="px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors flex items-center gap-2">
                    <PlusIcon className="w-4 h-4" />
                    {t('invoice.card.invoice')}
                  </button>
                )}
              </div>

              {loadingInvoices ? (
                <div className="text-center py-8"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto"></div></div>
              ) : invoices.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Date</th>
                        <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Description</th>
                        <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Montant</th>
                        <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Payé</th>
                        <th className="text-right py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Reste</th>
                        <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Statut</th>
                        <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                      {invoices.map((invoice) => {
                        const totalPrice = parseFloat(invoice.total_price);
                        const amountPaid = parseFloat(invoice.amount_paid || '0');
                        const remaining = totalPrice - amountPaid;
                        return (
                          <tr key={invoice.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                            <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                              {new Date(invoice.created_at).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })}
                            </td>
                            <td className="py-3 px-4">
                              <span className="text-sm font-medium text-gray-800 dark:text-gray-200">
                                {invoice.items?.[0]?.label || 'Consultation'}
                              </span>
                              {invoice.items && invoice.items.length > 1 && (
                                <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">+{invoice.items.length - 1} autre(s)</span>
                              )}
                            </td>
                            <td className="py-3 px-4 text-right">
                              <span className="text-sm font-bold text-gray-900 dark:text-white">
                                {totalPrice.toLocaleString('fr-DZ')} DA
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <span className={`text-sm font-medium ${amountPaid > 0 ? 'text-green-600 dark:text-green-400' : 'text-gray-400'}`}>
                                {amountPaid.toLocaleString('fr-DZ')} DA
                              </span>
                            </td>
                            <td className="py-3 px-4 text-right">
                              <span className={`text-sm font-bold ${remaining > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                                {remaining.toLocaleString('fr-DZ')} DA
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center justify-center">
                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${invoice.status === 'paid'
                                  ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                                  : invoice.status === 'partial'
                                    ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
                                    : invoice.status === 'free'
                                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
                                      : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                  }`}>
                                  {invoice.status === 'paid' ? 'Payée' : invoice.status === 'partial' ? 'Partiel' : invoice.status === 'free' ? 'Gratuit' : 'Non payée'}
                                </span>
                              </div>
                            </td>
                            <td className="py-3 px-4">
                              <div className="flex items-center justify-center gap-1">
                                {invoice.status !== 'paid' && invoice.status !== 'free' && (
                                  <button
                                    onClick={() => handleOpenPaymentModal(invoice)}
                                    className="text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 transition-colors p-1"
                                    title="Encaisser"
                                  >
                                    <BanknotesIcon className="w-4 h-4" />
                                  </button>
                                )}
                                <button onClick={() => handleDeleteInvoice(invoice.id)} className="text-gray-400 hover:text-red-500 transition-colors p-1" title="Supprimer">
                                  <TrashIcon className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  {/* Invoice Totals */}
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between">
                      {/* Global Payment Button */}
                      {invoices.some(inv => inv.status !== 'paid' && inv.status !== 'free') && (
                        <button
                          onClick={handleOpenGlobalPaymentModal}
                          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 transition-colors shadow-sm"
                        >
                          <BanknotesIcon className="w-5 h-5" />
                          Encaisser un montant global
                        </button>
                      )}
                      <div className="flex gap-8 ml-auto">
                        <div className="text-right">
                          <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Total Factures</p>
                          <p className="text-lg font-bold text-gray-900 dark:text-white">
                            {invoices.reduce((sum, inv) => sum + parseFloat(inv.total_price), 0).toLocaleString('fr-DZ')} DA
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Total Payé</p>
                          <p className="text-lg font-bold text-green-600 dark:text-green-400">
                            {invoices.reduce((sum, inv) => sum + parseFloat(inv.amount_paid || '0'), 0).toLocaleString('fr-DZ')} DA
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-500 dark:text-gray-400 uppercase">Reste à Payer</p>
                          <p className="text-lg font-bold text-red-600 dark:text-red-400">
                            {invoices.reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0).toLocaleString('fr-DZ')} DA
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                  <BanknotesIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                  <p className="text-sm font-medium">{t('invoice.card.noInvoices')}</p>
                  <p className="text-xs mt-1">Cliquez sur "Nouvelle facture" pour créer</p>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* ==================== MODALS ==================== */}

      {/* Dental Act Modal (lazy-loaded) */}
      {showDentalActModal && (
        <DentalActModal
          isOpen={showDentalActModal}
          onClose={() => {
            setShowDentalActModal(false);
            setSelectedDentalAct(null);
          }}
          patientId={params.id}
          onSuccess={() => setDentalActRefresh(prev => prev + 1)}
          editAct={selectedDentalAct}
          readOnly={selectedDentalAct && selectedDentalAct.doctor_user_id !== Number(user?.id)}
        />
      )}

      {/* Prescriptions Modal */}
      {showAllPrescriptions && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 dark:bg-black dark:bg-opacity-80" onClick={closePrescriptionsModal}></div>
          <div className="flex items-center justify-center min-h-screen p-4">
            <div className={`relative bg-white dark:bg-gray-800 rounded-lg shadow-xl transform transition-all sm:max-w-3xl sm:w-full ${modalAnimation}`}>
              <div className="px-4 pt-5 pb-4 sm:p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">{t('patients.detail.allPrescriptions')}</h3>
                  <button onClick={closePrescriptionsModal} className="text-gray-400 hover:text-gray-500">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
                <div className="max-h-[70vh] overflow-y-auto space-y-3">
                  {filteredPrescriptions.map((prescription, index) => (
                    <div key={index} className="p-3 border border-gray-100 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer" onClick={() => handleOpenPrescriptionPreview(prescription)}>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                          <DocumentTextIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-700 dark:text-gray-200">{new Date(prescription.created_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                          <div className="mt-1">{renderMedicationsPreview(prescription.medications, true)}</div>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); handleOpenPrescriptionPreview(prescription); }} className="px-3 py-1.5 border border-blue-300 dark:border-blue-600 text-xs font-medium rounded-md text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-900/20 hover:bg-blue-100 dark:hover:bg-blue-900/40">
                          {t('patients.detail.view') || 'Voir'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {printConfirm && prescriptionId && confirmationModal()}

      {/* Medical Report Modal */}
      {patient && (
        <AddMedicalReportModal isOpen={showMedicalReportModal} onClose={() => setShowMedicalReportModal(false)} patientId={patient.id.toString()} patientName={patient.family_name} patientFamilyName={patient.name} patientDateNaissance={patient.dateNaissance} patientGenre={patient.genre} onSuccess={fetchMedicalReports} />
      )}

      {/* Chart Modal */}
      <PatientChartModal isOpen={showChartModal} patientName={patient?.name || ''} patientFamilyName={patient?.family_name || ''} isPrivate={isPrivate} setIsPrivate={setIsPrivate} onConfirm={handleChartModalConfirm} onCancel={() => setShowChartModal(false)} loading={patientsLoading} />

      {/* History Modal */}
      <PatientHistoryModal isOpen={showHistoryModal} onClose={() => setShowHistoryModal(false)} history={patientHistory} patientName={`${patient?.name || ''} ${patient?.family_name || ''}`} currentUserId={user?.id ? parseInt(user.id) : undefined} metadata={historyMetadata || undefined} />

      {/* Share Modal */}
      <ShareMedicalRecordModal isOpen={showShareModal} onClose={() => setShowShareModal(false)} patientId={patient?.id || ''} patientName={`${patient?.name || ''} ${patient?.family_name || ''}`} />

      {/* Prescription Preview Modal */}
      <PrescriptionPreviewModal
        isOpen={showPrescriptionPreview}
        onClose={() => { setShowPrescriptionPreview(false); setPreviewPrescription(null); }}
        prescription={previewPrescription}
        patientName={patient?.name}
        patientFamilyName={patient?.family_name}
      />

      {/* Access Confirmation Modal */}
      {showAccessConfirmation && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-amber-500 to-orange-600 px-6 py-5">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-full">
                  <ExclamationTriangleIcon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    {t('patients.accessConfirmation.title') || 'Confirmation d\'accès'}
                  </h2>
                  <p className="text-sm text-white/80">
                    {t('patients.accessConfirmation.subtitle') || 'Vérification requise'}
                  </p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
                  {t('patients.accessConfirmation.warning') || 'Vous ne pouvez consulter ce dossier médical que si le patient est physiquement présent avec vous. L\'accès non autorisé aux dossiers médicaux est une violation de la confidentialité.'}
                </p>
              </div>

              {/* Checkbox */}
              <label className="flex items-start gap-3 cursor-pointer group">
                <div className="relative flex-shrink-0 mt-0.5">
                  <input
                    type="checkbox"
                    checked={patientPresentCheckbox}
                    onChange={(e) => setPatientPresentCheckbox(e.target.checked)}
                    className="sr-only"
                  />
                  <div className={`w-5 h-5 border-2 rounded transition-all ${patientPresentCheckbox ? 'bg-green-600 border-green-600' : 'border-gray-300 dark:border-gray-600 group-hover:border-green-500'}`}>
                    {patientPresentCheckbox && (
                      <svg className="w-full h-full text-white p-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </div>
                </div>
                <span className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                  {t('patients.accessConfirmation.checkbox') || 'Je confirme que le patient est présent avec moi et que j\'ai son consentement pour accéder à son dossier médical.'}
                </span>
              </label>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
              <button
                onClick={handleAccessCancel}
                className="flex-1 px-4 py-2.5 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
              >
                {t('common.cancel') || 'Annuler'}
              </button>
              <button
                onClick={handleAccessConfirm}
                disabled={!patientPresentCheckbox}
                className={`flex-1 px-4 py-2.5 font-medium rounded-xl transition-colors ${patientPresentCheckbox ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'}`}
              >
                {t('patients.accessConfirmation.confirm') || 'Confirmer l\'accès'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Privacy Choice Popup - shown after access confirmation if patient is private by another doctor */}
      {showPrivacyChoicePopup && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" />
          <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 px-6 py-5">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/20 rounded-full">
                  <LockClosedIcon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Choix de confidentialité
                  </h2>
                  <p className="text-sm text-white/80">
                    Ce dossier est marqué privé
                  </p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
                <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
                  C'est un <strong>nouveau patient</strong> pour vous.
                  Comment souhaitez-vous gérer la confidentialité de ce dossier ?
                </p>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => handlePrivacyChoice('private')}
                  className="w-full flex items-center gap-4 p-4 border-2 border-amber-200 dark:border-amber-700 rounded-xl hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors"
                >
                  <div className="p-2 bg-amber-100 dark:bg-amber-900/30 rounded-full">
                    <LockClosedIcon className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900 dark:text-white">Privé</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Dossier confidentiel - étiquette "Privé" visible</p>
                  </div>
                </button>

                <button
                  onClick={() => handlePrivacyChoice('shared')}
                  className="w-full flex items-center gap-4 p-4 border-2 border-green-200 dark:border-green-700 rounded-xl hover:bg-green-50 dark:hover:bg-green-900/20 transition-colors"
                >
                  <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
                    <ShareIcon className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900 dark:text-white">Partagé</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Dossier standard - pas d'étiquette "Privé"</p>
                  </div>
                </button>
              </div>
            </div>

            {/* Footer with cancel button */}
            <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={handleAccessCancel}
                className="w-full px-4 py-2.5 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
          <div className="fixed inset-0 bg-black bg-opacity-75" onClick={() => setShowInvoiceModal(false)}></div>
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative bg-white dark:bg-gray-800 rounded-lg shadow-xl sm:max-w-4xl sm:w-full">
              <div className="px-6 py-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-100">
                    <BanknotesIcon className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t('invoice.title')}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{t('invoice.subtitle')}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Left: Custom Items */}
                  <div className="space-y-4">
                    <div className="bg-gray-50 dark:bg-gray-700/30 p-4 rounded-xl">
                      <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-3 flex items-center gap-2">
                        <PlusIcon className="w-4 h-4 text-emerald-600" />
                        {t('invoice.addCustomItem')}
                      </h4>
                      <div className="flex gap-3 items-end">
                        <div className="flex-1">
                          <input
                            type="text"
                            placeholder={t('invoice.label')}
                            value={newItemLabel}
                            onChange={(e) => setNewItemLabel(e.target.value)}
                            className="w-full rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm"
                          />
                        </div>
                        <div className="w-28">
                          <input
                            type="number"
                            placeholder="0"
                            value={newItemPrice}
                            onChange={(e) => setNewItemPrice(e.target.value)}
                            className="w-full rounded-lg border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm"
                          />
                        </div>
                        <button type="button" onClick={() => {
                          if (newItemLabel && newItemPrice) {
                            setCustomItems(prev => [...prev, { label: newItemLabel, price: newItemPrice }]);
                            setNewItemLabel('');
                            setNewItemPrice('');
                          }
                        }} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700">
                          <PlusIcon className="w-5 h-5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      <h4 className="font-semibold text-gray-900 dark:text-white text-sm">{t('invoice.invoiceDetail')}</h4>
                      {selectedTarificationIds.map(id => {
                        const tarif = tarifications.find(t => t.id === id);
                        if (!tarif) return null;
                        return (
                          <div key={`t-${id}`} className="flex items-center justify-between p-3 bg-white dark:bg-gray-700/50 rounded-lg border border-gray-100 dark:border-gray-700">
                            <div><p className="font-medium text-gray-800 dark:text-gray-200 text-sm">{tarif.service_label}</p><span className="text-xs text-blue-600">Tarification</span></div>
                            <div className="flex items-center gap-4">
                              <span className="font-bold text-gray-900 dark:text-white">{Number(tarif.price).toLocaleString('fr-DZ')} DA</span>
                              <button onClick={() => setSelectedTarificationIds(prev => prev.filter(tid => tid !== id))} className="text-gray-400 hover:text-red-500"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                          </div>
                        );
                      })}
                      {customItems.map((item, index) => (
                        <div key={`c-${index}`} className="flex items-center justify-between p-3 bg-white dark:bg-gray-700/50 rounded-lg border border-gray-100 dark:border-gray-700">
                          <div><p className="font-medium text-gray-800 dark:text-gray-200 text-sm">{item.label}</p><span className="text-xs text-amber-600">Personnalisé</span></div>
                          <div className="flex items-center gap-4">
                            <span className="font-bold text-gray-900 dark:text-white">{Number(item.price).toLocaleString('fr-DZ')} DA</span>
                            <button onClick={() => setCustomItems(prev => prev.filter((_, i) => i !== index))} className="text-gray-400 hover:text-red-500"><TrashIcon className="w-4 h-4" /></button>
                          </div>
                        </div>
                      ))}
                      {selectedTarificationIds.length === 0 && customItems.length === 0 && (
                        <div className="text-center py-8 text-gray-400 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-lg">
                          <DocumentTextIcon className="w-8 h-8 mx-auto mb-2 opacity-40" />
                          <p className="text-sm">{t('invoice.noItems')}</p>
                        </div>
                      )}
                    </div>

                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-gray-800 dark:text-gray-200">{t('invoice.netAmount')}</span>
                        <span className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">{calculatedTotal.toLocaleString('fr-DZ')} DA</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Tarifications */}
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-3 flex items-center gap-2">
                      <UserCircleIcon className="w-4 h-4 text-blue-600" />
                      {t('invoice.availableTarifications')}
                    </h4>
                    <div className="space-y-2 max-h-80 overflow-y-auto bg-gray-50 dark:bg-gray-800/50 p-3 rounded-xl">
                      {tarifications.length > 0 ? (
                        tarifications.map(tarif => (
                          <label key={tarif.id} className={`flex items-center justify-between p-3 rounded-lg cursor-pointer border-2 ${selectedTarificationIds.includes(tarif.id) ? 'bg-blue-50 border-blue-500 dark:bg-blue-900/20' : 'bg-white border-transparent hover:border-gray-200 dark:bg-gray-700'}`}>
                            <div className="flex items-center gap-3">
                              <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" checked={selectedTarificationIds.includes(tarif.id)} onChange={(e) => {
                                if (e.target.checked) setSelectedTarificationIds(prev => [...prev, tarif.id]);
                                else setSelectedTarificationIds(prev => prev.filter(id => id !== tarif.id));
                              }} />
                              <span className="font-medium text-gray-700 dark:text-gray-300">{tarif.service_label}</span>
                            </div>
                            <span className="font-bold text-gray-900 dark:text-white">{Number(tarif.price).toLocaleString('fr-DZ')} DA</span>
                          </label>
                        ))
                      ) : (
                        <div className="text-center py-8 text-gray-500">
                          <UserCircleIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                          <p>{t('invoice.noTarifications')}</p>
                          <Link href="/profile" className="text-blue-600 hover:underline text-sm">{t('invoice.configureProfile')}</Link>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700/50 px-6 py-4 flex flex-row-reverse gap-3 rounded-b-lg">
                <button type="button" disabled={creatingInvoice || calculatedTotal < 0} onClick={handleCreateInvoice} className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 disabled:opacity-50">
                  {creatingInvoice ? <><div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div> Création...</> : <><BanknotesIcon className="w-5 h-5" /> {t('invoice.confirm')}</>}
                </button>
                <button type="button" onClick={() => setShowInvoiceModal(false)} className="px-6 py-3 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-300 font-semibold rounded-xl ring-1 ring-gray-300 dark:ring-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700">
                  {t('invoice.cancel')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && selectedInvoiceForPayment && (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
          <div className="fixed inset-0 bg-black bg-opacity-75" onClick={() => setShowPaymentModal(false)}></div>
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-5">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-full">
                    <BanknotesIcon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">Encaisser un paiement</h2>
                    <p className="text-sm text-white/80">Facture #{selectedInvoiceForPayment.id}</p>
                  </div>
                </div>
              </div>

              <div className="p-6">
                {/* Invoice Summary */}
                <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Total facture</span>
                    <span className="font-bold text-gray-900 dark:text-white">{parseFloat(selectedInvoiceForPayment.total_price).toLocaleString('fr-DZ')} DA</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Déjà payé</span>
                    <span className="font-medium text-green-600 dark:text-green-400">{parseFloat(selectedInvoiceForPayment.amount_paid || '0').toLocaleString('fr-DZ')} DA</span>
                  </div>
                  <div className="flex justify-between text-sm pt-2 border-t border-gray-200 dark:border-gray-600">
                    <span className="text-gray-700 dark:text-gray-300 font-medium">Reste à payer</span>
                    <span className="font-bold text-red-600 dark:text-red-400">
                      {(parseFloat(selectedInvoiceForPayment.total_price) - parseFloat(selectedInvoiceForPayment.amount_paid || '0')).toLocaleString('fr-DZ')} DA
                    </span>
                  </div>
                </div>

                {/* Payment Amount Input */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Montant reçu (DA)
                  </label>
                  <input
                    type="number"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    placeholder="Entrez le montant..."
                    className="w-full px-4 py-3 text-lg font-bold border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    min="0"
                    step="0.01"
                  />
                  <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                    Vous pouvez encaisser un montant partiel ou le total restant
                  </p>
                </div>

                {/* Quick Amount Button */}
                <div className="mb-6">
                  <button
                    type="button"
                    onClick={() => setPaymentAmount((parseFloat(selectedInvoiceForPayment.total_price) - parseFloat(selectedInvoiceForPayment.amount_paid || '0')).toString())}
                    className="w-full px-4 py-3 text-sm font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-lg hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors"
                  >
                    Payer la totalité ({(parseFloat(selectedInvoiceForPayment.total_price) - parseFloat(selectedInvoiceForPayment.amount_paid || '0')).toLocaleString('fr-DZ')} DA)
                  </button>
                </div>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                <button
                  onClick={() => { setShowPaymentModal(false); setSelectedInvoiceForPayment(null); setPaymentAmount(''); }}
                  className="flex-1 px-4 py-3 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                >
                  Annuler
                </button>
                <button
                  onClick={handleAddPayment}
                  disabled={processingPayment || !paymentAmount || parseFloat(paymentAmount) <= 0}
                  className="flex-1 px-4 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                >
                  {processingPayment ? (
                    <><div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div> Enregistrement...</>
                  ) : (
                    <><BanknotesIcon className="w-5 h-5" /> Encaisser</>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* NIN Popup */}
      {showNinPopup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[70] p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
            <div className="bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-4">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <ExclamationTriangleIcon className="w-6 h-6" />
                NIN manquant
              </h3>
            </div>
            <div className="p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UserIcon className="w-8 h-8 text-amber-600 dark:text-amber-400" />
                </div>
                <p className="text-gray-700 dark:text-gray-300 mb-2">Le patient <strong>{patient?.name} {patient?.family_name}</strong> n'a pas de NIN.</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Le NIN est important pour centraliser les données médicales.</p>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Numéro d'Identification National (NIN)</label>
                <input type="text" value={ninInput} onChange={(e) => setNinInput(e.target.value)} placeholder="Entrez le NIN..." className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => { setShowNinPopup(false); setNinInput(''); }} className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 font-medium">
                  Prochaine fois
                </button>
                <button
                  onClick={async () => {
                    if (!ninInput.trim()) { alert('Veuillez entrer un NIN valide'); return; }
                    setSavingNin(true);
                    try {
                      const response = await axios.put(`${API_URL}/patient/${params.id}`, { nin: ninInput.trim() }, { withCredentials: true });
                      if (response.data.success) {
                        setPatient(prev => prev ? { ...prev, nin: ninInput.trim() } : null);
                        setShowNinPopup(false); setNinInput('');
                        localStorage.removeItem(`nin_popup_${params.id}`);
                      }
                    } catch { alert('Erreur lors de l\'enregistrement'); } finally { setSavingNin(false); }
                  }}
                  disabled={savingNin || !ninInput.trim()}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-lg hover:from-amber-600 hover:to-orange-600 disabled:opacity-50 font-medium"
                >
                  {savingNin ? 'Enregistrement...' : 'Enregistrer le NIN'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Payment Modal */}
      {showGlobalPaymentModal && (
        <div className="fixed inset-0 z-[70] overflow-y-auto">
          <div className="fixed inset-0 bg-black bg-opacity-75" onClick={() => setShowGlobalPaymentModal(false)}></div>
          <div className="flex min-h-full items-center justify-center p-4">
            <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-5">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-white/20 rounded-full">
                    <BanknotesIcon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">Encaisser un montant global</h2>
                    <p className="text-sm text-white/80">{patient?.name} {patient?.family_name}</p>
                  </div>
                </div>
              </div>

              <div className="p-6">
                {/* Summary */}
                <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Total impayé</span>
                    <span className="font-bold text-red-600 dark:text-red-400">
                      {invoices.filter(inv => inv.status !== 'paid' && inv.status !== 'free').reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0).toLocaleString('fr-DZ')} DA
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Nombre de factures</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {invoices.filter(inv => inv.status !== 'paid' && inv.status !== 'free').length}
                    </span>
                  </div>
                </div>

                {/* Amount Input */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Montant reçu (DA)
                  </label>
                  <input
                    type="number"
                    value={globalPaymentAmount}
                    onChange={(e) => setGlobalPaymentAmount(e.target.value)}
                    placeholder="Entrez le montant..."
                    className="w-full px-4 py-3 text-lg font-bold border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    min="0"
                    step="0.01"
                  />
                </div>

                {/* Quick Amount Button */}
                <button
                  type="button"
                  onClick={() => {
                    const totalUnpaid = invoices.filter(inv => inv.status !== 'paid' && inv.status !== 'free').reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0);
                    setGlobalPaymentAmount(totalUnpaid.toString());
                  }}
                  className="w-full mb-4 px-4 py-3 text-sm font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-lg hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors"
                >
                  Payer la totalité ({invoices.filter(inv => inv.status !== 'paid' && inv.status !== 'free').reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0).toLocaleString('fr-DZ')} DA)
                </button>

                {/* Info */}
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                  Le montant sera réparti automatiquement sur les factures les plus anciennes en priorité.
                </p>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                <button
                  onClick={() => { setShowGlobalPaymentModal(false); setGlobalPaymentAmount(''); }}
                  className="flex-1 px-4 py-3 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                >
                  Annuler
                </button>
                <button
                  onClick={handleDistributePayment}
                  disabled={isDistributing || !globalPaymentAmount || parseFloat(globalPaymentAmount) <= 0}
                  className="flex-1 px-4 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                >
                  {isDistributing ? (
                    <><div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div> Traitement...</>
                  ) : (
                    <><BanknotesIcon className="w-5 h-5" /> Encaisser</>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
