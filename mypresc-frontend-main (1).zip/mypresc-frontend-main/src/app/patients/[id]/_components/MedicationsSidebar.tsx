'use client';

import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

interface MedItem {
    prescription_medication_id: number;
    nom_de_marque: string | null;
    dci: string | null;
    med_dosage: string | null;
    forme: string | null;
    quantity: number;
    dosage: string;
    note: string | null;
}

interface MedsData {
    current: MedItem[];
    history: MedItem[];
    latestPrescriptionDate?: string;
    prescriptionCount: number;
}

interface MedicationsSidebarProps {
    patientId: string;
    isVisible: boolean;
    refreshKey?: number;
}

function formatDate(d: string | null | undefined): string | null {
    if (!d) return null;
    try { return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
    catch { return d; }
}

export function MedicationsSidebar({ patientId, isVisible, refreshKey }: MedicationsSidebarProps) {
    const [medsData, setMedsData] = useState<MedsData | null>(null);
    const [loading, setLoading] = useState(true);
    const [collapsed, setCollapsed] = useState(false);

    const loadMedications = useCallback(() => {
        setLoading(true);
        axios.get(`${API_URL}/patient/${patientId}/medications`, { withCredentials: true })
            .then((res: any) => {
                setMedsData(res.data?.success ? res.data.data : null);
                setLoading(false);
            })
            .catch(() => { setMedsData(null); setLoading(false); });
    }, [patientId]);

    useEffect(() => { loadMedications(); }, [loadMedications, refreshKey]);

    if (!isVisible) return null;

    const hasMeds = medsData && medsData.current.length > 0;

    return (
        <div className="hidden xl:block w-64 flex-shrink-0">
            <div className="sticky top-24">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
                    {/* Header */}
                    <button
                        onClick={() => setCollapsed(!collapsed)}
                        className="w-full flex items-center justify-between px-4 py-3 bg-emerald-50 dark:bg-emerald-900/20 border-b border-emerald-100 dark:border-emerald-800/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors"
                    >
                        <div className="flex items-center gap-2">
                            <svg className="w-4 h-4 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />
                            </svg>
                            <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wide">Traitement</span>
                            {hasMeds && (
                                <span className="text-[10px] bg-emerald-200 dark:bg-emerald-800 text-emerald-800 dark:text-emerald-200 rounded-full px-1.5 py-0.5 font-medium">
                                    {medsData.current.length}
                                </span>
                            )}
                        </div>
                        <svg
                            className={`w-3.5 h-3.5 text-emerald-500 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`}
                            fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
                        >
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>

                    {/* Content */}
                    {!collapsed && (
                        <div className="p-3">
                            {loading ? (
                                <div className="space-y-2">
                                    {[1, 2, 3].map(i => (
                                        <div key={i} className="h-10 bg-gray-100 dark:bg-gray-700 rounded-lg animate-pulse" />
                                    ))}
                                </div>
                            ) : !hasMeds ? (
                                <div className="text-center py-4">
                                    <svg className="w-8 h-8 text-gray-300 dark:text-gray-600 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />
                                    </svg>
                                    <p className="text-[11px] text-gray-400 dark:text-gray-500">Aucun traitement</p>
                                </div>
                            ) : (
                                <>
                                    {medsData.latestPrescriptionDate && (
                                        <p className="text-[10px] text-gray-400 dark:text-gray-500 mb-2 text-center">
                                            Derni\u00e8re ordonnance : {formatDate(medsData.latestPrescriptionDate)}
                                        </p>
                                    )}
                                    <div className="space-y-1.5 max-h-[calc(100vh-200px)] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-emerald-200 dark:scrollbar-thumb-emerald-800">
                                        {medsData.current.map((med: MedItem) => (
                                            <div
                                                key={med.prescription_medication_id}
                                                className="group flex items-start gap-2 rounded-lg px-2.5 py-2 hover:bg-emerald-50 dark:hover:bg-emerald-900/10 transition-colors border border-transparent hover:border-emerald-100 dark:hover:border-emerald-800/20"
                                            >
                                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0 mt-1.5" />
                                                <div className="min-w-0 flex-1">
                                                    <p className="text-[11px] font-semibold text-gray-800 dark:text-gray-200 leading-tight truncate">
                                                        {med.nom_de_marque || med.dci || 'M\u00e9dicament'}
                                                    </p>
                                                    {(med.med_dosage || med.forme) && (
                                                        <p className="text-[10px] text-gray-400 dark:text-gray-500 truncate leading-tight">
                                                            {[med.med_dosage, med.forme].filter(Boolean).join(' \u00b7 ')}
                                                        </p>
                                                    )}
                                                    {med.dosage && (
                                                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium leading-tight mt-0.5">
                                                            {med.dosage}
                                                        </p>
                                                    )}
                                                </div>
                                                {med.quantity > 0 && (
                                                    <span className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 flex-shrink-0 bg-emerald-50 dark:bg-emerald-900/20 rounded px-1 py-0.5">
                                                        x{med.quantity}
                                                    </span>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                    {medsData.prescriptionCount > 1 && (
                                        <p className="text-[10px] text-gray-400 dark:text-gray-500 text-center mt-2 pt-2 border-t border-gray-100 dark:border-gray-700">
                                            {medsData.prescriptionCount} ordonnance{medsData.prescriptionCount > 1 ? 's' : ''} au total
                                        </p>
                                    )}
                                </>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
