'use client';

import React, { useState } from 'react';
import { OpticalCorrectionList } from '@/features/prescriptions/components/OpticalCorrectionList';
import { CreateOpticalCorrectionModal } from '@/features/prescriptions/components/modals/CreateOpticalCorrectionModal';
import { OphthoReportList } from '@/features/ophthalmology/components/OphthoReportList';
import { OphthoUploadModal } from '@/features/ophthalmology/components/OphthoUploadModal';
import { Eye, Plus, Upload } from 'lucide-react';

type Tab = 'ordonnance' | 'bilan';

interface OpticalCorrectionsSectionProps {
    patientId: string;
    patientName?: string;
    patientFamilyName?: string;
    patientDateNaissance?: string;
    patientGenre?: string;
    isVisible: boolean;
    currentUserId?: number;
}

export function OpticalCorrectionsSection({ 
    patientId, 
    patientName,
    patientFamilyName,
    patientDateNaissance,
    patientGenre,
    isVisible,
    currentUserId,
}: OpticalCorrectionsSectionProps) {
    const [tab,             setTab]             = useState<Tab>('ordonnance');
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showUploadModal, setShowUploadModal] = useState(false);
    const [refreshManual,   setRefreshManual]   = useState(0);
    const [refreshImported, setRefreshImported] = useState(0);

    if (!isVisible) return null;

    return (
        <div className="mb-6 hidden md:block">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-sm transition-colors">

                {/* ── Header ─────────────────────────────────────────────── */}
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                        <span className="p-1.5 bg-blue-100 dark:bg-blue-900/30 rounded-lg text-blue-600 dark:text-blue-500">
                            <Eye className="w-5 h-5" />
                        </span>
                        Correction Optique
                    </h2>

                    {/* Action button — contextual to active tab */}
                    {tab === 'ordonnance' ? (
                        <button
                            onClick={() => setShowCreateModal(true)}
                            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                        >
                            <Plus className="w-4 h-4" />
                            Nouvelle
                        </button>
                    ) : (
                        <button
                            onClick={() => setShowUploadModal(true)}
                            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-sky-700 bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 dark:bg-sky-900/20 dark:border-sky-700 dark:text-sky-400 dark:hover:bg-sky-900/30 transition-colors"
                        >
                            <Upload className="w-4 h-4" />
                            Importer XML
                        </button>
                    )}
                </div>

                {/* ── Tab pill toggler ────────────────────────────────────── */}
                <div className="flex gap-1 p-1 bg-gray-100 dark:bg-gray-700/50 rounded-xl w-fit mb-5">
                    {([
                        { key: 'ordonnance', label: 'Ordonnance' },
                        { key: 'bilan',      label: 'Bilan machine' },
                    ] as { key: Tab; label: string }[]).map(t => (
                        <button
                            key={t.key}
                            onClick={() => setTab(t.key)}
                            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                                tab === t.key
                                    ? 'bg-white dark:bg-gray-800 text-blue-700 dark:text-blue-400 shadow-sm'
                                    : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                            }`}
                        >
                            {t.label}
                        </button>
                    ))}
                </div>

                {/* ── Tab content ─────────────────────────────────────────── */}
                {tab === 'ordonnance' ? (
                    <OpticalCorrectionList
                        patientId={patientId}
                        refreshTrigger={refreshManual}
                    />
                ) : (
                    <OphthoReportList
                        patientId={patientId}
                        refreshTrigger={refreshImported}
                        currentUserId={currentUserId}
                    />
                )}
            </div>

            {/* Modals */}
            {showCreateModal && (
                <CreateOpticalCorrectionModal
                    isOpen={showCreateModal}
                    onClose={() => setShowCreateModal(false)}
                    patientId={patientId}
                    patientName={patientName}
                    patientFamilyName={patientFamilyName}
                    patientDateNaissance={patientDateNaissance}
                    patientGenre={patientGenre}
                    onSuccess={() => {
                        setRefreshManual(p => p + 1);
                        setShowCreateModal(false);
                    }}
                />
            )}

            {showUploadModal && (
                <OphthoUploadModal
                    isOpen={showUploadModal}
                    onClose={() => setShowUploadModal(false)}
                    patientId={patientId}
                    onSuccess={() => {
                        setRefreshImported(p => p + 1);
                        setShowUploadModal(false);
                    }}
                />
            )}
        </div>
    );
}

export default OpticalCorrectionsSection;
