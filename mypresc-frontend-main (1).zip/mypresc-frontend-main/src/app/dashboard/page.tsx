"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import {
  CalendarDaysIcon,
  UsersIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/outline";
import { useAppointmentsContext } from "@/contexts/AppointmentContext";
import { useWaitingRoom } from "@/contexts/WaitingRoomContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";

// Feature imports
import {
  useDashboardStats,
  StatsCard,
  DashboardHeader,
  DoctorChartsSection,
  AppointmentsModal,
  CallPatientPopup,
  NoPatientPopup,
} from "@/features/dashboard";

// Skeleton components
const ListSkeleton = () => (
  <div className="animate-pulse space-y-3 min-h-[280px]">
    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
    {[1, 2, 3].map((i) => (
      <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
    ))}
  </div>
);

const ChartSkeleton = () => (
  <div className="animate-pulse min-h-[320px]">
    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>
    <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
  </div>
);

// Lazy load heavy components
const UpcomingAppointments = dynamic(
  () => import("@/components/dashboard/UpcomingAppointments"),
  { loading: () => <ListSkeleton />, ssr: false }
);

const RecentPatients = dynamic(
  () => import("@/components/dashboard/RecentPatients"),
  { loading: () => <ListSkeleton />, ssr: false }
);

const DailyInvoices = dynamic(
  () => import("@/components/dashboard/DailyInvoices"),
  { loading: () => <ChartSkeleton />, ssr: false }
);

const WaitingEntriesModal = dynamic(
  () => import("@/components/dashboard/WaitingEntriesModal"),
  { ssr: false }
);

export default function DashboardPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  const { fetchAppointments } = useAppointmentsContext();
  const { fetchEntries, peekNextPatient, callNextPatient } = useWaitingRoom();

  // Dashboard stats from React Query hook
  const { stats, todayAppointments, isLoading } = useDashboardStats(user?.id);

  // Modal states
  const [appointmentsModalOpen, setAppointmentsModalOpen] = useState<'all' | 'today' | 'completed' | null>(null);
  const [waitingModalOpen, setWaitingModalOpen] = useState(false);

  // Call patient states
  const [pendingPatient, setPendingPatient] = useState<{ patientName: string } | null>(null);
  const [showNoPatientMessage, setShowNoPatientMessage] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);


  // Fetch context data on mount only
  useEffect(() => {
    if (!user?.id) return;
    fetchEntries(user.id, 50, 0);
    fetchAppointments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // Handle next patient click
  const handleNextPatientClick = useCallback(async () => {
    if (!user?.id) return;
    const result = await peekNextPatient(user.id);
    if (result) {
      setPendingPatient({ patientName: result.patientName });
    } else {
      setShowNoPatientMessage(true);
      setTimeout(() => setShowNoPatientMessage(false), 3000);
    }
  }, [user?.id, peekNextPatient]);

  // Handle confirm call patient
  const handleConfirmCallPatient = useCallback(async () => {
    if (!user?.id) return;
    setIsConfirming(true);
    const result = await callNextPatient(user.id);
    if (result) {
      await fetchAppointments();
      if (result.patientId) {
        router.push(`/patients/${result.patientId}`);
      }
    }
    setIsConfirming(false);
    setPendingPatient(null);
  }, [user?.id, callNextPatient, fetchAppointments, router]);

  return (
    <div className="flex min-h-screen">
      <div
        className="flex-1 min-w-0"
      >
        <div className="p-4 pt-6 sm:p-6 lg:p-8">
          <DashboardHeader
            userRole={user?.role}
            onNextPatientClick={handleNextPatientClick}
          />

          {/* Stats Cards */}
          <div className="grid grid-cols-1 gap-6 mb-6 sm:grid-cols-2 lg:grid-cols-3">
            <StatsCard
              title={t('dashboard.totalAppointments')}
              value={stats?.totalAppointments ?? 0}
              icon={<CalendarDaysIcon className="w-6 h-6 text-blue-500" />}
              onClick={() => setAppointmentsModalOpen('all')}
              isLoading={isLoading}
            />
            <StatsCard
              title={t('dashboard.completedAppointments') || 'RDV effectués'}
              value={stats?.completedAppointments ?? 0}
              icon={<CheckCircleIcon className="w-6 h-6 text-green-500" />}
              onClick={() => setAppointmentsModalOpen('completed')}
              isLoading={isLoading}
            />
            <StatsCard
              title={t('dashboard.waitingPatients')}
              value={stats?.waitingPatients ?? 0}
              icon={<UsersIcon className="w-6 h-6 text-green-500" />}
              onClick={() => setWaitingModalOpen(true)}
              isLoading={isLoading}
            />
          </div>

          {/* Charts Section */}
          {user?.role === 'doctor' && <DoctorChartsSection />}
          {user?.role === 'assistant' && <DailyInvoices />}

          {/* Lists Section */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 h-full">
              <UpcomingAppointments />
            </div>
            <div>
              <RecentPatients />
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AppointmentsModal
        isOpen={appointmentsModalOpen}
        onClose={() => setAppointmentsModalOpen(null)}
        appointments={todayAppointments}
      />

      <WaitingEntriesModal
        isOpen={waitingModalOpen}
        onClose={() => setWaitingModalOpen(false)}
      />

      <CallPatientPopup
        isOpen={!!pendingPatient}
        patientName={pendingPatient?.patientName || ''}
        isConfirming={isConfirming}
        onCancel={() => setPendingPatient(null)}
        onConfirm={handleConfirmCallPatient}
      />

      <NoPatientPopup
        isOpen={showNoPatientMessage}
        onClose={() => setShowNoPatientMessage(false)}
      />
    </div>
  );
}
