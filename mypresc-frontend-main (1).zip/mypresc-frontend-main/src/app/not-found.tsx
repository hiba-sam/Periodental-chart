'use client';

import Link from 'next/link';
import { useLanguage } from '@/contexts/LanguageContext';
import { HomeIcon } from '@heroicons/react/24/outline';
import { useEffect, useState } from 'react';

export default function NotFound() {
    const { t } = useLanguage();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return null;

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900 p-4">
            <div className="text-center max-w-md w-full">
                <div className="mb-8 flex justify-center">
                    <h1 className="text-9xl font-bold text-primary dark:text-blue-500">404</h1>
                </div>

                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    {t('notFound.title')}
                </h2>

                <p className="text-gray-600 dark:text-gray-300 mb-8">
                    {t('notFound.description')}
                </p>

                <Link
                    href="/"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-primary hover:bg-primary/90 text-white rounded-xl transition-all shadow-lg hover:shadow-primary/30 transform hover:-translate-y-0.5"
                >
                    <HomeIcon className="w-5 h-5" />
                    <span>{t('notFound.backHome')}</span>
                </Link>
            </div>
        </div>
    );
}
