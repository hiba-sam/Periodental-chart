'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useMessaging } from '@/features/messages';
import MessageThread from '@/features/messages/components/MessageThread';
import MessageInput from '@/features/messages/components/MessageInput';
import UserSearch from '@/features/messages/components/UserSearch';
import ConversationList from '@/features/messages/components/ConversationList';
import PresenceBadge from '@/features/messages/components/PresenceBadge';
import { ArrowLeft, MoreVertical } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

function ConversationPageContent() {
  const params = useParams();
  const router = useRouter();
  const { conversations, resetUnread, refreshConversations } = useMessaging();
  const conversationId = parseInt(params.id as string);
  const [currentUserId, setCurrentUserId] = useState<number | null>(null);
  const { t, isRTL } = useLanguage();

  // Get current conversation
  const conversation = conversations.find(c => c.id === conversationId);

  // Mark conversation as read when opening
  useEffect(() => {
    if (conversationId && !isNaN(conversationId)) {
      // Update local state immediately
      resetUnread(conversationId);

      // Call backend API to mark messages as read, then refresh
      const markAsRead = async () => {
        try {
          const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';
          console.log(`[Frontend] Calling markAsRead API for conversation ${conversationId}`);
          const response = await fetch(`${API_URL}/messaging/conversations/${conversationId}/read`, {
            method: 'POST',
            credentials: 'include',
          });

          const data = await response.json();
          console.log(`[Frontend] markAsRead response:`, response.status, data);

          if (response.ok) {
            // Refresh conversations to sync with backend
            console.log(`[Frontend] Refreshing conversations...`);
            refreshConversations();
          }
        } catch (error) {
          console.error('Failed to mark messages as read:', error);
        }
      };
      markAsRead();
    }
  }, [conversationId, resetUnread, refreshConversations]);

  // Get current user ID from API (cookies-based auth)
  useEffect(() => {
    const getUserId = async () => {
      try {
        const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';
        const res = await fetch(`${API_URL}/auth`, {
          credentials: 'include',
        });

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.data?.id) {
            setCurrentUserId(data.data.id);
          }
        }
      } catch (error) {
        console.error('Failed to get user ID:', error);
      }
    };

    getUserId();
  }, []);

  if (!currentUserId) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-gray-500">{t('messages.loading')}</div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Main Content with Sidebar spacing */}
      <div className="flex-1 ml-[100px] transition-all duration-300">
        <div className="h-screen flex overflow-hidden">
          {/* Conversations Panel - Hidden on mobile */}
          <div className="hidden md:flex w-96 lg:w-[420px] border-r border-gray-200 bg-white flex-col">
            {/* Search */}
            <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-purple-50">
              <UserSearch />
            </div>

            {/* Conversation List */}
            <div className="flex-1 overflow-y-auto">
              <ConversationList />
            </div>
          </div>

          {/* Main Conversation Area */}
          <div className="flex-1 flex flex-col bg-white">
            {/* Conversation Header */}
            <div className="border-b border-gray-200 bg-white px-6 py-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Back button for mobile */}
                  <button
                    onClick={() => router.push('/messages')}
                    className="md:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <ArrowLeft className={`w-5 h-5 text-gray-600 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Avatar with gradient */}
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-lg shadow-md">
                      {conversation?.other_user_name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    {conversation && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                    )}
                  </div>

                  {/* Name and status */}
                  <div>
                    <h2 className="font-bold text-gray-900 text-lg">
                      {conversation?.other_user_name || t('messages.loading')}
                    </h2>
                    {conversation && (
                      <div className="flex items-center gap-2 text-sm">
                        <PresenceBadge userId={conversation.other_user_id} />
                        <span className="text-gray-500">• {conversation.other_user_name?.split(' ')[0]}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* More options */}
                <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors group">
                  <MoreVertical className="w-5 h-5 text-gray-400 group-hover:text-gray-600" />
                </button>
              </div>
            </div>

            {/* Messages Thread with gradient background */}
            <div className="flex-1 min-h-0 bg-gradient-to-br from-gray-50 via-blue-50/20 to-purple-50/20">
              <MessageThread
                conversationId={conversationId}
                currentUserId={currentUserId}
              />
            </div>

            {/* Message Input with shadow */}
            <div className="border-t border-gray-200 bg-white shadow-lg">
              <MessageInput conversationId={conversationId} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ConversationPage() {
  return <ConversationPageContent />;
}
