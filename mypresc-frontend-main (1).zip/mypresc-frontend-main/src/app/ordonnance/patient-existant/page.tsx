'use client';

import { useState, useEffect } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import Link from 'next/link';
import { ArrowLeftIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { usePatients } from '@/contexts/PatientsContext';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/contexts/LanguageContext';


// Fonction pour formater le numéro de téléphone
function formatPhoneNumber(phoneNumber?: string): string {
  if (!phoneNumber) return '';

  // Supprimer tous les caractères non numériques
  const cleaned = phoneNumber.replace(/\D/g, '');

  // Formater le numéro avec des espaces tous les 2 chiffres
  const match = cleaned.match(/^(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);
  if (match) {
    return `${match[1]} ${match[2]} ${match[3]} ${match[4]} ${match[5]}`;
  }

  return phoneNumber;
}

// Fonction pour formater la date de façon sécurisée
function formatDate(dateStr?: string | Date | any): string {
  if (!dateStr) return 'Première consultation';

  let dateObj: Date;

  try {
    // Si c'est déjà un objet Date
    if (dateStr instanceof Date) {
      dateObj = dateStr;
    }
    // Si c'est une chaîne ISO
    else if (typeof dateStr === 'string') {
      dateObj = new Date(dateStr);
    }
    // Si c'est un objet avec des propriétés de date
    else if (typeof dateStr === 'object' && dateStr !== null) {
      // Vérifier si c'est un timestamp Firestore
      if ('seconds' in dateStr) {
        dateObj = new Date(dateStr.seconds * 1000);
      }
      // Vérifier si c'est un objet Date sérialisé
      else if ('toDate' in dateStr && typeof dateStr.toDate === 'function') {
        dateObj = dateStr.toDate();
      }
      else {
        dateObj = new Date(dateStr);
      }
    }
    else {
      dateObj = new Date(dateStr);
    }

    // Vérifier si la date est valide
    if (isNaN(dateObj.getTime())) {
      return 'Première consultation';
    }

    // Vérifier si c'est une date par défaut (1970 ou 1972)
    const year = dateObj.getFullYear();
    if (year === 1970 || year === 1972) {
      return 'Première consultation';
    }

    // Retourner la date formatée en français
    return dateObj.toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  } catch (e) {
    console.error('Erreur lors du formatage de la date:', e, dateStr);
    return 'Première consultation';
  }
}

export default function PatientExistantPage() {
  // Use the ApiPatient type from the context
  type Patient = import('@/contexts/PatientsContext').ApiPatient;

  // Use the patients context
  const {
    patients,
    searchPatients: contextSearchPatients,
    loading: contextLoading,
    fetchPatients
  } = usePatients();

  const router = useRouter();

  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [searchResults, setSearchResults] = useState<Patient[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const { t, isRTL } = useLanguage();


  // Recherche optimisée avec débounce pour éviter les requêtes excessives
  useEffect(() => {
    let debounceTimeout: NodeJS.Timeout | null = null;

    const performSearch = async () => {
      if (searchTerm.trim() === '') {
        // Si le champ de recherche est vide, afficher tous les patients
        setSearchResults(patients);
        setShowResults(patients.length > 0);
        setIsSearching(false);
      } else {
        try {
          setIsSearching(true);
          // Utiliser la recherche du contexte
          const results = await contextSearchPatients(searchTerm);
          setSearchResults(results);
          setShowResults(true);
        } catch (err) {
          console.error('Erreur lors de la recherche:', err);
          // Fallback sur le filtrage local si la recherche échoue
          const filtered = patients.filter(patient =>
            (patient.name && patient.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (patient.family_name && patient.family_name.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (patient.telephone && patient.telephone.toLowerCase().includes(searchTerm.toLowerCase())) ||
            (patient.email && patient.email.toLowerCase().includes(searchTerm.toLowerCase()))
          );
          setSearchResults(filtered);
          setShowResults(true);
        } finally {
          setIsSearching(false);
        }
      }
    };

    // Débounce la recherche pour éviter des requêtes excessives pendant la frappe
    if (debounceTimeout) {
      clearTimeout(debounceTimeout);
    }
    debounceTimeout = setTimeout(performSearch, 300);

    return () => {
      if (debounceTimeout) {
        clearTimeout(debounceTimeout);
      }
    };

  }, [searchTerm, patients, contextSearchPatients]);

  // Load patients on component mount
  useEffect(() => {
    if (patients.length === 0) {
      fetchPatients();
    }
  }, [fetchPatients, patients.length]);

  // Update search results when patients change
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setSearchResults(patients);
      setShowResults(patients.length > 0);
    }
  }, [patients, searchTerm]);

  return (
    <div className="min-h-screen overflow-hidden bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="flex">

        <div className="flex-1 ml-[100px] p-4 flex flex-col h-screen">
          <Header />

          <div className="flex-1 mt-4 overflow-auto">
            {/* Bouton de retour */}
            <Link href="/ordonnance" className="inline-flex items-center gap-2 mb-6 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors">
              <ArrowLeftIcon className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} />
              {t('common.back')}
            </Link>

            <h1 className="mb-6 text-2xl font-bold text-gray-800 dark:text-gray-100">{t('prescription.existingPatient.title')}</h1>

            {/* Barre de recherche */}
            <div className="relative mb-6">
              <div className="absolute inset-y-0 left-0 flex items-center px-4 pointer-events-none">
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full py-2 px-10 leading-5 placeholder-gray-500 text-gray-900 bg-white border border-gray-300 rounded-md focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm dark:bg-gray-800 dark:border-gray-600 dark:text-white dark:placeholder-gray-400 transition-colors"
                placeholder={t('prescription.existingPatient.searchPlaceholder')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Liste des patients - s'affiche uniquement quand on commence à écrire */}
            <div className="overflow-hidden bg-white dark:bg-gray-800 shadow sm:rounded-md transition-colors" style={{ minHeight: showResults ? 'auto' : '0' }}>
              {contextLoading ? (
                <div className="px-4 py-4 text-center text-gray-500 dark:text-gray-400">
                  {t('prescription.existingPatient.loading')}
                </div>
              ) : showResults ? (
                searchResults.length > 0 ? (
                  <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                    {searchResults.map((patient) => (
                      <li key={patient.id}>
                        <div
                          className={`px-4 py-4 flex items-center hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors`}
                          onClick={() => {
                            router.push(`/ordonnance/confirmation-patient?id=${patient.id}`);
                          }}
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between">
                              <p className="text-sm font-medium text-blue-600 dark:text-blue-400 truncate">
                                {patient.name} {patient.family_name}
                              </p>
                              <p className="text-sm text-gray-500 dark:text-gray-400" dir="ltr">
                                {patient.created_at ? formatDate(patient.created_at) : t('prescription.existingPatient.firstConsultation')}
                              </p>
                            </div>
                            <div className="flex mt-2 gap-6">
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <span className="truncate">
                                  {patient.age ? `${patient.age} ${t('prescription.existingPatient.years')}` : t('prescription.existingPatient.unknownAge')}
                                </span>
                              </div>
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400" dir="ltr">
                                <span className="truncate">{formatPhoneNumber(patient.telephone)} </span>
                              </div>
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <span className="truncate">
                                  {" "} {patient.chronicDiseases ||
                                    (Array.isArray(patient.allergies) ? patient.allergies.join(', ') : patient.allergies) ||
                                    t('prescription.existingPatient.noKnownIssues')}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="px-4 py-4 text-center text-gray-500 dark:text-gray-400">
                    {isSearching ? t('prescription.existingPatient.searching') : t('prescription.existingPatient.noResults')}
                  </div>
                )
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
