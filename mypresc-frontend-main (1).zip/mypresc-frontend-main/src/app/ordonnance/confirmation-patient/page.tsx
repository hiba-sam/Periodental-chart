'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
// Import séparé pour chaque icône plutôt que l'ensemble du paquet
import ArrowLeftIcon from '@heroicons/react/24/outline/esm/ArrowLeftIcon';
import PencilIcon from '@heroicons/react/24/outline/esm/PencilIcon';
import CheckIcon from '@heroicons/react/24/outline/esm/CheckIcon';
import XMarkIcon from '@heroicons/react/24/outline/esm/XMarkIcon';
import { useSearchParams } from 'next/navigation';
import { ApiPatient, usePatients } from '@/contexts/PatientsContext';
import { useLanguage } from '@/contexts/LanguageContext';

// Sidebar and Header are provided by MainLayout — no need to import them here



/**
 - Convert an unknown date-like input into a valid Date object.
 - Supports:
 --- Firestore Timestamp objects { seconds, nanoseconds }
 --- Date instances
 --- Numbers (epoch ms)
 --- Strings: ISO (yyyy-mm-dd) or dd/mm/yyyy
 - Returns null if the value cannot be parsed to a valid date.
 */
function toDate(value: unknown): Date | null {
  if (!value) return null;

  // Firestore Timestamp { seconds, nanoseconds }
  if (typeof value === 'object' && value !== null && 'seconds' in (value as any)) {
    const ts = value as { seconds: number };
    return new Date(ts.seconds * 1000);
  }

  if (value instanceof Date) return isNaN(value.getTime()) ? null : value;

  if (typeof value === 'number') {
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  if (typeof value === 'string') {
    const s = value.trim();
    // Support dd/mm/yyyy
    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (m) {
      const [, dd, mm, yyyy] = m;
      const d = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
      return isNaN(d.getTime()) ? null : d;
    }
    // ISO or yyyy-mm-dd or other parseable strings
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  }

  return null;
}

// Fonction optimisée pour calculer l'âge à partir de la date de naissance
const calculateAge = (birthDate: string): number => {
  const birth = toDate(birthDate);
  if (!birth) return 0;

  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();

  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;

  return age;
};

// Fonction optimisée pour formater le numéro de téléphone
const formatPhoneNumber = (phoneNumber?: string): string => {
  if (!phoneNumber) return '';

  const cleaned = phoneNumber.replace(/\D/g, '');

  // Formater le numéro avec des points (optimisé)
  return cleaned.length === 10
    ? cleaned.replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1.$2.$3.$4.$5')
    : phoneNumber;
}

// Fonction pour formater la date pour l'input date (format YYYY-MM-DD)
const formatDateForInput = (dateStr?: string): string => {
  if (!dateStr) return '';

  try {
    // Si c'est déjà au format YYYY-MM-DD, le retourner tel quel
    if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      return dateStr;
    }

    const date = toDate(dateStr);
    if (!date || isNaN(date.getTime())) {
      console.warn('Date invalide pour formatDateForInput:', dateStr);
      return '';
    }

    // Retourner au format YYYY-MM-DD requis par l'input date
    const formatted = date.toISOString().split('T')[0];
    console.log('Date formatée pour input:', formatted, 'from:', dateStr);
    return formatted;
  } catch (e) {
    console.error('Erreur lors du formatage de la date pour l\'input:', e, dateStr);
    return '';
  }
}

export default function ConfirmationPatientPage() {
  // État pour stocker les données du patient
  const [patient, setPatient] = useState<ApiPatient | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editedPatient, setEditedPatient] = useState<ApiPatient | null>(null);
  const [showModal, setShowModal] = useState(false);

  const { getPatient, updatePatient, loading } = usePatients();
  const { t, isRTL } = useLanguage();
  const [isUpdating, setIsUpdating] = useState(false);

  const searchParams = useSearchParams();
  const id = searchParams?.get("id");

  // Récupérer les données du patient sélectionné depuis localStorage et Firebase
  useEffect(() => {
    if (id) {
      getPatient(id).then((patient) => {
        setPatient(patient as ApiPatient);
      });
    }
  }, [id, getPatient]);

  // Initialize editedPatient when entering edit mode
  const handleStartEdit = () => {
    if (patient) {
      console.log('Patient data when starting edit:', patient);
      console.log('dateNaissance value:', patient.dateNaissance);
      console.log('Formatted date for input:', formatDateForInput(patient.dateNaissance));
      setEditedPatient({ ...patient });
    }
    setEditMode(true);
  };

  return (
    <div className="min-h-screen overflow-hidden bg-gray-50 dark:bg-gray-900 transition-colors">
      <div className="flex">
        <div className="flex-1 ml-[100px] p-4 flex flex-col h-screen" data-component-name="NouveauPatientPage">
          <div className="flex flex-col flex-1 mt-4 overflow-auto">
            {/* Bouton de retour */}
            <Link href="/ordonnance/patient-existant" className="inline-flex gap-4 items-center mb-4 text-lg font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 sm:mb-5 md:mb-6 sm:text-xl transition-colors">
              <ArrowLeftIcon className={`w-5 h-5 mr-2 sm:w-6 sm:h-6 ${isRTL ? 'rotate-180' : ''}`} />
              {t('prescription.confirmation.back')}
            </Link>

            <div className="flex items-center justify-center flex-1">
              <div className="w-full max-w-5xl p-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg sm:p-10 md:p-14 transition-colors">
                <h1 className="text-2xl sm:text-3xl md:text-3xl lg:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#642BEF] to-[#BF1D8E] mb-8 sm:mb-10 md:mb-12 text-center tracking-tight">{t('prescription.confirmation.title')}</h1>

                {/* Loading state */}
                {loading && (
                  <div className="flex items-center justify-center py-12">
                    <div className="flex flex-col items-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#642BEF] mb-4"></div>
                      <p className="text-gray-600 dark:text-gray-400">{t('prescription.confirmation.loadingPatient')}</p>
                    </div>
                  </div>
                )}

                {/* Patient information - only show when not loading */}
                {!loading && (
                  <>
                    <div className="grid grid-cols-1 mb-8 sm:grid-cols-2 gap-x-8 sm:gap-x-16 md:gap-x-24 lg:gap-x-32 gap-y-8 sm:gap-y-12 md:gap-y-16 sm:mb-12 md:mb-16">
                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.lastName')}</div>
                        {editMode ? (
                          <input
                            type="text"
                            className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                            value={editedPatient?.name || ''}
                            onChange={(e) => setEditedPatient(editedPatient ? { ...editedPatient, name: e.target.value } : null)}
                          />
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{patient?.name || ''}</div>
                        )}
                      </div>

                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.firstName')}</div>
                        {editMode ? (
                          <input
                            type="text"
                            className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                            value={editedPatient?.family_name || ''}
                            onChange={(e) => setEditedPatient(editedPatient ? { ...editedPatient, family_name: e.target.value } : null)}
                          />
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{patient?.family_name || ''}</div>
                        )}
                      </div>

                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.dateOfBirth')}</div>
                        {editMode ? (
                          <div>
                            <input
                              type="date"
                              className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                              value={formatDateForInput(editedPatient?.dateNaissance)}
                              onChange={(e) => setEditedPatient(editedPatient ? { ...editedPatient, dateNaissance: e.target.value } : null)}
                            />
                            {editedPatient?.dateNaissance && (
                              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                {t('prescription.confirmation.calculatedAge').replace('{age}', calculateAge(editedPatient.dateNaissance).toString())}
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{patient?.dateNaissance ? t('prescription.confirmation.yearsOld').replace('{age}', calculateAge(patient.dateNaissance).toString()) : t('prescription.confirmation.notSpecified')}</div>
                        )}
                      </div>

                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.gender')}</div>
                        {editMode ? (
                          <select
                            className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                            value={editedPatient?.genre || 'Non spécifié'}
                            onChange={(e) => setEditedPatient(editedPatient ? { ...editedPatient, genre: e.target.value as "homme" | "femme" } : null)}
                          >
                            <option value="homme">{t('prescription.confirmation.male')}</option>
                            <option value="femme">{t('prescription.confirmation.female')}</option>
                          </select>
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{patient?.genre || t('prescription.confirmation.notSpecified')}</div>
                        )}
                      </div>

                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.phoneNumber')}</div>
                        {editMode ? (
                          <input
                            type="text"
                            className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                            value={editedPatient?.telephone || ''}
                            onChange={(e) => setEditedPatient(editedPatient ? { ...editedPatient, telephone: e.target.value } : null)}
                          />
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{formatPhoneNumber(patient?.telephone) || t('prescription.confirmation.notSpecified')}</div>
                        )}
                      </div>

                      <div className="space-y-2 text-center sm:space-y-3 md:space-y-4">
                        <div className="text-base font-bold text-gray-900 dark:text-gray-100 uppercase sm:text-lg md:text-xl">{t('prescription.confirmation.socialSecurityCard')}</div>
                        {editMode ? (
                          <input
                            type="text"
                            className="text-base sm:text-lg md:text-xl text-center w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white transition-colors"
                            value={editedPatient?.numeroSecuriteSociale || ''}
                            onChange={(e) => {
                              if (editedPatient) {
                                // S'assurer que tous les champs requis sont présents
                                setEditedPatient({
                                  ...editedPatient,
                                  numeroSecuriteSociale: e.target.value
                                });
                              }
                            }}
                          />
                        ) : (
                          <div className="text-base sm:text-lg md:text-xl text-gray-800 dark:text-gray-200">{patient?.numeroSecuriteSociale || t('prescription.confirmation.notSpecified')}</div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-12">
                      {editMode ? (
                        <button
                          onClick={() => {
                            setEditMode(false);
                            // Corriger le type en vérifiant que patient existe et a un ID
                            if (patient && patient.id) {
                              setEditedPatient(patient);
                            }
                          }}
                          className="inline-flex items-center px-6 py-3 text-base font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
                        >
                          {t('prescription.confirmation.cancel')}
                          <XMarkIcon className="w-5 h-5 ml-2" />
                        </button>
                      ) : (
                        <button
                          onClick={handleStartEdit}
                          className="inline-flex items-center px-6 py-3 text-base font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors"
                        >
                          {t('prescription.confirmation.edit')}
                          <PencilIcon className="w-5 h-5 ml-2" />
                        </button>
                      )}

                      {editMode ? (
                        <button
                          onClick={() => setShowModal(true)}
                          className="inline-flex items-center px-8 py-3 text-base font-medium text-white border border-transparent rounded-md shadow-sm bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 transition-opacity"
                        >
                          {t('prescription.confirmation.confirm')}
                          <CheckIcon className="w-5 h-5 ml-2" />
                        </button>
                      ) : (
                        <Link
                          href={patient ? `/ordonnance/prescription/${patient.id}` : '#'}
                          className="relative inline-flex items-center text-base font-medium rounded-full shadow-sm"
                          style={{ background: 'linear-gradient(to right, #642BEF, #BF1D8E)', padding: '2px' }}
                        >
                          <span className="flex items-center justify-center w-full h-full px-8 py-3 bg-white dark:bg-gray-800 rounded-full dark:text-white transition-colors">
                            <span className="font-bold text-gray-900 dark:text-white">{t('prescription.confirmation.next')}</span>
                          </span>
                        </Link>
                      )}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Indicateurs d'étape */}
            <div className="flex justify-center py-6 gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div className="w-3 h-3 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
              <div className="w-3 h-3 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
              <div className="w-3 h-3 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
            </div>

            {/* Modal de confirmation - optimisé avec chargement dynamique */}
            {showModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-50 dark:bg-black dark:bg-opacity-70 backdrop-blur-sm">
                <div className="w-full max-w-md p-8 bg-white dark:bg-gray-800 rounded-lg shadow-xl border dark:border-gray-700 transition-colors">
                  <h3 className="mb-4 text-xl font-bold dark:text-white">{t('prescription.confirmation.modalTitle')}</h3>
                  <p className="mb-6 dark:text-gray-300">{t('prescription.confirmation.modalMessage')}</p>

                  {isUpdating && (
                    <div className="flex items-center justify-center mb-4">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#642BEF] mr-2"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{t('prescription.confirmation.updating')}</span>
                    </div>
                  )}
                  <div className="flex justify-end gap-4">
                    <button
                      onClick={() => setShowModal(false)}
                      disabled={isUpdating}
                      className={`px-4 py-2 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors ${isUpdating ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {t('prescription.confirmation.cancel')}
                    </button>
                    <button
                      onClick={async () => {
                        if (editedPatient?.id) {
                          try {
                            setIsUpdating(true);

                            // Vérifier si des modifications ont été apportées
                            const hasChanged = JSON.stringify(patient) !== JSON.stringify(editedPatient);


                            if (hasChanged) {
                              // Préparer les données pour la mise à jour (conversion ApiPatient vers PatientData)
                              const updateData = {
                                name: editedPatient.name,
                                family_name: editedPatient.family_name,
                                dateNaissance: editedPatient.dateNaissance,
                                genre: editedPatient.genre,
                                telephone: editedPatient.telephone,
                                email: editedPatient.email,
                                adresse: editedPatient.adresse,
                                numeroSecuriteSociale: editedPatient.numeroSecuriteSociale,
                                medecinTraitant: editedPatient.medecinTraitant,
                                chronicDiseases: editedPatient.chronicDiseases,
                                allergies: editedPatient.allergies,
                                notes: editedPatient.notes,
                                nin: editedPatient.nin
                              };

                              // Appeler la fonction de mise à jour du contexte
                              const updatedPatient = await updatePatient(editedPatient.id, updateData);

                              if (updatedPatient) {
                                // Mettre à jour l'état local
                                setPatient(updatedPatient);

                                // Fermer le modal et sortir du mode édition
                                setEditMode(false);
                                setShowModal(false);

                                // Afficher un message de succès
                                console.log('Patient mis à jour avec succès');
                              }
                            } else {
                              // Aucune modification détectée
                              setEditMode(false);
                              setShowModal(false);
                              console.log('Aucune modification détectée');
                            }
                          } catch (error) {
                            console.error('Erreur lors de la mise à jour:', error);
                          } finally {
                            setIsUpdating(false);
                          }
                        }
                      }}
                      disabled={isUpdating}
                      className={`px-4 py-2 text-white rounded-md bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 ${isUpdating ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {isUpdating ? t('prescription.confirmation.update') : t('prescription.confirmation.confirm')}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
