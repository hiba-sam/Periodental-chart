"use client";

import Sidebar from "@/components/Sidebar";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { usePrescription } from "@/contexts/PrescriptionContext";
import { PlusIcon, TrashIcon, DocumentDuplicateIcon, PencilSquareIcon, BeakerIcon } from "@heroicons/react/24/outline";
import CreatePrescriptionTypeModal from "./_components/CreatePrescriptionTypeModal";
import { PrescriptionType } from "@/features/prescriptions/types/prescription.types";

// Chargement dynamique uniquement pour Header
const Header = dynamic(() => import("@/components/Header"), { ssr: false });

export default function OrdonnancePage() {
  const { t } = useLanguage();
  const { prescriptionTypes, deletePrescriptionType } = usePrescription();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingModel, setEditingModel] = useState<PrescriptionType | null>(null);

  // Formatting date helper
  const formatDate = (dateString: string | Date) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleDeleteType = async (e: React.MouseEvent, id: number) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Êtes-vous sûr de vouloir supprimer ce modèle ? Cette action est irréversible.")) {
      await deletePrescriptionType(id);
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-gray-50 dark:bg-gray-900 py-12 px-4 transition-colors overflow-hidden">
      <div className="max-w-[1400px] mx-auto flex flex-col lg:flex-row gap-8 lg:gap-16 items-start h-full">
        {/* Partie Gauche : Commencer la création */}
        <div className="flex-1 flex flex-col items-center justify-center pt-8 lg:pt-16 w-full">
          <h1 className="text-[28px] md:text-3xl font-bold text-center mb-8 text-gray-900 dark:text-gray-100">
            {t('prescription.start.title')}
            <br />
            {t('prescription.start.electronic')}
          </h1>

          <div className="w-full max-w-md my-8 flex justify-center">
            <img
              src="/images/prescription-illustration.png"
              alt={t('prescription.start.imageAlt')}
              className="w-full max-w-md h-auto"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-6 w-full max-w-lg mt-8">
            <Link
              href="/ordonnance/patient-existant"
              className="flex-1 bg-gradient-to-r from-[#7F71A0] to-[#972475] hover:opacity-90 text-white py-3.5 px-6 rounded-xl text-center transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl font-medium"
            >
              <span>{t('prescription.start.existingPatient')}</span>
            </Link>

            <Link
              href="/ordonnance/nouveau-patient"
              className="flex-1 bg-gradient-to-r from-[#642BEF] to-[#BF1D8E] hover:opacity-90 text-white py-3.5 px-6 rounded-xl text-center transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl font-medium"
            >
              <span>{t('prescription.start.newPatient')}</span>
            </Link>
          </div>
        </div>

        {/* Partie Droite : Modèles d'ordonnance */}
        <div className="w-full lg:w-[450px] shrink-0 flex flex-col border-t border-gray-200 dark:border-gray-800 lg:border-t-0 lg:border-l lg:pl-12 pt-12 lg:pt-0">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <DocumentDuplicateIcon className="w-6 h-6 text-[#642BEF]" />
              Mes Modèles
            </h2>
            <button
              onClick={() => {
                setEditingModel(null);
                setIsModalOpen(true);
              }}
              className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 text-sm font-medium text-gray-700 dark:text-gray-200 px-4 py-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition"
            >
              <PlusIcon className="w-4 h-4" />
              Nouveau
            </button>
          </div>

          {prescriptionTypes.length > 0 ? (
            <div className="flex flex-col gap-4 overflow-y-auto max-h-[60vh] pr-2 custom-scrollbar">
              {prescriptionTypes.map((type) => (
                <div key={type.id} className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-100 dark:border-gray-700 shadow-sm relative group hover:shadow-md transition-shadow">
                  <button
                    onClick={(e) => handleDeleteType(e, type.id)}
                    className="absolute top-4 right-4 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-1"
                    title="Supprimer ce modèle"
                  >
                    <TrashIcon className="w-5 h-5" />
                  </button>
                  
                  <h3 className="font-bold text-lg text-gray-900 dark:text-white pr-8 truncate">
                    {type.name}
                  </h3>
                  
                  {type.description && (
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 line-clamp-1">
                      {type.description}
                    </p>
                  )}
                  
                  <div className="mt-4 flex items-center gap-3 text-sm text-gray-600 dark:text-gray-400">
                    <span className="flex items-center gap-1.5 bg-gray-50 dark:bg-gray-700/50 px-2.5 py-1 rounded-md text-xs font-medium border border-gray-100 dark:border-gray-700">
                      <BeakerIcon className="w-3.5 h-3.5 text-blue-500 dark:text-blue-400" /> 
                      {type.medications?.length || type.medication_count || 0} médicaments
                    </span>
                    <span className="text-xs">Créé le {formatDate(type.created_at)}</span>
                  </div>

                  <div className="mt-5 pt-4 border-t border-gray-50 dark:border-gray-700/50">
                    <button
                      onClick={() => {
                        setEditingModel(type);
                        setIsModalOpen(true);
                      }}
                      className="flex items-center justify-center gap-2 w-full py-2.5 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-50 hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg transition border border-gray-200 dark:border-gray-600"
                    >
                      <PencilSquareIcon className="w-4 h-4" />
                      Modifier ce modèle
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-8 border border-dashed border-gray-300 dark:border-gray-700 text-center">
              <div className="mx-auto w-12 h-12 bg-gray-50 dark:bg-gray-700/50 rounded-full flex items-center justify-center mb-4">
                <DocumentDuplicateIcon className="w-6 h-6 text-gray-400" />
              </div>
              <p className="text-gray-600 dark:text-gray-400 mb-3 text-sm">
                Vous n'avez pas encore créé de modèle d'ordonnance.
              </p>
              <button
                onClick={() => {
                  setEditingModel(null);
                  setIsModalOpen(true);
                }}
                className="text-sm font-medium text-[#642BEF] hover:text-[#BF1D8E] transition-colors"
              >
                Créer votre premier modèle →
              </button>
            </div>
          )}
        </div>
      </div>

      <CreatePrescriptionTypeModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingModel(null);
        }}
        initialData={editingModel}
      />
    </div>
  );
}
