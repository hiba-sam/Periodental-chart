"use client";

import { useState, useEffect, useRef, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

// Import séparé pour chaque icône plutôt que l'ensemble du paquet
import ArrowLeftIcon from "@heroicons/react/24/outline/esm/ArrowLeftIcon";
import PlusIcon from "@heroicons/react/24/outline/esm/PlusIcon";
import TrashIcon from "@heroicons/react/24/outline/esm/TrashIcon";
import MagnifyingGlassIcon from "@heroicons/react/24/outline/esm/MagnifyingGlassIcon";
import DocumentTextIcon from "@heroicons/react/24/outline/esm/DocumentTextIcon";
import DocumentDuplicateIcon from "@heroicons/react/24/outline/esm/DocumentDuplicateIcon";
import ChevronDownIcon from "@heroicons/react/24/outline/esm/ChevronDownIcon";
import PosologieInput from "@/components/PosologieInput";
import { ApiPatient, usePatients } from "@/contexts/PatientsContext";
import {
  usePrescription,
  Medication,
  PrescriptionMedication,
  ApiPrescription,
} from "@/contexts/PrescriptionContext";
import { useLanguage } from "@/contexts/LanguageContext";

// Sidebar and Header are provided by MainLayout — no need to import them here

/**
 - Convert an unknown date-like input into a valid Date object.
 - Supports:
 --- Firestore Timestamp objects { seconds, nanoseconds }
 --- Date instances
 --- Numbers (epoch ms)
 --- Strings: ISO (yyyy-mm-dd) or dd/mm/yyyy
 - Returns null if the value cannot be parsed to a valid date.
 */
function toDate(value: unknown): Date | null {
  if (!value) return null;

  // Firestore Timestamp { seconds, nanoseconds }
  if (
    typeof value === "object" &&
    value !== null &&
    "seconds" in (value as any)
  ) {
    const ts = value as { seconds: number };
    return new Date(ts.seconds * 1000);
  }

  if (value instanceof Date) return isNaN(value.getTime()) ? null : value;

  if (typeof value === "number") {
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }

  if (typeof value === "string") {
    const s = value.trim();
    // Support dd/mm/yyyy
    const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (m) {
      const [, dd, mm, yyyy] = m;
      const d = new Date(Number(yyyy), Number(mm) - 1, Number(dd));
      return isNaN(d.getTime()) ? null : d;
    }
    // ISO or yyyy-mm-dd or other parseable strings
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  }

  return null;
}

/**
 - Calculate age in years from a birth date input of unknown shape.
 - Uses toDate for normalization and guards against invalid dates.
 - Returns 0 if input is missing or invalid.
 */
function calculateAge(birthDateInput: unknown): number {
  const birth = toDate(birthDateInput);
  if (!birth) return 0;

  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }

  return age;
}

export default function PrescriptionMedicalePage({ params }: { params: { id: string } }) {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gray-50 dark:bg-gray-900" />}>
      <PrescriptionFormContent params={params} />
    </Suspense>
  );
}

function PrescriptionFormContent({ params }: { params: { id: string } }) {
  const { id } = params;
  const router = useRouter();
  const searchParams = useSearchParams();
  const typeIdParam = searchParams.get("typeId");

  // Patient state
  const [patient, setPatient] = useState<ApiPatient | null>(null);
  const [loading, setLoading] = useState(true);
  const { getPatient, error } = usePatients();

  // Prescription context
  const {
    prescriptions,
    medications,
    loading: prescriptionLoading,
    error: prescriptionError,
    createPrescription,
    searchMedications,
    getAllMedications,
    getMedicationById,
    clearError,
    prescriptionTypes,
    prescriptionTypesLoading,
    savePrescriptionAsType,
    createPrescriptionType,
  } = usePrescription();

  const { t, isRTL } = useLanguage();

  // Prescription form state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMedications, setSelectedMedications] = useState<
    PrescriptionMedication[]
  >([]);
  const [remarks, setRemarks] = useState("");
  const [isCreatingPrescription, setIsCreatingPrescription] = useState(false);
  const [searchResults, setSearchResults] = useState<Medication[]>([]);
  const [showConfirmCreate, setShowConfirmCreate] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Model selection state
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const [loadedModelId, setLoadedModelId] = useState<number | null>(null);
  const modelDropdownRef = useRef<HTMLDivElement>(null);

  // Save as model state
  const [showSaveModelForm, setShowSaveModelForm] = useState(false);
  const [newModelName, setNewModelName] = useState("");
  const [isSavingModel, setIsSavingModel] = useState(false);

  // Custom medication state
  const [showCustomMedForm, setShowCustomMedForm] = useState(false);
  const [customMedName, setCustomMedName] = useState("");
  const [customMedDCI, setCustomMedDCI] = useState("");
  const [customMedDosage, setCustomMedDosage] = useState("");
  const [customMedForme, setCustomMedForme] = useState("");
  const [isAddingCustomMed, setIsAddingCustomMed] = useState(false);

  // Load patient and prescriptions on mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const patientData = await getPatient(id);
        setPatient(patientData as ApiPatient);

        setLoading(false);
      } catch (error) {
        console.error("Error loading data:", error);
        setLoading(false);
      }
    };

    loadData();
  }, [id, getPatient]);

  // Load prescription type from URL if present
  useEffect(() => {
    if (typeIdParam && prescriptionTypes.length > 0 && selectedMedications.length === 0) {
      const modelId = parseInt(typeIdParam);
      const modelToLoad = prescriptionTypes.find(t => t.id === modelId);
      if (modelToLoad && modelToLoad.medications) {
        // Map from PrescriptionTypeMedication to PrescriptionMedication
        const mappedMeds: PrescriptionMedication[] = modelToLoad.medications.map(m => ({
          medication_id: m.medication_id || 0,
          custom_medication_id: m.custom_medication_id || undefined,
          is_custom: m.is_custom,
          nom_de_marque: m.nom_de_marque,
          denomination_commune_internationale: m.denomination_commune_internationale,
          quantity: m.quantity,
          dosage: m.dosage,
          note: m.note || "",
          med_dosage: m.med_dosage,
        }));
        setSelectedMedications(mappedMeds);
        setLoadedModelId(modelId);
        
        // Remove query param without refreshing to prevent reload loop
        router.replace(`/ordonnance/prescription/${id}`, { scroll: false });
      }
    }
  }, [typeIdParam, prescriptionTypes, id, router]); // Intentionally omitting selectedMedications to only run when empty

  // Real-time medication search with debouncing
  useEffect(() => {
    const runSearch = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }
      const results = await searchMedications(searchQuery.trim(), 5);
      setSearchResults(results);
    };

    const timeoutId = setTimeout(runSearch, 300);
    return () => clearTimeout(timeoutId);
  }, [searchQuery, searchMedications]);

  // Clear search
  const handleClearSearch = () => {
    setSearchQuery("");
    setSearchResults([]);
  };

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setSearchQuery("");
        setSearchResults([]);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Handle click outside for model dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        modelDropdownRef.current &&
        !modelDropdownRef.current.contains(event.target as Node)
      ) {
        setIsModelDropdownOpen(false);
      }
    };

    if (isModelDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isModelDropdownOpen]);

  // Add medication to prescription
  const handleAddMedication = (medication: Medication) => {
    const newPrescriptionMedication: PrescriptionMedication = {
      medication_id: medication.id,
      nom_de_marque: medication.nom_de_marque,
      denomination_commune_internationale:
        medication.denomination_commune_internationale,
      quantity: 1,
      med_dosage: medication.dosage,
      dosage: "",
      note: "",
    };

    setSelectedMedications((prev) => [...prev, newPrescriptionMedication]);
    setSearchQuery("");
    setSearchResults([]);
  };

  // Open custom medication form with search query as name
  const handleOpenCustomMedForm = () => {
    setCustomMedName(searchQuery);
    setShowCustomMedForm(true);
  };

  // Add custom medication
  const handleAddCustomMedication = async () => {
    if (!customMedName.trim()) return;

    setIsAddingCustomMed(true);
    try {
      const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';
      const response = await fetch(`${backendUrl}/custom-medications`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          nom_de_marque: customMedName.trim(),
          denomination_commune_internationale: customMedDCI.trim() || null,
          dosage: customMedDosage.trim() || null,
          forme: customMedForme.trim() || null,
        }),
      });

      const data = await response.json();
      if (data.success) {
        // Add to selected medications with custom flag
        const newPrescriptionMedication: PrescriptionMedication = {
          medication_id: data.data.id,
          nom_de_marque: data.data.nom_de_marque,
          denomination_commune_internationale: data.data.denomination_commune_internationale || '',
          quantity: 1,
          med_dosage: data.data.dosage || '',
          dosage: '',
          note: '',
          is_custom: true,
        };
        setSelectedMedications((prev) => [...prev, newPrescriptionMedication]);

        // Reset form
        setShowCustomMedForm(false);
        setCustomMedName('');
        setCustomMedDCI('');
        setCustomMedDosage('');
        setCustomMedForme('');
        setSearchQuery('');
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Error adding custom medication:', error);
    } finally {
      setIsAddingCustomMed(false);
    }
  };

  // Remove medication from prescription
  const handleRemoveMedication = (index: number) => {
    setSelectedMedications((prev) => {
      const newMeds = prev.filter((_, i) => i !== index);
      if (newMeds.length === 0) {
        setLoadedModelId(null);
      }
      return newMeds;
    });
  };

  // Update medication details
  const handleUpdateMedication = (
    index: number,
    field: keyof PrescriptionMedication,
    value: string | number
  ) => {
    setSelectedMedications((prev) =>
      prev.map((med, i) => (i === index ? { ...med, [field]: value } : med))
    );
  };



  // Show confirmation modal
  const handleShowConfirmCreate = () => {
    const noDosage = selectedMedications.some(med => !med.dosage || med.dosage.trim() === "");
    if (noDosage) {
      alert(t('prescription.create.selectDosage'));
      return;
    }
    if (!patient || selectedMedications.length === 0) {
      alert(t('prescription.create.selectMedication'));
      return;
    }
    setShowConfirmCreate(true);
  };

  // Create prescription (called from confirmation modal)
  const handleCreatePrescription = async () => {
    setIsCreatingPrescription(true);

    try {
      const prescriptionData = {
        patient_id: id as string,
        confirmed_count: 1,
        remarks: remarks.trim() || undefined,
        medications: selectedMedications,
      };

      const result = await createPrescription(prescriptionData);
      if (result) {
        // Reset form
        setSelectedMedications([]);
        setRemarks("");
        setSearchQuery("");
        setSearchResults([]);
        // Close modal and redirect
        setShowConfirmCreate(false);
        router.push(`/patients/${id}`);
        // Success message is handled by the context toast
      }
    } catch (error) {
      console.error("Error creating prescription:", error);
      // Close modal on error too
      setShowConfirmCreate(false);
    } finally {
      setIsCreatingPrescription(false);
    }
  };

  // Handle loading an existing model
  const handleLoadModel = (modelId: number) => {
    const modelToLoad = prescriptionTypes.find(t => t.id === modelId);
    if (!modelToLoad || !modelToLoad.medications) return;

    if (selectedMedications.length > 0) {
      if (!confirm("Attention : Le chargement de ce modèle remplacera tous les médicaments actuellement saisis. Voulez-vous continuer ?")) {
        setIsModelDropdownOpen(false);
        return;
      }
    }

    const mappedMeds: PrescriptionMedication[] = modelToLoad.medications.map(m => ({
      medication_id: m.medication_id || 0,
      custom_medication_id: m.custom_medication_id || undefined,
      is_custom: m.is_custom,
      nom_de_marque: m.nom_de_marque,
      denomination_commune_internationale: m.denomination_commune_internationale,
      quantity: m.quantity,
      dosage: m.dosage,
      note: m.note || "",
      med_dosage: m.med_dosage,
    }));
    
    setSelectedMedications(mappedMeds);
    setLoadedModelId(modelId);
    setIsModelDropdownOpen(false);
  };


  // Single stable return — conditional content inside a stable wrapper
  // This prevents React DOM reconciliation errors (removeChild/insertBefore)
  return (
    <div className="h-screen bg-gray-50 dark:bg-gray-900 overflow-hidden transition-colors">
      {loading ? (
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="animate-pulse flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-blue-200 dark:bg-blue-900 mb-4"></div>
            <div className="h-4 bg-blue-200 dark:bg-blue-900 rounded w-1/4 mb-2.5"></div>
            <div className="h-4 bg-blue-200 dark:bg-blue-900 rounded w-1/3"></div>
            <p className="mt-4 text-gray-500 dark:text-gray-400">
              Chargement des données du patient...
            </p>
          </div>
        </div>
      ) : error ? (
        <div className="flex-1 p-6">
          <div className="flex flex-col items-center justify-center h-full">
            <div className="text-red-500 text-xl mb-4">Erreur :</div>
            <div className="text-gray-700 dark:text-gray-300 mb-6">{error}</div>
            <Link
              href="/ordonnance/patient-existant"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              <ArrowLeftIcon className={`h-4 w-4 mx-2 ${isRTL ? "rotate-180" : ""}`} />
              {t('prescription.create.backToPatientsList')}
            </Link>
          </div>
        </div>
      ) : (
      <>
      <div className="flex flex-col p-4 md:p-6 bg-gray-50 dark:bg-gray-900 transition-colors">
        <div
          className="flex-1 max-h-screen overflow-y-auto pb-[100px]"
        >
          {/* Bouton de retour */}
          <div className="mb-4">
            <Link
              href="/ordonnance/patient-existant"
              className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors"
            >
              <ArrowLeftIcon className={`h-4 w-4 mx-1 ${isRTL ? "rotate-180" : ""}`} />
              {t('prescription.create.backToPatientsList')}
            </Link>
          </div>

          {/* Informations du patient */}
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 md:p-6 mb-6 transition-colors">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
                  {patient?.name} {patient?.family_name}
                </h2>
                <p className="text-gray-600 dark:text-gray-400">
                  {patient?.genre || "Non spécifié"},{" "}
                  {patient?.dateNaissance
                    ? calculateAge(patient.dateNaissance)
                    : 0}{" "}
                  ans, N° Carte:{" "}
                  {patient?.numeroSecuriteSociale || "Non spécifié"}
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  Tél: {patient?.telephone || "Non spécifié"}
                </p>
              </div>
            </div>

            {(patient?.chronicDiseases || patient?.allergies) && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-4">
                {patient?.chronicDiseases && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Maladies chroniques:
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">{patient.chronicDiseases}</p>
                  </div>
                )}
                {patient?.allergies && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      Allergies:
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">{patient.allergies}</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Prescription Form */}
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 md:p-6 mb-6 transition-colors overflow-visible">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                {t('prescription.create.prescriptionTitle')}
              </h1>

              {/* Model Loader Dropdown */}
              <div className="relative" ref={modelDropdownRef}>
                <button
                  onClick={() => setIsModelDropdownOpen(!isModelDropdownOpen)}
                  disabled={prescriptionTypesLoading}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors disabled:opacity-50"
                >
                  <DocumentDuplicateIcon className="w-4 h-4 text-[#642BEF]" />
                  Charger un modèle
                  <ChevronDownIcon className={`w-4 h-4 ml-1 transition-transform ${isModelDropdownOpen ? 'rotate-180' : ''}`} />
                </button>

                {isModelDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 z-50 max-h-80 overflow-y-auto">
                    {prescriptionTypesLoading ? (
                      <div className="px-4 py-3 text-sm text-center text-gray-500">Chargement...</div>
                    ) : prescriptionTypes.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-center text-gray-500">Aucun modèle disponible.</div>
                    ) : (
                      <div className="py-1">
                        {prescriptionTypes.map(model => {
                          const isLoaded = model.id === loadedModelId;
                          return (
                            <button
                              key={model.id}
                              onClick={() => handleLoadModel(model.id)}
                              disabled={isLoaded}
                              className={`w-full text-left px-4 py-3 border-b border-gray-50 dark:border-gray-700/50 last:border-0 ${isLoaded ? "bg-gray-50 dark:bg-gray-700/50 cursor-not-allowed" : "hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"}`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="font-medium text-sm text-gray-900 dark:text-gray-100 truncate pr-2">{model.name}</div>
                                {isLoaded && (
                                  <span className="text-[10px] bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 px-1.5 py-0.5 rounded-sm font-medium whitespace-nowrap">
                                    Déjà chargé
                                  </span>
                                )}
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                                {model.medication_count || (model.medications?.length) || 0} médicament(s)
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Error Display */}
            {prescriptionError && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <p>{t('prescription.create.error')} {prescriptionError}</p>
                <button
                  onClick={clearError}
                  className="mt-2 bg-red-500 text-white px-3 py-1 rounded text-sm"
                >
                  {t('prescription.create.close')}
                </button>
              </div>
            )}

            {/* Medication Search Input */}
            <div className="mb-6 relative" ref={searchContainerRef}>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('prescription.create.searchMedication')}
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder={t('prescription.create.searchPlaceholder')}
                  className="w-full h-12 text-base py-3 pl-12 pr-12 border border-gray-300 dark:border-gray-600 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white transition-colors"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <MagnifyingGlassIcon className="absolute w-6 h-6 text-gray-400 left-4 top-1/2 -translate-y-1/2" />
                {searchQuery && (
                  <button
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 hover:text-gray-700"
                    onClick={handleClearSearch}
                  >
                    {t('prescription.create.clear')}
                  </button>
                )}
              </div>

              {/* Search Results Dropdown - Fixed positioning */}
              {searchQuery && searchResults.length > 0 && (
                <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-xl max-h-96 overflow-y-auto transition-colors">
                  {searchResults.map((medication) => (
                    <div
                      key={medication.id}
                      className="flex justify-between items-center p-3 border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                      onClick={() => handleAddMedication(medication)}
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 dark:text-white">
                          {medication.nom_de_marque}
                        </h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {medication.denomination_commune_internationale}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {medication.dosage} - {medication.forme}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddMedication(medication);
                        }}
                        className="ml-4 px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors"
                      >
                        {t('prescription.create.add')}
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* No Results - With option to add custom medication */}
              {searchQuery &&
                searchResults.length === 0 &&
                !prescriptionLoading && (
                  <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-xl p-4 transition-colors">
                    <p className="text-gray-500 dark:text-gray-400 text-center mb-3">
                      Aucun médicament trouvé pour &quot;{searchQuery}&quot;
                    </p>
                    <button
                      onClick={handleOpenCustomMedForm}
                      className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <PlusIcon className="w-5 h-5" />
                      Ajouter &quot;{searchQuery}&quot; comme médicament personnalisé
                    </button>
                  </div>
                )}
            </div>

            {/* Spacer to ensure content below search results is visible */}
            {/* {searchQuery && searchResults.length > 0 && (
              <div className="h-80"></div>
            )} */}

            {/* Selected Medications */}
            {selectedMedications.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                  {t('prescription.create.selectedMedications').replace('{count}', selectedMedications.length.toString())}
                </h3>
                <div className="space-y-4">
                  {selectedMedications.map((med, index) => (
                    <div
                      key={index}
                      className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 dark:text-white">
                            {med.nom_de_marque} {med.med_dosage}
                          </h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            ID: {med.medication_id}
                          </p>
                        </div>
                        <button
                          onClick={() => handleRemoveMedication(index)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <TrashIcon className="h-5 w-5" />
                        </button>
                      </div>

                      {/* Posologie */}
                      <div className="mb-3">
                        <PosologieInput
                          value={med.dosage}
                          onChange={(val) =>
                            handleUpdateMedication(index, "dosage", val)
                          }
                          isRTL={isRTL}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            {t('prescription.create.quantity')}
                          </label>
                          <input
                            type="number"
                            value={med.quantity}

                            onChange={(e) =>
                              handleUpdateMedication(
                                index,
                                "quantity",
                                parseInt(e.target.value) || 1
                              )
                            }
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white transition-colors"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            {t('prescription.create.note')}
                          </label>
                          <input
                            type="text"
                            value={med.note}
                            onChange={(e) =>
                              handleUpdateMedication(
                                index,
                                "note",
                                e.target.value
                              )
                            }
                            placeholder={t('prescription.create.specialInstructions')}
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white transition-colors"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Remarks
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Remarques générales
              </label>
              <textarea
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Instructions générales pour le patient..."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div> */}

            {/* Prescription Preview */}
            {selectedMedications.length > 0 && (
              <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg transition-colors">
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">
                  {t('prescription.create.prescriptionPreview')}
                </h3>
                <div className="space-y-2">
                  <p className="dark:text-gray-300">
                    <strong className="dark:text-white">{t('prescription.create.numberOfMedications')}</strong>{" "}
                    {selectedMedications.length}
                  </p>
                  <div>
                    <strong className="dark:text-white">{t('prescription.create.medications')}</strong>
                    <ul className="mt-1 ml-4 space-y-1">
                      {selectedMedications.map((med, index) => (
                        <li key={index} className="text-sm text-gray-700 dark:text-gray-300">
                          • {med.quantity > 1 && med.quantity}{" "}
                          {med.nom_de_marque} {med.med_dosage} - {med.dosage}
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {med.note && `(${med.note})`}
                          </p>
                        </li>
                      ))}
                    </ul>
                  </div>
                  {remarks && (
                    <p>
                      <strong>Remarques:</strong> {remarks}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Action Buttons Footer */}
            <div className="flex flex-col-reverse sm:flex-row justify-end items-center gap-4 border-t border-gray-100 dark:border-gray-700 pt-6">
              <button
                onClick={() => setShowSaveModelForm(true)}
                disabled={selectedMedications.length === 0 || loadedModelId !== null}
                className="w-full sm:w-auto px-4 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                title={loadedModelId !== null ? "Ce modèle est déjà enregistré" : "Sauvegarder cette liste de médicaments comme modèle réutilisable"}
              >
                <DocumentDuplicateIcon className="w-5 h-5 text-gray-400" />
                Enregistrer comme modèle
              </button>
              
              <button
                onClick={handleShowConfirmCreate}
                disabled={
                  selectedMedications.length === 0 ||
                  isCreatingPrescription ||
                  prescriptionLoading
                }
                className="w-full sm:w-auto px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-center transition-colors"
              >
                {t('prescription.create.createPrescription')}
              </button>
            </div>
          </div>
        </div>
      </div>
      </>
      )}

      {/* Confirmation Modal */}
      {showConfirmCreate && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl max-w-md w-full mx-4 transition-colors">
            <div className="text-center">
              {isCreatingPrescription ? (
                // Loading state
                <>
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                    {t('prescription.create.creating')}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                    {t('prescription.create.pleasewait')}
                  </p>
                  <div className="flex justify-center">
                    <div className="animate-pulse bg-gray-200 dark:bg-gray-700 h-10 w-32 rounded-lg"></div>
                  </div>
                </>
              ) : (
                // Normal confirmation state
                <>
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <DocumentTextIcon className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                    {t('prescription.create.confirmCreation')}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 mb-6">
                    {t('prescription.create.confirmMessage')
                      .replace('{patient}', `${patient?.name} ${patient?.family_name}`)
                      .replace('{count}', selectedMedications.length.toString())
                      .replace('{plural}', selectedMedications.length > 1 ? 's' : '')}
                    <br />
                    <br />
                    {t('prescription.create.pdfWillOpen')}
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setShowConfirmCreate(false)}
                      className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                    >
                      {t('prescription.create.cancel')}
                    </button>
                    <button
                      onClick={handleCreatePrescription}
                      className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                    >
                      {t('prescription.create.confirm')}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Custom Medication Modal */}
      {showCustomMedForm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl max-w-md w-full mx-4 transition-colors">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
              Ajouter un médicament personnalisé
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
              Ce médicament sera enregistré pour utilisation future et soumis pour ajout à la base de données.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Nom du médicament *
                </label>
                <input
                  type="text"
                  value={customMedName}
                  onChange={(e) => setCustomMedName(e.target.value)}
                  placeholder="Ex: Doliprane"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  DCI (Dénomination Commune Internationale)
                </label>
                <input
                  type="text"
                  value={customMedDCI}
                  onChange={(e) => setCustomMedDCI(e.target.value)}
                  placeholder="Ex: Paracétamol"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Dosage
                  </label>
                  <input
                    type="text"
                    value={customMedDosage}
                    onChange={(e) => setCustomMedDosage(e.target.value)}
                    placeholder="Ex: 500mg"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Forme
                  </label>
                  <input
                    type="text"
                    value={customMedForme}
                    onChange={(e) => setCustomMedForme(e.target.value)}
                    placeholder="Ex: Comprimé"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setShowCustomMedForm(false);
                  setCustomMedName('');
                  setCustomMedDCI('');
                  setCustomMedDosage('');
                  setCustomMedForme('');
                }}
                className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleAddCustomMedication}
                disabled={!customMedName.trim() || isAddingCustomMed}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAddingCustomMed ? 'Ajout...' : 'Ajouter'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Save as Model Modal */}
      {showSaveModelForm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl max-w-sm w-full mx-4 transition-colors">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
              Enregistrer comme modèle
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Donnez un nom à cette combinaison de médicaments pour la retrouver facilement plus tard.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Nom du modèle <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newModelName}
                  onChange={(e) => setNewModelName(e.target.value)}
                  placeholder="Ex: Asthme aïgu..."
                  className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#642BEF] dark:bg-gray-700 dark:text-white"
                  autoFocus
                />
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button
                onClick={() => {
                  setShowSaveModelForm(false);
                  setNewModelName('');
                }}
                className="flex-1 px-4 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium text-sm"
              >
                Annuler
              </button>
              <button
                onClick={async () => {
                  if (!newModelName.trim()) return;
                  setIsSavingModel(true);
                  try {
                    // Extract methods from context closure directly
                    // This creates a direct Payload Model
                    const mappedPayloadMeds = selectedMedications.map((med, index) => ({
                      medication_id: med.medication_id,
                      custom_medication_id: med.custom_medication_id || null,
                      is_custom: med.is_custom || false,
                      quantity: med.quantity,
                      dosage: med.dosage,
                      note: med.note || undefined,
                      sort_order: index
                    }));
                    
                    const result = await createPrescriptionType({
                      name: newModelName.trim(),
                      medications: mappedPayloadMeds
                    });
                    
                    if (result) {
                      setShowSaveModelForm(false);
                      setNewModelName("");
                    }
                  } catch (e) {
                    console.error("Save as model error:", e);
                  } finally {
                    setIsSavingModel(false);
                  }
                }}
                disabled={!newModelName.trim() || isSavingModel}
                className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[#642BEF] to-[#BF1D8E] text-white rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed font-medium text-sm"
              >
                {isSavingModel ? 'Enregistrement...' : 'Enregistrer'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
