import NewOrUpdatePatient from '@/features/patients/components/NewOrUpdatePatient'
import React from 'react'

export default function page() {
  return <NewOrUpdatePatient backPath={'ordonnance'} nextPath={'ordonnance/confirmation-patient?id='} />
}
