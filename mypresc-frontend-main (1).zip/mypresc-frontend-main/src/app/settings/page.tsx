'use client';

import { useMemo, useState } from 'react';
import Header from '../../components/Header';
import { useTheme } from '../../contexts/ThemeContext';
import { useProfile } from '../../contexts/ProfileContext';
import LanguageSwitcher from '../../components/LanguageSwitcher';
import ExportPrescriptionModal from '../../features/prescriptions/components/modals/ExportPrescriptionModal';
import {
  UserCircleIcon,
  PaintBrushIcon,
  CreditCardIcon,
  ArrowDownTrayIcon,
  QuestionMarkCircleIcon,
  EyeIcon,
  EyeSlashIcon,
  CheckCircleIcon,
  XCircleIcon,
  ComputerDesktopIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '@/contexts/AuthContext';
import { usePrescription } from '@/contexts/PrescriptionContext';
import { usePatients } from '@/contexts/PatientsContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Link from 'next/link';
import { MoonIcon, SunIcon } from 'lucide-react';
import SubscribeModal from '@/components/payment/SubscribeModal';

const frontendUrl = process.env.NEXT_PUBLIC_FRONTEND_URL || 'http://localhost:3001';

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState('account');
  const [showPassword, setShowPassword] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const { profile, updateProfile, loading } = useProfile();
  const { user } = useAuth();
  const { exportPrescriptionData, loading: prescriptionLoading } = usePrescription();
  const { relatedPatients, fetchRelatedPatients, exportPatientData, loading: patientLoading } = usePatients();
  const { t, isRTL } = useLanguage();

  const { theme, setTheme } = useTheme();

  // Password update states
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);

  const [settings, setSettings] = useState({
    phone: profile?.phone_number || '+213 555 123 456',
    emailNotifications: true,
    pushNotifications: false,
    appointmentReminders: true,
    prescriptionAlerts: true,
    twoFactorAuth: false,
    loginAlerts: true,
    language: 'fr',
    timezone: 'Europe/Paris',
    autoSave: true,
    signatureRequired: false,
    requireSignature: false,
    autoSaveNotes: true,
    defaultTemplate: 'standard',
    defaultPrescriptionTemplate: 'standard',
    dataSharing: false
  });

  const isMobile = useMemo(() => typeof window !== 'undefined' && window.innerWidth < 768, []);

  const sections = [
    { id: 'account', name: t('settings.sections.account'), icon: UserCircleIcon },
    { id: 'appearance', name: t('settings.sections.appearance'), icon: PaintBrushIcon },
    { id: 'billing', name: t('settings.sections.billing'), icon: CreditCardIcon },
    { id: 'data', name: t('settings.sections.data'), icon: ArrowDownTrayIcon },
    { id: 'support', name: t('settings.sections.support'), icon: QuestionMarkCircleIcon },
  ];

  const mobileSections = [
    { id: 'account', name: t('settings.sections.account'), icon: UserCircleIcon },
    { id: 'appearance', name: t('settings.sections.appearance'), icon: PaintBrushIcon },
    { id: 'billing', name: t('settings.sections.billing'), icon: CreditCardIcon },
    { id: 'support', name: t('settings.sections.support'), icon: QuestionMarkCircleIcon },
  ];

  const assistantSections = [
    { id: 'account', name: t('settings.sections.account'), icon: UserCircleIcon },
    { id: 'appearance', name: t('settings.sections.appearance'), icon: PaintBrushIcon },
    { id: 'support', name: t('settings.sections.support'), icon: QuestionMarkCircleIcon },
  ];

  const handleSettingChange = (key: string, value: any) => {
    setSettings({ ...settings, [key]: value });
  };

  /**
   * Handle password form field changes
   */
  const handlePasswordChange = (field: string, value: string) => {
    setPasswordData({ ...passwordData, [field]: value });
    // Clear errors when user types
    if (passwordError) setPasswordError('');
    if (passwordSuccess) setPasswordSuccess('');
  };

  /**
   * Validate password form
   */
  const validatePasswordForm = (): boolean => {
    // Check if all fields are filled
    if (!passwordData.currentPassword.trim()) {
      setPasswordError(t('settings.account.errors.currentPasswordRequired'));
      return false;
    }

    if (!passwordData.newPassword.trim()) {
      setPasswordError(t('settings.account.errors.newPasswordRequired'));
      return false;
    }

    if (!passwordData.confirmPassword.trim()) {
      setPasswordError(t('settings.account.errors.confirmPasswordRequired'));
      return false;
    }

    // Check if passwords match
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordError(t('settings.account.errors.passwordMismatch'));
      return false;
    }

    // Check password strength (minimum 6 characters)
    if (passwordData.newPassword.length < 6) {
      setPasswordError(t('settings.account.errors.passwordTooShort'));
      return false;
    }

    // Check if new password is different from current
    if (passwordData.currentPassword === passwordData.newPassword) {
      setPasswordError(t('settings.account.errors.passwordSameAsCurrent'));
      return false;
    }

    return true;
  };

  /**
   * Handle opening the export modal and fetch related patients
   */
  const handleOpenExportModal = async () => {
    setIsExportModalOpen(true);
    await fetchRelatedPatients();
  };

  /**
   * Handle prescription export with patient selection
   */
  const handleExportPrescriptions = async (data: { patients?: string[]; is_all?: boolean }) => {
    await exportPrescriptionData(data);
    setIsExportModalOpen(false);
  };

  /**
   * Handle password update submission
   */
  const handlePasswordUpdate = async () => {
    // Clear previous messages
    setPasswordError('');
    setPasswordSuccess('');

    // Validate form
    if (!validatePasswordForm()) {
      return;
    }

    setIsUpdatingPassword(true);

    try {
      // Call updateProfile with password data
      const success = await updateProfile({
        password: passwordData.newPassword,
        // Note: If backend requires currentPassword, uncomment below:
        currentPassword: passwordData.currentPassword
      });

      if (success) {
        setPasswordSuccess(t('settings.account.passwordUpdated'));
        // Clear form
        setPasswordData({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
      } else {
        setPasswordError(t('settings.account.passwordUpdateFailed'));
      }
    } catch (error: any) {
      console.error('Password update error:', error);

      // Handle specific error messages
      if (error.response?.data?.error) {
        setPasswordError(error.response.data.error);
      } else if (error.response?.status === 401) {
        setPasswordError(t('settings.account.errors.incorrectCurrentPassword'));
      } else if (error.response?.status === 400) {
        setPasswordError(t('settings.account.errors.invalidData'));
      } else {
        setPasswordError(t('settings.account.errors.genericError'));
      }
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  const [isModalOpen, setIsModalOpen] = useState(false);
  const renderContent = () => {
    switch (activeSection) {
      case 'account':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.account.title')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('settings.account.email')}</label>
                    <input
                      type="email"
                      value={profile?.email || 'dr.vikram.kumar@myprescription.fr'}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('settings.account.phone')}</label>
                    <input
                      type="tel"
                      value={profile?.phone_number || settings.phone}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.account.changePassword')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                <div className="space-y-4">
                  {/* Success Message */}
                  {passwordSuccess && (
                    <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                      <CheckCircleIcon className="w-5 h-5 text-green-600 dark:text-green-400" />
                      <p className="text-sm text-green-700 dark:text-green-300">{passwordSuccess}</p>
                    </div>
                  )}

                  {/* Error Message */}
                  {passwordError && (
                    <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                      <XCircleIcon className="w-5 h-5 text-red-600 dark:text-red-400" />
                      <p className="text-sm text-red-700 dark:text-red-300">{passwordError}</p>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('settings.account.currentPassword')}</label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={passwordData.currentPassword}
                        onChange={(e) => handlePasswordChange('currentPassword', e.target.value)}
                        disabled={isUpdatingPassword}
                        className="w-full px-10 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                        placeholder={t('settings.account.currentPasswordPlaceholder')}
                        autoComplete="off"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                        disabled={isUpdatingPassword}
                      >
                        {showPassword ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('settings.account.newPassword')}</label>
                      <input
                        type="password"
                        value={passwordData.newPassword}
                        onChange={(e) => handlePasswordChange('newPassword', e.target.value)}
                        disabled={isUpdatingPassword}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                        placeholder={t('settings.account.newPasswordPlaceholder')}
                        autoComplete="off"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('settings.account.confirmPassword')}</label>
                      <input
                        type="password"
                        value={passwordData.confirmPassword}
                        onChange={(e) => handlePasswordChange('confirmPassword', e.target.value)}
                        disabled={isUpdatingPassword}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                        placeholder={t('settings.account.confirmPasswordPlaceholder')}
                        autoComplete="off"
                      />
                    </div>
                  </div>
                  <button
                    onClick={handlePasswordUpdate}
                    disabled={isUpdatingPassword || loading}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {isUpdatingPassword || loading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                        <span>{t('settings.account.updating')}</span>
                      </>
                    ) : (
                      <span>{t('settings.account.updatePassword')}</span>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        );

      case 'appearance':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.appearance.theme')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                <div className="grid grid-cols-3 gap-4">
                  {
                    [
                      { key: 'light', name: t('settings.appearance.light'), icon: SunIcon },
                      { key: 'dark', name: t('settings.appearance.dark'), icon: MoonIcon },
                      { key: 'system', name: t('settings.appearance.system'), icon: ComputerDesktopIcon }
                    ].map((themeOption) => (
                      <button
                        key={themeOption.key}
                        onClick={() => setTheme(themeOption.key as any)}
                        className={`p-4 rounded-lg border-2 transition-colors 
                          ${theme === themeOption.key
                            ? 'border-blue-600 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                            : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-600'
                          }
                          `}
                      >
                        <themeOption.icon className="w-6 h-6 mx-auto mb-2 text-current" />
                        <p className="text-sm font-medium text-current">{themeOption.name}</p>
                      </button>
                    ))}
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.appearance.language')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                <div>
                  <LanguageSwitcher />
                </div>
              </div>
            </div>
          </div>
        );

      case 'billing':
        return (
          <>
            <div className="space-y-6">
              {profile?.plan ? (
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6">{t('settings.billing.currentSubscription')}</h3>
                  <div className={`bg-gradient-to-r rounded-2xl p-8 text-white transition-colors shadow-xl ${profile.is_plan_expired
                    ? 'from-red-500 to-red-700 dark:from-red-700 dark:to-red-900'
                    : profile.plan === 'test'
                      ? 'from-green-500 to-emerald-600 dark:from-green-700 dark:to-emerald-800'
                      : 'from-blue-500 to-indigo-600 dark:from-blue-700 dark:to-indigo-800'
                    }`}>
                    <div className="flex items-center justify-between">
                      <div className="space-y-3">
                        <h4 className="text-3xl font-bold">
                          {profile.plan === 'test' && t('profile.planTest')}
                          {profile.plan === 'flex' && t('profile.planFlex')}
                          {profile.plan === 'smart' && t('profile.planSmart')}
                          {profile.plan === 'pro' && t('profile.planPro')}
                          {profile.plan && !['test', 'flex', 'smart', 'pro'].includes(profile.plan) && profile.plan}
                        </h4>
                        <p className="text-xl text-white/90 font-semibold">
                          {profile.plan === 'test' && t('profile.freeTrialDays')}
                          {profile.plan === 'flex' && '3 000 DZD'}
                          {profile.plan === 'smart' && '16 800 DZD'}
                          {profile.plan === 'pro' && '30 000 DZD'}
                        </p>
                        <p className="text-white/90 text-base">
                          {profile.is_plan_expired ? (
                            <span className="font-semibold text-lg">{t('profile.planExpired')}</span>
                          ) : (
                            <>
                              {t('settings.billing.expiresOn')}{' '}
                              {profile.end_date
                                ? new Date(profile.end_date).toLocaleDateString(isRTL ? 'ar-DZ' : 'fr-FR', {
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })
                                : t('profile.notProvided')}
                            </>
                          )}
                        </p>
                      </div>
                      <button
                        className="bg-white/20 hover:bg-white/30 px-6 py-3 rounded-lg transition-colors text-base font-semibold"
                        onClick={() => setIsModalOpen(true)}
                      >
                        {profile.plan === 'test'
                          ? t('profile.subscribe')
                          : t('profile.renew')}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.billing.currentSubscription')}</h3>
                  <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                    <p className="text-gray-600 dark:text-gray-400">{t('profile.notProvided')}</p>
                  </div>
                </div>
              )}

              {/* <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.billing.paymentMethods')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
                <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                        <CreditCardIcon className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-gray-100">•••• •••• •••• 1234</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{t('settings.billing.expires')} 12/26</p>
                      </div>
                    </div>
                    <button className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium">
                      {t('settings.billing.edit')}
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <button className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium">
                    {t('settings.billing.addPaymentMethod')}
                  </button>
                </div>
              </div>
            </div> */}
            </div>

            <SubscribeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
          </>
        );

      case 'data':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.data.dataExport')}</h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-white dark:bg-gray-700">
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">{t('settings.data.patientData')}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{t('settings.data.patientDataDesc')}</p>
                    <button
                      onClick={exportPatientData}
                      disabled={patientLoading}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors w-full disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {patientLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                          <span>{t('settings.data.exporting')}</span>
                        </>
                      ) : (
                        <span>{t('settings.data.exportCSV')}</span>
                      )}
                    </button>
                  </div>
                  <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-white dark:bg-gray-700">
                    <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">{t('settings.data.prescriptions')}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{t('settings.data.prescriptionsDesc')}</p>
                    <button onClick={handleOpenExportModal} className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors w-full">
                      {t('settings.data.exportCSV')}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'support':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('settings.support.helpCenter')}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {
                  [
                    { title: t('settings.support.documentation'), desc: t('settings.support.documentationDesc'), link: `${frontendUrl}/aide` },
                    { title: t('settings.support.faq'), desc: t('settings.support.faqDesc'), link: `${frontendUrl}/#faq` },
                    { title: t('settings.support.contactSupport'), desc: t('settings.support.contactSupportDesc'), link: `${frontendUrl}/aide/#contact-form` },
                  ].map((item, index) => (
                    <div key={index} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-6 hover:shadow-md transition-shadow">
                      <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">{item.title}</h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{item.desc}</p>
                      <Link href={item.link} target='_blank' rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 text-sm font-medium">
                        {t('settings.support.access')}
                      </Link>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        );

      default:
        return <div>{t('settings.sectionInDevelopment')}</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex">
      {/* Export Prescription Modal */}
      <ExportPrescriptionModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        onExport={handleExportPrescriptions}
        isLoading={prescriptionLoading}
        patients={relatedPatients}
      />

      <div className="flex-1">
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">{t('settings.title')}</h1>
            <p className="text-gray-600 dark:text-gray-400">{t('settings.subtitle')}</p>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {/* Navigation des sections */}
            <div className="lg:w-64">
              <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4">
                <nav className="space-y-2">
                  {((user?.role === 'doctor' && !isMobile) ? (user?.role === 'doctor' ? sections : assistantSections) : mobileSections).map((section) => (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${activeSection === section.id
                        ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-l-4 border-blue-600'
                        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                    >
                      <section.icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{section.name}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Contenu de la section */}
            <div className="flex-1">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}