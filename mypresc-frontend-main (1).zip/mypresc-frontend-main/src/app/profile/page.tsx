'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
// Header is provided by MainLayout — no need to import here
import { useProfile, Tarification, CreateTarificationData, UpdateTarificationData } from '@/contexts/ProfileContext';
import { useHeaderContext } from '@/contexts/HeaderContext';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  PencilIcon,
  MapPinIcon,
  PhoneIcon,
  EnvelopeIcon,
  CalendarIcon,
  AcademicCapIcon,
  UserGroupIcon,
  ClockIcon,
  ArrowLeftIcon,
  CheckIcon,
  XMarkIcon,
  StarIcon,
  CurrencyDollarIcon,
  PlusIcon,
  TrashIcon
} from '@heroicons/react/24/outline';
import SubscribeModal from '@/components/payment/SubscribeModal';

export default function ProfilePage() {
  const {
    profile,
    loading,
    error,
    updateProfile,
    tarifications,
    tarificationsLoading,
    tarificationsError,
    getTarificationsByDoctor,
    createTarification,
    updateTarification,
    deleteTarification
  } = useProfile();
  const { t, isRTL } = useLanguage();

  const [isEditing, setIsEditing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // subscription modal
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Tarification states
  const [isAddingTarification, setIsAddingTarification] = useState(false);
  const [editingTarificationId, setEditingTarificationId] = useState<number | null>(null);
  const [newTarification, setNewTarification] = useState<CreateTarificationData>({
    service_label: '',
    price: 0
  });
  const [editTarificationData, setEditTarificationData] = useState<UpdateTarificationData>({});

  const [editableData, setEditableData] = useState<{
    phone_number: string;
    work_location: string;
    home_location: string;
    languages: string[];
    work_time: { [day: string]: string };
  }>({
    phone_number: '',
    work_location: '',
    home_location: '',
    languages: [],
    work_time: {}
  });

  // Mobile header back-arrow
  const { setBackMode, clearBackMode } = useHeaderContext();
  useEffect(() => {
    setBackMode({ title: t('profile.profile') || 'Profile', href: '/dashboard' });
    return () => clearBackMode();
  }, [setBackMode, clearBackMode, t]);

  // Initialize editable data when profile loads
  useEffect(() => {
    if (profile) {
      setEditableData({
        phone_number: profile.phone_number || '',
        work_location: profile.work_location || '',
        home_location: profile.home_location || '',
        languages: profile.languages || [],
        work_time: profile.work_time || {}
      });
    }
  }, [profile]);

  // Fetch tarifications on mount if user is a doctor or assistant
  useEffect(() => {
    if (profile?.role === 'doctor' || profile?.role === 'assistant') {
      getTarificationsByDoctor();
    }
  }, [profile?.role, getTarificationsByDoctor]);

  // Tarification handlers
  const handleAddTarification = async () => {
    if (!newTarification.service_label.trim() || newTarification.price < 0) {
      alert(t('profile.fillAllFields'));
      return;
    }

    const result = await createTarification(newTarification);
    if (result) {
      setNewTarification({ service_label: '', price: 0 });
      setIsAddingTarification(false);
    }
  };

  const handleStartEdit = (tarif: Tarification) => {
    setEditingTarificationId(tarif.id);
    setEditTarificationData({
      service_label: tarif.service_label,
      price: tarif.price
    });
  };

  const handleSaveEdit = async () => {
    if (editingTarificationId === null) return;

    const result = await updateTarification(editingTarificationId, editTarificationData);
    if (result) {
      setEditingTarificationId(null);
      setEditTarificationData({});
    }
  };

  const handleCancelEdit = () => {
    setEditingTarificationId(null);
    setEditTarificationData({});
  };

  const handleDeleteTarification = async (id: number) => {
    if (confirm(t('profile.confirmDeleteTarification'))) {
      await deleteTarification(id);
    }
  };

  const handleSave = () => {
    setShowConfirmation(true);
  };

  const confirmSave = async () => {
    setIsSaving(true);

    const updateData: any = {};

    // Add doctor-specific fields if user is a doctor
    if (profile?.role === 'doctor') {
      updateData.phone_number = editableData.phone_number;
      updateData.work_location = editableData.work_location;
      updateData.home_location = editableData.home_location;
      updateData.languages = editableData.languages;
      updateData.work_time = editableData.work_time;
    }

    // Add assistant-specific fields if user is an assistant
    if (profile?.role === 'assistant') {
      updateData.phone_number = editableData.phone_number;
      updateData.work_location = editableData.work_location;
      updateData.work_time = editableData.work_time;
      updateData.doctor_id = profile.id;
    }

    const success = await updateProfile(updateData);

    setIsSaving(false);

    if (success) {
      setIsEditing(false);
      setShowConfirmation(false);
    }
  };

  const cancelSave = () => {
    setShowConfirmation(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset editable data to original profile data
    if (profile) {
      setEditableData({
        phone_number: profile.phone_number || '',
        work_location: profile.work_location || '',
        home_location: profile.home_location || '',
        languages: profile.languages || [],
        work_time: profile.work_time || {}
      });
    }
  };

  // Languages are already an array from the API
  const languagesArray = editableData.languages || [];

  // Work time is already an object from the API, just need to sort by day order
  const getSortedWorkTime = (workTime: { [day: string]: string }) => {
    const dayOrder = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const sorted: Array<[string, string]> = [];

    dayOrder.forEach(day => {
      if (workTime[day] !== undefined) {
        sorted.push([day, workTime[day]]);
      }
    });

    return sorted;
  };

  const sortedWorkingHours = getSortedWorkTime(editableData.work_time);

  const stats = !profile ? [] : [
    { label: t('profile.patientsFollowed'), value: profile?.statistics?.patientsFollowed || "--", icon: UserGroupIcon },
    { label: t('profile.consultationsThisMonth'), value: profile?.statistics?.consultationsThisMonth || "--", icon: CalendarIcon },
    { label: t('profile.yearsOfExperience'), value: profile?.experience ? `${profile.experience}+` : '--', icon: AcademicCapIcon }
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex transition-colors">
      {loading ? (
        <div className="flex-1 flex items-center justify-center h-96">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      ) : error ? (
        <div className="flex-1 flex items-center justify-center h-96">
          <div className="text-red-600 dark:text-red-400">Error: {error}</div>
        </div>
      ) : !profile ? (
        <div className="flex-1 flex items-center justify-center h-96">
          <div className="text-gray-600 dark:text-gray-400">{t('profile.noProfileFound')}</div>
        </div>
      ) : (
      <>
      <div className="flex-1 mb-20">
        <div className="p-2 md:p-6 pt-4">
          {/* Breadcrumb — hidden on mobile (back arrow in header handles it) */}
          <div className="hidden md:flex mt-6 mb-4">
            <Link
              href="/dashboard"
              className="inline-flex items-center text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200 transition-colors"
            >
              <ArrowLeftIcon className={`w-4 h-4 mx-1 ${isRTL ? 'rotate-180' : ''}`} />
              {t('profile.backToDashboard')}
            </Link>
          </div>

          <div className="grid grid-cols-12 gap-2 md:gap-6">

            {/* Colonne principale - Informations du profil */}
            <div className="col-span-12 lg:col-span-8 space-y-2 md:space-y-6 flex flex-col">

              {/* Carte profil principal */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden transition-colors">
                {/* Header with gradient background */}
                <div className="h-32 bg-gradient-to-r from-blue-500 via-purple-500 to-indigo-600 relative flex items-center px-6">
                  {/* Name on Header */}
                  <h1 className="text-3xl font-bold text-white">
                    {profile.role === 'doctor' ? `Dr. ` : ''}{profile.name} {profile.family_name}
                  </h1>

                  <div className="absolute top-4 right-4 flex gap-2">
                    {isEditing ? (
                      <>
                        <button
                          onClick={handleSave}
                          className="p-2 bg-green-500/80 rounded-lg hover:bg-green-600/80 transition-colors"
                          title={t('profile.save')}
                        >
                          <CheckIcon className="w-5 h-5 text-white" />
                        </button>
                        <button
                          onClick={handleCancel}
                          className="p-2 bg-red-500/80 rounded-lg hover:bg-red-600/80 transition-colors"
                          title={t('profile.cancel')}
                        >
                          <XMarkIcon className="w-5 h-5 text-white" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => setIsEditing(true)}
                        className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
                        title={t('profile.editProfile')}
                      >
                        <PencilIcon className="w-5 h-5 text-white" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="px-6 pb-6 pt-6">
                  {/* Doctor/Assistant Info */}
                  <div className="flex flex-col mb-6">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-sm rounded-full">
                        {t('profile.online')}
                      </span>
                      {profile.role === 'doctor' && profile.speciality && (
                        <p className="text-lg text-gray-600 dark:text-gray-300">{profile.speciality}</p>
                      )}
                      {profile.role === 'assistant' && (
                        <p className="text-lg text-gray-600 dark:text-gray-300">{t('profile.medicalAssistant')}</p>
                      )}
                    </div>
                    {profile.role === 'doctor' && profile.order_num && (
                      <p className="text-sm text-gray-500 dark:text-gray-400">{t('profile.orderNum')}: {profile.order_num}</p>
                    )}
                  </div>

                  {/* Bio / About */}
                  {profile.about && (
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">{t('profile.about')}</h3>
                      <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{profile.about}</p>
                    </div>
                  )}

                  {/* Informations de contact */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg transition-colors">
                      <PhoneIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('profile.phone')}</p>
                        {isEditing ? (
                          <input
                            type="tel"
                            value={editableData.phone_number}
                            onChange={(e) => setEditableData({ ...editableData, phone_number: e.target.value })}
                            className="text-sm text-gray-600 dark:text-gray-300 border-b border-gray-300 dark:border-gray-600 focus:border-blue-500 bg-transparent outline-none w-full"
                          />
                        ) : (
                          <p className="text-sm text-gray-600 dark:text-gray-300">{profile.phone_number || t('profile.notProvided')}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg transition-colors">
                      <EnvelopeIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('profile.email')}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-300 break-all overflow-hidden">{profile.email}</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg md:col-span-2 transition-colors">
                      <MapPinIcon className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('profile.workLocation')}</p>
                        {isEditing ? (
                          <textarea
                            value={editableData.work_location}
                            onChange={(e) => setEditableData({ ...editableData, work_location: e.target.value })}
                            className="text-sm text-gray-600 dark:text-gray-300 border border-gray-300 dark:border-gray-600 focus:border-blue-500 bg-transparent outline-none w-full p-2 rounded resize-none"
                            rows={2}
                          />
                        ) : (
                          <p className="text-sm text-gray-600 dark:text-gray-300">{profile.work_location || t('profile.notProvided')}</p>
                        )}
                      </div>
                    </div>

                    {profile.role === 'doctor' && profile.home_location && (
                      <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg md:col-span-2 transition-colors">
                        <MapPinIcon className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('profile.homeLocation')}</p>
                          {isEditing ? (
                            <textarea
                              value={editableData.home_location}
                              onChange={(e) => setEditableData({ ...editableData, home_location: e.target.value })}
                              className="text-sm text-gray-600 dark:text-gray-300 border border-gray-300 dark:border-gray-600 focus:border-blue-500 bg-transparent outline-none w-full p-2 rounded resize-none"
                              rows={2}
                            />
                          ) : (
                            <p className="text-sm text-gray-600 dark:text-gray-300">{profile.home_location}</p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Formation et qualifications - For Doctors Only */}
              {profile.role === 'doctor' && profile.certificates && profile.certificates.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
                    <AcademicCapIcon className="w-6 h-6 mr-2 text-blue-600 dark:text-blue-400" />
                    Formation et Qualifications
                  </h3>
                  <div className="space-y-3">
                    {profile.certificates.map((certificate, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <div className="w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full mt-2"></div>
                        <p className="text-gray-700 dark:text-gray-300">{certificate}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Horaires de travail */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 flex-1 transition-colors">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4 flex items-center">
                  <ClockIcon className="w-6 h-6 mr-2 text-blue-600 dark:text-blue-400" />
                  {t('profile.consultationHours')}
                </h3>
                {isEditing ? (
                  <div className="flex flex-col gap-2">
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{t('profile.editHoursDescription')}</p>
                    <div className="flex flex-col gap-3">
                      {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => {
                        const dayFr = t(`profile.days.${day.toLowerCase()}`);

                        const currentValue = editableData.work_time[day] || '';
                        // Helper to ensure HH:mm format (required for input type="time")
                        const normalizeTime = (timeStr: string): string => {
                          if (!timeStr) return '';
                          let cleanTime = timeStr.trim();

                          // Handle AM/PM
                          const isPM = cleanTime.toLowerCase().includes('pm');
                          const isAM = cleanTime.toLowerCase().includes('am');
                          cleanTime = cleanTime.replace(/[ap]m/i, '').trim();

                          let [hours, minutes] = cleanTime.split(':').map(Number);

                          if (isNaN(hours)) return '00:00';
                          if (isNaN(minutes)) minutes = 0;

                          if (isPM && hours < 12) hours += 12;
                          if (isAM && hours === 12) hours = 0;

                          return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
                        };

                        const isClosed = currentValue === 'Closed' || currentValue === '' || !currentValue;

                        // Parse existing times properly with robust handling
                        let startTime = '08:00';
                        let endTime = '18:00';

                        if (!isClosed && currentValue.includes('-')) {
                          // Split by hyphen, handling potential spaces
                          const parts = currentValue.split('-').map(p => p.trim());
                          if (parts.length >= 2) {
                            const parsedStart = normalizeTime(parts[0]);
                            const parsedEnd = normalizeTime(parts[1]);

                            // Only update if we got valid times
                            if (parsedStart) startTime = parsedStart;
                            if (parsedEnd) endTime = parsedEnd;
                          }
                        }

                        return (
                          <div key={day} className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 border border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-500 transition-colors">
                            {/* Day label row */}
                            <div className="flex items-center justify-between mb-2">
                              <label className="text-sm font-semibold text-gray-800 dark:text-gray-200">{dayFr}</label>
                              {/* Action buttons row (always visible) */}
                              <div className="flex items-center gap-2">
                                {/* 24h/24 button */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditableData({
                                      ...editableData,
                                      work_time: { ...editableData.work_time, [day]: '00:00 - 23:59' }
                                    });
                                  }}
                                  className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 ${currentValue === '00:00 - 23:59'
                                      ? 'bg-green-100 dark:bg-green-900/20 border-2 border-green-300 dark:border-green-800 text-green-700 dark:text-green-400'
                                      : 'bg-white dark:bg-gray-600 border-2 border-gray-300 dark:border-gray-500 hover:border-green-400 dark:hover:border-green-400 text-gray-600 dark:text-gray-300'
                                    }`}
                                >
                                  <ClockIcon className="w-3.5 h-3.5" />
                                  <span>24h</span>
                                </button>
                                {/* Closed toggle */}
                                <label className={`flex items-center gap-1 px-2 py-1.5 rounded-lg cursor-pointer text-xs font-medium transition-all duration-200 ${isClosed
                                    ? 'bg-red-100 dark:bg-red-900/20 border-2 border-red-300 dark:border-red-800 text-red-700 dark:text-red-400'
                                    : 'bg-white dark:bg-gray-600 border-2 border-gray-300 dark:border-gray-500 hover:border-gray-400 dark:hover:border-gray-400 text-gray-600 dark:text-gray-300'
                                  }`}>
                                  <input
                                    type="checkbox"
                                    checked={isClosed}
                                    onChange={(e) => {
                                      setEditableData({
                                        ...editableData,
                                        work_time: {
                                          ...editableData.work_time,
                                          [day]: e.target.checked ? 'Closed' : `${startTime} - ${endTime}`
                                        }
                                      });
                                    }}
                                    className="w-3.5 h-3.5 rounded border-2 border-gray-400 text-red-600 accent-red-600 cursor-pointer"
                                  />
                                  <span>{t('profile.closed')}</span>
                                </label>
                              </div>
                            </div>

                            {/* Time pickers row */}
                            <div className="flex items-center gap-2">
                              <input
                                type="time"
                                lang="en-GB"
                                value={isClosed ? '' : startTime}
                                disabled={isClosed}
                                onChange={(e) => {
                                  const newStartTime = e.target.value;
                                  const currentEnd = isClosed ? '18:00' : endTime;
                                  setEditableData({
                                    ...editableData,
                                    work_time: { ...editableData.work_time, [day]: `${newStartTime} - ${currentEnd}` }
                                  });
                                }}
                                className="flex-1 min-w-0 px-2 py-2 text-sm font-medium border-2 border-gray-300 dark:border-gray-600 rounded-lg
                                         focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 dark:bg-gray-700 dark:text-white outline-none
                                         disabled:bg-gray-200 dark:disabled:bg-gray-600 disabled:text-gray-400 dark:disabled:text-gray-500 disabled:cursor-not-allowed
                                         transition-all duration-200"
                              />
                              <span className="text-gray-400 font-bold shrink-0">→</span>
                              <input
                                type="time"
                                lang="en-GB"
                                value={isClosed ? '' : endTime}
                                disabled={isClosed}
                                onChange={(e) => {
                                  const newEndTime = e.target.value;
                                  const currentStart = isClosed ? '08:00' : startTime;
                                  setEditableData({
                                    ...editableData,
                                    work_time: { ...editableData.work_time, [day]: `${currentStart} - ${newEndTime}` }
                                  });
                                }}
                                className="flex-1 min-w-0 px-2 py-2 text-sm font-medium border-2 border-gray-300 dark:border-gray-600 rounded-lg
                                         focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900 dark:bg-gray-700 dark:text-white outline-none
                                         disabled:bg-gray-200 dark:disabled:bg-gray-600 disabled:text-gray-400 dark:disabled:text-gray-500 disabled:cursor-not-allowed
                                         transition-all duration-200"
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {sortedWorkingHours.map(([day, hours]) => {
                      const dayFr = t(`profile.days.${day.toLowerCase()}`);

                      return (
                        <div key={day} className="flex justify-between items-center p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg transition-colors">
                          <span className="font-medium text-gray-900 dark:text-gray-100">{dayFr}</span>
                          <span className={`text-sm ${hours === 'Closed' || !hours ? 'text-red-600 dark:text-red-400' : 'text-gray-600 dark:text-gray-300'}`}>
                            {(!hours || hours === 'Closed') ? t('profile.closed') : hours}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Colonne latérale - Statistiques et langues */}
            <div className="col-span-12 lg:col-span-4 space-y-2 md:space-y-6 flex flex-col">

              {/* Statistiques - For Doctors Only */}
              {profile.role === 'doctor' && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('profile.statistics')}</h3>
                  <div className="flex flex-col gap-4">
                    {stats.map((stat, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg border border-blue-100 dark:border-blue-900/10">
                        <stat.icon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                          <p className="text-xl font-bold text-gray-900 dark:text-gray-50">{stat.value}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Doctor Information - For Assistants Only */}
              {profile.role === 'assistant' && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('profile.doctorInfo')}</h3>
                  <div className="flex flex-col gap-3">
                    {profile.doctor_name && profile.doctor_family_name && (
                      <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('profile.fullName')}</p>
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                          {t('profile.doctorPrefix')} {profile.doctor_name} {profile.doctor_family_name}
                        </p>
                      </div>
                    )}
                    {profile.doctor_email && (
                      <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('profile.email')}</p>
                        <p className="text-sm text-gray-900 dark:text-gray-100 break-all">{profile.doctor_email}</p>
                      </div>
                    )}
                    {profile.doctor_phone_number && (
                      <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">{t('profile.phone')}</p>
                        <p className="text-sm text-gray-900 dark:text-gray-100">{profile.doctor_phone_number}</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Abonnement - For Doctors Only */}
              {profile.role === 'doctor' && profile.plan && (
                <div className={`bg-gradient-to-r rounded-xl shadow-lg p-6 text-white transition-colors ${profile.is_plan_expired
                  ? 'from-red-500 to-red-700 dark:from-red-700 dark:to-red-900'
                  : profile.plan === 'test'
                    ? 'from-green-500 to-emerald-600 dark:from-green-700 dark:to-emerald-800'
                    : 'from-blue-500 to-indigo-600 dark:from-blue-700 dark:to-indigo-800'
                  }`}>
                  <div className="flex items-center gap-3 mb-4">
                    <StarIcon className="w-6 h-6 text-yellow-300" />
                    <h3 className="text-lg font-semibold">{t('profile.premiumSubscription')}</h3>
                  </div>

                  {profile.is_plan_expired && (
                    <div className="mb-3 p-2 bg-white/20 rounded-lg">
                      <p className="text-sm font-semibold">{t('profile.planExpired')}</p>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div className="bg-white/20 rounded-lg p-3">
                      <p className="text-sm opacity-90">{t('profile.plan')}</p>
                      <p className="font-semibold">
                        {profile.plan === 'test' && t('profile.planTest')}
                        {profile.plan === 'flex' && t('profile.planFlex')}
                        {profile.plan === 'smart' && t('profile.planSmart')}
                        {profile.plan === 'pro' && t('profile.planPro')}
                        {profile.plan && !['test', 'flex', 'smart', 'pro'].includes(profile.plan) && profile.plan}
                      </p>
                    </div>

                    <div className="bg-white/20 rounded-lg p-3">
                      <p className="text-sm opacity-90">{t('profile.pricePaid')}</p>
                      <p className="font-semibold">
                        {profile.plan === 'test' && t('profile.freeTrialDays')}
                        {profile.plan === 'flex' && '3 000 DZD'}
                        {profile.plan === 'smart' && '16 800 DZD'}
                        {profile.plan === 'pro' && '30 000 DZD'}
                      </p>
                    </div>

                    <div className="bg-white/20 rounded-lg p-3">
                      <p className="text-sm opacity-90">{t('profile.endDate')}</p>
                      <p className="font-semibold">
                        {profile.end_date
                          ? new Date(profile.end_date).toLocaleDateString(isRTL ? 'ar-DZ' : 'fr-FR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          })
                          : t('profile.notProvided')}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="inline-flex items-center justify-center gap-2 mt-4 w-full bg-white/20 hover:bg-white/30 transition-colors rounded-lg px-4 py-2 text-sm font-medium"
                  >
                    <span>
                      {profile.plan === 'test' ? t('profile.subscribe') : t('profile.renew')}
                    </span>
                  </button>
                </div>
              )}

              {/* Langues parlées - For Doctors Only */}
              {profile.role === 'doctor' && (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 transition-colors">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">{t('profile.spokenLanguages')}</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={editableData.languages.join(', ')}
                        onChange={(e) => setEditableData({
                          ...editableData,
                          languages: e.target.value.split(',').map(lang => lang.trim()).filter(Boolean)
                        })}
                        placeholder={t('profile.separateLanguages')}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-blue-500 dark:bg-gray-700 dark:text-white outline-none"
                      />
                      <p className="text-xs text-gray-500 dark:text-gray-400">{t('profile.separateLanguages')}</p>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {languagesArray.length > 0 ? (
                        languagesArray.map((language, index) => (
                          <span
                            key={index}
                            className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 text-sm rounded-full capitalize"
                          >
                            {language}
                          </span>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">{t('profile.notProvided')}</p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Tarification Section */}
              {/* Tarification Section */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 flex-1 transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 flex items-center">
                    <CurrencyDollarIcon className="w-6 h-6 mr-2 text-blue-600 dark:text-blue-400" />
                    {t('profile.pricing')}
                  </h3>
                  {!isAddingTarification && (
                    <button
                      onClick={() => setIsAddingTarification(true)}
                      className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      title={t('profile.addPricing')}
                    >
                      <PlusIcon className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {tarificationsError && (
                  <div className="mb-3 p-3 bg-red-50 dark:bg-red-900/40 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-300 text-sm rounded-lg">
                    {tarificationsError}
                  </div>
                )}

                {/* Add new tarification form */}
                {isAddingTarification && (
                  <div className="mb-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600 transition-colors">
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('profile.service')}</label>
                        <input
                          type="text"
                          value={newTarification.service_label}
                          onChange={(e) => setNewTarification({ ...newTarification, service_label: e.target.value })}
                          placeholder={t('profile.servicePlaceholder')}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-blue-500 dark:bg-gray-700 dark:text-white outline-none text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('profile.priceDzd')}</label>
                        <input
                          type="number"
                          value={newTarification.price === 0 ? '0' : newTarification.price || ''}
                          onChange={(e) => setNewTarification({ ...newTarification, price: parseFloat(e.target.value) || 0 })}
                          placeholder="0.00"
                          min="0"
                          step="0.01"
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:border-blue-500 dark:bg-gray-700 dark:text-white outline-none text-sm"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={handleAddTarification}
                          className="flex-1 bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm"
                        >
                          {t('profile.add')}
                        </button>
                        <button
                          onClick={() => {
                            setIsAddingTarification(false);
                            setNewTarification({ service_label: '', price: 0 });
                          }}
                          className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-2 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors text-sm"
                        >
                          {t('profile.cancel')}
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Tarifications list */}
                {tarificationsLoading ? (
                  <div className="flex justify-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-600"></div>
                  </div>
                ) : tarifications.length > 0 ? (
                  <div className="flex flex-col gap-2">
                    {tarifications.map((tarif) => (
                      <div
                        key={tarif.id}
                        className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg border border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-500 transition-colors"
                      >
                        {editingTarificationId === tarif.id ? (
                          // Edit mode
                          <div className="space-y-2">
                            <input
                              type="text"
                              value={editTarificationData.service_label !== undefined ? editTarificationData.service_label : tarif.service_label}
                              onChange={(e) => setEditTarificationData({ ...editTarificationData, service_label: e.target.value })}
                              className="w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm focus:border-blue-500 dark:bg-gray-700 dark:text-white outline-none"
                            />
                            <input
                              type="number"
                              value={editTarificationData.price !== undefined ? editTarificationData.price : tarif.price}
                              onChange={(e) => {
                                const value = e.target.value;
                                // Allow empty string to clear the field
                                if (value === '') {
                                  setEditTarificationData({ ...editTarificationData, price: '' as any });
                                } else {
                                  setEditTarificationData({ ...editTarificationData, price: parseFloat(value) || 0 });
                                }
                              }}
                              className="w-full px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm focus:border-blue-500 dark:bg-gray-700 dark:text-white outline-none"
                              min="0"
                              step="0.01"
                            />
                            <div className="flex gap-2">
                              <button
                                onClick={handleSaveEdit}
                                className="flex-1 bg-green-600 text-white px-2 py-1 rounded text-xs hover:bg-green-700 transition-colors"
                              >
                                {t('profile.save')}
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-2 py-1 rounded text-xs hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                              >
                                {t('profile.cancel')}
                              </button>
                            </div>
                          </div>
                        ) : (
                          // Display mode
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="font-medium text-gray-900 dark:text-gray-100 text-sm">{tarif.service_label}</p>
                              <p className="text-blue-600 dark:text-blue-400 font-semibold text-sm">{tarif.price.toFixed(2)} DZD</p>
                            </div>
                            <div className="flex gap-1">
                              <button
                                onClick={() => handleStartEdit(tarif)}
                                className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/40 rounded transition-colors"
                                title={t('profile.edit')}
                              >
                                <PencilIcon className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteTarification(tarif.id)}
                                className="p-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/40 rounded transition-colors"
                                title={t('profile.delete')}
                              >
                                <TrashIcon className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400 text-center py-4">{t('profile.noPricingDefined')}</p>
                )}
              </div>

            </div>
          </div>
        </div>
      </div>

      {/* Modal de confirmation */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 transition-opacity">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4 shadow-xl">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">{t('profile.confirmModifications')}</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">{t('profile.confirmSaveDescription')}</p>
            <div className="flex gap-3">
              <button
                onClick={confirmSave}
                disabled={isSaving}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSaving ? t('profile.saving') : t('profile.yesConfirm')}
              </button>
              <button
                onClick={cancelSave}
                disabled={isSaving}
                className="flex-1 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t('profile.cancel')}
              </button>
            </div>
          </div>
        </div>
      )}

      <SubscribeModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </>
      )}
    </div>
  );
}
