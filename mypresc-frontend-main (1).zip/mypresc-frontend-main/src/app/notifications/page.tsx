'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { BellIcon, MagnifyingGlassIcon, TrashIcon, CheckIcon, ClockIcon, FunnelIcon, ArrowTopRightOnSquareIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon, ExclamationTriangleIcon, InformationCircleIcon, XCircleIcon } from '@heroicons/react/24/solid';
import { useNotifications, type Notification, type NotificationType } from '../../contexts/NotificationContext';
import { useLanguage } from '@/contexts/LanguageContext';
import logger from '@/utils/logger';

export default function NotificationsPage() {
  const {
    notifications,
    loading,
    error,
    stats,
    getAllNotifications,
    searchNotifications,
    deleteNotification,
    markAsSeen,
    markAllAsSeen,
  } = useNotifications();
  const { t, isRTL } = useLanguage();

  logger.log("Notifications :", notifications);

  const [selectedNotifications, setSelectedNotifications] = useState<string[]>([]);
  const [filter, setFilter] = useState<'all' | 'unseen' | 'seen'>('all');
  const [typeFilter, setTypeFilter] = useState<NotificationType | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch notifications based on filters
  useEffect(() => {
    const fetchData = async () => {
      if (searchTerm.trim()) {
        // Use search functionality
        setIsSearching(true);
        await searchNotifications(searchTerm);
        setIsSearching(false);
      } else {
        // Use filter functionality
        const params: any = {};

        if (filter === 'seen') params.seen = true;
        if (filter === 'unseen') params.seen = false;
        if (typeFilter !== 'all') params.type = typeFilter;

        await getAllNotifications(params);
      }
    };

    fetchData();
  }, [filter, typeFilter]);

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (searchTerm.trim()) {
        setIsSearching(true);
        await searchNotifications(searchTerm);
        setIsSearching(false);
      } else {
        // Reset to filtered view
        const params: any = {};
        if (filter === 'seen') params.seen = true;
        if (filter === 'unseen') params.seen = false;
        if (typeFilter !== 'all') params.type = typeFilter;
        await getAllNotifications(params);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Delete selected notifications
  const deleteSelected = async () => {
    for (const id of selectedNotifications) {
      await deleteNotification(id);
    }
    setSelectedNotifications([]);
  };

  // Delete single notification
  const deleteSingleNotification = async (notificationId: string) => {
    await deleteNotification(notificationId);
    if (selectedNotification?.id === notificationId) {
      setSelectedNotification(null);
    }
    setShowDeleteConfirm(false);
  };

  // Mark selected as seen
  const markSelectedAsSeen = async () => {
    for (const id of selectedNotifications) {
      const notification = notifications.find(n => n.id === id);
      if (notification && !notification.is_seen) {
        await markAsSeen(id);
      }
    }
    setSelectedNotifications([]);
  };

  // Select/deselect all
  const toggleSelectAll = () => {
    if (selectedNotifications.length === notifications.length) {
      setSelectedNotifications([]);
    } else {
      setSelectedNotifications(notifications.map(n => n.id));
    }
  };

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'check':
        return <CheckCircleIcon className="w-5 h-5 text-green-600" />;
      case 'alert':
        return <ExclamationTriangleIcon className="w-5 h-5 text-yellow-600" />;
      case 'error':
        return <XCircleIcon className="w-5 h-5 text-red-600" />;
      case 'info':
      default:
        return <InformationCircleIcon className="w-5 h-5 text-blue-600" />;
    }
  };

  // Get background color
  const getNotificationBgColor = (type: string) => {
    switch (type) {
      case 'check':
        return 'bg-green-100';
      case 'alert':
        return 'bg-yellow-100';
      case 'error':
        return 'bg-red-100';
      case 'info':
      default:
        return 'bg-blue-100';
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

    if (diffInHours < 1) {
      return t('notifications.time.justNow');
    } else if (diffInHours < 24) {
      return t('notifications.time.hoursAgo', { count: diffInHours });
    } else if (diffInHours < 48) {
      return t('notifications.time.yesterday');
    } else {
      const days = Math.floor(diffInHours / 24);
      return t('notifications.time.daysAgo', { count: days });
    }
  };

  // Handle notification click
  const handleNotificationClick = async (notification: Notification) => {
    setSelectedNotification(notification);
    // Auto-mark as seen if unseen
    if (!notification.is_seen) {
      await markAsSeen(notification.id);
    }
  };

  const unseenCount = stats?.unseen || notifications.filter(n => !n.is_seen).length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex transition-colors">

      <div className="flex-1 ml-[100px]">
        <div className="p-6">

          {/* Error Display */}
          {error && (
            <div className="mt-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-600 dark:text-red-400">
              <p>{error}</p>
            </div>
          )}

          {/* Layout à 3 panneaux */}
          <div className="mt-6 grid grid-cols-12 gap-6 h-[calc(100vh-8rem)]">

            {/* Left Panel - Notifications List */}
            <div className="col-span-5 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 flex flex-col transition-colors">
              {/* Header */}
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{t('notifications.title')}</h2>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {t('notifications.unreadCount', { count: unseenCount })}
                  </span>
                </div>

                {/* Search Bar */}
                <div className="relative mb-4">
                  <MagnifyingGlassIcon className={`w-5 h-5 absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-gray-400`} />
                  <input
                    type="text"
                    placeholder={t('notifications.searchPlaceholder')}
                    className={`w-full ${isRTL ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-400 transition-colors`}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                  {isSearching && (
                    <div className={`absolute ${isRTL ? 'left-3' : 'right-3'} top-1/2 transform -translate-y-1/2`}>
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-blue-600"></div>
                    </div>
                  )}
                </div>

                {/* Filters */}
                <div className="flex flex-col gap-2 mb-4">
                  <div className="flex items-center gap-2">
                    <FunnelIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('notifications.filters')}</span>
                  </div>

                  {/* Seen/Unseen Filter */}
                  <div className="flex gap-2">
                    {[
                      { key: 'all', label: t('notifications.filterAll') },
                      { key: 'unseen', label: t('notifications.filterUnseen') },
                      { key: 'seen', label: t('notifications.filterSeen') }
                    ].map((filterOption) => (
                      <button
                        key={filterOption.key}
                        onClick={() => setFilter(filterOption.key as 'all' | 'unseen' | 'seen')}
                        className={`px-3 py-1 text-sm rounded-full transition-colors ${filter === filterOption.key
                          ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                      >
                        {filterOption.label}
                      </button>
                    ))}
                  </div>

                  {/* Type Filter */}
                  <div className="flex gap-2">
                    {[
                      { key: 'all', label: t('notifications.typeAll') },
                      { key: 'info', label: t('notifications.typeInfo') },
                      { key: 'check', label: t('notifications.typeCheck') },
                      { key: 'alert', label: t('notifications.typeAlert') },
                      { key: 'error', label: t('notifications.typeError') }
                    ].map((typeOption) => (
                      <button
                        key={typeOption.key}
                        onClick={() => setTypeFilter(typeOption.key as NotificationType | 'all')}
                        className={`px-2 py-1 text-xs rounded-full transition-colors ${typeFilter === typeOption.key
                          ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                          }`}
                      >
                        {typeOption.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bulk Actions */}
                {selectedNotifications.length > 0 && (
                  <div className="flex gap-2 mb-4">
                    <button
                      onClick={deleteSelected}
                      className="px-3 py-1 text-sm bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-lg hover:bg-red-200 dark:hover:bg-red-900/50 flex items-center gap-1 transition-colors"
                    >
                      <TrashIcon className="w-4 h-4" />
                      {t('notifications.deleteSelected', { count: selectedNotifications.length })}
                    </button>
                  </div>
                )}

                {/* Mark All As Read */}
                {unseenCount > 0 && (
                  <button
                    onClick={() => markAllAsSeen()}
                    className="w-full px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    {t('notifications.markAllRead')}
                  </button>
                )}
              </div>

              {/* Notifications List */}
              <div className="flex-1 overflow-y-auto">
                <div className="p-4">
                  {notifications.length > 0 && (
                    <label className="flex items-center gap-2 mb-4">
                      <input
                        type="checkbox"
                        checked={selectedNotifications.length === notifications.length && notifications.length > 0}
                        onChange={toggleSelectAll}
                        className="rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-gray-700 dark:checked:bg-blue-600"
                      />
                      <span className="text-sm text-gray-600 dark:text-gray-400">{t('notifications.selectAll')}</span>
                    </label>
                  )}

                  {loading ? (
                    <div className="flex items-center justify-center py-12">
                      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
                    </div>
                  ) : notifications.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <BellIcon className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                      <p className="text-lg font-medium mb-2">{t('notifications.noNotifications')}</p>
                      <p>{t('notifications.noNotificationsDesc')}</p>
                    </div>
                  ) : (
                    notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-4 mb-2 rounded-lg cursor-pointer transition-colors ${selectedNotification?.id === notification.id
                          ? 'bg-blue-100 dark:bg-blue-900/30 hover:bg-blue-200 dark:hover:bg-blue-900/40'
                          : !notification.is_seen
                            ? 'bg-blue-50 dark:bg-blue-900/10 border-l-4 border-blue-500 hover:bg-blue-100 dark:hover:bg-blue-900/20'
                            : 'hover:bg-gray-50 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 dark:bg-gray-800'
                          }`}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="checkbox"
                            checked={selectedNotifications.includes(notification.id)}
                            onChange={(e) => {
                              e.stopPropagation();
                              if (e.target.checked) {
                                setSelectedNotifications(prev => [...prev, notification.id]);
                              } else {
                                setSelectedNotifications(prev => prev.filter(id => id !== notification.id));
                              }
                            }}
                            className="mt-1 rounded border-gray-300 dark:border-gray-600 text-blue-600 focus:ring-blue-500 dark:bg-gray-700 dark:checked:bg-blue-600"
                          />

                          <div className="flex-shrink-0 mt-1">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getNotificationBgColor(notification.type)}`}>
                              {getNotificationIcon(notification.type)}
                            </div>
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                              <h3 className={`text-sm font-medium ${!notification.is_seen ? 'text-gray-900 dark:text-gray-100' : 'text-gray-700 dark:text-gray-300'}`}>
                                {notification.title}
                              </h3>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-500">
                                  {formatDate(notification.created_at)}
                                </span>
                                {!notification.is_seen && (
                                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                )}
                              </div>
                            </div>
                            <p className={`text-sm mt-1 line-clamp-2 ${!notification.is_seen ? 'text-gray-800 dark:text-gray-200' : 'text-gray-600 dark:text-gray-400'}`}>
                              {notification.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Right Panel - Notification Detail */}
            <div className="col-span-7 bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 transition-colors">
              {selectedNotification ? (
                <div className="h-full flex flex-col">
                  {/* Header */}
                  <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getNotificationBgColor(selectedNotification.type)}`}>
                            {getNotificationIcon(selectedNotification.type)}
                          </div>
                          <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">{selectedNotification.title}</h1>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <div className="flex items-center gap-1">
                            <ClockIcon className="w-4 h-4" />
                            <span>{formatDate(selectedNotification.created_at)}</span>
                          </div>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${selectedNotification.is_seen ? 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300' : 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300'
                            }`}>
                            {selectedNotification.is_seen ? t('notifications.read') : t('notifications.unread')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => !selectedNotification.is_seen && markAsSeen(selectedNotification.id)}
                          className="p-2 rounded-lg transition-colors text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/30"
                          title={selectedNotification.is_seen ? "Marquer comme non lue" : "Marquer comme lue"}
                        >
                          <CheckIcon className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => setShowDeleteConfirm(true)}
                          className="p-2 rounded-lg transition-colors text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/30"
                          title="Supprimer cette notification"
                        >
                          <TrashIcon className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 p-6 overflow-y-auto">
                    <div className="prose dark:prose-invert max-w-none">
                      <p className="text-gray-700 dark:text-gray-300 leading-relaxed whitespace-pre-wrap">
                        {selectedNotification.description}
                      </p>

                      {/* Link Button */}
                      {selectedNotification.link && (
                        <div className="mt-6">
                          <Link
                            href={selectedNotification.link}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md"
                          >
                            <span>{t('notifications.viewDetails')}</span>
                            <ArrowTopRightOnSquareIcon className="w-4 h-4" />
                          </Link>
                        </div>
                      )}

                      {/* Additional Data */}
                      {selectedNotification.data && Object.keys(selectedNotification.data).length > 0 && (
                        <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg transition-colors">
                          <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100 mb-3">{t('notifications.additionalInfo')}</h3>
                          <div className="flex flex-col gap-2">
                            {Object.entries(selectedNotification.data).map(([key, value]) => (
                              <div key={key} className="flex justify-between text-sm">
                                <span className="font-medium text-gray-600 dark:text-gray-400">{key}:</span>
                                <span className="text-gray-900 dark:text-gray-200">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500 dark:text-gray-400">
                  <div className="text-center">
                    <BellIcon className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">{t('notifications.selectNotification')}</h3>
                    <p>{t('notifications.selectNotificationDesc')}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && selectedNotification && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-2xl max-w-md w-full mx-4 transition-colors">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrashIcon className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{t('notifications.deleteTitle')}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-6">
                {t('notifications.deleteConfirm', { title: selectedNotification.title })}
                <br /><br />
                {t('notifications.irreversible')}
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  {t('notifications.cancel')}
                </button>
                <button
                  onClick={() => deleteSingleNotification(selectedNotification.id)}
                  className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-md"
                >
                  {t('notifications.delete')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
