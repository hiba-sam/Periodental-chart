'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import MiniMonth from '@/components/calendar/MiniMonth';
import { useCalendar, type CalendarView, type CalendarEvent } from '@/contexts/CalendarContext';
import { PlusIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { toast } from '@/components/ui/use-toast';
import { useLanguage } from '@/contexts/LanguageContext';

// Skeleton for calendar grids
const CalendarSkeleton = () => (
  <div className="animate-pulse bg-white dark:bg-gray-800 rounded-lg p-4">
    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>
    <div className="grid grid-cols-7 gap-2">
      {[...Array(35)].map((_, i) => (
        <div key={i} className="h-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
      ))}
    </div>
  </div>
);

// Lazy load heavy calendar components
const CalendarGrid = dynamic(
  () => import('@/components/calendar/CalendarGrid'),
  { loading: () => <CalendarSkeleton />, ssr: false }
);

const DayViewGrid = dynamic(
  () => import('@/components/calendar/DayViewGrid'),
  { loading: () => <CalendarSkeleton />, ssr: false }
);

const MonthViewGrid = dynamic(
  () => import('@/components/calendar/MonthViewGrid'),
  { loading: () => <CalendarSkeleton />, ssr: false }
);

const EventDetailsPanel = dynamic(
  () => import('@/components/calendar/EventDetailsPanel'),
  { ssr: false }
);

const EventModal = dynamic(
  () => import('@/components/calendar/EventModal'),
  { ssr: false }
);

const DeleteConfirmModal = dynamic(
  () => import('@/components/calendar/DeleteConfirmModal'),
  { ssr: false }
);

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function CalendarPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { t, isRTL, language } = useLanguage();
  const {
    selectedDate,
    selectedEvent,
    calendarView,
    setSelectedDate,
    setCalendarView,
    goToToday,
    goPrevious,
    goNext,
    selectEvent,
    deleteEvent,
    loading,
  } = useCalendar();

  // ============================================================================
  // LOCAL STATE
  // ============================================================================

  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDayViewModalOpen, setIsDayViewModalOpen] = useState(false);
  const [modalInitialDate, setModalInitialDate] = useState<Date | undefined>();
  const [modalInitialTime, setModalInitialTime] = useState<string | undefined>();
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [dayViewDate, setDayViewDate] = useState<Date>(new Date());

  // Preselected patient data from query params
  const [preselectedPatient, setPreselectedPatient] = useState<{
    id: string;
    name: string;
    familyName: string;
  } | null>(null);
  const [preselectedEventType, setPreselectedEventType] = useState<'patient' | null>(null);
  const [returnPatientId, setReturnPatientId] = useState<string | null>(null);
  const [showPatientAlert, setShowPatientAlert] = useState(false);


  // ============================================================================
  // HANDLE QUERY PARAMS FOR PRESELECTED PATIENT
  // ============================================================================

  useEffect(() => {
    // Parse query params on mount
    const patientId = searchParams.get('patientId');
    const patientName = searchParams.get('patientName');
    const patientFamilyName = searchParams.get('patientFamilyName');
    const eventType = searchParams.get('eventType');

    if (patientId && patientName && patientFamilyName) {
      // Set preselected patient data - keep it in state for later use
      setPreselectedPatient({
        id: patientId,
        name: patientName,
        familyName: patientFamilyName,
      });

      // Store patient ID for back navigation
      setReturnPatientId(patientId);

      // Set event type if specified
      if (eventType === 'patient') {
        setPreselectedEventType('patient');
      }

      // Show banner alert for 3 seconds
      setShowPatientAlert(true);
      const alertTimer = setTimeout(() => {
        setShowPatientAlert(false);
      }, 3000);

      // Show 3-second success alert for selected patient
      const toastInstance = toast.success(
        `${t('calendar.patientSelected')}: ${patientName} ${patientFamilyName} ${t('calendar.selectedFor')}`,
        t('calendar.patientSelected')
      );

      // Auto-dismiss toast after 3 seconds
      setTimeout(() => {
        toastInstance.dismiss();
      }, 3000);

      // DO NOT auto-open the modal - let user choose a time slot first

      return () => {
        clearTimeout(alertTimer);
      };
    }
  }, [searchParams]);

  const getWeekStart = (date: Date): Date => {
    const d = new Date(date);
    const day = d.getDay();
    // Saturday = 6, Sunday = 0, Monday = 1, etc.
    // We want to go back to the most recent Saturday (or stay on Saturday if today is Saturday)
    // If today is Saturday (6), diff = 0
    // If today is Sunday (0), diff = -1 (go back 1 day to Saturday)
    // If today is Monday (1), diff = -2 (go back 2 days to Saturday)
    // If today is Tuesday (2), diff = -3, etc.
    const diff = day === 6 ? 0 : -(day + 1);
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
  };
  // ============================================================================
  // COMPUTED VALUES
  // ============================================================================

  /**
   * Format current period label based on view
   */
  const currentLabel = useMemo(() => {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';

    if (calendarView === 'month') {
      return selectedDate.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
    }
    if (calendarView === 'week') {
      const weekStart = getWeekStart(selectedDate);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 6);
      return `${weekStart.toLocaleDateString(locale, {
        day: '2-digit',
        month: 'short',
      })} - ${weekEnd.toLocaleDateString(locale, {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      })}`;
    }
    return selectedDate.toLocaleDateString(locale, {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  }, [selectedDate, calendarView, language]);

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================



  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  /**
   * Open create event modal
   */
  const handleCreateEventClick = () => {
    setEditingEvent(null);
    setModalInitialDate(selectedDate);
    setModalInitialTime(undefined);
    setIsEventModalOpen(true);
  };

  /**
   * Handle slot click in calendar grid
   */
  const handleSlotClick = (date: Date, time: string) => {
    setEditingEvent(null);
    setModalInitialDate(date);
    setModalInitialTime(time);
    setIsEventModalOpen(true);
  };

  /**
   * Handle event click in calendar grid
   */
  const handleEventClick = (event: CalendarEvent) => {
    selectEvent(event);
  };

  /**
   * Handle edit button click in details panel
   */
  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setModalInitialDate(undefined);
    setModalInitialTime(undefined);
    setIsEventModalOpen(true);
  };

  /**
   * Handle delete button click in details panel
   */
  const handleDeleteEventClick = (event: CalendarEvent) => {
    setIsDeleteModalOpen(true);
  };

  /**
   * Confirm delete action
   */
  const handleConfirmDelete = async () => {
    if (!selectedEvent) return;

    setIsDeleting(true);
    try {
      const success = await deleteEvent(selectedEvent.id);
      if (success) {
        setIsDeleteModalOpen(false);
        selectEvent(null);
      }
    } finally {
      setIsDeleting(false);
    }
  };

  /**
   * Handle mini calendar date selection
   */
  const handleMiniCalendarDateChange = (date: Date) => {
    // Create a new Date object to prevent reference issues
    const newDate = new Date(date);
    setSelectedDate(newDate);

    // Auto-switch to day view when selecting a specific date
    setCalendarView('day');

    // Clear any selected event when changing dates
    selectEvent(null);
  };

  /**
   * Handle mini calendar month change
   */
  const handleMiniCalendarMonthChange = (date: Date) => {
    // Create a new Date object to prevent reference issues
    const newDate = new Date(date);
    setSelectedDate(newDate);

    // Clear any selected event when changing months
    selectEvent(null);
  };

  /**
   * Handle day click in month view - opens DayViewModal
   */
  const handleMonthDayClick = (date: Date) => {
    setSelectedDate(date);
    setDayViewDate(date);
    setCalendarView('day');

    selectEvent(null);
  };


  /**
   * Handle event modal close
   */
  const handleEventModalClose = (wasSuccessfulCreation?: boolean) => {
    setIsEventModalOpen(false);
    setEditingEvent(null);
    setModalInitialDate(undefined);
    setModalInitialTime(undefined);

    // Ne PAS rediriger automatiquement - laisser l'utilisateur choisir
    // Il peut utiliser le bouton "Retour au dossier patient" s'il le souhaite
    
    // Clear preselected patient data only if appointment was created
    if (wasSuccessfulCreation) {
      setPreselectedPatient(null);
      setPreselectedEventType(null);
    }

    // Reset selected event to prevent stale data
    selectEvent(null);
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900 transition-colors">
      <div className={`flex-1 flex flex-col overflow-hidden ${isRTL ? 'mr-[60px]' : 'ml-[60px]'} px-4`}>
        {/* <Header /> */}

        <div className="flex-1 overflow-y-auto p-4">
          <div className="mx-auto">
            {/* Main Grid Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-3">
              {/* ============================================
                  LEFT SIDEBAR
                  ============================================ */}
              <div className="lg:col-span-1 space-y-3">
                {/* View Mode Tabs */}
                <div className="flex gap-2 rounded-3xl border dark:border-gray-700 bg-white dark:bg-gray-800 p-1">
                  <button
                    onClick={() => setCalendarView('day')}
                    className={`
                        px-4 py-2 rounded-full text-sm font-medium transition-colors flex-1 text-center  
                        ${calendarView === 'day'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }
                      `}
                  >
                    {t('calendar.day')}
                  </button>
                  <button
                    onClick={() => setCalendarView('week')}
                    className={`
                        px-4 py-2 rounded-full text-sm font-medium transition-colors flex-1 text-center
                        ${calendarView === 'week'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }
                      `}
                  >
                    {t('calendar.week')}
                  </button>
                  <button
                    onClick={() => setCalendarView('month')}
                    className={`
                        px-4 py-2 rounded-full text-sm font-medium transition-colors flex-1 text-center
                        ${calendarView === 'month'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }
                      `}
                  >
                    {t('calendar.month')}
                  </button>
                </div>

                {/* Mini Month Calendar */}
                <MiniMonth
                  activeDate={selectedDate}
                  onSelectDate={handleMiniCalendarDateChange}
                  onChangeMonth={handleMiniCalendarMonthChange}
                />

                {/* Event Details Panel - shows when event is selected */}
                {selectedEvent && (
                  <EventDetailsPanel
                    event={selectedEvent}
                    onEdit={handleEditEvent}
                    onDelete={handleDeleteEventClick}
                  />
                )}
              </div>

              {/* ============================================
                  MAIN CALENDAR AREA
                  ============================================ */}
              <div className="lg:col-span-4 space-y-4">
                {/* Compact Patient Alert - Auto-dismisses after 3s */}
                {preselectedPatient && showPatientAlert && (
                  <div className="bg-blue-600 rounded-lg shadow-md px-4 py-2.5 text-white animate-in fade-in slide-in-from-top-2 duration-300">
                    <div className="flex items-center gap-2">
                      <div className="flex-shrink-0 w-7 h-7 bg-white/20 rounded-full flex items-center justify-center">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-semibold">
                          {t('calendar.patientSelected')}: {preselectedPatient.name} {preselectedPatient.familyName}
                        </p>
                      </div>
                      <button
                        onClick={() => setShowPatientAlert(false)}
                        className="flex-shrink-0 p-1 hover:bg-white/20 rounded-full transition-colors"
                        aria-label={t('calendar.close')}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  </div>
                )}

                {/* Header with Navigation and Create Button */}
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 transition-colors">
                  <div className="flex items-center justify-between">
                    {/* Navigation Controls */}
                    <div className="flex items-center gap-4">
                      <button
                        onClick={goPrevious}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                        aria-label={t('calendar.previous')}
                      >
                        <svg
                          className={`w-5 h-5 text-gray-600 dark:text-gray-400 ${isRTL ? 'rotate-180' : ''}`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M15 19l-7-7 7-7"
                          />
                        </svg>
                      </button>

                      <button
                        onClick={goToToday}
                        className="px-4 py-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 rounded-md text-sm font-medium transition-colors"
                      >
                        {t('calendar.today')}
                      </button>

                      <button
                        onClick={goNext}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors"
                        aria-label={t('calendar.next')}
                      >
                        <svg
                          className={`w-5 h-5 text-gray-600 dark:text-gray-400 ${isRTL ? 'rotate-180' : ''}`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 5l7 7-7 7"
                          />
                        </svg>
                      </button>

                      <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100 capitalize">{currentLabel}</h2>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-3">
                      {/* Back to Patient Page Button - only show when coming from patient page */}
                      {returnPatientId && (
                        <button
                          onClick={() => router.push(`/patients/${returnPatientId}`)}
                          className="
                            flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md
                            hover:bg-gray-700 transition-colors font-medium text-sm
                            focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2
                          "
                        >
                          <ArrowLeftIcon className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                          {t('calendar.backToPatient')}
                        </button>
                      )}

                      {/* Create Event Button */}
                      <button
                        onClick={handleCreateEventClick}
                        className="
                          flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md
                          hover:bg-blue-700 transition-colors font-medium text-sm
                          focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
                        "
                      >
                        <PlusIcon className="w-5 h-5" />
                        {t('calendar.newAppointment')}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Week View */}
                {calendarView === 'week' && (
                  <CalendarGrid
                    onSlotClick={handleSlotClick}
                    onEventClick={handleEventClick}
                  />
                )}

                {/* Day View */}
                {calendarView === 'day' && (
                  <DayViewGrid onSlotClick={handleSlotClick} onEventClick={handleEventClick} />
                )}

                {/* Month View */}
                {calendarView === 'month' && (
                  <MonthViewGrid onDayClick={handleMonthDayClick} onEventClick={handleEventClick} />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ============================================
          MODALS
          ============================================ */}

      {/* Event Create/Edit Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={handleEventModalClose}
        initialDate={modalInitialDate}
        initialTime={modalInitialTime}
        editEvent={editingEvent}
        preselectedPatient={preselectedPatient}
        preselectedEventType={preselectedEventType}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        event={selectedEvent}
        isDeleting={isDeleting}
      />
    </div>
  );
}