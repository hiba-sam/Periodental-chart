'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import { Loader2 } from 'lucide-react';

export default function AdminProtectedRoute({ children }: { children: React.ReactNode }) {
    const { admin, loading } = useAdminAuth();
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        // Si pas en cours de chargement et pas authentifié
        if (!loading && !admin) {
            // Sauvegarder l'URL de destination pour rediriger après login
            const returnUrl = encodeURIComponent(pathname || '/admin/registrations');
            router.push(`/admin/login?returnUrl=${returnUrl}`);
        }
    }, [admin, loading, router, pathname]);

    // Afficher un loader pendant la vérification
    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
                    <p className="text-gray-600">Vérification de l'authentification...</p>
                </div>
            </div>
        );
    }

    // Si pas authentifié, ne rien afficher (redirection en cours)
    if (!admin) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
                    <p className="text-gray-600">Redirection...</p>
                </div>
            </div>
        );
    }

    // Si authentifié, afficher le contenu
    return <>{children}</>;
}
