"use client";

import { ReactNode, useEffect } from "react";
import { createPortal } from "react-dom";
import { XMarkIcon } from "@heroicons/react/24/outline";

type ModalProps = {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  className?: string; // extra classes for the dialog container
  closeOnBackdrop?: boolean;
  showCloseIcon?: boolean;
  zIndex?: number; // override stacking order
};

export default function Modal({
  isOpen,
  onClose,
  children,
  title,
  className,
  closeOnBackdrop = true,
  showCloseIcon = true,
  zIndex = 10000,
}: ModalProps) {
  // Lock body scroll when open
  useEffect(() => {
    if (!isOpen) return;

    // Store previous values
    const originalStyle = window.getComputedStyle(document.body).overflow;

    // Lock scroll on both html and body to be safe
    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = originalStyle;
      document.documentElement.style.overflow = "";
    };
  }, [isOpen]);

  // Close on ESC
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen, onClose]);

  if (!isOpen || typeof window === "undefined") return null;

  const overlayStyle = { zIndex } as React.CSSProperties;

  return createPortal(
    <div
      className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur overflow-y-auto py-8"
      style={overlayStyle}
      onClick={() => closeOnBackdrop && onClose()}
    >
      <div
        className={`w-full max-w-3xl mx-4 my-auto rounded-2xl bg-white dark:bg-gray-800 shadow-2xl ${className || ""}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="max-h-[90vh] overflow-y-auto">
          <div className="p-8">
            <div className="flex items-center justify-between mb-6">
              {title ? (
                <h3 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">{title}</h3>
              ) : (
                <span />
              )}
              {showCloseIcon && (
                <button
                  aria-label="Fermer"
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                  onClick={onClose}
                >
                  <XMarkIcon className="w-6 h-6" />
                </button>
              )}
            </div>
            {children}
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}


