'use client';

import { useState, useEffect } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function NetworkStatusPopup() {
  const [isOffline, setIsOffline] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    // Check initial status
    setIsOffline(!navigator.onLine);

    const handleOffline = () => {
      setIsOffline(true);
      setIsReconnecting(false);
    };

    const handleOnline = () => {
      setIsReconnecting(true);
      // Small delay to show reconnection message before hiding
      setTimeout(() => {
        setIsOffline(false);
        setIsReconnecting(false);
      }, 1500);
    };

    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  const handleReload = () => {
    window.location.reload();
  };

  if (!isOffline) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-md mx-4 overflow-hidden bg-white dark:bg-gray-800 rounded-2xl shadow-2xl animate-in fade-in zoom-in duration-300">
        {/* Header with icon */}
        <div className="flex flex-col items-center pt-8 pb-4">
          <div className={`p-4 rounded-full ${isReconnecting ? 'bg-green-100 dark:bg-green-900/30' : 'bg-red-100 dark:bg-red-900/30'} mb-4`}>
            {isReconnecting ? (
              <RefreshCw className="w-12 h-12 text-green-600 dark:text-green-400 animate-spin" />
            ) : (
              <WifiOff className="w-12 h-12 text-red-600 dark:text-red-400 animate-pulse" />
            )}
          </div>
          
          <h2 className={`text-xl font-bold ${isReconnecting ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>
            {isReconnecting 
              ? t('network.reconnecting') 
              : t('network.disconnected')
            }
          </h2>
        </div>

        {/* Content */}
        <div className="px-6 pb-6 text-center">
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {isReconnecting 
              ? t('network.reconnectingMessage')
              : t('network.disconnectedMessage')
            }
          </p>

          {!isReconnecting && (
            <>
              {/* Tips */}
              <div className="p-4 mb-6 text-sm text-left bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <p className="font-medium text-gray-700 dark:text-gray-200 mb-2">
                  {t('network.tips')}
                </p>
                <ul className="space-y-1 text-gray-600 dark:text-gray-400">
                  <li>• {t('network.tip1')}</li>
                  <li>• {t('network.tip2')}</li>
                  <li>• {t('network.tip3')}</li>
                </ul>
              </div>

              {/* Reload button */}
              <button
                onClick={handleReload}
                className="w-full px-6 py-3 font-semibold text-white transition-all duration-200 bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                {t('network.reload')}
              </button>
            </>
          )}
        </div>

        {/* Animated bottom bar */}
        <div className={`h-1 ${isReconnecting ? 'bg-green-500' : 'bg-red-500'}`}>
          <div className="h-full bg-white/30 animate-pulse" />
        </div>
      </div>
    </div>
  );
}
