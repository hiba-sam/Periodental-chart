"use client";

import { useAppointments, useAppointmentsContext } from '@/contexts/AppointmentContext';
import { useState, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { XMarkIcon, PhoneIcon, ClockIcon, CheckCircleIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';
import Link from 'next/link';
import ConfirmDialog from '@/components/ui/ConfirmDialog';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePatients } from '@/contexts/PatientsContext';
import { useWaitingRoom } from '@/contexts/WaitingRoomContext';
import { useCalendar } from '@/contexts/CalendarContext';
import socketClient from '@/utils/socketClient';

type UiAppointment = {
  id: string;
  patientName: string;
  patientPhone?: string;
  date: Date;
  time: string;
  duration?: number;
  notes?: string | null;
  confirmed_coming?: boolean;
  venue_confirmed?: boolean;
  consultation_done?: boolean;
};

export default function UpcomingAppointments() {
  const { appointments, fetchAppointments } = useAppointmentsContext();
  const { patients } = usePatients();
  const { user } = useAuth();
  const { t, formatDate, locale } = useLanguage();
  const { createEntry, entries, fetchEntries, getTodaySchedule, currentCall } = useWaitingRoom();
  const { refreshEvents } = useCalendar();
  const [activeAppointment, setActiveAppointment] = useState<UiAppointment | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [updatingStatus, setUpdatingStatus] = useState(false);

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Socket.IO Integration for real-time appointment updates
  useEffect(() => {
    const handleAppointmentChange = (data: any) => {
      console.log('[UpcomingAppointments] Received appointment update:', data);
      fetchAppointments();
    };

    const attachListeners = () => {
      const socket = socketClient.getSocket();
      if (!socket) return;

      console.log('[UpcomingAppointments] Attaching appointment listeners');
      socket.off('appointment:created', handleAppointmentChange);
      socket.off('appointment:updated', handleAppointmentChange);
      socket.off('appointment:deleted', handleAppointmentChange);

      socket.on('appointment:created', handleAppointmentChange);
      socket.on('appointment:updated', handleAppointmentChange);
      socket.on('appointment:deleted', handleAppointmentChange);
    };

    // Attach listeners immediately if already connected
    attachListeners();

    // Also attach when socket connects/reconnects
    const cleanupOnConnect = socketClient.onConnect(attachListeners);

    return () => {
      cleanupOnConnect();
      const socket = socketClient.getSocket();
      if (socket) {
        socket.off('appointment:created', handleAppointmentChange);
        socket.off('appointment:updated', handleAppointmentChange);
        socket.off('appointment:deleted', handleAppointmentChange);
      }
    };
  }, [fetchAppointments]);

  // ESC pour fermer le modal
  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => e.key === 'Escape' && setIsModalOpen(false);
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, []);

  // Prevents body scrolling when the modal is open
  useEffect(() => {
    if (isModalOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isModalOpen]);

  // Handler for opening the modal with specific appointment data
  const handleOpenModal = (appointment: UiAppointment) => {
    setActiveAppointment(appointment);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setActiveAppointment(null);
  };

  const { deleteAppointment, updateAppointment } = useAppointments();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const handleAskDelete = () => setConfirmOpen(true);
  const handleCancelDelete = () => setConfirmOpen(false);
  const handleConfirmDelete = () => {
    if (activeAppointment) {
      // Call delete and close both dialogs; ignore result handling for now
      deleteAppointment(activeAppointment.id);
      setConfirmOpen(false);
      handleCloseModal();
    }
  };

  // Handler to toggle venue_confirmed status (patient confirmed they will come)
  const handleToggleConfirmation = async () => {
    if (!activeAppointment) return;

    setUpdatingStatus(true);
    const appointmentData = appointments.find(a => a.id === activeAppointment.id);
    if (appointmentData) {
      const newStatus = !(appointmentData as any).venue_confirmed;
      await updateAppointment(activeAppointment.id, { venue_confirmed: newStatus } as any);

      // Update local state
      setActiveAppointment({
        ...activeAppointment,
        venue_confirmed: newStatus
      });

      // Sync with calendar
      await refreshEvents();
    }
    setUpdatingStatus(false);
  };

  // The modal component to show details of one appointment
  const DetailsModal = () => {
    if (!activeAppointment) return null;

    return (
      <div
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 "
        onClick={handleCloseModal}
      >
        <div
          className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-xl"
          style={{ maxWidth: 450, width: '90%' }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between pb-4 border-b border-gray-100 dark:border-gray-700">
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
              {t('dashboard.appointmentDetails')}
            </h3>
            <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300" onClick={handleCloseModal}>
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>

          <div className="p-4 space-y-4">
            <div className="flex items-center space-x-3">
              <span className="font-semibold text-gray-700 dark:text-gray-300">{t('common.patient')}:</span>
              <p className="font-bold text-gray-900 dark:text-gray-100">{activeAppointment.patientName}</p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="font-semibold text-gray-700 dark:text-gray-300">{t('common.date')}:</span>
              <p className="text-gray-600 dark:text-gray-400">{formatDate(activeAppointment.date)}</p>
            </div>
            <div className="flex items-center space-x-3">
              <span className="font-semibold text-gray-700 dark:text-gray-300">{t('common.time')}:</span>
              <p className="text-gray-600 dark:text-gray-400">{activeAppointment.time}</p>
            </div>
            {activeAppointment.patientPhone && (
              <div className="flex items-center space-x-3">
                <PhoneIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                <span className="font-semibold text-gray-700 dark:text-gray-300">{t('common.phone')}:</span>
                <p className="text-gray-600 dark:text-gray-400">{activeAppointment.patientPhone}</p>
              </div>
            )}
            {activeAppointment.duration && (
              <div className="flex items-center space-x-3">
                <ClockIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                <span className="font-semibold text-gray-700 dark:text-gray-300">{t('dashboard.duration')}:</span>
                <p className="text-gray-600 dark:text-gray-400">{activeAppointment.duration} min</p>
              </div>
            )}
            {activeAppointment.notes && (
              <div className="flex items-start space-x-3">
                <span className="font-semibold text-gray-700 dark:text-gray-300">{t('common.notes')}:</span>
                <p className="italic text-gray-600 dark:text-gray-400">"{activeAppointment.notes}"</p>
              </div>
            )}
            <div className="flex items-center space-x-3">
              <span className="font-semibold text-gray-700 dark:text-gray-300">{t('dashboard.status')}:</span>
              <div className="flex gap-2">
                {activeAppointment.venue_confirmed ? (
                  <span className="px-2 py-1 text-xs font-medium text-green-800 dark:text-green-200 bg-green-100 dark:bg-green-900/50 rounded-full">
                    {t('dashboard.confirmed')}
                  </span>
                ) : (
                  <span className="px-2 py-1 text-xs font-medium text-orange-800 dark:text-orange-200 bg-orange-100 dark:bg-orange-900/50 rounded-full">
                    {t('dashboard.notConfirmed')}
                  </span>
                )}
                {activeAppointment.confirmed_coming && (
                  <span className="px-2 py-1 text-xs font-medium text-purple-800 dark:text-purple-200 bg-purple-100 dark:bg-purple-900/50 rounded-full">
                    {t('dashboard.arrived')}
                  </span>
                )}
                {activeAppointment.consultation_done && (
                  <span className="px-2 py-1 text-xs font-medium text-blue-800 dark:text-blue-200 bg-blue-100 dark:bg-blue-900/50 rounded-full">
                    {t('dashboard.completedConsultation')}
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-end gap-3 px-4 py-2 ">
            <button
              onClick={handleToggleConfirmation}
              disabled={updatingStatus}
              className="px-4 flex-1 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {updatingStatus ? t('dashboard.updating') : (activeAppointment.venue_confirmed ? t('dashboard.notConfirmed') : t('dashboard.confirmed'))}
            </button>
            <button
              onClick={async () => {
                if (user?.id && activeAppointment) {
                  // Toggle confirmed_coming + arrived_at
                  const newStatus = !activeAppointment.confirmed_coming;
                  const arrivedAt = newStatus ? new Date().toISOString() : null;
                  await updateAppointment(activeAppointment.id, {
                    confirmed_coming: newStatus,
                    arrived_at: arrivedAt
                  } as any);
                  await getTodaySchedule(user.id);
                  await fetchAppointments(); // Rafraîchir pour le compteur salle d'attente
                  await refreshEvents(); // Sync avec le calendrier
                  setActiveAppointment({ ...activeAppointment, confirmed_coming: newStatus });
                  if (newStatus) handleCloseModal();
                }
              }}
              className={`px-4 flex-1 py-2 text-sm font-medium text-white rounded-md ${activeAppointment.confirmed_coming ? 'bg-orange-600 hover:bg-orange-700' : 'bg-green-600 hover:bg-green-700'}`}
            >
              {activeAppointment.confirmed_coming ? t('dashboard.cancelArrival') : t('dashboard.arrived')}
            </button>
            <button className="px-4 flex-1 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700" onClick={handleAskDelete}>
              {t('common.delete')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Helper function to check if appointment is past, current, or upcoming
  // "En cours" seulement si ce RDV est le patient actuellement en consultation
  const getAppointmentStatus = (apptId: string, apptDate: Date, apptTime: string, isDone?: boolean) => {
    // Si le RDV est terminé (is_done), il est passé
    if (isDone) return 'past';

    // "En cours" uniquement si ce patient est actuellement en consultation
    if (currentCall && currentCall.type === 'appointment') {
      const appt = appointments.find(a => a.id === apptId);
      if (appt && appt.patient_id === currentCall.patientId) {
        return 'current';
      }
    }

    const today = new Date();
    const [hours, minutes] = apptTime.split(':').map(Number);
    const apptDateTime = new Date(apptDate);
    apptDateTime.setHours(hours, minutes, 0, 0);

    const currentDateTime = new Date(today);
    const diffMinutes = (apptDateTime.getTime() - currentDateTime.getTime()) / (1000 * 60);

    // Passé si plus de 30 min après l'heure du RDV
    if (diffMinutes < -30) return 'past';
    return 'upcoming';
  };

  // Filter appointments for TODAY only and sort by time
  const todayAppointments: UiAppointment[] = appointments
    .filter((appt) => {
      const d = appt.date instanceof Date ? appt.date : new Date(appt.date as any);
      const today = new Date();
      return (
        d.getDate() === today.getDate() &&
        d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear()
      );
    })
    .map((appt) => {
      const d = appt.date instanceof Date ? appt.date : new Date(appt.date as any);
      const name = `${(appt as any).patient_name || ''} ${(appt as any).patient_family_name || ''}`.trim();
      const time = (appt.time || '').slice(0, 5);

      // Find patient phone
      const patient = patients.find(p => p.id === appt.patient_id);

      return {
        id: appt.id,
        patientName: name || (appt as any).patientId || 'Patient',
        patientPhone: patient?.phone,
        date: d,
        time,
        duration: appt.duration || 30,
        notes: appt.notes as any,
        confirmed_coming: appt.confirmed_coming,
        venue_confirmed: (appt as any).venue_confirmed,
        consultation_done: appt.is_done,
      } as UiAppointment;
    })
    .sort((a, b) => {
      // Sort by time
      const [aHours, aMinutes] = a.time.split(':').map(Number);
      const [bHours, bMinutes] = b.time.split(':').map(Number);
      return (aHours * 60 + aMinutes) - (bHours * 60 + bMinutes);
    });

  return (
    <>
      {isModalOpen && typeof window !== 'undefined' && createPortal(<DetailsModal />, document.body)}
      <ConfirmDialog
        isOpen={confirmOpen}
        title={t('dashboard.deleteAppointment')}
        description={<span>{t('dashboard.deleteConfirmation')}</span>}
        confirmText={t('common.delete')}
        cancelText={t('common.cancel')}
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
      />

      {/* Main Block */}
      <div
        id="upcoming-appointments-block"
        className="flex flex-col h-full min-h-[400px] mb-8 overflow-hidden bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-700">
          <div>
            <h3 className="flex items-center text-lg font-semibold text-gray-800 dark:text-gray-100">
              <span className="inline-block w-2 h-2 mr-2 bg-blue-500 rounded-full animate-pulse"></span>
              {t('dashboard.todaySchedule')}
            </h3>
            <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
              {formatDate(new Date(), { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              {todayAppointments.length}
            </div>
            <div className="text-xs text-gray-500 dark:text-gray-400">
              {t('dashboard.appointmentsToday')}
            </div>
          </div>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 min-h-0 p-4 overflow-auto">
          {/* Timeline Layout */}
          <div className="space-y-3">
            {todayAppointments.map((appointment, index) => {
              const status = getAppointmentStatus(appointment.id, appointment.date, appointment.time, appointment.consultation_done);
              return (
                <div
                  key={appointment.id}
                  className={`rounded-lg border transition-all cursor-pointer shadow-sm flex items-stretch ${status === 'current'
                      ? 'border-green-400 dark:border-green-500 bg-green-50/50 dark:bg-green-900/10 shadow-md'
                      : status === 'past'
                        ? 'border-gray-300 dark:border-gray-600 bg-gray-50/50 dark:bg-gray-800/50 opacity-60'
                        : 'border-blue-300 dark:border-blue-600 bg-white dark:bg-gray-800 hover:shadow-md'
                    } ${activeAppointment?.id === appointment.id
                      ? 'ring-2 ring-blue-400 dark:ring-blue-500'
                      : ''
                    }`}
                  onClick={() => handleOpenModal(appointment)}
                >
                  {/* Timeline indicator */}
                  <div className={`w-1 rounded-l-lg ${status === 'current'
                      ? 'bg-green-500'
                      : status === 'past'
                        ? 'bg-gray-400'
                        : 'bg-blue-500'
                    }`}></div>

                  {/* Time column */}
                  <div className={`flex flex-col justify-center items-center px-4 py-3 min-w-[100px] border-r ${status === 'current'
                      ? 'border-green-200 dark:border-green-700 bg-green-100/50 dark:bg-green-900/20'
                      : status === 'past'
                        ? 'border-gray-200 dark:border-gray-700 bg-gray-100/50 dark:bg-gray-700/50'
                        : 'border-blue-200 dark:border-blue-700 bg-blue-50/50 dark:bg-blue-900/20'
                    }`}>
                    <div className="text-2xl font-bold text-gray-800 dark:text-gray-100">
                      {appointment.time}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {appointment.duration} min
                    </div>
                    {status === 'current' && (
                      <div className="mt-2 px-2 py-1 text-xs font-semibold text-green-700 dark:text-green-300 bg-green-200 dark:bg-green-800 rounded-full">
                        {t('dashboard.inProgress')}
                      </div>
                    )}
                    {status === 'past' && appointment.consultation_done && (
                      <CheckCircleIcon className="w-5 h-5 text-green-600 dark:text-green-400 mt-2" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="text-base font-bold text-gray-900 dark:text-gray-100 mb-1">
                          {appointment.patientName}
                        </h4>
                        {appointment.patientPhone && (
                          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                            <PhoneIcon className="w-4 h-4" />
                            <span>{appointment.patientPhone}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col gap-1 items-end">
                        {appointment.venue_confirmed ? (
                          <span className="px-2 py-1 text-xs font-medium text-green-800 dark:text-green-200 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center gap-1">
                            <CheckCircleIcon className="w-3 h-3" />
                            {t('dashboard.confirmed')}
                          </span>
                        ) : (
                          <span className="px-2 py-1 text-xs font-medium text-orange-800 dark:text-orange-200 bg-orange-100 dark:bg-orange-900/50 rounded-full flex items-center gap-1">
                            <ExclamationCircleIcon className="w-3 h-3" />
                            {t('dashboard.notConfirmed')}
                          </span>
                        )}
                        {appointment.confirmed_coming && (
                          <span className="px-2 py-1 text-xs font-medium text-purple-800 dark:text-purple-200 bg-purple-100 dark:bg-purple-900/50 rounded-full">
                            {t('dashboard.arrived')}
                          </span>
                        )}
                        {appointment.consultation_done && (
                          <span className="px-2 py-1 text-xs font-medium text-blue-800 dark:text-blue-200 bg-blue-100 dark:bg-blue-900/50 rounded-full">
                            {t('dashboard.done')}
                          </span>
                        )}
                      </div>
                    </div>
                    {appointment.notes && (
                      <div className="mt-3 p-2 bg-gray-100 dark:bg-gray-700/50 rounded text-sm text-gray-700 dark:text-gray-300 italic">
                        <span className="font-semibold not-italic">{t('common.notes')}:</span> {appointment.notes}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {todayAppointments.length === 0 && (
            <div className="py-12 text-center">
              <div className="flex justify-center mb-4">
                <div className="w-20 h-20 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                  <ClockIcon className="w-10 h-10 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                {t('dashboard.noAppointmentsToday')}
              </h4>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {t('dashboard.enjoyYourDay')}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}