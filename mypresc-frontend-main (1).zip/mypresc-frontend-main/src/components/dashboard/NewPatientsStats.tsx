import { useState, useEffect, useRef, useMemo } from 'react';
import { ArrowTopRightOnSquareIcon, XMarkIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import { createPortal } from 'react-dom';
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Bar, BarChart, XAxis, YAxis, LabelList } from 'recharts';
import { usePatients } from '@/contexts/PatientsContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';

export default function NewPatientsStats() {
  const { t } = useLanguage();
  const { theme } = useTheme();

  const chartConfig = useMemo(() => ({
    patients: {
      label: t('charts.newPatientsChart.newPatients'),
      color: '#8b5cf6', // Couleur mauve
    },
  } satisfies ChartConfig), [t]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'year'>('month');
  const {
    newPatientStat,
    fetchPatientStatistics,
    statisticsLoading,
    statisticsError
  } = usePatients();

  // Track if data has been fetched at least once
  const hasFetchedRef = useRef(false);

  /**
   * Lazy load statistics when component becomes visible
   * Only fetches once on mount - subsequent data comes from cache
   */
  useEffect(() => {
    if (!hasFetchedRef.current) {
      console.log('[NewPatientsStats] Lazy loading new patient statistics...');
      fetchPatientStatistics('new');
      hasFetchedRef.current = true;
    }
  }, [fetchPatientStatistics]);

  const isLoading = statisticsLoading.new;
  const error = statisticsError.new;
  const hasData = newPatientStat && newPatientStat.weeklyData && newPatientStat.monthlyData && newPatientStat.yearlyData;

  const getData = () => {
    if (!hasData) return [];

    switch (selectedPeriod) {
      case 'week': return newPatientStat.weeklyData;
      case 'month': return newPatientStat.monthlyData;
      case 'year': return newPatientStat.yearlyData;
      default: return newPatientStat.monthlyData;
    }
  };

  const getTitle = () => {
    switch (selectedPeriod) {
      case 'week': return t('charts.newPatientsChart.weekTitle');
      case 'month': return t('charts.newPatientsChart.monthTitle');
      case 'year': return t('charts.newPatientsChart.yearTitle');
      default: return t('charts.newPatientsChart.title');
    }
  };

  const getFullPeriodName = (period: string) => {
    if (selectedPeriod === 'week') {
      const dayMap: Record<string, string> = {
        'Lun': t('daysFull.monday'),
        'Mar': t('daysFull.tuesday'),
        'Mer': t('daysFull.wednesday'),
        'Jeu': t('daysFull.thursday'),
        'Ven': t('daysFull.friday'),
        'Sam': t('daysFull.saturday'),
        'Dim': t('daysFull.sunday'),
      };
      return dayMap[period] || period;
    } else if (selectedPeriod === 'month') {
      const monthMap: Record<string, string> = {
        'Jan': t('monthsFull.january'),
        'Fév': t('monthsFull.february'),
        'Mar': t('monthsFull.march'),
        'Avr': t('monthsFull.april'),
        'Mai': t('monthsFull.may'),
        'Jui': t('monthsFull.june'),
        'Juil': t('monthsFull.july'),
        'Août': t('monthsFull.august'),
        'Sep': t('monthsFull.september'),
        'Oct': t('monthsFull.october'),
        'Nov': t('monthsFull.november'),
        'Déc': t('monthsFull.december'),
      };
      return monthMap[period] || period;
    }
    return period; // For years, return as is
  };

  /**
   * Loading skeleton placeholder
   */
  const LoadingSkeleton = () => (
    <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      <p className="text-sm text-gray-500">{t('charts.newPatientsChart.loading')}</p>
    </div>
  );

  /**
   * Error state component
   */
  const ErrorState = () => (
    <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
      <ExclamationTriangleIcon className="w-12 h-12 text-red-500" />
      <p className="text-sm text-gray-700 font-medium">{t('charts.newPatientsChart.loadingError')}</p>
      <p className="text-xs text-gray-500 text-center">{error}</p>
      <button
        onClick={() => fetchPatientStatistics('new')}
        className="px-4 py-2 bg-purple-600 text-white text-sm rounded-lg hover:bg-purple-700 transition-colors"
      >
        {t('charts.newPatientsChart.retry')}
      </button>
    </div>
  );

  /**
   * Empty state when no data is available
   */
  const EmptyState = () => (
    <div className="h-full w-full flex flex-col items-center justify-center space-y-4 p-8">
      <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
        <svg className="w-8 h-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      </div>
      <p className="text-sm text-gray-500">{t('charts.newPatientsChart.noData')}</p>
    </div>
  );

  const Modal = () => (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
      onClick={() => setIsModalOpen(false)}
    >
      <div
        className="p-6 m-4 bg-white dark:bg-gray-800 rounded-lg shadow-xl"
        style={{ width: '80vw', height: '70vh', maxWidth: '1000px' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">{getTitle()}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t('charts.newPatientsChart.detailedView')}</p>
          </div>
          <button
            onClick={() => setIsModalOpen(false)}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <XMarkIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Sélecteur de période dans la modal */}
        <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1 mb-6 w-fit">
          <button
            onClick={() => setSelectedPeriod('week')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'week'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.newPatientsChart.periodWeek')}
          </button>
          <button
            onClick={() => setSelectedPeriod('month')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'month'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.newPatientsChart.periodMonth')}
          </button>
          <button
            onClick={() => setSelectedPeriod('year')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'year'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.newPatientsChart.periodYear')}
          </button>
        </div>

        <div style={{ height: 'calc(100% - 140px)', width: '100%' }}>
          <ChartContainer config={chartConfig} className="h-full w-full">
            <BarChart data={getData()} width="100%" height="100%" margin={{ top: 30, right: 20, left: 20, bottom: 20 }}>
              <defs>
                <linearGradient id="purpleGradientModal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8b5cf6" />
                  <stop offset="100%" stopColor={theme === 'dark' ? '#1f2937' : '#ffffff'} stopOpacity={theme === 'dark' ? 0.2 : 1} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="period"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                width={80}
              />
              <ChartTooltip
                content={<ChartTooltipContent
                  formatter={(value) => [`${value}`, ` ${t('charts.newPatientsChart.newPatients')}`]}
                  labelFormatter={(label) => getFullPeriodName(String(label))}
                  className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                  labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                />}
              />
              <Bar
                dataKey="patients"
                fill="url(#purpleGradientModal)"
                radius={[4, 4, 0, 0]}
              >
                <LabelList
                  dataKey="patients"
                  position="top"
                  style={{
                    fontSize: '12px',
                    fontWeight: 'bold',
                    fill: theme === 'dark' ? '#e5e7eb' : '#374151'
                  }}
                  offset={8}
                />
              </Bar>
            </BarChart>
          </ChartContainer>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {isModalOpen && typeof window !== 'undefined' && createPortal(<Modal />, document.body)}

      <div className="h-[400px] p-4">
        {/* En-tête avec titre et sélecteur */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <h3 className="mb-0 text-sm font-semibold text-gray-800 dark:text-gray-100">{t('charts.newPatientsChart.title')}</h3>

            {/* Sélecteur de période compact - disabled when loading */}
            {hasData && (
              <div className="flex bg-gray-100 dark:bg-gray-700 rounded-md p-0.5">
                <button
                  onClick={() => setSelectedPeriod('week')}
                  disabled={isLoading}
                  className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'week'
                    ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                    } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {t('charts.newPatientsChart.periodWeekShort')}
                </button>
                <button
                  onClick={() => setSelectedPeriod('month')}
                  disabled={isLoading}
                  className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'month'
                    ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                    } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {t('charts.newPatientsChart.periodMonthShort')}
                </button>
                <button
                  onClick={() => setSelectedPeriod('year')}
                  disabled={isLoading}
                  className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'year'
                    ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                    : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                    } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {t('charts.newPatientsChart.periodYearShort')}
                </button>
              </div>
            )}
          </div>

          {hasData && !isLoading && (
            <ArrowTopRightOnSquareIcon
              className="w-4 h-4 text-gray-400 cursor-pointer hover:text-gray-600 dark:hover:text-gray-300"
              onClick={() => setIsModalOpen(true)}
            />
          )}
        </div>

        {/* Container du graphique avec états conditionnels */}
        <div className="relative flex items-center justify-center flex-1 h-full" style={{ padding: '0 16px 16px' }}>
          {isLoading ? (
            <LoadingSkeleton />
          ) : error ? (
            <ErrorState />
          ) : !hasData || getData().length === 0 ? (
            <EmptyState />
          ) : (
            <ChartContainer config={chartConfig} className="h-full w-full">
              <BarChart
                data={getData()}
                width="100%"
                height="100%"
                margin={{ top: 30, right: 45, left: 10, bottom: 20 }}
              >
                <defs>
                  <linearGradient id="purpleGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor={theme === 'dark' ? '#1f2937' : '#ffffff'} stopOpacity={theme === 'dark' ? 0.2 : 1} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="period"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tick={{ fontSize: 11, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                  interval={0}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tick={{ fontSize: 11, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                  width={65}
                />
                <ChartTooltip
                  content={<ChartTooltipContent
                    formatter={(value) => [`${value}`, ` ${t('charts.newPatientsChart.newPatients')}`]}
                    labelFormatter={(label) => getFullPeriodName(String(label))}
                    className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                    labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                  />}
                />
                <Bar
                  dataKey="patients"
                  fill="url(#purpleGradient)"
                  radius={[2, 2, 0, 0]}
                >
                  <LabelList
                    dataKey="patients"
                    position="top"
                    style={{
                      fontSize: '10px',
                      fontWeight: 'bold',
                      fill: theme === 'dark' ? '#e5e7eb' : '#374151'
                    }}
                    offset={8}
                  />
                </Bar>
              </BarChart>
            </ChartContainer>
          )}
        </div>
      </div>
    </>
  );
}