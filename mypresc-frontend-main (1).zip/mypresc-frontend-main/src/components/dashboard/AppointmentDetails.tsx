'use client';

import { ChevronLeftIcon, ChevronRightIcon, ChevronDownIcon, ArrowTopRightOnSquareIcon } from '@heroicons/react/24/outline';

export default function AppointmentDetails() {
  // Simulation des dates du calendrier
  const dates = Array.from({ length: 31 }, (_, i) => i + 1);
  const emptyStartDates = Array.from({ length: 1 }, () => null);
  const emptyEndDates = Array.from({ length: 2 }, () => null);
  const allDates = [...emptyStartDates, ...dates, ...emptyEndDates];

  // Réduire la taille pour s'adapter à la nouvelle mise en page

  // Catégories de rendez-vous
  const categories = [
    { name: 'Chirurgie', color: 'blue', colorClass: 'bg-blue-500' },
    { name: 'Allergies', color: 'red', colorClass: 'bg-red-500' },
    { name: 'Cœur', color: 'green', colorClass: 'bg-green-500' },
  ];

  // Jours de la semaine
  const weekDays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  // Dots pour  // Simulation des rendez-vous
  const appointments = {
    // Jour du mois: [catégories]
    4: ['Chirurgie'],
    10: ['Allergies'],
    15: ['Cœur'],
    17: [], // Jour sélectionné
    22: ['Chirurgie', 'Allergies'],
    24: ['Allergies', 'Cœur'],
    28: ['Chirurgie', 'Cœur'],
  };

  // Fonction pour obtenir les points de couleur pour un jour donné
  const getDayAppointmentDots = (day) => {
    if (!day || !appointments[day]) return null;

    return (
      <div className="flex justify-center mt-1 space-x-1">
        {appointments[day].map((type, index) => {
          const category = categories.find(cat => cat.name === type);
          return category ? (
            <div
              key={index}
              className={`w-1.5 h-1.5 rounded-full ${category.colorClass}`}
            >
            </div>
          ) : null;
        })}
      </div>
    );
  };

  return (
    <div className="card bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 p-4 rounded-lg shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="card-title text-lg font-bold text-gray-900 dark:text-gray-100">Détails des RDV</h3>
        <button
          onClick={() => window.location.href = '/calendar'}
          className="bg-gray-700 hover:bg-gray-800 text-white p-2 rounded-full shadow-sm flex items-center justify-center transition-all duration-200 hover:shadow-md"
          aria-label="Voir le calendrier"
          title="Voir le calendrier"
        >
          <ArrowTopRightOnSquareIcon className="h-4 w-4" />
        </button>
      </div>

      {/* Month Navigation */}
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm text-gray-700 dark:text-gray-300">June 2023</span>
        <div className="flex gap-2">
          <button className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <ChevronLeftIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
          <button className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <ChevronRightIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
      </div>

      {/* Filtres par catégorie */}
      <div className="flex justify-center space-x-2 mt-2 mb-4">
        {categories.map((category) => (
          <div key={category.name} className="flex items-center">
            <span
              className={`inline-block w-2 h-2 rounded-full mr-1 ${category.colorClass}`}
            >
            </span>
            <span className="text-xs text-gray-600 dark:text-gray-400">{category.name}</span>
          </div>
        ))}
      </div>

      {/* Calendar */}
      <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-medium text-gray-900 dark:text-gray-100">August 2023</span>
          <ChevronDownIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
        </div>

        {/* Calendar Grid */}
        <div className="space-y-2">
          {/* Days of week */}
          <div className="grid grid-cols-7 gap-1 text-center mb-2">
            {weekDays.map((day, index) => (
              <div key={index} className="text-xs font-medium text-gray-400 dark:text-gray-500">{day}</div>
            ))}
          </div>

          {/* Calendar dates */}
          <div className="grid grid-cols-7 gap-1">
            {allDates.map((date, index) => (
              <div key={index} className="flex flex-col items-center min-h-[40px]">
                {date && (
                  <div className="text-center w-full">
                    <div className={`w-7 h-7 mx-auto flex items-center justify-center rounded-full text-sm ${date === 17
                        ? 'bg-blue-500 text-white'
                        : 'text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-colors'
                      }`}>
                      {date}
                    </div>
                    {getDayAppointmentDots(date)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
