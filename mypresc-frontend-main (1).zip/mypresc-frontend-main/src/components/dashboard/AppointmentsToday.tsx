export default function AppointmentsToday() {
  return (
    <div className="bg-white rounded-lg p-5 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-800">RDV d'Aujourd'hui</h3>
      <p className="text-sm text-gray-500 mt-1">Total des patients</p>
      <div className="mt-4 flex items-end justify-between">
        <div>
          <p className="text-4xl font-bold text-gray-900">522</p>
        </div>
        <div className="text-xs px-2 py-1 bg-red-100 text-red-600 rounded-md">
          -0.6%
        </div>
      </div>
    </div>
  );
}
