"use client";

import { useEffect, useState } from "react";
import Modal from "@/components/ui/Modal";
import { useWaitingRoom, WaitingEntry } from "@/contexts/WaitingRoomContext";
import { useAuth } from "@/contexts/AuthContext";
import { usePatients, ApiPatient } from "@/contexts/PatientsContext";
import { useLanguage } from "@/contexts/LanguageContext";

export default function WaitingEntriesModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { entries, createEntry, deleteEntry, updateEntry } = useWaitingRoom();
  const { user } = useAuth();
  const { t } = useLanguage();
  const doctorUserId = user?.id as any;

  const [form, setForm] = useState<{ patient_id: string; patientLabel?: string }>({ patient_id: "", patientLabel: "" });
  const [submitting, setSubmitting] = useState(false);
  const { searchPatients } = usePatients();
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<ApiPatient[] | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);

  // debounced search
  useEffect(() => {
    const id = setTimeout(async () => {
      if (!searchOpen || !search.trim()) {
        setResults(null);
        return;
      }
      const res = await searchPatients(search.trim(), 10, true); // includeAll=true pour la salle d'attente
      setResults(res);
    }, 300);
    return () => clearTimeout(id);
  }, [search, searchOpen, searchPatients]);

  const handleCreate = async () => {
    if (!form.patient_id) return;
    setSubmitting(true);
    await createEntry({ patient_id: form.patient_id }, doctorUserId);
    setSubmitting(false);
    setForm({ patient_id: "", patientLabel: "" });
    setSearch("");
    setResults(null);
  };

  const handleExit = async (id: string) => {
    await deleteEntry(id, doctorUserId);
  };

  const callPatient = async (entry: WaitingEntry) => {
    if (entry.called_at) return;
    await updateEntry(entry.id, { called_at: new Date().toISOString() }, doctorUserId);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t('dashboard.waitingRoom')} zIndex={15000}>
      <div className="space-y-6 h-[80vh] overflow-auto">
        <div className="flex gap-3 items-end">
          <div className="flex-1 relative">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('common.patient')}</label>
            <input
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400"
              placeholder={t('dashboard.searchPatient')}
              value={form.patientLabel || search}
              onChange={(e) => { setSearch(e.target.value); setSearchOpen(true); setForm({ ...form, patientLabel: e.target.value }); }}
              onFocus={() => setSearchOpen(true)}
            />
            {searchOpen && (form.patientLabel || search) && (
              <div className="absolute z-[16000] mt-2 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg max-h-80 overflow-auto">
                {results === null ? (
                  <div className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400">{t('dashboard.enterToSearch')}</div>
                ) : results.length === 0 ? (
                  <div className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400">{t('dashboard.noResults')}</div>
                ) : (
                  results.map((p) => (
                    <button
                      type="button"
                      key={p.id}
                      onClick={() => { setForm({ patient_id: p.id, patientLabel: `${p.name} ${p.family_name}` }); setSearchOpen(false); }}
                      className="w-full text-left block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-gray-100">{p.name} {p.family_name}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">{p.telephone}</div>
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{p.genre?.toUpperCase()} · {p.age} ans · #{p.id.substring(0, 8)}…</div>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
          <button
            onClick={handleCreate}
            disabled={submitting || !form.patient_id}
            className="px-5 py-2.5 text-sm font-medium bg-blue-600 text-white rounded-md disabled:opacity-50"
          >
            {t('common.add')}
          </button>
        </div>

        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="text-gray-700 dark:text-gray-400 border-b dark:border-gray-700">
              <th className="py-2 pr-2">{t('common.patient')}</th>
              <th className="py-2 pr-2">{t('dashboard.arrived')}</th>
              <th className="py-2">{t('dashboard.called')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {entries
              .filter((e) => e.status !== 'served')
              .map((e) => {
                const arrived = e.arrived_at ? new Date(e.arrived_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) : '-';
                const called = e.called_at ? new Date(e.called_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) : '-';
                const name = `${e.patient_name || ''} ${e.patient_family_name || ''}`.trim() || e.patient_id;
                return (
                  <tr key={e.id} className="border-b dark:border-gray-800">
                    <td className="py-2 pr-2 font-medium text-gray-900 dark:text-gray-100">{name}</td>
                    <td className="py-2 pr-2 text-gray-600 dark:text-gray-400">{arrived}</td>
                    <td className="py-2 text-gray-600 dark:text-gray-400">{called}</td>
                  </tr>
                );
              })}
          </tbody>
        </table>
        {entries.filter((e) => !e.called_at).length === 0 && (
          <div className="py-6 text-center text-gray-500 dark:text-gray-400">{t('dashboard.noEntries')}</div>
        )}
      </div>
    </Modal>
  );
}


