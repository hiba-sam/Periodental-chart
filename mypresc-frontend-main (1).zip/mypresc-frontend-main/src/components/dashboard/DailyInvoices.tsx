"use client";

import React, { useEffect, useState, useCallback, Fragment } from "react";
import { usePatients, Invoice, PatientUnpaidSummary } from "@/contexts/PatientsContext";
import { useLanguage } from "@/contexts/LanguageContext";
import socketClient from "@/utils/socketClient";
import { BanknotesIcon, MagnifyingGlassIcon, XMarkIcon, ChevronRightIcon, CheckCircleIcon, CurrencyDollarIcon } from "@heroicons/react/24/outline";
import { Dialog, Transition } from "@headlessui/react";

export default function DailyInvoices() {
    const { getUnpaidByPatient, updateInvoiceStatus, distributePayment } = usePatients();
    const { t } = useLanguage();
    const [unpaidSummaries, setUnpaidSummaries] = useState<PatientUnpaidSummary[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState("");
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [selectedPatient, setSelectedPatient] = useState<PatientUnpaidSummary | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [confirmPayment, setConfirmPayment] = useState<{ isOpen: boolean; invoiceId: number | null; amount: string }>({ isOpen: false, invoiceId: null, amount: '0' });
    const [isProcessing, setIsProcessing] = useState(false);
    
    // Global payment state
    const [globalPaymentModal, setGlobalPaymentModal] = useState(false);
    const [globalPaymentAmount, setGlobalPaymentAmount] = useState("");
    const [isDistributing, setIsDistributing] = useState(false);

    const parseBufferString = (str: any) => {
        if (!str) return "";
        if (typeof str === "string") return str;
        if (typeof str === "object" && str.type === "Buffer" && Array.isArray(str.data)) {
            try {
                return new TextDecoder("utf-8").decode(new Uint8Array(str.data));
            } catch (e) {
                return "";
            }
        }
        return "";
    };

    const fetchUnpaidSummaries = useCallback(async (search?: string) => {
        setLoading(true);
        const data = await getUnpaidByPatient(search);
        setUnpaidSummaries(data);
        setLoading(false);
    }, [getUnpaidByPatient]);

    // Debounce search
    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearch(searchTerm);
        }, 300);
        return () => clearTimeout(timer);
    }, [searchTerm]);

    // Fetch on mount and when search changes
    useEffect(() => {
        fetchUnpaidSummaries(debouncedSearch);
    }, [debouncedSearch, fetchUnpaidSummaries]);

    // Socket.IO Integration for real-time updates
    useEffect(() => {
        const handleInvoiceChange = (data: any) => {
            console.log('[DailyInvoices] Received invoice update:', data);
            fetchUnpaidSummaries(debouncedSearch);
        };

        const attachListeners = () => {
            const socket = socketClient.getSocket();
            if (!socket) return;

            console.log('[DailyInvoices] Attaching invoice listeners');
            socket.off('invoice:created', handleInvoiceChange);
            socket.off('invoice:updated', handleInvoiceChange);
            socket.off('invoice:deleted', handleInvoiceChange);

            socket.on('invoice:created', handleInvoiceChange);
            socket.on('invoice:updated', handleInvoiceChange);
            socket.on('invoice:deleted', handleInvoiceChange);
        };

        // Attach listeners immediately if already connected
        attachListeners();

        // Also attach when socket connects/reconnects
        const cleanupOnConnect = socketClient.onConnect(attachListeners);

        return () => {
            cleanupOnConnect();
            const socket = socketClient.getSocket();
            if (socket) {
                socket.off('invoice:created', handleInvoiceChange);
                socket.off('invoice:updated', handleInvoiceChange);
                socket.off('invoice:deleted', handleInvoiceChange);
            }
        };
    }, [debouncedSearch, fetchUnpaidSummaries]);

    const openPaymentConfirmation = (invoiceId: number, amount: string) => {
        setConfirmPayment({ isOpen: true, invoiceId, amount });
    };

    const closePaymentConfirmation = () => {
        setConfirmPayment({ isOpen: false, invoiceId: null, amount: '0' });
    };

    const handleConfirmPayment = async () => {
        if (!confirmPayment.invoiceId || isProcessing) return;
        
        setIsProcessing(true);
        const invoiceId = confirmPayment.invoiceId;
        const patientId = selectedPatient?.patient_id;
        
        // Fermer le popup de confirmation immédiatement
        closePaymentConfirmation();
        
        // Mise à jour OPTIMISTE: retirer la facture immédiatement de l'affichage
        if (selectedPatient) {
            const updatedInvoices = selectedPatient.invoices.filter(inv => inv.id !== invoiceId);
            if (updatedInvoices.length === 0) {
                // Plus de factures impayées, fermer le popup
                setIsModalOpen(false);
                setSelectedPatient(null);
                // Retirer le patient de la liste principale
                setUnpaidSummaries(prev => prev.filter(p => p.patient_id !== patientId));
            } else {
                // Mettre à jour le patient avec les factures restantes
                const newTotal = updatedInvoices.reduce((sum, inv) => sum + parseFloat(inv.total_price || '0'), 0);
                setSelectedPatient({
                    ...selectedPatient,
                    invoices: updatedInvoices,
                    total_unpaid: newTotal.toString(),
                    invoice_count: updatedInvoices.length.toString()
                });
                // Mettre à jour aussi la liste principale
                setUnpaidSummaries(prev => prev.map(p => 
                    p.patient_id === patientId 
                        ? { ...p, invoices: updatedInvoices, total_unpaid: newTotal.toString(), invoice_count: updatedInvoices.length.toString() }
                        : p
                ));
            }
        }
        
        // Appel API en arrière-plan
        const success = await updateInvoiceStatus(invoiceId, 'paid');
        setIsProcessing(false);
        
        if (!success) {
            // En cas d'erreur, rafraîchir pour restaurer l'état correct
            fetchUnpaidSummaries(debouncedSearch);
            if (patientId) {
                getUnpaidByPatient(debouncedSearch).then(updatedData => {
                    const updated = updatedData.find(p => p.patient_id === patientId);
                    if (updated) {
                        setSelectedPatient(updated);
                        setIsModalOpen(true);
                    }
                });
            }
        }
    };

    const openPatientDetails = (patient: PatientUnpaidSummary) => {
        setSelectedPatient(patient);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setSelectedPatient(null);
    };

    const openGlobalPaymentModal = () => {
        if (selectedPatient) {
            setGlobalPaymentAmount(selectedPatient.total_unpaid);
            setGlobalPaymentModal(true);
        }
    };

    const closeGlobalPaymentModal = () => {
        setGlobalPaymentModal(false);
        setGlobalPaymentAmount("");
    };

    const handleDistributePayment = async () => {
        if (!selectedPatient || isDistributing) return;
        
        const amount = parseFloat(globalPaymentAmount);
        if (isNaN(amount) || amount <= 0) return;
        
        setIsDistributing(true);
        const result = await distributePayment(selectedPatient.patient_id, amount);
        setIsDistributing(false);
        
        if (result?.success) {
            closeGlobalPaymentModal();
            // Refresh the data
            fetchUnpaidSummaries(debouncedSearch);
            // Check if all invoices are paid
            const remainingUnpaid = result.updatedInvoices.filter(inv => inv.status !== 'paid');
            if (remainingUnpaid.length === 0) {
                closeModal();
            } else {
                // Update the selected patient with new data
                const updatedData = await getUnpaidByPatient(debouncedSearch);
                const updated = updatedData.find(p => p.patient_id === selectedPatient.patient_id);
                if (updated) {
                    setSelectedPatient(updated);
                } else {
                    closeModal();
                }
            }
        }
    };

    const totalUnpaid = unpaidSummaries.reduce((sum, p) => sum + parseFloat(p.total_unpaid || '0'), 0);

    return (
        <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 flex flex-col border border-gray-200 dark:border-gray-700 transition-all duration-200 mb-6 min-h-[500px]">
                {/* Header */}
                <div className="flex flex-wrap gap-2 items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-800 dark:text-white flex items-center gap-2">
                        <BanknotesIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-500" />
                        {t("invoice.card.unpaidHistory") || "Historique des impayés"}
                    </h2>
                    <div className="text-sm font-semibold text-red-600 dark:text-red-400">
                        {t("invoice.card.totalUnpaid") || "Total"}: {totalUnpaid.toLocaleString("fr-DZ", { style: "currency", currency: "DZD" })}
                    </div>
                </div>

                {/* Search Bar */}
                <div className="relative mb-4">
                    <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                        type="text"
                        placeholder={t("invoice.card.searchPlaceholder") || "Rechercher un patient..."}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-10 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
                    />
                    {searchTerm && (
                        <button
                            onClick={() => setSearchTerm("")}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                        >
                            <XMarkIcon className="w-5 h-5" />
                        </button>
                    )}
                </div>

                {/* Content */}
                {loading ? (
                    <div className="flex-1 flex items-center justify-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
                    </div>
                ) : (
                    <div className="space-y-3 overflow-y-auto pr-2 flex-1 max-h-[350px]">
                        {unpaidSummaries.length > 0 ? (
                            unpaidSummaries.map((patient) => (
                                <div
                                    key={patient.patient_id}
                                    onClick={() => openPatientDetails(patient)}
                                    className="border rounded-lg p-4 transition-all duration-200 cursor-pointer bg-white border-gray-100 hover:bg-gray-50 hover:border-emerald-300 dark:bg-transparent dark:border-gray-700 dark:hover:bg-gray-700 dark:hover:border-emerald-600 group"
                                >
                                    <div className="flex items-center justify-between">
                                        <div className="flex-1">
                                            <span className="text-sm font-bold text-gray-800 dark:text-gray-200">
                                                {parseBufferString(patient.patient_name)} {parseBufferString(patient.patient_family_name)}
                                            </span>
                                            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                                {patient.invoice_count} {parseInt(patient.invoice_count) > 1 
                                                    ? (t("invoice.card.invoices") || "factures") 
                                                    : (t("invoice.card.invoice") || "facture")}
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-base font-bold text-red-600 dark:text-red-400">
                                                {parseFloat(patient.total_unpaid).toLocaleString("fr-DZ", {
                                                    style: "currency",
                                                    currency: "DZD",
                                                })}
                                            </span>
                                            <ChevronRightIcon className="w-5 h-5 text-gray-400 group-hover:text-emerald-500 transition-colors" />
                                        </div>
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="text-center py-6 text-gray-500 dark:text-gray-400 h-full flex flex-col justify-center">
                                <BanknotesIcon className="w-10 h-10 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                                <p className="text-sm">
                                    {searchTerm 
                                        ? (t("invoice.card.noResults") || "Aucun résultat trouvé")
                                        : (t("invoice.card.noUnpaid") || "Aucune facture impayée")}
                                </p>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Details Modal */}
            <Transition appear show={isModalOpen} as={Fragment}>
                <Dialog as="div" className="relative z-50" onClose={closeModal}>
                    <Transition.Child
                        as={Fragment}
                        enter="ease-out duration-300"
                        enterFrom="opacity-0"
                        enterTo="opacity-100"
                        leave="ease-in duration-200"
                        leaveFrom="opacity-100"
                        leaveTo="opacity-0"
                    >
                        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                    </Transition.Child>

                    <div className="fixed inset-0 overflow-y-auto">
                        <div className="flex min-h-full items-center justify-center p-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel className="w-full max-w-lg transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 shadow-xl transition-all">
                                    <Dialog.Title className="flex items-center justify-between mb-4">
                                        <div>
                                            <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                                                {parseBufferString(selectedPatient?.patient_name)} {parseBufferString(selectedPatient?.patient_family_name)}
                                            </h3>
                                            <p className="text-sm text-gray-500 dark:text-gray-400">
                                                {t("invoice.card.detailsSubtitle") || "Détails des factures impayées"}
                                            </p>
                                        </div>
                                        <button
                                            onClick={closeModal}
                                            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                                        >
                                            <XMarkIcon className="w-5 h-5 text-gray-500" />
                                        </button>
                                    </Dialog.Title>

                                    {/* Total Summary */}
                                    <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 mb-4">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm font-medium text-red-700 dark:text-red-300">
                                                {t("invoice.card.totalToPay") || "Total à payer"}
                                            </span>
                                            <span className="text-xl font-bold text-red-600 dark:text-red-400">
                                                {parseFloat(selectedPatient?.total_unpaid || '0').toLocaleString("fr-DZ", {
                                                    style: "currency",
                                                    currency: "DZD",
                                                })}
                                            </span>
                                        </div>
                                        {/* Global Payment Button */}
                                        <button
                                            onClick={openGlobalPaymentModal}
                                            className="mt-3 w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg text-sm font-bold transition-all duration-200 bg-emerald-600 text-white hover:bg-emerald-700 shadow-md hover:shadow-lg active:scale-[0.98]"
                                        >
                                            <BanknotesIcon className="w-5 h-5" />
                                            Encaisser un montant global
                                        </button>
                                    </div>

                                    {/* Invoice List */}
                                    <div className="space-y-3 max-h-[300px] overflow-y-auto">
                                        {selectedPatient?.invoices?.map((invoice: Invoice) => (
                                            <div
                                                key={invoice.id}
                                                className="border border-gray-200 dark:border-gray-700 rounded-lg p-4"
                                            >
                                                <div className="flex items-center justify-between mb-2">
                                                    <span className="text-xs text-gray-500 dark:text-gray-400">
                                                        {new Date(invoice.created_at).toLocaleDateString("fr-FR", {
                                                            day: '2-digit',
                                                            month: 'short',
                                                            year: 'numeric'
                                                        })} à {new Date(invoice.created_at).toLocaleTimeString("fr-FR", {
                                                            hour: '2-digit',
                                                            minute: '2-digit'
                                                        })}
                                                    </span>
                                                    <button
                                                        onClick={() => openPaymentConfirmation(invoice.id, (parseFloat(invoice.total_price) - parseFloat(invoice.amount_paid || '0')).toString())}
                                                        className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 bg-emerald-500 text-white hover:bg-emerald-600 shadow-sm hover:shadow-md active:scale-95"
                                                    >
                                                        <CurrencyDollarIcon className="w-4 h-4" />
                                                        {t("invoice.card.confirmPayment") || "Encaisser"}
                                                    </button>
                                                </div>

                                                {/* Invoice Items */}
                                                <div className="space-y-1">
                                                    {invoice.items?.map((item, idx) => (
                                                        <div key={idx} className="flex items-center justify-between text-sm">
                                                            <span className="text-gray-700 dark:text-gray-300">{item.label}</span>
                                                            <span className="text-gray-900 dark:text-white font-medium">
                                                                {item.price.toLocaleString("fr-DZ", { style: "currency", currency: "DZD" })}
                                                            </span>
                                                        </div>
                                                    ))}
                                                </div>

                                                {/* Invoice Total */}
                                                <div className="mt-2 pt-2 border-t border-gray-100 dark:border-gray-700 space-y-1">
                                                    {parseFloat(invoice.amount_paid || '0') > 0 && (
                                                        <>
                                                            <div className="flex items-center justify-between text-sm">
                                                                <span className="text-gray-500 dark:text-gray-400">Total</span>
                                                                <span className="text-gray-600 dark:text-gray-300">
                                                                    {parseFloat(invoice.total_price).toLocaleString("fr-DZ", { style: "currency", currency: "DZD" })}
                                                                </span>
                                                            </div>
                                                            <div className="flex items-center justify-between text-sm">
                                                                <span className="text-green-600 dark:text-green-400">Déjà payé</span>
                                                                <span className="text-green-600 dark:text-green-400">
                                                                    -{parseFloat(invoice.amount_paid || '0').toLocaleString("fr-DZ", { style: "currency", currency: "DZD" })}
                                                                </span>
                                                            </div>
                                                        </>
                                                    )}
                                                    <div className="flex items-center justify-between">
                                                        <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                                                            {parseFloat(invoice.amount_paid || '0') > 0 ? "Reste à payer" : (t("invoice.card.subtotal") || "Sous-total")}
                                                        </span>
                                                        <span className="text-base font-bold text-gray-900 dark:text-white">
                                                            {(parseFloat(invoice.total_price) - parseFloat(invoice.amount_paid || '0')).toLocaleString("fr-DZ", {
                                                                style: "currency",
                                                                currency: "DZD",
                                                            })}
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>

            {/* Payment Confirmation Modal */}
            <Transition appear show={confirmPayment.isOpen} as={Fragment}>
                <Dialog as="div" className="relative z-[60]" onClose={closePaymentConfirmation}>
                    <Transition.Child
                        as={Fragment}
                        enter="ease-out duration-200"
                        enterFrom="opacity-0"
                        enterTo="opacity-100"
                        leave="ease-in duration-150"
                        leaveFrom="opacity-100"
                        leaveTo="opacity-0"
                    >
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
                    </Transition.Child>

                    <div className="fixed inset-0 overflow-y-auto">
                        <div className="flex min-h-full items-center justify-center p-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-200"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-150"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel className="w-full max-w-sm transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 p-6 shadow-2xl transition-all text-center">
                                    <div className="mx-auto w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mb-4">
                                        <CheckCircleIcon className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
                                    </div>
                                    
                                    <Dialog.Title className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                                        {t("invoice.card.confirmPaymentTitle") || "Confirmer le paiement"}
                                    </Dialog.Title>
                                    
                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                        {t("invoice.card.confirmPaymentMessage") || "Voulez-vous marquer cette facture comme payée ?"}
                                    </p>
                                    
                                    <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-3 mb-6">
                                        <span className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
                                            {parseFloat(confirmPayment.amount || '0').toLocaleString("fr-DZ", {
                                                style: "currency",
                                                currency: "DZD",
                                            })}
                                        </span>
                                    </div>
                                    
                                    <div className="flex gap-3">
                                        <button
                                            onClick={closePaymentConfirmation}
                                            className="flex-1 px-4 py-2.5 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                                        >
                                            {t("common.cancel") || "Annuler"}
                                        </button>
                                        <button
                                            onClick={handleConfirmPayment}
                                            disabled={isProcessing}
                                            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold text-white bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-400 disabled:cursor-not-allowed transition-colors shadow-sm"
                                        >
                                            {isProcessing ? (
                                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                            ) : (
                                                <CheckCircleIcon className="w-5 h-5" />
                                            )}
                                            {isProcessing ? (t("common.loading") || "...") : (t("invoice.card.confirmBtn") || "Confirmer")}
                                        </button>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>

            {/* Global Payment Modal */}
            <Transition appear show={globalPaymentModal} as={Fragment}>
                <Dialog as="div" className="relative z-[70]" onClose={closeGlobalPaymentModal}>
                    <Transition.Child
                        as={Fragment}
                        enter="ease-out duration-200"
                        enterFrom="opacity-0"
                        enterTo="opacity-100"
                        leave="ease-in duration-150"
                        leaveFrom="opacity-100"
                        leaveTo="opacity-0"
                    >
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
                    </Transition.Child>

                    <div className="fixed inset-0 overflow-y-auto">
                        <div className="flex min-h-full items-center justify-center p-4">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-200"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-150"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white dark:bg-gray-800 shadow-2xl transition-all">
                                    {/* Header */}
                                    <div className="bg-gradient-to-r from-emerald-500 to-green-600 px-6 py-5">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 bg-white/20 rounded-full">
                                                <BanknotesIcon className="w-6 h-6 text-white" />
                                            </div>
                                            <div>
                                                <h2 className="text-lg font-bold text-white">Encaisser un montant global</h2>
                                                <p className="text-sm text-white/80">
                                                    {parseBufferString(selectedPatient?.patient_name)} {parseBufferString(selectedPatient?.patient_family_name)}
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="p-6">
                                        {/* Summary */}
                                        <div className="mb-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl space-y-2">
                                            <div className="flex justify-between text-sm">
                                                <span className="text-gray-500 dark:text-gray-400">Total impayé</span>
                                                <span className="font-bold text-red-600 dark:text-red-400">
                                                    {parseFloat(selectedPatient?.total_unpaid || '0').toLocaleString("fr-DZ")} DA
                                                </span>
                                            </div>
                                            <div className="flex justify-between text-sm">
                                                <span className="text-gray-500 dark:text-gray-400">Nombre de factures</span>
                                                <span className="font-medium text-gray-900 dark:text-white">
                                                    {selectedPatient?.invoice_count || 0}
                                                </span>
                                            </div>
                                        </div>

                                        {/* Amount Input */}
                                        <div className="mb-4">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Montant reçu (DA)
                                            </label>
                                            <input
                                                type="number"
                                                value={globalPaymentAmount}
                                                onChange={(e) => setGlobalPaymentAmount(e.target.value)}
                                                placeholder="Entrez le montant..."
                                                className="w-full px-4 py-3 text-lg font-bold border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                                                min="0"
                                                step="0.01"
                                            />
                                        </div>

                                        {/* Quick Amount Button */}
                                        <button
                                            type="button"
                                            onClick={() => setGlobalPaymentAmount(selectedPatient?.total_unpaid || '0')}
                                            className="w-full mb-4 px-4 py-3 text-sm font-medium bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 rounded-lg hover:bg-emerald-200 dark:hover:bg-emerald-900/50 transition-colors"
                                        >
                                            Payer la totalité ({parseFloat(selectedPatient?.total_unpaid || '0').toLocaleString("fr-DZ")} DA)
                                        </button>

                                        {/* Info */}
                                        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
                                            Le montant sera réparti automatiquement sur les factures les plus anciennes en priorité.
                                        </p>
                                    </div>

                                    {/* Footer */}
                                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                                        <button
                                            onClick={closeGlobalPaymentModal}
                                            className="flex-1 px-4 py-3 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-xl hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                                        >
                                            Annuler
                                        </button>
                                        <button
                                            onClick={handleDistributePayment}
                                            disabled={isDistributing || !globalPaymentAmount || parseFloat(globalPaymentAmount) <= 0}
                                            className="flex-1 px-4 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                                        >
                                            {isDistributing ? (
                                                <><div className="animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full"></div> Traitement...</>
                                            ) : (
                                                <><BanknotesIcon className="w-5 h-5" /> Encaisser</>
                                            )}
                                        </button>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </>
    );
}
