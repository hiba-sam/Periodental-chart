'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import socketClient from '@/utils/socketClient';
import { useLanguage } from '@/contexts/LanguageContext';
import { useWaitingRoom } from '@/contexts/WaitingRoomContext';
import { useAppointmentsContext } from '@/contexts/AppointmentContext';
import { Bell, X, Volume2 } from 'lucide-react';
import logger from '@/utils/logger';

interface PatientCallData {
  patientName: string;
  patientId: string;
  type: 'appointment' | 'waiting';
  timestamp: string;
}

export default function PatientCallPopup() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { getTodaySchedule, fetchEntries } = useWaitingRoom();
  const { fetchAppointments } = useAppointmentsContext();
  const [callData, setCallData] = useState<PatientCallData | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const hasJoinedRoomRef = useRef(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (user?.role !== 'assistant') {
      return;
    }

    // For assistants, user.id is the doctor_id (from auth.controller.ts)
    const doctorId = user?.id;
    logger.log('[PatientCallPopup] v4 - Assistant, doctor_id:', doctorId);

    // Ensure socket is initialized
    socketClient.connect();

    const handlePatientCall = (data: PatientCallData) => {
      logger.log('📢 [PatientCallPopup] RECEIVED:', data);
      setCallData(data);
      setIsVisible(true);

      // Play notification sound
      try {
        const audio = new Audio('/sounds/notification.mp3');
        audio.volume = 0.5;
        audio.play().catch(() => { });
      } catch (e) { }
    };

    // Function to join the doctor's assistant notification room and setup listener
    const setupSocketAndJoinRoom = () => {
      if (hasJoinedRoomRef.current || !doctorId) return;

      const currentSocket = socketClient.getSocket();
      if (currentSocket?.connected) {
        // Remove any existing listener first
        currentSocket.off('patient:call');

        // Add listener on the SAME socket that joins the room
        currentSocket.on('patient:call', handlePatientCall);
        logger.log('[PatientCallPopup] Listener added on socket:', currentSocket.id);

        // Join the room
        logger.log('[PatientCallPopup] JOINING room doctor-assistants:', doctorId, 'socket:', currentSocket.id);
        currentSocket.emit('join:doctor-assistants', { doctorId }, (response: any) => {
          logger.log('[PatientCallPopup] Join room response:', response);
        });

        hasJoinedRoomRef.current = true;
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
          intervalRef.current = null;
        }
      }
    };

    // Check periodically for socket connection
    intervalRef.current = setInterval(() => {
      const currentSocket = socketClient.getSocket();
      if (currentSocket?.connected && !hasJoinedRoomRef.current) {
        logger.log('[PatientCallPopup] Socket ready, joining room...');
        setupSocketAndJoinRoom();
      }
    }, 300);

    // Also try immediately if already connected
    setupSocketAndJoinRoom();

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      const currentSocket = socketClient.getSocket();
      if (currentSocket) {
        currentSocket.off('patient:call', handlePatientCall);
      }
      // Don't reset hasJoinedRoomRef on cleanup to avoid rejoining issues
    };
  }, [user?.role, user?.id]);

  const handleClose = async () => {
    setIsVisible(false);
    setTimeout(() => setCallData(null), 300);

    // Rafraîchir les données après confirmation
    if (user?.id) {
      await Promise.all([
        getTodaySchedule(user.id),
        fetchEntries(user.id),
        fetchAppointments()
      ]);
    }
  };

  if (!isVisible || !callData) return null;

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative bg-white dark:bg-gray-800 rounded-3xl shadow-2xl max-w-md w-full mx-4 overflow-hidden animate-in zoom-in-95 duration-300">
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-full">
                <Bell className="w-6 h-6 text-white animate-bounce" />
              </div>
              <h2 className="text-xl font-bold text-white">
                {t('dashboard.callPatient') || 'Appeler le patient'}
              </h2>
            </div>
            <button
              onClick={handleClose}
              className="p-1 hover:bg-white/20 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 text-center">
          <div className="mb-6">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 rounded-full flex items-center justify-center mb-4">
              <Volume2 className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-2">
              {t('dashboard.pleaseCallPatient') || 'Veuillez appeler le patient suivant :'}
            </p>
            <p className="text-3xl font-extrabold text-green-600 dark:text-green-400">
              {callData.patientName}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              {callData.type === 'appointment' ? 'RDV' : 'Salle d\'attente'}
            </p>
          </div>

          <button
            onClick={handleClose}
            className="w-full px-6 py-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-700 transition-all transform hover:scale-[1.02] shadow-lg"
          >
            {t('common.confirm') || 'Confirmer'}
          </button>
        </div>
      </div>
    </div>
  );
}
