// ListSkeleton - Generic list loading placeholder
'use client';

interface ListSkeletonProps {
    /** Number of items to show */
    count?: number;
    className?: string;
}

/**
 * Simple list skeleton for any list-based content loading
 */
export function ListSkeleton({ count = 3, className = '' }: ListSkeletonProps) {
    return (
        <div className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 animate-pulse ${className}`}>
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-4" />
            <div className="space-y-3">
                {Array.from({ length: count }).map((_, i) => (
                    <div key={i} className="h-12 bg-gray-100 dark:bg-gray-700/50 rounded" />
                ))}
            </div>
        </div>
    );
}

export default ListSkeleton;
