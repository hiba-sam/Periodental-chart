'use client';

import { BellIcon, Bars3CenterLeftIcon, XMarkIcon, ClockIcon, ArrowLeftIcon } from '@heroicons/react/24/outline';
import { ChevronRightIcon } from '@heroicons/react/24/solid';
import { CheckCircleIcon, ExclamationTriangleIcon, InformationCircleIcon, XCircleIcon } from '@heroicons/react/24/solid';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState, useRef, useEffect } from 'react';
import { useNotifications } from '../contexts/NotificationContext';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useMobileMenu } from '@/contexts/MobileMenuContext';
import { useHeaderContext } from '@/contexts/HeaderContext';
import MobileFullModal from '@/components/ui/MobileFullModal';
import logger from '@/utils/logger';

export default function Header() {
  const { user } = useAuth();
  const router = useRouter();
  const { backMode, hidden } = useHeaderContext();

  const {
    notifications,
    loading,
    stats,
    markAsSeen,
    markAllAsSeen,
    getUnreadCount
  } = useNotifications();

  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  const { isRTL, t } = useLanguage();
  const { isMobileMenuOpen, openMobileMenu, closeMobileMenu } = useMobileMenu();

  // Track mobile breakpoint
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 767px)');
    setIsMobile(mq.matches);
    const handler = (e: MediaQueryListEvent) => setIsMobile(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Close desktop dropdown when clicking outside (desktop only)
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (!isMobile && notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobile]);

  // Auto mark-all-as-read when mobile modal opens
  useEffect(() => {
    if (isNotificationOpen && isMobile && unreadCount > 0) markAllAsSeen();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNotificationOpen, isMobile]);

  // Format date to relative time
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));

    if (diffInHours < 1) {
      return t('time.justNow') || 'À l\'instant';
    } else if (diffInHours < 24) {
      return `${diffInHours}h`;
    } else if (diffInHours < 48) {
      return t('time.yesterday') || 'Hier';
    } else {
      const days = Math.floor(diffInHours / 24);
      return t('time.daysAgo', { count: days }) || `Il y a ${days} jour${days > 1 ? 's' : ''}`;
    }
  };

  // Get icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'check':
        return <CheckCircleIcon className="w-4 h-4 text-green-600" />;
      case 'alert':
        return <ExclamationTriangleIcon className="w-4 h-4 text-yellow-600" />;
      case 'error':
        return <XCircleIcon className="w-4 h-4 text-red-600" />;
      case 'info':
      default:
        return <InformationCircleIcon className="w-4 h-4 text-blue-600" />;
    }
  };

  // Get background color based on notification type
  const getNotificationBgColor = (type: string) => {
    switch (type) {
      case 'check':
        return 'bg-green-100';
      case 'alert':
        return 'bg-yellow-100';
      case 'error':
        return 'bg-red-100';
      case 'info':
      default:
        return 'bg-blue-100';
    }
  };

  // Handle marking notification as seen
  const handleNotificationClick = async (notificationId: string) => {
    await markAsSeen(notificationId);
  };

  // Handle mark all as seen
  const handleMarkAllAsSeen = async () => {
    await markAllAsSeen();
  };

  const unreadCount = stats?.unseen || getUnreadCount();

  logger.log('checking user', user);

  if (hidden && !isMobile) return null;

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-40 flex items-center justify-between px-2 py-3 lg:py-4 md:px-6 bg-gray-50 dark:bg-gray-900 md:bg-transparent md:dark:bg-transparent border-b md:border-0 border-gray-100 dark:border-gray-800 transition-colors duration-200">

      {/* ─── Back arrow OR Hamburger/Close — mobile only ─── */}
      {backMode ? (
        // ── Back mode: arrow + optional page title ──
        <div className="md:hidden flex items-center gap-2 min-w-0">
          <button
            onClick={() => {
              if (backMode.onBack) {
                backMode.onBack();
              } else if (backMode.href) {
                router.push(backMode.href);
              } else {
                router.back();
              }
            }}
            className="flex items-center justify-center w-10 h-10 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors shrink-0"
            aria-label="Go back"
          >
            <ArrowLeftIcon className="w-6 h-6" />
          </button>
          {backMode.title && (
            <span className="text-base font-semibold text-gray-800 dark:text-gray-100 truncate">
              {backMode.title}
            </span>
          )}
        </div>
      ) : (
        // ── Normal mode: hamburger / X ──
        <button
          className="md:hidden flex items-center justify-center w-10 h-10 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          onClick={isMobileMenuOpen ? closeMobileMenu : openMobileMenu}
          aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
        >
          {isMobileMenuOpen
            ? <XMarkIcon className="w-7 h-7" />
            : <Bars3CenterLeftIcon className="w-8 h-8" />}
        </button>
      )}

      {/* ─── Right side actions ─── */}
      <div className="flex items-center gap-3 ml-auto">
        {/* Notification Bell */}
        <div className="relative" ref={notificationRef}>
          <div
            className="flex items-center justify-center w-10 h-10 transition-colors bg-blue-100 dark:bg-blue-900/30 rounded-full cursor-pointer hover:bg-blue-200 dark:hover:bg-blue-900/50"
            onClick={() => setIsNotificationOpen(!isNotificationOpen)}
          >
            <BellIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          </div>
          {unreadCount > 0 && (
            <span className="absolute top-0 right-0 h-2.5 w-2.5 rounded-full bg-red-500 border-2 border-white"></span>
          )}

          {/* Notifications Dropdown — desktop only */}
          {isNotificationOpen && !isMobile && (
            <div className="absolute right-0 z-50 mt-2 overflow-hidden bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-xl w-80 md:w-96 max-h-96">
              {/* Header */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 dark:border-gray-700">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">{t('header.notifications')}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {unreadCount} {unreadCount > 1 ? t('header.newMessagesPlural') : t('header.newMessages')}
                  </p>
                </div>
                <button
                  onClick={() => setIsNotificationOpen(false)}
                  className="p-1 rounded-full hover:bg-gray-100"
                >
                  <XMarkIcon className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              {/* Notifications List */}
              <div className="overflow-y-auto max-h-80">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-600"></div>
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <BellIcon className="w-12 h-12 mx-auto mb-2 text-gray-300 dark:text-gray-600" />
                    <p className="text-sm">{t('header.noNotifications')}</p>
                  </div>
                ) : (
                  notifications.slice(0, 5).map((notification) => (
                    <div
                      key={notification.id}
                      className={`px-4 py-3 border-b border-gray-50 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer transition-colors ${!notification.is_seen ? 'bg-blue-50 dark:bg-blue-900/20 border-l-4 border-l-blue-500' : ''
                        }`}
                      onClick={() => handleNotificationClick(notification.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getNotificationBgColor(notification.type)}`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <h4 className={`text-sm font-medium ${!notification.is_seen ? 'text-gray-900 dark:text-gray-100' : 'text-gray-700 dark:text-gray-300'}`}>
                              {notification.title}
                            </h4>
                            <div className="flex items-center space-x-2">
                              <span className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                                <ClockIcon className="w-3 h-3 mr-1" />
                                {formatDate(notification.created_at)}
                              </span>
                              {!notification.is_seen && (
                                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              )}
                            </div>
                          </div>
                          <p className={`text-sm mt-1 line-clamp-2 ${!notification.is_seen ? 'text-gray-800 dark:text-gray-200' : 'text-gray-600 dark:text-gray-400'}`}>
                            {notification.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Footer */}
              {notifications.length > 0 && (
                <div className="px-4 py-3 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={handleMarkAllAsSeen}
                      className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
                      disabled={unreadCount === 0}
                    >
                      {t('header.markAllAsRead')}
                    </button>
                    <Link
                      href="/notifications"
                      onClick={() => setIsNotificationOpen(false)}
                      className="text-sm text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
                    >
                      {t('header.viewAllNotifications')}
                    </Link>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ── Mobile notifications modal ──────────────────────────────────── */}
        <MobileFullModal
          isOpen={isNotificationOpen && isMobile}
          onClose={() => setIsNotificationOpen(false)}
          title={t('header.notifications')}
        >
          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-600" />
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-gray-400 dark:text-gray-500">
              <BellIcon className="w-16 h-16 mb-4 text-gray-300 dark:text-gray-600" />
              <p className="text-sm">{t('header.noNotifications')}</p>
            </div>
          ) : (() => {
            // ── Bucket notifications by date ──────────────────────────────
            const now = new Date();
            const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const start7Days = new Date(startOfToday.getTime() - 6 * 24 * 60 * 60 * 1000);
            const start30Days = new Date(startOfToday.getTime() - 29 * 24 * 60 * 60 * 1000);

            const groups: { key: string; labelKey: string; items: typeof notifications }[] = [
              { key: 'today', labelKey: 'header.groupToday', items: [] },
              { key: 'last7', labelKey: 'header.groupLast7Days', items: [] },
              { key: 'last30', labelKey: 'header.groupLast30Days', items: [] },
              { key: 'older', labelKey: 'header.groupOlder', items: [] },
            ];

            notifications.forEach((n) => {
              const d = new Date(n.created_at);
              if (d >= startOfToday) groups[0]!.items.push(n);
              else if (d >= start7Days) groups[1]!.items.push(n);
              else if (d >= start30Days) groups[2]!.items.push(n);
              else groups[3]!.items.push(n);
            });

            return (
              <div>
                {groups.filter((g) => g.items.length > 0).map((group) => (
                  <div key={group.key}>
                    {/* Section header */}
                    <div className="sticky top-0 z-10 px-4 py-2 bg-gray-50 dark:bg-gray-800/80 backdrop-blur-sm border-b border-gray-100 dark:border-gray-700">
                      <span className="text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-gray-400">
                        {t(group.labelKey)}
                      </span>
                    </div>

                    {/* Notification rows */}
                    {group.items.map((notification) => (
                      <div
                        key={notification.id}
                        className="px-4 py-4 border-b border-gray-100 dark:border-gray-800"
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${getNotificationBgColor(notification.type)}`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <h4 className="text-sm font-medium leading-snug text-gray-900 dark:text-gray-100">
                                {notification.title}
                              </h4>
                              <span className="flex items-center gap-1 text-xs text-gray-400 shrink-0">
                                <ClockIcon className="w-3 h-3" />
                                {formatDate(notification.created_at)}
                              </span>
                            </div>
                            <p className="text-sm mt-1 text-gray-500 dark:text-gray-400">
                              {notification.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            );
          })()}

        </MobileFullModal>

        {/* User Profile */}
        <Link
          href="/profile"
          className="flex items-center gap-2 h-10 py-2 px-3 transition-shadow bg-white dark:bg-gray-800 rounded-full shadow-sm cursor-pointer hover:shadow-md border border-transparent dark:border-gray-700"
        >
          <div>
            <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{user?.role === "doctor" ? "Dr." : "Asst."} {user?.name}</p>
          </div>
          {isRTL ? <ChevronRightIcon className="w-4 h-4 text-gray-400 rotate-180" /> : <ChevronRightIcon className="w-4 h-4 text-gray-400" />}
        </Link>
      </div>
    </header>
  );
}
