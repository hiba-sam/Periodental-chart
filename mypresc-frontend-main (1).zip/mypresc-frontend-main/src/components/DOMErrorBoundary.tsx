'use client';

import React, { Component, ErrorInfo, ReactNode } from 'react';
import * as Sentry from '@sentry/nextjs';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  retryCount: number;
}

/**
 * DOMErrorBoundary
 *
 * Catches DOM manipulation errors (insertBefore, removeChild, appendChild)
 * that occur when React's virtual DOM gets out of sync with the real DOM.
 *
 * Common causes:
 * - Rapid conditional rendering switching entire DOM trees
 * - Browser extensions injecting/removing nodes
 * - Hydration mismatches with dynamic imports (ssr: false)
 *
 * Instead of showing a white page, this boundary:
 * 1. Logs the error to Sentry with context
 * 2. Automatically retries rendering (up to 2 times)
 * 3. Shows a user-friendly fallback if retries fail
 */
export class DOMErrorBoundary extends Component<Props, State> {
  private static readonly MAX_RETRIES = 2;

  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, retryCount: 0 };
  }

  static getDerivedStateFromError(error: Error): Partial<State> | null {
    // Only catch DOM manipulation errors — let others propagate
    if (DOMErrorBoundary.isDOMError(error)) {
      return { hasError: true, error };
    }
    // Re-throw non-DOM errors so other boundaries or Next.js can handle them
    throw error;
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    if (DOMErrorBoundary.isDOMError(error)) {
      Sentry.captureException(error, {
        tags: {
          errorType: 'dom_manipulation_error',
          retryCount: String(this.state.retryCount),
        },
        extra: {
          componentStack: errorInfo.componentStack,
          errorMessage: error.message,
        },
      });

      // Auto-retry: reset error state after a micro-task to re-render children
      if (this.state.retryCount < DOMErrorBoundary.MAX_RETRIES) {
        setTimeout(() => {
          this.setState((prev) => ({
            hasError: false,
            error: null,
            retryCount: prev.retryCount + 1,
          }));
        }, 100);
      }
    }
  }

  private static isDOMError(error: Error): boolean {
    const msg = error.message || '';
    return (
      error.name === 'NotFoundError' ||
      msg.includes('insertBefore') ||
      msg.includes('removeChild') ||
      msg.includes('appendChild') ||
      msg.includes('is not a child of this node')
    );
  }

  private handleRetry = () => {
    this.setState({ hasError: false, error: null, retryCount: 0 });
  };

  render() {
    if (this.state.hasError && this.state.retryCount >= DOMErrorBoundary.MAX_RETRIES) {
      // All retries exhausted — show fallback
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex flex-col items-center justify-center min-h-[200px] p-8">
          <p className="text-gray-600 dark:text-gray-400 mb-4 text-center">
            Une erreur d&apos;affichage est survenue.
          </p>
          <button
            onClick={this.handleRetry}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
          >
            Réessayer
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default DOMErrorBoundary;
