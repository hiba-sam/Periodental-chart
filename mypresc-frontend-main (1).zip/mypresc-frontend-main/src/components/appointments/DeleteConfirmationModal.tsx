'use client';

import { XMarkIcon } from '@heroicons/react/24/outline';
import { Appointment } from '@/contexts/AppointmentContext';

interface DeleteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
  onConfirmDelete: () => void;
}

export default function DeleteConfirmationModal({
  isOpen,
  onClose,
  appointment,
  onConfirmDelete
}: DeleteConfirmationModalProps) {
  if (!isOpen || !appointment) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70">
      <div
        className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl w-full max-w-md mx-4 transform transition-all animate-fadeIn border border-gray-300 dark:border-gray-700"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b border-gray-300 dark:border-gray-700 bg-red-50 dark:bg-red-900/30">
          <h2 className="text-xl font-semibold text-red-700 dark:text-red-300">
            Confirmer la suppression
          </h2>
          <button
            type="button"
            className="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 focus:outline-none"
            onClick={onClose}
          >
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <p className="text-gray-800 dark:text-gray-200 mb-4">
              Êtes-vous sûr de vouloir supprimer ce rendez-vous ?
            </p>

            <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg border border-gray-200 dark:border-gray-600">
              <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Détails du rendez-vous :</h3>
              <ul className="space-y-2 text-sm">
                <li><span className="font-medium">Patient :</span> {appointment.patientName}</li>
                <li><span className="font-medium">Date :</span> {new Date(appointment.date).toLocaleDateString('fr-FR')}</li>
                <li><span className="font-medium">Heure :</span> {appointment.time}</li>
                {appointment.notes && (
                  <li><span className="font-medium">Notes :</span> {appointment.notes}</li>
                )}
              </ul>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 font-medium"
              onClick={onClose}
            >
              Annuler
            </button>
            <button
              type="button"
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 font-medium"
              onClick={onConfirmDelete}
            >
              Supprimer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
