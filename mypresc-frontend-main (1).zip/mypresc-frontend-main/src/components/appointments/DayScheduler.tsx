"use client";

import { useState, useRef, useEffect, SetStateAction, Dispatch } from "react";

interface Appointment {
  id: string;
  time: string;
  duration?: number;
  patientName?: string;
  patient_name?: string;
  patient_family_name?: string;
  color?: string;
}

interface TimeSlot {
  startTime: string;
  endTime: string;
  status: "available" | "occupied" | "selected";
  appointment?: Appointment;
}

interface DaySchedulerProps {
  selectedDate: Date;
  onTimeSlotSelect: (startTime: string, endTime: string) => void;
  existingAppointments: Appointment[];
  onAppointmentDeleted?: () => void;
  onAppointmentEdit?: (appointment: Appointment) => void;
  setEditingAppointment?: Dispatch<SetStateAction<Appointment | null>>;
}

const DayScheduler: React.FC<DaySchedulerProps> = ({
  selectedDate,
  onTimeSlotSelect,
  existingAppointments,
  onAppointmentDeleted,
  onAppointmentEdit,
  setEditingAppointment,
}) => {
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartIndex, setDragStartIndex] = useState<number | null>(null);
  const [dragEndIndex, setDragEndIndex] = useState<number | null>(null);
  const [selectedRange, setSelectedRange] = useState<{
    start: number;
    end: number;
  } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Convertir une heure au format HH:MM en minutes depuis minuit
  const timeToMinutes = (timeString: string): number => {
    const [hours, minutes] = timeString.split(":").map(Number);
    return hours * 60 + minutes;
  };

  // Convertir des minutes depuis minuit en format HH:MM
  const minutesToTime = (minutes: number): string => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours.toString().padStart(2, "0")}:${mins
      .toString()
      .padStart(2, "0")}`;
  };

  // Réinitialiser la sélection lors du changement de date
  useEffect(() => {
    setSelectedRange(null);
    setIsDragging(false);
    setDragStartIndex(null);
    setDragEndIndex(null);
  }, [selectedDate]);

  // Fonction pour générer les créneaux horaires à partir des rendez-vous
  const generateTimeSlots = (appointments: Appointment[]) => {
    const slots: TimeSlot[] = [];
    const startHour = 8; // 8h00
    const endHour = 20; // 20h00
    const intervalMinutes = 15; // Intervalles de 15 minutes

    // Créer tous les créneaux de la journée
    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += intervalMinutes) {
        const startTimeString = `${hour.toString().padStart(2, "0")}:${minute
          .toString()
          .padStart(2, "0")}`;
        const endMinutes = hour * 60 + minute + intervalMinutes;
        const endTimeString = minutesToTime(endMinutes);

        // Vérifier si ce créneau est occupé par un rendez-vous existant
        let isOccupied = false;
        let occupyingAppointment: Appointment | undefined = undefined;

        for (const appointment of appointments) {
          const appointmentStartMinutes = timeToMinutes(appointment.time);
          const duration = appointment.duration ?? 30;
          const appointmentEndMinutes = appointmentStartMinutes + duration;
          const slotStartMinutes = timeToMinutes(startTimeString);
          const slotEndMinutes = timeToMinutes(endTimeString);

          // Vérifier si le créneau chevauche le rendez-vous
          const overlaps =
            (slotStartMinutes >= appointmentStartMinutes &&
              slotStartMinutes < appointmentEndMinutes) ||
            (slotEndMinutes > appointmentStartMinutes &&
              slotEndMinutes <= appointmentEndMinutes) ||
            (slotStartMinutes <= appointmentStartMinutes &&
              slotEndMinutes >= appointmentEndMinutes);

          if (overlaps) {
            isOccupied = true;
            // Marquer comme occupyingAppointment seulement si c'est le premier créneau
            if (slotStartMinutes === appointmentStartMinutes) {
              occupyingAppointment = appointment;
            }
            break;
          }
        }

        slots.push({
          startTime: startTimeString,
          endTime: endTimeString,
          status: isOccupied ? "occupied" : "available",
          appointment: occupyingAppointment,
        });
      }
    }

    return slots;
  };

  // Initialiser les créneaux horaires avec mise à jour en temps réel
  useEffect(() => {
    const slots = generateTimeSlots(existingAppointments);
    setTimeSlots(slots);

    // Réinitialiser la sélection si un rendez-vous a été modifié
    if (existingAppointments.length > 0) {
      setSelectedRange(null);
    }
  }, [existingAppointments, selectedDate]);

  // Gérer le début du glisser-déposer
  const handleDragStart = (index: number) => {
    if (timeSlots[index].status === "occupied") return;

    setIsDragging(true);
    setDragStartIndex(index);
    setDragEndIndex(index);
    setSelectedRange(null);
  };

  // Gérer le mouvement pendant le glisser-déposer
  const handleDragMove = (index: number) => {
    if (!isDragging || dragStartIndex === null) return;
    if (timeSlots[index].status === "occupied") return;

    const minIndex = Math.min(dragStartIndex, index);
    const maxIndex = Math.max(dragStartIndex, index);

    // Vérifier si tous les créneaux sont disponibles
    const hasOccupiedSlots = timeSlots
      .slice(minIndex, maxIndex + 1)
      .some((slot) => slot.status === "occupied");

    if (hasOccupiedSlots) return;

    setDragEndIndex(index);
  };

  // Fonction pour trouver l'index du créneau à partir d'un événement tactile
  const findSlotIndexFromTouch = (
    touchEvent: React.TouchEvent
  ): number | null => {
    if (!containerRef.current) return null;

    const touch = touchEvent.touches[0];
    const container = containerRef.current;
    const containerRect = container.getBoundingClientRect();

    const relativeY = touch.clientY - containerRect.top + container.scrollTop;
    const slotHeight = 36;
    const approximateIndex = Math.floor(relativeY / slotHeight);

    if (approximateIndex >= 0 && approximateIndex < timeSlots.length) {
      return approximateIndex;
    }

    return null;
  };

  // Calculer automatiquement la durée en fonction de la sélection
  const calculateDuration = (startIndex: number, endIndex: number): number => {
    const minIndex = Math.min(startIndex, endIndex);
    const maxIndex = Math.max(startIndex, endIndex);
    const slotsCount = maxIndex - minIndex + 1;
    return slotsCount * 15; // Chaque créneau = 15 minutes
  };

  // Gérer la fin du glisser-déposer
  const handleDragEnd = () => {
    if (!isDragging || dragStartIndex === null || dragEndIndex === null) return;

    const minIndex = Math.min(dragStartIndex, dragEndIndex);
    const maxIndex = Math.max(dragStartIndex, dragEndIndex);

    const startTime = timeSlots[minIndex].startTime;
    const duration = calculateDuration(dragStartIndex, dragEndIndex);
    const endTimeMinutes = timeToMinutes(startTime) + duration;
    const endTime = minutesToTime(endTimeMinutes);

    setSelectedRange({ start: minIndex, end: maxIndex });
    onTimeSlotSelect(startTime, endTime);

    setIsDragging(false);
    setDragStartIndex(null);
    setDragEndIndex(null);
  };

  // Déterminer le statut d'un créneau (pour l'affichage)
  const getSlotStatus = (index: number): string => {
    if (timeSlots[index].status === "occupied") {
      return "text-white font-medium shadow-sm cursor-pointer";
    }

    if (isDragging && dragStartIndex !== null && dragEndIndex !== null) {
      const minIndex = Math.min(dragStartIndex, dragEndIndex);
      const maxIndex = Math.max(dragStartIndex, dragEndIndex);

      if (index >= minIndex && index <= maxIndex) {
        return "bg-blue-600 text-white font-medium shadow-md";
      }
    }

    if (
      selectedRange &&
      index >= selectedRange.start &&
      index <= selectedRange.end
    ) {
      return "bg-blue-600 text-white font-medium shadow-md";
    }

    if (timeSlots[index].status === "selected") {
      return "bg-blue-600 text-white font-medium shadow-md";
    }

    return "bg-gray-50 hover:bg-gray-200 border border-gray-300 cursor-pointer transition-colors";
  };

  // Déterminer si un créneau est le début d'un rendez-vous
  const isAppointmentStart = (index: number): boolean => {
    return !!timeSlots[index].appointment;
  };

  // Obtenir la couleur de fond pour un créneau occupé avec mise à jour en temps réel
  const getOccupiedSlotColor = (index: number): string => {
    if (timeSlots[index].status !== "occupied") return "";

    // Trouver le rendez-vous qui occupe ce créneau avec les données les plus récentes
    const slotTime = timeToMinutes(timeSlots[index].startTime);
    const appointment = existingAppointments.find((apt) => {
      const aptStart = timeToMinutes(apt.time);
      const aptEnd = aptStart + (apt.duration ?? 30);
      return slotTime >= aptStart && slotTime < aptEnd;
    });

    // Retourner la couleur du rendez-vous ou bleu par défaut
    return appointment?.color || "#2563eb";
  };

  // Obtenir les informations du rendez-vous pour un créneau
  const getSlotAppointment = (index: number): Appointment | undefined => {
    if (timeSlots[index].status !== "occupied") return undefined;

    const slotTime = timeToMinutes(timeSlots[index].startTime);
    return existingAppointments.find((apt) => {
      const aptStart = timeToMinutes(apt.time);
      const aptEnd = aptStart + (apt.duration ?? 30);
      return slotTime >= aptStart && slotTime < aptEnd;
    });
  };


  return (
    <div className="flex flex-col h-full select-none">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-sm font-medium text-gray-700">
          Horaires disponibles
        </h3>
      </div>

      <div className="flex items-center mb-2 text-xs text-gray-500">
        <div className="w-12 text-right pr-2">Heure</div>
        <div className="flex-1">Disponibilité</div>
      </div>

      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto select-none"
        onMouseUp={handleDragEnd}
        onMouseLeave={handleDragEnd}
        onTouchEnd={(e) => {
          e.preventDefault();
          handleDragEnd();
        }}
      >
        <div className="space-y-1">
          {timeSlots.map((slot, index) => (
            <div key={index} className="flex items-center h-8">
              <div className="w-12 text-right pr-2 text-xs text-gray-500">
                {slot.startTime}
              </div>
              <div
                className={`flex-1 h-full rounded-md ${getSlotStatus(
                  index
                )} flex items-center`}
                style={{
                  backgroundColor:
                    slot.status === "occupied"
                      ? getOccupiedSlotColor(index)
                      : undefined,
                }}
                onMouseDown={() => handleDragStart(index)}
                onMouseOver={() => handleDragMove(index)}
                onTouchStart={(e) => {
                  e.preventDefault();
                  handleDragStart(index);
                }}
                onTouchMove={(e) => {
                  e.preventDefault();
                  const slotIndex = findSlotIndexFromTouch(e);
                  if (slotIndex !== null) {
                    handleDragMove(slotIndex);
                  }
                }}
                onClick={() => {
                  if (setEditingAppointment) {
                    const appointment = getSlotAppointment(index);
                    if (timeSlots[index].status === "occupied" && appointment) {
                      setEditingAppointment(appointment);
                    } else {
                      setEditingAppointment(null);
                    }
                  }
                }}
                onDoubleClick={() => {
                  // Si c'est un créneau occupé, ouvrir la modal d'options
                  if (
                    timeSlots[index].status === "occupied" &&
                    timeSlots[index].appointment
                  ) {
                    // handleAppointmentDoubleClick(timeSlots[index].appointment);
                  }
                }}
              >
                {isAppointmentStart(index) && timeSlots[index].appointment && (
                  <div className="px-2 py-1 text-xs font-semibold truncate text-white w-full">
                    {(() => {
                      const currentAppointment = getSlotAppointment(index);
                      if (!currentAppointment) return null;

                      const patientName =
                        currentAppointment.patientName ||
                        `${currentAppointment.patient_name || ""} ${
                          currentAppointment.patient_family_name || ""
                        }`.trim();

                      return `${currentAppointment.time} • ${patientName}`;
                    })()}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 flex justify-between items-center text-xs text-gray-700 font-medium">
        <div className="flex items-center space-x-4">
          <div className="flex items-center">
            <span className="w-4 h-4 rounded-full bg-gray-50 border border-gray-300 mr-1"></span>
            <span>Disponible</span>
          </div>
          <div className="flex items-center">
            <span className="w-4 h-4 rounded-full bg-blue-600 mr-1"></span>
            <span>Sélectionné</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DayScheduler;
