'use client';

import React from 'react';
import MiniMonth from './MiniMonth';

interface SidebarProps {
	date: Date;
	onChangeDate: (date: Date) => void;
	view?: 'day' | 'week' | 'month';
	onViewChange?: (view: 'day' | 'week' | 'month') => void;
}

const tabs: Array<{ key: 'day' | 'week' | 'month'; label: string }> = [
	{ key: 'day', label: 'Journée' },
	{ key: 'week', label: 'Semaine' },
	{ key: 'month', label: 'Mois' }
];

export default function Sidebar({ date, onChangeDate, view = 'week', onViewChange }: SidebarProps) {
	return (
		<div className="space-y-4">
				<div className="inline-flex w-full rounded-full bg-white p-0.5">
					{tabs.map(t => (
						<button
							key={t.key}
						className={`flex-1 px-1 py-2 text-md rounded-full transition-colors ${view === t.key ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-white'}`}
							onClick={() => onViewChange && onViewChange(t.key)}
						>
							{t.label}
						</button>
					))}
				</div>
			<div>
				<MiniMonth
					activeDate={date}
					onChangeMonth={(d) => onChangeDate(d)}
					onSelectDate={(d) => onChangeDate(d)}
				/>
			</div>
		</div>
	);
}


