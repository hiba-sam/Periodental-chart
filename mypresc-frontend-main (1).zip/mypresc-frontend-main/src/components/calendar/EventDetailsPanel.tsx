'use client';

import React, { useState } from 'react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { UserIcon, PhoneIcon, ClockIcon, CalendarIcon, DocumentTextIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon, XCircleIcon } from '@heroicons/react/24/solid';
import Link from 'next/link';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface EventDetailsPanelProps {
  event: CalendarEvent;
  onEdit: (event: CalendarEvent) => void;
  onDelete: (event: CalendarEvent) => void;
}

// ============================================================================
// COMPONENT
// ============================================================================

export const EventDetailsPanel: React.FC<EventDetailsPanelProps> = ({ event, onEdit, onDelete }) => {
  const { updateEvent, updateEventOptimistic } = useCalendar();
  const { t, language } = useLanguage();
  const [isUpdatingConfirmed, setIsUpdatingConfirmed] = useState(false);
  const [isUpdatingDone, setIsUpdatingDone] = useState(false);
  
  // Local state for instant UI feedback (optimistic updates)
  const [localConfirmed, setLocalConfirmed] = useState(event.venueConfirmed);
  const [localDone, setLocalDone] = useState(event.isDone);
  
  // Sync local state when event prop changes (e.g., after API response)
  React.useEffect(() => {
    setLocalConfirmed(event.venueConfirmed);
    setLocalDone(event.isDone);
  }, [event.venueConfirmed, event.isDone, event.id]);

  // ============================================================================
  // FORMAT HELPERS
  // ============================================================================

  const formatDate = (date: Date): string => {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    return date.toLocaleDateString(locale, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (time: string): string => {
    return time;
  };

  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  const handleEditClick = () => {
    onEdit(event);
  };

  const handleDeleteClick = () => {
    onDelete(event);
  };

  const handleToggleConfirmed = async () => {
    const newValue = !localConfirmed;
    
    // Instant local UI update
    setLocalConfirmed(newValue);
    setIsUpdatingConfirmed(true);
    
    // Update context for other components
    updateEventOptimistic(event.id, { venueConfirmed: newValue });
    
    // Background API call (skipLoading=true to prevent scroll reset)
    try {
      await updateEvent({
        id: event.id,
        venue_confirmed: newValue,
      }, true);
    } catch {
      // Rollback on error
      setLocalConfirmed(!newValue);
      updateEventOptimistic(event.id, { venueConfirmed: !newValue });
    } finally {
      setIsUpdatingConfirmed(false);
    }
  };

  const handleToggleDone = async () => {
    const newValue = !localDone;
    
    // Instant local UI update
    setLocalDone(newValue);
    setIsUpdatingDone(true);
    
    // Update context for other components
    updateEventOptimistic(event.id, { isDone: newValue });
    
    // Background API call (skipLoading=true to prevent scroll reset)
    try {
      await updateEvent({
        id: event.id,
        is_done: newValue,
      }, true);
    } catch {
      // Rollback on error
      setLocalDone(!newValue);
      updateEventOptimistic(event.id, { isDone: !newValue });
    } finally {
      setIsUpdatingDone(false);
    }
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  // Color styling
  const borderColor = event.color;
  const backgroundColor = `${event.color}15`; // 15% opacity

  return (
    <div className="event-details-panel bg-white dark:bg-gray-800 rounded-lg shadow-md border-s-4 overflow-hidden" style={{ borderInlineStartColor: borderColor }}>
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 transition-colors" style={{ backgroundColor }}>
        <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-1">
          {event.isAppointmentLinked ? t('calendar.eventDetails') : t('calendar.eventTitle')}
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-200">
          {formatDate(event.date)} à {formatTime(event.time)}
        </p>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Patient Information - Only show for appointment-linked events */}
        {event.isAppointmentLinked && (
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">{t('calendar.patient')}</h4>

            {/* Patient Name */}
            <div className="flex items-start gap-3">
              <UserIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
              <div>
                {event.patientId ? <Link href={`/patients/${event.patientId}`}>
                  <p className="text-base font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline">{event.title}</p>
                </Link> : <p className="text-base font-medium text-gray-900 dark:text-gray-100">{event.title}</p>}

                {event.patientAge && (
                  <p className="text-sm text-gray-500 dark:text-gray-400">{event.patientAge} {t('calendar.years')}</p>
                )}
              </div>
            </div>

            {/* Patient Phone */}
            {event.patientPhone && (
              <div className="flex items-center gap-3">
                <PhoneIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                <a
                  href={`tel:${event.patientPhone}`}
                  className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline"
                >
                  {event.patientPhone}
                </a>
              </div>
            )}
          </div>
        )}

        {/* Event Title - Only show for free events */}
        {!event.isAppointmentLinked && (
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">{t('calendar.event')}</h4>
            <div className="flex items-start gap-3">
              <CalendarIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
              <p className="text-base font-medium text-gray-900 dark:text-gray-100">{event.title}</p>
            </div>
          </div>
        )}

        {/* Date and Time Information */}
        <div className={`space-y-3 ${event.isAppointmentLinked ? 'pt-4 border-t border-gray-200 dark:border-gray-700' : ''}`}>
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">
            {event.isAppointmentLinked ? t('calendar.appointment') : t('calendar.schedule')}
          </h4>

          {/* Date */}
          <div className="flex items-center gap-3">
            <CalendarIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
            <p className="text-sm text-gray-700 dark:text-gray-300">{formatDate(event.date)}</p>
          </div>

          {/* Time */}
          <div className="flex items-center gap-3">
            <ClockIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
            <p className="text-sm text-gray-700 dark:text-gray-300">
              {formatTime(event.time)} - {formatTime(event.endTime || '')} ({event.duration} {t('calendar.min')})
            </p>
          </div>

          {/* Description/Notes */}
          {event.description && (
            <div className="flex items-start gap-3">
              <DocumentTextIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{event.description}</p>
            </div>
          )}
        </div>

        {/* Status Toggles - Only show for appointment-linked events */}
        {event.isAppointmentLinked && (
          <div className="space-y-2 pt-4 border-t border-gray-200 dark:border-gray-700">
            <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide mb-3">{t('calendar.status')}</h4>

            {/* Confirmed Status */}
            <button
              onClick={handleToggleConfirmed}
              disabled={isUpdatingConfirmed}
              className={`
                w-full flex items-center gap-3 p-3 rounded-md border-2 transition-all
                ${localConfirmed
                  ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 hover:bg-green-100 dark:hover:bg-green-900/30'
                  : 'bg-gray-50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'
                }
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              {localConfirmed ? (
                <CheckCircleIcon className="w-5 h-5 text-green-600 dark:text-green-500 flex-shrink-0" />
              ) : (
                <XCircleIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
              )}
              <span className={`text-sm font-medium ${localConfirmed ? 'text-green-700 dark:text-green-400' : 'text-gray-600 dark:text-gray-300'}`}>
                {localConfirmed ? t('calendar.confirmed') : t('calendar.notConfirmed')}
              </span>
            </button>

            {/* Done Status */}
            <button
              onClick={handleToggleDone}
              disabled={isUpdatingDone}
              className={`
                w-full flex items-center gap-3 p-3 rounded-md border-2 transition-all
                ${localDone
                  ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/30'
                  : 'bg-gray-50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'
                }
                disabled:opacity-50 disabled:cursor-not-allowed
              `}
            >
              {localDone ? (
                <CheckCircleIcon className="w-5 h-5 text-blue-600 dark:text-blue-500 flex-shrink-0" />
              ) : (
                <XCircleIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
              )}
              <span className={`text-sm font-medium ${localDone ? 'text-blue-700 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'}`}>
                {localDone ? t('calendar.completed') : t('calendar.pending')}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="p-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 flex gap-3">
        <button
          onClick={handleEditClick}
          className="
            flex-1 px-4 py-2 bg-blue-600 text-white rounded-md
            hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2
            transition-colors font-medium text-sm
          "
        >
          {t('calendar.edit')}
        </button>
        <button
          onClick={handleDeleteClick}
          className="
            flex-1 px-4 py-2 bg-white dark:bg-gray-800 text-red-600 dark:text-red-400 border-2 border-red-600 dark:border-red-400 rounded-md
            hover:bg-red-50 dark:hover:bg-red-900/20 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2
            transition-colors font-medium text-sm
          "
        >
          {t('calendar.delete')}
        </button>
      </div>
    </div>
  );
};

export default EventDetailsPanel;
