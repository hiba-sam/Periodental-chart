'use client';

import React, { useMemo, useCallback } from 'react';
import { DndContext, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useCalendarDragDrop, customCollisionDetection } from '@/hooks/useCalendarDragDrop';
import { DraggableEvent } from './DraggableEvent';
import { DroppableSlot } from './DroppableSlot';
import { useTheme } from '@/contexts/ThemeContext';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface TimeSlot {
  hour: number;
  minute: number;
  label: string;
}

interface DayViewGridProps {
  onSlotClick?: (date: Date, time: string) => void;
  onEventClick?: (event: CalendarEvent) => void;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const HOURS_START = 8; // 8:00 AM
const HOURS_END = 31; // 7:00 AM next day (8 + 24 - 1)
const SLOT_HEIGHT = 80; // pixels per hour (4 × 20px slots)
const QUARTER_SLOT_HEIGHT = 20; // pixels per 15-minute slot
const EVENT_HEIGHT = 25; // fixed height for all events
const EVENT_SPACING = 5; // vertical spacing between events

// Color palette with transparency for event blocks
const COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
  '#2563eb': { bg: 'rgba(37, 99, 235, 0.15)', border: '#2563eb', text: '#1e40af' },
  '#10b981': { bg: 'rgba(16, 185, 129, 0.15)', border: '#10b981', text: '#047857' },
  '#ef4444': { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#b91c1c' },
  '#f59e0b': { bg: 'rgba(245, 158, 11, 0.15)', border: '#f59e0b', text: '#d97706' },
  '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#6d28d9' },
  '#6b7280': { bg: 'rgba(107, 114, 128, 0.15)', border: '#6b7280', text: '#4b5563' },
};

// Dark mode variants - Lighter text and slightly more visible background
const DARK_COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
  '#2563eb': { bg: 'rgba(59, 130, 246, 0.25)', border: '#3b82f6', text: '#dbeafe' }, // Blue-500 bg, Blue-100 text
  '#10b981': { bg: 'rgba(16, 185, 129, 0.25)', border: '#10b981', text: '#d1fae5' }, // Emerald-500 bg, Emerald-100 text
  '#ef4444': { bg: 'rgba(239, 68, 68, 0.25)', border: '#ef4444', text: '#fee2e2' }, // Red-500 bg, Red-100 text
  '#f59e0b': { bg: 'rgba(245, 158, 11, 0.25)', border: '#f59e0b', text: '#fef3c7' }, // Amber-500 bg, Amber-100 text
  '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.25)', border: '#8b5cf6', text: '#ede9fe' }, // Violet-500 bg, Violet-100 text
  '#6b7280': { bg: 'rgba(107, 114, 128, 0.25)', border: '#6b7280', text: '#f3f4f6' }, // Gray-500 bg, Gray-100 text
};

// ============================================================================
// COMPONENT
// ============================================================================

export const DayViewGrid: React.FC<DayViewGridProps> = ({ onSlotClick, onEventClick }) => {
  const { selectedDate, getEventsForDate, selectEvent, selectedEvent } = useCalendar();
  const { actualTheme } = useTheme();

  // Drag & drop functionality
  const { dragState, handlers } = useCalendarDragDrop();

  // Configure pointer sensor with activation constraints
  // This ensures clicks don't accidentally trigger drags
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // Drag only starts after moving 8px
      },
    })
  );

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================

  const isToday = (date: Date): boolean => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isPast = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  /**
   * Check if two events overlap in time
   */
  const eventsOverlap = (event1: CalendarEvent, event2: CalendarEvent): boolean => {
    const getEndMinutes = (event: CalendarEvent) => {
      const [hours, minutes] = event.time.split(':').map(Number);
      const startMinutes = hours * 60 + minutes;
      return startMinutes + (event.duration || 30);
    };

    const getStartMinutes = (event: CalendarEvent) => {
      const [hours, minutes] = event.time.split(':').map(Number);
      return hours * 60 + minutes;
    };

    const start1 = getStartMinutes(event1);
    const end1 = getEndMinutes(event1);
    const start2 = getStartMinutes(event2);
    const end2 = getEndMinutes(event2);

    // Events overlap if one starts before the other ends
    return start1 < end2 && start2 < end1;
  };

  const getEventStyle = (event: CalendarEvent, eventsInSameDay: CalendarEvent[]) => {
    const [hours, minutes] = event.time.split(':').map(Number);
    const startMinutes = hours * 60 + minutes;
    let offsetMinutes = startMinutes - HOURS_START * 60;

    // Handle events in the early morning (00:00 - 07:59) - they should appear at the bottom
    if (startMinutes < HOURS_START * 60) {
      offsetMinutes = (24 * 60) + startMinutes - HOURS_START * 60;
    }

    // Calculate top position based on 15-minute precision
    const top = (offsetMinutes / 15) * QUARTER_SLOT_HEIGHT;

    // Calculate height based on duration
    const durationInMinutes = event.duration || 30;
    const baseSlotHeight = QUARTER_SLOT_HEIGHT * 2; // 40px for 30 minutes

    // 15min = 20px (half of 30min slot), 30min+ = proportional
    const height = durationInMinutes === 15
      ? baseSlotHeight / 2 // 20px for 15min events
      : Math.min(baseSlotHeight, (durationInMinutes / 30) * baseSlotHeight);

    // Find overlapping events to calculate horizontal positioning
    const overlappingEvents = eventsInSameDay.filter(e =>
      e.id !== event.id && eventsOverlap(event, e)
    );

    let columnIndex = 0;
    let totalColumns = 1;

    if (overlappingEvents.length > 0) {
      // Sort all overlapping events (including current) by start time, then by ID for consistency
      const allOverlapping = [event, ...overlappingEvents].sort((a, b) => {
        const timeCompare = a.time.localeCompare(b.time);
        if (timeCompare !== 0) return timeCompare;
        return a.id.localeCompare(b.id);
      });

      columnIndex = allOverlapping.findIndex(e => e.id === event.id);
      totalColumns = allOverlapping.length;

      console.log(`[DayView getEventStyle] Event "${event.title}" overlaps with ${overlappingEvents.length} events. Column ${columnIndex + 1}/${totalColumns}`);
    }

    // Calculate width and left position based on columns
    const widthPercent = 100 / totalColumns;
    const leftPercent = columnIndex * widthPercent;

    console.log(`[DayView getEventStyle] Event "${event.title}" at ${event.time} (${hours}:${minutes}) duration=${durationInMinutes}min => top: ${top}px, height: ${height}px, width: ${widthPercent}%, left: ${leftPercent}%`);

    return {
      top: `${top}px`,
      height: `${height}px`,
      width: `${widthPercent}%`,
      left: `${leftPercent}%`,
    };
  };

  const getEventColors = (color: string) => {
    const variants = actualTheme === 'dark' ? DARK_COLOR_VARIANTS : COLOR_VARIANTS;
    return variants[color] || (actualTheme === 'dark' ? DARK_COLOR_VARIANTS['#2563eb'] : COLOR_VARIANTS['#2563eb']);
  };

  /**
   * Check if a specific time slot is in the past
   */
  const isTimeSlotPast = (date: Date, hour: number): boolean => {
    const now = new Date();
    const slotDate = new Date(date);

    // Handle hours beyond 23 (next day)
    if (hour >= 24) {
      slotDate.setDate(slotDate.getDate() + 1);
      slotDate.setHours(hour - 24, 0, 0, 0);
    } else {
      slotDate.setHours(hour, 0, 0, 0);
    }

    return slotDate < now;
  };

  // ============================================================================
  // COMPUTED DATA
  // ============================================================================

  const timeSlots: TimeSlot[] = useMemo(() => {
    const slots: TimeSlot[] = [];
    for (let i = 0; i < 24; i++) {
      const hour = (HOURS_START + i) % 24;
      slots.push({
        hour: HOURS_START + i, // Keep original for calculations
        minute: 0,
        label: `${String(hour).padStart(2, '0')}:00`,
      });
    }
    return slots;
  }, []);

  const dayEvents = useMemo(() => {
    return getEventsForDate(selectedDate);
  }, [selectedDate, getEventsForDate]);

  const dateLabel = useMemo(() => {
    return selectedDate.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }, [selectedDate]);

  const dayIsPast = isPast(selectedDate);
  const dayIsToday = isToday(selectedDate);

  /**
   * Get current time in minutes from HOURS_START
   */
  const getCurrentTimeOffset = (): number => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTotalMinutes = currentHour * 60 + currentMinute;
    const startTotalMinutes = HOURS_START * 60;

    // If current time is before HOURS_START, return 0 (top of calendar)
    if (currentTotalMinutes < startTotalMinutes) {
      return 0;
    }

    return currentTotalMinutes - startTotalMinutes;
  };


  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  const handleSlotClick = useCallback((hour: number, minute: number) => {
    // Check if time slot is in the past
    if (isTimeSlotPast(selectedDate, hour)) {
      return;
    }

    // Handle hours beyond 23 (next day)
    let slotDate = new Date(selectedDate);
    let actualHour = hour;

    if (hour >= 24) {
      slotDate.setDate(slotDate.getDate() + 1);
      actualHour = hour - 24;
    }

    const time = `${String(actualHour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    onSlotClick?.(slotDate, time);
  }, [selectedDate, onSlotClick]);

  const handleEventClick = useCallback((event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    selectEvent(event);
    onEventClick?.(event);
  }, [selectEvent, onEventClick]);

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={customCollisionDetection}
      onDragStart={handlers.onDragStart}
      onDragOver={handlers.onDragOver}
      onDragEnd={handlers.onDragEnd}
      onDragCancel={handlers.onDragCancel}
    >
      <div className="day-view-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
        {/* Day Header */}
        <div className={`p-4 border-b border-gray-200 dark:border-gray-700 ${dayIsToday ? 'bg-blue-50 dark:bg-blue-900/40' : 'bg-gray-50 dark:bg-gray-900'}`}>
          <h3 className={`text-lg font-semibold capitalize ${dayIsToday ? 'text-blue-600 dark:text-blue-400' : 'text-gray-800 dark:text-gray-100'}`}>
            {dateLabel}
          </h3>
          {dayIsToday && <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">Aujourd'hui</p>}
          {dayEvents.length > 0 && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {dayEvents.length} rendez-vous
            </p>
          )}
        </div>

        {/* Time Grid */}
        <div className="day-view-grid-body relative overflow-y-auto" style={{ height: 'calc(100vh - 220px)' }}>
          <div className="relative">
            {/* Grid container */}
            <div className="grid grid-cols-[80px_1fr]">
              {/* Time labels column */}
              <div className="border-e border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 relative z-10">
                {timeSlots.map((slot) => (
                  <div
                    key={slot.hour}
                    className="relative text-sm font-medium text-gray-600 dark:text-gray-400 text-end pe-3"
                    style={{ height: `${SLOT_HEIGHT}px`, lineHeight: `${SLOT_HEIGHT}px` }}
                  >
                    <span dir="ltr">{slot.label}</span>
                  </div>
                ))}
              </div>

              {/* Day column with events */}
              <div className="relative overflow-hidden">
                {/* Time slot cells */}
                {timeSlots.map((slot) => {
                  const slotIsPast = isTimeSlotPast(selectedDate, slot.hour);

                  return (
                    <div
                      key={slot.hour}
                      className="relative h-[80px]"
                    >
                      {/* Clickable slot - first 30min (00 minutes) */}
                      <DroppableSlot
                        id={`slot-${selectedDate.toISOString()}-${String(slot.hour >= 24 ? slot.hour - 24 : slot.hour).padStart(2, '0')}:00`}
                        disabled={slotIsPast}
                        className="absolute top-0 left-0 right-0 h-[40px]"
                        style={{ zIndex: 20 }}
                      >
                        <div
                          role="button"
                          tabIndex={slotIsPast ? -1 : 0}
                          aria-label={`Create event at ${slot.label}`}
                          className={`
                          w-full h-full transition-colors
                          ${slotIsPast ? 'bg-gray-100 dark:bg-gray-900/80 cursor-not-allowed' : 'cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}
                        `}
                          style={{
                            pointerEvents: 'auto',
                          }}
                          onClick={() => !slotIsPast && handleSlotClick(slot.hour, 0)}
                          onKeyDown={(e) => {
                            if (!slotIsPast && (e.key === 'Enter' || e.key === ' ')) {
                              e.preventDefault();
                              handleSlotClick(slot.hour, 0);
                            }
                          }}
                        />
                      </DroppableSlot>

                      {/* Clickable slot - second 30min (30 minutes) */}
                      <DroppableSlot
                        id={`slot-${selectedDate.toISOString()}-${String(slot.hour >= 24 ? slot.hour - 24 : slot.hour).padStart(2, '0')}:30`}
                        disabled={slotIsPast}
                        className="absolute left-0 right-0 top-[40px] h-[40px]"
                        style={{ zIndex: 21 }}
                      >
                        <div
                          role="button"
                          tabIndex={slotIsPast ? -1 : 0}
                          aria-label={`Create event at ${slot.label.replace(':00', ':30')}`}
                          className={`
                          w-full h-full transition-colors
                          ${slotIsPast ? 'bg-gray-100 dark:bg-gray-900/80 cursor-not-allowed' : 'cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}
                        `}
                          style={{
                            pointerEvents: 'auto',
                          }}
                          onClick={() => !slotIsPast && handleSlotClick(slot.hour, 30)}
                          onKeyDown={(e) => {
                            if (!slotIsPast && (e.key === 'Enter' || e.key === ' ')) {
                              e.preventDefault();
                              handleSlotClick(slot.hour, 30);
                            }
                          }}
                        />
                      </DroppableSlot>
                    </div>
                  );
                })}

                {/* Event blocks (absolute positioned) */}
                <div className="absolute top-0 left-0 right-0 pointer-events-none px-2" style={{ zIndex: 30 }}>
                  {dayEvents.map((event) => {
                    const eventStyle = getEventStyle(event, dayEvents);
                    const colors = getEventColors(event.color);
                    const isSelected = selectedEvent?.id === event.id;

                    console.log(`[DayView EVENT RENDER] ${event.title}: duration=${event.duration}min, style=`, eventStyle);

                    return (
                      <DraggableEvent
                        key={event.id}
                        event={event}
                        isDraggingAny={dragState.isDragging}
                        style={{
                          top: eventStyle.top,
                          height: eventStyle.height,
                          width: eventStyle.width,
                          insetInlineStart: eventStyle.left,
                          zIndex: 30,
                          maxWidth: 'calc(100% - 8px)',
                        }}
                        className={`
                        absolute rounded-lg border-s-4
                        transition-all duration-150 pointer-events-auto overflow-hidden
                        ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'shadow-md hover:shadow-lg'}
                      `}
                        onClick={(e) => handleEventClick(event, e)}
                      >
                        <div
                          className="w-full h-full px-3 py-1.5 flex flex-col justify-center"
                          style={{
                            backgroundColor: colors.bg,
                            borderInlineStartColor: colors.border,
                          }}
                          title={`${event.time} - ${event.endTime}: ${event.title}${event.description ? ' - ' + event.description : ''}`}
                        >
                          {/* Compact event display */}
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-xs font-bold whitespace-nowrap ${event.isDone ? 'line-through opacity-60' : ''}`}
                              style={{ color: colors.text }}
                            >
                              {event.time}
                            </span>
                            <span
                              className={`text-xs font-semibold truncate flex-1 ${event.isDone ? 'line-through opacity-60' : ''}`}
                              style={{ color: colors.text }}
                            >
                              {event.title}
                            </span>
                            {/* Status indicator dots - Only show for appointments */}
                            {event.isAppointmentLinked && (
                              <div className="flex items-center gap-1 flex-shrink-0">
                                {event.venueConfirmed && !event.isDone && (
                                  <span className="w-2 h-2 rounded-full bg-green-500" title="Confirmé" />
                                )}
                                {!event.venueConfirmed && !event.isDone && (
                                  <span className="w-2 h-2 rounded-full bg-yellow-500" title="Non confirmé" />
                                )}
                                {event.isDone && (
                                  <span className="w-2 h-2 rounded-full bg-blue-600" title="Terminé" />
                                )}
                              </div>
                            )}
                            <span className="text-[10px] text-gray-600 dark:text-gray-300 font-medium">
                              {event.duration}min
                            </span>
                          </div>
                        </div>
                      </DraggableEvent>
                    );
                  })}
                </div>


                {/* Horizontal grid lines spanning across (positioned absolutely) */}
                <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 25 }}>
                  {timeSlots.map((slot, index) => (
                    <React.Fragment key={slot.hour}>
                      {/* Main hour line (solid, darker) */}
                      <div
                        className="absolute left-0 right-0 border-t border-gray-300 dark:border-gray-600 w-full"
                        style={{ top: `${index * SLOT_HEIGHT}px` }}
                      />
                      {/* 30-min line (medium) */}
                      <div
                        className="absolute left-0 right-0 border-t border-gray-200 dark:border-gray-700 w-full"
                        style={{ top: `${index * SLOT_HEIGHT + QUARTER_SLOT_HEIGHT * 2}px` }}
                      />
                    </React.Fragment>
                  ))}

                  {/* Current time indicator - only show if today */}
                  {dayIsToday && (() => {
                    const currentTimeMinutes = getCurrentTimeOffset();
                    const topPosition = (currentTimeMinutes / 60) * SLOT_HEIGHT;

                    // Only show if current time is within calendar hours
                    if (currentTimeMinutes >= 0) {
                      return (
                        <div
                          className="absolute left-0 right-0 h-[2px] bg-red-500 w-full"
                          style={{ top: `${topPosition}px`, zIndex: 40 }}
                        />
                      );
                    }
                    return null;
                  })()}
                </div>
              </div>
            </div>


          </div>
        </div>

        {/* No events message */}
        {dayEvents.length === 0 && (
          <div className="p-12 text-center">
            <div className="text-gray-400 dark:text-gray-600 text-5xl mb-4">📅</div>
            <p className="text-gray-500 dark:text-gray-400 text-lg font-medium">Aucun rendez-vous ce jour</p>
            <p className="text-gray-400 dark:text-gray-500 text-sm mt-2">
              Cliquez sur un créneau horaire pour créer un rendez-vous
            </p>
          </div>
        )}
      </div>
    </DndContext >
  );
};

export default DayViewGrid;
