/**
 * DraggableEvent.tsx
 *
 * Wrapper component that makes calendar events draggable.
 * Provides visual feedback during dragging and handles drag state.
 * Implements smart click vs drag detection using dnd-kit's PointerSensor.
 *
 * KEY FIX: The DndContext must be configured with a PointerSensor that has
 * an activationConstraint (distance: 8px). This ensures that:
 * 1. Clicks on any part of the event (including bottom slots) work reliably
 * 2. Drags only start after intentional movement beyond the threshold
 * 3. Works consistently across all views (Day, Week, Month)
 * 4. dnd-kit natively handles the distinction between click and drag
 */

import React from 'react';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { CalendarEvent } from '@/contexts/CalendarContext';

interface DraggableEventProps {
  event: CalendarEvent;
  children: React.ReactNode;
  isDraggingAny: boolean;
  style?: React.CSSProperties;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
}

/**
 * Makes a calendar event draggable with smart click detection
 */
export const DraggableEvent: React.FC<DraggableEventProps> = ({
  event,
  children,
  isDraggingAny,
  style = {},
  className = '',
  onClick,
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    isDragging,
  } = useDraggable({
    id: event.id,
    data: {
      event,
      type: 'calendar-event',
    },
  });

  /**
   * Handle click on event
   *
   * Since the DndContext uses PointerSensor with distance activation constraint,
   * this onClick will only fire when the user doesn't move beyond the threshold.
   * If they move beyond 8px, dnd-kit starts the drag and prevents click.
   */
  const handleClick = (e: React.MouseEvent) => {
    // Only trigger click if not currently dragging
    if (!isDragging && !isDraggingAny && onClick) {
      console.log('[DraggableEvent] ✅ Click detected on event:', event.title);
      e.stopPropagation();
      onClick(e);
    }
  };

  // Apply transform for drag feedback
  const dragStyle: React.CSSProperties = {
    ...style,
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.5 : 1,
    cursor: isDragging ? 'grabbing' : 'grab',
    zIndex: isDragging ? 1000 : style.zIndex || 30,
    transition: isDragging ? 'none' : 'all 150ms ease',
    // Prevent text selection during drag
    userSelect: 'none',
    WebkitUserSelect: 'none',
  };

  return (
    <div
      ref={setNodeRef}
      style={dragStyle}
      {...listeners}
      {...attributes}
      className={className}
      onClick={handleClick}
    >
      {children}
    </div>
  );
};
