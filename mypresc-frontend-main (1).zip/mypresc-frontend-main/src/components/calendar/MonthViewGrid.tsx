'use client';

import React, { useMemo } from 'react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface DayCell {
  date: Date;
  dayNumber: number;
  isCurrentMonth: boolean;
  isToday: boolean;
  isPast: boolean;
  events: CalendarEvent[];
}

interface MonthViewGridProps {
  onDayClick?: (date: Date) => void;
  onEventClick?: (event: CalendarEvent) => void;
}

// ============================================================================
// CONSTANTS
// ============================================================================

// Day names are now dynamically generated based on language

// Color palette for event dots
const EVENT_COLORS: Record<string, string> = {
  '#2563eb': '#2563eb',
  '#10b981': '#10b981',
  '#ef4444': '#ef4444',
  '#f59e0b': '#f59e0b',
  '#8b5cf6': '#8b5cf6',
  '#6b7280': '#6b7280',
};

// ============================================================================
// COMPONENT
// ============================================================================

export const MonthViewGrid: React.FC<MonthViewGridProps> = ({ onDayClick, onEventClick }) => {
  const { selectedDate, getEventsForMonth, selectEvent } = useCalendar();
  const { language, isRTL } = useLanguage();

  // ============================================================================
  // COMPUTED VALUES
  // ============================================================================

  /**
   * Generate week day names based on language
   */
  const weekDays = useMemo(() => {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    // Start from Monday (1) to Sunday (0)
    const days = [1, 2, 3, 4, 5, 6, 0];
    return days.map(day => {
      const date = new Date(2024, 0, day + 1); // January 2024 starts on Monday
      return date.toLocaleDateString(locale, { weekday: 'short' });
    });
  }, [language]);

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================

  const getMonthStart = (date: Date): Date => {
    return new Date(date.getFullYear(), date.getMonth(), 1);
  };

  const getMonthEnd = (date: Date): Date => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0);
  };

  const getCalendarStart = (monthStart: Date): Date => {
    const day = monthStart.getDay();
    const diff = day === 0 ? -6 : 1 - day; // Monday start
    const start = new Date(monthStart);
    start.setDate(monthStart.getDate() + diff);
    return start;
  };

  const isToday = (date: Date): boolean => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isPast = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  const isSameMonth = (date1: Date, date2: Date): boolean => {
    return date1.getMonth() === date2.getMonth() && date1.getFullYear() === date2.getFullYear();
  };

  const isSameDay = (date1: Date, date2: Date): boolean => {
    return (
      date1.getDate() === date2.getDate() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getFullYear() === date2.getFullYear()
    );
  };

  // ============================================================================
  // COMPUTED DATA
  // ============================================================================

  const monthEvents = useMemo(() => {
    return getEventsForMonth(selectedDate);
  }, [selectedDate, getEventsForMonth]);

  const calendarCells: DayCell[] = useMemo(() => {
    const monthStart = getMonthStart(selectedDate);
    const monthEnd = getMonthEnd(selectedDate);
    const calendarStart = getCalendarStart(monthStart);

    const cells: DayCell[] = [];
    const current = new Date(calendarStart);

    // Generate 42 cells (6 weeks)
    for (let i = 0; i < 42; i++) {
      const dayEvents = monthEvents.filter((event) => isSameDay(event.date, current));

      cells.push({
        date: new Date(current),
        dayNumber: current.getDate(),
        isCurrentMonth: isSameMonth(current, selectedDate),
        isToday: isToday(current),
        isPast: isPast(current),
        events: dayEvents,
      });

      current.setDate(current.getDate() + 1);
    }

    return cells;
  }, [selectedDate, monthEvents]);

  const monthLabel = useMemo(() => {
    const localeStr = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    return selectedDate.toLocaleDateString(localeStr, {
      month: 'long',
      year: 'numeric',
    });
  }, [selectedDate, language]);

  // ============================================================================
  // OCCUPATION RATE CALCULATION
  // ============================================================================

  const getOccupationRate = (events: CalendarEvent[]): number => {
    if (events.length === 0) return 0;
    if (events.length >= 8) return 100;
    return (events.length / 8) * 100;
  };

  const getOccupationColor = (rate: number): string => {
    if (rate === 0) return '';
    if (rate < 40) return 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800';
    if (rate < 70) return 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800';
    if (rate < 90) return 'bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800';
    return 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800';
  };

  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  const handleDayClick = (cell: DayCell) => {
    onDayClick?.(cell.date);
  };

  const handleEventClick = (event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    selectEvent(event);
    onEventClick?.(event);
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="month-view-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
      {/* Month Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
        <h3 className="text-lg font-semibold capitalize text-gray-800 dark:text-gray-100">
          {monthLabel}
        </h3>
      </div>

      {/* Calendar Grid */}
      <div className="p-4">
        {/* Week day headers */}
        <div className="grid grid-cols-7 mb-2" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
          {weekDays.map((day, idx) => (
            <div key={idx} className="text-center text-sm font-semibold text-gray-600 dark:text-gray-400 py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar cells */}
        <div className="grid grid-cols-7 gap-2" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
          {calendarCells.map((cell, idx) => {
            const occupationRate = getOccupationRate(cell.events);
            const occupationColor = getOccupationColor(occupationRate);

            return (
              <div
                key={idx}
                onClick={() => handleDayClick(cell)}
                className={`
                  relative min-h-[100px] p-2 border-2 rounded-lg cursor-pointer
                  transition-all duration-150 hover:shadow-md
                  ${cell.isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-900'}
                  ${cell.isToday ? 'ring-2 ring-blue-500 border-blue-300 dark:border-blue-700' : 'border-gray-200 dark:border-gray-700'}
                  ${cell.isPast && !cell.isToday ? 'opacity-60' : ''}
                  ${occupationColor}
                `}
              >
                {/* Day number */}
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`
                      text-sm font-semibold
                      ${cell.isToday ? 'text-blue-600 dark:text-blue-400' : cell.isCurrentMonth ? 'text-gray-800 dark:text-gray-200' : 'text-gray-400 dark:text-gray-600'}
                    `}
                  >
                    {cell.dayNumber}
                  </span>

                  {/* Event count badge */}
                  {cell.events.length > 0 && (
                    <span className="text-xs px-2 py-0.5 bg-blue-600 text-white rounded-full font-medium">
                      {cell.events.length}
                    </span>
                  )}
                </div>

                {/* Events list (max 3 visible) */}
                <div className="space-y-1">
                  {cell.events.slice(0, 3).map((event) => {
                    const eventColor = EVENT_COLORS[event.color] || EVENT_COLORS['#2563eb'];

                    return (
                      <div
                        key={event.id}
                        onClick={(e) => handleEventClick(event, e)}
                        className="flex items-center gap-1 text-xs p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        style={{ borderLeft: `3px solid ${eventColor}` }}
                      >
                        <span className="font-medium text-gray-700 dark:text-gray-300 truncate">
                          {event.time}
                        </span>
                        <span className="text-gray-600 dark:text-gray-400 truncate flex-1">
                          {event.title}
                        </span>
                      </div>
                    );
                  })}

                  {/* More indicator */}
                  {cell.events.length > 3 && (
                    <div className="text-xs text-gray-500 font-medium pl-1">
                      +{cell.events.length - 3} de plus
                    </div>
                  )}
                </div>

                {/* Empty day indicator */}
                {cell.events.length === 0 && cell.isCurrentMonth && !cell.isPast && (
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <span className="text-gray-400 text-xs">Cliquez pour ajouter</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Taux d'occupation</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded border-2 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800" />
              <span className="text-xs text-gray-600 dark:text-gray-400">Faible (&lt;40%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded border-2 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800" />
              <span className="text-xs text-gray-600 dark:text-gray-400">Modéré (40-70%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded border-2 bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800" />
              <span className="text-xs text-gray-600 dark:text-gray-400">Élevé (70-90%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded border-2 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800" />
              <span className="text-xs text-gray-600 dark:text-gray-400">Complet (&gt;90%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonthViewGrid;
