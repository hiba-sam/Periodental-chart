'use client';

import React from 'react';

interface AppointmentLike {
	id: string;
	date: Date;
	duration: number;
	patientName?: string;
	time?: string;
	color?: string;
}

interface CalendarDay {
	day: number;
	currentMonth: boolean;
	date: Date;
}

interface MonthGridProps {
	monthDate: Date; // any day within the month
	appointments: AppointmentLike[];
	onDayClick?: (date: Date) => void;
}

const getDaysInMonth = (date: Date): CalendarDay[] => {
	const year = date.getFullYear();
	const month = date.getMonth();
	const daysInMonth = new Date(year, month + 1, 0).getDate();

	const firstDayOfMonth = new Date(year, month, 1).getDay();
	const daysArray: CalendarDay[] = [];

	const prevMonthDays = new Date(year, month, 0).getDate();
	for (let i = firstDayOfMonth - 1; i >= 0; i--) {
		daysArray.push({ day: prevMonthDays - i, currentMonth: false, date: new Date(year, month - 1, prevMonthDays - i) });
	}

	for (let i = 1; i <= daysInMonth; i++) {
		daysArray.push({ day: i, currentMonth: true, date: new Date(year, month, i) });
	}

	const remainingDays = 42 - daysArray.length;
	for (let i = 1; i <= remainingDays; i++) {
		daysArray.push({ day: i, currentMonth: false, date: new Date(year, month + 1, i) });
	}

	return daysArray;
};

const getAppointmentsForDate = (all: AppointmentLike[], date: Date) => {
	return all.filter(appointment =>
		appointment.date.getDate() === date.getDate() &&
		appointment.date.getMonth() === date.getMonth() &&
		appointment.date.getFullYear() === date.getFullYear()
	);
};

const calculateDayOccupationRate = (all: AppointmentLike[], date: Date) => {
	const dayAppointments = getAppointmentsForDate(all, date);
	const totalSlots = (20 - 8) * 4; // 15min slots
	let occupiedSlots = 0;
	dayAppointments.forEach(apt => {
		const appointmentSlots = Math.ceil(apt.duration / 15);
		occupiedSlots += appointmentSlots;
	});
	return Math.min(occupiedSlots / totalSlots, 1);
};

const getColorByOccupationRate = (rate: number) => {
	if (rate === 0) return 'bg-white hover:bg-gray-100';
	if (rate < 0.25) return 'bg-green-100 hover:bg-green-200';
	if (rate < 0.5) return 'bg-yellow-100 hover:bg-yellow-200';
	if (rate < 0.75) return 'bg-orange-100 hover:bg-orange-200';
	if (rate < 1) return 'bg-red-100 hover:bg-red-200';
	return 'bg-red-200 hover:bg-red-300';
};

export default function MonthGrid({ monthDate, appointments, onDayClick }: MonthGridProps) {
	const today = new Date();
	return (
		<div className="bg-gray-50 rounded-lg p-4">
			<div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-gray-500 mb-2">
				<div>D</div><div>L</div><div>M</div><div>M</div><div>J</div><div>V</div><div>S</div>
			</div>
			<div className="grid grid-cols-7 gap-1 text-center">
				{getDaysInMonth(monthDate).map((day, index) => {
					const occupationRate = calculateDayOccupationRate(appointments, day.date);
					const dayAppointments = getAppointmentsForDate(appointments, day.date);
					const isToday = day.date.getDate() === today.getDate() && day.date.getMonth() === today.getMonth() && day.date.getFullYear() === today.getFullYear();
					const isPastDay = day.date < new Date(new Date().setHours(0, 0, 0, 0));
					const colorClass = isPastDay ? 'bg-gray-100 text-gray-400' : getColorByOccupationRate(occupationRate);
					return (
						<button
							key={index}
							onClick={() => !isPastDay && onDayClick && onDayClick(day.date)}
							className={`h-16 md:h-20 flex flex-col items-center justify-start rounded-md text-sm p-1 border ${!day.currentMonth ? 'opacity-60' : ''} ${colorClass}`}
						>
							<div className={`w-full flex items-center justify-between ${isToday ? 'font-semibold text-blue-700' : ''}`}>
								<span>{day.day}</span>
								{dayAppointments.length > 1 && (
									<span className="text-[10px] px-1 rounded-full bg-white text-gray-700 border">{dayAppointments.length}</span>
								)}
							</div>
							{/* Preview a small badge for first appointment without filling the whole day */}
							{dayAppointments[0] && (
								<div className="mt-1 w-full">
									<span className="inline-block max-w-full truncate text-[11px] px-2 py-0.5 rounded text-white" style={{ backgroundColor: dayAppointments[0].color || '#2563eb' }}>
										{dayAppointments[0].time} • {dayAppointments[0].patientName || 'RDV'}
									</span>
								</div>
							)}
						</button>
					);
				})}
			</div>
		</div>
	);
}


