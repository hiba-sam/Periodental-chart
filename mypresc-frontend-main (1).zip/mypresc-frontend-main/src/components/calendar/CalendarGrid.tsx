'use client';

import React, { useMemo, useCallback, useRef, useEffect } from 'react';
import { DndContext, DragOverlay, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { AlertCircle, CheckCircle2, BadgeCheck } from 'lucide-react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useCalendarDragDrop, customCollisionDetection } from '@/hooks/useCalendarDragDrop';
import { DraggableEvent } from './DraggableEvent';
import { DroppableSlot } from './DroppableSlot';
import { useProfile } from '@/contexts/ProfileContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface TimeSlot {
  hour: number;
  label: string;
}

interface DayColumn {
  date: Date;
  dayName: string;
  dayNumber: number;
  isToday: boolean;
  isPast: boolean;
  events: CalendarEvent[];
}

interface CalendarGridProps {
  onSlotClick?: (date: Date, time: string) => void;
  onEventClick?: (event: CalendarEvent) => void;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const HOURS_START = 0; // Minuit (00:00)
const HOURS_END = 23; // 23:00 (24 heures au total: 0-23)
const BUSINESS_HOURS_START = 8; // 8:00 AM - début horaires de bureau
const SLOT_HEIGHT = 80; // pixels per hour (4 × 20px slots)
const QUARTER_SLOT_HEIGHT = 20; // pixels per 15-minute slot
const EVENT_HEIGHT = 25; // fixed height for all events
const EVENT_SPACING = 5; // vertical spacing between events
const DAY_COLUMN_WIDTH = 220; // pixels per day column (wider for better readability)
const TIME_LABEL_WIDTH = 50; // pixels for time label column

// Day names are now dynamically generated based on language

// Color palette with transparency for event blocks
const COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
  '#2563eb': { bg: 'rgba(37, 99, 235, 0.15)', border: '#2563eb', text: '#1e40af' }, // Blue
  '#10b981': { bg: 'rgba(16, 185, 129, 0.15)', border: '#10b981', text: '#047857' }, // Green
  '#ef4444': { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#b91c1c' }, // Red
  '#f59e0b': { bg: 'rgba(245, 158, 11, 0.15)', border: '#f59e0b', text: '#d97706' }, // Orange
  '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#6d28d9' }, // Purple
  '#6b7280': { bg: 'rgba(107, 114, 128, 0.15)', border: '#6b7280', text: '#4b5563' }, // Gray
};

// Dark mode variants - Lighter text and slightly more visible background
const DARK_COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
  '#2563eb': { bg: 'rgba(59, 130, 246, 0.25)', border: '#3b82f6', text: '#dbeafe' }, // Blue-500 bg, Blue-100 text
  '#10b981': { bg: 'rgba(16, 185, 129, 0.25)', border: '#10b981', text: '#d1fae5' }, // Emerald-500 bg, Emerald-100 text
  '#ef4444': { bg: 'rgba(239, 68, 68, 0.25)', border: '#ef4444', text: '#fee2e2' }, // Red-500 bg, Red-100 text
  '#f59e0b': { bg: 'rgba(245, 158, 11, 0.25)', border: '#f59e0b', text: '#fef3c7' }, // Amber-500 bg, Amber-100 text
  '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.25)', border: '#8b5cf6', text: '#ede9fe' }, // Violet-500 bg, Violet-100 text
  '#6b7280': { bg: 'rgba(107, 114, 128, 0.25)', border: '#6b7280', text: '#f3f4f6' }, // Gray-500 bg, Gray-100 text
};

// ============================================================================
// COMPONENT
// ============================================================================

export const CalendarGrid: React.FC<CalendarGridProps> = ({ onSlotClick, onEventClick }) => {
  const { selectedDate, getEventsForWeek, selectEvent, selectedEvent } = useCalendar();
  const { profile } = useProfile();

  const { language, isRTL } = useLanguage();
  const { actualTheme } = useTheme();

  // Drag & drop functionality
  const { dragState, handlers } = useCalendarDragDrop();

  // Refs for scroll containers
  const horizontalScrollRef = useRef<HTMLDivElement>(null);
  const verticalScrollRef = useRef<HTMLDivElement>(null);

  // Configure pointer sensor with activation constraints
  // This ensures clicks don't accidentally trigger drags
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // Drag only starts after moving 8px
      },
    })
  );

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================

  /**
   * Parse working time string (e.g., "09:00 - 17:00") to get start and end hours
   * Returns null if closed or invalid format
   */
  const parseWorkingTime = (timeString: string | undefined): { start: number; end: number } | null => {
    if (!timeString || timeString.toLowerCase() === 'closed' || timeString.toLowerCase() === 'fermé') {
      return null;
    }

    const match = timeString.match(/(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})/);
    if (!match) return null;

    const startHour = parseInt(match[1], 10);
    const endHour = parseInt(match[3], 10);
    const endMinute = parseInt(match[4], 10);

    // If end time is 23:59 (or any minute > 0 at hour 23), treat as 24h (include hour 23)
    // Use 24 as end so that hour 23 passes the check (23 < 24)
    const adjustedEndHour = (endHour === 23 && endMinute > 0) ? 24 : endHour;

    return { start: startHour, end: adjustedEndHour };
  };

  /**
   * Get working hours for a specific day
   * Maps JavaScript day (0=Sunday, 6=Saturday) to work_time keys
   */
  const getWorkingHoursForDay = useCallback((date: Date): { start: number; end: number } | null => {
    if (!profile?.work_time) {
      // Default to 8:00 - 17:00 if no work_time is set
      return { start: 8, end: 17 };
    }

    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = dayNames[date.getDay()];

    return parseWorkingTime(profile.work_time[dayName]);
  }, [profile]);

  /**
   * Check if a time slot is outside working hours for a specific day
   * Returns true if the slot should be grayed out (non-working hours)
   */
  const isOutsideWorkingHours = useCallback((date: Date, hour: number): boolean => {
    const workingHours = getWorkingHoursForDay(date);

    // If the day is closed (no working hours), all slots are outside working hours
    if (!workingHours) {
      return true;
    }

    // Check if hour is before start or at/after end
    return hour < workingHours.start || hour >= workingHours.end;
  }, [getWorkingHoursForDay]);

  /**
   * Get start of week (Saturday)
   */
  const getWeekStart = (date: Date): Date => {
    const d = new Date(date);
    const day = d.getDay();
    // Saturday = 6, Sunday = 0, Monday = 1, etc.
    // We want to go back to the most recent Saturday (or stay on Saturday if today is Saturday)
    // If today is Saturday (6), diff = 0
    // If today is Sunday (0), diff = -1 (go back 1 day to Saturday)
    // If today is Monday (1), diff = -2 (go back 2 days to Saturday)
    // If today is Tuesday (2), diff = -3, etc.
    const diff = day === 6 ? 0 : -(day + 1);
    d.setDate(d.getDate() + diff);
    d.setHours(0, 0, 0, 0);
    return d;
  };

  /**
   * Check if date is today
   */
  const isToday = (date: Date): boolean => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  /**
   * Check if date is in the past
   */
  const isPast = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  /**
   * Check if a specific time slot is in the past (DISABLED - all slots clickable)
   */
  const isTimeSlotPast = (date: Date, hour: number): boolean => {
    return false; // ✅ Toutes les cases sont cliquables
  };

  /**
   * Calculate position of current time indicator line
   */
  const getCurrentTimePosition = (date: Date): number | null => {
    const now = new Date();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dateCheck = new Date(date);
    dateCheck.setHours(0, 0, 0, 0);

    // Only show line on today's column
    if (dateCheck.getTime() !== today.getTime()) {
      return null;
    }

    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    // Calculate position: hours * slot height + (minutes / 60) * slot height
    const minutesFromStart = (currentHour - HOURS_START) * 60 + currentMinute;

    // Si avant HOURS_START, retourner null (pas d'affichage)
    if (minutesFromStart < 0) {
      return null;
    }

    const position = (minutesFromStart / 60) * SLOT_HEIGHT;

    return position;
  };

  /**
   * Convert time string (HH:mm) to minutes from midnight
   */
  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  /**
   * Check if two events overlap in time
   */
  const eventsOverlap = (event1: CalendarEvent, event2: CalendarEvent): boolean => {
    const getEndMinutes = (event: CalendarEvent) => {
      const [hours, minutes] = event.time.split(':').map(Number);
      const startMinutes = hours * 60 + minutes;
      return startMinutes + (event.duration || 30);
    };

    const getStartMinutes = (event: CalendarEvent) => {
      const [hours, minutes] = event.time.split(':').map(Number);
      return hours * 60 + minutes;
    };

    const start1 = getStartMinutes(event1);
    const end1 = getEndMinutes(event1);
    const start2 = getStartMinutes(event2);
    const end2 = getEndMinutes(event2);

    return start1 < end2 && start2 < end1;
  };

  /**
   * Calculate position, height, width, and horizontal offset for event block
   * - Height: 30min slot = 40px (2 × QUARTER_SLOT_HEIGHT), 15min = 50% of that (20px)
   * - Width: Events constrained to day column, positioned side-by-side if overlapping
   * - Position: Based on 15-minute precision (0, 15, 30, 45)
   * - Overlapping events: Arranged horizontally in columns
   */
  const getEventStyle = (event: CalendarEvent, eventsInSameDay: CalendarEvent[]) => {
    const [hours, minutes] = event.time.split(':').map(Number);
    const startMinutes = hours * 60 + minutes;

    // Calculate base position (top of the 15-min slot)
    // Maintenant HOURS_START = 0, donc position directe depuis minuit
    const top = (startMinutes / 15) * QUARTER_SLOT_HEIGHT;

    // Calculate height based on duration
    const durationInMinutes = event.duration || 30;
    // Calcul: QUARTER_SLOT_HEIGHT = 20px par 15 minutes
    // Donc: hauteur = (durée / 15) * 20px
    const height = (durationInMinutes / 15) * QUARTER_SLOT_HEIGHT;

    // Find overlapping events
    const overlappingEvents = eventsInSameDay.filter(e =>
      e.id !== event.id && eventsOverlap(event, e)
    );

    // Calculate horizontal column position for overlapping events
    let columnIndex = 0;
    let totalColumns = 1;

    if (overlappingEvents.length > 0) {
      // Sort all overlapping events by start time, then end time, then by id
      const allOverlapping = [event, ...overlappingEvents].sort((a, b) => {
        const timeCompare = a.time.localeCompare(b.time);
        if (timeCompare !== 0) return timeCompare;

        // Si même heure de début, celui qui finit plus tard va à gauche
        const aDuration = a.duration || 30;
        const bDuration = b.duration || 30;
        if (aDuration !== bDuration) return bDuration - aDuration;

        return a.id.localeCompare(b.id);
      });

      // Algorithme de placement en colonnes (greedy)
      const columns: CalendarEvent[][] = [];

      for (const evt of allOverlapping) {
        // Trouver la première colonne où l'événement peut être placé sans chevauchement
        let placed = false;
        for (let col = 0; col < columns.length; col++) {
          // Vérifier si l'événement chevauche un des événements de cette colonne
          const hasOverlap = columns[col].some(colEvent => eventsOverlap(evt, colEvent));
          if (!hasOverlap) {
            columns[col].push(evt);
            placed = true;
            break;
          }
        }

        // Si aucune colonne ne convient, créer une nouvelle colonne
        if (!placed) {
          columns.push([evt]);
        }
      }

      // Trouver dans quelle colonne se trouve notre événement
      columnIndex = columns.findIndex(col => col.some(e => e.id === event.id));
      totalColumns = columns.length;
    }

    // Calculate width and left position based on columns
    const widthPercent = 100 / totalColumns;
    const leftPercent = (columnIndex * widthPercent);

    console.log(`[getEventStyle] Event "${event.title}" at ${event.time} duration=${durationInMinutes}min => top: ${top}px, height: ${height}px, width: ${widthPercent}%, left: ${leftPercent}%, overlapping: ${overlappingEvents.length}, column: ${columnIndex}/${totalColumns}`);

    return {
      top: `${top}px`,
      height: `${height}px`,
      width: `${widthPercent}%`,
      left: `${leftPercent}%`,
    };
  };

  /**
   * Count events in a specific hour for density checking
   */
  const getEventsInHour = (date: Date, hour: number): number => {
    const dayEvents = weekColumns.find((col) =>
      col.date.getDate() === date.getDate() &&
      col.date.getMonth() === date.getMonth() &&
      col.date.getFullYear() === date.getFullYear()
    )?.events || [];

    return dayEvents.filter((event) => {
      const eventHour = parseInt(event.time.split(':')[0], 10);
      return eventHour === hour;
    }).length;
  };

  /**
   * Get color styling for event
   */
  const getEventColors = (color: string) => {
    const variants = actualTheme === 'dark' ? DARK_COLOR_VARIANTS : COLOR_VARIANTS;
    return variants[color] || (actualTheme === 'dark' ? DARK_COLOR_VARIANTS['#2563eb'] : COLOR_VARIANTS['#2563eb']);
  };

  // ============================================================================
  // COMPUTED DATA
  // ============================================================================

  /**
   * Generate time slots for 24 hours (00:00 - 23:00)
   */
  const timeSlots: TimeSlot[] = useMemo(() => {
    const slots: TimeSlot[] = [];
    for (let i = 0; i <= 23; i++) {
      slots.push({
        hour: i,
        label: `${String(i).padStart(2, '0')}:00`,
      });
    }
    return slots;
  }, []);

  /**
   * Generate week columns with events
   */
  const weekColumns: DayColumn[] = useMemo(() => {
    const weekStart = getWeekStart(selectedDate);
    const weekEvents = getEventsForWeek(weekStart);

    console.log('[CalendarGrid] Week start:', weekStart);
    console.log('[CalendarGrid] Total week events:', weekEvents.length, weekEvents);

    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date(weekStart);
      date.setDate(weekStart.getDate() + index);

      const dayEvents = weekEvents.filter(
        (event) =>
          event.date.getDate() === date.getDate() &&
          event.date.getMonth() === date.getMonth() &&
          event.date.getFullYear() === date.getFullYear()
      );

      console.log(`[CalendarGrid] Day ${date.toDateString()}: ${dayEvents.length} events`);

      // Get day name based on language
      const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
      const dayName = date.toLocaleDateString(locale, { weekday: 'short' });

      return {
        date,
        dayName,
        dayNumber: date.getDate(),
        isToday: isToday(date),
        isPast: isPast(date),
        events: dayEvents,
      };
    });
  }, [selectedDate, getEventsForWeek, language]);

  /**
   * Get current time in minutes from midnight
   */
  const getCurrentTimeOffset = (): number => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    // Retourne les minutes depuis minuit (00:00)
    return currentHour * 60 + currentMinute;
  };

  /**
   * Scroll horizontally to current day, or to Saturday if current day is not in the week
   */
  const scrollToCurrentDay = useCallback(() => {
    // Scroll horizontally to current day or first day (Saturday)
    if (horizontalScrollRef.current) {
      const todayIndex = weekColumns.findIndex(col => col.isToday);

      if (todayIndex !== -1) {
        // Current day is in the week - scroll to it and center it
        const scrollLeft = (todayIndex * DAY_COLUMN_WIDTH) - (horizontalScrollRef.current.clientWidth / 2) + (DAY_COLUMN_WIDTH / 2);
        horizontalScrollRef.current.scrollTo({
          left: Math.max(0, scrollLeft),
          behavior: 'smooth'
        });
      } else {
        // Current day is NOT in the week - scroll to Saturday (first day, index 0)
        horizontalScrollRef.current.scrollTo({
          left: 0,
          behavior: 'smooth'
        });
      }
    }
  }, [weekColumns]);

  /**
   * Scroll vertically to center working hours in viewport
   * Uses dynamic working hours from profile, defaults to 8:00 - 17:00
   */
  const scrollToBusinessHours = useCallback(() => {
    if (verticalScrollRef.current) {
      const viewportHeight = verticalScrollRef.current.clientHeight; // Hauteur visible

      // Get working hours for today
      const today = new Date();
      const workingHours = getWorkingHoursForDay(today);

      // If day is closed, scroll to 8:00 by default
      const startHour = workingHours?.start ?? 8;
      const endHour = workingHours?.end ?? 17;

      const businessHoursDuration = endHour - startHour;
      const businessHoursHeight = businessHoursDuration * SLOT_HEIGHT;
      const businessHoursStartPosition = startHour * SLOT_HEIGHT;

      // Center the working hours zone in the viewport
      // scrollTop = position of start hour - (available space / 2)
      const availableSpace = viewportHeight - businessHoursHeight;
      const scrollTop = businessHoursStartPosition - (availableSpace / 2);

      verticalScrollRef.current.scrollTo({
        top: Math.max(0, scrollTop), // Don't scroll to negative
        behavior: 'smooth'
      });
    }
  }, [getWorkingHoursForDay]);

  /**
   * Auto-scroll horizontally and vertically on initial mount only
   * Use ref to prevent scroll reset on every re-render (e.g., when events update)
   */
  const hasInitialScrolled = useRef(false);
  
  useEffect(() => {
    // Only scroll on first mount, not on subsequent re-renders
    if (hasInitialScrolled.current) return;
    
    // Small delay to ensure DOM is ready
    const timer = setTimeout(() => {
      scrollToCurrentDay();
      scrollToBusinessHours();
      hasInitialScrolled.current = true;
    }, 100);

    return () => clearTimeout(timer);
  }, [scrollToCurrentDay, scrollToBusinessHours]);
  
  // Reset scroll flag when date actually changes (user navigation)
  useEffect(() => {
    hasInitialScrolled.current = false;
    const timer = setTimeout(() => {
      scrollToCurrentDay();
      scrollToBusinessHours();
      hasInitialScrolled.current = true;
    }, 100);
    return () => clearTimeout(timer);
  }, [selectedDate]);

  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  /**
   * Handle 30-minute slot click
   * @param date - The date of the slot
   * @param hour - The hour (0-23)
   * @param minute - The minute (0 or 30)
   */
  const handleSlotClick = useCallback((date: Date, hour: number, minute: number) => {
    console.log(`✅ Clicked slot: ${date.toDateString()} at ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`);

    // Check if this hour is "charged" (4+ events already)
    const dayEvents = weekColumns.find((col) =>
      col.date.getDate() === date.getDate() &&
      col.date.getMonth() === date.getMonth() &&
      col.date.getFullYear() === date.getFullYear()
    )?.events || [];

    const eventsInHour = dayEvents.filter((event) => {
      const eventHour = parseInt(event.time.split(':')[0], 10);
      return eventHour === hour;
    }).length;

    // If hour is too full, don't open modal (user can still manually create)
    if (eventsInHour >= 4) {
      console.log(`Hour ${hour}:00 is fully charged with ${eventsInHour} events`);
      return;
    }

    // Format time (hour is now 0-23)
    const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    onSlotClick?.(date, time);
  }, [onSlotClick, weekColumns]);

  const handleEventClick = useCallback((event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();

    selectEvent(event);
    onEventClick?.(event);
  }, [selectEvent, onEventClick]);

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={customCollisionDetection}
      onDragStart={handlers.onDragStart}
      onDragOver={handlers.onDragOver}
      onDragEnd={handlers.onDragEnd}
      onDragCancel={handlers.onDragCancel}
    >
      <div className="calendar-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
        {/* Horizontal scroll container with custom scrollbar styling */}
        <div ref={horizontalScrollRef} className="overflow-x-auto scrollbar-thin scrollbar-thumb-gray-300 dark:scrollbar-thumb-gray-600 scrollbar-track-gray-100 dark:scrollbar-track-gray-800">
          {/* Inner container with fixed width based on day columns */}
          <div style={{ minWidth: `${TIME_LABEL_WIDTH + DAY_COLUMN_WIDTH * 7}px` }}>
            {/* Header Row - Days */}
            <div
              className="grid border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 sticky top-0 z-40"
              style={{
                gridTemplateColumns: `${TIME_LABEL_WIDTH}px repeat(7, ${DAY_COLUMN_WIDTH}px) 17px`,
                direction: isRTL ? 'rtl' : 'ltr'
              }}
            >
              {/* Empty corner cell - sticky time label header */}
              <div className="bg-gray-50 dark:bg-gray-900 border-e border-gray-200 dark:border-gray-700" />

              {/* Day headers */}
              {weekColumns.map((column, idx) => (
                <div
                  key={idx}
                  className={`
              flex items-center justify-center gap-2
              p-2 text-center border-e border-gray-200 dark:border-gray-700
              ${column.isToday ? 'bg-blue-50 dark:bg-blue-900/40' : ''}
            `}
                >
                  <div
                    className={`
                text-xl font-bold
                ${column.isToday ? 'text-blue-600 dark:text-blue-400' : column.isPast ? 'text-gray-400 dark:text-gray-500' : 'text-gray-800 dark:text-gray-100'}
              `}
                  >
                    {column.dayNumber}
                  </div>
                  <div
                    className={`
                text-sm font-medium
                ${column.isToday ? 'text-blue-600 dark:text-blue-400' : 'text-gray-600 dark:text-gray-400'}
              `}
                  >
                    {column.dayName}
                  </div>
                </div>
              ))}
              {/* Scrollbar spacer - aligns header with body scrollbar */}
              <div className="bg-gray-50 dark:bg-gray-900" />
            </div>

            {/* Time Grid */}
            <div ref={verticalScrollRef} className="calendar-grid-body relative" style={{ height: "770px", overflowY: 'auto', overflowX: 'hidden' }}>
              {/* Grid container with columns */}
              <div
                className="grid"
                style={{
                  gridTemplateColumns: `${TIME_LABEL_WIDTH}px repeat(7, ${DAY_COLUMN_WIDTH}px)`,
                  direction: isRTL ? 'rtl' : 'ltr'
                }}
              >
                {/* Time labels column */}
                <div className="border-e border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 relative">
                  {timeSlots.map((slot) => (
                    <div
                      key={slot.hour}
                      className={`relative text-xs text-gray-500 dark:text-gray-400 text-end pe-2`}
                      style={{ height: `${SLOT_HEIGHT}px` }}
                    >
                      <span className={`absolute top-0 ${isRTL ? 'left-2' : 'right-2'} -translate-y-2`}>{slot.label}</span>
                    </div>
                  ))}
                </div>

                {/*
            RESTRUCTURED: Each day column now contains ALL its layers in proper order:
            1. Background slots (clickable white/gray areas)
            2. Grid lines (visual borders)
            3. Events (overlay with pointer-events-auto)
          */}
                {weekColumns.map((column, colIdx) => (
                  <div key={colIdx} className="relative border-e border-gray-200 dark:border-gray-700 last:border-e-0">
                    {/* Layer 1: Background clickable slots */}
                    <div className="relative w-full h-full">
                      {timeSlots.map((slot) => {
                        const slotIsPast = isTimeSlotPast(column.date, slot.hour);
                        return (
                          <div
                            key={slot.hour}
                            className={`relative w-full h-[80px]`}
                          >
                            {/* First 15-min slot (00 minutes) */}
                            <DroppableSlot
                              id={`slot-${colIdx}-${column.date.toISOString()}-${String(slot.hour).padStart(2, '0')}:00`}
                              disabled={slotIsPast}
                              className="absolute inset-x-0 w-full top-0 h-[20px] left-0"
                              style={{ zIndex: 20 }}
                            >
                              <div
                                role="button"
                                tabIndex={0}
                                aria-label={`Create event at ${column.dayName} ${column.dayNumber} ${slot.label}`}
                                className={`w-full h-full transition-colors cursor-pointer ${isOutsideWorkingHours(column.date, slot.hour) ? 'bg-gray-100 dark:bg-gray-950/50 hover:bg-gray-200 dark:hover:bg-gray-900' : 'hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}`}
                                style={{ pointerEvents: 'auto' }}
                                onClick={() => {
                                  console.log(`[SLOT CLICK] ${column.date.toDateString()} at ${slot.label}`);
                                  handleSlotClick(column.date, slot.hour, 0);
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleSlotClick(column.date, slot.hour, 0);
                                  }
                                }}
                              />
                            </DroppableSlot>

                            {/* Second 15-min slot (15 minutes) */}
                            <DroppableSlot
                              id={`slot-${colIdx}-${column.date.toISOString()}-${String(slot.hour).padStart(2, '0')}:15`}
                              disabled={slotIsPast}
                              className="absolute inset-x-0 w-full top-[20px] h-[20px]"
                              style={{ zIndex: 20 }}
                            >
                              <div
                                role="button"
                                tabIndex={0}
                                aria-label={`Create event at ${column.dayName} ${column.dayNumber} ${slot.label.replace(':00', ':15')}`}
                                className={`w-full h-full transition-colors cursor-pointer ${isOutsideWorkingHours(column.date, slot.hour) ? 'bg-gray-100 dark:bg-gray-950/50 hover:bg-gray-200 dark:hover:bg-gray-900' : 'hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}`}
                                style={{ pointerEvents: 'auto' }}
                                onClick={() => {
                                  console.log(`[SLOT CLICK] ${column.date.toDateString()} at ${slot.label.replace(':00', ':15')}`);
                                  handleSlotClick(column.date, slot.hour, 15);
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleSlotClick(column.date, slot.hour, 15);
                                  }
                                }}
                              />
                            </DroppableSlot>

                            {/* Third 15-min slot (30 minutes) */}
                            <DroppableSlot
                              id={`slot-${colIdx}-${column.date.toISOString()}-${String(slot.hour).padStart(2, '0')}:30`}
                              disabled={slotIsPast}
                              className="absolute inset-x-0 w-full top-[40px] h-[20px]"
                              style={{ zIndex: 21 }}
                            >
                              <div
                                role="button"
                                tabIndex={0}
                                aria-label={`Create event at ${column.dayName} ${column.dayNumber} ${slot.label.replace(':00', ':30')}`}
                                className={`w-full h-full transition-colors cursor-pointer ${isOutsideWorkingHours(column.date, slot.hour) ? 'bg-gray-100 dark:bg-gray-950/50 hover:bg-gray-200 dark:hover:bg-gray-900' : 'hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}`}
                                style={{ pointerEvents: 'auto' }}
                                onClick={() => {
                                  console.log(`[SLOT CLICK] ${column.date.toDateString()} at ${slot.label.replace(':00', ':30')}`);
                                  handleSlotClick(column.date, slot.hour, 30);
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleSlotClick(column.date, slot.hour, 30);
                                  }
                                }}
                              />
                            </DroppableSlot>

                            {/* Fourth 15-min slot (45 minutes) */}
                            <DroppableSlot
                              id={`slot-${colIdx}-${column.date.toISOString()}-${String(slot.hour).padStart(2, '0')}:45`}
                              disabled={slotIsPast}
                              className="absolute inset-x-0 w-full top-[60px] h-[20px]"
                              style={{ zIndex: 21 }}
                            >
                              <div
                                role="button"
                                tabIndex={0}
                                aria-label={`Create event at ${column.dayName} ${column.dayNumber} ${slot.label.replace(':00', ':45')}`}
                                className={`w-full h-full transition-colors cursor-pointer ${isOutsideWorkingHours(column.date, slot.hour) ? 'bg-gray-100 dark:bg-gray-950/50 hover:bg-gray-200 dark:hover:bg-gray-900' : 'hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'}`}
                                style={{ pointerEvents: 'auto' }}
                                onClick={() => {
                                  console.log(`[SLOT CLICK] ${column.date.toDateString()} at ${slot.label.replace(':00', ':45')}`);
                                  handleSlotClick(column.date, slot.hour, 45);
                                }}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    handleSlotClick(column.date, slot.hour, 45);
                                  }
                                }}
                              />
                            </DroppableSlot>
                          </div>
                        );
                      })}
                    </div>

                    {/* Layer 2: Grid lines (visual only, pointer-events-none) */}
                    <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 25 }}>
                      {timeSlots.map((slot, index) => (
                        <React.Fragment key={slot.hour}>
                          {/* Main hour line (solid, darker) */}
                          <div
                            className="absolute left-0 right-0 border-t border-gray-300 dark:border-gray-600 w-full"
                            style={{ top: `${index * SLOT_HEIGHT}px` }}
                          />
                          {/* 30-min line (medium) */}
                          <div
                            className="absolute left-0 right-0 border-t border-gray-200 dark:border-gray-700 w-full"
                            style={{ top: `${index * SLOT_HEIGHT + QUARTER_SLOT_HEIGHT * 2}px` }}
                          />
                        </React.Fragment>
                      ))}

                    </div>

                    {/* Layer 3: Event blocks (pointer-events-none on container, auto on events) */}
                    <div className="absolute inset-0 pointer-events-none">
                      {column.events.map((event) => {
                        const eventStyle = getEventStyle(event, column.events);
                        const colors = getEventColors(event.color);
                        const isSelected = selectedEvent?.id === event.id;

                        console.log(`[EVENT RENDER] ${event.title}: duration=${event.duration}min, style=`, eventStyle);

                        return (
                          <DraggableEvent
                            key={event.id}
                            event={event}
                            isDraggingAny={dragState.isDragging}
                            style={{
                              top: eventStyle.top,
                              height: eventStyle.height,
                              width: eventStyle.width,
                              insetInlineStart: eventStyle.left,
                              zIndex: 30,
                              paddingLeft: '4px',
                              paddingRight: '4px',
                            }}
                            className={`
                        absolute rounded-md border-s-4
                        transition-all duration-150 pointer-events-auto overflow-hidden
                        ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'shadow-sm hover:shadow-md'}
                      `}
                            onClick={(e) => {
                              console.log(`[EVENT CLICK] ${event.title} at ${event.time}`);
                              handleEventClick(event, e);
                            }}
                          >
                            <div
                              className="w-full h-full p-2 flex items-center gap-2 rounded-md"
                              style={{
                                backgroundColor: colors.bg,
                                borderInlineStartColor: colors.border,
                              }}
                              title={`${event.time} - ${event.endTime}: ${event.title}`}
                            >
                              {/* Status Icon - Only show for appointments, not free events */}
                              {event.isAppointmentLinked && (
                                <div className="flex-shrink-0 flex items-center">
                                  {event.isDone ? (
                                    <BadgeCheck
                                      className="w-4 h-4 text-blue-600"
                                      strokeWidth={2.5}
                                    />
                                  ) : !event.venueConfirmed ? (
                                    <AlertCircle
                                      className="w-4 h-4 text-yellow-500"
                                      strokeWidth={2.5}
                                    />
                                  ) : (
                                    <CheckCircle2
                                      className="w-4 h-4 text-green-600"
                                      strokeWidth={2.5}
                                    />
                                  )}
                                </div>
                              )}

                              {/* Event details */}
                              <div className={`flex-1 min-w-0 flex items-center gap-1.5 ${event.isDone ? 'relative' : ''}`}>
                                <span
                                  className={`text-[11px] font-bold whitespace-nowrap ${event.isDone ? 'line-through opacity-60' : ''}`}
                                  style={{ color: colors.text }}
                                >
                                  {event.time}
                                </span>
                                <span
                                  className={`text-[11px] font-medium truncate ${event.isDone ? 'line-through opacity-60' : ''}`}
                                  style={{ color: colors.text }}
                                >
                                  {event.title}
                                </span>
                              </div>
                            </div>
                          </DraggableEvent>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>

              {/* Current time indicator - spans entire week */}
              {(() => {
                const currentTimeMinutes = getCurrentTimeOffset();
                const topPosition = (currentTimeMinutes / 60) * SLOT_HEIGHT;

                // Calculer l'heure actuelle pour l'affichage
                const now = new Date();
                const currentHour = String(now.getHours()).padStart(2, '0');
                const currentMinute = String(now.getMinutes()).padStart(2, '0');
                const currentTimeText = `${currentHour}:${currentMinute}`;

                // Position styles based on direction
                const containerStyle = isRTL
                  ? { right: `${TIME_LABEL_WIDTH}px`, left: 0 }
                  : { left: `${TIME_LABEL_WIDTH}px`, right: 0 };

                const textStyle = isRTL
                  ? { width: '45px', textAlign: 'left' as const, right: '-50px' }
                  : { width: '45px', textAlign: 'right' as const, left: '-50px' };

                const circleStyle = isRTL
                  ? { right: '-4px' }
                  : { left: '-4px' };

                // Don't render if outside of reasonable bounds (optional safeguard)
                if (topPosition < 0) return null;

                return (
                  <div
                    className="absolute pointer-events-none"
                    style={{
                      top: `${topPosition}px`,
                      ...containerStyle,
                      zIndex: 60
                    }}
                    dir={isRTL ? 'rtl' : 'ltr'}
                  >
                    {/* Heure actuelle en rouge */}
                    <div
                      className="absolute -top-2 text-xs font-bold text-red-500"
                      style={textStyle}
                    >
                      {currentTimeText}
                    </div>

                    {/* Cercle rouge */}
                    <div
                      className="absolute -top-1.5 w-3 h-3 bg-red-500 rounded-full border-2 border-white shadow"
                      style={circleStyle}
                    />

                    {/* Ligne rouge horizontale traversant toute la semaine */}
                    <div className="absolute inset-x-0 h-[2px] bg-red-500 shadow-sm" />
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      </div>
    </DndContext>
  );
};

export default CalendarGrid;
