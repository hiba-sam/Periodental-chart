'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Modal from '@/components/ui/Modal';
import ColorSelect, { COLORS } from '@/components/ui/ColorSelect';
import { useCalendar, type CalendarEvent, type CreateEventData, type UpdateEventData } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { ApiPatient, usePatients } from '@/contexts/PatientsContext';
import { MagnifyingGlassIcon, UserIcon, XMarkIcon, CalendarIcon, ClockIcon } from '@heroicons/react/24/outline';

// ============================================================================
// CONSTANTS & HELPERS
// ============================================================================

/**
 * Get a random color from available colors
 */
const getRandomColor = (): string => {
  const randomIndex = Math.floor(Math.random() * COLORS.length);
  return COLORS[randomIndex].value;
};

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface EventModalProps {
  isOpen: boolean;
  onClose: (wasSuccessfulCreation?: boolean) => void;
  initialDate?: Date;
  initialTime?: string;
  editEvent?: CalendarEvent | null;
  hideDateInput?: boolean;
  preselectedPatient?: {
    id: string;
    name: string;
    familyName: string;
  } | null;
  preselectedEventType?: 'patient' | null;
}

interface TimeOption {
  value: string;
  label: string;
}

type EventType = 'patient' | 'free' | null;

// ============================================================================
// CONSTANTS
// ============================================================================


// ============================================================================
// COMPONENT
// ============================================================================

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  onClose,
  initialDate,
  initialTime,
  editEvent,
  hideDateInput = false,
  preselectedPatient = null,
  preselectedEventType = null,
}) => {
  const { createEvent, updateEvent, loading } = useCalendar();
  const { t } = useLanguage();
  const { patients, searchPatients, getPatient } = usePatients();
  const [serverResults, setServerResults] = useState<ApiPatient[] | null>(null);

  // Duration options with translations
  const DURATION_OPTIONS = useMemo(() => [
    { value: 15, label: t('calendar.duration15') },
    { value: 30, label: t('calendar.duration30') },
    { value: 45, label: t('calendar.duration45') },
    { value: 60, label: t('calendar.duration60') },
    { value: 90, label: t('calendar.duration90') },
    { value: 120, label: t('calendar.duration120') },
  ], [t]);

  // ============================================================================
  // FORM STATE
  // ============================================================================

  const [eventType, setEventType] = useState<EventType>(null);
  const [formData, setFormData] = useState({
    // Common fields
    date: '',
    time: '',
    duration: 30,
    color: getRandomColor(),
    notes: '',

    // Patient appointment fields
    patientId: '',
    patient_name: '',
    patient_family_name: '',
    confirmedComing: false,

    // Free event fields
    title: '',
  });

  const [patientSearch, setPatientSearch] = useState('');
  const [showPatientDropdown, setShowPatientDropdown] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // ============================================================================
  // INITIALIZE FORM DATA
  // ============================================================================

  useEffect(() => {
    const initializeForm = async () => {
      if (isOpen) {
        if (editEvent) {
          // Edit mode - determine type and populate with existing event data
          const isPatientAppointment = !!editEvent.patientId;
          setEventType(isPatientAppointment ? 'patient' : 'free');

          // Format date properly to avoid timezone issues
          const year = editEvent.date.getFullYear();
          const month = String(editEvent.date.getMonth() + 1).padStart(2, '0');
          const day = String(editEvent.date.getDate()).padStart(2, '0');
          const formattedDate = `${year}-${month}-${day}`;

          let patientName = editEvent.patientName || '';
          let patientFamilyName = editEvent.patientFamilyName || '';

          // If patient data is missing but we have patientId, fetch it
          if (isPatientAppointment && editEvent.patientId && (!editEvent.patientName || !editEvent.patientFamilyName)) {
            try {
              const patientData = await getPatient(editEvent.patientId);
              if (patientData) {
                patientName = patientData.name || '';
                patientFamilyName = patientData.family_name || '';
              }
            } catch (error) {
              console.error('Error fetching patient data:', error);
            }
          }

          setFormData({
            date: formattedDate,
            time: editEvent.time,
            duration: editEvent.duration,
            notes: editEvent.description || '',
            color: editEvent.color,
            patientId: editEvent.patientId || '',
            patient_name: patientName,
            patient_family_name: patientFamilyName,
            confirmedComing: editEvent.confirmedComing as boolean,
            title: isPatientAppointment ? (patientName + ' ' + patientFamilyName) : editEvent.title,
          });
          setPatientSearch(isPatientAppointment ? `${patientName} ${patientFamilyName}`.trim() : '');
        } else {
          // Create mode - check for preselected patient or reset to type selection
          const now = new Date();
          const defaultDate = initialDate || now;
          const defaultTime = initialTime || `${String(now.getHours()).padStart(2, '0')}:00`;

          // Format date properly to avoid timezone issues
          const year = defaultDate.getFullYear();
          const month = String(defaultDate.getMonth() + 1).padStart(2, '0');
          const day = String(defaultDate.getDate()).padStart(2, '0');
          const formattedDate = `${year}-${month}-${day}`;

          // Check if patient is preselected from query params
          if (preselectedPatient && preselectedEventType === 'patient') {
            setEventType('patient');
            setFormData({
              date: formattedDate,
              time: defaultTime,
              duration: 30,
              notes: '',
              color: getRandomColor(),
              patientId: preselectedPatient.id,
              patient_name: preselectedPatient.name,
              patient_family_name: preselectedPatient.familyName,
              confirmedComing: false,
              title: '',
            });
            setPatientSearch(`${preselectedPatient.name} ${preselectedPatient.familyName}`);
          } else {
            setEventType(null);
            setFormData({
              date: formattedDate,
              time: defaultTime,
              duration: 30,
              notes: '',
              color: getRandomColor(),
              patientId: '',
              confirmedComing: false,
              title: '',
              patient_name: '',
              patient_family_name: '',
            });
            setPatientSearch('');
          }
        }
        setErrors({});
      }
    };

    initializeForm();
  }, [isOpen, editEvent, initialDate, initialTime, getPatient, preselectedPatient, preselectedEventType]);

  // ============================================================================
  // COMPUTED VALUES
  // ============================================================================

  /**
   * Generate time options (8:00 - 20:00, 15min intervals)
   */
  const timeOptions: TimeOption[] = useMemo(() => {
    const options: TimeOption[] = [];
    for (let hour = 8; hour <= 20; hour++) {
      for (let minute = 0; minute < 60; minute += 15) {
        if (hour === 20 && minute > 0) break; // Stop at 20:00
        const timeValue = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        options.push({
          value: timeValue,
          label: timeValue,
        });
      }
    }
    return options;
  }, []);

  /**
   * Filter patients based on search query
   */
  // Debounced live search
  useEffect(() => {
    const run = async () => {
      if (!patientSearch.trim()) {
        setServerResults(null);
        return;
      }
      const results = await searchPatients(patientSearch.trim(), 10);
      setServerResults(results);
    };
    const id = setTimeout(run, 300);
    return () => clearTimeout(id);
  }, [patientSearch, searchPatients]);


  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  const handleInputChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handlePatientSearch = (query: string) => {
    setPatientSearch(query);
    setShowPatientDropdown(true);

    // Trigger search if query length > 2
    if (query.length > 2) {
      searchPatients(query, 10);
    }
  };

  const handlePatientSelect = (patient: any) => {
    setFormData((prev) => ({
      ...prev,
      patientId: patient.id,
      patient_name: patient.name || '',
      patient_family_name: patient.family_name || '',
    }));
    setPatientSearch(`${patient.name} ${patient.family_name}`);
    setShowPatientDropdown(false);
    if (errors.patientId) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors.patientId;
        return newErrors;
      });
    }
  };

  const handlePatientClear = () => {
    setFormData((prev) => ({
      ...prev,
      patientId: '',
      patient_name: '',
      patient_family_name: '',
    }));
    setPatientSearch('');
    setShowPatientDropdown(false);
  };

  const handleEventTypeSelect = (type: EventType) => {
    setEventType(type);
  };

  const handleBack = () => {
    setEventType(null);
  };

  /**
   * Get today's date in YYYY-MM-DD format for min date validation
   */
  const getTodayDateString = (): string => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  /**
   * Validate form data
   */
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (eventType === 'patient') {
      if (!formData.patientId) {
        newErrors.patientId = t('calendar.patientRequired');
      }
    } else if (eventType === 'free') {
      if (!formData.title) {
        newErrors.title = t('calendar.titleRequired');
      }
    }

    if (!formData.date) {
      newErrors.date = t('calendar.dateRequired');
    } else {
      // Validate that date is not in the past
      const selectedDate = new Date(formData.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      selectedDate.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        newErrors.date = t('calendar.pastDateError');
      }
    }
    
    if (!formData.time) {
      newErrors.time = t('calendar.timeRequired');
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handle form submission
   */
  /**
   * Parse date string to local Date object (avoiding timezone issues)
   * Handles both "YYYY-MM-DD" and ISO timestamp formats
   */
  const parseLocalDate = (dateString: string): Date => {
    // If it's an ISO timestamp (e.g., "2025-10-18T23:00:00.000Z")
    if (dateString.includes('T')) {
      // Parse as Date and get local date components
      const date = new Date(dateString);
      // Use local date components to create a date object at midnight local time
      return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }

    // For plain date strings (e.g., "2025-10-18")
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      let result: CalendarEvent | null = null;
      if (editEvent) {
        // Update existing event
        const updateData: UpdateEventData = {
          title: formData.title,
          id: editEvent.id,
          date: parseLocalDate(formData.date),
          time: formData.time,
          duration: formData.duration,
          note: formData.notes,
          color: formData.color,
          confirmed_coming: formData.confirmedComing || false,
          is_done: editEvent.isDone || false,
        };

        result = await updateEvent(updateData);
        // Close modal on success (editing doesn't trigger redirect)
        if (result) {
          onClose(false);
        }
      } else {
        // Create new event
        if (eventType === 'patient') {
          const createData: CreateEventData = {
            patientId: formData.patientId,
            date: parseLocalDate(formData.date),
            time: formData.time,
            duration: formData.duration,
            notes: formData.notes,
            color: formData.color,
            confirmedComing: formData.confirmedComing,
          };

          result = await createEvent(createData);
        } else if (eventType === 'free') {
          // For free events, we'll create a "virtual" patient or handle differently
          // For now, we'll use a placeholder approach
          const createData: CreateEventData = {
            title: formData.title,
            date: parseLocalDate(formData.date),
            time: formData.time,
            duration: formData.duration,
            notes: `${formData.title}\n${formData.notes}`,
            color: formData.color,
            confirmedComing: false,
          };

          result = await createEvent(createData);
        }

        // Close modal on success with flag indicating successful creation
        if (result) {
          onClose(true);
        }
      }
    } catch (error) {
      console.error('Error submitting event:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ============================================================================
  // RENDER - TYPE SELECTION SCREEN
  // ============================================================================

  if (!editEvent && eventType === null) {
    return (
      <Modal
        isOpen={isOpen}
        onClose={() => onClose(false)}
        title={t('calendar.newAppointment')}
        closeOnBackdrop={false}
      >
        <div className="space-y-4 py-6">
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">{t('calendar.whatTypeQuestion')}</p>

          {/* Patient Appointment Option */}
          <button
            onClick={() => handleEventTypeSelect('patient')}
            className="
              w-full p-6 border-2 border-gray-200 dark:border-gray-700 rounded-lg
              hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all
              text-left group
            "
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-blue-100 dark:bg-blue-900/40 rounded-lg flex items-center justify-center group-hover:bg-blue-200 dark:group-hover:bg-blue-900/60 transition-colors">
                <UserIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                  {t('calendar.patientAppointment')}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('calendar.patientAppointmentDesc')}
                </p>
              </div>
            </div>
          </button>

          {/* Free Event Option */}
          {/* Free Event Option */}
          <button
            onClick={() => handleEventTypeSelect('free')}
            className="
              w-full p-6 border-2 border-gray-200 dark:border-gray-700 rounded-lg
              hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-all
              text-left group
            "
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-green-100 dark:bg-green-900/40 rounded-lg flex items-center justify-center group-hover:bg-green-200 dark:group-hover:bg-green-900/60 transition-colors">
                <CalendarIcon className="w-6 h-6 text-green-600 dark:text-green-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                  {t('calendar.freeEvent')}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('calendar.freeEventDesc')}
                </p>
              </div>
            </div>
          </button>
        </div>
      </Modal>
    );
  }

  // ============================================================================
  // RENDER - FORM SCREEN
  // ============================================================================

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        editEvent
          ? t('calendar.editAppointment')
          : eventType === 'patient'
            ? t('calendar.patientAppointment')
            : t('calendar.freeEvent')
      }
      closeOnBackdrop={false}
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Preselected Patient Indicator - Prominent Header Badge */}
        {preselectedPatient && !editEvent && (
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-l-4 border-blue-500 rounded-lg p-4 flex items-start gap-3 shadow-sm">
            <div className="flex-shrink-0 w-10 h-10 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center">
              <UserIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wide mb-1">
                {t('calendar.patientSelected')}
              </p>
              <p className="text-base font-bold text-gray-900 dark:text-gray-100">
                {preselectedPatient.name} {preselectedPatient.familyName}
              </p>
              <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                {t('calendar.appointmentWillBeCreated')}
              </p>
            </div>
          </div>
        )}

        {/* Back button for type selection (only in create mode) */}
        {!editEvent && !preselectedPatient && (
          <button
            type="button"
            onClick={handleBack}
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            {t('calendar.changeType')}
          </button>
        )}

        {/* PATIENT APPOINTMENT FORM */}
        {eventType === 'patient' && (
          <>
            {/* Patient Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('calendar.patient')} <span className="text-red-500">*</span>
              </label>

              <div className="relative">
                {/* Search Input */}
                {!formData.patientId ? (
                  <>
                    <div className="relative">
                      <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={patientSearch}
                        onChange={(e) => handlePatientSearch(e.target.value)}
                        onFocus={() => setShowPatientDropdown(true)}
                        placeholder={t('calendar.searchPatientPlaceholder')}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>

                    {/* Patient Dropdown */}
                    {showPatientDropdown && serverResults && serverResults.length > 0 && (
                      <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-md shadow-lg max-h-60 overflow-y-auto">
                        {serverResults?.map((patient: ApiPatient) => (
                          <button
                            key={patient.id}
                            type="button"
                            onClick={() => handlePatientSelect(patient)}
                            className="w-full px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700/50 focus:bg-gray-50 dark:focus:bg-gray-700/50 focus:outline-none border-b border-gray-100 dark:border-gray-700 last:border-b-0"
                          >
                            <div className="flex items-center gap-3">
                              <UserIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                              <div>
                                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                  {patient.name} {patient.family_name}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                  {patient.age} {t('calendar.years')}
                                </p>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  /* Selected Patient Display */
                  <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-md">
                    <UserIcon className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                        {formData?.patient_name} {formData?.patient_family_name}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handlePatientClear}
                      className="p-1 hover:bg-blue-100 dark:hover:bg-blue-800/30 rounded-full transition-colors"
                    >
                      <XMarkIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                    </button>
                  </div>
                )}
              </div>

              {errors.patientId && <p className="mt-1 text-sm text-red-600">{errors.patientId}</p>}
            </div>

            {/* Confirmed Coming Checkbox */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="confirmedComing"
                checked={formData.confirmedComing}
                onChange={(e) => handleInputChange('confirmedComing', e.target.checked)}
                className="w-4 h-4 text-blue-600 border-gray-300 dark:border-gray-600 rounded focus:ring-blue-500 dark:bg-gray-700"
              />
              <label htmlFor="confirmedComing" className="text-sm text-gray-700 dark:text-gray-300">
                {t('calendar.confirmed')}
              </label>
            </div>
          </>
        )}

        {/* FREE EVENT FORM */}
        {eventType === 'free' && (
          <>
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('calendar.title')} <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder={t('calendar.titlePlaceholder')}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
            </div>
          </>
        )}

        {/* COMMON FIELDS FOR BOTH TYPES */}

        {/* Date and Time Row */}
        <div className={hideDateInput ? "grid grid-cols-1 gap-4" : "grid grid-cols-2 gap-4"}>
          {/* Date (hidden when hideDateInput is true) */}
          {!hideDateInput && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('calendar.date')} <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={formData.date}
                min={getTodayDateString()}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              {errors.date && <p className="mt-1 text-sm text-red-600">{errors.date}</p>}
            </div>
          )}

          {/* Time */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('calendar.time')} <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.time}
              onChange={(e) => handleInputChange('time', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">{t('calendar.selectTime')}</option>
              {timeOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            {errors.time && <p className="mt-1 text-sm text-red-600">{errors.time}</p>}
          </div>
        </div>

        {/* Duration */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('calendar.duration')}</label>
          <select
            value={formData.duration}
            onChange={(e) => handleInputChange('duration', Number(e.target.value))}
            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            {DURATION_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        {/* Color */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t('calendar.color')}</label>
          <ColorSelect
            color={formData.color}
            setColor={(color) => handleInputChange('color', color)}
          />
        </div>

        {/* Notes */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            {eventType === 'patient' ? t('calendar.consultationNotes') : t('calendar.description')}
          </label>
          <textarea
            value={formData.notes}
            onChange={(e) => handleInputChange('notes', e.target.value)}
            placeholder={
              eventType === 'patient'
                ? t('calendar.consultationNotesPlaceholder')
                : t('calendar.descriptionPlaceholder')
            }
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
            disabled={isSubmitting || loading}
          >
            {t('calendar.cancel')}
          </button>
          <button
            type="submit"
            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isSubmitting || loading}
          >
            {isSubmitting || loading ? t('calendar.loading') : editEvent ? t('calendar.update') : t('calendar.create')}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default EventModal;
