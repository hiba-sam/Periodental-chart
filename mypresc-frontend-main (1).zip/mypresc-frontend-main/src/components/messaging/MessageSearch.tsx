'use client';

import React, { useState, useCallback, useRef } from 'react';
import { Search, X, Loader2 } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';
import { fr } from 'date-fns/locale';

interface SearchResult {
    id: number;
    content: string;
    sender_name: string;
    created_at: string;
}

interface MessageSearchProps {
    conversationId: number;
    onResultClick?: (messageId: number) => void;
}

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

export default function MessageSearch({ conversationId, onResultClick }: MessageSearchProps) {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<SearchResult[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const debounceRef = useRef<NodeJS.Timeout | null>(null);

    const searchMessages = useCallback(async (searchQuery: string) => {
        if (searchQuery.length < 2) {
            setResults([]);
            return;
        }

        setIsLoading(true);
        setError(null);

        try {
            const response = await fetch(
                `${API_URL}/messaging/conversations/${conversationId}/search?q=${encodeURIComponent(searchQuery)}`,
                { credentials: 'include' }
            );

            if (!response.ok) {
                throw new Error('Search failed');
            }

            const data = await response.json();
            setResults(data.data || []);
        } catch (err) {
            setError('Échec de la recherche');
            setResults([]);
        } finally {
            setIsLoading(false);
        }
    }, [conversationId]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setQuery(value);

        // Debounce search
        if (debounceRef.current) {
            clearTimeout(debounceRef.current);
        }

        debounceRef.current = setTimeout(() => {
            searchMessages(value);
        }, 300);
    };

    const formatDate = (dateStr: string) => {
        const date = new Date(dateStr);
        if (isToday(date)) {
            return format(date, 'HH:mm');
        } else if (isYesterday(date)) {
            return 'Hier ' + format(date, 'HH:mm');
        }
        return format(date, 'dd/MM/yyyy', { locale: fr });
    };

    const highlightMatch = (text: string, searchTerm: string) => {
        if (!searchTerm.trim()) return text;

        const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        const parts = text.split(regex);

        return parts.map((part, index) =>
            regex.test(part) ? (
                <mark key={index} className="bg-yellow-300 dark:bg-yellow-600 rounded px-0.5">
                    {part}
                </mark>
            ) : part
        );
    };

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                title="Rechercher dans la conversation"
            >
                <Search className="w-5 h-5" />
            </button>
        );
    }

    return (
        <div className="relative">
            {/* Search Input */}
            <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2">
                <Search className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                <input
                    type="text"
                    value={query}
                    onChange={handleInputChange}
                    placeholder="Rechercher des messages..."
                    className="flex-1 bg-transparent text-sm outline-none text-gray-900 dark:text-gray-100 placeholder-gray-500"
                    autoFocus
                />
                {isLoading && <Loader2 className="w-4 h-4 animate-spin text-gray-500" />}
                <button
                    onClick={() => {
                        setIsOpen(false);
                        setQuery('');
                        setResults([]);
                    }}
                    className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                    <X className="w-4 h-4" />
                </button>
            </div>

            {/* Search Results Dropdown */}
            {(results.length > 0 || error) && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 max-h-80 overflow-y-auto z-50">
                    {error ? (
                        <div className="p-4 text-sm text-red-500">{error}</div>
                    ) : (
                        <>
                            <div className="p-2 text-xs text-gray-500 dark:text-gray-400 border-b border-gray-200 dark:border-gray-700">
                                {results.length} résultat{results.length !== 1 ? 's' : ''}
                            </div>
                            {results.map((result) => (
                                <button
                                    key={result.id}
                                    onClick={() => {
                                        onResultClick?.(result.id);
                                        setIsOpen(false);
                                        setQuery('');
                                        setResults([]);
                                    }}
                                    className="w-full px-4 py-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700 border-b last:border-b-0 border-gray-100 dark:border-gray-700 transition-colors"
                                >
                                    <div className="flex justify-between items-start mb-1">
                                        <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                                            {result.sender_name}
                                        </span>
                                        <span className="text-xs text-gray-400 dark:text-gray-500">
                                            {formatDate(result.created_at)}
                                        </span>
                                    </div>
                                    <p className="text-sm text-gray-900 dark:text-gray-100 line-clamp-2">
                                        {highlightMatch(result.content, query)}
                                    </p>
                                </button>
                            ))}
                        </>
                    )}
                </div>
            )}

            {/* No results message */}
            {query.length >= 2 && !isLoading && results.length === 0 && !error && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-4 z-50">
                    <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
                        Aucun message trouvé pour "{query}"
                    </p>
                </div>
            )}
        </div>
    );
}
