'use client';

import React, { useEffect, useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import socketClient from '@/utils/socketClient';

interface PresenceBadgeProps {
  userId: number;
  className?: string;
}

type PresenceStatus = 'online' | 'away' | 'offline';

export default function PresenceBadge({ userId, className = '' }: PresenceBadgeProps) {
  const [status, setStatus] = useState<PresenceStatus>('offline');
  const [lastSeenAt, setLastSeenAt] = useState<Date | null>(null);

  useEffect(() => {
    // Fetch initial presence
    const fetchPresence = async () => {
      try {
        const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

        // Add timestamp for cache-busting to ensure fresh presence data
        const res = await fetch(`${API_URL}/messaging/users/${userId}/presence?_t=${Date.now()}`, {
          credentials: 'include',
          cache: 'no-store',
        });

        if (res.ok) {
          const data = await res.json();
          setStatus(data.data?.status || 'offline');
          if (data.data?.last_seen_at) {
            setLastSeenAt(new Date(data.data.last_seen_at));
          }
        }
      } catch (error) {
        console.error('Failed to fetch presence:', error);
      }
    };

    fetchPresence();

    // Listen for presence changes
    const handlePresenceChange = (data: {
      userId: number;
      status: PresenceStatus;
      timestamp?: Date | string;
    }) => {
      if (data.userId === userId) {
        setStatus(data.status);
        if (data.status === 'offline' && data.timestamp) {
          setLastSeenAt(new Date(data.timestamp));
        } else if (data.status === 'online') {
          // Clear last seen when user comes online
          setLastSeenAt(null);
        }
      }
    };

    const socket = socketClient.getSocket();
    if (socket) {
      socket.on('presence:changed', handlePresenceChange);
    }

    return () => {
      if (socket) {
        socket.off('presence:changed', handlePresenceChange);
      }
    };
  }, [userId]);

  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'offline':
      default:
        return 'bg-gray-400';
    }
  };

  const getStatusLabel = () => {
    switch (status) {
      case 'online':
        return 'En ligne';
      case 'away':
        return 'Absent';
      case 'offline':
      default:
        if (lastSeenAt) {
          try {
            return `Vu ${formatDistanceToNow(lastSeenAt, { addSuffix: true, locale: fr })}`;
          } catch {
            return 'Hors ligne';
          }
        }
        return 'Hors ligne';
    }
  };

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      <div className={`w-2 h-2 rounded-full ${getStatusColor()}`} />
      <span className="text-xs text-gray-600 dark:text-gray-400">
        {getStatusLabel()}
      </span>
    </div>
  );
}
