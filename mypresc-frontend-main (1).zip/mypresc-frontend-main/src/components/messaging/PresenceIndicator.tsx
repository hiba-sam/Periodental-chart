'use client';

import { useState, useEffect } from 'react';
import socketClient from '@/utils/socketClient';

interface PresenceIndicatorProps {
  userId: number;
  size?: 'sm' | 'md' | 'lg';
}

export default function PresenceIndicator({ userId, size = 'md' }: PresenceIndicatorProps) {
  const [status, setStatus] = useState<'online' | 'away' | 'offline'>('offline');

  useEffect(() => {
    // Fetch initial presence
    const fetchPresence = async () => {
      try {
        const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';
        
        const res = await fetch(`${API_URL}/messaging/users/${userId}/presence`, {
          credentials: 'include', // Envoie les cookies HTTP-only
        });

        if (res.ok) {
          const data = await res.json();
          setStatus(data.data?.status || 'offline');
        }
      } catch (error) {
        console.error('Failed to fetch presence:', error);
      }
    };

    fetchPresence();

    // Listen for presence changes
    const handlePresenceChange = (data: { userId: number; status: 'online' | 'away' | 'offline' }) => {
      if (data.userId === userId) {
        setStatus(data.status);
      }
    };

    const socket = socketClient.getSocket();
    if (socket) {
      socket.on('presence:changed', handlePresenceChange);
    }

    return () => {
      if (socket) {
        socket.off('presence:changed', handlePresenceChange);
      }
    };
  }, [userId]);

  const getStatusColor = () => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'offline':
      default:
        return 'bg-gray-400';
    }
  };

  const getSizeClass = () => {
    switch (size) {
      case 'sm':
        return 'w-2.5 h-2.5';
      case 'lg':
        return 'w-4 h-4';
      case 'md':
      default:
        return 'w-3.5 h-3.5';
    }
  };

  return (
    <div className={`${getSizeClass()} ${getStatusColor()} border-2 border-white rounded-full`}></div>
  );
}
