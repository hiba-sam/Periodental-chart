"use client";

import {
  HomeIcon as HomeOutline,
  UserIcon as UsersOutline,
  DocumentTextIcon as ClipboardOutline,
  BellIcon as BellOutline,
  UserCircleIcon as UserCircleOutline,
  Cog6ToothIcon as CogOutline,
  ArrowLeftOnRectangleIcon as ArrowLeftOutline,
  ChevronRightIcon as ChevronRight,
  ChevronLeftIcon as ChevronLeft,
  CalendarIcon as CalendarOutline,
  ChatBubbleLeftRightIcon as ChatOutline,
} from "@heroicons/react/24/outline";

import {
  HomeIcon as HomeSolid,
  UserIcon as UsersSolid,
  DocumentTextIcon as ClipboardSolid,
  BellIcon as BellSolid,
  UserCircleIcon as UserCircleSolid,
  Cog6ToothIcon as CogSolid,
  ArrowLeftOnRectangleIcon as ArrowLeftSolid,
  CalendarIcon as CalendarSolid,
  ChatBubbleLeftRightIcon as ChatSolid,
} from "@heroicons/react/24/solid";

import { useState, useEffect, useMemo } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useMessagingSafe } from "@/contexts/MessagingContext";
import LogoDonut from "./ui/Logo";


// The onToggleExpanded prop is received here
export default function Sidebar({
  onToggleExpanded = () => { },
  isMobileOpen = false,
  onMobileClose = () => { },
}: {
  onToggleExpanded?: (expanded: boolean) => void;
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
}) {
  const { logout, user } = useAuth();
  const { t, isRTL } = useLanguage();
  const [activeItem, setActiveItem] = useState("");
  const [isExpanded, setIsExpanded] = useState(false);
  const pathname = usePathname();

  // Get messaging context (returns null if not in provider)
  const messagingContext = useMessagingSafe();

  // Calculate number of conversations with unread messages (number of people)
  const unreadConversationsCount = useMemo(() => {
    if (!messagingContext?.conversations) return 0;
    return messagingContext.conversations.filter(conv => (conv.unread_count || 0) > 0).length;
  }, [messagingContext?.conversations]);


  useEffect(() => {
    onToggleExpanded(isExpanded);
  }, [isExpanded, onToggleExpanded]);

  useEffect(() => {
    if (!pathname) {
      setActiveItem("");
      return;
    }
    if (pathname === "/dashboard" || pathname === "/") {
      setActiveItem("overview");
    } else if (pathname === "/patients" || pathname.includes("/patients/")) {
      setActiveItem("patients");
    } else if (pathname.includes("/ordonnance")) {
      setActiveItem("prescription");
    } else if (pathname.includes("/calendar")) {
      setActiveItem("calendar");
    } else if (pathname.includes("/notifications")) {
      setActiveItem("notifications");
    } else if (pathname.includes("/messages")) {
      setActiveItem("messages");
    } else if (pathname.includes("/profile")) {
      setActiveItem("profile");
    } else if (pathname.includes("/settings")) {
      setActiveItem("settings");
    } else {
      setActiveItem("");
    }
  }, [pathname]);

  if (!user) return null; // Sidebar won't render if no user

  // Desktop Item — icon only or icon+label based on isExpanded
  const Item = ({ href, labelKey, isActive, OutlineIcon, SolidIcon, onClick }: any) => (
    <li>
      <Link
        href={href}
        className={`flex items-center h-10 ${isRTL ? 'space-x-reverse' : ''} space-x-3 p-2 rounded-lg transition-all duration-300 transform
       ${isExpanded ? "px-4" : "justify-center"}
       ${isActive ? "bg-blue-800/30 dark:bg-blue-900/50" : "hover:bg-blue-800/30 dark:hover:bg-blue-900/30"}`}
        onClick={() => {
          setActiveItem(labelKey);
          if (onClick) onClick();
        }}
      >
        {isActive ? (
          <SolidIcon className="w-6 h-6 shrink-0" />
        ) : (
          <OutlineIcon className="w-6 h-6 shrink-0" />
        )}
        {isExpanded && <span
          className={`text-white whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out`}
        >
          {t(`sidebar.${labelKey}`)}
        </span>}
      </Link>
    </li>
  );

  // Mobile Item — same style as desktop Item (icon + label always shown)
  const MobileItem = ({ href, labelKey, isActive, OutlineIcon, SolidIcon, onClick }: any) => (
    <li>
      <Link
        href={href}
        className={`flex items-center h-10 ${isRTL ? 'space-x-reverse' : ''} space-x-3 p-2 rounded-lg transition-all duration-300
       ${isActive ? "bg-blue-800/30 dark:bg-blue-900/50" : "hover:bg-blue-800/30 dark:hover:bg-blue-900/30"}`}
        onClick={() => {
          setActiveItem(labelKey);
          if (onClick) onClick();
          onMobileClose();
        }}
      >
        {isActive ? (
          <SolidIcon className="w-6 h-6 shrink-0" />
        ) : (
          <OutlineIcon className="w-6 h-6 shrink-0" />
        )}
        <span className="text-white whitespace-nowrap">
          {t(`sidebar.${labelKey}`)}
        </span>
      </Link>
    </li>
  );

  return (
    <>
      {/* ─── DESKTOP SIDEBAR (hidden on mobile) ─── */}
      <div
        className={`hidden md:flex bg-[#2B2F98] dark:bg-gray-800 text-white h-dvh fixed top-0 flex-col z-30 transition-all duration-300 ease-in-out shadow-lg group
        rounded-r-2xl
        ${isExpanded ? "w-64" : "w-20"}
        `}
      >
        {/* Header + Logo */}
        <div
          className={`py-6 px-2 gap-2 flex items-center justify-center transition-all duration-300 overflow-hidden ${isExpanded ? `px-4 ${isRTL ? 'space-x-reverse' : ''} space-x-2` : "px-2"
            }`}
          dir="ltr"
        >
          <LogoDonut />
          <h1
            className={`text-sm xl:text-base font-bold whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out ${isExpanded ? "opacity-100 w-auto" : "opacity-0 w-0"
              }`}
          >
            MyPrescription
          </h1>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 mt-10">
          <ul className="space-y-3">
            <Item
              href="/dashboard"
              labelKey="overview"
              isActive={activeItem === "overview"}
              OutlineIcon={HomeOutline}
              SolidIcon={HomeSolid}
            />
            <Item
              href="/patients"
              labelKey="patients"
              isActive={activeItem === "patients"}
              OutlineIcon={UsersOutline}
              SolidIcon={UsersSolid}
            />
            {user?.role === 'doctor' && (
              <Item
                href="/ordonnance"
                labelKey="prescription"
                isActive={activeItem === "prescription"}
                OutlineIcon={ClipboardOutline}
                SolidIcon={ClipboardSolid}
              />
            )}
            <Item
              href="/calendar"
              labelKey="calendar"
              isActive={activeItem === "calendar"}
              OutlineIcon={CalendarOutline}
              SolidIcon={CalendarSolid}
            />
            {/* Messages with unread badge */}
            <li>
              <Link
                href="/messages"
                className={`relative flex items-center h-10 ${isRTL ? 'space-x-reverse' : ''} space-x-3 p-2 rounded-lg transition-all duration-300 transform
                ${isExpanded ? "px-4" : "justify-center"}
                ${activeItem === "messages" ? "bg-blue-800/30 dark:bg-blue-900/50" : "hover:bg-blue-800/30 dark:hover:bg-blue-900/30"}`}
                onClick={() => setActiveItem("messages")}
              >
                {activeItem === "messages" ? (
                  <ChatSolid className={`w-6 h-6 shrink-0 ${unreadConversationsCount > 0 ? 'text-red-400' : ''}`} />
                ) : (
                  <ChatOutline className={`w-6 h-6 shrink-0 ${unreadConversationsCount > 0 ? 'text-red-400' : ''}`} />
                )}
                {isExpanded && (
                  <span className={`text-white whitespace-nowrap overflow-hidden transition-all duration-300 ease-in-out ${unreadConversationsCount > 0 ? 'text-red-300' : ''}`}>
                    {t(`sidebar.messages`)}
                  </span>
                )}
                {/* Unread badge */}
                {unreadConversationsCount > 0 && (
                  <span className={`absolute ${isExpanded ? 'right-2' : '-top-1 -right-1'} bg-red-500 text-white text-xs font-bold rounded-full min-w-[20px] h-5 flex items-center justify-center px-1.5`}>
                    {unreadConversationsCount > 99 ? '99+' : unreadConversationsCount}
                  </span>
                )}
              </Link>
            </li>
            <Item
              href="/notifications"
              labelKey="notifications"
              isActive={activeItem === "notifications"}
              OutlineIcon={BellOutline}
              SolidIcon={BellSolid}
            />
            <Item
              href="/profile"
              labelKey="profile"
              isActive={activeItem === "profile"}
              OutlineIcon={UserCircleOutline}
              SolidIcon={UserCircleSolid}
            />
          </ul>
        </nav>

        {/* Footer */}
        <div className="px-2 mt-auto mb-10">
          <ul className="space-y-3">
            <Item
              href="/settings"
              labelKey="settings"
              isActive={activeItem === "settings"}
              OutlineIcon={CogOutline}
              SolidIcon={CogSolid}
            />
            <Item
              href="/"
              labelKey="logout"
              isActive={activeItem === "logout"}
              onClick={logout}
              OutlineIcon={ArrowLeftOutline}
              SolidIcon={ArrowLeftSolid}
            />
          </ul>
        </div>

        {/* Toggle Button */}
        <button
          style={{
            [isRTL ? 'left' : 'right']: '-1.5rem',
          }}
          className={`absolute top-1/2 transform -translate-y-1/2 p-2 rounded-full bg-blue-600 dark:bg-blue-700 text-white shadow-lg transition-all duration-300 ease-in-out z-50 hover:bg-blue-700 dark:hover:bg-blue-600
          ${isExpanded ? "" : "group-hover:flex"}
          `}
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? (
            isRTL ? <ChevronRight className="w-6 h-6" /> : <ChevronLeft className="w-6 h-6" />
          ) : (
            isRTL ? <ChevronLeft className="w-6 h-6" /> : <ChevronRight className="w-6 h-6" />
          )}
        </button>
      </div>

      {/* ─── MOBILE DRAWER (hidden on desktop) ─── */}
      <div
        className={`md:hidden fixed top-16 h-[calc(100vh-3.5rem)] w-72 bg-[#2B2F98] dark:bg-gray-800 text-white z-50 flex flex-col shadow-2xl transition-transform duration-300 ease-in-out
          ${isMobileOpen
            ? 'translate-x-0'
            : isRTL ? 'translate-x-full' : '-translate-x-full'
          }
        `}
      >
        {/* Header + Logo — mirrors desktop sidebar */}
        <div className="py-6 px-4 flex items-center justify-center space-x-3" dir="ltr">
          <LogoDonut />
          <h1 className="text-md font-bold whitespace-nowrap">MyPrescription</h1>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 mt-10 overflow-y-auto">
          <ul className="space-y-2">
            <MobileItem
              href="/dashboard"
              labelKey="overview"
              isActive={activeItem === "overview"}
              OutlineIcon={HomeOutline}
              SolidIcon={HomeSolid}
            />
            <MobileItem
              href="/patients"
              labelKey="patients"
              isActive={activeItem === "patients"}
              OutlineIcon={UsersOutline}
              SolidIcon={UsersSolid}
            />
            <MobileItem
              href="/calendar"
              labelKey="calendar"
              isActive={activeItem === "calendar"}
              OutlineIcon={CalendarOutline}
              SolidIcon={CalendarSolid}
            />
            {/* Messages with unread badge — mobile */}
            <li>
              <Link
                href="/messages"
                className={`relative flex items-center h-10 ${isRTL ? 'space-x-reverse' : ''} space-x-3 p-2 rounded-lg transition-all duration-300
                ${activeItem === "messages" ? "bg-blue-800/30 dark:bg-blue-900/50" : "hover:bg-blue-800/30 dark:hover:bg-blue-900/30"}`}
                onClick={() => { setActiveItem("messages"); onMobileClose(); }}
              >
                {activeItem === "messages" ? (
                  <ChatSolid className={`w-6 h-6 shrink-0 ${unreadConversationsCount > 0 ? 'text-red-400' : ''}`} />
                ) : (
                  <ChatOutline className={`w-6 h-6 shrink-0 ${unreadConversationsCount > 0 ? 'text-red-400' : ''}`} />
                )}
                <span className={`text-white whitespace-nowrap ${unreadConversationsCount > 0 ? 'text-red-300' : ''}`}>
                  {t(`sidebar.messages`)}
                </span>
                {unreadConversationsCount > 0 && (
                  <span className="absolute right-4 bg-red-500 text-white text-xs font-bold rounded-full min-w-[20px] h-5 flex items-center justify-center px-1.5">
                    {unreadConversationsCount > 99 ? '99+' : unreadConversationsCount}
                  </span>
                )}
              </Link>
            </li>
            {/* <MobileItem
              href="/notifications"
              labelKey="notifications"
              isActive={activeItem === "notifications"}
              OutlineIcon={BellOutline}
              SolidIcon={BellSolid}
            /> */}
            <MobileItem
              href="/profile"
              labelKey="profile"
              isActive={activeItem === "profile"}
              OutlineIcon={UserCircleOutline}
              SolidIcon={UserCircleSolid}
            />
          </ul>
        </nav>

        {/* Footer */}
        <div className="px-2 mt-auto mb-10">
          <ul className="space-y-3">
            <MobileItem
              href="/settings"
              labelKey="settings"
              isActive={activeItem === "settings"}
              OutlineIcon={CogOutline}
              SolidIcon={CogSolid}
            />
            <MobileItem
              href="/"
              labelKey="logout"
              isActive={activeItem === "logout"}
              onClick={logout}
              OutlineIcon={ArrowLeftOutline}
              SolidIcon={ArrowLeftSolid}
            />
          </ul>
        </div>
      </div>
    </>
  );
}
