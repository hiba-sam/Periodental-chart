'use client';

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import socketClient from '@/utils/socketClient';
import useSWR from 'swr';
import { useAuth } from '@/contexts/AuthContext';
import logger from '@/utils/logger';

interface Message {
  id: number | null;
  conversation_id: number;
  sender_id: number;
  sender_name: string;
  content: string;
  is_read: boolean;
  created_at: string;
  read_at?: string;
  is_edited?: boolean;
  tempId?: string;
  isPending?: boolean;
  isFailed?: boolean;
  attachment_url?: string;
  attachment_type?: 'image' | 'pdf';
  attachment_name?: string;
}

interface Conversation {
  id: number;
  other_user_id: number;
  other_user_name: string;
  last_message?: string;
  last_message_at?: string;
  unread_count: number;
}

interface ConversationPartner {
  id: number;
  other_user_id: number;
  other_user_name: string;
  last_message?: string;
  last_message_at?: string;
  unread_count: number;
}

// Cache for messages by conversation
interface MessageCache {
  [conversationId: number]: Message[];
}

interface MessagingContextType {
  conversations: Conversation[];
  conversationPartner: ConversationPartner | null;
  isLoading: boolean;
  partnerLoading: boolean;
  error: any;
  partnerError: any;
  refreshConversations: () => void;
  updateConversation: (conversationId: number, updates: Partial<Conversation>) => void;
  incrementUnread: (conversationId: number) => void;
  resetUnread: (conversationId: number) => void;
  activeConversationId: number | null;
  setActiveConversationId: (id: number | null) => void;
  // Message cache functions
  getMessagesForConversation: (conversationId: number) => Message[];
  setMessagesForConversation: (conversationId: number, messages: Message[]) => void;
  addMessageToConversation: (conversationId: number, message: Message) => void;
  updateMessageInConversation: (conversationId: number, messageId: number | null, updates: Partial<Message>) => void;
}

const MessagingContext = createContext<MessagingContextType | undefined>(undefined);

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// Fetcher for conversations (returns array)
const conversationsFetcher = async (url: string) => {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!res.ok) {
    throw new Error('Failed to fetch');
  }

  const data = await res.json();
  return data.data || [];
};

// Fetcher for conversation partner (can return null)
const partnerFetcher = async (url: string) => {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Handle 404 as "no partner" (valid case)
  if (res.status === 404) {
    return null;
  }

  if (!res.ok) {
    throw new Error('Failed to fetch conversation partner');
  }

  const data = await res.json();
  return data.data || null;
};

export function MessagingProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();

  const { data: conversations, error, isLoading, mutate } = useSWR<Conversation[]>(
    `${API_URL}/messaging/conversations`,
    conversationsFetcher,
    {
      refreshInterval: 30000, // Refresh every 30s
      revalidateOnFocus: true,
    }
  );

  // Fetch conversation partner (doctor for assistant, assistant for doctor)
  const { data: conversationPartner, error: partnerError, isLoading: partnerLoading } = useSWR<ConversationPartner | null>(
    `${API_URL}/messaging/conversation-partner`,
    partnerFetcher,
    {
      refreshInterval: 30000,
      revalidateOnFocus: true,
    }
  );

  const [localConversations, setLocalConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);

  // Global message cache - persists between page navigations
  const [messageCache, setMessageCache] = useState<MessageCache>({});

  // Define callbacks BEFORE refs
  const refreshConversations = useCallback(() => {
    mutate();
  }, [mutate]);

  const updateConversation = useCallback((conversationId: number, updates: Partial<Conversation>) => {
    setLocalConversations(prev =>
      prev.map(conv =>
        conv.id === conversationId
          ? { ...conv, ...updates }
          : conv
      )
    );
  }, []);

  const incrementUnread = useCallback((conversationId: number) => {
    setLocalConversations(prev =>
      prev.map(conv =>
        conv.id === conversationId
          ? { ...conv, unread_count: conv.unread_count + 1 }
          : conv
      )
    );
  }, []);

  const resetUnread = useCallback((conversationId: number) => {
    setLocalConversations(prev =>
      prev.map(conv =>
        conv.id === conversationId
          ? { ...conv, unread_count: 0 }
          : conv
      )
    );
  }, []);

  // Message cache functions
  const getMessagesForConversation = useCallback((conversationId: number): Message[] => {
    return messageCache[conversationId] || [];
  }, [messageCache]);

  const setMessagesForConversation = useCallback((conversationId: number, messages: Message[]) => {
    setMessageCache(prev => ({
      ...prev,
      [conversationId]: messages
    }));
  }, []);

  const addMessageToConversation = useCallback((conversationId: number, message: Message) => {
    setMessageCache(prev => {
      const existing = prev[conversationId] || [];
      // Check if message already exists (by id, tempId, or content+timestamp)
      const exists = existing.some(m => {
        // Check by ID
        if (m.id && message.id && m.id === message.id) return true;
        // Check by tempId
        if ((m as any).tempId && (message as any).tempId && (m as any).tempId === (message as any).tempId) return true;
        // Check by content + timestamp (for messages without id/tempId)
        if (m.content === message.content && m.created_at === message.created_at && m.sender_id === message.sender_id) return true;
        return false;
      });
      if (exists) return prev;
      return {
        ...prev,
        [conversationId]: [...existing, message]
      };
    });
  }, []);

  const updateMessageInConversation = useCallback((conversationId: number, messageId: number | null, updates: Partial<Message>) => {
    setMessageCache(prev => {
      const existing = prev[conversationId] || [];
      return {
        ...prev,
        [conversationId]: existing.map(msg =>
          msg.id === messageId ? { ...msg, ...updates } : msg
        )
      };
    });
  }, []);

  // Sync SWR data to local state (with deduplication and sorting)
  useEffect(() => {
    logger.log('📊 MessagingContext: conversations:', conversations);
    logger.log('🤝 MessagingContext: conversationPartner:', conversationPartner);
    logger.log('⚠️ MessagingContext: error:', error);
    logger.log('⚠️ MessagingContext: partnerError:', partnerError);

    if (conversations) {
      // Deduplicate by ID
      const uniqueConversations = Array.from(
        new Map(conversations.map(conv => [conv.id, conv])).values()
      );

      // Sort conversations: place partner conversation first if it exists
      const sortedConversations = [...uniqueConversations];
      if (conversationPartner) {
        const partnerIndex = sortedConversations.findIndex(
          conv => conv.id === conversationPartner.id
        );

        if (partnerIndex > 0) {
          // Move partner conversation to first position
          const [partnerConv] = sortedConversations.splice(partnerIndex, 1);
          sortedConversations.unshift(partnerConv!);
        }

        logger.log('✅ Sorted conversations with partner first:', sortedConversations);
      }

      // Merge with local state to preserve local modifications (like resetUnread)
      setLocalConversations(prev => {
        if (!prev || prev.length === 0) return sortedConversations;

        // Create a map of local unread counts (0 means user has read)
        const localUnreadMap = new Map(
          prev.filter(c => c.unread_count === 0).map(c => [c.id, 0])
        );

        // Merge: keep local unread_count if it was reset to 0
        return sortedConversations.map(conv => {
          if (localUnreadMap.has(conv.id)) {
            return { ...conv, unread_count: 0 };
          }
          return conv;
        });
      });
    }
  }, [conversations, conversationPartner]);

  // Use refs for stable references in socket handlers
  const updateConversationRef = useRef(updateConversation);
  const incrementUnreadRef = useRef(incrementUnread);
  const currentUserIdRef = useRef<number | null>(null);
  const activeConversationIdRef = useRef<number | null>(null);

  // Keep refs updated
  // Pour les assistants, user.id est le doctorId - on utilise assistant_id (leur vrai userId)
  useEffect(() => {
    updateConversationRef.current = updateConversation;
    incrementUnreadRef.current = incrementUnread;
    // assistant_id = vrai userId de l'assistant, sinon user.id pour les médecins
    const realUserId = (user as any)?.assistant_id || user?.id;
    currentUserIdRef.current = realUserId ? Number(realUserId) : null;
    activeConversationIdRef.current = activeConversationId;
  }, [updateConversation, incrementUnread, user, activeConversationId]);

  // Connect socket on mount - use onConnect to ensure listeners are added after connection
  useEffect(() => {
    socketClient.connect();

    // Listen for new messages
    const handleNewMessage = (data: { message: Message; conversationId: number; senderId?: number }) => {
      // Update last message in conversation
      updateConversationRef.current(data.conversationId, {
        last_message: data.message.content,
        last_message_at: data.message.created_at,
      });

      // Increment unread ONLY if:
      // 1. It's not the current user's message
      // 2. The sender ID is provided and different from current user
      // 3. The conversation is NOT currently open
      const senderId = data.senderId || data.message.sender_id;
      const isConversationOpen = activeConversationIdRef.current === data.conversationId;
      if (senderId && currentUserIdRef.current && senderId !== currentUserIdRef.current && !isConversationOpen) {
        incrementUnreadRef.current(data.conversationId);
      }
    };

    // Listen for conversation updates
    const handleConversationUpdated = (data: {
      conversationId: number;
      lastMessage: string;
      unreadCount: number;
    }) => {
      updateConversationRef.current(data.conversationId, {
        last_message: data.lastMessage,
      });
    };

    // Attach listeners when socket connects
    const attachListeners = () => {
      const socket = socketClient.getSocket();
      if (!socket) return;

      logger.log('📨 [MessagingContext] Attaching message:new listener');
      socket.off('message:new', handleNewMessage); // Remove existing to avoid duplicates
      socket.on('message:new', handleNewMessage);
      socket.off('conversation:updated', handleConversationUpdated);
      socket.on('conversation:updated', handleConversationUpdated);

      socketClient.updatePresence('online');
    };

    // Use onConnect to attach listeners after socket is connected
    const cleanupOnConnect = socketClient.onConnect(attachListeners);

    return () => {
      cleanupOnConnect();
      socketClient.updatePresence('offline');
      const socket = socketClient.getSocket();
      if (socket) {
        socket.off('message:new', handleNewMessage);
        socket.off('conversation:updated', handleConversationUpdated);
      }
    };
  }, []);

  return (
    <MessagingContext.Provider
      value={{
        conversations: localConversations || [],
        conversationPartner: conversationPartner || null,
        isLoading,
        partnerLoading,
        error,
        partnerError,
        refreshConversations,
        updateConversation,
        incrementUnread,
        resetUnread,
        activeConversationId,
        setActiveConversationId,
        getMessagesForConversation,
        setMessagesForConversation,
        addMessageToConversation,
        updateMessageInConversation,
      }}
    >
      {children}
    </MessagingContext.Provider>
  );
}

export function useMessaging() {
  const context = useContext(MessagingContext);
  if (context === undefined) {
    throw new Error('useMessaging must be used within a MessagingProvider');
  }
  return context;
}

// Safe version that doesn't throw - returns null if not in provider
export function useMessagingSafe() {
  const context = useContext(MessagingContext);
  return context ?? null;
}

export type { Conversation, ConversationPartner, Message };
