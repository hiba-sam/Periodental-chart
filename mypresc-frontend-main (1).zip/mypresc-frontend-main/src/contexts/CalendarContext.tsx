'use client';

import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import axios, { AxiosError } from 'axios';
import { toast } from '@/components/ui/use-toast';
import { usePatients } from './PatientsContext';
import { useAuth } from './AuthContext';
import { useWaitingRoom } from './WaitingRoomContext';
import { useAppointments } from './AppointmentContext';
import socketClient from '@/utils/socketClient';
import logger from '@/utils/logger';
import { useQueryClient } from '@tanstack/react-query';
import { dashboardKeys } from '@/features/dashboard/hooks/useDashboardStats';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export type CalendarView = 'day' | 'week' | 'month';

export interface CalendarEvent {
  id: string;
  date: Date;
  time: string; // HH:mm format
  duration: number; // minutes
  title: string;
  description?: string; // note field from API
  color: string; // Hex color
  patientId?: string;
  patientName?: string;
  patientFamilyName?: string;
  patientPhone?: string;
  patientAge?: number;
  confirmedComing?: boolean;
  venueConfirmed?: boolean;
  isDone?: boolean;
  appointmentId?: string | null; // null for standalone events
  isAppointmentLinked: boolean;
  // Computed fields
  endTime?: string; // HH:mm format
}

export interface CreateEventData {
  // For appointment-linked events
  patientId?: string;
  confirmedComing?: boolean;

  // For standalone events
  title?: string;

  // Common fields
  date: Date;
  time: string;
  duration?: number;
  notes?: string;
  color?: string;

  // Flag to determine event type
  isAppointment?: boolean;
}

export interface UpdateEventData {
  id: string;

  // Calendar fields
  title?: string;
  note?: string;
  date?: Date;
  time?: string;
  duration?: number;
  color?: string;

  // Appointment-specific fields (only for appointment-linked events)
  appointment_notes?: string;
  is_done?: boolean;
  confirmed_coming?: boolean;
  venue_confirmed?: boolean;
}

// ============================================================================
// CONTEXT DEFINITION
// ============================================================================

interface CalendarContextValue {
  // State
  events: CalendarEvent[];
  selectedDate: Date;
  selectedEvent: CalendarEvent | null;
  calendarView: CalendarView;
  loading: boolean;
  error: string | null;

  // Actions - Date Navigation
  setSelectedDate: (date: Date) => void;
  goToToday: () => void;
  goPrevious: () => void;
  goNext: () => void;

  // Actions - View Management
  setCalendarView: (view: CalendarView) => void;

  // Actions - Event Selection
  selectEvent: (event: CalendarEvent | null) => void;

  // Actions - CRUD Operations
  createEvent: (data: CreateEventData) => Promise<CalendarEvent | null>;
  updateEvent: (data: UpdateEventData, skipLoading?: boolean) => Promise<CalendarEvent | null>;
  updateEventOptimistic: (eventId: string, updates: Partial<CalendarEvent>) => void;
  deleteEvent: (eventId: string) => Promise<boolean>;

  // Utility Functions
  getEventsForDate: (date: Date) => CalendarEvent[];
  getEventsForWeek: (weekStart: Date) => CalendarEvent[];
  getEventsForMonth: (month: Date) => CalendarEvent[];
  getEventAtDateTime: (date: Date, time: string) => CalendarEvent | null;

  // Refresh data
  refreshEvents: () => Promise<void>;
}

const CalendarContext = createContext<CalendarContextValue | undefined>(undefined);

// ============================================================================
// AXIOS INSTANCE
// ============================================================================

const API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333') + '/calendar';
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
});

// ============================================================================
// PROVIDER COMPONENT
// ============================================================================

export const CalendarProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // External data sources
  const { getPatient } = usePatients();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Local state
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [calendarView, setCalendarView] = useState<CalendarView>('week');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fetchingTime, setFetchingTime] = useState<Date | null>(null);


  const { getTodaySchedule } = useWaitingRoom();
  const { fetchAppointments } = useAppointments();

  // Sync today's schedule and appointments only when the user identity changes.
  // ⚠️ Do NOT add 'events' here — it creates an infinite loop:
  //    events change → fetchAppointments fires → state updates → events change → ...
  useEffect(() => {
    if (!user?.id) return;
    getTodaySchedule(user.id);
    fetchAppointments();
  }, [user?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================

  /**
   * Calculate end time from start time and duration
   */
  const calculateEndTime = (startTime: string, duration: number): string => {
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + duration;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
  };

  /**
   * Calculate age from date of birth
   */
  const calculateAge = (dateOfBirth: string): number => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  /**
   * Compare two dates (date only, ignore time)
   */
  const isSameDay = (date1: Date, date2: Date): boolean => {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  };

  /**
   * Convert date string to local Date object (avoiding timezone issues)
   * Handles both "YYYY-MM-DD" and ISO timestamp formats
   * IMPORTANT: For ISO timestamps, converts to local date considering timezone offset
   */
  const parseLocalDate = (dateString: string): Date => {
    // If it's an ISO timestamp (e.g., "2025-10-18T23:00:00.000Z")
    if (dateString.includes('T')) {
      // Parse as Date and get local date components
      const date = new Date(dateString);
      // Use local date components to create a date object at midnight local time
      return new Date(date.getFullYear(), date.getMonth(), date.getDate());
    }

    // For plain date strings (e.g., "2025-10-18")
    const [year, month, day] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day);
  };

  /**
   * Convert Date object to local date string (YYYY-MM-DD)
   */
  const formatLocalDate = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  /**
   * Map API calendar event to CalendarEvent
   * Note: Patient data is already included in the API response via JOIN - no extra fetch needed
   */
  const mapApiEventToCalendarEvent = (apiEvent: any): CalendarEvent => {
    const dateObj = parseLocalDate(apiEvent.date);
    const timeStr = (apiEvent.time || '09:00').slice(0, 5);
    const duration = apiEvent.duration || 30;
    const isAppointmentLinked = !!apiEvent.appointment_id;

    // Patient data is already in the API response (from backend JOIN query)
    // No need to make additional API calls - this was causing N+1 performance issues
    const patientName = apiEvent.patient_name || apiEvent.appointment?.patient_name || '';
    const patientFamilyName = apiEvent.patient_family_name || apiEvent.appointment?.patient_family_name || '';

    const title = apiEvent.title ||
      (isAppointmentLinked ? `${patientName} ${patientFamilyName}`.trim() : 'Event');

    return {
      id: apiEvent.id,
      date: dateObj,
      time: timeStr,
      duration,
      title: title || 'Untitled Event',
      description: apiEvent.note || '',
      color: apiEvent.color || '#2563eb',
      appointmentId: apiEvent.appointment_id || null,
      patientId: apiEvent.patient_id || null,
      isAppointmentLinked,
      confirmedComing: apiEvent.confirmed_coming || false,
      venueConfirmed: apiEvent.venue_confirmed || false,
      isDone: apiEvent.is_done || false,
      endTime: calculateEndTime(timeStr, duration),
      patientName,
      patientFamilyName,
    };
  };

  // ============================================================================
  // FETCH CALENDAR EVENTS
  // ============================================================================

  // Ref so fetchEvents can read the current events array without closing over it.
  // This prevents fetchEvents from getting a new reference on every render,
  // which would cascade into socket re-subscriptions and unstable useCallback chains.
  const eventsRef = useRef(events);
  useEffect(() => {
    eventsRef.current = events;
  });

  const fetchEvents = useCallback(
    async (force: boolean = false) => {
      // 10-minute cache
      if (!force && eventsRef.current.length > 0 && fetchingTime) {
        const now = Date.now();
        const last = fetchingTime.getTime();
        const tenMinutesMs = 10 * 60 * 1000;
        if (now - last < tenMinutesMs) {
          return;
        }
      }

      setLoading(true);
      setError(null);

      try {
        const response = await axiosInstance.get('/', {
          params: {
            doctorUserId: user?.id || '1',
            limit: 100,
          },
        });

        if (response.data?.success && response.data.data) {
          const mappedEvents = response.data.data.map(mapApiEventToCalendarEvent);
          setEvents(mappedEvents);
          setFetchingTime(new Date());
        } else {
          const msg = response.data?.error || 'Échec du chargement des événements du calendrier.';
          setError(msg);
        }
      } catch (err) {
        setError('Échec du chargement des événements du calendrier.');
      } finally {
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [fetchingTime, user] // events.length removed — read via eventsRef to keep this callback stable
  );

  // Ref so the socket handler always calls the latest fetchEvents without
  // needing it as a dependency (which would cause the socket to re-subscribe
  // on every fetch, creating listener gaps during navigation).
  const fetchEventsRef = useRef(fetchEvents);
  useEffect(() => {
    fetchEventsRef.current = fetchEvents;
  });

  // Initial fetch
  useEffect(() => {
    if (user) {
      fetchEvents();
    }
    setError(null);
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  // Socket.IO Integration for real-time calendar updates.
  // ⚠️ Deps are intentionally [] — the socket must be subscribed ONCE and stay stable.
  //    fetchEventsRef.current always points to the latest fetchEvents without
  //    making it a dependency (which would cause constant re-subscription).
  useEffect(() => {
    const socket = socketClient.connect();

    if (!socket) {
      return;
    }

    const handleAppointmentChange = () => {
      // Reset fetchingTime to force a fresh fetch
      setFetchingTime(null);
      fetchEventsRef.current(); // ← uses ref, not direct closure
      // Invalidate dashboard stats to show updated appointment counts
      queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    socket.on('appointment:created', handleAppointmentChange);
    socket.on('appointment:updated', handleAppointmentChange);
    socket.on('appointment:deleted', handleAppointmentChange);

    return () => {
      socket.off('appointment:created', handleAppointmentChange);
      socket.off('appointment:updated', handleAppointmentChange);
      socket.off('appointment:deleted', handleAppointmentChange);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ============================================================================
  // DATE NAVIGATION ACTIONS
  // ============================================================================

  const goToToday = useCallback(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    setSelectedDate(today);
  }, []);

  const goPrevious = useCallback(() => {
    setSelectedDate((prev) => {
      const newDate = new Date(prev);
      if (calendarView === 'day') {
        newDate.setDate(newDate.getDate() - 1);
      } else if (calendarView === 'week') {
        newDate.setDate(newDate.getDate() - 7);
      } else if (calendarView === 'month') {
        newDate.setMonth(newDate.getMonth() - 1);
      }
      return newDate;
    });
  }, [calendarView]);

  const goNext = useCallback(() => {
    setSelectedDate((prev) => {
      const newDate = new Date(prev);
      if (calendarView === 'day') {
        newDate.setDate(newDate.getDate() + 1);
      } else if (calendarView === 'week') {
        newDate.setDate(newDate.getDate() + 7);
      } else if (calendarView === 'month') {
        newDate.setMonth(newDate.getMonth() + 1);
      }
      return newDate;
    });
  }, [calendarView]);

  // ============================================================================
  // EVENT SELECTION
  // ============================================================================

  const selectEvent = useCallback((event: CalendarEvent | null) => {
    setSelectedEvent(event);
  }, []);

  // ============================================================================
  // CRUD OPERATIONS
  // ============================================================================

  /**
   * Create a new calendar event
   */
  const createEvent = useCallback(
    async (data: CreateEventData): Promise<CalendarEvent | null> => {
      setLoading(true);
      setError(null);
      logger.log('Creating event with data:', data);

      try {
        const dateStr = formatLocalDate(data.date);

        const payload: any = {
          title: data.title,
          date: dateStr,
          time: data.time,
          duration: data.duration || 30,
          color: data.color || '#2563eb',
          note: data.notes || '',
        };

        // If it's an appointment-linked event
        if (data.patientId) {
          payload.appointment = {
            patient_id: data.patientId,
            confirmed_coming: data.confirmedComing || false,
            is_done: false,
          };
        }

        const response = await axiosInstance.post('/', payload, {
          params: { doctorUserId: user?.id || '1' },
        });

        if (response.data?.success && response.data.data) {
          const newEvent = mapApiEventToCalendarEvent(response.data.data);
          setEvents((prev) => [...prev, newEvent]);
          toast.success(
            response.data?.message ||
            (data.isAppointment ? 'Rendez-vous créé avec succès' : 'Événement créé avec succès')
          );
          return newEvent;
        }

        const msg = response.data?.error || 'Erreur lors de la création de l\'événement.';
        setError(msg);
        toast.error(msg, 'Erreur');
        return null;
      } catch (err) {
        console.error('Erreur createEvent:', err);
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data && (axiosErr.response.data as any).error
            ? (axiosErr.response.data as any).error
            : 'Erreur lors de la création de l\'événement.';
        setError(message);
        toast.error(message, 'Erreur');
        return null;
      } finally {
        setLoading(false);
      }
    },
    [user, getPatient, formatLocalDate, mapApiEventToCalendarEvent]
  );

  /**
   * Optimistically update an event in local state (for instant UI feedback)
   * Use this before making the API call for drag-and-drop or similar interactions
   */
  const updateEventOptimistic = useCallback((eventId: string, updates: Partial<CalendarEvent>) => {
    logger.log('[CalendarContext] Optimistic update for event:', eventId, updates);
    setEvents((prev) =>
      prev.map((e) => {
        if (e.id === eventId) {
          const updatedEvent = { ...e, ...updates };
          // Recalculate endTime if time or duration changed
          if (updates.time || updates.duration) {
            updatedEvent.endTime = calculateEndTime(
              updatedEvent.time,
              updatedEvent.duration
            );
          }
          return updatedEvent;
        }
        return e;
      })
    );
  }, []);

  /**
   * Update an existing calendar event
   * @param skipLoading - If true, skip loading state to prevent scroll reset (for optimistic updates)
   */

  // Ref so updateEvent can check selectedEvent without closing over it.
  // Closing over selectedEvent directly makes updateEvent get a new reference
  // every time the user clicks an event, making the entire CalendarContextValue
  // object unstable and forcing expensive re-renders of all consumers.
  const selectedEventRef = useRef(selectedEvent);
  useEffect(() => {
    selectedEventRef.current = selectedEvent;
  });

  const updateEvent = useCallback(
    async (data: UpdateEventData, skipLoading: boolean = false): Promise<CalendarEvent | null> => {
      if (!skipLoading) setLoading(true);
      setError(null);
      logger.log('Updating event with data:', data);

      try {
        const payload: any = {};

        if (data.title !== undefined) payload.title = data.title;
        if (data.note !== undefined) payload.note = data.note;
        if (data.date) payload.date = formatLocalDate(data.date);
        if (data.time !== undefined) payload.time = data.time;
        if (data.duration !== undefined) payload.duration = data.duration;
        if (data.color) payload.color = data.color;

        // Appointment-specific fields
        if (data.appointment_notes !== undefined) payload.appointment_notes = data.appointment_notes;
        if (data.is_done !== undefined) payload.is_done = data.is_done;
        if (data.confirmed_coming !== undefined) payload.confirmed_coming = data.confirmed_coming;
        if (data.venue_confirmed !== undefined) payload.venue_confirmed = data.venue_confirmed;

        const response = await axiosInstance.put(`/${data.id}`, payload, {
          params: { doctorUserId: user?.id || '1' },
        });
        logger.log('API Response for updateEvent:', response.data);

        if (response.data?.success && response.data.data) {
          const updatedEvent = mapApiEventToCalendarEvent(response.data.data);
          // Update local state immediately for instant UI feedback
          setEvents((prev) => prev.map((e) => (e.id === data.id ? updatedEvent : e)));
          // Update selected event if it's the one being edited
          if (selectedEventRef.current?.id === data.id) {
            setSelectedEvent(updatedEvent);
          }
          toast.success(response.data?.message || 'Événement mis à jour avec succès');
          return updatedEvent;
        }

        const msg = response.data?.error || 'Erreur lors de la mise à jour de l\'événement.';
        setError(msg);
        toast.error(msg, 'Erreur');
        return null;
      } catch (err) {
        console.error('Erreur updateEvent:', err);
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data && (axiosErr.response.data as any).error
            ? (axiosErr.response.data as any).error
            : 'Erreur lors de la mise à jour de l\'événement.';
        setError(message);
        toast.error(message, 'Erreur');
        return null;
      } finally {
        if (!skipLoading) setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [user, formatLocalDate, mapApiEventToCalendarEvent] // selectedEvent removed — read via selectedEventRef
  );

  /**
   * Delete a calendar event
   */
  const deleteEvent = useCallback(
    async (eventId: string): Promise<boolean> => {
      setLoading(true);
      setError(null);

      try {
        const response = await axiosInstance.delete(`/${eventId}`, {
          params: { doctorUserId: user?.id || '1' },
        });

        if (response.data?.success) {
          setEvents((prev) => prev.filter((event) => event.id !== eventId));

          // Clear selected event if it was deleted
          if (selectedEvent?.id === eventId) {
            setSelectedEvent(null);
          }

          toast.success(response.data?.message || 'Événement supprimé avec succès');
          return true;
        }

        const msg = response.data?.error || 'Erreur lors de la suppression de l\'événement.';
        setError(msg);
        toast.error(msg, 'Erreur');
        return false;
      } catch (err) {
        console.error('Erreur deleteEvent:', err);
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data && (axiosErr.response.data as any).error
            ? (axiosErr.response.data as any).error
            : 'Erreur lors de la suppression de l\'événement.';
        setError(message);
        toast.error(message, 'Erreur');
        return false;
      } finally {
        setLoading(false);
      }
    },
    [user, selectedEvent]
  );

  // ============================================================================
  // QUERY FUNCTIONS
  // ============================================================================

  /**
   * Get all events for a specific date
   */
  const getEventsForDate = useCallback(
    (date: Date): CalendarEvent[] => {
      return events.filter((event) => isSameDay(event.date, date));
    },
    [events]
  );

  /**
   * Get all events for a week (starting from weekStart)
   */
  const getEventsForWeek = useCallback(
    (weekStart: Date): CalendarEvent[] => {
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 7);

      return events.filter((event) => {
        return event.date >= weekStart && event.date < weekEnd;
      });
    },
    [events]
  );

  /**
   * Get all events for a specific month
   */
  const getEventsForMonth = useCallback(
    (month: Date): CalendarEvent[] => {
      return events.filter(
        (event) =>
          event.date.getFullYear() === month.getFullYear() &&
          event.date.getMonth() === month.getMonth()
      );
    },
    [events]
  );

  /**
   * Get event at a specific date and time
   */
  const getEventAtDateTime = useCallback(
    (date: Date, time: string): CalendarEvent | null => {
      const dayEvents = getEventsForDate(date);
      return dayEvents.find((event) => event.time === time) || null;
    },
    [getEventsForDate]
  );

  /**
   * Refresh events from API
   */
  const refreshEvents = useCallback(async () => {
    await fetchEvents(true);
  }, [fetchEvents]);

  // ============================================================================
  // CONTEXT VALUE
  // ============================================================================

  const value: CalendarContextValue = {
    // State
    events,
    selectedDate,
    selectedEvent,
    calendarView,
    loading,
    error,

    // Actions - Date Navigation
    setSelectedDate,
    goToToday,
    goPrevious,
    goNext,

    // Actions - View Management
    setCalendarView,

    // Actions - Event Selection
    selectEvent,

    // Actions - CRUD
    createEvent,
    updateEvent,
    updateEventOptimistic,
    deleteEvent,

    // Utility Functions
    getEventsForDate,
    getEventsForWeek,
    getEventsForMonth,
    getEventAtDateTime,

    // Refresh
    refreshEvents,
  };

  return <CalendarContext.Provider value={value}>{children}</CalendarContext.Provider>;
};

// ============================================================================
// CUSTOM HOOK
// ============================================================================

export const useCalendar = () => {
  const context = useContext(CalendarContext);
  if (!context) {
    throw new Error('useCalendar must be used within a CalendarProvider');
  }
  return context;
};