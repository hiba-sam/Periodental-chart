'use client';

import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

// Axios instance
const NOTIFICATION_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/notification";

const axiosInstance = axios.create({
  baseURL: NOTIFICATION_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

/**
 * Notification type from backend
 */
export type NotificationType = 'alert' | 'check' | 'error' | 'info';

/**
 * Notification interface matching backend structure
 */
export interface Notification {
  id: string;
  user_id: number;
  type: NotificationType;
  title: string;
  description: string;
  link?: string | null;
  data?: Record<string, any> | null;
  is_seen: boolean;
  created_at: string;
  updated_at: string;
}

/**
 * Notification statistics
 */
export interface NotificationStats {
  total: number;
  unseen: number;
  seen: number;
}

/**
 * Query parameters for fetching notifications
 */
export interface NotificationQueryParams {
  limit?: number;
  offset?: number;
  type?: NotificationType;
  seen?: boolean;
}

/**
 * Backend API response structure
 */
interface NotificationApiResponse {
  success: boolean;
  data?: Notification | Notification[] | NotificationStats | { updatedCount: number };
  message?: string;
  error?: string;
}

/**
 * Context state interface
 */
interface NotificationContextState {
  notifications: Notification[];
  loading: boolean;
  error: string | null;
  stats: NotificationStats | null;

  // Fetch methods
  getAllNotifications: (params?: NotificationQueryParams) => Promise<void>;
  getNotificationStats: () => Promise<void>;
  searchNotifications: (query: string, limit?: number, offset?: number) => Promise<Notification[]>;

  // Action methods
  deleteNotification: (id: string) => Promise<boolean>;
  markAsSeen: (id: string) => Promise<boolean>;
  markAsUnseen: (id: string) => Promise<boolean>;
  markAllAsSeen: () => Promise<number>;

  // Utility methods
  clearError: () => void;
  getUnreadCount: () => number;
}

// ============================================================================
// CONTEXT CREATION
// ============================================================================

const NotificationContext = createContext<NotificationContextState | undefined>(undefined);

// ============================================================================
// PROVIDER COMPONENT
// ============================================================================

interface NotificationProviderProps {
  children: ReactNode;
  autoFetch?: boolean; // Whether to auto-fetch notifications on mount
}

/**
 * NotificationProvider Component
 *
 * Manages notifications for the authenticated user.
 * Provides methods to fetch, update, and manage notifications.
 */
export const NotificationProvider: React.FC<NotificationProviderProps> = ({
  children,
  autoFetch = true
}) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<NotificationStats | null>(null);

  const { isAuthenticated } = useAuth();

  /**
   * Fetches all notifications with optional filters
   * Calls GET /notification
   */
  const getAllNotifications = useCallback(async (params?: NotificationQueryParams) => {
    setLoading(true);
    setError(null);

    try {
      const queryParams = new URLSearchParams();

      if (params?.limit) queryParams.append('limit', params.limit.toString());
      if (params?.offset) queryParams.append('offset', params.offset.toString());
      if (params?.type) queryParams.append('type', params.type);
      if (params?.seen !== undefined) queryParams.append('seen', params.seen.toString());

      const url = queryParams.toString() ? `?${queryParams.toString()}` : '';
      const response = await axiosInstance.get<NotificationApiResponse>(url);

      if (response.data.success && Array.isArray(response.data.data)) {
        setNotifications(response.data.data);
      } else {
        throw new Error(response.data.error || 'Failed to fetch notifications');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while fetching notifications';

      setError(errorMessage);
      console.error('NotificationContext: getAllNotifications error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Fetches notification statistics
   * Calls GET /notification/stats
   */
  const getNotificationStats = useCallback(async () => {
    try {
      const response = await axiosInstance.get<NotificationApiResponse>('/stats');

      if (response.data.success && response.data.data) {
        setStats(response.data.data as NotificationStats);
      } else {
        throw new Error(response.data.error || 'Failed to fetch notification stats');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while fetching notification stats';

      console.error('NotificationContext: getNotificationStats error:', err);
    }
  }, []);

  /**
   * Searches notifications by query
   * Calls GET /notification/search
   *
   * @param query - Search query string
   * @param limit - Maximum number of results (default: 50)
   * @param offset - Pagination offset (default: 0)
   * @returns Promise<Notification[]> - Array of matching notifications
   */
  const searchNotifications = useCallback(async (
    query: string,
    limit: number = 50,
    offset: number = 0
  ): Promise<Notification[]> => {
    setLoading(true);
    setError(null);

    try {
      const queryParams = new URLSearchParams({
        q: query,
        limit: limit.toString(),
        offset: offset.toString()
      });

      const response = await axiosInstance.get<NotificationApiResponse>(`/search?${queryParams.toString()}`);

      if (response.data.success && Array.isArray(response.data.data)) {
        return response.data.data;
      } else {
        throw new Error(response.data.error || 'Failed to search notifications');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while searching notifications';

      setError(errorMessage);
      console.error('NotificationContext: searchNotifications error:', err);
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Deletes a notification
   * Calls DELETE /notification/:id
   * Refetches notifications and stats after successful deletion
   *
   * @param id - The notification ID
   * @returns Promise<boolean> - true if deletion succeeded, false otherwise
   */
  const deleteNotification = useCallback(async (id: string): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosInstance.delete<NotificationApiResponse>(`/${id}`);

      if (response.data.success) {
        // Update local state by removing the deleted notification
        setNotifications(prev => prev.filter(n => n.id !== id));
        // Refresh stats and notifications
        await Promise.all([
          getNotificationStats(),
          getAllNotifications()
        ]);
        return true;
      } else {
        throw new Error(response.data.error || 'Failed to delete notification');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while deleting notification';

      setError(errorMessage);
      console.error('NotificationContext: deleteNotification error:', err);
      return false;
    } finally {
      setLoading(false);
    }
  }, [getNotificationStats, getAllNotifications]);

  /**
   * Marks a notification as seen
   * Calls PATCH /notification/:id/seen
   * Refetches notifications and stats after success
   *
   * @param id - The notification ID
   * @returns Promise<boolean> - true if update succeeded, false otherwise
   */
  const markAsSeen = useCallback(async (id: string): Promise<boolean> => {
    try {
      const response = await axiosInstance.patch<NotificationApiResponse>(`/${id}/seen`);

      if (response.data.success && response.data.data && !Array.isArray(response.data.data)) {
        const updatedNotification = response.data.data as Notification;
        // Update local state
        setNotifications(prev =>
          prev.map(n => n.id === id ? updatedNotification : n)
        );
        // Refresh stats and notifications
        await Promise.all([
          getNotificationStats(),
          getAllNotifications()
        ]);
        return true;
      } else {
        throw new Error(response.data.error || 'Failed to mark notification as seen');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while marking notification as seen';

      setError(errorMessage);
      console.error('NotificationContext: markAsSeen error:', err);
      return false;
    }
  }, [getNotificationStats, getAllNotifications]);

  /**
   * Marks a notification as unseen
   * Calls PATCH /notification/:id/unseen
   * Refetches notifications and stats after success
   *
   * @param id - The notification ID
   * @returns Promise<boolean> - true if update succeeded, false otherwise
   */
  const markAsUnseen = useCallback(async (id: string): Promise<boolean> => {
    try {
      const response = await axiosInstance.patch<NotificationApiResponse>(`/${id}/unseen`);

      if (response.data.success && response.data.data && !Array.isArray(response.data.data)) {
        const updatedNotification = response.data.data as Notification;
        // Update local state
        setNotifications(prev =>
          prev.map(n => n.id === id ? updatedNotification : n)
        );
        // Refresh stats and notifications
        await Promise.all([
          getNotificationStats(),
          getAllNotifications()
        ]);
        return true;
      } else {
        throw new Error(response.data.error || 'Failed to mark notification as unseen');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while marking notification as unseen';

      setError(errorMessage);
      console.error('NotificationContext: markAsUnseen error:', err);
      return false;
    }
  }, [getNotificationStats, getAllNotifications]);

  /**
   * Marks all notifications as seen
   * Calls PATCH /notification/mark-all-seen
   * Refetches notifications and stats after success
   *
   * @returns Promise<number> - Number of notifications marked as seen
   */
  const markAllAsSeen = useCallback(async (): Promise<number> => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosInstance.patch<NotificationApiResponse>('/mark-all-seen');

      if (response.data.success && response.data.data) {
        const data = response.data.data as { updatedCount: number };
        // Update local state - mark all as seen
        setNotifications(prev =>
          prev.map(n => ({ ...n, is_seen: true }))
        );
        // Refresh stats and notifications
        await Promise.all([
          getNotificationStats(),
          getAllNotifications()
        ]);
        return data.updatedCount;
      } else {
        throw new Error(response.data.error || 'Failed to mark all notifications as seen');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while marking all notifications as seen';

      setError(errorMessage);
      console.error('NotificationContext: markAllAsSeen error:', err);
      return 0;
    } finally {
      setLoading(false);
    }
  }, [getNotificationStats, getAllNotifications]);

  /**
   * Clears the current error state
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Gets the count of unread notifications
   */
  const getUnreadCount = useCallback(() => {
    return notifications.filter(n => !n.is_seen).length;
  }, [notifications]);

  /**
   * Auto-fetch notifications on mount if autoFetch is enabled
   */
  useEffect(() => {
    if (autoFetch && isAuthenticated) {
      getAllNotifications();
      getNotificationStats();
    }
  }, [autoFetch, isAuthenticated, getAllNotifications, getNotificationStats]);

  /**
   * Real-time polling: Fetch notifications every 10 seconds
   * This provides near real-time updates without WebSocket complexity
   */
  useEffect(() => {
    if (!isAuthenticated) return;

    // Set up polling interval
    const pollingInterval = setInterval(() => {
      // Fetch both notifications and stats silently (without loading state)
      Promise.all([
        axiosInstance.get<NotificationApiResponse>('').then(response => {
          if (response.data.success && Array.isArray(response.data.data)) {
            setNotifications(response.data.data);
          }
        }),
        axiosInstance.get<NotificationApiResponse>('/stats').then(response => {
          if (response.data.success && response.data.data) {
            setStats(response.data.data as NotificationStats);
          }
        })
      ]).catch(err => {
        // Silent fail - don't show errors for background polling
        console.error('NotificationContext: Background polling error:', err);
      });
    }, 10000); // Poll every 10 seconds

    // Cleanup interval on unmount
    return () => clearInterval(pollingInterval);
  }, [isAuthenticated]);

  const value: NotificationContextState = {
    notifications,
    loading,
    error,
    stats,
    getAllNotifications,
    getNotificationStats,
    searchNotifications,
    deleteNotification,
    markAsSeen,
    markAsUnseen,
    markAllAsSeen,
    clearError,
    getUnreadCount,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

// ============================================================================
// CUSTOM HOOK
// ============================================================================

/**
 * Custom hook to access NotificationContext
 *
 * @throws Error if used outside of NotificationProvider
 *
 * @example
 * // In any component:
 * import { useNotifications } from '@/contexts/NotificationContext';
 *
 * function NotificationsList() {
 *   const {
 *     notifications,
 *     loading,
 *     error,
 *     markAsSeen,
 *     deleteNotification
 *   } = useNotifications();
 *
 *   if (loading) return <div>Loading...</div>;
 *   if (error) return <div>Error: {error}</div>;
 *
 *   return (
 *     <div>
 *       {notifications.map((notification) => (
 *         <div key={notification.id}>
 *           <h3>{notification.title}</h3>
 *           <p>{notification.message}</p>
 *           <button onClick={() => markAsSeen(notification.id)}>
 *             Mark as Read
 *           </button>
 *           <button onClick={() => deleteNotification(notification.id)}>
 *             Delete
 *           </button>
 *         </div>
 *       ))}
 *     </div>
 *   );
 * }
 *
 * @example
 * // Filtering notifications:
 * function UnreadNotifications() {
 *   const { getAllNotifications, notifications } = useNotifications();
 *
 *   useEffect(() => {
 *     // Fetch only unseen notifications
 *     getAllNotifications({ seen: false, limit: 10 });
 *   }, []);
 *
 *   return <div>{notifications.length} unread notifications</div>;
 * }
 *
 * @example
 * // Using notification stats:
 * function NotificationBadge() {
 *   const { stats, getUnreadCount } = useNotifications();
 *
 *   return (
 *     <div>
 *       <span>Unread: {stats?.unseen || getUnreadCount()}</span>
 *     </div>
 *   );
 * }
 */
export function useNotifications(): NotificationContextState {
  const context = useContext(NotificationContext);

  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }

  return context;
}

// ============================================================================
// EXPORT TYPES FOR EXTERNAL USE
// ============================================================================

export type { NotificationApiResponse };
