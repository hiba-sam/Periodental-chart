# 🩺 MyPrescription – Système de Gestion Médicale

Une application web moderne de gestion médicale développée avec Next.js 14, permettant aux médecins de gérer leurs patients, leurs rendez-vous et de générer des ordonnances électroniques.

## ⚙️ Fonctionnalités

### 📊 Tableau de bord
- Statistiques en temps réel
- Graphiques des revenus et du nombre de patients
- Vue d'ensemble des rendez-vous du jour
- Gestion des patients récents et anciens

### 👥 Gestion des patients
- Liste complète avec recherche et filtres
- Fiches détaillées pour chaque patient
- Historique médical
- Ajout / modification des informations patients

### 📅 Calendrier de rendez-vous
- Calendrier interactif (vue par jour/semaine/mois)
- Planification facile des consultations
- Notifications de rappel

### 💊 Prescriptions électroniques
- Génération automatique de fichiers PDF
- Modèle HTML personnalisable
- Système de secours fiable
- QR codes intégrés pour vérification
- Logo du cabinet/médecin intégré

### 🔐 Intégration Firebase
- Authentification sécurisée
- Base de données Firestore
- Stockage de fichiers
- Synchronisation en temps réel (Realtime Database)

## 🧪 Technologies utilisées

- **Frontend** : Next.js 14, React, TypeScript
- **Style** : Tailwind CSS
- **Base de données** : Firebase Firestore
- **Authentification** : Firebase Auth
- **PDF** : jsPDF, html2canvas
- **Graphiques** : Chart.js, react-chartjs-2
- **Icônes** : Heroicons

## Structure du Projet

```
mypresc-nextjs/
u251cu2500u2500 public/
u2502   u2514u2500u2500 images/
u2502       u2514u2500u2500 doctor-avatar.jpg
u251cu2500u2500 src/
u2502   u251cu2500u2500 app/
u2502   u2502   u251cu2500u2500 globals.css
u2502   u2502   u251cu2500u2500 layout.tsx
u2502   u2502   u2514u2500u2500 page.tsx
u2502   u2514u2500u2500 components/
u2502       u251cu2500u2500 Header.tsx
u2502       u251cu2500u2500 Sidebar.tsx
u2502       u2514u2500u2500 dashboard/
u2502           u251cu2500u2500 AppointmentsToday.tsx
u2502           u251cu2500u2500 AppointmentDetails.tsx
u2502           u251cu2500u2500 RecentPatients.tsx
u2502           u251cu2500u2500 PaymentChart.tsx
u2502           u251cu2500u2500 NewPatientsStats.tsx
u2502           u251cu2500u2500 OldPatientsStats.tsx
u2502           u2514u2500u2500 UpcomingAppointments.tsx
u251cu2500u2500 package.json
u2514u2500u2500 README.md
```

## 🚀 Installation

### 1. Cloner le dépôt
```bash
git clone https://github.com/hicham400/mypresc-nextjs.git
cd mypresc-nextjs
```

### 2. Installer les dépendances
```bash
npm install
```

### 3. Configurer Firebase
Créer un projet Firebase
Copier les informations de configuration dans `.env.local` :
```env
NEXT_PUBLIC_FIREBASE_API_KEY=your_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_app_id
```

### 4. Démarrer le serveur de développement
```bash
npm run dev
```

### 5. Accéder à l'application
http://localhost:3000

## 🛠️ Personnalisation

### 👤 Remplacer l'avatar du médecin
Remplace l'image `public/images/doctor-avatar.jpg` par celle de ton choix.

### 📊 Modifier les données graphiques
Les données affichées dans les graphiques se trouvent dans :
- `PaymentChart.tsx`
- `NewPatientsStats.tsx`
- `OldPatientsStats.tsx`

### 🎨 Modifier les couleurs
Les couleurs principales sont définies dans `tailwind.config.ts` :
```ts
theme: {
  extend: {
    colors: {
      primary: {
        DEFAULT: '#1a237e', // Bleu profond pour la sidebar
        light: '#4a69ff',
      },
      // ... autres couleurs
    },
  },
},
```

## 🔗 Intégration avec un backend
Tu peux intégrer cette interface à une API via les API Routes de Next.js ou en te connectant directement à un backend externe.

Exemple d'appel API :
```typescript
import { useEffect, useState } from 'react';

export default function PatientsList() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPatients() {
      try {
        const response = await fetch('/api/patients');
        const data = await response.json();
        setPatients(data);
      } catch (error) {
        console.error("Erreur lors de la récupération des patients :", error);
      } finally {
        setLoading(false);
      }
    }

    fetchPatients();
  }, []);

  if (loading) return <div>Chargement...</div>;

  return (
    <div>
      {/* Afficher les patients */}
    </div>
  );
}
```

## 📦 Déploiement
Le projet peut être déployé facilement sur :
- **Vercel** (recommandé pour Next.js)
- **Netlify**
- Ou tout autre hébergeur compatible avec Node.js / Next.js
