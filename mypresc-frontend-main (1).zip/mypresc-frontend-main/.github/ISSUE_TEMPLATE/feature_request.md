---
name: 📌 Nouvelle fonctionnalité
about: Suggérer une nouvelle fonctionnalité ou une amélioration
title: "[Feature] - "
labels: enhancement
assignees: ''

---

## 📝 Description
Décris ici la fonctionnalité ou l'amélioration souhaitée.

## 🎯 Objectif
Quel est le but de cette fonctionnalité pour l'utilisateur final ?

## ✅ Critères d'acceptation
- [ ] Fonction testable
- [ ] Visible sur interface (si applicable)
- [ ] Ne casse pas le reste du projet

## 🧪 Étapes de test
Décris comment valider que la fonctionnalité fonctionne bien.

## 📎 Fichiers ou maquettes
Ajoute ici des captures, des liens vers Figma, etc. si tu en as.
