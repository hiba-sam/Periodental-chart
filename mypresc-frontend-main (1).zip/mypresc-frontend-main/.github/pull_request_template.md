## 🔧 Description de la modification
<!-- Explique clairement ce qui a été ajouté, modifié ou corrigé -->

## ✅ Tâches réalisées
- [ ] Fonctionnalité développée
- [ ] Tests manuels effectués
- [ ] Intégration avec d'autres parties du projet vérifiée
- [ ] Nettoyage du code effectué
- [ ] Documentation mise à jour (si nécessaire)
- [ ] Variables d'environnement documentées (si nouvelles)

## 📂 Fichiers modifiés
<!-- Liste rapide des fichiers concernés -->
- 
- 
- 

## 👀 Comportement attendu
<!-- Explique comment tester la modification -->
1. Lancer le projet localement (`npm run dev`)
2. Naviguer vers la page concernée
3. Vérifier que tout fonctionne comme prévu
4. Tester sur différentes tailles d'écran (responsive)

## 🧪 Tests effectués
<!-- Décris les tests que tu as effectués -->
- [ ] Tests sur desktop
- [ ] Tests sur mobile
- [ ] Tests des fonctionnalités principales
- [ ] Tests d'intégration Firebase (si applicable)
- [ ] Tests de génération PDF (si applicable)

## 📸 Capture d'écran (si UI modifiée)
<!-- Insère une image ou un lien vers une maquette Figma si applicable -->

## 🔗 Liens utiles
<!-- Si applicable, ajoute des liens vers la documentation, issues, etc. -->
- Closes #[numéro d'issue]
- Related to #[numéro d'issue]

## ❗ Commentaires ou points d'attention
<!-- Signale s'il reste des points à discuter ou valider avant merge -->

## 🔄 Type de modification
- [ ] 🐛 Bug fix (correction d'un problème)
- [ ] ✨ Nouvelle fonctionnalité
- [ ] 💄 Amélioration UI/UX
- [ ] ⚡ Amélioration des performances
- [ ] 📝 Documentation
- [ ] 🔧 Configuration/Build
- [ ] ♻️ Refactoring
- [ ] 🚀 Déploiement

---
**Merci pour votre contribution au projet MyPrescription ! 🏥**
