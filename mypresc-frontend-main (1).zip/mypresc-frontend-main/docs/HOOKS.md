# Custom Hooks Documentation

## Overview

This document describes the custom React hooks used in the MyPresc frontend. Hooks are organized by feature module.

---

## Patient Hooks

### `usePatientDetail`

**Location:** `@/features/patients/hooks/usePatientDetail`

Main hook for the patient detail page. Manages all patient-related state and operations.

```typescript
const {
  // Patient data
  patient,
  patientId,
  patientName,
  
  // Loading states
  isLoading,
  error,
  
  // Access control
  accessControl,
  onConfirmAccess,
  onDenyAccess,
  
  // Privacy choice
  privacyChoice,
  onPrivacyChoice,
  
  // History modal
  history,
  
  // Share modal
  showShareModal,
  setShowShareModal,
  
  // NIN popup
  showNinPopup,
  onSkipNin,
  
  // Utils
  router,
  t,
} = usePatientDetail({ patientId: string });
```

---

## Invoice Hooks

### `useInvoices`

**Location:** `@/features/invoices/hooks/useInvoices`

Fetches invoices for a patient using React Query.

```typescript
const {
  data: invoices,
  isLoading,
  error,
  refetch,
} = useInvoices(patientId: string);
```

### `useInvoiceMutations`

**Location:** `@/features/invoices/hooks/useInvoiceMutations`

Provides mutation functions for invoice operations.

```typescript
const {
  createInvoice,
  updateInvoiceStatus,
  addPayment,
  distributePayment,
  deleteInvoice,
  isCreating,
  isDeleting,
} = useInvoiceMutations(patientId: string);
```

### `useTodayInvoices`

**Location:** `@/features/invoices/hooks/useTodayInvoices`

Fetches today's invoices for the dashboard.

```typescript
const {
  data: todayInvoices,
  isLoading,
  stats,
} = useTodayInvoices();
```

---

## Prescription Hooks

### `usePrescriptions`

**Location:** `@/features/prescriptions/hooks/usePrescriptions`

Fetches prescriptions for a patient.

```typescript
const {
  data: prescriptions,
  isLoading,
  refetch,
} = usePrescriptions(patientId: string, filter?: 'all' | 'mine');
```

---

## Medical Report Hooks

### `useMedicalReports`

**Location:** `@/features/medical-reports/hooks/useMedicalReports`

Fetches medical reports for a patient.

```typescript
const {
  data: reports,
  isLoading,
  refetch,
} = useMedicalReports(patientId: string, filter?: 'all' | 'mine');
```

---

## Common Patterns

### Using with React Query

All data fetching hooks use React Query for caching and background refetching:

```typescript
// Hooks automatically cache data
const { data } = useInvoices(patientId);

// Manual refetch when needed
const { refetch } = useInvoices(patientId);
await refetch();
```

### Query Keys

Each hook uses structured query keys for cache invalidation:

```typescript
// Invoice keys
['invoices', patientId]
['invoices', 'today']

// Prescription keys
['prescriptions', patientId]

// Medical report keys
['medical-reports', patientId]
```

### Error Handling

All hooks return error states that can be used for UI:

```typescript
const { error, isLoading } = useInvoices(patientId);

if (isLoading) return <ListSkeleton />;
if (error) return <ErrorMessage error={error} />;
```
