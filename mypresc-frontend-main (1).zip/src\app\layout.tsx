import React from 'react';
import './globals.css';

export const metadata = {
  title: 'Périodontie - Test Integration',
  description: 'Validation du module parodontal optimisé',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr text-left" dir="ltr">
      <body className="antialiased bg-gray-50 text-gray-900">
        {children}
      </body>
    </html>
  );
}