'use client';

import ParodontalStatusSection from '@/app/patients/[id]/_components/ParodontalStatusSection';

export default function TestPerioPage() {
  // Use a dummy patient ID for testing
  const patientId = "test-patient-001";
  const patientName = "Patient de Test";

  return (
    <main className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-cyan-900 p-8 text-white">
          <h1 className="text-3xl font-black uppercase tracking-tighter">Module Parodontal - Test d'Intégration</h1>
          <p className="text-cyan-200 mt-2 font-medium">Validation clinique des calculs CAL et du Dashboard KPI</p>
        </div>
        
        <div className="p-8">
          <ParodontalStatusSection 
            patientId={patientId} 
            patientName={patientName} 
          />
        </div>
      </div>
      
      <footer className="mt-12 text-center text-gray-400 text-sm font-medium">
        Expertisé par Antigravity - Solution Parodontale Optimisée
      </footer>
    </main>
  );
}
