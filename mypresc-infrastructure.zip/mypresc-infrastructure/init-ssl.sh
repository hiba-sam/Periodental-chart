#!/bin/bash
# ============================================
# MyPrescription - SSL Certificate Setup
# Usage: ./init-ssl.sh <domain> <email>
# ============================================

set -e

DOMAIN="${1:-app.mypresc.dz}"
EMAIL="${2:-admin@mypresc.dz}"

echo "============================================"
echo "   SSL Certificate Setup for $DOMAIN"
echo "============================================"

# Create nginx directories
mkdir -p nginx/ssl nginx/conf.d nginx/logs

# Create temporary nginx config for ACME challenge
cat > nginx/conf.d/default.conf << EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    location / {
        return 301 https://\$host\$request_uri;
    }
}
EOF

# Start nginx temporarily
echo "[1/4] Starting nginx for ACME challenge..."
docker compose up -d nginx

# Wait for nginx
sleep 5

# Request certificate
echo "[2/4] Requesting SSL certificate..."
docker compose run --rm certbot certonly \
    --webroot \
    --webroot-path=/var/www/certbot \
    --email $EMAIL \
    --agree-tos \
    --no-eff-email \
    -d $DOMAIN \
    -d www.$DOMAIN

# Update nginx config with SSL
echo "[3/4] Updating nginx configuration..."
sed -i "s/\${DOMAIN}/$DOMAIN/g" nginx/nginx.conf

# Restart nginx with SSL
echo "[4/4] Restarting nginx with SSL..."
docker compose restart nginx

echo ""
echo "============================================"
echo "   SSL Certificate Setup Complete!"
echo "============================================"
echo ""
echo "Certificate will auto-renew via certbot container."
echo ""
