#!/bin/bash
# ============================================
# MyPrescription - Production Deployment Script
# Usage: ./deploy.sh [--staging] [--build] [--pull]
# ============================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
COMPOSE_FILE="docker-compose.yml"
ENV_FILE=".env"
BACKUP_DIR="$SCRIPT_DIR/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Parse arguments
STAGING=false
BUILD=false
PULL=false

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --staging) STAGING=true; COMPOSE_FILE="docker-compose.staging.yml" ;;
        --build) BUILD=true ;;
        --pull) PULL=true ;;
        *) echo "Unknown parameter: $1"; exit 1 ;;
    esac
    shift
done

echo -e "${BLUE}============================================${NC}"
echo -e "${BLUE}   MyPrescription Deployment Script${NC}"
echo -e "${BLUE}============================================${NC}"

# Check requirements
check_requirements() {
    echo -e "${YELLOW}[1/7] Checking requirements...${NC}"
    
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}ERROR: Docker is not installed${NC}"
        exit 1
    fi
    
    if ! command -v docker compose &> /dev/null; then
        echo -e "${RED}ERROR: Docker Compose is not installed${NC}"
        exit 1
    fi
    
    if [ ! -f "$SCRIPT_DIR/$ENV_FILE" ]; then
        echo -e "${RED}ERROR: $ENV_FILE not found. Copy .env.example to .env${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}✓ Requirements OK${NC}"
}

# Backup current deployment
backup_deployment() {
    echo -e "${YELLOW}[2/7] Creating backup...${NC}"
    
    mkdir -p "$BACKUP_DIR"
    
    # Save current image tags
    docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" config > "$BACKUP_DIR/compose_$TIMESTAMP.yml" 2>/dev/null || true
    
    # Backup database (if running)
    if docker ps --format '{{.Names}}' | grep -q "mypresc.*db"; then
        echo -e "${YELLOW}   Backing up database...${NC}"
        docker exec mypresc-db pg_dump -U mypresc_user mypresc_db > "$BACKUP_DIR/db_$TIMESTAMP.sql" 2>/dev/null || true
    fi
    
    echo -e "${GREEN}✓ Backup created: $BACKUP_DIR/*_$TIMESTAMP.*${NC}"
}

# Pull latest changes and images
pull_changes() {
    if [ "$PULL" = true ]; then
        echo -e "${YELLOW}[3/7] Pulling latest changes...${NC}"
        
        # Pull infrastructure changes
        git pull
        
        # Pull backend changes
        if [ -d "../mypresc-backend" ]; then
            echo -e "${YELLOW}   Pulling backend...${NC}"
            (cd ../mypresc-backend && git pull)
        else
            echo -e "${RED}WARNING: ../mypresc-backend not found${NC}"
        fi
        
        # Pull frontend changes
        if [ -d "../mypresc-frontend" ]; then
            echo -e "${YELLOW}   Pulling frontend...${NC}"
            (cd ../mypresc-frontend && git pull)
        else
            echo -e "${RED}WARNING: ../mypresc-frontend not found${NC}"
        fi
        
        echo -e "${YELLOW}   Pulling docker images...${NC}"
        docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" pull
        echo -e "${GREEN}✓ Changes and images pulled${NC}"
    else
        echo -e "${YELLOW}[3/7] Skipping pull (use --pull to enable)${NC}"
    fi
}

# Build images
build_images() {
    if [ "$BUILD" = true ]; then
        echo -e "${YELLOW}[4/7] Building images...${NC}"
        docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" build --no-cache
        echo -e "${GREEN}✓ Images built${NC}"
    else
        echo -e "${YELLOW}[4/7] Skipping build (use --build to enable)${NC}"
    fi
}

# Stop current containers
stop_containers() {
    echo -e "${YELLOW}[5/7] Stopping current containers...${NC}"
    docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" down --remove-orphans 2>/dev/null || true
    echo -e "${GREEN}✓ Containers stopped${NC}"
}

# Start new containers
start_containers() {
    echo -e "${YELLOW}[6/7] Starting containers...${NC}"
    
    cd "$SCRIPT_DIR"
    docker compose -f "$COMPOSE_FILE" --env-file "$ENV_FILE" up -d
    
    echo -e "${GREEN}✓ Containers started${NC}"
}

# Health check
health_check() {
    echo -e "${YELLOW}[7/7] Running health checks...${NC}"
    
    # Wait for services to start
    sleep 10
    
    # Check all containers are running
    RUNNING=$(docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" ps --status running -q | wc -l)
    EXPECTED=4  # postgres, backend, frontend, nginx
    
    if [ "$RUNNING" -lt "$EXPECTED" ]; then
        echo -e "${RED}WARNING: Only $RUNNING/$EXPECTED containers running${NC}"
        docker compose -f "$SCRIPT_DIR/$COMPOSE_FILE" ps
    else
        echo -e "${GREEN}✓ All $RUNNING containers running${NC}"
    fi
    
    # Check backend health
    echo -e "${YELLOW}   Checking backend health...${NC}"
    for i in {1..30}; do
        if curl -sf http://localhost:3333/health > /dev/null 2>&1; then
            echo -e "${GREEN}   ✓ Backend healthy${NC}"
            break
        fi
        if [ $i -eq 30 ]; then
            echo -e "${RED}   ✗ Backend health check failed${NC}"
        fi
        sleep 2
    done
    
    # Check nginx
    echo -e "${YELLOW}   Checking nginx...${NC}"
    if curl -sf http://localhost > /dev/null 2>&1; then
        echo -e "${GREEN}   ✓ Nginx responding${NC}"
    else
        echo -e "${RED}   ✗ Nginx not responding${NC}"
    fi
}

# Main execution
main() {
    echo ""
    if [ "$STAGING" = true ]; then
        echo -e "${YELLOW}Mode: STAGING${NC}"
    else
        echo -e "${GREEN}Mode: PRODUCTION${NC}"
    fi
    echo ""
    
    check_requirements
    backup_deployment
    pull_changes
    build_images
    stop_containers
    start_containers
    health_check
    
    echo ""
    echo -e "${GREEN}============================================${NC}"
    echo -e "${GREEN}   Deployment Complete!${NC}"
    echo -e "${GREEN}============================================${NC}"
    echo ""
    echo -e "View logs:    ${BLUE}docker compose -f $COMPOSE_FILE logs -f${NC}"
    echo -e "View status:  ${BLUE}docker compose -f $COMPOSE_FILE ps${NC}"
    echo -e "Rollback:     ${BLUE}./rollback.sh $TIMESTAMP${NC}"
    echo ""
}

main "$@"
