// This file configures the initialization of Sentry on the server.
// The config you add here will be used whenever the server handles a request.
// https://docs.sentry.io/platforms/javascript/guides/nextjs/

import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: "https://f9276d5456a28af37e383c0c6c836b30@o4510726592004096.ingest.de.sentry.io/4510726594887760",

  // Define how likely traces are sampled. Adjust this value in production, or use tracesSampler for greater control.
  tracesSampleRate: 1,

  // Enable logs to be sent to Sentry
  enableLogs: true,

  // Enable sending user PII (Personally Identifiable Information)
  // https://docs.sentry.io/platforms/javascript/guides/nextjs/configuration/options/#sendDefaultPii
  sendDefaultPii: true,

  // Filter out null errors and malformed requests
  beforeSend(event, hint) {
    const error = hint.originalException;
    
    // Skip null errors (malformed requests causing Next.js internal errors)
    if (error === null || error === undefined) {
      return null;
    }
    
    // Skip errors from malicious/scanner requests
    if (event.request?.headers?.['content-type']?.includes('multipart/form-data')) {
      const url = event.request?.url || '';
      // Block multipart errors on non-upload routes
      if (url.endsWith('/') || url.includes('login')) {
        return null;
      }
    }
    
    return event;
  },
});
