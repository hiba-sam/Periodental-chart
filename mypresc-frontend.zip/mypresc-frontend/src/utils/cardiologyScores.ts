// ============================================
// CARDIOLOGY SCORE CALCULATIONS — Pure functions
// Mirrors backend logic for real-time frontend display
// Backend recalculates on save (authoritative)
// ============================================

export interface CardiologyFormData {
    // Patient info
    patient_age?: number | null;
    patient_sex?: string | null;
    patient_weight?: number | null;
    patient_height?: number | null;

    // Clinical exam
    heart_rate?: number | null;
    systolic_bp?: number | null;
    diastolic_bp?: number | null;
    spo2?: number | null;
    auscultation?: string | null;
    lower_limb_edema?: string | null;
    nyha_class?: number | null;
    chest_pain?: string | null;
    heart_failure_signs?: string[] | null;

    // History
    has_hta?: boolean;
    has_diabetes?: boolean;
    has_diabetes_insulin?: boolean;
    has_afib?: boolean;
    has_mi?: boolean;
    has_stroke?: boolean;
    has_heart_failure?: boolean;
    has_arteriopathy?: boolean;
    has_valvulopathy?: boolean;
    has_active_smoking?: boolean;
    has_stopped_smoking?: boolean;
    has_dyslipidemia?: boolean;
    has_endocarditis?: boolean;
    has_prior_cardiac_surgery?: boolean;
    has_chronic_lung_disease?: boolean;
    has_reduced_mobility?: boolean;
    has_hepatic_anomaly?: boolean;
    has_bleeding_history?: boolean;
    has_nsaid_antiplatelet?: boolean;
    has_excessive_alcohol?: boolean;
    known_lvef?: number | null;
    creatinine?: number | null;

    // Exams - ECG
    ecg_result?: string | null;
    ecg_detail?: string | null;
    ecg_st_deviation?: boolean;
    // Exams - Echo
    echo_lvef?: number | null;
    echo_lvedd?: number | null;
    echo_la_size?: number | null;
    echo_valvulopathies?: string[] | null;
    echo_pulmonary_htn?: number | null;
    echo_lvesd?: number | null;
    echo_ivs_thickness?: number | null;
    echo_pw_thickness?: number | null;
    echo_tapse?: number | null;
    echo_wall_motion?: string | null;
    echo_wall_motion_detail?: string | null;
    echo_diastolic_function?: string | null;
    echo_pericardial_effusion?: string | null;
    echo_valvulopathy_severity?: Record<string, string> | null;
    bio_bnp?: number | null;
    bio_troponin?: number | null;
    bio_ldl?: number | null;
    bio_hdl?: number | null;
    bio_total_cholesterol?: number | null;
    bio_triglycerides?: number | null;
    bio_hba1c?: number | null;
    bio_creatinine?: number | null;
    bio_inr?: number | null;

    // Pre-op
    preop_critical_state?: boolean;
    preop_urgency?: string | null;
    preop_surgery_type?: string | null;
    preop_thoracic_aorta?: boolean;
    preop_dialysis?: boolean;

    // Notes
    free_notes?: string | null;
}

export interface ScoreResult {
    value: number | null;
    label: string;
    maxValue?: number | string;
    level: 'low' | 'moderate' | 'high' | 'very_high' | null;
    color: string; // tailwind color class
    missingFields: string[];
    details: ScoreDetail[];
}

export interface ScoreDetail {
    criterion: string;
    points: number;
    present: boolean;
}

// ============================================
// ROBUST TYPE HELPERS — handle pg/Bun string coercion
// PostgreSQL via pg under Bun may return 't'/'f' strings
// instead of true/false for BOOLEAN columns.
// ============================================
function toBool(v: any): boolean {
    if (typeof v === 'boolean') return v;
    if (typeof v === 'string') return v === 'true' || v === 't' || v === '1';
    if (typeof v === 'number') return v !== 0;
    return false;
}

function toNum(v: any): number | null {
    if (v == null) return null;
    if (typeof v === 'number') return v;
    const n = Number(v);
    return isNaN(n) ? null : n;
}

// ============================================
// 1. CHA₂DS₂-VASc
// ============================================
export function calcCHA2DS2VASc(d: CardiologyFormData): ScoreResult {
    const age = toNum(d.patient_age);
    const missing: string[] = [];
    if (age == null) missing.push('Âge');
    if (!d.patient_sex) missing.push('Sexe');

    if (missing.length > 0) {
        return { value: null, label: 'CHA₂DS₂-VASc', maxValue: 9, level: null, color: 'gray', missingFields: missing, details: [] };
    }

    const details: ScoreDetail[] = [];
    let score = 0;

    const add = (criterion: string, pts: number, present: boolean) => {
        details.push({ criterion, points: pts, present });
        if (present) score += pts;
    };

    add('Insuffisance cardiaque / Dysfonction VG', 1, toBool(d.has_heart_failure));
    add('Hypertension artérielle', 1, toBool(d.has_hta));
    add('Âge ≥ 75 ans', 2, age! >= 75);
    add('Diabète', 1, toBool(d.has_diabetes));
    add('AVC / AIT antérieur', 2, toBool(d.has_stroke));
    add('Maladie vasculaire', 1, toBool(d.has_arteriopathy));
    add('Âge 65-74 ans', 1, age! >= 65 && age! < 75);
    add('Sexe féminin', 1, d.patient_sex === 'femme');

    let level: ScoreResult['level'] = 'low';
    let color = 'green';
    if (score >= 2) { level = 'high'; color = 'red'; }
    else if (score === 1) { level = 'moderate'; color = 'yellow'; }

    return { value: score, label: 'CHA₂DS₂-VASc', maxValue: 9, level, color, missingFields: [], details };
}

// ============================================
// 2. HAS-BLED
// ============================================
export function calcHASBLED(d: CardiologyFormData): ScoreResult {
    const missing: string[] = [];
    if (d.patient_age == null) missing.push('Âge');

    if (missing.length > 0) {
        return { value: null, label: 'HAS-BLED', maxValue: 9, level: null, color: 'gray', missingFields: missing, details: [] };
    }

    const details: ScoreDetail[] = [];
    let score = 0;

    const add = (criterion: string, pts: number, present: boolean) => {
        details.push({ criterion, points: pts, present });
        if (present) score += pts;
    };

    // H - Hypertension (PAS > 160)
    add('HTA non contrôlée (PAS > 160)', 1, toBool(d.has_hta) && (toNum(d.systolic_bp) ?? 0) > 160);
    // A - Abnormal renal function (créat > 200)
    const creat = toNum(d.bio_creatinine) ?? toNum(d.creatinine);
    add('Anomalie rénale (créat > 200 µmol/L)', 1, (creat ?? 0) > 200);
    // A - Abnormal liver function
    add('Anomalie hépatique', 1, toBool(d.has_hepatic_anomaly));
    // S - Stroke
    add('AVC antérieur', 1, toBool(d.has_stroke));
    // B - Bleeding history
    add('Antécédent hémorragique', 1, toBool(d.has_bleeding_history));
    // L - Labile INR
    add('INR labile', 1, d.bio_inr != null && (d.bio_inr < 2 || d.bio_inr > 3));
    // E - Elderly
    add('Âge > 65 ans', 1, (d.patient_age ?? 0) > 65);
    // D - Drugs (NSAIDs / antiplatelets)
    add('Médicaments (AINS / antiagrégants)', 1, toBool(d.has_nsaid_antiplatelet));
    // D - Alcohol
    add('Alcool excessif', 1, toBool(d.has_excessive_alcohol));

    let level: ScoreResult['level'] = 'low';
    let color = 'green';
    if (score >= 3) { level = 'high'; color = 'red'; }
    else if (score >= 1) { level = 'moderate'; color = 'yellow'; }

    return { value: score, label: 'HAS-BLED', maxValue: 9, level, color, missingFields: [], details };
}

// ============================================
// 3. GRACE
// ============================================
export function calcGRACE(d: CardiologyFormData): ScoreResult {
    const missing: string[] = [];
    if (d.patient_age == null) missing.push('Âge');
    if (d.heart_rate == null) missing.push('FC');
    if (d.systolic_bp == null) missing.push('PAS');

    if (missing.length > 0) {
        return { value: null, label: 'GRACE', maxValue: '> 140', level: null, color: 'gray', missingFields: missing, details: [] };
    }

    let score = 0;
    const details: ScoreDetail[] = [];

    // Age points
    const age = d.patient_age!;
    let agePts = 0;
    if (age < 30) agePts = 0;
    else if (age < 40) agePts = 8;
    else if (age < 50) agePts = 25;
    else if (age < 60) agePts = 41;
    else if (age < 70) agePts = 58;
    else if (age < 80) agePts = 75;
    else if (age < 90) agePts = 91;
    else agePts = 100;
    details.push({ criterion: `Âge (${age} ans)`, points: agePts, present: true });
    score += agePts;

    // Heart rate
    const hr = d.heart_rate!;
    let hrPts = 0;
    if (hr < 50) hrPts = 0;
    else if (hr < 70) hrPts = 3;
    else if (hr < 90) hrPts = 9;
    else if (hr < 110) hrPts = 15;
    else if (hr < 150) hrPts = 24;
    else if (hr < 200) hrPts = 38;
    else hrPts = 46;
    details.push({ criterion: `FC (${hr} bpm)`, points: hrPts, present: true });
    score += hrPts;

    // Systolic BP (inverse)
    const sbp = d.systolic_bp!;
    let sbpPts = 0;
    if (sbp < 80) sbpPts = 58;
    else if (sbp < 100) sbpPts = 53;
    else if (sbp < 120) sbpPts = 43;
    else if (sbp < 140) sbpPts = 34;
    else if (sbp < 160) sbpPts = 24;
    else if (sbp < 200) sbpPts = 10;
    else sbpPts = 0;
    details.push({ criterion: `PAS (${sbp} mmHg)`, points: sbpPts, present: true });
    score += sbpPts;

    // Creatinine
    const creat = d.bio_creatinine ?? d.creatinine;
    if (creat != null) {
        const creatMgDl = creat / 88.4;
        let creatPts = 0;
        if (creatMgDl < 0.4) creatPts = 1;
        else if (creatMgDl < 0.8) creatPts = 4;
        else if (creatMgDl < 1.2) creatPts = 7;
        else if (creatMgDl < 1.6) creatPts = 10;
        else if (creatMgDl < 2.0) creatPts = 13;
        else if (creatMgDl < 4.0) creatPts = 21;
        else creatPts = 28;
        details.push({ criterion: `Créatinine (${creat} µmol/L)`, points: creatPts, present: true });
        score += creatPts;
    }

    // Killip / NYHA
    const killip = d.nyha_class ?? 1;
    let killipPts = 0;
    if (killip === 2) killipPts = 20;
    else if (killip === 3) killipPts = 39;
    else if (killip === 4) killipPts = 59;
    details.push({ criterion: `Classe Killip/NYHA (${killip})`, points: killipPts, present: killip > 1 });
    score += killipPts;

    if (toBool(d.ecg_st_deviation)) {
        details.push({ criterion: 'Déviation ST', points: 28, present: true });
        score += 28;
    }
    if (d.bio_troponin && (toNum(d.bio_troponin) ?? 0) > 0) {
        details.push({ criterion: 'Troponine positive', points: 14, present: true });
        score += 14;
    }

    let level: ScoreResult['level'] = 'low';
    let color = 'green';
    if (score > 140) { level = 'high'; color = 'red'; }
    else if (score > 108) { level = 'moderate'; color = 'orange'; }

    return { value: score, label: 'GRACE', maxValue: '> 140', level, color, missingFields: [], details };
}

// ============================================
// 4. Framingham
// ============================================
export function calcFramingham(d: CardiologyFormData): ScoreResult {
    const missing: string[] = [];
    if (d.patient_age == null) missing.push('Âge');
    if (!d.patient_sex) missing.push('Sexe');
    if (d.bio_total_cholesterol == null) missing.push('Cholestérol total');
    if (d.bio_hdl == null) missing.push('HDL');
    if (d.systolic_bp == null) missing.push('PAS');

    if (missing.length > 0) {
        return { value: null, label: 'Framingham', maxValue: '30%', level: null, color: 'gray', missingFields: missing, details: [] };
    }

    const age = d.patient_age!;
    const isMale = d.patient_sex === 'homme';
    const tc = d.bio_total_cholesterol!;
    const hdl = d.bio_hdl!;
    const sbp = d.systolic_bp!;
    const treated = toBool(d.has_hta);
    const smoker = toBool(d.has_active_smoking);
    const diabetes = toBool(d.has_diabetes);

    const details: ScoreDetail[] = [];
    let points = 0;

    if (isMale) {
        // Age
        let agePts = 0;
        if (age <= 34) agePts = -9;
        else if (age <= 39) agePts = -4;
        else if (age <= 44) agePts = 0;
        else if (age <= 49) agePts = 3;
        else if (age <= 54) agePts = 6;
        else if (age <= 59) agePts = 8;
        else if (age <= 64) agePts = 10;
        else if (age <= 69) agePts = 11;
        else if (age <= 74) agePts = 12;
        else agePts = 13;
        details.push({ criterion: `Âge (${age})`, points: agePts, present: true }); points += agePts;

        let tcPts = 0;
        if (tc < 1.6) tcPts = 0;
        else if (tc < 2.0) tcPts = 4;
        else if (tc < 2.4) tcPts = 7;
        else if (tc < 2.8) tcPts = 9;
        else tcPts = 11;
        details.push({ criterion: `Cholestérol total (${tc} g/L)`, points: tcPts, present: true }); points += tcPts;

        let hdlPts = 0;
        if (hdl >= 0.6) hdlPts = -1;
        else if (hdl >= 0.5) hdlPts = 0;
        else if (hdl >= 0.4) hdlPts = 1;
        else hdlPts = 2;
        details.push({ criterion: `HDL (${hdl} g/L)`, points: hdlPts, present: true }); points += hdlPts;

        let sbpPts = 0;
        if (treated) {
            if (sbp < 120) sbpPts = 0;
            else if (sbp < 130) sbpPts = 1;
            else if (sbp < 140) sbpPts = 2;
            else if (sbp < 160) sbpPts = 2;
            else sbpPts = 3;
        } else {
            if (sbp < 120) sbpPts = 0;
            else if (sbp < 130) sbpPts = 0;
            else if (sbp < 140) sbpPts = 1;
            else if (sbp < 160) sbpPts = 1;
            else sbpPts = 2;
        }
        details.push({ criterion: `PAS (${sbp}, ${treated ? 'traitée' : 'non traitée'})`, points: sbpPts, present: true }); points += sbpPts;

        if (smoker) { details.push({ criterion: 'Tabac actif', points: 8, present: true }); points += 8; }
        if (diabetes) { details.push({ criterion: 'Diabète', points: 5, present: true }); points += 5; }

        const riskTable: Record<number, number> = {
            0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 2, 6: 2, 7: 3, 8: 4,
            9: 5, 10: 6, 11: 8, 12: 10, 13: 12, 14: 16, 15: 20, 16: 25, 17: 30
        };
        const cp = Math.max(0, Math.min(17, points));
        const risk = riskTable[cp] ?? (points < 0 ? 1 : 30);

        let level: ScoreResult['level'] = 'low'; let color = 'green';
        if (risk > 20) { level = 'high'; color = 'red'; }
        else if (risk >= 10) { level = 'moderate'; color = 'orange'; }

        return { value: risk, label: 'Framingham', maxValue: '30%', level, color, missingFields: [], details };
    } else {
        let agePts = 0;
        if (age <= 34) agePts = -7;
        else if (age <= 39) agePts = -3;
        else if (age <= 44) agePts = 0;
        else if (age <= 49) agePts = 3;
        else if (age <= 54) agePts = 6;
        else if (age <= 59) agePts = 8;
        else if (age <= 64) agePts = 10;
        else if (age <= 69) agePts = 12;
        else if (age <= 74) agePts = 14;
        else agePts = 16;
        details.push({ criterion: `Âge (${age})`, points: agePts, present: true }); points += agePts;

        let tcPts = 0;
        if (tc < 1.6) tcPts = 0;
        else if (tc < 2.0) tcPts = 4;
        else if (tc < 2.4) tcPts = 8;
        else if (tc < 2.8) tcPts = 11;
        else tcPts = 13;
        details.push({ criterion: `Cholestérol total (${tc} g/L)`, points: tcPts, present: true }); points += tcPts;

        let hdlPts = 0;
        if (hdl >= 0.6) hdlPts = -1;
        else if (hdl >= 0.5) hdlPts = 0;
        else if (hdl >= 0.4) hdlPts = 1;
        else hdlPts = 2;
        details.push({ criterion: `HDL (${hdl} g/L)`, points: hdlPts, present: true }); points += hdlPts;

        let sbpPts = 0;
        if (treated) {
            if (sbp < 120) sbpPts = 0;
            else if (sbp < 130) sbpPts = 3;
            else if (sbp < 140) sbpPts = 4;
            else if (sbp < 160) sbpPts = 5;
            else sbpPts = 6;
        } else {
            if (sbp < 120) sbpPts = 0;
            else if (sbp < 130) sbpPts = 1;
            else if (sbp < 140) sbpPts = 2;
            else if (sbp < 160) sbpPts = 3;
            else sbpPts = 4;
        }
        details.push({ criterion: `PAS (${sbp}, ${treated ? 'traitée' : 'non traitée'})`, points: sbpPts, present: true }); points += sbpPts;

        if (smoker) { details.push({ criterion: 'Tabac actif', points: 9, present: true }); points += 9; }
        if (diabetes) { details.push({ criterion: 'Diabète', points: 7, present: true }); points += 7; }

        const riskTable: Record<number, number> = {
            9: 1, 10: 1, 11: 1, 12: 1, 13: 2, 14: 2, 15: 3, 16: 4,
            17: 5, 18: 6, 19: 8, 20: 11, 21: 14, 22: 17, 23: 22, 24: 27, 25: 30
        };
        const cp = Math.max(9, Math.min(25, points));
        const risk = riskTable[cp] ?? (points < 9 ? 1 : 30);

        let level: ScoreResult['level'] = 'low'; let color = 'green';
        if (risk > 20) { level = 'high'; color = 'red'; }
        else if (risk >= 10) { level = 'moderate'; color = 'orange'; }

        return { value: risk, label: 'Framingham', maxValue: '30%', level, color, missingFields: [], details };
    }
}

// ============================================
// 5. SCORE2 / SCORE2-OP (ESC 2021)
// SCORE2 : patients < 70 ans
// SCORE2-OP : patients ≥ 70 ans (seuils et risques de base différents)
// Région de risque modéré (Algérie/Maghreb)
// ============================================
export function calcSCORE2(d: CardiologyFormData): ScoreResult {
    const missing: string[] = [];
    if (d.patient_age == null) missing.push('Âge');
    if (!d.patient_sex) missing.push('Sexe');
    if (d.systolic_bp == null) missing.push('PAS');
    if (d.bio_total_cholesterol == null) missing.push('Cholestérol total');
    if (d.bio_hdl == null) missing.push('HDL');

    const isOP = (d.patient_age ?? 0) >= 70;
    const scoreName = isOP ? 'SCORE2-OP' : 'SCORE2';

    if (missing.length > 0) {
        return { value: null, label: scoreName, maxValue: isOP ? '≥15%' : '≥7.5%', level: null, color: 'gray', missingFields: missing, details: [] };
    }

    const age = d.patient_age!;
    const isMale = d.patient_sex === 'homme';
    const sbp = d.systolic_bp!;
    const nonHDL = d.bio_total_cholesterol! - d.bio_hdl!;
    const smoker = toBool(d.has_active_smoking);

    const details: ScoreDetail[] = [];

    // Base risk by age/sex — moderate risk region (Algeria/Maghreb)
    let baseRisk: number;
    if (isOP) {
        // SCORE2-OP base risk tables (≥70 ans)
        if (isMale) {
            if (age < 75) baseRisk = 13.0;
            else if (age < 80) baseRisk = 16.0;
            else if (age < 85) baseRisk = 19.0;
            else baseRisk = 22.0;
        } else {
            if (age < 75) baseRisk = 9.0;
            else if (age < 80) baseRisk = 12.0;
            else if (age < 85) baseRisk = 15.0;
            else baseRisk = 18.0;
        }
    } else {
        // SCORE2 base risk tables (<70 ans)
        if (isMale) {
            if (age < 40) baseRisk = 0.5;
            else if (age < 50) baseRisk = 1.5;
            else if (age < 55) baseRisk = 3.0;
            else if (age < 60) baseRisk = 4.5;
            else if (age < 65) baseRisk = 6.5;
            else baseRisk = 9.0;
        } else {
            if (age < 40) baseRisk = 0.3;
            else if (age < 50) baseRisk = 0.8;
            else if (age < 55) baseRisk = 1.5;
            else if (age < 60) baseRisk = 2.5;
            else if (age < 65) baseRisk = 4.0;
            else baseRisk = 6.0;
        }
    }
    details.push({ criterion: `Risque de base ${scoreName} (${isMale ? 'H' : 'F'}, ${age} ans)`, points: baseRisk, present: true });

    // Risk modifiers (common to SCORE2 and SCORE2-OP)
    let modifier = 1.0;
    if (smoker) { modifier *= 2.0; details.push({ criterion: 'Tabac actif (×2)', points: 2, present: true }); }
    if (sbp >= 160) { modifier *= 1.8; details.push({ criterion: 'PAS ≥ 160 (×1.8)', points: 1.8, present: true }); }
    else if (sbp >= 140) { modifier *= 1.4; details.push({ criterion: 'PAS 140-159 (×1.4)', points: 1.4, present: true }); }
    else if (sbp >= 120) { modifier *= 1.1; details.push({ criterion: 'PAS 120-139 (×1.1)', points: 1.1, present: true }); }

    if (nonHDL > 1.9) { modifier *= 1.6; details.push({ criterion: 'Non-HDL > 1.9 (×1.6)', points: 1.6, present: true }); }
    else if (nonHDL > 1.6) { modifier *= 1.3; details.push({ criterion: 'Non-HDL 1.6-1.9 (×1.3)', points: 1.3, present: true }); }
    else if (nonHDL > 1.3) { modifier *= 1.1; details.push({ criterion: 'Non-HDL 1.3-1.6 (×1.1)', points: 1.1, present: true }); }

    const risk = Math.round(baseRisk * modifier * 10) / 10;

    // Thresholds differ between SCORE2 and SCORE2-OP (ESC 2021)
    let level: ScoreResult['level'] = 'low'; let color = 'green';
    if (isOP) {
        // SCORE2-OP thresholds (≥70 ans)
        if (risk >= 15) { level = 'very_high'; color = 'red'; }
        else if (risk >= 7.5) { level = 'high'; color = 'orange'; }
        else { level = 'moderate'; color = 'yellow'; }
    } else {
        // SCORE2 thresholds (<70 ans)
        if (risk >= 7.5) { level = 'very_high'; color = 'red'; }
        else if (risk >= 5) { level = 'high'; color = 'orange'; }
        else if (risk >= 2.5) { level = 'moderate'; color = 'yellow'; }
    }

    return { value: risk, label: scoreName, maxValue: isOP ? '≥15%' : '≥7.5%', level, color, missingFields: [], details };
}

// ============================================
// 6. NYHA
// ============================================
export function calcNYHA(d: CardiologyFormData): ScoreResult {
    if (d.nyha_class == null) {
        return { value: null, label: 'NYHA', maxValue: 'IV', level: null, color: 'gray', missingFields: ['Classe NYHA'], details: [] };
    }

    const nyha = d.nyha_class;
    const descriptions: Record<number, string> = {
        1: 'Pas de limitation. Activité physique ordinaire sans symptômes.',
        2: 'Limitation légère. Confortable au repos, symptômes pour efforts ordinaires.',
        3: 'Limitation marquée. Confortable au repos, symptômes pour efforts modérés.',
        4: 'Symptômes au repos. Toute activité physique augmente l\'inconfort.',
    };
    const colors: Record<number, string> = { 1: 'green', 2: 'yellow', 3: 'orange', 4: 'red' };
    const levels: Record<number, ScoreResult['level']> = { 1: 'low', 2: 'moderate', 3: 'high', 4: 'very_high' };

    return {
        value: nyha,
        label: 'NYHA',
        maxValue: 'IV',
        level: levels[nyha] ?? 'low',
        color: colors[nyha] ?? 'gray',
        missingFields: [],
        details: [{ criterion: descriptions[nyha] || '', points: nyha, present: true }],
    };
}

// ============================================
// 7. EuroSCORE II
// ============================================
export function calcEuroSCORE2(d: CardiologyFormData): ScoreResult {
    if (!d.preop_urgency && !d.preop_surgery_type) {
        return { value: null, label: 'EuroSCORE II', maxValue: '> 5%', level: null, color: 'gray', missingFields: ['Section pré-opératoire non remplie'], details: [] };
    }
    const missing: string[] = [];
    if (d.patient_age == null) missing.push('Âge');
    if (!d.patient_sex) missing.push('Sexe');
    if (missing.length > 0) {
        return { value: null, label: 'EuroSCORE II', maxValue: '> 5%', level: null, color: 'gray', missingFields: missing, details: [] };
    }

    const details: ScoreDetail[] = [];
    let logit = -5.324;

    const age = d.patient_age!;
    if (age > 60) {
        const pts = 0.0285181 * (age - 60);
        logit += pts;
        details.push({ criterion: `Âge > 60 (${age} ans)`, points: Math.round(pts * 100) / 100, present: true });
    }

    if (d.patient_sex === 'femme') {
        logit += 0.2196434;
        details.push({ criterion: 'Sexe féminin', points: 0.22, present: true });
    }

    const creat = d.bio_creatinine ?? d.creatinine;
    if (creat && d.patient_weight && age) {
        const sexFactor = d.patient_sex === 'femme' ? 0.85 : 1.0;
        const clCr = ((140 - age) * d.patient_weight * sexFactor) / (0.814 * creat);
        if (clCr < 50) { logit += 0.6421508; details.push({ criterion: 'Clairance créat < 50', points: 0.64, present: true }); }
        else if (clCr < 85) { logit += 0.3034948; details.push({ criterion: 'Clairance créat 50-84', points: 0.30, present: true }); }
    }
    if (toBool(d.preop_dialysis)) { logit += 0.6421508; details.push({ criterion: 'Dialyse', points: 0.64, present: true }); }
    if (toBool(d.has_arteriopathy)) { logit += 0.5360268; details.push({ criterion: 'Artériopathie', points: 0.54, present: true }); }
    if (toBool(d.has_reduced_mobility)) { logit += 0.2407181; details.push({ criterion: 'Mobilité réduite', points: 0.24, present: true }); }
    if (toBool(d.has_prior_cardiac_surgery)) { logit += 1.118599; details.push({ criterion: 'Chirurgie cardiaque antérieure', points: 1.12, present: true }); }
    if (toBool(d.has_chronic_lung_disease)) { logit += 0.1886564; details.push({ criterion: 'Maladie pulmonaire chronique', points: 0.19, present: true }); }
    if (toBool(d.has_endocarditis)) { logit += 0.6194522; details.push({ criterion: 'Endocardite active', points: 0.62, present: true }); }
    if (toBool(d.preop_critical_state)) { logit += 0.9058132; details.push({ criterion: 'État critique pré-op', points: 0.91, present: true }); }
    if (toBool(d.has_diabetes_insulin)) { logit += 0.3542749; details.push({ criterion: 'Diabète insulino-traité', points: 0.35, present: true }); }

    const nyha = d.nyha_class ?? 1;
    if (nyha === 2) { logit += 0.1070545; details.push({ criterion: 'NYHA II', points: 0.11, present: true }); }
    else if (nyha === 3) { logit += 0.2958358; details.push({ criterion: 'NYHA III', points: 0.30, present: true }); }
    else if (nyha === 4) { logit += 0.5597929; details.push({ criterion: 'NYHA IV', points: 0.56, present: true }); }

    const lvef = d.echo_lvef ?? d.known_lvef;
    if (lvef != null) {
        if (lvef < 21) { logit += 0.9346919; details.push({ criterion: 'FEVG < 21%', points: 0.93, present: true }); }
        else if (lvef < 31) { logit += 0.5460218; details.push({ criterion: 'FEVG 21-30%', points: 0.55, present: true }); }
        else if (lvef < 51) { logit += 0.2407181; details.push({ criterion: 'FEVG 31-50%', points: 0.24, present: true }); }
    }

    if (d.echo_pulmonary_htn != null) {
        if (d.echo_pulmonary_htn > 55) { logit += 0.5983526; details.push({ criterion: 'HTAP > 55 mmHg', points: 0.60, present: true }); }
        else if (d.echo_pulmonary_htn > 31) { logit += 0.1886564; details.push({ criterion: 'HTAP 31-55 mmHg', points: 0.19, present: true }); }
    }

    if (d.preop_urgency === 'urgent') { logit += 0.3174673; details.push({ criterion: 'Chirurgie urgente', points: 0.32, present: true }); }
    else if (d.preop_urgency === 'emergency') { logit += 0.7039121; details.push({ criterion: 'Chirurgie émergence', points: 0.70, present: true }); }
    else if (d.preop_urgency === 'salvage') { logit += 1.362947; details.push({ criterion: 'Chirurgie sauvetage', points: 1.36, present: true }); }

    if (toBool(d.preop_thoracic_aorta)) { logit += 0.6527205; details.push({ criterion: 'Chirurgie aorte thoracique', points: 0.65, present: true }); }

    const mortality = (Math.exp(logit) / (1 + Math.exp(logit))) * 100;
    const rounded = Math.round(mortality * 100) / 100;

    let level: ScoreResult['level'] = 'low'; let color = 'green';
    if (rounded > 5) { level = 'high'; color = 'red'; }
    else if (rounded >= 2) { level = 'moderate'; color = 'orange'; }

    return { value: rounded, label: 'EuroSCORE II', maxValue: '> 5%', level, color, missingFields: [], details };
}

// ============================================
// Compute all scores
// ============================================
export function computeAllScores(d: CardiologyFormData): ScoreResult[] {
    return [
        calcCHA2DS2VASc(d),
        calcHASBLED(d),
        calcGRACE(d),
        calcFramingham(d),
        calcSCORE2(d),
        calcNYHA(d),
        calcEuroSCORE2(d),
    ];
}

// ============================================
// Risk level labels
// ============================================
export const RISK_LABELS: Record<string, string> = {
    low: 'Faible',
    moderate: 'Modéré',
    high: 'Élevé',
    very_high: 'Très élevé',
};
