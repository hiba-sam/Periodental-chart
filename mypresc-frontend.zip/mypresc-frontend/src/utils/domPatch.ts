/**
 * DOM Patch — Prevents React crashes caused by browser extensions
 * (Google Translate, Grammarly, password managers, etc.)
 *
 * These extensions modify the DOM outside of React's control,
 * causing "Failed to execute 'insertBefore'/'removeChild' on 'Node'"
 * errors when React tries to reconcile the virtual DOM.
 *
 * This patch wraps the native methods with a try/catch so the error
 * is silently swallowed instead of crashing the app.
 */
if (typeof window !== 'undefined') {
  const originalInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function <T extends Node>(
    newNode: T,
    referenceNode: Node | null
  ): T {
    try {
      return originalInsertBefore.call(this, newNode, referenceNode) as T;
    } catch (e) {
      // Extension-injected node conflict — silently ignore
      return newNode;
    }
  };

  const originalRemoveChild = Node.prototype.removeChild;
  Node.prototype.removeChild = function <T extends Node>(child: T): T {
    try {
      return originalRemoveChild.call(this, child) as T;
    } catch (e) {
      // Extension-removed node conflict — silently ignore
      return child;
    }
  };
}

export {};
