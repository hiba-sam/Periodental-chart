/**
 * Axios Configuration - Global CSRF Protection
 * 
 * Configure axios pour ajouter automatiquement le token CSRF
 * à toutes les requêtes POST, PUT, DELETE, PATCH
 * 
 * USAGE: Import this file early in your app (e.g., in _app.tsx or layout.tsx)
 * or use the createApiInstance function for isolated instances.
 */

import { safeStorage } from '@/utils/safeStorage';

import axios, { AxiosInstance } from 'axios';
import { getCsrfToken } from './csrf';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

/**
 * Configure CSRF interceptors on an axios instance
 */
export function configureCsrfInterceptors(instance: AxiosInstance): void {
    // Intercepteur de requêtes : Ajoute automatiquement le token CSRF
    instance.interceptors.request.use(
        (config) => {
            const protectedMethods = ['post', 'put', 'delete', 'patch'];
            
            if (config.method && protectedMethods.includes(config.method.toLowerCase())) {
                const csrfToken = getCsrfToken();
                
                if (csrfToken) {
                    config.headers['X-CSRF-Token'] = csrfToken;
                }
            }
            
            return config;
        },
        (error) => Promise.reject(error)
    );

    // Intercepteur de réponses : Gérer les erreurs d'authentification et CSRF
    instance.interceptors.response.use(
        (response) => response,
        (error) => {
            // Gestion erreur 401 ou erreur réseau : Session expirée ou backend redémarré
            const isAuthError = error.response?.status === 401;
            const isNetworkError = error.code === 'ERR_NETWORK' || error.code === 'ECONNABORTED';
            
            if (isAuthError || isNetworkError) {
                console.warn('🔒 Session expirée ou backend inaccessible - Redirection vers authentification');
                
                // Éviter la redirection si déjà sur la page de login ou pages admin
                if (typeof window !== 'undefined') {
                    const currentPath = window.location.pathname;
                    const publicPaths = ['/', '/admin', '/resset_password'];
                    const isPublicPath = publicPaths.some(path => 
                        currentPath === path || currentPath.startsWith('/admin') || currentPath.startsWith('/resset_password')
                    );
                    
                    if (!isPublicPath) {
                        // Sauvegarder l'URL actuelle pour y revenir après reconnexion
                        safeStorage.setItem('returnUrl', currentPath + window.location.search);
                        window.location.href = '/';
                    }
                }
            }
            
            // Gestion erreur 403 : CSRF invalide
            if (error.response?.status === 403) {
                const errorData = error.response.data;
                
                if (errorData?.error && 
                    (errorData.error.includes('CSRF') || errorData.error.includes('csrf'))) {
                    console.error('🔒 CSRF Protection: Token invalid or missing');
                }
            }
            
            return Promise.reject(error);
        }
    );
}

/**
 * Create a new axios instance with CSRF protection
 */
export function createApiInstance(baseURL?: string): AxiosInstance {
    const instance = axios.create({
        baseURL: baseURL || API_BASE_URL,
        withCredentials: true,
        headers: {
            'Content-Type': 'application/json',
        },
        timeout: 10000,
    });
    
    configureCsrfInterceptors(instance);
    return instance;
}

// Configure global axios with CSRF
configureCsrfInterceptors(axios);

// Export pre-configured instance for API calls
export const api = createApiInstance();

export default axios;
