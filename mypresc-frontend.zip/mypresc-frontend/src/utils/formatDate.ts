/**
 * Date Formatting Utilities with Locale Support
 * 
 * This module provides locale-aware date formatting functions using date-fns.
 * The locale is determined by the application's selected language.
 */

import { format, formatRelative } from 'date-fns';
import { fr, enUS, arDZ } from 'date-fns/locale';

export type SupportedLanguage = 'en' | 'fr' | 'ar';

/**
 * Map language codes to their corresponding date-fns locale objects
 */
const localeMap: Record<SupportedLanguage, Locale> = {
    fr: fr,
    en: enUS,
    ar: arDZ, // Arabic - Algeria
};

/**
 * Map language codes to BCP-47 locale strings for toLocaleDateString
 */
export const bcp47LocaleMap: Record<SupportedLanguage, string> = {
    fr: 'fr-FR',
    en: 'en-US',
    ar: 'ar-DZ',
};

/**
 * Get the date-fns locale object for a given language
 */
export function getDateLocale(language: SupportedLanguage): Locale {
    return localeMap[language] || localeMap.fr;
}

/**
 * Get the BCP-47 locale string for a given language
 * Used with toLocaleDateString
 */
export function getBcp47Locale(language: SupportedLanguage): string {
    return bcp47LocaleMap[language] || bcp47LocaleMap.fr;
}

/**
 * Format a date using the specified language locale
 * 
 * @param date - The date to format
 * @param language - The language code ('fr', 'en', 'ar')
 * @param formatString - The date-fns format string (default: 'P' for localized date)
 * @returns Formatted date string
 * 
 * Common format strings:
 * - 'P' - Short localized date (e.g., 04/29/1453 for en-US)
 * - 'PP' - Medium date (e.g., Apr 29, 1453)
 * - 'PPP' - Long date (e.g., April 29th, 1453)
 * - 'PPPP' - Full date (e.g., Friday, April 29th, 1453)
 * - 'dd/MM/yyyy' - Custom format
 */
export function formatLocalizedDate(
    date: Date | string | number,
    language: SupportedLanguage,
    formatString: string = 'P'
): string {
    const dateObj = date instanceof Date ? date : new Date(date);

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    return format(dateObj, formatString, { locale: getDateLocale(language) });
}

/**
 * Format a date using toLocaleDateString with the correct BCP-47 locale
 * 
 * @param date - The date to format
 * @param language - The language code ('fr', 'en', 'ar')
 * @param options - Intl.DateTimeFormatOptions
 * @returns Formatted date string
 */
export function formatDateWithOptions(
    date: Date | string | number,
    language: SupportedLanguage,
    options?: Intl.DateTimeFormatOptions
): string {
    const dateObj = date instanceof Date ? date : new Date(date);

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    return dateObj.toLocaleDateString(getBcp47Locale(language), options);
}

/**
 * Format a relative date (e.g., "yesterday", "last Friday")
 */
export function formatRelativeDate(
    date: Date | string | number,
    language: SupportedLanguage,
    baseDate: Date = new Date()
): string {
    const dateObj = date instanceof Date ? date : new Date(date);

    if (isNaN(dateObj.getTime())) {
        return '';
    }

    return formatRelative(dateObj, baseDate, { locale: getDateLocale(language) });
}

/**
 * Preset format functions for common use cases
 */
export const dateFormats = {
    /** Short date: 15/01/2026 (fr) or 01/15/2026 (en) */
    short: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'P'),

    /** Medium date: 15 janv. 2026 (fr) or Jan 15, 2026 (en) */
    medium: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'PP'),

    /** Long date: 15 janvier 2026 (fr) or January 15, 2026 (en) */
    long: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'PPP'),

    /** Full date with weekday: jeudi 15 janvier 2026 (fr) */
    full: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'PPPP'),

    /** Weekday short: jeu. (fr) or Thu (en) */
    weekdayShort: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'EEE'),

    /** Day and month short: 15 janv. (fr) or Jan 15 (en) */
    dayMonth: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'd MMM'),

    /** Month and year: janvier 2026 (fr) or January 2026 (en) */
    monthYear: (date: Date | string | number, language: SupportedLanguage) =>
        formatLocalizedDate(date, language, 'MMMM yyyy'),
};
