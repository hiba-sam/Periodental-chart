'use client';

import React, { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { FileText, Pill, Clock, User, Calendar, AlertTriangle, Shield, Loader2, ArrowLeft, Download, X, Eye } from 'lucide-react';
import axios from 'axios';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';

const DENTAL_SPECIALITIES = [
  'Chirurgie dentaire',
  'Orthodontie',
  'Parodontologie',
  'Implantologie',
  'Médecine bucco-dentaire'
];

interface MedicalShare {
  id: number;
  patient_id: string;
  patient_name: string;
  patient_family_name: string;
  shared_by_doctor_name: string;
  shared_by_doctor_family_name: string;
  share_prescriptions: boolean;
  share_medical_reports: boolean;
  share_dental_acts: boolean;
  visible_until_date: string | null;
  expires_at: string;
  reason: string;
  created_at: string;
}

interface Prescription {
  id: number;
  created_at: string;
  medications: Array<{
    id: number;
    dosage: string;
    note: string;
    quantity: number;
    medication: {
      id: number;
      nom_de_marque: string;
      denomination_commune_internationale: string;
      forme: string;
      dosage: string;
    };
  }>;
}

interface MedicalReport {
  id: number;
  title: string;
  content: string;
  created_at: string;
  report_type: string;
}

interface DentalAct {
  id: number;
  date_act: string;
  act_label: string;
  act_code: string;
  teeth: string[] | null;
  surfaces: string[] | null;
  scope: string;
  status: string;
  notes: string | null;
  doctor_name?: string;
  doctor_family_name?: string;
}

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

export default function SharedMedicalFilePage() {
  const params = useParams();
  const router = useRouter();
  const { user, checking } = useAuth();
  const { profile } = useProfile();
  const token = params?.token as string;

  const [share, setShare] = useState<MedicalShare | null>(null);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [medicalReports, setMedicalReports] = useState<MedicalReport[]>([]);
  const [dentalActs, setDentalActs] = useState<DentalAct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'prescriptions' | 'reports' | 'dental'>('prescriptions');
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [selectedReport, setSelectedReport] = useState<MedicalReport | null>(null);

  // Check if current user is a dental specialist (handles multiple specialities in one string)
  const isDentalSpecialist = profile?.speciality && DENTAL_SPECIALITIES.some(spec => profile.speciality?.toLowerCase().includes(spec.toLowerCase()));

  useEffect(() => {
    if (!checking && !user) {
      router.push('/login?redirect=/shared-medical-file/' + token);
      return;
    }

    if (user && token) {
      fetchShareData();
    }
  }, [user, checking, token]);

  const fetchShareData = async () => {
    setIsLoading(true);
    setError('');

    try {
      // Fetch share details
      const shareResponse = await axios.get(`${API_URL}/medical-shares/access/${token}`, {
        withCredentials: true,
      });

      if (!shareResponse.data?.success) {
        throw new Error(shareResponse.data?.error || 'Erreur lors de la récupération du partage');
      }

      const shareData = shareResponse.data.data;
      setShare(shareData);

      // Set default tab based on what's shared
      if (shareData.share_prescriptions) {
        setActiveTab('prescriptions');
      } else if (shareData.share_medical_reports) {
        setActiveTab('reports');
      }

      // Fetch prescriptions if shared (using dedicated share endpoint)
      if (shareData.share_prescriptions) {
        try {
          const prescResponse = await axios.get(
            `${API_URL}/medical-shares/access/${token}/prescriptions`,
            { withCredentials: true }
          );
          if (prescResponse.data?.success && prescResponse.data?.prescriptions) {
            setPrescriptions(prescResponse.data.prescriptions);
          }
        } catch (err) {
          console.error('Error fetching prescriptions:', err);
        }
      }

      // Fetch medical reports if shared (using dedicated share endpoint)
      if (shareData.share_medical_reports) {
        try {
          const reportsResponse = await axios.get(
            `${API_URL}/medical-shares/access/${token}/reports`,
            { withCredentials: true }
          );
          if (reportsResponse.data?.success && reportsResponse.data?.reports) {
            setMedicalReports(reportsResponse.data.reports);
          }
        } catch (err) {
          console.error('Error fetching medical reports:', err);
        }
      }

      // Fetch dental acts if shared (only visible to dental specialists)
      if (shareData.share_dental_acts) {
        try {
          const dentalResponse = await axios.get(
            `${API_URL}/medical-shares/access/${token}/dental-acts`,
            { withCredentials: true }
          );
          if (dentalResponse.data?.success && dentalResponse.data?.dental_acts) {
            setDentalActs(dentalResponse.data.dental_acts);
          }
        } catch (err) {
          console.error('Error fetching dental acts:', err);
        }
      }
    } catch (err: any) {
      console.error('Error fetching share:', err);
      setError(err.response?.data?.error || err.message || 'Erreur lors du chargement');
    } finally {
      setIsLoading(false);
    }
  };

  if (checking || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Chargement du dossier médical...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            Accès Refusé
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">{error}</p>
          <button
            onClick={() => router.push('/messages')}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Retour aux messages
          </button>
        </div>
      </div>
    );
  }

  if (!share) {
    return null;
  }

  const expiresAt = new Date(share.expires_at);
  const isExpiringSoon = expiresAt.getTime() - Date.now() < 24 * 60 * 60 * 1000;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push('/messages')}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                  Dossier Médical Partagé
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Partagé par Dr. {share.shared_by_doctor_name} {share.shared_by_doctor_family_name}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-500" />
              <span className="text-sm text-green-600 dark:text-green-400 font-medium">
                Accès Sécurisé
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Patient Info Card */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold">
                {share.patient_name?.charAt(0).toUpperCase()}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {share.patient_name} {share.patient_family_name}
                </h2>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-500 dark:text-gray-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Partagé le {new Date(share.created_at).toLocaleDateString('fr-FR')}
                  </span>
                  <span className={`flex items-center gap-1 ${isExpiringSoon ? 'text-amber-500' : ''}`}>
                    <Clock className="w-4 h-4" />
                    Expire le {expiresAt.toLocaleDateString('fr-FR')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Reason */}
          {share.reason && (
            <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                <strong>Raison du partage :</strong> {share.reason}
              </p>
            </div>
          )}

          {/* Warning */}
          <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-amber-700 dark:text-amber-300">
                Ce dossier médical vous est partagé de manière confidentielle. Conformément au code de 
                déontologie médicale, son contenu ne doit pas être divulgué à des tiers.
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6">
          {share.share_prescriptions && (
            <button
              onClick={() => setActiveTab('prescriptions')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'prescriptions'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <Pill className="w-5 h-5" />
              Prescriptions ({prescriptions.length})
            </button>
          )}
          {share.share_medical_reports && (
            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'reports'
                  ? 'bg-purple-600 text-white shadow-lg'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <FileText className="w-5 h-5" />
              Comptes Rendus ({medicalReports.length})
            </button>
          )}
          {/* Dental acts tab - only visible to dental specialists */}
          {share.share_dental_acts && isDentalSpecialist && (
            <button
              onClick={() => setActiveTab('dental')}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                activeTab === 'dental'
                  ? 'bg-cyan-600 text-white shadow-lg'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
              }`}
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
              </svg>
              Actes Dentaires ({dentalActs.length})
            </button>
          )}
        </div>

        {/* Content */}
        <div className="space-y-4">
          {activeTab === 'prescriptions' && share.share_prescriptions && (
            prescriptions.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8 text-center">
                <Pill className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  Aucune prescription disponible pour la période sélectionnée
                </p>
              </div>
            ) : (
              prescriptions.map((prescription) => (
                <div
                  key={prescription.id}
                  onClick={() => setSelectedPrescription(prescription)}
                  className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-all hover:scale-[1.01] border-2 border-transparent hover:border-blue-500"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-gray-900 dark:text-white">
                      Prescription du {new Date(prescription.created_at).toLocaleDateString('fr-FR')}
                    </h3>
                    <button className="flex items-center gap-2 text-blue-600 hover:text-blue-700 text-sm font-medium">
                      <Eye className="w-4 h-4" />
                      Voir détails
                    </button>
                  </div>
                  <div className="space-y-2">
                    {prescription.medications?.slice(0, 3).map((med, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
                      >
                        <p className="font-medium text-gray-900 dark:text-white">
                          {med.medication?.nom_de_marque || med.medication?.denomination_commune_internationale || 'Médicament'}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {med.dosage}
                        </p>
                      </div>
                    ))}
                    {prescription.medications && prescription.medications.length > 3 && (
                      <p className="text-sm text-blue-600 dark:text-blue-400 text-center py-2">
                        + {prescription.medications.length - 3} autre(s) médicament(s)...
                      </p>
                    )}
                  </div>
                </div>
              ))
            )
          )}

          {activeTab === 'reports' && share.share_medical_reports && (
            medicalReports.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8 text-center">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  Aucun compte rendu disponible pour la période sélectionnée
                </p>
              </div>
            ) : (
              medicalReports.map((report) => (
                <div
                  key={report.id}
                  onClick={() => setSelectedReport(report)}
                  className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 cursor-pointer hover:shadow-xl transition-all hover:scale-[1.01] border-2 border-transparent hover:border-purple-500"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-gray-900 dark:text-white">{report.title}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {report.report_type} • {new Date(report.created_at).toLocaleDateString('fr-FR')}
                      </p>
                    </div>
                    <button className="flex items-center gap-2 text-purple-600 hover:text-purple-700 text-sm font-medium">
                      <Eye className="w-4 h-4" />
                      Voir détails
                    </button>
                  </div>
                  <div className="prose dark:prose-invert max-w-none">
                    <div
                      className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap line-clamp-4"
                      dangerouslySetInnerHTML={{ __html: report.content }}
                    />
                    <p className="text-sm text-purple-600 dark:text-purple-400 mt-2">
                      Cliquez pour voir le contenu complet...
                    </p>
                  </div>
                </div>
              ))
            )
          )}

          {/* Dental Acts Content - only for dental specialists */}
          {activeTab === 'dental' && share.share_dental_acts && isDentalSpecialist && (
            dentalActs.length === 0 ? (
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8 text-center">
                <svg className="w-12 h-12 text-gray-400 mx-auto mb-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
                </svg>
                <p className="text-gray-600 dark:text-gray-400">
                  Aucun acte dentaire disponible pour la période sélectionnée
                </p>
              </div>
            ) : (
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Date</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Acte</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Dent(s)</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Surfaces</th>
                      <th className="text-center py-3 px-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Statut</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                    {dentalActs.map((act) => (
                      <tr key={act.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                        <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                          {new Date(act.date_act).toLocaleDateString('fr-FR')}
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-sm font-medium text-gray-800 dark:text-gray-200">{act.act_label || '-'}</div>
                          {act.act_code && <div className="text-xs text-gray-500">{act.act_code}</div>}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                          {act.scope === 'MOUTH' ? 'Bouche entière' : act.teeth?.join(', ') || '-'}
                        </td>
                        <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                          {act.surfaces?.join(', ') || '-'}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${
                            act.status === 'TERMINE' ? 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400' :
                            act.status === 'EN_COURS' ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' :
                            act.status === 'ANNULE' ? 'bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400' :
                            'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'
                          }`}>
                            {act.status === 'TERMINE' ? 'Terminé' :
                             act.status === 'EN_COURS' ? 'En cours' :
                             act.status === 'ANNULE' ? 'Annulé' : 'Non commencé'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          )}
        </div>
      </div>

      {/* Prescription Detail Modal */}
      {selectedPrescription && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          onClick={() => setSelectedPrescription(null)}
        >
          <div 
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-600 to-blue-700">
              <div className="flex items-center gap-3 text-white">
                <Pill className="w-6 h-6" />
                <div>
                  <h2 className="text-xl font-bold">Détails de la Prescription</h2>
                  <p className="text-blue-200 text-sm">
                    {new Date(selectedPrescription.created_at).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPrescription(null)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[70vh]">
              <div className="space-y-4">
                {selectedPrescription.medications?.map((med, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-bold text-lg text-gray-900 dark:text-white flex items-center gap-2">
                          <span className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 text-sm font-bold">
                            {idx + 1}
                          </span>
                          {med.medication?.nom_de_marque || med.medication?.denomination_commune_internationale || 'Médicament'}
                        </h4>
                        {med.medication?.denomination_commune_internationale && med.medication?.nom_de_marque && (
                          <p className="text-sm text-gray-500 dark:text-gray-400 ml-10 mt-1">
                            ({med.medication.denomination_commune_internationale})
                          </p>
                        )}
                        <div className="mt-3 ml-10 space-y-2">
                          <p className="text-gray-700 dark:text-gray-300">
                            <span className="font-medium text-gray-500 dark:text-gray-400">Posologie:</span>{' '}
                            {med.dosage}
                          </p>
                          {med.medication?.forme && (
                            <p className="text-gray-700 dark:text-gray-300">
                              <span className="font-medium text-gray-500 dark:text-gray-400">Forme:</span>{' '}
                              {med.medication.forme}
                            </p>
                          )}
                          {med.quantity && med.quantity > 1 && (
                            <p className="text-gray-700 dark:text-gray-300">
                              <span className="font-medium text-gray-500 dark:text-gray-400">Quantité:</span>{' '}
                              {med.quantity}
                            </p>
                          )}
                          {med.note && (
                            <p className="text-gray-700 dark:text-gray-300">
                              <span className="font-medium text-gray-500 dark:text-gray-400">Note:</span>{' '}
                              {med.note}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  <strong>Total:</strong> {selectedPrescription.medications?.length || 0} médicament(s)
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Medical Report Detail Modal */}
      {selectedReport && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4"
          onClick={() => setSelectedReport(null)}
        >
          <div 
            className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-purple-600 to-purple-700">
              <div className="flex items-center gap-3 text-white">
                <FileText className="w-6 h-6" />
                <div>
                  <h2 className="text-xl font-bold">{selectedReport.title}</h2>
                  <p className="text-purple-200 text-sm">
                    {selectedReport.report_type} • {new Date(selectedReport.created_at).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedReport(null)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[70vh]">
              <div className="prose dark:prose-invert max-w-none">
                <div
                  className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: selectedReport.content }}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
