'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import AdminProtectedRoute from '@/components/admin/AdminProtectedRoute';
import axios from 'axios';
import {
    ArrowLeft, Shield, User, Mail, Phone, Calendar, MapPin,
    Briefcase, FileText, CheckCircle, XCircle, Loader2,
    AlertCircle, Clock, Download, Eye, File, Plus, Trash2, Award, Sparkles
} from 'lucide-react';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface RegistrationDetails {
    user: {
        id: number;
        name: string;
        family_name: string;
        email: string;
        role: string;
        created_at: string;
    };
    doctor_info?: {
        birth_date: string;
        birth_place: string;
        speciality: string;
        experience: number;
        order_num: string;
        work_location: string;
        home_location: string;
        phone_number: string;
        diploma_file?: string | string[];
        id_card_file?: string;
        order_num_file?: string;
        nin?: string;
    };
    assistant_info?: {
        assistant_name: string;
        assistant_email: string;
        phone_number: string | null;
    };
    audit_history: any[];
}

export default function RegistrationDetailsPage() {
    const params = useParams();
    const router = useRouter();
    const { isAuthenticated } = useAdminAuth();
    const [details, setDetails] = useState<RegistrationDetails | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [notes, setNotes] = useState('');
    const [processing, setProcessing] = useState(false);
    const [showConfirmModal, setShowConfirmModal] = useState<'approve' | 'reject' | null>(null);
    const [previewFile, setPreviewFile] = useState<{ url: string; name: string } | null>(null);
    const [experience, setExperience] = useState('');
    const [certificates, setCertificates] = useState<string[]>(['']);

    const userId = params?.id;
    console.log(details);

    const addCertificate = () => setCertificates([...certificates, '']);

    const updateCertificate = (index: number, value: string) => {
        const newCerts = [...certificates];
        newCerts[index] = value;
        setCertificates(newCerts);
    };

    const removeCertificate = (index: number) => {
        const newCerts = certificates.filter((_, i) => i !== index);
        setCertificates(newCerts);
    };

    // Fetch registration details
    useEffect(() => {
        const fetchDetails = async () => {
            if (!isAuthenticated || !userId) return;

            try {
                const response = await axios.get(
                    `${API_URL}/admin/registrations/${userId}`,
                    { withCredentials: true }
                );

                console.log(response.data);
                if (response.data.success) {
                    setDetails(response.data.data);
                }
            } catch (err: any) {
                setError(err.response?.data?.error || 'Failed to load details');
            } finally {
                setLoading(false);
            }
        };

        fetchDetails();
    }, [isAuthenticated, userId]);

    const handleApprove = async () => {
        setProcessing(true);
        try {
            const response = await axios.post(
                `${API_URL}/admin/registrations/${userId}/approve`,
                {
                    notes,
                    experience: experience ? parseInt(experience, 10) : null,
                    certificates: certificates.filter(c => c.trim() !== '')
                },
                { withCredentials: true }
            );

            if (response.data.success) {
                alert('✅ Registration approved successfully!');
                router.push('/admin/registrations');
            }
        } catch (err: any) {
            alert(err.response?.data?.error || 'Failed to approve');
        } finally {
            setProcessing(false);
            setShowConfirmModal(null);
        }
    };

    const handleReject = async () => {
        if (!notes.trim()) {
            alert('⚠️ Please provide a reason for rejection');
            return;
        }

        setProcessing(true);
        try {
            const response = await axios.post(
                `${API_URL}/admin/registrations/${userId}/reject`,
                { notes, reason: notes },
                { withCredentials: true }
            );

            if (response.data.success) {
                alert('✅ Registration rejected successfully');
                router.push('/admin/registrations');
            }
        } catch (err: any) {
            alert(err.response?.data?.error || 'Failed to reject');
        } finally {
            setProcessing(false);
            setShowConfirmModal(null);
        }
    };

    const handleDownloadFile = (filePath: string, fileName: string) => {
        const fileUrl = `${API_URL}/${filePath.replace(/\\/g, '/')}`;
        const link = document.createElement('a');
        link.href = fileUrl;
        link.download = fileName;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handlePreviewFile = (filePath: string, fileName: string) => {
        const fileUrl = `${API_URL}/${filePath.replace(/\\/g, '/')}`;
        setPreviewFile({ url: fileUrl, name: fileName });
    };

    const getFileExtension = (filePath: string): string => {
        return filePath.split('.').pop()?.toLowerCase() || '';
    };

    const isImageFile = (filePath: string): boolean => {
        const ext = getFileExtension(filePath);
        return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(ext);
    };

    const isPdfFile = (filePath: string): boolean => {
        return getFileExtension(filePath) === 'pdf';
    };

    return (
        <AdminProtectedRoute>
            {loading ? (
                <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                    <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
            ) : error || !details ? (
                <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
                    <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-6 text-center">
                        <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
                        <h2 className="text-xl font-bold text-gray-900 mb-2">Error</h2>
                        <p className="text-gray-600 mb-4">{error || 'Registration not found'}</p>
                        <button
                            onClick={() => router.push('/admin/registrations')}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                            Back to List
                        </button>
                    </div>
                </div>
            ) : (
                <div className="min-h-screen bg-gray-50">
                    {/* Header */}
                    <div className="bg-white border-b border-gray-200 shadow-sm">
                        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
                            <div className="flex items-center gap-4 h-16">
                                <button
                                    onClick={() => router.push('/admin/registrations')}
                                    className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                                >
                                    <ArrowLeft className="w-5 h-5" />
                                </button>
                                <div className="flex items-center gap-3">
                                    <Shield className="w-6 h-6 text-blue-600" />
                                    <h1 className="text-lg font-bold text-gray-900">Registration Details</h1>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Main Content */}
                    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                        {/* Status Badge */}
                        <div className="mb-6 flex items-center gap-3">
                            <span className="px-4 py-2 bg-yellow-100 text-yellow-800 font-medium rounded-full flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                Pending Approval
                            </span>
                            <span className="text-sm text-gray-500">
                                {new Date(details.user.created_at).toLocaleString('fr-FR')}
                            </span>
                        </div>

                        {/* User Information */}
                        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                            <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <User className="w-5 h-5 text-blue-600" />
                                User Information
                            </h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="text-sm font-medium text-gray-500">Full Name</label>
                                    <p className="text-gray-900 font-medium">
                                        {details.user.role === 'doctor' ? 'Dr. ' : ''}
                                        {details.user.name} {details.user.family_name}
                                    </p>
                                </div>
                                <div>
                                    <label className="text-sm font-medium text-gray-500">Email</label>
                                    <p className="text-gray-900 flex items-center gap-2">
                                        <Mail className="w-4 h-4 text-gray-400" />
                                        {details.user.email}
                                    </p>
                                </div>
                                <div>
                                    <label className="text-sm font-medium text-gray-500">Role</label>
                                    <p className="text-gray-900 capitalize">{details.user.role}</p>
                                </div>
                                <div>
                                    <label className="text-sm font-medium text-gray-500">Registration Date</label>
                                    <p className="text-gray-900">
                                        {new Date(details.user.created_at).toLocaleDateString('fr-FR')}
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Doctor Information */}
                        {details.doctor_info && (
                            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                    <Briefcase className="w-5 h-5 text-blue-600" />
                                    Doctor Information
                                </h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Birth Date</label>
                                        <p className="text-gray-900">{details.doctor_info.birth_date}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Birth Place</label>
                                        <p className="text-gray-900">{details.doctor_info.birth_place}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Speciality</label>
                                        <p className="text-gray-900 font-medium">{details.doctor_info.speciality}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">NIN</label>
                                        <p className="text-gray-900">{details.doctor_info.nin}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Order Number</label>
                                        <p className="text-gray-900 font-mono">{details.doctor_info.order_num}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Phone</label>
                                        <p className="text-gray-900 flex items-center gap-2">
                                            <Phone className="w-4 h-4 text-gray-400" />
                                            {details.doctor_info.phone_number}
                                        </p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Work Location</label>
                                        <p className="text-gray-900 flex items-center gap-2">
                                            <MapPin className="w-4 h-4 text-gray-400" />
                                            {details.doctor_info.work_location}
                                        </p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Home Location</label>
                                        <p className="text-gray-900 flex items-center gap-2">
                                            <MapPin className="w-4 h-4 text-gray-400" />
                                            {details.doctor_info.home_location}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Assistant Information */}
                        {details.assistant_info && (
                            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                    <User className="w-5 h-5 text-blue-600" />
                                    Assistant Information
                                </h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Assistant Name</label>
                                        <p className="text-gray-900 font-medium">{details.assistant_info.assistant_name}</p>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium text-gray-500">Assistant Email</label>
                                        <p className="text-gray-900 flex items-center gap-2">
                                            <Mail className="w-4 h-4 text-gray-400" />
                                            {details.assistant_info.assistant_email}
                                        </p>
                                    </div>
                                    {details.assistant_info.phone_number && (
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">Phone</label>
                                            <p className="text-gray-900 flex items-center gap-2">
                                                <Phone className="w-4 h-4 text-gray-400" />
                                                {details.assistant_info.phone_number}
                                            </p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Documents Section */}
                        {details.doctor_info && ((Array.isArray(details.doctor_info.diploma_file) ? details.doctor_info.diploma_file.length > 0 : details.doctor_info.diploma_file) || details.doctor_info.id_card_file || details.doctor_info.order_num_file) && (
                            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                    <File className="w-5 h-5 text-blue-600" />
                                    Submitted Documents
                                </h2>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    {/* Diploma Files */}
                                    {details.doctor_info.diploma_file && (
                                        (() => {
                                            const files = Array.isArray(details.doctor_info.diploma_file)
                                                ? details.doctor_info.diploma_file
                                                : [details.doctor_info.diploma_file];

                                            return files.map((filePath, index) => (
                                                <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                                                    <div className="flex items-start gap-3">
                                                        <div className="p-2 bg-blue-50 rounded-lg">
                                                            <FileText className="w-5 h-5 text-blue-600" />
                                                        </div>
                                                        <div className="flex-1 min-w-0">
                                                            <h3 className="font-medium text-gray-900 mb-1">
                                                                Diploma {files.length > 1 ? index + 1 : ''}
                                                            </h3>
                                                            <p className="text-xs text-gray-500 truncate mb-3">
                                                                {filePath.split('\\').pop()}
                                                            </p>
                                                            <div className="flex gap-2">
                                                                <button
                                                                    onClick={() => handlePreviewFile(filePath, `Diploma ${files.length > 1 ? index + 1 : ''}`)}
                                                                    className="flex-1 px-3 py-1.5 text-sm bg-blue-50 text-blue-700 rounded-md hover:bg-blue-100 transition-colors flex items-center justify-center gap-1"
                                                                >
                                                                    <Eye className="w-4 h-4" />
                                                                    View
                                                                </button>
                                                                <button
                                                                    onClick={() => {
                                                                        const ext = getFileExtension(filePath);
                                                                        handleDownloadFile(filePath, `diploma_${details.user.name}_${details.user.family_name}_${index + 1}.${ext}`);
                                                                    }}
                                                                    className="flex-1 px-3 py-1.5 text-sm bg-gray-50 text-gray-700 rounded-md hover:bg-gray-100 transition-colors flex items-center justify-center gap-1"
                                                                >
                                                                    <Download className="w-4 h-4" />
                                                                    Download
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ));
                                        })()
                                    )}

                                    {/* ID Card File */}
                                    {details.doctor_info.id_card_file && (
                                        <div className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                                            <div className="flex items-start gap-3">
                                                <div className="p-2 bg-green-50 rounded-lg">
                                                    <FileText className="w-5 h-5 text-green-600" />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="font-medium text-gray-900 mb-1">ID Card</h3>
                                                    <p className="text-xs text-gray-500 truncate mb-3">
                                                        {details.doctor_info.id_card_file.split('\\').pop()}
                                                    </p>
                                                    <div className="flex gap-2">
                                                        <button
                                                            onClick={() => handlePreviewFile(details.doctor_info!.id_card_file!, 'ID Card')}
                                                            className="flex-1 px-3 py-1.5 text-sm bg-green-50 text-green-700 rounded-md hover:bg-green-100 transition-colors flex items-center justify-center gap-1"
                                                        >
                                                            <Eye className="w-4 h-4" />
                                                            View
                                                        </button>
                                                        <button
                                                            onClick={() => {
                                                                const ext = getFileExtension(details.doctor_info!.id_card_file!);
                                                                handleDownloadFile(details.doctor_info!.id_card_file!, `id_card_${details.user.name}_${details.user.family_name}.${ext}`);
                                                            }}
                                                            className="flex-1 px-3 py-1.5 text-sm bg-gray-50 text-gray-700 rounded-md hover:bg-gray-100 transition-colors flex items-center justify-center gap-1"
                                                        >
                                                            <Download className="w-4 h-4" />
                                                            Download
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* Order Number File */}
                                    {details.doctor_info.order_num_file && (
                                        <div className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                                            <div className="flex items-start gap-3">
                                                <div className="p-2 bg-purple-50 rounded-lg">
                                                    <FileText className="w-5 h-5 text-purple-600" />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="font-medium text-gray-900 mb-1">Order Certificate</h3>
                                                    <p className="text-xs text-gray-500 truncate mb-3">
                                                        {details.doctor_info.order_num_file.split('\\').pop()}
                                                    </p>
                                                    <div className="flex gap-2">
                                                        <button
                                                            onClick={() => handlePreviewFile(details.doctor_info!.order_num_file!, 'Order Certificate')}
                                                            className="flex-1 px-3 py-1.5 text-sm bg-purple-50 text-purple-700 rounded-md hover:bg-purple-100 transition-colors flex items-center justify-center gap-1"
                                                        >
                                                            <Eye className="w-4 h-4" />
                                                            View
                                                        </button>
                                                        <button
                                                            onClick={() => {
                                                                const ext = getFileExtension(details.doctor_info!.order_num_file!);
                                                                handleDownloadFile(details.doctor_info!.order_num_file!, `order_certificate_${details.user.name}_${details.user.family_name}.${ext}`);
                                                            }}
                                                            className="flex-1 px-3 py-1.5 text-sm bg-gray-50 text-gray-700 rounded-md hover:bg-gray-100 transition-colors flex items-center justify-center gap-1"
                                                        >
                                                            <Download className="w-4 h-4" />
                                                            Download
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Notes */}
                        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                            <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-blue-600" />
                                Verification Notes (Optional)
                            </h2>
                            <textarea
                                value={notes}
                                onChange={(e) => setNotes(e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                                rows={4}
                                placeholder="Add notes about verification, documents checked, etc..."
                            />
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-4">
                            <button
                                onClick={() => setShowConfirmModal('approve')}
                                disabled={processing}
                                className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            >
                                <CheckCircle className="w-5 h-5" />
                                Approve Registration
                            </button>
                            <button
                                onClick={() => setShowConfirmModal('reject')}
                                disabled={processing}
                                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            >
                                <XCircle className="w-5 h-5" />
                                Reject Registration
                            </button>
                        </div>
                    </div>

                    {/* Confirmation Modal */}
                    {showConfirmModal && (
                        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 transition-all duration-300">
                            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-hidden flex flex-col transform transition-all scale-100">
                                {/* Modal Header */}
                                <div className={`px-6 py-4 border-b border-gray-100 flex items-center gap-3 ${showConfirmModal === 'approve' ? 'bg-green-50/50' : 'bg-red-50/50'
                                    }`}>
                                    <div className={`p-2 rounded-full ${showConfirmModal === 'approve' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                                        }`}>
                                        {showConfirmModal === 'approve' ? <Sparkles className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                                    </div>
                                    <h3 className="text-xl font-bold text-gray-900">
                                        {showConfirmModal === 'approve' ? 'Approve Registration' : 'Reject Registration'}
                                    </h3>
                                </div>

                                {/* Modal Body */}
                                <div className="p-6 overflow-y-auto">
                                    {showConfirmModal === 'approve' ? (
                                        <div className="space-y-6">
                                            <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 text-sm text-blue-800">
                                                Please complete the professional profile for <strong>Dr. {details.user.family_name}</strong>. This information will be visible on their public profile.
                                            </div>

                                            {/* Experience Field */}
                                            <div>
                                                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                                                    <Briefcase className="w-4 h-4 text-gray-500" />
                                                    Years of Experience
                                                </label>
                                                <div className="relative">
                                                    <input
                                                        type="number"
                                                        min="0"
                                                        value={experience}
                                                        onChange={(e) => setExperience(e.target.value)}
                                                        className="w-full pl-4 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                                        placeholder="5"
                                                    />
                                                </div>
                                            </div>

                                            {/* Certificates Field */}
                                            <div>
                                                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                                                    <Award className="w-4 h-4 text-gray-500" />
                                                    Certificates & Diplomas
                                                </label>
                                                <div className="space-y-3">
                                                    {certificates.map((cert, index) => (
                                                        <div key={index} className="flex gap-2 group">
                                                            <input
                                                                type="text"
                                                                value={cert}
                                                                onChange={(e) => updateCertificate(index, e.target.value)}
                                                                className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                                                                placeholder="Certificate or Diploma name"
                                                            />
                                                            {certificates.length > 1 && (
                                                                <button
                                                                    onClick={() => removeCertificate(index)}
                                                                    className="px-3 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                                                                    title="Remove certificate"
                                                                >
                                                                    <Trash2 className="w-5 h-5" />
                                                                </button>
                                                            )}
                                                        </div>
                                                    ))}
                                                    <button
                                                        onClick={addCertificate}
                                                        className="w-full py-3 border-2 border-dashed border-gray-200 rounded-xl text-gray-500 font-medium hover:border-blue-300 hover:text-blue-600 hover:bg-blue-50 transition-all flex items-center justify-center gap-2"
                                                    >
                                                        <Plus className="w-5 h-5" />
                                                        Add Another Certificate
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="text-center py-4">
                                            <div className="bg-red-50 text-red-800 p-4 rounded-xl mb-4 text-left border border-red-100">
                                                <p className="font-semibold mb-1">Warning: Irreversible Action</p>
                                                <p className="text-sm opacity-90">
                                                    You are about to permanently delete the account for <strong>{details.user.name} {details.user.family_name}</strong>. All associated data will be removed.
                                                </p>
                                            </div>
                                            <div className="text-left">
                                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                                    Reason for Rejection (Required)
                                                </label>
                                                <textarea
                                                    value={notes}
                                                    onChange={(e) => setNotes(e.target.value)}
                                                    className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all resize-none"
                                                    rows={3}
                                                    placeholder="Please explain why this registration is being rejected..."
                                                />
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Modal Footer */}
                                <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex gap-3">
                                    <button
                                        onClick={() => setShowConfirmModal(null)}
                                        disabled={processing}
                                        className="flex-1 px-4 py-2.5 font-medium text-gray-700 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-colors shadow-sm"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        onClick={showConfirmModal === 'approve' ? handleApprove : handleReject}
                                        disabled={processing}
                                        className={`flex-1 px-4 py-2.5 font-semibold text-white rounded-xl shadow-lg shadow-blue-500/20 transition-all transform active:scale-95 flex items-center justify-center gap-2 ${showConfirmModal === 'approve'
                                            ? 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700'
                                            : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700'
                                            }`}
                                    >
                                        {processing ? (
                                            <Loader2 className="w-5 h-5 animate-spin" />
                                        ) : showConfirmModal === 'approve' ? (
                                            <>
                                                <CheckCircle className="w-5 h-5" />
                                                Confirm Approval
                                            </>
                                        ) : (
                                            <>
                                                <XCircle className="w-5 h-5" />
                                                Confirm Rejection
                                            </>
                                        )}
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* File Preview Modal */}
                    {previewFile && (
                        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50" onClick={() => setPreviewFile(null)}>
                            <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[95vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-between p-4 border-b border-gray-200">
                                    <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                                        <Eye className="w-5 h-5 text-blue-600" />
                                        {previewFile.name}
                                    </h3>
                                    <div className="flex items-center gap-2">
                                        <a
                                            href={previewFile.url}
                                            download
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 text-sm"
                                        >
                                            <Download className="w-4 h-4" />
                                            Download
                                        </a>
                                        <button
                                            onClick={() => setPreviewFile(null)}
                                            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                                        >
                                            <XCircle className="w-6 h-6" />
                                        </button>
                                    </div>
                                </div>
                                <div className="overflow-auto max-h-[calc(95vh-80px)]">
                                    {isPdfFile(previewFile.url) ? (
                                        <iframe
                                            src={previewFile.url}
                                            className="w-full h-[calc(95vh-80px)] border-0"
                                            title={previewFile.name}
                                        />
                                    ) : isImageFile(previewFile.url) ? (
                                        <div className="p-4">
                                            <img
                                                src={previewFile.url}
                                                alt={previewFile.name}
                                                className="w-auto h-full rounded-lg mx-auto"
                                                onError={(e) => {
                                                    const target = e.target as HTMLImageElement;
                                                    target.style.display = 'none';
                                                    target.parentElement!.innerHTML = '<div class="text-center py-12"><p class="text-red-600">Failed to load image</p></div>';
                                                }}
                                            />
                                        </div>
                                    ) : (
                                        <div className="text-center py-12">
                                            <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                                            <p className="text-gray-600 mb-4">Preview not available for this file type</p>
                                            <a
                                                href={previewFile.url}
                                                download
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                                            >
                                                <Download className="w-5 h-5" />
                                                Download File
                                            </a>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </AdminProtectedRoute>
    );
}
