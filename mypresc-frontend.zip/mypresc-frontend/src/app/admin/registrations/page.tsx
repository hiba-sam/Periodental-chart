'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAdminAuth } from '@/contexts/AdminAuthContext';
import AdminProtectedRoute from '@/components/admin/AdminProtectedRoute';
import axios from 'axios';
import { 
    Shield, 
    LogOut, 
    Clock, 
    User, 
    Mail, 
    Briefcase,
    Loader2,
    AlertCircle,
    Calendar,
    MapPin
} from 'lucide-react';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface Registration {
    id: number;
    name: string;
    family_name: string;
    email: string;
    role: string;
    created_at: string;
    doctor_info?: {
        birth_date: string;
        birth_place: string;
        speciality: string;
        experience: number;
        order_num: string;
        work_location: string;
    };
}

export default function AdminRegistrationsPage() {
    const { admin, loading: authLoading, logout, isAuthenticated } = useAdminAuth();
    const router = useRouter();
    const [registrations, setRegistrations] = useState<Registration[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    // Fetch pending registrations
    useEffect(() => {
        const fetchRegistrations = async () => {
            if (!isAuthenticated) return;

            try {
                const response = await axios.get(
                    `${API_URL}/admin/registrations/pending`,
                    { withCredentials: true }
                );

                if (response.data.success) {
                    setRegistrations(response.data.data.registrations);
                }
            } catch (err: any) {
                console.error('Fetch error:', err);
                setError(err.response?.data?.error || 'Failed to load registrations');
            } finally {
                setLoading(false);
            }
        };

        fetchRegistrations();
    }, [isAuthenticated]);

    const formatDate = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);

        if (diffMins < 60) return `Il y a ${diffMins} min`;
        if (diffHours < 24) return `Il y a ${diffHours}h`;
        if (diffDays < 7) return `Il y a ${diffDays}j`;
        return date.toLocaleDateString('fr-FR');
    };

    return (
        <AdminProtectedRoute>
            <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        {/* Logo & Title */}
                        <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg">
                                <Shield className="w-6 h-6 text-white" />
                            </div>
                            <div>
                                <h1 className="text-lg font-bold text-gray-900">Admin Dashboard</h1>
                                <p className="text-xs text-gray-500">Registration Management</p>
                            </div>
                        </div>

                        {/* Admin Info & Logout */}
                        <div className="flex items-center gap-4">
                            <div className="text-right">
                                <p className="text-sm font-medium text-gray-900">{admin?.name}</p>
                                <p className="text-xs text-gray-500">{admin?.email}</p>
                            </div>
                            <button
                                onClick={logout}
                                className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                title="Logout"
                            >
                                <LogOut className="w-5 h-5" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Stats */}
                <div className="mb-6">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <div className="flex items-center gap-3">
                            <Clock className="w-8 h-8 text-blue-600" />
                            <div>
                                <h2 className="text-2xl font-bold text-blue-900">
                                    {registrations.length}
                                </h2>
                                <p className="text-sm text-blue-700">
                                    {registrations.length === 0 ? 'Aucune demande' : 
                                     registrations.length === 1 ? 'Demande en attente' : 
                                     'Demandes en attente'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Error Message */}
                {error && (
                    <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-800">{error}</p>
                    </div>
                )}

                {/* Registrations List */}
                {registrations.length === 0 ? (
                    <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                        <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">
                            Aucune demande en attente
                        </h3>
                        <p className="text-gray-600">
                            Toutes les demandes d'inscription ont été traitées.
                        </p>
                    </div>
                ) : (
                    <div className="space-y-4">
                        {registrations.map((registration) => (
                            <div
                                key={registration.id}
                                onClick={() => router.push(`/admin/registrations/${registration.id}`)}
                                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer border border-gray-200 hover:border-blue-300"
                            >
                                <div className="p-6">
                                    <div className="flex items-start justify-between">
                                        {/* Left: User Info */}
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3 mb-3">
                                                <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full">
                                                    <User className="w-6 h-6 text-blue-600" />
                                                </div>
                                                <div>
                                                    <h3 className="text-lg font-bold text-gray-900">
                                                        {registration.role === 'doctor' ? 'Dr. ' : ''}
                                                        {registration.name} {registration.family_name}
                                                    </h3>
                                                    <div className="flex items-center gap-2 text-sm text-gray-600">
                                                        <Mail className="w-4 h-4" />
                                                        {registration.email}
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Doctor Info */}
                                            {registration.doctor_info && (
                                                <div className="ml-15 space-y-2">
                                                    <div className="flex items-center gap-2 text-sm text-gray-700">
                                                        <Briefcase className="w-4 h-4 text-gray-400" />
                                                        <span className="font-medium">
                                                            {registration.doctor_info.speciality}
                                                        </span>
                                                        <span className="text-gray-500">
                                                            • {registration.doctor_info.experience} ans d'expérience
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center gap-2 text-sm text-gray-600">
                                                        <MapPin className="w-4 h-4 text-gray-400" />
                                                        {registration.doctor_info.work_location}
                                                    </div>
                                                    <div className="flex items-center gap-2 text-sm text-gray-600">
                                                        <Calendar className="w-4 h-4 text-gray-400" />
                                                        Ordre N° {registration.doctor_info.order_num}
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        {/* Right: Time & Badge */}
                                        <div className="flex flex-col items-end gap-2">
                                            <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-xs font-medium rounded-full">
                                                En attente
                                            </span>
                                            <span className="text-sm text-gray-500">
                                                {formatDate(registration.created_at)}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                {/* Footer */}
                                <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 rounded-b-lg">
                                    <p className="text-sm text-gray-600">
                                        Cliquez pour voir les détails et valider la demande →
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
        </AdminProtectedRoute>
    );
}
