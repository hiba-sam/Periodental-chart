'use client';

import React, { useState, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useMessaging } from '@/features/messages';
import UserSearch from '@/features/messages/components/UserSearch';
import ConversationList from '@/features/messages/components/ConversationList';
import MessageThread from '@/features/messages/components/MessageThread';
import MessageInput from '@/features/messages/components/MessageInput';
import PresenceBadge from '@/features/messages/components/PresenceBadge';
import { MessageCircle, Inbox, ArrowLeft, X } from 'lucide-react';
import Header from '@/components/Header';
import PresenceIndicator from '@/features/messages/components/PresenceIndicator';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useHeaderContext } from '@/contexts/HeaderContext';

function MessagesPageContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { conversations, conversationPartner } = useMessaging();
  const { user, checking } = useAuth(); // Get user and checking state
  const { t, isRTL } = useLanguage();
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);
  const [isMobileConversationOpen, setIsMobileConversationOpen] = useState(false);
  const [optimisticMessage, setOptimisticMessage] = useState<any>(null);

  const { setHidden } = useHeaderContext();

  useEffect(() => {
    setHidden(true);
    return () => setHidden(false);
  }, []);

  // Check if user is assistant
  const isAssistant = user?.role === 'assistant';

  // Get current user ID from AuthContext
  // IMPORTANT DATA STRUCTURE:
  // - For assistants: user.id = doctor_id, user.assistant_id = assistant's actual ID (used as sender_id)
  // - For doctors: user.id = doctor's actual ID (used as sender_id)
  const currentUserId = user
    ? parseInt(isAssistant && user.assistant_id ? user.assistant_id : user.id)
    : null;

  // Debug log
  useEffect(() => {
    console.log('🔍 Messages Page Debug:');
    console.log('  - Role:', user?.role);
    console.log('  - isAssistant:', isAssistant);
    console.log('  - user.id:', user?.id);
    console.log('  - user.assistant_id:', user?.assistant_id);
    console.log('  - currentUserId (calculated):', currentUserId);
  }, [checking, user, currentUserId, isAssistant]);

  // Auto-select first conversation for assistants (their doctor)
  useEffect(() => {
    if (isAssistant && conversations.length > 0 && !selectedConversationId) {
      // For assistants, automatically select the first conversation (should be their doctor)
      setSelectedConversationId(conversations[0]?.id ?? null);
      setIsMobileConversationOpen(true);
    }
  }, [isAssistant, conversations, selectedConversationId]);

  // Handle URL params (conversation or id)
  useEffect(() => {
    const conversationParam = searchParams?.get('conversation');
    const idParam = searchParams?.get('id');
    const convId = conversationParam || idParam;

    if (convId) {
      setSelectedConversationId(parseInt(convId));
      setIsMobileConversationOpen(true);
    }
  }, [searchParams]);

  // Show loading state while checking authentication
  if (checking || !user) {
    return (
      <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        <div className="flex-1 ml-[100px] transition-all duration-300">
          <div className="h-screen flex flex-col">
            {/* Header */}
            <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-3 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{t('messages.title')}</h1>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{t('messages.loading')}</p>
                </div>
                <Header />
              </div>
            </div>

            {/* Loading state */}
            <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10 transition-colors">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600 dark:text-gray-400">{t('messages.loading')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const selectedConversation = conversations.find(c => c.id === selectedConversationId);

  const handleSelectConversation = (conversationId: number) => {
    setSelectedConversationId(conversationId);
    setIsMobileConversationOpen(true);
  };

  const handleCloseConversation = () => {
    setIsMobileConversationOpen(false);
    setTimeout(() => setSelectedConversationId(null), 300);
  };

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      {/* Main Content with Sidebar spacing */}
      <div className="flex-1 transition-all duration-300">
        <div className="h-dvh flex flex-col">
          {/* Header */}
          <div className="bg-white dark:bg-gray-900 md:border-b border-gray-200 dark:border-gray-800 px-6 py-3 transition-colors">
            <div className="hidden md:flex items-center justify-between mb-2">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                  {t('messages.title')}
                </h1>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
                  {isAssistant
                    ? t('messages.subtitleAssistant')
                    : t('messages.subtitleDoctor')
                  }
                </p>
              </div>
              {/* <Header /> */}
            </div>
          </div>

          {/* Main Messages Layout */}
          <div className="flex-1 flex overflow-hidden mt-12 md:mt-0">
            {/* Conversations Panel - Hidden for assistants */}
            {!isAssistant && (
              <div className={`${isMobileConversationOpen ? 'hidden md:flex' : 'flex'} w-full md:w-96 lg:w-[420px] border-r border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 flex-col transition-colors`}>
                {/* Search */}
                <div className="px-3 py-2.5 md:p-4 md:bg-gradient-to-r md:from-blue-50 md:to-purple-50 md:dark:from-blue-900/20 md:dark:to-purple-900/20 transition-colors">
                  <UserSearch onSelectConversation={handleSelectConversation} />
                </div>

                {/* Conversation List */}
                <div className="flex-1 overflow-y-auto">
                  <ConversationList
                    selectedId={selectedConversationId}
                    onSelectConversation={handleSelectConversation}
                  />
                </div>
              </div>
            )}

            {/* Conversation Area */}
            {selectedConversationId ? (
              <div className={`${isAssistant
                ? 'flex flex-col fixed top-0 left-0 right-0 h-dvh z-50 md:relative md:top-auto md:left-auto md:right-auto md:h-auto md:z-auto md:flex-1'
                : isMobileConversationOpen
                  ? 'flex flex-col fixed top-0 left-0 right-0 h-dvh z-50 md:relative md:top-auto md:left-auto md:right-auto md:h-auto md:z-auto md:flex-1 animate-slide-up md:animate-none'
                  : 'hidden md:flex md:flex-1 md:flex-col'
                } bg-white dark:bg-gray-900 transition-colors`}>
                {/* Conversation Header */}
                <div className="sticky top-0 z-10 flex items-center gap-3 h-14 min-h-[56px] md:h-auto md:min-h-0 px-3 md:px-6 md:py-4 border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-sm shrink-0 transition-colors">
                  {/* Back button — mobile only (both doctor and assistant) */}
                  <button
                    onClick={isAssistant ? () => router.back() : handleCloseConversation}
                    className="md:hidden flex items-center justify-center w-9 h-9 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 transition-colors shrink-0"
                    aria-label="Go back"
                  >
                    <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Avatar */}
                  <div className="relative shrink-0">
                    <div className="w-9 h-9 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-base md:text-lg shadow-md">
                      {selectedConversation?.other_user_name?.charAt(0).toUpperCase() || '?'}
                    </div>
                    {selectedConversation && (
                      <div className="absolute -bottom-0.5 -right-0.5">
                        <PresenceIndicator userId={selectedConversation.other_user_id} size="sm" />
                      </div>
                    )}
                  </div>

                  {/* Name + status */}
                  <div className="flex-1 min-w-0">
                    <h2 className="font-semibold mb-1 text-sm md:text-lg text-gray-900 dark:text-gray-100 truncate leading-tight">
                      {selectedConversation?.other_user_name || t('messages.loading')}
                    </h2>
                    {selectedConversation && (
                      <div className="flex items-center gap-1.5 text-xs md:text-sm">
                        <PresenceBadge userId={selectedConversation.other_user_id} />
                        <span className="text-gray-400 dark:text-gray-500 truncate">• {selectedConversation.other_user_name?.split(' ')[0]}</span>
                      </div>
                    )}
                  </div>

                  {/* Desktop close button */}
                  {!isAssistant && (
                    <button
                      onClick={handleCloseConversation}
                      className="hidden md:flex items-center justify-center p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors group"
                    >
                      <X className="w-5 h-5 text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300" />
                    </button>
                  )}
                </div>

                {/* Messages Thread */}
                <div className="flex-1 min-h-0 bg-gradient-to-br from-gray-50 via-blue-50/20 to-purple-50/20 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10 flex flex-col overflow-hidden transition-colors">
                  {currentUserId ? (
                    <MessageThread
                      conversationId={selectedConversationId!}
                      currentUserId={currentUserId}
                      optimisticMessage={optimisticMessage}
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-gray-500 dark:text-gray-400">{t('messages.loading')}</div>
                    </div>
                  )}
                </div>

                {/* Message Input */}
                <div className="border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 shadow-lg transition-colors">
                  <MessageInput
                    conversationId={selectedConversationId!}
                    recipientDoctorId={selectedConversation?.other_user_id}
                    recipientDoctorName={selectedConversation?.other_user_name}
                    recipientIsDoctor={!isAssistant && selectedConversation?.other_user_id !== conversationPartner?.other_user_id}
                    onMessageSent={(msg) => setOptimisticMessage(msg)}
                  />
                </div>
              </div>
            ) : !isAssistant ? (
              /* Empty State - Only show for non-assistants */
              <div className="hidden md:flex flex-1 items-center justify-center bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10 transition-colors">
                <div className="text-center max-w-md px-4">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg">
                    <Inbox className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-3">
                    {t('messages.selectConversation')}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {t('messages.selectConversationDesc')}
                  </p>
                  <div className="flex items-center justify-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    <span>{t('messages.connected')}</span>
                  </div>
                </div>
              </div>
            ) : (
              /* Loading state for assistants */
              <div className="flex-1 flex items-center justify-center bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10 transition-colors">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600 dark:text-gray-400">{t('messages.loadingConversation')}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MessagesPage() {
  return <MessagesPageContent />;
}
