"use client";

import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import { ThemeProvider } from "../contexts/ThemeContext";
import ScrollToTop from "../components/ScrollToTop";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import Loader from "@/components/ui/FullPageLoader";
import { MobileMenuProvider, useMobileMenu } from "@/contexts/MobileMenuContext";

// Import all providers - they must be available synchronously
import { ProfileProvider } from "@/contexts/ProfileContext";
import { MessagingProvider } from "@/features/messages";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { AppointmentsProvider } from "@/contexts/AppointmentContext";
import { PatientsProvider } from "@/contexts/PatientsContext";
import { WaitingRoomProvider } from "@/contexts/WaitingRoomContext";
import { CalendarProvider } from "@/contexts/CalendarContext";
import { PrescriptionProvider } from "@/contexts/PrescriptionContext";
import { useHeaderContext } from "@/contexts/HeaderContext";
import GlobalErrorMonitor from "@/components/GlobalErrorMonitor";
import DOMErrorBoundary from "@/components/DOMErrorBoundary";

// Lazy load heavy UI components only
const RenewAlert = dynamic(() => import("@/components/payment/RenewAlert"), { ssr: false });
const StatusAlert = dynamic(() => import("@/components/payment/StatusAlert"), { ssr: false });
const PatientCallPopup = dynamic(() => import("@/components/PatientCallPopup"), { ssr: false });

// Inner layout that can consume MobileMenuContext
function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isLoginPage = pathname === "/";
  const isAdminPage = pathname?.startsWith("/admin") || pathname?.startsWith("/resset_password");
  const { isRTL } = useLanguage();
  const { checking } = useAuth();
  const { isMobileMenuOpen, closeMobileMenu } = useMobileMenu();
  const { hidden } = useHeaderContext();

  // Auto-close mobile sidebar on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (isMobileMenuOpen) closeMobileMenu();
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('touchmove', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('touchmove', handleScroll);
    };
  }, [isMobileMenuOpen, closeMobileMenu]);

  const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);

  // Desktop margin shifts with sidebar; on mobile (< md) sidebar is an overlay so no margin needed
  const desktopMarginClass = isSidebarExpanded
    ? (isRTL ? "md:mr-64" : "md:ml-64")
    : (isRTL ? "md:mr-20" : "md:ml-20");

  const showSidebar = !isLoginPage && !isAdminPage;

  if (checking) return <Loader />;

  // For login/admin pages, render minimal layout
  if (isLoginPage || isAdminPage) {
    return (
      <div className="flex">
        <div className="flex-1">{children}</div>
      </div>
    );
  }

  // For authenticated pages
  return (
    <>
      {/* Fixed header — sits above everything */}
      {showSidebar && <Header />}

      <div className="flex min-h-screen">
        {/* Sidebar (desktop strip + mobile drawer) */}
        {showSidebar && (
          <Sidebar
            onToggleExpanded={setIsSidebarExpanded}
            isMobileOpen={isMobileMenuOpen}
            onMobileClose={closeMobileMenu}
          />
        )}

        {/* Mobile overlay backdrop — starts below header */}
        {isMobileMenuOpen && (
          <div
            className="fixed top-16 bottom-0 left-0 right-0 z-40 bg-black/50 md:hidden"
            onClick={closeMobileMenu}
          />
        )}

        {/* Main content — no left margin on mobile (sidebar is overlay), md+ gets margin */}
        <div className={`flex-1 min-w-0 ${hidden ? '' : 'pt-14'} transition-all duration-300 ease-in-out ${showSidebar ? desktopMarginClass : ''}`}>
          <DOMErrorBoundary>
            {children}
          </DOMErrorBoundary>
        </div>
      </div>
    </>
  );
}

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ThemeProvider>
      <MobileMenuProvider>
        <ProfileProvider>
          <NotificationProvider>
            <MessagingProvider>
              <AppointmentsProvider>
                <PatientsProvider>
                  <WaitingRoomProvider>
                    <CalendarProvider>
                      <PrescriptionProvider>
                        <AppLayout>{children}</AppLayout>
                        <PatientCallPopup />
                      </PrescriptionProvider>
                    </CalendarProvider>
                  </WaitingRoomProvider>
                </PatientsProvider>
              </AppointmentsProvider>
            </MessagingProvider>
          </NotificationProvider>
        </ProfileProvider>
        <RenewAlert />
        <StatusAlert />
        <ScrollToTop />
        <GlobalErrorMonitor />
      </MobileMenuProvider>
    </ThemeProvider>
  );
}
