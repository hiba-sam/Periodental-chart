'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import dynamic from 'next/dynamic';
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

const CardioEvolutionModal = dynamic(
    () => import('@/features/cardiology/components/CardioEvolutionModal'),
    { loading: () => <div className="animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg h-96" />, ssr: false }
);

interface CRCardio {
    id: number; patient_id: string; doctor_user_id: number;
    patient_age?: number | null; patient_sex?: string | null;
    patient_weight?: number | null; patient_height?: number | null; patient_bmi?: number | null;
    heart_rate?: number | null; systolic_bp?: number | null; diastolic_bp?: number | null;
    spo2?: number | null;
    auscultation?: string | null; nyha_class?: number | null;
    chest_pain?: string | null; lower_limb_edema?: string | null;
    heart_failure_signs?: string[] | null;
    ecg_result?: string | null; ecg_detail?: string | null;
    echo_lvef?: number | null; known_lvef?: number | null;
    echo_lvedd?: number | null; echo_lvesd?: number | null; echo_la_size?: number | null;
    echo_ivs_thickness?: number | null; echo_pw_thickness?: number | null;
    echo_tapse?: number | null;
    echo_wall_motion?: string | null; echo_wall_motion_detail?: string | null;
    echo_diastolic_function?: string | null; echo_pericardial_effusion?: string | null;
    echo_valvulopathies?: string[] | null; echo_pulmonary_htn?: number | null;
    echo_valvulopathy_severity?: Record<string, string> | null;
    bio_bnp?: number | null; bio_troponin?: number | null;
    bio_ldl?: number | null; bio_hdl?: number | null;
    bio_total_cholesterol?: number | null; bio_triglycerides?: number | null;
    bio_hba1c?: number | null; bio_creatinine?: number | null; bio_inr?: number | null;
    has_hta?: boolean; has_diabetes?: boolean; has_afib?: boolean;
    has_heart_failure?: boolean; has_mi?: boolean; has_stroke?: boolean;
    free_notes?: string | null;
    score_cha2ds2_vasc?: number | null; score_has_bled?: number | null;
    score_grace?: number | null; score_framingham?: number | null;
    score_score2?: number | null; score_nyha?: number | null; score_euroscore2?: number | null;
    created_at: string; updated_at: string;
    doctor_name?: string; doctor_family_name?: string;
}


interface MedItem {
    prescription_medication_id: number;
    nom_de_marque: string | null;
    dci: string | null;
    med_dosage: string | null;
    forme: string | null;
    quantity: number;
    dosage: string;
    note: string | null;
    atc_code: string | null;
    change_status?: 'maintained' | 'dose_changed' | 'replacement' | 'new' | 'initial' | 'stopped';
    previous_dosage?: string | null;
    previous_nom_de_marque?: string | null;
    replaces_dci?: string | null;
    replaces_nom_de_marque?: string | null;
    replaces_dosage?: string | null;
}

interface MedsData {
    current: MedItem[];
    stopped: MedItem[];
    latestPrescriptionDate?: string;
    previousPrescriptionDate?: string | null;
    prescriptionCount: number;
}

interface CardiologieActsSectionProps {
    patientId: string; patientName: string;
    patientAge?: number; patientSex?: string;
    currentUserId: number; isVisible: boolean;
    refreshKey?: number;
}

async function fetchCRCardio(patientId: string): Promise<CRCardio[]> {
    const { data } = await axios.get(`${API_URL}/api/patients/${patientId}/cardiology-reports`, { withCredentials: true });
    return data.data || [];
}

function KpiCard({ label, value, unit, colorClass }: { label: string; value: string | number | null | undefined; unit?: string; colorClass?: string }) {
    const display = value != null && value !== '' ? `${value}${unit ? ` ${unit}` : ''}` : '—';
    return (
        <div className="flex flex-col items-center p-3 bg-gray-50 dark:bg-gray-700/40 rounded-xl min-w-[90px]">
            <span className="text-[10px] font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">{label}</span>
            <span className={`text-lg font-bold ${colorClass || 'text-gray-700 dark:text-gray-200'}`}>{display}</span>
        </div>
    );
}

function BioRow({ label, value, unite, min, max }: { label: string; value: number | null | undefined; unite: string; min?: number; max?: number }) {
    let color = 'text-gray-400';
    if (value != null) {
        const bad = (max != null && value > max) || (min != null && value < min);
        color = bad ? 'text-red-600 dark:text-red-400 font-semibold' : 'text-green-600 dark:text-green-400';
    }
    return (
        <div className="flex items-center justify-between py-1">
            <span className="text-xs text-gray-600 dark:text-gray-400">{label}</span>
            <span className={`text-sm font-semibold ${color}`}>{value != null ? `${value} ${unite}` : '—'}</span>
        </div>
    );
}

function ScoreBadge({ label, value, danger }: { label: string; value: number | null | undefined; danger?: number }) {
    if (value == null) return null;
    const bad = danger != null && value >= danger;
    return (
        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium ${bad ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400' : 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'}`}>
            {label}: <strong>{value}</strong>
        </span>
    );
}

function formatDate(d: string | null | undefined) {
    if (!d) return null;
    try { return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
    catch { return d; }
}

export function CardiologieActsSection({ patientId, patientName, patientAge, patientSex, currentUserId, isVisible, refreshKey }: CardiologieActsSectionProps) {
    const [showEvolution, setShowEvolution] = useState(false);
    const [showMeds, setShowMeds] = useState(false);
    const [allReports, setAllReports] = useState<CRCardio[]>([]);
    const [latestCR, setLatestCR] = useState<CRCardio | null>(null);
    const [loading, setLoading] = useState(true);
    const [medsData, setMedsData] = useState<MedsData | null>(null);
    const [restoredIds, setRestoredIds] = useState<Set<number>>(new Set());
    const [stoppedByDrag, setStoppedByDrag] = useState<Set<number>>(new Set());
    const [manualLinks, setManualLinks] = useState<Map<number, number>>(new Map());
    const [linkingMedId, setLinkingMedId] = useState<number | null>(null);
    const [draggingId, setDraggingId] = useState<number | null>(null);
    const [draggingFrom, setDraggingFrom] = useState<'current' | 'stopped' | null>(null);
    const [dragOverZone, setDragOverZone] = useState<'current' | 'stopped' | null>(null);
    const draggingIdRef = useRef<number | null>(null);
    const draggingFromRef = useRef<'current' | 'stopped' | null>(null);

    const loadData = useCallback(() => {
        setLoading(true);
        Promise.all([
            fetchCRCardio(patientId),
            axios.get(`${API_URL}/patient/${patientId}/medications?cardio=true`, { withCredentials: true })
                .then((res: any) => res.data?.success ? res.data.data : null)
                .catch(() => null),
        ]).then(([reports, meds]) => {
            setAllReports(reports); setLatestCR(reports[0] ?? null);
            setMedsData(meds);
            setLoading(false);
        }).catch(() => setLoading(false));
    }, [patientId]);

    useEffect(() => { loadData(); }, [loadData, refreshKey]);

    if (!isVisible) return null;

    const r = latestCR;
    const fevg = r?.echo_lvef ?? r?.known_lvef ?? null;
    const imc = r?.patient_bmi ?? (r?.patient_weight && r?.patient_height ? +(r.patient_weight / ((r.patient_height / 100) ** 2)).toFixed(1) : null);
    const paColor = (v: number | null | undefined) => { if (v == null) return ''; if (v >= 180 || v <= 80) return 'text-red-600 font-bold'; if (v >= 140 || v < 90) return 'text-orange-600 font-semibold'; return 'text-green-600'; };
    const fcColor = (v: number | null | undefined) => { if (v == null) return ''; if (v >= 130 || (v && v < 40)) return 'text-red-600 font-bold'; if (v >= 100 || (v && v < 50)) return 'text-orange-600'; return 'text-green-600'; };
    const historyFlags = r ? [r.has_hta && 'HTA', r.has_diabetes && 'Diabète', r.has_afib && 'FA', r.has_heart_failure && 'IC', r.has_mi && 'IDM', r.has_stroke && 'AVC'].filter(Boolean) : [];

    return (
        <div className="mb-6 bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                        <svg className="w-5 h-5 text-red-600 dark:text-red-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                    </div>
                    <div>
                        <h3 className="text-base font-semibold text-gray-800 dark:text-gray-200">Synthèse Cardiologique</h3>
                        {r && <p className="text-[11px] text-gray-500 dark:text-gray-400">Dernière MAJ : {formatDate(r.updated_at || r.created_at)}{r.doctor_name ? ` — Dr. ${r.doctor_name}` : ''}</p>}
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    {medsData && medsData.current.length > 0 && (
                        <button onClick={() => setShowMeds(!showMeds)} className={`flex items-center gap-1.5 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${showMeds ? 'text-white bg-emerald-600 hover:bg-emerald-700' : 'text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 hover:bg-emerald-100 dark:hover:bg-emerald-900/30 border border-emerald-200 dark:border-emerald-800/30'}`}>
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" /></svg>
                            Traitement
                            <span className={`text-[10px] rounded-full px-1.5 py-0.5 font-medium ${showMeds ? 'bg-emerald-500 text-white' : 'bg-emerald-200 dark:bg-emerald-800 text-emerald-800 dark:text-emerald-200'}`}>{medsData.current.length}</span>
                        </button>
                    )}
                    {allReports.length >= 1 && (
                        <button onClick={() => setShowEvolution(true)} className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>
                            Évolutions
                        </button>
                    )}
                </div>
            </div>

            {/* Medications Banner - toggleable with Drag & Drop */}
            {showMeds && medsData && (() => {
                const linkedStoppedIds = new Set(manualLinks.values());
                const restoredMeds = (medsData.stopped || []).filter(m => restoredIds.has(m.prescription_medication_id));
                const displayCurrent = [
                    ...medsData.current.filter(m => !stoppedByDrag.has(m.prescription_medication_id)).map(med => {
                        const linkedStoppedId = manualLinks.get(med.prescription_medication_id);
                        if (linkedStoppedId) {
                            const linked = (medsData.stopped || []).find(s => s.prescription_medication_id === linkedStoppedId);
                            if (linked) return { ...med, change_status: 'replacement' as const, replaces_nom_de_marque: linked.nom_de_marque, replaces_dci: linked.dci, replaces_dosage: linked.med_dosage };
                        }
                        return med;
                    }),
                    ...restoredMeds.map(med => ({ ...med, change_status: 'maintained' as const })),
                ];
                const displayStopped = [
                    ...(medsData.stopped || []).filter(m => !restoredIds.has(m.prescription_medication_id) && !linkedStoppedIds.has(m.prescription_medication_id)),
                    ...medsData.current.filter(m => stoppedByDrag.has(m.prescription_medication_id)),
                ];
                const totalCount = displayCurrent.length;
                const isDragging = draggingId !== null;

                const handleDragStart = (id: number, from: 'current' | 'stopped') => (e: React.DragEvent) => {
                    draggingIdRef.current = id;
                    draggingFromRef.current = from;
                    setDraggingId(id);
                    setDraggingFrom(from);
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/plain', String(id));
                    if (e.currentTarget instanceof HTMLElement) e.currentTarget.style.opacity = '0.4';
                };
                const handleDragEnd = (e: React.DragEvent) => {
                    draggingIdRef.current = null;
                    draggingFromRef.current = null;
                    setDraggingId(null);
                    setDraggingFrom(null);
                    setDragOverZone(null);
                    if (e.currentTarget instanceof HTMLElement) e.currentTarget.style.opacity = '1';
                };
                const handleDropOnStopped = (e: React.DragEvent) => {
                    e.preventDefault();
                    setDragOverZone(null);
                    const id = draggingIdRef.current;
                    const from = draggingFromRef.current;
                    if (id === null || from !== 'current') return;
                    const isFromOriginalCurrent = medsData.current.some(m => m.prescription_medication_id === id);
                    if (isFromOriginalCurrent) {
                        setStoppedByDrag(prev => new Set(prev).add(id));
                    }
                    const wasRestored = restoredIds.has(id);
                    if (wasRestored) {
                        setRestoredIds(prev => { const n = new Set(prev); n.delete(id); return n; });
                    }
                    draggingIdRef.current = null; draggingFromRef.current = null;
                    setDraggingId(null); setDraggingFrom(null);
                };
                const handleDropOnCurrent = (e: React.DragEvent) => {
                    e.preventDefault();
                    setDragOverZone(null);
                    const id = draggingIdRef.current;
                    const from = draggingFromRef.current;
                    if (id === null || from !== 'stopped') return;
                    const wasDragStopped = stoppedByDrag.has(id);
                    if (wasDragStopped) {
                        setStoppedByDrag(prev => { const n = new Set(prev); n.delete(id); return n; });
                    } else {
                        setRestoredIds(prev => new Set(prev).add(id));
                    }
                    draggingIdRef.current = null; draggingFromRef.current = null;
                    setDraggingId(null); setDraggingFrom(null);
                };
                const handleDragEnterCurrent = (e: React.DragEvent) => {
                    if (draggingFromRef.current === 'stopped') {
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                    }
                };
                const handleDragOverCurrent = (e: React.DragEvent) => {
                    if (draggingFromRef.current === 'stopped') {
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                        setDragOverZone('current');
                    }
                };
                const handleDragEnterStopped = (e: React.DragEvent) => {
                    if (draggingFromRef.current === 'current') {
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                    }
                };
                const handleDragOverStopped = (e: React.DragEvent) => {
                    if (draggingFromRef.current === 'current') {
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                        setDragOverZone('stopped');
                    }
                };
                const leaveDrop = () => setDragOverZone(null);

                if (totalCount === 0 && displayStopped.length === 0) return null;
                return (
                <div className="mb-4 bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-200 dark:border-emerald-800/30 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                            <h4 className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wide">Traitement cardio en cours</h4>
                            <span className="text-[10px] text-emerald-600/60 dark:text-emerald-500/60">{totalCount} médicament{totalCount > 1 ? 's' : ''}</span>
                        </div>
                        {medsData && medsData.latestPrescriptionDate && (
                            <span className="text-[10px] text-emerald-600/50 dark:text-emerald-500/50">
                                Ordonnance du {formatDate(medsData.latestPrescriptionDate)}
                            </span>
                        )}
                    </div>
                    {/* Current treatment drop zone */}
                    <div
                        onDragEnter={handleDragEnterCurrent}
                        onDragOver={handleDragOverCurrent}
                        onDragLeave={leaveDrop}
                        onDrop={handleDropOnCurrent}
                        className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 rounded-lg p-1 transition-all duration-200 ${
                            dragOverZone === 'current'
                                ? 'ring-2 ring-emerald-400 bg-emerald-100/50 dark:bg-emerald-900/20'
                                : ''
                        }`}
                    >
                        {displayCurrent.length === 0 && (
                            <div className={`col-span-full flex flex-col items-center justify-center py-8 rounded-lg border-2 border-dashed transition-all duration-200 ${
                                dragOverZone === 'current'
                                    ? 'border-emerald-400 dark:border-emerald-500 bg-emerald-100/60 dark:bg-emerald-900/20'
                                    : 'border-emerald-300/60 dark:border-emerald-700/40 bg-emerald-50/30 dark:bg-emerald-900/5'
                            }`}>
                                <svg className="w-8 h-8 text-emerald-400 dark:text-emerald-500 mb-2" fill="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>
                                <span className={`text-sm font-medium ${isDragging && draggingFrom === 'stopped' ? 'text-emerald-600 dark:text-emerald-400 animate-pulse' : 'text-emerald-500/60 dark:text-emerald-500/40'}`}>
                                    {isDragging && draggingFrom === 'stopped' ? 'Déposer ici pour rétablir le traitement' : 'Aucun traitement en cours'}
                                </span>
                            </div>
                        )}
                        {displayCurrent.map((med: MedItem) => {
                            const statusConfig: Record<string, { icon: string; color: string; bg: string; border: string }> = {
                                maintained: { icon: '✓', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-white dark:bg-gray-800', border: 'border-emerald-100 dark:border-emerald-800/20' },
                                dose_changed: { icon: '↑↓', color: 'text-orange-600 dark:text-orange-400', bg: 'bg-orange-50 dark:bg-orange-900/10', border: 'border-orange-200 dark:border-orange-800/20' },
                                replacement: { icon: '⇄', color: 'text-blue-600 dark:text-blue-400', bg: 'bg-blue-50 dark:bg-blue-900/10', border: 'border-blue-200 dark:border-blue-800/20' },
                                new: { icon: '+', color: 'text-purple-600 dark:text-purple-400', bg: 'bg-purple-50 dark:bg-purple-900/10', border: 'border-purple-200 dark:border-purple-800/20' },
                                initial: { icon: '•', color: 'text-emerald-600 dark:text-emerald-400', bg: 'bg-white dark:bg-gray-800', border: 'border-emerald-100 dark:border-emerald-800/20' },
                            };
                            const s = statusConfig[med.change_status || 'initial'] || statusConfig.initial;
                            const isNewUnlinked = med.change_status === 'new' && displayStopped.length > 0;
                            const isLinking = linkingMedId === med.prescription_medication_id;
                            const beingDragged = draggingId === med.prescription_medication_id;
                            return (
                                <div key={med.prescription_medication_id}
                                    draggable
                                    onDragStart={handleDragStart(med.prescription_medication_id, 'current')}
                                    onDragEnd={handleDragEnd}
                                    className={`relative flex items-start gap-2 rounded-lg px-3 py-2 border cursor-grab active:cursor-grabbing select-none transition-opacity ${s.bg} ${s.border} ${beingDragged ? 'opacity-40' : 'opacity-100'}`}
                                >
                                    <span className={`text-[10px] font-bold flex-shrink-0 mt-0.5 w-4 text-center ${s.color}`}>{s.icon}</span>
                                    <div className="min-w-0 flex-1">
                                        <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 truncate">{med.nom_de_marque || med.dci || 'Médicament'}</p>
                                        {(med.med_dosage || med.forme) && (
                                            <p className="text-[10px] text-gray-500 dark:text-gray-400 truncate">{[med.med_dosage, med.forme].filter(Boolean).join(' · ')}</p>
                                        )}
                                        {med.dosage && <p className="text-[10px] text-emerald-700 dark:text-emerald-400 font-medium truncate">{med.dosage}</p>}
                                        {med.change_status === 'dose_changed' && med.previous_dosage && (
                                            <p className="text-[10px] text-orange-600 dark:text-orange-400 truncate">Dose : {med.previous_dosage} → {med.med_dosage}</p>
                                        )}
                                        {med.change_status === 'replacement' && med.replaces_nom_de_marque && (
                                            <p className="text-[10px] text-blue-600 dark:text-blue-400 truncate">Remplace {med.replaces_nom_de_marque} {med.replaces_dosage || ''}</p>
                                        )}
                                        {isNewUnlinked && !isDragging && (
                                            <button onClick={() => setLinkingMedId(isLinking ? null : med.prescription_medication_id)} className={`mt-1 text-[9px] font-medium px-1.5 py-0.5 rounded transition-colors ${isLinking ? 'bg-blue-600 text-white' : 'text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/20'}`}>
                                                {isLinking ? 'Annuler' : 'Lier à un arrêté'}
                                            </button>
                                        )}
                                    </div>
                                    {med.quantity > 0 && (
                                        <span className="text-[10px] font-medium text-emerald-700 dark:text-emerald-400 flex-shrink-0 bg-emerald-50 dark:bg-emerald-900/20 rounded px-1 py-0.5">x{med.quantity}</span>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                    {/* Stopped zone — always visible during drag, or when there are stopped meds */}
                    {(displayStopped.length > 0 || (isDragging && draggingFrom === 'current')) && (
                        <div
                            onDragEnter={handleDragEnterStopped}
                            onDragOver={handleDragOverStopped}
                            onDragLeave={leaveDrop}
                            onDrop={handleDropOnStopped}
                            className={`mt-3 pt-3 border-t transition-all duration-200 rounded-lg ${
                                dragOverZone === 'stopped'
                                    ? 'border-red-300 bg-red-100/60 dark:bg-red-900/20 ring-2 ring-red-400 p-3'
                                    : isDragging && draggingFrom === 'current'
                                        ? 'border-dashed border-red-300 dark:border-red-700 bg-red-50/40 dark:bg-red-900/5 p-3'
                                        : 'border-emerald-200/50 dark:border-emerald-800/20'
                            }`}
                        >
                            <div className="flex items-center gap-2 mb-1.5">
                                <p className="text-[10px] font-semibold text-red-500 dark:text-red-400 uppercase tracking-wide">Arrêtés</p>
                                {isDragging && draggingFrom === 'current' && (
                                    <span className="text-[9px] text-red-400 dark:text-red-500 italic animate-pulse">Déposer ici pour arrêter</span>
                                )}
                                {!isDragging && displayStopped.length > 0 && (
                                    <span className="text-[9px] text-gray-400 dark:text-gray-500 italic">Glisser vers le haut pour rétablir</span>
                                )}
                            </div>
                            <div className="flex flex-wrap gap-1.5">
                                {displayStopped.map((med: MedItem) => (
                                    <div key={med.prescription_medication_id}
                                        draggable
                                        onDragStart={handleDragStart(med.prescription_medication_id, 'stopped')}
                                        onDragEnd={handleDragEnd}
                                        onClick={() => {
                                            if (linkingMedId) {
                                                const next = new Map(manualLinks);
                                                next.set(linkingMedId, med.prescription_medication_id);
                                                setManualLinks(next);
                                                setLinkingMedId(null);
                                            }
                                        }}
                                        className={`inline-flex items-center gap-1.5 text-[10px] rounded px-2 py-1 transition-all border cursor-grab active:cursor-grabbing select-none ${
                                            draggingId === med.prescription_medication_id ? 'opacity-40' : 'opacity-100'
                                        } ${
                                            linkingMedId
                                                ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10 border-blue-300 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-900/20 cursor-pointer ring-1 ring-blue-400 animate-pulse'
                                                : 'text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800/20 hover:border-red-300'
                                        }`}
                                        title={linkingMedId ? 'Lier comme remplacé' : 'Glisser vers le haut pour rétablir'}
                                    >
                                        <span className={linkingMedId ? '' : 'line-through'}>{med.nom_de_marque || med.dci} {med.med_dosage || ''}</span>
                                        {linkingMedId && <span className="text-[8px] opacity-60">← lier</span>}
                                    </div>
                                ))}
                                {displayStopped.length === 0 && isDragging && draggingFrom === 'current' && (
                                    <span className="text-[10px] text-red-400/60 italic py-1">Déposer le médicament ici...</span>
                                )}
                            </div>
                        </div>
                    )}
                </div>
                );
            })()}

            {loading ? (
                <div className="flex items-center justify-center py-10"><div className="animate-spin w-6 h-6 border-2 border-red-500 border-t-transparent rounded-full" /></div>
            ) : !r ? (
                <div className="text-center py-10 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl">
                    <svg className="w-10 h-10 mx-auto text-gray-300 dark:text-gray-600 mb-2" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Aucune donnée cardiologique</p>
                    <p className="text-xs text-gray-400 mt-1">Créez un CR Cardio pour alimenter cette synthèse</p>
                    <button onClick={() => setShowEvolution(true)} className="mt-3 text-sm text-red-600 hover:underline font-medium">Créer un CR Cardio</button>
                </div>
            ) : (
                <>
                    {/* Scores */}
                    <div className="flex flex-wrap gap-2 mb-4">
                        <ScoreBadge label="NYHA" value={r.score_nyha} danger={3} />
                        <ScoreBadge label="CHA₂DS₂-VASc" value={r.score_cha2ds2_vasc} danger={2} />
                        <ScoreBadge label="HAS-BLED" value={r.score_has_bled} danger={3} />
                        <ScoreBadge label="GRACE" value={r.score_grace} danger={140} />
                        {r.score_framingham != null && <ScoreBadge label="Framingham" value={r.score_framingham} danger={20} />}
                        {r.score_score2 != null && <ScoreBadge label="SCORE2" value={r.score_score2} danger={10} />}
                        {r.score_euroscore2 != null && <ScoreBadge label="EuroSCORE II" value={r.score_euroscore2} danger={5} />}
                        {historyFlags.length > 0 && (
                            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400">
                                ATCD: {historyFlags.join(', ')}
                            </span>
                        )}
                    </div>

                    {/* KPI Cards */}
                    <div className="flex flex-wrap gap-3 mb-5">
                        <KpiCard label="PA" value={r.systolic_bp != null && r.systolic_bp > 0 && r.diastolic_bp != null && r.diastolic_bp > 0 ? `${r.systolic_bp}/${r.diastolic_bp}` : null} unit="mmHg" colorClass={paColor(r.systolic_bp)} />
                        <KpiCard label="FC" value={r.heart_rate != null && r.heart_rate > 0 ? r.heart_rate : null} unit="bpm" colorClass={fcColor(r.heart_rate)} />
                        <KpiCard label="FEVG" value={fevg} unit="%" colorClass={fevg != null ? (fevg < 40 ? 'text-red-600 font-bold' : fevg < 55 ? 'text-orange-600' : 'text-green-600') : undefined} />
                        <KpiCard label="TAPSE" value={r.echo_tapse} unit="mm" colorClass={r.echo_tapse != null ? (r.echo_tapse < 17 ? 'text-red-600 font-bold' : 'text-green-600') : undefined} />
                        <KpiCard label="ECG" value={r.ecg_result} colorClass={r.ecg_result && r.ecg_result !== 'sinusal_normal' ? 'text-orange-600 font-semibold' : 'text-green-600'} />
                        <KpiCard label="IMC" value={imc} colorClass={imc ? (imc > 30 ? 'text-orange-600' : imc < 18.5 ? 'text-orange-600' : 'text-green-600') : undefined} />
                        <KpiCard label="NYHA" value={r.nyha_class ? `Classe ${r.nyha_class}` : null} colorClass={r.nyha_class && r.nyha_class >= 3 ? 'text-red-600 font-bold' : 'text-green-600'} />
                        {r.spo2 != null && <KpiCard label="SpO₂" value={r.spo2} unit="%" colorClass={r.spo2 < 92 ? 'text-red-600 font-bold' : r.spo2 < 95 ? 'text-orange-600' : 'text-green-600'} />}
                    </div>

                    {/* 3-column grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {/* COL 1: ECG + ETT */}
                        <div className="space-y-3">
                            <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-3">
                                <h4 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">ECG</h4>
                                <div className="space-y-1 text-sm">
                                    <div className="flex justify-between"><span className="text-gray-500">Résultat</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.ecg_result || '—'}</span></div>
                                    {r.ecg_detail && <p className="text-xs text-gray-600 dark:text-gray-400 mt-1 italic">{r.ecg_detail}</p>}
                                </div>
                            </div>
                            <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-3">
                                <h4 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Échographie (ETT)</h4>
                                <div className="space-y-1 text-sm">
                                    <div className="flex justify-between"><span className="text-gray-500">FEVG</span><span className={`font-bold ${fevg != null && fevg < 40 ? 'text-red-600' : 'text-gray-700 dark:text-gray-300'}`}>{fevg != null ? `${fevg}%` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">DTD VG</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.echo_lvedd ? `${r.echo_lvedd} mm` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">DTS VG</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.echo_lvesd ? `${r.echo_lvesd} mm` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">SIV</span><span className={`font-medium ${r.echo_ivs_thickness != null && r.echo_ivs_thickness > 11 ? 'text-orange-600 font-semibold' : 'text-gray-700 dark:text-gray-300'}`}>{r.echo_ivs_thickness ? `${r.echo_ivs_thickness} mm${r.echo_ivs_thickness > 11 ? ' (HVG)' : ''}` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">PP</span><span className={`font-medium ${r.echo_pw_thickness != null && r.echo_pw_thickness > 11 ? 'text-orange-600 font-semibold' : 'text-gray-700 dark:text-gray-300'}`}>{r.echo_pw_thickness ? `${r.echo_pw_thickness} mm${r.echo_pw_thickness > 11 ? ' (HVG)' : ''}` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">OG</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.echo_la_size ? `${r.echo_la_size} mm` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">TAPSE</span><span className={`font-bold ${r.echo_tapse != null && r.echo_tapse < 17 ? 'text-red-600' : 'text-gray-700 dark:text-gray-300'}`}>{r.echo_tapse ? `${r.echo_tapse} mm` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">HTAP</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.echo_pulmonary_htn ? `${r.echo_pulmonary_htn} mmHg` : '—'}</span></div>
                                    {r.echo_wall_motion && (
                                        <div className="flex justify-between"><span className="text-gray-500">Cinétique</span><span className={`font-medium ${r.echo_wall_motion !== 'normal' ? 'text-orange-600' : 'text-gray-700 dark:text-gray-300'}`}>{({ normal: 'Normale', hypokinesia: 'Hypokinesie', akinesia: 'Akinésie', dyskinesia: 'Dyskinésie' } as Record<string, string>)[r.echo_wall_motion] || r.echo_wall_motion}{r.echo_wall_motion_detail ? ` — ${r.echo_wall_motion_detail}` : ''}</span></div>
                                    )}
                                    {r.echo_diastolic_function && (
                                        <div className="flex justify-between"><span className="text-gray-500">Fn diastolique</span><span className={`font-medium ${r.echo_diastolic_function !== 'normal' ? 'text-orange-600' : 'text-gray-700 dark:text-gray-300'}`}>{({ normal: 'Normale', relaxation_impaired: 'Tr. relaxation', pseudonormal: 'Pseudo-N', restrictive: 'Restrictive' } as Record<string, string>)[r.echo_diastolic_function] || r.echo_diastolic_function}</span></div>
                                    )}
                                    {r.echo_pericardial_effusion && r.echo_pericardial_effusion !== 'absent' && (
                                        <div className="flex justify-between"><span className="text-gray-500">Épanch. péric.</span><span className={`font-semibold ${r.echo_pericardial_effusion === 'important' ? 'text-red-600' : 'text-orange-600'}`}>{({ minime: 'Minime', modere: 'Modéré', important: 'Important' } as Record<string, string>)[r.echo_pericardial_effusion] || r.echo_pericardial_effusion}</span></div>
                                    )}
                                    {r.echo_valvulopathies && r.echo_valvulopathies.length > 0 && (
                                        <div className="flex justify-between"><span className="text-gray-500">Valvulopathies</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.echo_valvulopathies.map((v: string) => {
                                            const sev = r.echo_valvulopathy_severity?.[v];
                                            const sevLabel: Record<string, string> = { legere: 'légère', moderee: 'modérée', severe: 'sévère' };
                                            return sev ? `${v} ${sevLabel[sev] || sev}` : v;
                                        }).join(', ')}</span></div>
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* COL 2: Biology */}
                        <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-3">
                            <h4 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Biologie</h4>
                            <div className="space-y-0.5">
                                <BioRow label="LDL" value={r.bio_ldl} unite="g/L" max={0.55} />
                                <BioRow label="HDL" value={r.bio_hdl} unite="g/L" min={0.40} />
                                <BioRow label="Chol. total" value={r.bio_total_cholesterol} unite="g/L" max={2.0} />
                                <BioRow label="Triglycérides" value={r.bio_triglycerides} unite="g/L" max={1.50} />
                                <BioRow label="HbA1c" value={r.bio_hba1c} unite="%" max={7.0} />
                                <BioRow label="Créatinine" value={r.bio_creatinine} unite="µmol/L" min={60} max={110} />
                                <BioRow label="BNP" value={r.bio_bnp} unite="pg/mL" max={100} />
                                <BioRow label="Troponine" value={r.bio_troponin} unite="ng/mL" max={0.04} />
                                {r.bio_inr != null && <BioRow label="INR" value={r.bio_inr} unite="" min={2.0} max={3.0} />}
                            </div>
                        </div>

                        {/* COL 3: Clinical + Notes */}
                        <div className="space-y-3">
                            <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-3">
                                <h4 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Examen clinique</h4>
                                <div className="space-y-1 text-sm">
                                    <div className="flex justify-between"><span className="text-gray-500">PA</span><span className={`font-medium ${paColor(r.systolic_bp)}`}>{r.systolic_bp != null && r.systolic_bp > 0 && r.diastolic_bp != null && r.diastolic_bp > 0 ? `${r.systolic_bp}/${r.diastolic_bp} mmHg` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">FC</span><span className={`font-medium ${fcColor(r.heart_rate)}`}>{r.heart_rate != null && r.heart_rate > 0 ? `${r.heart_rate} bpm` : '—'}</span></div>
                                    {r.spo2 != null && <div className="flex justify-between"><span className="text-gray-500">SpO₂</span><span className={`font-medium ${r.spo2 < 92 ? 'text-red-600 font-bold' : r.spo2 < 95 ? 'text-orange-600' : 'text-green-600'}`}>{r.spo2}%</span></div>}
                                    <div className="flex justify-between"><span className="text-gray-500">Auscultation</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.auscultation ? (({ normal: 'Normale', souffle_systolique: 'Souffle syst.', souffle_diastolique: 'Souffle diast.', souffle_continu: 'Souffle continu', galop_b3: 'Galop B3', galop_b4: 'Galop B4', frottement_pericardique: 'Frottement péric.', arythmie: 'Arythmie' } as Record<string, string>)[r.auscultation] || r.auscultation) : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">NYHA</span><span className={`font-medium ${r.nyha_class && r.nyha_class >= 3 ? 'text-red-600' : 'text-gray-700 dark:text-gray-300'}`}>{r.nyha_class ? `Classe ${r.nyha_class}` : '—'}</span></div>
                                    {r.chest_pain && r.chest_pain !== '' && (
                                        <div className="flex justify-between"><span className="text-gray-500">Douleur thoracique</span><span className="font-medium text-orange-600">{({ typique: 'Typique', atypique: 'Atypique', non_cardiaque: 'Non cardiaque' } as Record<string, string>)[r.chest_pain] || r.chest_pain}</span></div>
                                    )}
                                    {r.lower_limb_edema && r.lower_limb_edema !== '' && r.lower_limb_edema !== 'absent' && (
                                        <div className="flex justify-between"><span className="text-gray-500">Œdèmes MI</span><span className="font-medium text-orange-600">{({ discrets: 'Discrets', moderes: 'Modérés', importants: 'Importants' } as Record<string, string>)[r.lower_limb_edema] || r.lower_limb_edema}</span></div>
                                    )}
                                    {r.heart_failure_signs && r.heart_failure_signs.length > 0 && (
                                        <div className="flex justify-between"><span className="text-gray-500">Signes IC</span><span className="font-medium text-orange-600 text-right max-w-[65%]">{r.heart_failure_signs.join(', ')}</span></div>
                                    )}
                                    <div className="flex justify-between"><span className="text-gray-500">Poids</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.patient_weight ? `${r.patient_weight} kg` : '—'}</span></div>
                                    <div className="flex justify-between"><span className="text-gray-500">Taille</span><span className="font-medium text-gray-700 dark:text-gray-300">{r.patient_height ? `${r.patient_height} cm` : '—'}</span></div>
                                </div>
                            </div>
                            {r.free_notes && (
                                <div className="bg-gray-50 dark:bg-gray-700/30 rounded-xl p-3">
                                    <h4 className="text-[11px] font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-2">Notes</h4>
                                    <p className="text-xs text-gray-600 dark:text-gray-400 whitespace-pre-line">{r.free_notes}</p>
                                </div>
                            )}
                        </div>
                    </div>
                </>
            )}

            {/* Evolution Modal */}
            {showEvolution && (
                <CardioEvolutionModal
                    isOpen={showEvolution}
                    onClose={() => setShowEvolution(false)}
                    reports={allReports}
                    patientName={patientName}
                />
            )}
        </div>
    );
}