// Section components barrel export

export { PrescriptionsSection } from './PrescriptionsSection';

export { InvoicesSection } from './InvoicesSection';

export { MedicalReportsSection, medicalReportKeys, cardiologyReportKeys } from './MedicalReportsSection';

export { PatientProfile } from './PatientProfile';

export { AppointmentsSection } from './AppointmentsSection';

export { DentalActsSection } from './DentalActsSection';
export { DentalModuleSection } from './DentalModuleSection';
export { ParodontalStatusSection } from '@/features/dental/components';
export { OpticalCorrectionsSection } from './OpticalCorrectionsSection';
export { CardiologieActsSection } from './CardiologieActsSection';
