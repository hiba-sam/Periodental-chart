'use client';

import React, { useState } from 'react';
import dynamic from 'next/dynamic';
import { PlusIcon, TableCellsIcon, ChartBarIcon, ClockIcon } from '@heroicons/react/24/outline';
import { ParodontalStatusSection } from '@/features/dental/components';

const DentalActHistory = dynamic(() => import('@/features/dental/components/DentalActHistory'), {
    loading: () => <div className="animate-pulse bg-white dark:bg-gray-800 rounded-2xl h-96" />,
    ssr: false,
});

const DynamicDentalActModal = dynamic(() => import('@/features/dental/components/DentalActModal'), {
    loading: () => <div className="animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg h-96" />,
    ssr: false,
});

interface DentalModuleSectionProps {
    patientId: string;
    patientName?: string;
    currentUserId: number;
    isVisible: boolean;
}

type TabType = 'acts' | 'perio';

export function DentalModuleSection({ patientId, patientName, currentUserId, isVisible }: DentalModuleSectionProps) {
    const [activeTab, setActiveTab] = useState<TabType>('acts');
    const [showActsModal, setShowActsModal] = useState(false);
    const [selectedAct, setSelectedAct] = useState<any>(null);
    const [refreshTrigger, setRefreshTrigger] = useState(0);

    const [isCreating, setIsCreating] = useState(false);
    const perioRef = React.useRef<any>(null);

    if (!isVisible) return null;

    const handleViewDetail = (act: any) => {
        setSelectedAct(act);
        setShowActsModal(true);
    };

    const handleModalClose = () => {
        setShowActsModal(false);
        setSelectedAct(null);
    };

    const handleSuccess = () => {
        setRefreshTrigger((prev) => prev + 1);
        handleModalClose();
    };

    const isReadOnly = selectedAct && selectedAct.doctor_user_id !== currentUserId;

    return (
        <div className="mb-10">
            <div className="flex justify-between items-end mb-0 px-2 relative">
                <div className="flex gap-1">
                    <button
                        onClick={() => setActiveTab('acts')}
                        className={`flex items-center gap-2 px-8 py-3 text-sm font-black rounded-t-2xl transition-all border-b-0 ${
                            activeTab === 'acts'
                                ? 'bg-white dark:bg-gray-800 text-cyan-600 shadow-[0_-4px_10px_rgba(0,0,0,0.03)] border-x border-t border-gray-100 dark:border-gray-700'
                                : 'text-gray-400 dark:text-gray-500 hover:text-cyan-600 hover:bg-white/50 dark:hover:bg-gray-800/50'
                        }`}
                    >
                        <TableCellsIcon className="w-4 h-4" /> Actes Dentaires
                    </button>
                    <button
                        onClick={() => setActiveTab('perio')}
                        className={`flex items-center gap-2 px-8 py-3 text-sm font-black rounded-t-2xl transition-all border-b-0 ${
                            activeTab === 'perio'
                                ? 'bg-white dark:bg-gray-800 text-cyan-600 shadow-[0_-4px_10px_rgba(0,0,0,0.03)] border-x border-t border-gray-100 dark:border-gray-700'
                                : 'text-gray-400 dark:text-gray-500 hover:text-cyan-600 hover:bg-white/50 dark:hover:bg-gray-800/50'
                        }`}
                    >
                        <ChartBarIcon className="w-4 h-4" /> Statut Parodontal
                    </button>
                </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-2xl rounded-tl-none shadow-xl shadow-gray-200/50 dark:shadow-none transition-colors border border-gray-100 dark:border-gray-700/50 relative">
                <div className="p-0 border-b border-gray-50 dark:border-gray-700/30">
                    <div className="flex items-center justify-end gap-4 px-6 py-4">
                        {activeTab === 'perio' && (
                            <div className="flex gap-2">
                                <button
                                    onClick={async () => {
                                        setIsCreating(true);
                                        await perioRef.current?.createNew();
                                        setIsCreating(false);
                                    }}
                                    disabled={isCreating}
                                    className="px-4 py-2 text-xs font-black text-white bg-cyan-600 rounded-xl hover:bg-cyan-700 transition-all shadow-lg shadow-cyan-500/20 flex items-center gap-2 uppercase tracking-widest"
                                >
                                    <PlusIcon className="w-4 h-4 stroke-[4px]" /> Nouveau
                                </button>
                                <button
                                    onClick={async () => {
                                        setIsCreating(true);
                                        await perioRef.current?.createOld();
                                        setIsCreating(false);
                                    }}
                                    disabled={isCreating}
                                    className="px-4 py-2 text-xs font-black text-white bg-amber-600 rounded-xl hover:bg-amber-700 transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2 uppercase tracking-widest"
                                >
                                    <ClockIcon className="w-4 h-4 stroke-[4px]" /> Dupliquer
                                </button>
                            </div>
                        )}
                    </div>
                </div>

                <div className="p-0 transition-all">
                    {activeTab === 'acts' ? (
                        <div className="animate-in slide-in-from-left-2 fade-in duration-300">
                            <DentalActHistory
                                patientId={patientId}
                                onAddClick={() => {
                                    setSelectedAct(null);
                                    setShowActsModal(true);
                                }}
                                onViewDetail={handleViewDetail}
                                refreshTrigger={refreshTrigger}
                                noCard={true}
                            />
                        </div>
                    ) : (
                        <div className="animate-in slide-in-from-right-2 fade-in duration-300">
                            <ParodontalStatusSection ref={perioRef} patientId={patientId} patientName={patientName} isVisible={true} noCard={true} />
                        </div>
                    )}
                </div>
            </div>

            {showActsModal && (
                <DynamicDentalActModal
                    isOpen={showActsModal}
                    onClose={handleModalClose}
                    patientId={patientId}
                    onSuccess={handleSuccess}
                    editAct={selectedAct}
                    readOnly={!!isReadOnly}
                />
            )}
        </div>
    );
}
