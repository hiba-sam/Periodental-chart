'use client';

import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// ============================================
// TYPES
// ============================================
interface MedicationItem {
    prescription_medication_id: number;
    prescription_id: number;
    prescription_date: string;
    medication_id: number | null;
    custom_medication_id: number | null;
    is_custom: boolean;
    nom_de_marque: string | null;
    dci: string | null;
    med_dosage: string | null;
    forme: string | null;
    quantity: number;
    dosage: string;
    note: string | null;
    doctor_name: string | null;
    doctor_family_name: string | null;
}

interface MedicationsData {
    current: MedicationItem[];
    history: MedicationItem[];
    prescriptionCount: number;
    latestPrescriptionDate?: string;
}

interface MedicationsSectionProps {
    patientId: string;
    isVisible: boolean;
    refreshKey?: number;
}

// ============================================
// HELPERS
// ============================================
function formatDate(d: string | null | undefined): string {
    if (!d) return '';
    try {
        return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
    } catch {
        return d;
    }
}

function getMedName(m: MedicationItem): string {
    return m.nom_de_marque || m.dci || 'Médicament inconnu';
}

function getMedSubtitle(m: MedicationItem): string {
    const parts: string[] = [];
    if (m.dci && m.nom_de_marque) parts.push(m.dci);
    if (m.med_dosage) parts.push(m.med_dosage);
    if (m.forme) parts.push(m.forme);
    return parts.join(' · ');
}

// ============================================
// SUB-COMPONENTS
// ============================================
function MedCard({ med, showDate }: { med: MedicationItem; showDate?: boolean }) {
    return (
        <div className="flex items-start gap-3 p-3 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg hover:shadow-sm transition-shadow">
            {/* Pill icon */}
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mt-0.5">
                <svg className="w-4 h-4 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />
                </svg>
            </div>

            <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                        {getMedName(med)}
                    </p>
                    {med.quantity > 0 && (
                        <span className="flex-shrink-0 text-xs font-medium px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300">
                            x{med.quantity}
                        </span>
                    )}
                </div>

                {getMedSubtitle(med) && (
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 truncate">
                        {getMedSubtitle(med)}
                    </p>
                )}

                {/* Posologie */}
                {med.dosage && (
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-1 font-medium">
                        {med.dosage}
                    </p>
                )}

                {/* Note */}
                {med.note && (
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 italic truncate">
                        {med.note}
                    </p>
                )}

                {/* Date + Doctor (for history items) */}
                {showDate && (
                    <div className="flex items-center gap-2 mt-1.5">
                        <span className="text-[10px] text-gray-400 dark:text-gray-500">
                            {formatDate(med.prescription_date)}
                        </span>
                        {med.doctor_name && (
                            <span className="text-[10px] text-gray-400 dark:text-gray-500">
                                — Dr. {med.doctor_name} {med.doctor_family_name || ''}
                            </span>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

// ============================================
// MAIN COMPONENT
// ============================================
export function MedicationsSection({ patientId, isVisible, refreshKey }: MedicationsSectionProps) {
    const [data, setData] = useState<MedicationsData | null>(null);
    const [loading, setLoading] = useState(true);
    const [showHistory, setShowHistory] = useState(false);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const res = await axios.get(`${API_URL}/patient/${patientId}/medications`, { withCredentials: true });
            if (res.data?.success) {
                setData(res.data.data);
            }
        } catch (err) {
            console.error('Failed to load medications:', err);
        } finally {
            setLoading(false);
        }
    }, [patientId]);

    useEffect(() => { loadData(); }, [loadData, refreshKey]);

    if (!isVisible) return null;

    const hasCurrent = data && data.current.length > 0;
    const hasHistory = data && data.history.length > 0;

    // Group history by prescription
    const historyByPrescription = hasHistory
        ? data!.history.reduce((acc: Record<number, MedicationItem[]>, med: MedicationItem) => {
            if (!acc[med.prescription_id]) acc[med.prescription_id] = [];
            acc[med.prescription_id].push(med);
            return acc;
        }, {})
        : {};

    return (
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
                        <svg className="w-5 h-5 text-emerald-600 dark:text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />
                        </svg>
                    </div>
                    <div>
                        <h3 className="text-base font-semibold text-gray-800 dark:text-gray-200">Médicaments</h3>
                        {data?.latestPrescriptionDate && (
                            <p className="text-[11px] text-gray-500 dark:text-gray-400">
                                Dernière prescription : {formatDate(data.latestPrescriptionDate)}
                                {data.prescriptionCount > 1 && ` · ${data.prescriptionCount} ordonnances`}
                            </p>
                        )}
                    </div>
                </div>

                {/* Toggle history */}
                {hasHistory && (
                    <button
                        onClick={() => setShowHistory(!showHistory)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                    >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        {showHistory ? 'Masquer historique' : 'Historique'}
                    </button>
                )}
            </div>

            {/* Loading */}
            {loading ? (
                <div className="flex items-center justify-center py-10">
                    <div className="animate-spin w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full" />
                </div>
            ) : !hasCurrent && !hasHistory ? (
                /* Empty state */
                <div className="text-center py-10 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl">
                    <svg className="w-10 h-10 mx-auto text-gray-300 dark:text-gray-600 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" />
                    </svg>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Aucun médicament prescrit</p>
                    <p className="text-xs text-gray-400 mt-1">Les médicaments apparaîtront automatiquement après une prescription</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {/* Current treatment */}
                    {hasCurrent && (
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400">
                                    Traitement en cours
                                </span>
                                <span className="text-[10px] text-gray-400">
                                    {data!.current.length} médicament{data!.current.length > 1 ? 's' : ''}
                                </span>
                            </div>
                            <div className="space-y-2">
                                {data!.current.map((med) => (
                                    <MedCard key={med.prescription_medication_id} med={med} />
                                ))}
                            </div>
                        </div>
                    )}

                    {/* History */}
                    {showHistory && hasHistory && (
                        <div>
                            <div className="flex items-center gap-2 mb-2 mt-3">
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400">
                                    Historique
                                </span>
                            </div>
                            <div className="space-y-3">
                                {Object.entries(historyByPrescription).map(([prescriptionId, meds]) => {
                                    const first: MedicationItem | undefined = (meds as MedicationItem[])[0];
                                    if (!first) return null;
                                    return (
                                        <div key={prescriptionId} className="border border-gray-100 dark:border-gray-700 rounded-lg p-3">
                                            <div className="flex items-center justify-between mb-2">
                                                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                                                    {formatDate(first.prescription_date)}
                                                </span>
                                                {first.doctor_name && (
                                                    <span className="text-[10px] text-gray-400 dark:text-gray-500">
                                                        Dr. {first.doctor_name} {first.doctor_family_name || ''}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="space-y-1.5">
                                                {(meds as MedicationItem[]).map((med) => (
                                                    <div key={med.prescription_medication_id} className="flex items-center gap-2 text-sm">
                                                        <span className="w-1.5 h-1.5 rounded-full bg-gray-300 dark:bg-gray-600 flex-shrink-0" />
                                                        <span className="text-gray-700 dark:text-gray-300 font-medium truncate">
                                                            {getMedName(med)}
                                                        </span>
                                                        {med.med_dosage && (
                                                            <span className="text-gray-400 text-xs flex-shrink-0">{med.med_dosage}</span>
                                                        )}
                                                        {med.quantity > 0 && (
                                                            <span className="text-gray-400 text-xs flex-shrink-0">x{med.quantity}</span>
                                                        )}
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}

export default MedicationsSection;
