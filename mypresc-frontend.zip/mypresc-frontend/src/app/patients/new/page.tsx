"use client";

import { useSearchParams } from "next/navigation";
import { NewOrUpdatePatient } from "@/features/patients/components";

export default function Page() {
  const searchParams = useSearchParams();
  const from = searchParams.get("from") || "patients";

  return <NewOrUpdatePatient backPath={from} nextPath="patients" />;
}
