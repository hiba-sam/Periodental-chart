"use client";

import { useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { PlusIcon, XMarkIcon } from "@heroicons/react/24/outline";
import { usePatients } from "@/contexts/PatientsContext";
import { useLanguage } from "@/contexts/LanguageContext";
import Link from "next/link";

import { ListSkeleton } from "@/components/feedback";

// Lazy load heavy components
const PatientsList = dynamic(
  () => import("@/features/patients/components/PatientsList"),
  { loading: () => <ListSkeleton />, ssr: false }
);

// --- PatientsPage Component ---

export default function PatientsPage() {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const { loading: contextLoading } = usePatients();
  const { t } = useLanguage();

  const isLoading = contextLoading;

  return (
    <>
      <div className="min-h-[calc(100vh-6rem)] bg-gray-50 dark:bg-gray-900">
        <div className="">
          <main className="py-6">
            <div className="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
              {/* --- Notifications --- (NO CHANGE HERE) */}
              {(error || success) && (
                <div className="p-4 mb-4">
                  {error && (
                    <div className="p-4 mb-2 border-l-4 border-red-400 bg-red-50 dark:bg-red-900/20">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <XMarkIcon className="w-5 h-5 text-red-400" />
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-red-700 dark:text-red-300">
                            {error}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {success && (
                    <div className="p-4 border-l-4 border-green-400 bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <svg
                            className="w-5 h-5 text-green-400"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-green-700 dark:text-green-300">
                            {success}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
              {/* --- End Notifications --- */}

              <div className="hidden md:flex items-center justify-between mb-6">
                <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
                  {t('patients.title')}
                </h1>
                <Link href={"/patients/new"}>
                  <button
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                    disabled={isLoading}
                  >
                    <PlusIcon className="w-4 h-4" />
                    {isLoading ? t('patients.loading') : t('patients.addPatient')}
                  </button>
                </Link>
              </div>

              <PatientsList />
            </div>
          </main>
        </div>
      </div>
    </>
  );
}
