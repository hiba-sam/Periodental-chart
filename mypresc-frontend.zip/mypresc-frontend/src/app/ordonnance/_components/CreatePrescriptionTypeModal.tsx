"use client";

import { useState, useRef, useEffect } from "react";
import Modal from "@/components/ui/Modal";
import { TrashIcon, PlusIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { usePrescription, Medication, PrescriptionMedication } from "@/contexts/PrescriptionContext";
import PosologieInput from "@/components/PosologieInput";
import { useLanguage } from "@/contexts/LanguageContext";
import { PrescriptionType } from "@/features/prescriptions/types/prescription.types";

interface CreatePrescriptionTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  initialData?: PrescriptionType | null;
}

export default function CreatePrescriptionTypeModal({ isOpen, onClose, onSuccess, initialData }: CreatePrescriptionTypeModalProps) {
  const { t } = useLanguage();
  const { searchMedications, createPrescriptionType, updatePrescriptionType } = usePrescription();
  
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [medications, setMedications] = useState<PrescriptionMedication[]>([]);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Medication[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Reset or initialize state
  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        setName(initialData.name);
        setDescription(initialData.description || "");
        
        // Map backend relation data to PrescriptionMedication format
        const mapped = (initialData.medications || []).map(m => ({
          medication_id: m.medication_id || 0,
          custom_medication_id: m.custom_medication_id || undefined,
          is_custom: m.is_custom,
          nom_de_marque: m.nom_de_marque,
          denomination_commune_internationale: m.denomination_commune_internationale,
          quantity: m.quantity,
          dosage: m.dosage,
          med_dosage: m.med_dosage,
          note: m.note
        }));
        
        setMedications(mapped);
      } else {
        setName("");
        setDescription("");
        setMedications([]);
      }
      setSearchQuery("");
      setSearchResults([]);
    }
  }, [isOpen, initialData]);

  // Handle click outside search results
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setSearchResults([]);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);

    if (value.length > 2) {
      setIsSearching(true);
      try {
        const results = await searchMedications(value, 15);
        setSearchResults(results || []);
      } catch (error) {
        console.error("Erreur recherche médicaments:", error);
      } finally {
        setIsSearching(false);
      }
    } else {
      setSearchResults([]);
    }
  };

  const handleAddMedication = (med: Medication) => {
    // Check if already added
    if (medications.some((m) => m.medication_id === med.id && !m.is_custom)) {
      return;
    }

    const newMed: PrescriptionMedication = {
      medication_id: med.id,
      nom_de_marque: med.nom_de_marque,
      denomination_commune_internationale: med.denomination_commune_internationale,
      dosage: "",
      quantity: 1,
      med_dosage: med.dosage,
      is_custom: false,
    };

    setMedications([...medications, newMed]);
    setSearchQuery("");
    setSearchResults([]);
  };

  const handleUpdateMedication = (index: number, field: keyof PrescriptionMedication, value: any) => {
    const updated = [...medications];
    updated[index] = { ...updated[index], [field]: value } as PrescriptionMedication;
    setMedications(updated);
  };

  const handleRemoveMedication = (index: number) => {
    setMedications(medications.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!name.trim()) return;
    if (medications.length === 0) return;
    // Validate that all have dosages
    if (medications.some(m => !(m.dosage || "").trim())) return;

    setIsSaving(true);
    
    // Map to API expected payload
    const payloadMedications = medications.map((med, index) => ({
      medication_id: med.medication_id || 0,
      custom_medication_id: med.custom_medication_id || null,
      is_custom: med.is_custom || false,
      quantity: med.quantity || 1,
      dosage: med.dosage,
      note: med.note || "",
      sort_order: index
    }));

    try {
      let success = false;
      if (initialData) {
        const result = await updatePrescriptionType(initialData.id, {
          name: name.trim(),
          description: description.trim() || undefined,
          medications: payloadMedications
        });
        success = !!result;
      } else {
        const result = await createPrescriptionType({
          name: name.trim(),
          description: description.trim() || undefined,
          medications: payloadMedications
        });
        success = !!result;
      }

      if (success) {
        onSuccess?.();
        onClose();
      }
    } finally {
      setIsSaving(false);
    }
  };

  const isFormValid = name.trim().length > 0 && medications.length > 0 && medications.every(m => (m.dosage || "").trim().length > 0);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={initialData ? "Modifier le modèle" : "Créer un modèle d'ordonnance"}>
      <div className="text-gray-500 mb-6 -mt-2">
        {initialData 
          ? "Modifiez cette liste de médicaments ou son nom pour vos prochaines consultations."
          : "Enregistrez une liste de médicaments pour pouvoir la réutiliser rapidement lors de vos prochaines consultations."}
      </div>

      <div className="space-y-6">
        <div className="grid grid-cols-1 gap-4">
          <div className="space-y-2">
            <label htmlFor="model-name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Nom du modèle <span className="text-red-500">*</span>
            </label>
            <input 
              id="model-name" 
              placeholder="Ex: Hypertension standard, Post-opératoire..." 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#642BEF] transition-all"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="model-desc" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Description (optionnelle)
            </label>
            <textarea 
              id="model-desc" 
              placeholder="Notes internes pour vous rappeler quand utiliser ce modèle..." 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#642BEF] transition-all resize-none h-16"
            />
          </div>
        </div>

        <div className="border-t pt-6" ref={searchContainerRef}>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Ajouter des médicaments <span className="text-red-500">*</span>
          </label>
          
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="w-full pl-10 pr-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#642BEF] transition-all"
              placeholder={t('prescription.form.searchPlaceholder') || "Rechercher par nom de marque, DCI, forme..."}
              value={searchQuery}
              onChange={handleSearch}
            />
            
            {/* Search Results Dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute z-50 mt-1 w-full bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-100 dark:border-gray-700 max-h-60 overflow-y-auto">
                {searchResults.map((med) => (
                  <div
                    key={med.id}
                    onClick={() => handleAddMedication(med)}
                    className="px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 cursor-pointer border-b border-gray-50 dark:border-gray-700/50 last:border-0"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">
                          {med.nom_de_marque}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {med.denomination_commune_internationale}
                        </p>
                      </div>
                      <div className="text-right flex space-x-2 space-x-reverse ml-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                          {med.dosage}
                        </span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300">
                          {med.forme}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Medications List */}
        {medications.length > 0 ? (
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300">Médicaments du modèle ({medications.length})</h4>
            
            {medications.map((med, index) => (
              <div key={`${med.medication_id}-${index}`} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg p-4 shadow-sm relative">
                <button
                  onClick={() => handleRemoveMedication(index)}
                  className="absolute top-4 right-4 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <TrashIcon className="h-5 w-5" />
                </button>

                <div className="pr-10">
                  <h4 className="font-bold text-gray-900 dark:text-white">{med.nom_de_marque}</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-4 truncate">
                    {med.denomination_commune_internationale} {med.med_dosage && `- ${med.med_dosage}`}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div className="md:col-span-8">
                      <PosologieInput
                        value={med.dosage || ""}
                        onChange={(val) => handleUpdateMedication(index, "dosage", val)}
                      />
                    </div>
                    
                    <div className="md:col-span-4">
                      <label className="text-xs text-gray-500 mb-1 block">Quantité</label>
                      <div className="flex bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden h-[42px]">
                        <button
                          type="button"
                          onClick={() => handleUpdateMedication(index, "quantity", Math.max(1, (med.quantity || 1) - 1))}
                          className="px-3 py-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors disabled:opacity-50"
                          disabled={med.quantity <= 1}
                        >
                          -
                        </button>
                        <div className="flex-1 flex items-center justify-center font-medium border-x border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                          {med.quantity}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleUpdateMedication(index, "quantity", (med.quantity || 1) + 1)}
                          className="px-3 py-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                        >
                          +
                        </button>
                      </div>
                    </div>
                    
                    <div className="md:col-span-12">
                      <label className="text-xs text-gray-500 mb-1 block">Note (optionnelle)</label>
                      <input
                        placeholder="Remarque spécifique pour ce médicament dans ce modèle..."
                        value={med.note || ""}
                        onChange={(e) => handleUpdateMedication(index, "note", e.target.value)}
                        className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#642BEF] transition-all"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-dashed border-gray-300 dark:border-gray-700">
            <div className="w-12 h-12 bg-white dark:bg-gray-800 shadow-sm border border-gray-100 dark:border-gray-700 rounded-full flex items-center justify-center mx-auto mb-3">
              <PlusIcon className="h-6 w-6 text-gray-400" />
            </div>
            <p className="text-gray-500 dark:text-gray-400">Aucun médicament ajouté à ce modèle.</p>
            <p className="text-sm text-gray-400 mt-1">Recherchez ci-dessus pour commencer.</p>
          </div>
        )}
      </div>

      <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-800 flex flex-col-reverse sm:flex-row sm:justify-end gap-3">
        <button
          onClick={onClose}
          className="px-6 py-2.5 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        >
          Annuler
        </button>
        <button
          onClick={handleSave}
          disabled={!isFormValid || isSaving}
          className="px-6 py-2.5 rounded-lg text-sm font-medium bg-gradient-to-r from-[#642BEF] to-[#BF1D8E] text-white shadow-sm hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSaving ? "Enregistrement..." : (initialData ? "Mettre à jour" : "Enregistrer le modèle")}
        </button>
      </div>
    </Modal>
  );
}
