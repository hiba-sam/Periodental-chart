"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import {
  CalendarDaysIcon,
  ClockIcon,
  UsersIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/outline";
import Header from "@/components/Header";
import { Appointment, useAppointmentsContext } from "@/contexts/AppointmentContext";
import { usePatients } from "@/contexts/PatientsContext";
import Modal from "@/components/ui/Modal";
import { useWaitingRoom } from "@/contexts/WaitingRoomContext";
import { useLanguage } from "@/contexts/LanguageContext";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";

// Feature imports
import { useDashboardStats, QuickStats, PatientStatsChart, StatsCard } from "@/features/dashboard";

// Skeleton component for loading states - Fixed dimensions to prevent CLS
const ChartSkeleton = () => (
  <div className="animate-pulse min-h-[320px]">
    <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4"></div>
    <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
  </div>
);

const ListSkeleton = () => (
  <div className="animate-pulse space-y-3 min-h-[280px]">
    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
    {[1, 2, 3].map((i) => (
      <div key={i} className="h-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
    ))}
  </div>
);

// Lazy load heavy components
const PaymentChart = dynamic(
  () => import("@/components/dashboard/PaymentChart"),
  { loading: () => <ChartSkeleton />, ssr: false }
);

const UpcomingAppointments = dynamic(
  () => import("@/components/dashboard/UpcomingAppointments"),
  { loading: () => <ListSkeleton />, ssr: false }
);

const RecentPatients = dynamic(
  () => import("@/components/dashboard/RecentPatients"),
  { loading: () => <ListSkeleton />, ssr: false }
);

const DailyInvoices = dynamic(
  () => import("@/components/dashboard/DailyInvoices"),
  { loading: () => <ChartSkeleton />, ssr: false }
);

const WaitingEntriesModal = dynamic(
  () => import("@/components/dashboard/WaitingEntriesModal"),
  { ssr: false }
);


export default function DashboardPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  const { appointments, fetchAppointments } = useAppointmentsContext();
  const { patients } = usePatients();
  const { entries, fetchEntries, getTodaySchedule, peekNextPatient, callNextPatient, currentCall } = useWaitingRoom();
  const [showCallPopup, setShowCallPopup] = useState(false);
  const [calledPatient, setCalledPatient] = useState<{ patientName: string } | null>(null);
  const [pendingPatient, setPendingPatient] = useState<{ patientName: string } | null>(null);
  const [isConfirming, setIsConfirming] = useState(false);
  const [showNoPatientMessage, setShowNoPatientMessage] = useState(false);

  const [activeChartTab, setActiveChartTab] = useState("paiements");

  // Use the new dashboard stats hook
  const { stats, todayAppointments, isLoading, refetch: refetchStats } = useDashboardStats(user?.id);

  const [appointmentsModalOpen, setAppointmentsModalOpen] = useState<
    null | "all" | "today" | "completed"
  >(null);
  const [waitingModalOpen, setWaitingModalOpen] = useState(false);

  // Fetch context data on mount
  useEffect(() => {
    if (!user?.id) return;
    fetchEntries(user.id, 50, 0);
    fetchAppointments();
  }, [user?.id, fetchEntries, fetchAppointments]);


  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center justify-center animate-pulse">
          <div className="w-16 h-16 mb-4 bg-blue-400 rounded-full"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">{t('dashboard.loadingDashboard')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      {/* Main Content Area: Responsive adjustments */}
      <div
        style={{
          [isRTL ? 'marginRight' : 'marginLeft']: '100px',
        }}
        className="flex-1 overflow-y-auto"
      >
        <div className="p-4 dashboard-content sm:p-6 lg:p-8">
          <Header />

          {/* Main Dashboard Header & Action */}
          <div className="flex flex-col items-start justify-between mb-8 sm:flex-row sm:items-center sm:mb-10">
            <div>
              <h1 className="text-3xl font-extrabold tracking-tight text-gray-800 dark:text-gray-100 sm:text-4xl">
                {user?.role === 'assistant' ? t('dashboard.title.assistant') : t('dashboard.title.doctor')}
              </h1>
              <p className="mt-1 text-base text-gray-500 dark:text-gray-400 sm:mt-2 sm:text-lg">
                {t('dashboard.subtitle')}
              </p>
            </div>
            <div className="flex gap-3 mt-4 sm:mt-0 min-h-[48px] items-center">
              {user?.role === 'doctor' && (
                <button
                  onClick={async () => {
                    if (user?.id) {
                      // D'abord, récupérer le prochain patient SANS le marquer comme servi
                      const result = await peekNextPatient(user.id);
                      if (result) {
                        setPendingPatient({ patientName: result.patientName });
                        setShowCallPopup(true);
                        setShowNoPatientMessage(false);
                      } else {
                        setShowNoPatientMessage(true);
                        setTimeout(() => setShowNoPatientMessage(false), 3000);
                      }
                    }
                  }}
                  className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-green-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-green-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 min-w-[140px] sm:min-w-[180px] justify-center"
                >
                  {t('dashboard.nextPatient') || 'Patient suivant'}
                </button>
              )}
              {user?.role === 'assistant' && (
                <Link href={"/patients/new?from=dashboard"}>
                  <button className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-green-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-green-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 min-w-[160px] sm:min-w-[200px] justify-center">
                    <UsersIcon className="w-5 h-5 mr-2" />
                    {t('dashboard.addPatient') || 'Ajouter un patient'}
                  </button>
                </Link>
              )}
              <Link href={"/calendar"}>
                <button className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-blue-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-blue-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 min-w-[120px] sm:min-w-[160px] justify-center">
                  {t('dashboard.createAppointment')}
                </button>
              </Link>
            </div>
          </div>

          {/* Section 1: Top Stat Blocks */}
          <div className="grid grid-cols-1 gap-6 mb-6 sm:grid-cols-2 lg:grid-cols-3">
            <StatsCard
              title={t('dashboard.totalAppointments')}
              value={stats?.totalAppointments ?? 0}
              icon={<CalendarDaysIcon className="w-6 h-6 text-blue-500" />}
              onClick={() => setAppointmentsModalOpen("all")}
              isLoading={isLoading}
            />
            <StatsCard
              title={t('dashboard.completedAppointments') || 'RDV effectués'}
              value={stats?.completedAppointments ?? 0}
              icon={<CheckCircleIcon className="w-6 h-6 text-green-500" />}
              onClick={() => setAppointmentsModalOpen("completed")}
              isLoading={isLoading}
            />
            <StatsCard
              title={t('dashboard.waitingPatients')}
              value={stats?.waitingPatients ?? 0}
              icon={<UsersIcon className="w-6 h-6 text-green-500" />}
              onClick={() => setWaitingModalOpen(true)}
              isLoading={isLoading}
            />
          </div>

          {/* Section 2: Charts */}

          {user?.role === 'doctor' && (
            <div className="flex flex-col justify-center p-4 mb-8 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-sm rounded-2xl sm:p-6">
              <div className="flex mb-6 space-x-2 overflow-x-auto border-b border-gray-200 dark:border-gray-700 sm:space-x-4">
                <button
                  className={`flex-none py-2 px-3 sm:py-3 sm:px-4 font-medium text-sm transition-all duration-300 ${activeChartTab === "paiements"
                    ? "border-b-4 border-blue-600 text-blue-700 dark:text-blue-400 font-bold"
                    : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                    }`}
                  onClick={() => setActiveChartTab("paiements")}
                >
                  {t('dashboard.payments')}
                </button>
                <button
                  className={`flex-none py-2 px-3 sm:py-3 sm:px-4 font-medium text-sm transition-all duration-300 ${activeChartTab === "nouveaux-patients"
                    ? "border-b-4 border-blue-600 text-blue-700 dark:text-blue-400 font-bold"
                    : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                    }`}
                  onClick={() => setActiveChartTab("nouveaux-patients")}
                >
                  {t('dashboard.newPatients')}
                </button>
                <button
                  className={`flex-none py-2 px-3 sm:py-3 sm:px-4 font-medium text-sm transition-all duration-300 ${activeChartTab === "anciens-patients"
                    ? "border-b-4 border-blue-600 text-blue-700 dark:text-blue-400 font-bold"
                    : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
                    }`}
                  onClick={() => setActiveChartTab("anciens-patients")}
                >
                  {t('dashboard.oldPatients')}
                </button>
              </div>
              <div className="flex-grow h-full">
                {activeChartTab === "paiements" && <PaymentChart />}
                {activeChartTab === "nouveaux-patients" && <PatientStatsChart variant="new" />}
                {activeChartTab === "anciens-patients" && <PatientStatsChart variant="old" />}
              </div>
            </div>
          )}

          {user?.role === 'assistant' && (
            <DailyInvoices />
          )}

          {/* Section 3: Lists (Appointments & Patients) */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 h-full">
              <UpcomingAppointments />
            </div>
            <div>
              <RecentPatients />
            </div>
          </div>
        </div>
      </div>
      <Modal
        isOpen={appointmentsModalOpen !== null}
        onClose={() => setAppointmentsModalOpen(null)}
        title={
          appointmentsModalOpen === "completed"
            ? t('dashboard.completedAppointments') || 'RDV effectués'
            : appointmentsModalOpen === "today"
              ? t('dashboard.todayAppointmentsTitle')
              : t('dashboard.allAppointments')
        }
        zIndex={14000}
      >
        <div className="max-h-[75vh] overflow-auto">
          <table className="w-full text-left border-collapse text-base dark:text-gray-300">
            <thead>
              <tr className="text-[15px] text-gray-700 dark:text-gray-400 border-b dark:border-gray-700">
                <th className="py-3 pr-3">{t('common.patient')}</th>
                <th className="py-3 pr-3">{t('common.date')}</th>
                <th className="py-3 pr-3">{appointmentsModalOpen === "completed" ? "Heure de passage" : t('common.time')}</th>
                <th className="py-3">{t('common.notes')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {((appointmentsModalOpen === "completed" && todayAppointments)
                ? (todayAppointments.filter(app => app.is_done) || [])
                : appointmentsModalOpen === "today" && todayAppointments
                  ? (todayAppointments || [])
                  : (todayAppointments || [])
              ).map((a) => {
                const d = new Date(a.date as any);
                const dateStr = d.toLocaleDateString();
                // Pour les RDV terminés, afficher l'heure de passage (served_at) si disponible
                const servedAt = (a as any).served_at ? new Date((a as any).served_at) : null;
                const timeStr = appointmentsModalOpen === "completed" && servedAt
                  ? servedAt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
                  : (a.time || "").slice(0, 5);
                const name =
                  `${(a as any).patient_name || ""} ${(a as any).patient_family_name || ""
                    }`.trim() || a.patient_id;
                return (
                  <tr key={a.id} className="border-b dark:border-gray-800">
                    <td className="py-3 pr-3 font-medium text-gray-900 dark:text-gray-100">
                      {name}
                    </td>
                    <td className="py-3 pr-3 text-gray-700 dark:text-gray-300">{dateStr}</td>
                    <td className="py-3 pr-3 text-gray-700 dark:text-gray-300">{timeStr}</td>
                    <td className="py-3 text-gray-600 dark:text-gray-400">{a.notes || "-"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {(appointmentsModalOpen === "today"
            ? appointments.filter((a) => {
              const d = new Date(a.date as any);
              const t = new Date();
              return (
                d.getDate() === t.getDate() &&
                d.getMonth() === t.getMonth() &&
                d.getFullYear() === t.getFullYear()
              );
            })
            : appointments
          ).length === 0 && (
              <div className="py-6 text-center text-gray-500 dark:text-gray-400">
                {t('dashboard.noAppointmentsToShow')}
              </div>
            )}
        </div>
      </Modal>
      <WaitingEntriesModal
        isOpen={waitingModalOpen}
        onClose={() => setWaitingModalOpen(false)}
      />

      {/* Popup appel patient - Confirmation avant d'envoyer à l'assistant */}
      {showCallPopup && pendingPatient && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50">
          <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 text-center">
            <div className="mb-4">
              <div className="w-16 h-16 mx-auto bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                <UsersIcon className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-2">
              {t('dashboard.callPatient') || 'Appeler le patient'}
            </h2>
            <p className="text-3xl font-extrabold text-green-600 dark:text-green-400 mb-6">
              {pendingPatient.patientName}
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => {
                  setShowCallPopup(false);
                  setPendingPatient(null);
                }}
                className="px-6 py-3 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold rounded-full hover:bg-gray-300 dark:hover:bg-gray-600 transition-all"
              >
                {t('common.cancel') || 'Annuler'}
              </button>
              <button
                disabled={isConfirming}
                onClick={async () => {
                  if (user?.id) {
                    setIsConfirming(true);
                    // Maintenant on appelle vraiment le patient (marquer servi + notifier assistant)
                    const result = await callNextPatient(user.id);
                    if (result) {
                      setCalledPatient({ patientName: result.patientName });
                      await fetchAppointments();
                      // Rediriger vers le dossier médical du patient
                      if (result.patientId) {
                        router.push(`/patients/${result.patientId}`);
                      }
                    }
                    setIsConfirming(false);
                    setShowCallPopup(false);
                    setPendingPatient(null);
                  }
                }}
                className="px-6 py-3 bg-green-600 text-white font-bold rounded-full hover:bg-green-700 transition-all disabled:opacity-50"
              >
                {isConfirming ? '...' : (t('common.confirm') || 'Confirmer')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message aucun patient */}
      {showNoPatientMessage && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50">
          <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 text-center">
            <div className="mb-4">
              <div className="w-16 h-16 mx-auto bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center">
                <UsersIcon className="w-8 h-8 text-orange-600 dark:text-orange-400" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-4">
              {t('dashboard.noPatientWaiting') || 'Aucun patient en attente'}
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {t('dashboard.noPatientWaitingDesc') || 'Il n\'y a plus de patient dans la salle d\'attente.'}
            </p>
            <button
              onClick={() => setShowNoPatientMessage(false)}
              className="px-6 py-3 bg-orange-600 text-white font-bold rounded-full hover:bg-orange-700 transition-all"
            >
              OK
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
