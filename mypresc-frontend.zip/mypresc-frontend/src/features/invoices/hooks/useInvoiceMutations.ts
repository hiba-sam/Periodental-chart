// useInvoiceMutations Hook - All invoice mutation operations
// Self-contained hook for invoice CRUD mutations

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';
import { invoiceKeys } from './useInvoices';
import type { Invoice, CreateInvoicePayload, InvoiceStatus, DistributePaymentResult } from '../types';

import {
    createInvoice as createInvoiceApi,
    updateInvoiceStatus as updateInvoiceStatusApi,
    addInvoicePayment as addPaymentApi,
    distributePayment as distributePaymentApi,
    deleteInvoice as deleteInvoiceApi,
} from '../api';

// ==================== INDIVIDUAL MUTATION HOOKS ====================

/**
 * Hook to create a new invoice
 */
export function useCreateInvoice(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: createInvoiceApi,
        onSuccess: (newInvoice) => {
            // Note: Socket will handle real-time update, but we also update cache for immediate feedback
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) => {
                    if (oldInvoices.some(inv => inv.id === newInvoice.id)) {
                        return oldInvoices;
                    }
                    return [newInvoice, ...oldInvoices];
                }
            );
        },
    });
}

/**
 * Hook to update invoice status (paid/unpaid toggle)
 */
export function useUpdateInvoiceStatus(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: ({ invoiceId, status }: { invoiceId: number; status: InvoiceStatus }) =>
            updateInvoiceStatusApi(invoiceId, status),
        onSuccess: (updatedInvoice) => {
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) =>
                    oldInvoices.map(inv => (inv.id === updatedInvoice.id ? updatedInvoice : inv))
            );
        },
    });
}

/**
 * Hook to add a payment to an invoice
 */
export function useAddPayment(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: ({ invoiceId, amount }: { invoiceId: number; amount: number }) =>
            addPaymentApi(invoiceId, amount),
        onSuccess: (updatedInvoice) => {
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) =>
                    oldInvoices.map(inv => (inv.id === updatedInvoice.id ? updatedInvoice : inv))
            );
        },
    });
}

/**
 * Hook to distribute payment across multiple invoices
 */
export function useDistributePayment(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (amount: number) => distributePaymentApi(patientId, amount),
        onSuccess: (result) => {
            if (result.success && result.updatedInvoices.length > 0) {
                queryClient.setQueryData<Invoice[]>(
                    invoiceKeys.byPatient(patientId),
                    (oldInvoices = []) => {
                        const updatedMap = new Map(result.updatedInvoices.map(inv => [inv.id, inv]));
                        return oldInvoices.map(inv => updatedMap.get(inv.id) || inv);
                    }
                );
            }
        },
    });
}

/**
 * Hook to delete an invoice
 */
export function useDeleteInvoice(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: deleteInvoiceApi,
        onSuccess: (_, invoiceId) => {
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) => oldInvoices.filter(inv => inv.id !== invoiceId)
            );
        },
    });
}

// ==================== COMBINED MUTATIONS HOOK ====================

interface UseInvoiceMutationsReturn {
    // Mutations
    createInvoice: (payload: CreateInvoicePayload) => Promise<Invoice>;
    toggleInvoiceStatus: (invoiceId: number, currentStatus: InvoiceStatus) => Promise<void>;
    addPayment: (invoiceId: number, amount: number) => Promise<Invoice>;
    distributePayment: (amount: number) => Promise<DistributePaymentResult>;
    deleteInvoice: (invoiceId: number) => Promise<void>;

    // Loading states
    isCreating: boolean;
    isUpdatingStatus: boolean;
    isAddingPayment: boolean;
    isDistributing: boolean;
    isDeleting: boolean;

    // Any mutation in progress
    isAnyMutating: boolean;
}

/**
 * Combined hook for all invoice mutations
 * Provides a clean interface for invoice CRUD operations
 */
export function useInvoiceMutations(patientId: string): UseInvoiceMutationsReturn {
    const createMutation = useCreateInvoice(patientId);
    const updateStatusMutation = useUpdateInvoiceStatus(patientId);
    const addPaymentMutation = useAddPayment(patientId);
    const distributePaymentMutation = useDistributePayment(patientId);
    const deleteMutation = useDeleteInvoice(patientId);

    // Wrapped handlers
    const handleCreateInvoice = useCallback(
        async (payload: CreateInvoicePayload) => {
            return await createMutation.mutateAsync(payload);
        },
        [createMutation]
    );

    const handleToggleInvoiceStatus = useCallback(
        async (invoiceId: number, currentStatus: InvoiceStatus) => {
            const newStatus: InvoiceStatus = currentStatus === 'paid' ? 'unpaid' : 'paid';
            await updateStatusMutation.mutateAsync({ invoiceId, status: newStatus });
        },
        [updateStatusMutation]
    );

    const handleAddPayment = useCallback(
        async (invoiceId: number, amount: number) => {
            return await addPaymentMutation.mutateAsync({ invoiceId, amount });
        },
        [addPaymentMutation]
    );

    const handleDistributePayment = useCallback(
        async (amount: number) => {
            return await distributePaymentMutation.mutateAsync(amount);
        },
        [distributePaymentMutation]
    );

    const handleDeleteInvoice = useCallback(
        async (invoiceId: number) => {
            if (!confirm('Supprimer cette facture ?')) return;
            await deleteMutation.mutateAsync(invoiceId);
        },
        [deleteMutation]
    );

    const isAnyMutating =
        createMutation.isPending ||
        updateStatusMutation.isPending ||
        addPaymentMutation.isPending ||
        distributePaymentMutation.isPending ||
        deleteMutation.isPending;

    return {
        // Mutations
        createInvoice: handleCreateInvoice,
        toggleInvoiceStatus: handleToggleInvoiceStatus,
        addPayment: handleAddPayment,
        distributePayment: handleDistributePayment,
        deleteInvoice: handleDeleteInvoice,

        // Loading states
        isCreating: createMutation.isPending,
        isUpdatingStatus: updateStatusMutation.isPending,
        isAddingPayment: addPaymentMutation.isPending,
        isDistributing: distributePaymentMutation.isPending,
        isDeleting: deleteMutation.isPending,

        // Any mutation in progress
        isAnyMutating,
    };
}
