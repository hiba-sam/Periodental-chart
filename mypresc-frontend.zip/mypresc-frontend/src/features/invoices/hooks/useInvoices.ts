// useInvoices Hook - Manages invoice data with React Query and socket integration
// Self-contained hook for invoice fetching and real-time updates

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useCallback } from 'react';
import socketClient from '@/utils/socketClient';
import type { Invoice } from '../types';
import { fetchInvoicesByPatient, fetchTodayInvoices } from '../api';

// Query keys for cache management
export const invoiceKeys = {
    all: ['invoices'] as const,
    byPatient: (patientId: string) => ['invoices', 'patient', patientId] as const,
    today: () => ['invoices', 'today'] as const,
    unpaid: () => ['invoices', 'unpaid'] as const,
};

// ==================== MAIN HOOK ====================

interface UseInvoicesReturn {
    // Data
    invoices: Invoice[];

    // Loading & Error
    isLoading: boolean;
    error: Error | null;

    // Computed values
    totalUnpaid: number;
    unpaidCount: number;
    paidCount: number;

    // Actions
    refetch: () => void;
}

/**
 * Hook for patient invoices with real-time socket updates
 * 
 * Features:
 * - React Query caching
 * - Socket.io real-time updates (created, updated, deleted)
 * - Automatic cache invalidation
 */
export function useInvoices(patientId: string): UseInvoicesReturn {
    const queryClient = useQueryClient();

    // Query
    const invoicesQuery = useQuery({
        queryKey: invoiceKeys.byPatient(patientId),
        queryFn: () => fetchInvoicesByPatient(patientId),
        staleTime: 2 * 60 * 1000, // 2 minutes (shorter for invoices)
        enabled: !!patientId,
    });

    // Socket integration for real-time updates
    useEffect(() => {
        if (!patientId) return;

        const socket = socketClient.connect();
        if (!socket) return;

        // Handle new invoice created
        const handleCreated = (newInvoice: Invoice) => {
            if (newInvoice.patient_id === patientId) {
                queryClient.setQueryData<Invoice[]>(
                    invoiceKeys.byPatient(patientId),
                    (oldInvoices = []) => {
                        // Avoid duplicates
                        if (oldInvoices.some(inv => String(inv.id) === String(newInvoice.id))) {
                            return oldInvoices;
                        }
                        return [newInvoice, ...oldInvoices];
                    }
                );
            }
        };

        // Handle invoice updated
        const handleUpdated = (updatedInvoice: Invoice) => {
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) =>
                    oldInvoices.map(inv =>
                        inv.id === updatedInvoice.id ? { ...inv, ...updatedInvoice } : inv
                    )
            );
        };

        // Handle invoice deleted
        const handleDeleted = ({ id }: { id: number }) => {
            queryClient.setQueryData<Invoice[]>(
                invoiceKeys.byPatient(patientId),
                (oldInvoices = []) => oldInvoices.filter(inv => inv.id !== id)
            );
        };

        // Subscribe to socket events
        socket.on('invoice:created', handleCreated);
        socket.on('invoice:updated', handleUpdated);
        socket.on('invoice:deleted', handleDeleted);

        // Cleanup
        return () => {
            socket.off('invoice:created', handleCreated);
            socket.off('invoice:updated', handleUpdated);
            socket.off('invoice:deleted', handleDeleted);
        };
    }, [patientId, queryClient]);

    // Refetch function
    const refetch = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: invoiceKeys.byPatient(patientId) });
    }, [queryClient, patientId]);

    // Compute totals
    const invoices = invoicesQuery.data ?? [];

    const totalUnpaid = invoices
        .filter(inv => inv.status !== 'paid' && inv.status !== 'free')
        .reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0);

    const unpaidCount = invoices.filter(inv => inv.status !== 'paid' && inv.status !== 'free').length;
    const paidCount = invoices.filter(inv => inv.status === 'paid').length;

    return {
        // Data
        invoices,

        // Loading & Error
        isLoading: invoicesQuery.isLoading,
        error: invoicesQuery.error,

        // Computed values
        totalUnpaid,
        unpaidCount,
        paidCount,

        // Actions
        refetch,
    };
}

/**
 * Hook for fetching today's invoices (for dashboard)
 */
export function useTodayInvoices() {
    return useQuery({
        queryKey: invoiceKeys.today(),
        queryFn: fetchTodayInvoices,
        staleTime: 5 * 60 * 1000,
    });
}
