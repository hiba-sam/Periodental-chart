// useInvoiceForm Hook - Manages invoice creation form state
// Self-contained hook for tarification selection and custom items

import { useState, useMemo, useCallback } from 'react';

interface Tarification {
    id: number;
    service_label: string;
    price: string | number;
    description?: string;
}

interface CustomItem {
    label: string;
    price: string;
}

interface InvoiceItem {
    tarification_id?: number;
    label: string;
    price: number;
}

interface UseInvoiceFormProps {
    tarifications: Tarification[];
    onSubmit?: (items: InvoiceItem[], total: number) => Promise<void>;
}

interface UseInvoiceFormReturn {
    // Tarification selection
    selectedTarificationIds: number[];
    toggleTarification: (id: number) => void;
    selectAllTarifications: () => void;
    clearTarifications: () => void;

    // Custom items
    customItems: CustomItem[];
    addCustomItem: (label: string, price: string) => void;
    removeCustomItem: (index: number) => void;
    updateCustomItem: (index: number, field: 'label' | 'price', value: string) => void;
    clearCustomItems: () => void;

    // New item input
    newItemLabel: string;
    newItemPrice: string;
    setNewItemLabel: (value: string) => void;
    setNewItemPrice: (value: string) => void;
    handleAddNewItem: () => void;

    // Calculated values
    tarificationTotal: number;
    customTotal: number;
    calculatedTotal: number;

    // Selected tarifications for display
    selectedTarifications: Tarification[];

    // Form validation
    isValid: boolean;
    hasItems: boolean;

    // Build payload
    buildPayload: () => InvoiceItem[];

    // Reset form
    resetForm: () => void;
}

/**
 * Hook for invoice creation form
 * Manages tarification selection, custom items, and total calculation
 */
export function useInvoiceForm({ tarifications, onSubmit }: UseInvoiceFormProps): UseInvoiceFormReturn {
    // Tarification selection state
    const [selectedTarificationIds, setSelectedTarificationIds] = useState<number[]>([]);

    // Custom items state
    const [customItems, setCustomItems] = useState<CustomItem[]>([]);

    // New item input state
    const [newItemLabel, setNewItemLabel] = useState('');
    const [newItemPrice, setNewItemPrice] = useState('');

    // ==================== TARIFICATION HANDLERS ====================

    const toggleTarification = useCallback((id: number) => {
        setSelectedTarificationIds(prev =>
            prev.includes(id) ? prev.filter(tid => tid !== id) : [...prev, id]
        );
    }, []);

    const selectAllTarifications = useCallback(() => {
        setSelectedTarificationIds(tarifications.map(t => t.id));
    }, [tarifications]);

    const clearTarifications = useCallback(() => {
        setSelectedTarificationIds([]);
    }, []);

    // ==================== CUSTOM ITEM HANDLERS ====================

    const addCustomItem = useCallback((label: string, price: string) => {
        if (!label.trim() || !price.trim()) return;
        setCustomItems(prev => [...prev, { label: label.trim(), price: price.trim() }]);
    }, []);

    const removeCustomItem = useCallback((index: number) => {
        setCustomItems(prev => prev.filter((_, i) => i !== index));
    }, []);

    const updateCustomItem = useCallback((index: number, field: 'label' | 'price', value: string) => {
        setCustomItems(prev =>
            prev.map((item, i) => (i === index ? { ...item, [field]: value } : item))
        );
    }, []);

    const clearCustomItems = useCallback(() => {
        setCustomItems([]);
    }, []);

    // ==================== NEW ITEM HANDLERS ====================

    const handleAddNewItem = useCallback(() => {
        if (!newItemLabel.trim() || !newItemPrice.trim()) return;
        addCustomItem(newItemLabel, newItemPrice);
        setNewItemLabel('');
        setNewItemPrice('');
    }, [newItemLabel, newItemPrice, addCustomItem]);

    // ==================== CALCULATIONS ====================

    const selectedTarifications = useMemo(
        () => tarifications.filter(t => selectedTarificationIds.includes(t.id)),
        [tarifications, selectedTarificationIds]
    );

    const tarificationTotal = useMemo(
        () => selectedTarifications.reduce((sum, t) => sum + Number(t.price), 0),
        [selectedTarifications]
    );

    const customTotal = useMemo(
        () =>
            customItems.reduce((sum, item) => {
                const price = parseFloat(item.price);
                return sum + (isNaN(price) ? 0 : price);
            }, 0),
        [customItems]
    );

    const calculatedTotal = useMemo(
        () => tarificationTotal + customTotal,
        [tarificationTotal, customTotal]
    );

    // ==================== VALIDATION ====================

    const hasItems = selectedTarificationIds.length > 0 || customItems.filter(i => i.label && i.price).length > 0;
    const isValid = hasItems && calculatedTotal >= 0;

    // ==================== BUILD PAYLOAD ====================

    const buildPayload = useCallback((): InvoiceItem[] => {
        const tarificationItems = selectedTarifications.map(t => ({
            tarification_id: t.id,
            label: t.service_label,
            price: Number(t.price),
        }));

        const customItemsPayload = customItems
            .filter(i => i.label && i.price)
            .map(i => ({
                label: i.label,
                price: parseFloat(i.price),
            }));

        return [...tarificationItems, ...customItemsPayload];
    }, [selectedTarifications, customItems]);

    // ==================== RESET ====================

    const resetForm = useCallback(() => {
        setSelectedTarificationIds([]);
        setCustomItems([]);
        setNewItemLabel('');
        setNewItemPrice('');
    }, []);

    return {
        // Tarification selection
        selectedTarificationIds,
        toggleTarification,
        selectAllTarifications,
        clearTarifications,

        // Custom items
        customItems,
        addCustomItem,
        removeCustomItem,
        updateCustomItem,
        clearCustomItems,

        // New item input
        newItemLabel,
        newItemPrice,
        setNewItemLabel,
        setNewItemPrice,
        handleAddNewItem,

        // Calculated values
        tarificationTotal,
        customTotal,
        calculatedTotal,

        // Selected tarifications for display
        selectedTarifications,

        // Form validation
        isValid,
        hasItems,

        // Build payload
        buildPayload,

        // Reset form
        resetForm,
    };
}
