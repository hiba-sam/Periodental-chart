'use client';

// TarificationSelector Component - Select service tarifications for invoice
// Subcomponent of InvoiceForm

import React from 'react';
import { CheckCircleIcon } from '@heroicons/react/24/outline';

interface Tarification {
    id: number;
    service_label: string;
    price: string | number;
    description?: string;
}

interface TarificationSelectorProps {
    tarifications: Tarification[];
    selectedIds: number[];
    onToggle: (id: number) => void;
    onSelectAll: () => void;
    onClearAll: () => void;
}

/**
 * Format price with currency
 */
function formatPrice(price: string | number): string {
    const numPrice = typeof price === 'string' ? parseFloat(price) : price;
    return `${numPrice.toLocaleString('fr-DZ')} DA`;
}

/**
 * TarificationSelector - Grid of selectable tarifications
 */
export function TarificationSelector({
    tarifications,
    selectedIds,
    onToggle,
    onSelectAll,
    onClearAll,
}: TarificationSelectorProps) {
    const selectedCount = selectedIds.length;

    return (
        <div className="space-y-4">
            {/* Header with actions */}
            <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Services ({selectedCount} sélectionné{selectedCount > 1 ? 's' : ''})
                </h4>
                <div className="flex gap-2">
                    <button
                        type="button"
                        onClick={onSelectAll}
                        className="text-xs text-blue-600 hover:text-blue-700 dark:text-blue-400"
                    >
                        Tout sélectionner
                    </button>
                    {selectedCount > 0 && (
                        <button
                            type="button"
                            onClick={onClearAll}
                            className="text-xs text-gray-500 hover:text-gray-600 dark:text-gray-400"
                        >
                            Effacer
                        </button>
                    )}
                </div>
            </div>

            {/* Tarifications grid */}
            {tarifications.length > 0 ? (
                <div className="grid grid-cols-2 gap-3 max-h-[250px] overflow-y-auto">
                    {tarifications.map((tarif) => {
                        const isSelected = selectedIds.includes(tarif.id);
                        return (
                            <button
                                key={tarif.id}
                                type="button"
                                onClick={() => onToggle(tarif.id)}
                                className={`relative text-left p-4 rounded-xl border-2 transition-all ${isSelected
                                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20'
                                        : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                                    }`}
                            >
                                {isSelected && (
                                    <div className="absolute top-2 right-2">
                                        <CheckCircleIcon className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                                    </div>
                                )}
                                <div className="pr-6">
                                    <span className="block font-semibold text-sm text-gray-900 dark:text-white mb-1 line-clamp-2">
                                        {tarif.service_label}
                                    </span>
                                    <span className={`text-lg font-bold ${isSelected
                                            ? 'text-emerald-600 dark:text-emerald-400'
                                            : 'text-gray-700 dark:text-gray-300'
                                        }`}>
                                        {formatPrice(tarif.price)}
                                    </span>
                                </div>
                            </button>
                        );
                    })}
                </div>
            ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <p className="text-sm">Aucune tarification configurée</p>
                    <p className="text-xs mt-1">Ajoutez des tarifications dans vos paramètres</p>
                </div>
            )}
        </div>
    );
}

export default TarificationSelector;
