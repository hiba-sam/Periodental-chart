// Invoice API - All invoice-related API calls
// Self-contained API layer for the invoices feature

import axios from 'axios';
import type {
    Invoice,
    CreateInvoicePayload,
    InvoiceStatus,
    InvoiceStatistics,
    PatientUnpaidSummary,
    DistributePaymentResult,
} from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Create axios instance for invoice API
// Backend uses /consultation-invoice endpoint
const invoiceApi = axios.create({
    baseURL: `${API_URL}/consultation-invoice`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

// ==================== INVOICE CRUD ====================

/**
 * Fetch all invoices for a patient
 */
export async function fetchInvoicesByPatient(patientId: string): Promise<Invoice[]> {
    const response = await invoiceApi.get(`/patient/${patientId}`);
    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to fetch invoices');
}

/**
 * Fetch today's invoices
 */
export async function fetchTodayInvoices(): Promise<Invoice[]> {
    const response = await invoiceApi.get('/today');
    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to fetch today invoices');
}

/**
 * Create a new invoice
 */
export async function createInvoice(payload: CreateInvoicePayload): Promise<Invoice> {
    const response = await invoiceApi.post('/', payload);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to create invoice');
}

/**
 * Update invoice status
 */
export async function updateInvoiceStatus(invoiceId: number, status: InvoiceStatus): Promise<Invoice> {
    const response = await invoiceApi.put(`/${invoiceId}/status`, { status });
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to update invoice status');
}

/**
 * Delete an invoice
 */
export async function deleteInvoice(invoiceId: number): Promise<boolean> {
    const response = await invoiceApi.delete(`/${invoiceId}`);
    return response.data.success;
}

// ==================== PAYMENTS ====================

/**
 * Add a payment to an invoice
 */
export async function addInvoicePayment(invoiceId: number, amount: number): Promise<Invoice> {
    const response = await invoiceApi.post(`/${invoiceId}/payment`, { amount });
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to add payment');
}

/**
 * Distribute payment across multiple invoices for a patient
 */
export async function distributePayment(patientId: string, amount: number): Promise<DistributePaymentResult> {
    const response = await invoiceApi.post('/distribute-payment', {patientId, amount });
    if (response.data.success) {
        return {
            success: true,
            updatedInvoices: response.data.data.updatedInvoices || [],
            remainingAmount: response.data.data.remainingAmount,
        };
    }
    throw new Error(response.data.error || 'Failed to distribute payment');
}

// ==================== STATISTICS ====================

/**
 * Fetch payment/invoice statistics
 */
export async function fetchInvoiceStatistics(): Promise<InvoiceStatistics | null> {
    try {
        const response = await invoiceApi.get('/statistics');
        if (response.data.success) {
            return response.data.data;
        }
    } catch {
        // Silently fail
    }
    return null;
}

/**
 * Fetch unpaid invoices grouped by patient
 */
export async function fetchUnpaidByPatient(searchTerm?: string): Promise<PatientUnpaidSummary[]> {
    const params = searchTerm ? `?search=${encodeURIComponent(searchTerm)}` : '';
    const response = await invoiceApi.get(`/unpaid-by-patient${params}`);
    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to fetch unpaid invoices');
}

/**
 * Calculate total unpaid amount for a list of invoices
 */
export function calculateTotalUnpaid(invoices: Invoice[]): number {
    return invoices
        .filter((inv) => inv.status !== 'paid' && inv.status !== 'free')
        .reduce((sum, inv) => sum + (parseFloat(inv.total_price) - parseFloat(inv.amount_paid || '0')), 0);
}

/**
 * Calculate remaining amount for a single invoice
 */
export function calculateRemainingAmount(invoice: Invoice): number {
    return parseFloat(invoice.total_price) - parseFloat(invoice.amount_paid || '0');
}
