'use client';

import { useState, useCallback } from 'react';
import type { OdontogramProps, ToothProps, ToothSurface } from '../types';
import { SURFACE_LABELS, TOOTH_QUADRANTS } from '../types';

const SURFACES: ToothSurface[] = ['O', 'M', 'D', 'B', 'L'];

function Tooth({ number, isSelected, selectedSurfaces, onSelect, onSurfaceSelect, disabled, showSurfaces, position }: ToothProps) {
    const [showSurfacePopup, setShowSurfacePopup] = useState(false);

    const handleClick = () => {
        if (disabled) return;
        onSelect();
        if (showSurfaces && !isSelected) {
            setShowSurfacePopup(true);
        }
    };

    const handleSurfaceClick = (e: React.MouseEvent, surface: string) => {
        e.stopPropagation();
        onSurfaceSelect(surface);
    };

    // Determine tooth type for shape
    const toothNum = parseInt(number.slice(-1));
    const isMolar = toothNum >= 6;
    const isPremolar = toothNum >= 4 && toothNum <= 5;
    const isCanine = toothNum === 3;

    const getToothPath = () => {
        if (isMolar) {
            return position === 'upper'
                ? "M4 2h24c2 0 4 2 4 4v16c0 4-2 8-6 10h-20c-4-2-6-6-6-10V6c0-2 2-4 4-4z"
                : "M4 30h24c2 0 4-2 4-4V10c0-4-2-8-6-10h-20c-4 2-6 6-6 10v16c0 2 2 4 4 4z";
        }
        if (isPremolar) {
            return position === 'upper'
                ? "M6 2h20c2 0 4 2 4 4v14c0 4-2 8-5 10h-18c-3-2-5-6-5-10V6c0-2 2-4 4-4z"
                : "M6 30h20c2 0 4-2 4-4V12c0-4-2-8-5-10h-18c-3 2-5 6-5 10v14c0 2 2 4 4 4z";
        }
        if (isCanine) {
            return position === 'upper'
                ? "M10 2h12c2 0 3 2 3 4v12c0 6-3 12-7 14h-4c-4-2-7-8-7-14V6c0-2 1-4 3-4z"
                : "M10 30h12c2 0 3-2 3-4V14c0-6-3-12-7-14h-4c-4 2-7 8-7 14v12c0 2 1 4 3 4z";
        }
        // Incisor
        return position === 'upper'
            ? "M8 2h16c2 0 3 1 3 3v14c0 4-2 8-5 11h-12c-3-3-5-7-5-11V5c0-2 1-3 3-3z"
            : "M8 30h16c2 0 3-1 3-3V13c0-4-2-8-5-11h-12c-3 3-5 7-5 11v14c0 2 1 3 3 3z";
    };

    return (
        <div className="relative flex flex-col items-center flex-1 min-w-0">
            <svg
                viewBox="-1 -2 34 40"
                className={`w-full h-auto max-w-[40px] cursor-pointer transition-all ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:scale-110'}`}
                onClick={handleClick}
            >
                <path
                    d={getToothPath()}
                    fill={isSelected ? '#0891b2' : '#f3f4f6'}
                    stroke={isSelected ? '#0e7490' : '#d1d5db'}
                    strokeWidth="1.5"
                    className="transition-colors"
                />
                <text
                    x="16"
                    y={position === 'upper' ? "17" : "20"}
                    textAnchor="middle"
                    fontSize="8"
                    fill={isSelected ? 'white' : '#6b7280'}
                    fontWeight="500"
                >
                    {number}
                </text>
            </svg>

            {/* Surface indicators */}
            {isSelected && selectedSurfaces.length > 0 && (
                <div className="flex gap-0.5 mt-0.5">
                    {selectedSurfaces.map(s => (
                        <span key={s} className="w-3 h-3 bg-cyan-500 text-white text-[8px] rounded flex items-center justify-center">
                            {s}
                        </span>
                    ))}
                </div>
            )}

            {/* Surface selection popup */}
            {showSurfacePopup && isSelected && showSurfaces && (
                <div className="absolute z-50 top-full mt-1 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-2">
                    <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Surfaces:</div>
                    <div className="flex gap-1">
                        {SURFACES.map(surface => (
                            <button
                                key={surface}
                                onClick={(e) => handleSurfaceClick(e, surface)}
                                className={`w-6 h-6 text-xs font-medium rounded transition-colors ${selectedSurfaces.includes(surface)
                                        ? 'bg-cyan-600 text-white'
                                        : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-cyan-100'
                                    }`}
                                title={SURFACE_LABELS[surface]}
                            >
                                {surface}
                            </button>
                        ))}
                    </div>
                    <button
                        onClick={(e) => { e.stopPropagation(); setShowSurfacePopup(false); }}
                        className="w-full mt-1 text-xs text-gray-500 hover:text-gray-700"
                    >
                        Fermer
                    </button>
                </div>
            )}
        </div>
    );
}

export default function Odontogram({
    selectedTeeth,
    selectedSurfaces,
    onToothSelect,
    onSurfaceSelect,
    disabled = false,
    showSurfaces = true,
    readOnly = false
}: OdontogramProps) {
    const isDisabled = disabled || readOnly;

    const handleToothSelect = useCallback((tooth: string) => {
        onToothSelect(tooth);
    }, [onToothSelect]);

    const handleSurfaceSelect = useCallback((tooth: string, surface: string) => {
        onSurfaceSelect(tooth, surface);
    }, [onSurfaceSelect]);

    return (
        <div className="w-full">
            {/* Legend */}
            <div className="flex justify-center gap-4 mb-3 text-xs">
                <div className="flex items-center gap-1">
                    <div className="w-4 h-4 bg-gray-100 border border-gray-300 rounded"></div>
                    <span className="text-gray-600 dark:text-gray-400">Non sélectionné</span>
                </div>
                <div className="flex items-center gap-1">
                    <div className="w-4 h-4 bg-cyan-600 rounded"></div>
                    <span className="text-gray-600 dark:text-gray-400">Sélectionné</span>
                </div>
            </div>

            {/* Upper Jaw */}
            <div className="mb-6">
                <div className="text-center text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                    MAXILLAIRE (Haut)
                </div>
                <div className="flex justify-center w-full">
                    {/* Upper Right (18-11) */}
                    <div className="flex flex-1 justify-end gap-[2px] border-r-2 border-gray-300 pr-1 mr-1 max-w-[50%]">
                        {TOOTH_QUADRANTS.UPPER_RIGHT.map(tooth => (
                            <Tooth
                                key={tooth}
                                number={tooth}
                                isSelected={selectedTeeth.includes(tooth)}
                                selectedSurfaces={selectedSurfaces[tooth] || []}
                                onSelect={() => handleToothSelect(tooth)}
                                onSurfaceSelect={(s) => handleSurfaceSelect(tooth, s)}
                                disabled={isDisabled}
                                showSurfaces={showSurfaces}
                                position="upper"
                            />
                        ))}
                    </div>
                    {/* Upper Left (21-28) */}
                    <div className="flex flex-1 gap-[2px] max-w-[50%]">
                        {TOOTH_QUADRANTS.UPPER_LEFT.map(tooth => (
                            <Tooth
                                key={tooth}
                                number={tooth}
                                isSelected={selectedTeeth.includes(tooth)}
                                selectedSurfaces={selectedSurfaces[tooth] || []}
                                onSelect={() => handleToothSelect(tooth)}
                                onSurfaceSelect={(s) => handleSurfaceSelect(tooth, s)}
                                disabled={isDisabled}
                                showSurfaces={showSurfaces}
                                position="upper"
                            />
                        ))}
                    </div>
                </div>
            </div>

            {/* Divider */}
            <div className="flex items-center justify-center gap-4 my-4">
                <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
                <span className="text-xs text-gray-400">Ligne occlusale</span>
                <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
            </div>

            {/* Lower Jaw */}
            <div>
                <div className="flex justify-center w-full">
                    {/* Lower Right (48-41) - Patient's right side, displayed on left of screen */}
                    <div className="flex flex-1 justify-end gap-[2px] border-r-2 border-gray-300 pr-1 mr-1 max-w-[50%]">
                        {TOOTH_QUADRANTS.LOWER_RIGHT.map(tooth => (
                            <Tooth
                                key={tooth}
                                number={tooth}
                                isSelected={selectedTeeth.includes(tooth)}
                                selectedSurfaces={selectedSurfaces[tooth] || []}
                                onSelect={() => handleToothSelect(tooth)}
                                onSurfaceSelect={(s) => handleSurfaceSelect(tooth, s)}
                                disabled={isDisabled}
                                showSurfaces={showSurfaces}
                                position="lower"
                            />
                        ))}
                    </div>
                    {/* Lower Left (31-38) - Patient's left side, displayed on right of screen */}
                    <div className="flex flex-1 gap-[2px] max-w-[50%]">
                        {TOOTH_QUADRANTS.LOWER_LEFT.map(tooth => (
                            <Tooth
                                key={tooth}
                                number={tooth}
                                isSelected={selectedTeeth.includes(tooth)}
                                selectedSurfaces={selectedSurfaces[tooth] || []}
                                onSelect={() => handleToothSelect(tooth)}
                                onSurfaceSelect={(s) => handleSurfaceSelect(tooth, s)}
                                disabled={isDisabled}
                                showSurfaces={showSurfaces}
                                position="lower"
                            />
                        ))}
                    </div>
                </div>
                <div className="text-center text-xs font-medium text-gray-500 dark:text-gray-400 mt-2">
                    MANDIBULE (Bas)
                </div>
            </div>

            {/* Surface Legend */}
            {showSurfaces && (
                <div className="mt-6 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2">Légende des surfaces:</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2 text-xs">
                        {SURFACES.map(s => (
                            <div key={s} className="flex items-center gap-2 min-w-0">
                                <span className="w-5 h-5 bg-cyan-100 text-cyan-700 rounded flex items-center justify-center font-medium flex-shrink-0">{s}</span>
                                <span className="text-gray-600 dark:text-gray-400 truncate">{SURFACE_LABELS[s]}</span>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
