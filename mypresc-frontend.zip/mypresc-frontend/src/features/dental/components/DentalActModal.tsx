'use client';

import { useState, useEffect, useCallback } from 'react';
import Modal from '@/components/ui/Modal';
import Odontogram from './Odontogram';
import { toast } from '@/components/ui/use-toast';
import { MagnifyingGlassIcon, XMarkIcon } from '@heroicons/react/24/outline';
import type {
    DentalActModalProps,
    CatalogAct,
    DentalActScope,
    DentalActStatus,
} from '../types';
import { STATUS_OPTIONS } from '../types';
import { createDentalAct, updateDentalAct, searchCatalogActs } from '../api';

export default function DentalActModal({ isOpen, onClose, patientId, onSuccess, editAct, readOnly = false }: DentalActModalProps) {
    // Form state
    const [scope, setScope] = useState<DentalActScope>('TOOTH');
    const [selectedTeeth, setSelectedTeeth] = useState<string[]>([]);
    const [selectedSurfaces, setSelectedSurfaces] = useState<Record<string, string[]>>({});
    const [selectedAct, setSelectedAct] = useState<CatalogAct | null>(null);
    const [customActLabel, setCustomActLabel] = useState('');
    const [isCustomAct, setIsCustomAct] = useState(false);
    const [status, setStatus] = useState<DentalActStatus>('NON_COMMENCE');
    const [dateAct, setDateAct] = useState(new Date().toISOString().split('T')[0]);
    const [notes, setNotes] = useState('');

    // Catalog search state
    const [searchQuery, setSearchQuery] = useState('');
    const [catalogResults, setCatalogResults] = useState<CatalogAct[]>([]);
    const [searchLoading, setSearchLoading] = useState(false);
    const [showCatalogDropdown, setShowCatalogDropdown] = useState(false);

    // Submit state
    const [submitting, setSubmitting] = useState(false);

    // Reset form when modal opens/closes
    useEffect(() => {
        if (isOpen) {
            if (editAct) {
                // Edit mode
                setScope(editAct.scope);
                setSelectedTeeth(editAct.teeth || []);
                setSelectedSurfaces(editAct.surfaces ? { [editAct.teeth?.[0] || '']: editAct.surfaces } : {});
                setSelectedAct(editAct.act_catalog_id ? {
                    id: editAct.act_catalog_id,
                    code_ccam: editAct.act_code_cache || '',
                    code_short: '',
                    label: editAct.act_label_cache || '',
                    chapter_label: null,
                    family_label: null
                } : null);
                setStatus(editAct.status);
                setDateAct(editAct.date_act?.split('T')[0] || new Date().toISOString().split('T')[0]);
                setNotes(editAct.notes || '');
            } else {
                // Create mode - reset
                setScope('TOOTH');
                setSelectedTeeth([]);
                setSelectedSurfaces({});
                setSelectedAct(null);
                setCustomActLabel('');
                setIsCustomAct(false);
                setStatus('NON_COMMENCE');
                setDateAct(new Date().toISOString().split('T')[0]);
                setNotes('');
            }
            setSearchQuery('');
            setCatalogResults([]);
        }
    }, [isOpen, editAct]);

    // Search catalog with debounce
    useEffect(() => {
        const timer = setTimeout(async () => {
            if (searchQuery.length >= 2) {
                setSearchLoading(true);
                const result = await searchCatalogActs(searchQuery);
                if (result.success && result.data) {
                    setCatalogResults(result.data);
                    setShowCatalogDropdown(true);
                }
                setSearchLoading(false);
            } else {
                setCatalogResults([]);
                setShowCatalogDropdown(false);
            }
        }, 300);

        return () => clearTimeout(timer);
    }, [searchQuery]);

    // Handle tooth selection
    const handleToothSelect = useCallback((tooth: string) => {
        setSelectedTeeth(prev => {
            if (prev.includes(tooth)) {
                // Remove tooth and its surfaces
                const newSurfaces = { ...selectedSurfaces };
                delete newSurfaces[tooth];
                setSelectedSurfaces(newSurfaces);
                return prev.filter(t => t !== tooth);
            }
            return [...prev, tooth];
        });
    }, [selectedSurfaces]);

    // Handle surface selection
    const handleSurfaceSelect = useCallback((tooth: string, surface: string) => {
        setSelectedSurfaces(prev => {
            const toothSurfaces = prev[tooth] || [];
            if (toothSurfaces.includes(surface)) {
                const newSurfaces = toothSurfaces.filter(s => s !== surface);
                if (newSurfaces.length === 0) {
                    const { [tooth]: _, ...rest } = prev;
                    return rest;
                }
                return { ...prev, [tooth]: newSurfaces };
            }
            return { ...prev, [tooth]: [...toothSurfaces, surface] };
        });
    }, []);

    // Select act from catalog
    const handleSelectAct = (act: CatalogAct) => {
        setSelectedAct(act);
        setSearchQuery('');
        setShowCatalogDropdown(false);
    };

    // Clear selected act
    const handleClearAct = () => {
        setSelectedAct(null);
        setSearchQuery('');
        setIsCustomAct(false);
        setCustomActLabel('');
    };

    // Switch to custom act mode
    const handleUseCustomAct = () => {
        setIsCustomAct(true);
        setSelectedAct(null);
        setCustomActLabel(searchQuery);
        setShowCatalogDropdown(false);
    };

    // Validate form
    const validateForm = (): string | null => {
        if (scope === 'TOOTH' && selectedTeeth.length === 0) {
            return 'Veuillez sélectionner au moins une dent';
        }
        if (!selectedAct && !isCustomAct) {
            return 'Veuillez sélectionner un acte';
        }
        if (isCustomAct && !customActLabel.trim()) {
            return 'Veuillez saisir le nom de l\'acte';
        }
        if (!dateAct) {
            return 'Veuillez sélectionner une date';
        }
        return null;
    };

    // Submit form
    const handleSubmit = async () => {
        const error = validateForm();
        if (error) {
            toast({ title: 'Erreur', description: error, variant: 'destructive' });
            return;
        }

        setSubmitting(true);

        // Collect all surfaces from all teeth
        const allSurfaces = Object.values(selectedSurfaces).flat();

        const payload = {
            scope,
            teeth: scope === 'TOOTH' ? selectedTeeth : null,
            surfaces: scope === 'TOOTH' && allSurfaces.length > 0 ? allSurfaces : null,
            act_catalog_id: isCustomAct ? null : selectedAct?.id || null,
            custom_act_label: isCustomAct ? customActLabel.trim() : null,
            status,
            date_act: dateAct,
            notes: notes || null
        };

        let result;
        if (editAct) {
            result = await updateDentalAct(editAct.id, payload);
            if (result.success) {
                toast({ title: 'Succès', description: 'Acte dentaire modifié' });
            }
        } else {
            result = await createDentalAct(patientId, payload);
            if (result.success) {
                toast({ title: 'Succès', description: 'Acte dentaire enregistré' });
            }
        }

        if (result.success) {
            onSuccess();
            onClose();
        } else {
            toast({
                title: 'Erreur',
                description: result.error || 'Une erreur est survenue',
                variant: 'destructive'
            });
        }

        setSubmitting(false);
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={readOnly ? 'Détails de l\'acte dentaire' : (editAct ? 'Modifier l\'acte dentaire' : 'Nouvel acte dentaire')}
            className="max-w-[95vw] xl:max-w-7xl w-full"
        >
            <div className="flex flex-col xl:flex-row gap-6">
                {/* Left: Odontogram */}
                <div className="order-2 xl:order-1 xl:w-[55%] flex-shrink-0">
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Type d'acte
                        </label>
                        <div className="flex gap-4">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="scope"
                                    value="TOOTH"
                                    checked={scope === 'TOOTH'}
                                    onChange={() => setScope('TOOTH')}
                                    disabled={readOnly}
                                    className="w-4 h-4 text-cyan-600"
                                />
                                <span className="text-sm text-gray-700 dark:text-gray-300">Sur dent(s)</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="scope"
                                    value="MOUTH"
                                    checked={scope === 'MOUTH'}
                                    onChange={() => {
                                        setScope('MOUTH');
                                        setSelectedTeeth([]);
                                        setSelectedSurfaces({});
                                    }}
                                    disabled={readOnly}
                                    className="w-4 h-4 text-cyan-600"
                                />
                                <span className="text-sm text-gray-700 dark:text-gray-300">Bouche entière</span>
                            </label>
                        </div>
                    </div>

                    {scope === 'TOOTH' ? (
                        <Odontogram
                            selectedTeeth={selectedTeeth}
                            selectedSurfaces={selectedSurfaces}
                            onToothSelect={readOnly ? () => { } : handleToothSelect}
                            onSurfaceSelect={readOnly ? () => { } : handleSurfaceSelect}
                            showSurfaces={true}
                            readOnly={readOnly}
                        />
                    ) : (
                        <div className="flex items-center justify-center h-64 bg-cyan-50 dark:bg-cyan-900/20 rounded-xl border-2 border-dashed border-cyan-300 dark:border-cyan-700">
                            <div className="text-center">
                                <svg className="w-16 h-16 mx-auto text-cyan-400" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
                                </svg>
                                <p className="mt-2 text-sm font-medium text-cyan-700 dark:text-cyan-300">
                                    Acte sur bouche entière
                                </p>
                                <p className="text-xs text-cyan-600 dark:text-cyan-400">
                                    Aucune dent spécifique à sélectionner
                                </p>
                            </div>
                        </div>
                    )}

                    {/* Selected teeth summary */}
                    {scope === 'TOOTH' && selectedTeeth.length > 0 && (
                        <div className="mt-4 p-3 bg-cyan-50 dark:bg-cyan-900/20 rounded-lg">
                            <div className="text-sm font-medium text-cyan-700 dark:text-cyan-300">
                                Dents sélectionnées: {selectedTeeth.sort().join(', ')}
                            </div>
                        </div>
                    )}
                </div>

                {/* Right: Form */}
                <div className="order-1 xl:order-2 flex-1 min-w-0 space-y-4">
                    {/* Act search */}
                    <div className="relative">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Acte *
                        </label>
                        <div className="relative">
                            <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Rechercher un acte..."
                                disabled={readOnly}
                                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                            />
                        </div>

                        {/* Search results dropdown */}
                        {showCatalogDropdown && (
                            <div className="absolute z-50 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                                {catalogResults.length > 0 ? (
                                    catalogResults.map(act => (
                                        <button
                                            key={act.id}
                                            onClick={() => handleSelectAct(act)}
                                            className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-0"
                                        >
                                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                                                {act.label}
                                            </div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">
                                                {act.code_ccam} • {act.family_label || '-'}
                                            </div>
                                        </button>
                                    ))
                                ) : !searchLoading && searchQuery.length >= 2 ? (
                                    <div className="p-3">
                                        <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Aucun acte trouvé</p>
                                        <button
                                            onClick={handleUseCustomAct}
                                            className="w-full px-3 py-2 text-sm font-medium text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-900/30 rounded-lg hover:bg-cyan-100 dark:hover:bg-cyan-900/50 transition-colors"
                                        >
                                            + Utiliser "{searchQuery}" comme acte personnalisé
                                        </button>
                                    </div>
                                ) : null}
                            </div>
                        )}

                        {searchLoading && (
                            <div className="absolute right-10 top-1/2 -translate-y-1/2">
                                <div className="animate-spin w-4 h-4 border-2 border-cyan-500 border-t-transparent rounded-full"></div>
                            </div>
                        )}
                    </div>

                    {/* Selected act display */}
                    {selectedAct && (
                        <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg relative">
                            <button
                                onClick={handleClearAct}
                                className="absolute top-2 right-2 p-1 text-green-600 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                title="Supprimer l'acte"
                            >
                                <XMarkIcon className="w-5 h-5" />
                            </button>
                            <div className="text-sm font-medium text-green-800 dark:text-green-300 pr-8">
                                {selectedAct.label}
                            </div>
                            <div className="text-xs text-green-600 dark:text-green-400">
                                Code: {selectedAct.code_ccam}
                            </div>
                        </div>
                    )}

                    {/* Custom act input */}
                    {isCustomAct && (
                        <div className="p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg relative">
                            <button
                                onClick={handleClearAct}
                                className="absolute top-2 right-2 p-1 text-amber-600 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                                title="Supprimer"
                            >
                                <XMarkIcon className="w-5 h-5" />
                            </button>
                            <div className="text-xs text-amber-600 dark:text-amber-400 mb-2">
                                Acte personnalisé (hors catalogue)
                            </div>
                            <input
                                type="text"
                                value={customActLabel}
                                onChange={(e) => setCustomActLabel(e.target.value)}
                                placeholder="Nom de l'acte..."
                                className="w-full px-3 py-2 text-sm border border-amber-300 dark:border-amber-700 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                            />
                        </div>
                    )}

                    {/* Date */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Date de l'acte *
                        </label>
                        <input
                            type="date"
                            value={dateAct}
                            onChange={(e) => setDateAct(e.target.value)}
                            disabled={readOnly}
                            className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                        />
                    </div>

                    {/* Status */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Statut
                        </label>
                        <select
                            value={status}
                            onChange={(e) => setStatus(e.target.value as DentalActStatus)}
                            disabled={readOnly}
                            className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {STATUS_OPTIONS.map(opt => (
                                <option key={opt.value} value={opt.value}>{opt.label}</option>
                            ))}
                        </select>
                    </div>

                    {/* Notes */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                            Notes
                        </label>
                        <textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            rows={3}
                            placeholder="Notes additionnelles..."
                            disabled={readOnly}
                            className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent resize-none disabled:opacity-50 disabled:cursor-not-allowed"
                        />
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3 pt-4">
                        <button
                            onClick={onClose}
                            className="flex-1 px-4 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                        >
                            {readOnly ? 'Fermer' : 'Annuler'}
                        </button>
                        {!readOnly && (
                            <button
                                onClick={handleSubmit}
                                disabled={submitting}
                                className="flex-1 px-4 py-2.5 text-white bg-cyan-600 rounded-lg hover:bg-cyan-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            >
                                {submitting ? (
                                    <>
                                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full"></div>
                                        Enregistrement...
                                    </>
                                ) : (
                                    editAct ? 'Modifier' : 'Enregistrer'
                                )}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </Modal>
    );
}
