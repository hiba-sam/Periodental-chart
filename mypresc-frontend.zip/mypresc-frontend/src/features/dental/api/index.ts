// API barrel export
export * from './dental.api';
