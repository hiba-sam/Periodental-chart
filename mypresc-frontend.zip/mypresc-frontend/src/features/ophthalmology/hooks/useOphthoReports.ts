import axios from 'axios';
import type { OphthalmologyReport, UpdateOphthoAnnotations } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// ─── Query keys ───────────────────────────────────────────────────────────────
export const ophthoReportKeys = {
    all:       ['ophtho-reports'] as const,
    byPatient: (patientId: string) => ['ophtho-reports', 'patient', patientId] as const,
    byId:      (id: number)        => ['ophtho-reports', id] as const,
};

// ─── Fetch list for patient ───────────────────────────────────────────────────
export async function fetchOphthoReports(patientId: string): Promise<OphthalmologyReport[]> {
    const { data } = await axios.get(
        `${API_URL}/api/patients/${patientId}/ophtho-reports`,
        { withCredentials: true },
    );
    return data.data || [];
}

// ─── Fetch single ─────────────────────────────────────────────────────────────
export async function fetchOphthoReport(id: number): Promise<OphthalmologyReport> {
    const { data } = await axios.get(
        `${API_URL}/api/ophtho-reports/${id}`,
        { withCredentials: true },
    );
    return data.data;
}

// ─── Upload XML ───────────────────────────────────────────────────────────────
export async function uploadOphthoXml(
    patientId: string,
    file: File,
): Promise<OphthalmologyReport> {
    const formData = new FormData();
    formData.append('file', file);
    const { data } = await axios.post(
        `${API_URL}/api/patients/${patientId}/ophtho-reports/upload`,
        formData,
        { withCredentials: true, headers: { 'Content-Type': 'multipart/form-data' } },
    );
    return data.data;
}

// ─── Update annotations ───────────────────────────────────────────────────────
export async function updateOphthoReport(
    id: number,
    payload: UpdateOphthoAnnotations,
): Promise<OphthalmologyReport> {
    const { data } = await axios.patch(
        `${API_URL}/api/ophtho-reports/${id}`,
        payload,
        { withCredentials: true },
    );
    return data.data;
}

// ─── Delete ───────────────────────────────────────────────────────────────────
export async function deleteOphthoReport(id: number): Promise<void> {
    await axios.delete(`${API_URL}/api/ophtho-reports/${id}`, { withCredentials: true });
}

// ─── Download PDF ─────────────────────────────────────────────────────────────
export function downloadOphthoReportPdf(id: number): void {
    const url = `${API_URL}/api/ophtho-reports/${id}/pdf`;
    // Open in new tab — browser handles inline PDF display
    window.open(url, '_blank', 'noopener,noreferrer');
}
