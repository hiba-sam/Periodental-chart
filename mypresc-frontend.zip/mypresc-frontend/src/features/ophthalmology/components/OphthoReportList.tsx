'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { Loader2, FileX } from 'lucide-react';
import { fetchOphthoReports } from '../hooks/useOphthoReports';
import type { OphthalmologyReport } from '../types';
import { OphthoReportCard } from './OphthoReportCard';
import { RefractionsEvolutionChart } from './RefractionsEvolutionChart';

interface OphthoReportListProps {
    patientId:      string;
    refreshTrigger?: number;
    currentUserId?: number;
}

export function OphthoReportList({
    patientId,
    refreshTrigger = 0,
    currentUserId,
}: OphthoReportListProps) {
    const [reports,  setReports]  = useState<OphthalmologyReport[]>([]);
    const [loading,  setLoading]  = useState(true);
    const [error,    setError]    = useState<string | null>(null);

    const load = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await fetchOphthoReports(patientId);
            setReports(data);
        } catch {
            setError('Impossible de charger les rapports ophtalmologiques.');
        } finally {
            setLoading(false);
        }
    }, [patientId]);

    useEffect(() => { load(); }, [load, refreshTrigger]);

    if (loading) {
        return (
            <div className="flex items-center justify-center py-8 text-gray-400">
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                <span className="text-sm">Chargement…</span>
            </div>
        );
    }

    if (error) {
        return (
            <div className="text-sm text-red-500 dark:text-red-400 py-4 text-center">{error}</div>
        );
    }

    if (reports.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center py-8 gap-2 text-gray-400 dark:text-gray-600">
                <FileX className="w-8 h-8" />
                <p className="text-sm">Aucun rapport importé pour ce patient.</p>
                <p className="text-xs">Cliquez sur «&nbsp;Importer XML&nbsp;» pour ajouter un bilan réfractométrique.</p>
            </div>
        );
    }

    function handleDeleted(id: number) {
        setReports(prev => prev.filter(r => r.id !== id));
    }

    return (
        <div className="space-y-3">
            {/* Evolution chart — only visible when ≥ 2 reports */}
            <RefractionsEvolutionChart reports={reports} />

            {reports.map(report => (
                <OphthoReportCard
                    key={report.id}
                    report={report}
                    currentUserId={currentUserId}
                    onDeleted={handleDeleted}
                />
            ))}
        </div>
    );
}
