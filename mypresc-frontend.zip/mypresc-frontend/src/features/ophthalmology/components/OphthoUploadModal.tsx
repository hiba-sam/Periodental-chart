'use client';

import React, { useRef, useState } from 'react';
import { Upload, FileCheck2, X, Loader2, AlertCircle } from 'lucide-react';
import { uploadOphthoXml } from '../hooks/useOphthoReports';
import type { OphthalmologyReport } from '../types';
import { RxTable } from './RxTable';

interface OphthoUploadModalProps {
    isOpen:    boolean;
    onClose:   () => void;
    patientId: string;
    onSuccess: (report: OphthalmologyReport) => void;
}

type Step = 'upload' | 'preview' | 'success';

export function OphthoUploadModal({
    isOpen,
    onClose,
    patientId,
    onSuccess,
}: OphthoUploadModalProps) {
    const [step,        setStep]        = useState<Step>('upload');
    const [file,        setFile]        = useState<File | null>(null);
    const [dragging,    setDragging]    = useState(false);
    const [uploading,   setUploading]   = useState(false);
    const [error,       setError]       = useState<string | null>(null);
    const [report,      setReport]      = useState<OphthalmologyReport | null>(null);
    const [diagnosis,   setDiagnosis]   = useState('');
    const [notes,       setNotes]       = useState('');
    const inputRef = useRef<HTMLInputElement>(null);

    // After upload succeeds, save annotations then call onSuccess
    async function saveAnnotations(r: OphthalmologyReport) {
        if (!diagnosis && !notes) { onSuccess(r); onClose(); return; }
        try {
            const { updateOphthoReport } = await import('../hooks/useOphthoReports');
            const updated = await updateOphthoReport(r.id, { diagnosis: diagnosis || undefined, clinical_notes: notes || undefined });
            onSuccess(updated);
        } catch {
            onSuccess(r); // fallback — annotations lost, report still created
        }
        onClose();
    }

    if (!isOpen) return null;

    function handleFile(f: File) {
        if (!f.name.endsWith('.xml')) {
            setError('Seuls les fichiers XML sont acceptés.');
            return;
        }
        setFile(f);
        setError(null);
    }

    async function handleUpload() {
        if (!file) return;
        setUploading(true);
        setError(null);
        try {
            const created = await uploadOphthoXml(patientId, file);
            setReport(created);
            setStep('preview');
        } catch (e: any) {
            const msg = e?.response?.data?.error ?? 'Erreur lors de l\'import XML.';
            setError(msg);
        } finally {
            setUploading(false);
        }
    }

    function handleConfirm() {
        if (report) saveAnnotations(report);
    }

    function reset() {
        setStep('upload');
        setFile(null);
        setError(null);
        setReport(null);
        setDiagnosis('');
        setNotes('');
    }

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <div className="relative w-full max-w-3xl bg-white dark:bg-gray-900 rounded-2xl shadow-2xl overflow-hidden">

                {/* Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-800">
                    <h2 className="text-base font-semibold text-gray-800 dark:text-white">
                        {step === 'upload'  && 'Importer un fichier XML (TOPCON)'}
                        {step === 'preview' && 'Aperçu — Données extraites'}
                    </h2>
                    <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
                        <X className="w-5 h-5 text-gray-500" />
                    </button>
                </div>

                {/* ── Step 1: upload ──────────────────────────────────── */}
                {step === 'upload' && (
                    <div className="px-6 py-6 space-y-5">
                        {/* Drag-drop zone */}
                        <div
                            className={`relative flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed py-10 transition-colors cursor-pointer ${
                                dragging
                                    ? 'border-sky-500 bg-sky-50 dark:bg-sky-900/20'
                                    : file
                                        ? 'border-green-400 bg-green-50 dark:bg-green-900/20'
                                        : 'border-gray-300 dark:border-gray-600 hover:border-sky-400 hover:bg-sky-50 dark:hover:bg-sky-900/10'
                            }`}
                            onClick={() => inputRef.current?.click()}
                            onDragOver={e => { e.preventDefault(); setDragging(true); }}
                            onDragLeave={() => setDragging(false)}
                            onDrop={e => {
                                e.preventDefault();
                                setDragging(false);
                                const f = e.dataTransfer.files[0];
                                if (f) handleFile(f);
                            }}
                        >
                            <input
                                ref={inputRef}
                                type="file"
                                accept=".xml,text/xml,application/xml"
                                className="hidden"
                                onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }}
                            />
                            {file ? (
                                <>
                                    <FileCheck2 className="w-10 h-10 text-green-500" />
                                    <p className="text-sm font-medium text-green-700 dark:text-green-400">{file.name}</p>
                                    <p className="text-xs text-gray-400">{(file.size / 1024).toFixed(1)} Ko</p>
                                </>
                            ) : (
                                <>
                                    <Upload className="w-10 h-10 text-gray-400" />
                                    <p className="text-sm text-gray-600 dark:text-gray-400">
                                        <span className="font-medium text-sky-600">Cliquez</span> ou déposez un fichier XML ici
                                    </p>
                                    <p className="text-xs text-gray-400">Formats acceptés : XML (JOIA / TOPCON)</p>
                                </>
                            )}
                        </div>

                        {/* Error */}
                        {error && (
                            <div className="flex items-start gap-2 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 px-4 py-3 text-sm text-red-700 dark:text-red-400">
                                <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                                {error}
                            </div>
                        )}

                        {/* Actions */}
                        <div className="flex justify-end gap-3">
                            <button onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
                                Annuler
                            </button>
                            <button
                                onClick={handleUpload}
                                disabled={!file || uploading}
                                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                                Importer
                            </button>
                        </div>
                    </div>
                )}

                {/* ── Step 2: preview ─────────────────────────────────── */}
                {step === 'preview' && report && (
                    <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">
                        {/* Machine info */}
                        <div className="text-xs text-gray-400 dark:text-gray-500 flex gap-3 flex-wrap">
                            <span>Machine : <strong className="text-gray-600 dark:text-gray-300">{[report.machine_company, report.machine_model].filter(Boolean).join(' ')}</strong></span>
                            {report.machine_no && <span>N° <strong className="text-gray-600 dark:text-gray-300">{report.machine_no}</strong></span>}
                            <span>Date : <strong className="text-gray-600 dark:text-gray-300">
                                {report.exam_date ? new Date(report.exam_date).toLocaleDateString('fr-FR') : '—'}
                            </strong></span>
                        </div>

                        {/* Far Rx */}
                        <div>
                            <p className="text-xs font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide mb-2">Réfraction de Loin</p>
                            <RxTable report={report} distance="far" />
                        </div>

                        {/* Near Rx */}
                        <div>
                            <p className="text-xs font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide mb-2">Réfraction de Près</p>
                            <RxTable report={report} distance="near" showAdd />
                        </div>

                        {/* ── Annotations ──────────────────────────────── */}
                        <div className="space-y-3 pt-1">
                            <p className="text-xs font-bold text-sky-700 dark:text-sky-400 uppercase tracking-wide">Diagnostic &amp; Notes</p>
                            <div>
                                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Diagnostic</label>
                                <textarea
                                    value={diagnosis}
                                    onChange={e => setDiagnosis(e.target.value)}
                                    rows={2}
                                    placeholder="Myopie, astigmatisme, presbytie…"
                                    className="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-sm px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-sky-500 text-gray-800 dark:text-gray-200 placeholder:text-gray-400"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Notes cliniques</label>
                                <textarea
                                    value={notes}
                                    onChange={e => setNotes(e.target.value)}
                                    rows={2}
                                    placeholder="Observation, conduite à tenir…"
                                    className="w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 text-sm px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-sky-500 text-gray-800 dark:text-gray-200 placeholder:text-gray-400"
                                />
                            </div>
                        </div>

                        <div className="flex justify-between gap-3 pt-1">
                            <button onClick={reset} className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors">
                                ← Recommencer
                            </button>
                            <button
                                onClick={handleConfirm}
                                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-green-600 hover:bg-green-700 rounded-lg transition-colors"
                            >
                                <FileCheck2 className="w-4 h-4" />
                                Confirmer et enregistrer
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
