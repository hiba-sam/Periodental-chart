'use client';

import React from 'react';
import type { OphthalmologyReport } from '../types';
import { formatDiop } from '../types';

interface RxTableProps {
    report: OphthalmologyReport;
    distance: 'far' | 'near';
    showAdd?: boolean;
}

const TEAL = '#1a7fa0';

/** Coerce a pg numeric string (or number) to a float, or null */
function toN(v: any): number | null {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v));
    return isNaN(n) ? null : n;
}

/** Cell value: diopter formatted or em-dash */
function d(v: any): string {
    return formatDiop(v);
}

function ax(v: any): string {
    const n = toN(v);
    return n !== null ? `${n}°` : '—';
}

function val(v: any): string {
    const n = toN(v);
    return n !== null ? String(n) : '—';
}

function computeAdd(report: OphthalmologyReport, eye: 'right' | 'left'): string {
    const near = toN(eye === 'right' ? report.rx_near_right_sph : report.rx_near_left_sph);
    const far  = toN(eye === 'right' ? report.rx_far_right_sph  : report.rx_far_left_sph);
    if (near === null || far === null) return '—';
    const add = near - far;
    return (add >= 0 ? '+' : '') + add.toFixed(2);
}

export function RxTable({ report, distance, showAdd = false }: RxTableProps) {
    const p = distance === 'far' ? 'rx_far' : 'rx_near';

    const rows: { label: string; od: string; os: string }[] = [
        { label: 'Sph (D)',  od: d((report as any)[`${p}_right_sph`]),  os: d((report as any)[`${p}_left_sph`]) },
        { label: 'Cyl (D)',  od: d((report as any)[`${p}_right_cyl`]),  os: d((report as any)[`${p}_left_cyl`]) },
        { label: 'Axe',      od: ax((report as any)[`${p}_right_axis`]), os: ax((report as any)[`${p}_left_axis`]) },
        { label: 'VD (mm)',  od: val((report as any)[`${p}_vd`]),       os: val((report as any)[`${p}_vd`]) },
    ];

    const pdR = (report as any)[`${p}_pd_r`];
    const pdL = (report as any)[`${p}_pd_l`];
    const pdB = (report as any)[`${p}_pd_b`];

    const cylOd = (report as any)[`${p}_right_cyl`];
    const cylOs = (report as any)[`${p}_left_cyl`];

    function cylColor(v: any): string {
        const n = toN(v);
        if (n === null) return 'text-gray-700 dark:text-gray-300';
        if (n < 0) return 'text-blue-700 dark:text-blue-400';
        if (n > 0) return 'text-amber-700 dark:text-amber-400';
        return 'text-gray-700 dark:text-gray-300';
    }

    return (
        <div className="overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700">
            {/* Table header */}
            <table className="w-full text-sm">
                <thead>
                    <tr style={{ backgroundColor: TEAL }}>
                        <th className="py-2 px-3 text-left text-white font-semibold text-xs uppercase tracking-wide">
                            Œil
                        </th>
                        <th className="py-2 px-3 text-center text-white font-semibold text-xs uppercase tracking-wide">
                            Sph
                        </th>
                        <th className="py-2 px-3 text-center text-white font-semibold text-xs uppercase tracking-wide">
                            Cyl
                        </th>
                        <th className="py-2 px-3 text-center text-white font-semibold text-xs uppercase tracking-wide">
                            Axe
                        </th>
                        <th className="py-2 px-3 text-center text-white font-semibold text-xs uppercase tracking-wide">
                            VD
                        </th>
                        {showAdd && (
                            <th className="py-2 px-3 text-center text-white font-semibold text-xs uppercase tracking-wide">
                                ADD
                            </th>
                        )}
                    </tr>
                </thead>
                <tbody>
                    {(['right', 'left'] as const).map((eye, i) => {
                        const eyeLabel = eye === 'right' ? 'OD' : 'OG';
                        const sph  = (report as any)[`${p}_${eye}_sph`];
                        const cyl  = (report as any)[`${p}_${eye}_cyl`];
                        const axis = (report as any)[`${p}_${eye}_axis`];
                        const vd   = (report as any)[`${p}_vd`];
                        return (
                            <tr
                                key={eye}
                                className={i % 2 === 0 ? 'bg-white dark:bg-gray-800' : 'bg-sky-50 dark:bg-sky-900/20'}
                            >
                                <td className="py-2 px-3 font-bold text-sky-700 dark:text-sky-400">{eyeLabel}</td>
                                <td className="py-2 px-3 text-center text-gray-800 dark:text-gray-200">{d(sph)}</td>
                                <td className={`py-2 px-3 text-center font-medium ${cylColor(cyl)}`}>{d(cyl)}</td>
                                <td className="py-2 px-3 text-center text-gray-800 dark:text-gray-200">{ax(axis)}</td>
                                <td className="py-2 px-3 text-center text-gray-500 dark:text-gray-400">{val(vd)}</td>
                                {showAdd && (
                                    <td className="py-2 px-3 text-center font-semibold text-teal-700 dark:text-teal-400">
                                        {computeAdd(report, eye)}
                                    </td>
                                )}
                            </tr>
                        );
                    })}
                </tbody>
            </table>

            {/* PD row */}
            {(pdR || pdL || pdB) && (
                <div className="flex gap-4 px-3 py-2 bg-sky-50 dark:bg-sky-900/20 border-t border-gray-200 dark:border-gray-700 text-xs text-gray-600 dark:text-gray-400">
                    <span className="font-semibold text-gray-700 dark:text-gray-300">Écart Pupillaire</span>
                    {pdR && <span>OD: <strong>{pdR} mm</strong></span>}
                    {pdL && <span>OG: <strong>{pdL} mm</strong></span>}
                    {pdB && <span>Total: <strong>{pdB} mm</strong></span>}
                </div>
            )}
        </div>
    );
}
