'use client';

import React from 'react';

interface AxisDialProps {
    /** Axis in degrees 0–180 — may arrive as string from pg */
    axis: number | string | null | undefined;
    /** Label shown above the dial */
    label: string;
    /** Dial size in px (default 72) */
    size?: number;
}

/**
 * SVG circular dial showing axis direction (0–180°).
 * 0° = horizontal right, 90° = vertical.
 */
export function AxisDial({ axis, label, size = 72 }: AxisDialProps) {
    const r     = size / 2;
    const cx    = r;
    const cy    = r;
    const inner = r * 0.72;

    // Coerce to number — pg returns NUMERIC as strings
    const axisNum: number | null = (axis === null || axis === undefined || axis === '')
        ? null
        : typeof axis === 'number' ? axis : parseFloat(String(axis));
    const validAxis = axisNum !== null && !isNaN(axisNum);

    const svgAngle = validAxis ? -axisNum! * (Math.PI / 180) : 0;

    const x1 = cx + inner * Math.cos(svgAngle + Math.PI);
    const y1 = cy + inner * Math.sin(svgAngle + Math.PI);
    const x2 = cx + inner * Math.cos(svgAngle);
    const y2 = cy + inner * Math.sin(svgAngle);

    return (
        <div className="flex flex-col items-center gap-1">
            <span className="text-xs font-bold text-sky-700 dark:text-sky-400 tracking-wide">{label}</span>
            <div className="relative">
                <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
                    {/* Tick marks at 0, 45, 90, 135, 180° */}
                    {[0, 45, 90, 135].map(deg => {
                        const a  = -deg * (Math.PI / 180);
                        const r1 = r * 0.88;
                        const r2 = r * 0.95;
                        return (
                            <line
                                key={deg}
                                x1={cx + r1 * Math.cos(a + Math.PI)} y1={cy + r1 * Math.sin(a + Math.PI)}
                                x2={cx + r2 * Math.cos(a + Math.PI)} y2={cy + r2 * Math.sin(a + Math.PI)}
                                stroke="#94a3b8" strokeWidth="1"
                            />
                        );
                    })}

                    {/* Outer ring */}
                    <circle cx={cx} cy={cy} r={r - 2} fill="#f0f9ff" stroke="#bae6fd" strokeWidth="1.5"
                        className="dark:fill-gray-800 dark:stroke-sky-700" />

                    {/* Center dot */}
                    <circle cx={cx} cy={cy} r={2} fill="#1a7fa0" />

                    {/* Axis line */}
                    {validAxis ? (
                        <line
                            x1={x1} y1={y1} x2={x2} y2={y2}
                            stroke="#1a7fa0" strokeWidth="2" strokeLinecap="round"
                        />
                    ) : (
                        <text x={cx} y={cy + 5} textAnchor="middle" fontSize={10} fill="#94a3b8">—</text>
                    )}
                </svg>
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">
                {validAxis ? `${axisNum}°` : '—'}
            </span>
        </div>
    );
}
