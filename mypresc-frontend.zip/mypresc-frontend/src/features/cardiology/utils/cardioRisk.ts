import type { ActeCardiologueFormData } from '../types/cardiologue';

export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';

export interface RiskResult {
    level: RiskLevel;
    score: number;       // 0-100
    label: string;
    color: string;       // tailwind text color
    bgColor: string;     // tailwind bg color
    items: string[];     // human-readable risk factors
}

const RISK_COLORS: Record<RiskLevel, { label: string; color: string; bgColor: string }> = {
    low:      { label: 'Faible',   color: 'text-green-700 dark:text-green-400',  bgColor: 'bg-green-100 dark:bg-green-900/30' },
    moderate: { label: 'Modéré',   color: 'text-yellow-700 dark:text-yellow-400', bgColor: 'bg-yellow-100 dark:bg-yellow-900/30' },
    high:     { label: 'Élevé',    color: 'text-orange-700 dark:text-orange-400', bgColor: 'bg-orange-100 dark:bg-orange-900/30' },
    critical: { label: 'Critique', color: 'text-red-700 dark:text-red-400',      bgColor: 'bg-red-100 dark:bg-red-900/30' },
};

export function computeCardioRisk(data: ActeCardiologueFormData): RiskResult {
    const items: string[] = [];
    let score = 0;

    // HTA
    if (data.pa_systolique && data.pa_systolique >= 180) { score += 25; items.push('HTA sévère'); }
    else if (data.pa_systolique && data.pa_systolique >= 140) { score += 12; items.push('HTA'); }

    // Tachycardie / Bradycardie
    if (data.frequence_cardiaque && data.frequence_cardiaque >= 130) { score += 15; items.push('Tachycardie sévère'); }
    else if (data.frequence_cardiaque && data.frequence_cardiaque >= 100) { score += 8; items.push('Tachycardie'); }
    if (data.frequence_cardiaque && data.frequence_cardiaque < 50) { score += 10; items.push('Bradycardie'); }

    // SpO2
    if (data.spo2 != null && data.spo2 < 90) { score += 20; items.push('SpO₂ critique'); }
    else if (data.spo2 != null && data.spo2 < 95) { score += 10; items.push('SpO₂ basse'); }

    // FEVG
    if (data.ett_fevg != null && data.ett_fevg < 30) { score += 25; items.push('FEVG sévèrement altérée'); }
    else if (data.ett_fevg != null && data.ett_fevg < 40) { score += 15; items.push('FEVG altérée'); }
    else if (data.ett_fevg != null && data.ett_fevg < 55) { score += 8; items.push('FEVG modérément réduite'); }

    // ECG rhythm
    if (data.ecg_rythme === 'FA') { score += 10; items.push('FA'); }
    if (data.ecg_rythme === 'BAV') { score += 12; items.push('BAV'); }
    if (data.ecg_rythme === 'Flutter') { score += 8; items.push('Flutter'); }

    // LDL
    if (data.bio_ldl != null && data.bio_ldl > 1.0) { score += 10; items.push('LDL très élevé'); }
    else if (data.bio_ldl != null && data.bio_ldl > 0.55) { score += 5; items.push('LDL hors cible'); }

    // HbA1c
    if (data.bio_hba1c != null && data.bio_hba1c > 9) { score += 12; items.push('HbA1c très élevée'); }
    else if (data.bio_hba1c != null && data.bio_hba1c > 7) { score += 6; items.push('HbA1c élevée'); }

    // Potassium
    if (data.bio_potassium != null && (data.bio_potassium < 3.5 || data.bio_potassium > 5.5)) {
        score += 10; items.push('K⁺ anormal');
    }

    // Creatinine
    if (data.bio_creatinine != null && data.bio_creatinine > 150) { score += 8; items.push('Créatinine élevée'); }

    // Cap score
    score = Math.min(score, 100);

    let level: RiskLevel = 'low';
    if (score >= 60) level = 'critical';
    else if (score >= 35) level = 'high';
    else if (score >= 15) level = 'moderate';

    const colors = RISK_COLORS[level];
    return { level, score, items, ...colors };
}

// Helper: get color for a constante value
export function getConstanteColor(key: string, value: number | null): string {
    if (value == null) return '';
    const refs: Record<string, { min?: number; max?: number; dangerHigh?: number; dangerLow?: number }> = {
        pa_systolique:         { min: 90, max: 140, dangerHigh: 180, dangerLow: 80 },
        pa_diastolique:        { min: 60, max: 90,  dangerHigh: 110, dangerLow: 50 },
        frequence_cardiaque:   { min: 50, max: 100, dangerHigh: 130, dangerLow: 40 },
        spo2:                  { min: 95, max: 100, dangerLow: 90 },
        frequence_respiratoire:{ min: 12, max: 20,  dangerHigh: 30,  dangerLow: 8 },
    };
    const ref = refs[key];
    if (!ref) return '';
    if ((ref.dangerHigh && value >= ref.dangerHigh) || (ref.dangerLow && value <= ref.dangerLow))
        return 'text-red-600 dark:text-red-400 font-bold';
    if ((ref.max && value > ref.max) || (ref.min && value < ref.min))
        return 'text-orange-600 dark:text-orange-400 font-semibold';
    return 'text-green-600 dark:text-green-400';
}

// Helper: get bio alert color
export function getBioColor(key: string, value: number | null): string {
    if (value == null) return '';
    const refs: Record<string, { min?: number; max?: number }> = {
        bio_glycemie: { min: 0.70, max: 1.10 }, bio_hba1c: { max: 7.0 },
        bio_cholesterol_total: { max: 2.0 }, bio_ldl: { max: 0.55 },
        bio_hdl: { min: 0.40 }, bio_triglycerides: { max: 1.50 },
        bio_creatinine: { min: 60, max: 110 }, bio_uree: { min: 0.15, max: 0.45 },
        bio_potassium: { min: 3.5, max: 5.0 }, bio_hemoglobine: { min: 13, max: 17 },
    };
    const ref = refs[key];
    if (!ref) return '';
    if ((ref.max && value > ref.max) || (ref.min && value < ref.min))
        return 'text-red-600 dark:text-red-400 font-semibold';
    return 'text-green-600 dark:text-green-400';
}
