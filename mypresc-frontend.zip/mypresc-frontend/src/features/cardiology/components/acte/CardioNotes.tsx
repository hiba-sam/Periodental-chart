'use client';

import React from 'react';
import type { ActeCardiologueFormData } from '../../types/cardiologue';

interface Props {
    data: ActeCardiologueFormData;
    onChange: (field: keyof ActeCardiologueFormData, value: any) => void;
}

export default React.memo(function CardioNotes({ data, onChange }: Props) {
    return (
        <div className="space-y-2">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <svg className="w-4 h-4 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
                </svg>
                Notes &amp; Conduite
            </h3>

            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Notes cliniques</label>
                <textarea value={data.notes} onChange={e => onChange('notes', e.target.value)}
                    rows={3} placeholder="Observation, examen clinique..."
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-emerald-500 resize-none" />
            </div>

            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Conduite à tenir (CAT)</label>
                <textarea value={data.conduite_a_tenir} onChange={e => onChange('conduite_a_tenir', e.target.value)}
                    rows={2} placeholder="Ajuster traitement, bilan complémentaire..."
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-emerald-500 resize-none" />
            </div>

            <div>
                <label className="text-[11px] text-gray-500 dark:text-gray-400">Prochain rendez-vous</label>
                <input type="date" value={data.prochain_rdv || ''} onChange={e => onChange('prochain_rdv', e.target.value || null)}
                    className="w-full px-2 py-1.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:ring-2 focus:ring-emerald-500" />
            </div>
        </div>
    );
});
