'use client';

import React from 'react';
import type { ActeCardiologueFormData } from '../../types/cardiologue';
import { computeCardioRisk } from '../../utils/cardioRisk';

interface Props {
    data: ActeCardiologueFormData;
}

function KpiBadge({ label, value, unit, color }: { label: string; value: string | number | null; unit?: string; color: string }) {
    if (value == null || value === '') return null;
    return (
        <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${color}`}>
            <span className="opacity-70">{label}</span>
            <span>{value}{unit || ''}</span>
        </div>
    );
}

export default React.memo(function CardioKpiSynthesis({ data }: Props) {
    const risk = computeCardioRisk(data);
    const pa = data.pa_systolique && data.pa_diastolique ? `${data.pa_systolique}/${data.pa_diastolique}` : null;

    const paColor = (() => {
        if (!data.pa_systolique) return '';
        if (data.pa_systolique >= 180) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.pa_systolique >= 140) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const fcColor = (() => {
        if (!data.frequence_cardiaque) return '';
        if (data.frequence_cardiaque >= 130 || data.frequence_cardiaque < 50) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.frequence_cardiaque >= 100) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const spo2Color = (() => {
        if (data.spo2 == null) return '';
        if (data.spo2 < 90) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.spo2 < 95) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const fevgColor = (() => {
        if (data.ett_fevg == null) return '';
        if (data.ett_fevg < 30) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.ett_fevg < 40) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        if (data.ett_fevg < 55) return 'bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const ecgColor = (() => {
        if (!data.ecg_rythme) return '';
        if (data.ecg_rythme === 'Sinusal') return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
        return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
    })();

    const ldlColor = (() => {
        if (data.bio_ldl == null) return '';
        if (data.bio_ldl > 1.0) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.bio_ldl > 0.55) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const hba1cColor = (() => {
        if (data.bio_hba1c == null) return '';
        if (data.bio_hba1c > 9) return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300';
        if (data.bio_hba1c > 7) return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300';
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300';
    })();

    const hasAnyKpi = pa || data.frequence_cardiaque || data.spo2 != null || data.ett_fevg != null
        || data.ecg_rythme || data.bio_ldl != null || data.bio_hba1c != null;

    return (
        <div className="flex items-center gap-2 flex-wrap">
            {/* Risk score badge */}
            <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${risk.bgColor} ${risk.color}`}>
                <span className="w-2 h-2 rounded-full bg-current" />
                Score CV : {risk.label}
                {risk.items.length > 0 && <span className="opacity-60">({risk.items.length})</span>}
            </div>

            {/* Separator */}
            {hasAnyKpi && <div className="w-px h-5 bg-gray-300 dark:bg-gray-600" />}

            {/* Level 1 KPIs */}
            <KpiBadge label="PA" value={pa} color={paColor} />
            <KpiBadge label="FC" value={data.frequence_cardiaque} unit=" bpm" color={fcColor} />
            <KpiBadge label="SpO₂" value={data.spo2} unit="%" color={spo2Color} />
            <KpiBadge label="FEVG" value={data.ett_fevg} unit="%" color={fevgColor} />
            <KpiBadge label="ECG" value={data.ecg_rythme} color={ecgColor} />
            <KpiBadge label="LDL" value={data.bio_ldl} unit=" g/L" color={ldlColor} />
            <KpiBadge label="HbA1c" value={data.bio_hba1c} unit="%" color={hba1cColor} />
        </div>
    );
});
