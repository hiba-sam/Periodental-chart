'use client';

import { useState, useEffect } from 'react';
import type { ActeCardiologue } from '../../types/cardiologue';
import { fetchActesCardiologue } from '../../hooks/useActeCardiologue';

interface CardioActHistoryProps {
    patientId: string;
    onAddClick: () => void;
    onViewDetail: (acte: ActeCardiologue) => void;
    refreshTrigger?: number;
}

export default function CardioActHistory({ patientId, onAddClick, onViewDetail, refreshTrigger }: CardioActHistoryProps) {
    const [actes, setActes] = useState<ActeCardiologue[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let cancelled = false;
        setLoading(true);
        setError(null);
        fetchActesCardiologue(patientId)
            .then(data => { if (!cancelled) { setActes(data); setLoading(false); } })
            .catch(err => { if (!cancelled) { setError(err?.message || 'Erreur'); setLoading(false); } });
        return () => { cancelled = true; };
    }, [patientId, refreshTrigger]);

    const formatDate = (d: string) => {
        try { return new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }); }
        catch { return d; }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-8">
                <div className="animate-spin w-6 h-6 border-2 border-red-500 border-t-transparent rounded-full" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="text-center py-6">
                <p className="text-sm text-red-500">{error}</p>
                <button onClick={() => setError(null)} className="mt-2 text-xs text-blue-600 hover:underline">Réessayer</button>
            </div>
        );
    }

    return (
        <div>
            {/* Header with add button */}
            <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-semibold text-gray-800 dark:text-gray-200">
                    Actes Cardiologiques
                    {actes.length > 0 && <span className="ml-1.5 text-xs font-normal text-gray-500">({actes.length})</span>}
                </h3>
                <button
                    onClick={onAddClick}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
                >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                    </svg>
                    Nouvel acte
                </button>
            </div>

            {actes.length === 0 ? (
                <div className="text-center py-8 bg-gray-50 dark:bg-gray-800 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600">
                    <svg className="w-10 h-10 mx-auto text-gray-300 dark:text-gray-600 mb-2" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                    </svg>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Aucun acte cardiologique</p>
                    <button onClick={onAddClick} className="mt-2 text-sm text-red-600 hover:underline font-medium">
                        Créer le premier acte
                    </button>
                </div>
            ) : (
                <div className="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700">
                    <table className="w-full text-sm">
                        <thead>
                            <tr className="bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-400 text-xs uppercase">
                                <th className="px-3 py-2 text-left font-medium">Date</th>
                                <th className="px-3 py-2 text-left font-medium">Praticien</th>
                                <th className="px-3 py-2 text-left font-medium">Motif</th>
                                <th className="px-3 py-2 text-center font-medium">ECG</th>
                                <th className="px-3 py-2 text-center font-medium">FEVG</th>
                                <th className="px-3 py-2 text-center font-medium">PA</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                            {actes.map(acte => {
                                const fevgColor = acte.ett_fevg != null
                                    ? acte.ett_fevg < 30 ? 'text-red-600' : acte.ett_fevg < 40 ? 'text-orange-600' : acte.ett_fevg < 55 ? 'text-yellow-600' : 'text-green-600'
                                    : 'text-gray-400';
                                const ecgColor = acte.ecg_rythme && acte.ecg_rythme !== 'Sinusal' ? 'text-orange-600 font-medium' : 'text-gray-600 dark:text-gray-400';
                                const pa = acte.pa_systolique && acte.pa_diastolique ? `${acte.pa_systolique}/${acte.pa_diastolique}` : '—';
                                const paColor = acte.pa_systolique && acte.pa_systolique >= 140 ? 'text-orange-600 font-medium' : 'text-gray-600 dark:text-gray-400';

                                return (
                                    <tr
                                        key={acte.id}
                                        onClick={() => onViewDetail(acte)}
                                        className="hover:bg-red-50 dark:hover:bg-red-900/10 cursor-pointer transition-colors"
                                    >
                                        <td className="px-3 py-2 text-gray-700 dark:text-gray-300 whitespace-nowrap">{formatDate(acte.date_acte)}</td>
                                        <td className="px-3 py-2 text-gray-600 dark:text-gray-400 whitespace-nowrap">
                                            {acte.doctor_name ? `Dr. ${acte.doctor_name}` : '—'}
                                        </td>
                                        <td className="px-3 py-2 text-gray-700 dark:text-gray-300 max-w-[200px] truncate">{acte.motif || '—'}</td>
                                        <td className={`px-3 py-2 text-center whitespace-nowrap ${ecgColor}`}>{acte.ecg_rythme || '—'}</td>
                                        <td className={`px-3 py-2 text-center font-semibold ${fevgColor}`}>{acte.ett_fevg != null ? `${acte.ett_fevg}%` : '—'}</td>
                                        <td className={`px-3 py-2 text-center whitespace-nowrap ${paColor}`}>{pa}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
