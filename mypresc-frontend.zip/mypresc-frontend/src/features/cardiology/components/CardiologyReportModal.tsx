'use client';

import { useState, useCallback, useRef } from 'react';
import { XMarkIcon, DocumentTextIcon, HeartIcon, DocumentArrowDownIcon, PencilIcon, EyeIcon } from '@heroicons/react/24/outline';
import axios from 'axios';
import CardiologyReportForm from './CardiologyReportForm';
import CardiologyVoiceButton from './CardiologyVoiceButton';
import type { CardiologyFormData } from '@/utils/cardiologyScores';
import { computeAllScores, RISK_LABELS } from '@/utils/cardiologyScores';

const API_URL = process.env.NEXT_PUBLIC_API_URL || process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// ============================================
// REPORT TEXT GENERATION
// ============================================

function generateReportText(d: CardiologyFormData, patientFullName?: string): string {
    const scores = computeAllScores(d);
    const lines: string[] = [];

    // Header
    const sexLabel = d.patient_sex === 'homme' ? 'sexe masculin' : d.patient_sex === 'femme' ? 'sexe féminin' : '';
    const namePrefix = patientFullName ? `${patientFullName}, ` : 'Patient de ';
    lines.push(`${namePrefix}${d.patient_age ?? '?'} ans, ${sexLabel}.`);
    lines.push('');

    // Clinical exam
    const clinParts: string[] = [];
    if (d.heart_rate) clinParts.push(`FC ${d.heart_rate} bpm`);
    if (d.systolic_bp && d.diastolic_bp) clinParts.push(`PA ${d.systolic_bp}/${d.diastolic_bp} mmHg`);
    else if (d.systolic_bp) clinParts.push(`PAS ${d.systolic_bp} mmHg`);
    if (d.spo2 != null) clinParts.push(`SpO₂ ${d.spo2}%`);
    if (d.auscultation && d.auscultation !== '') {
        const auscLabels: Record<string, string> = {
            normal: 'normale', souffle_systolique: 'souffle systolique', souffle_diastolique: 'souffle diastolique',
            souffle_continu: 'souffle continu', galop_b3: 'galop B3', galop_b4: 'galop B4',
            frottement_pericardique: 'frottement péricardique', arythmie: 'arythmie',
        };
        clinParts.push(`Auscultation : ${auscLabels[d.auscultation] || d.auscultation}`);
    }
    if (d.nyha_class) clinParts.push(`Classe NYHA ${d.nyha_class}`);
    if (d.lower_limb_edema && d.lower_limb_edema !== '') {
        const edemaLabels: Record<string, string> = { absent: 'Pas d\'œdèmes', discrets: 'Œdèmes discrets', moderes: 'Œdèmes modérés', importants: 'Œdèmes importants' };
        clinParts.push(edemaLabels[d.lower_limb_edema] || d.lower_limb_edema);
    }
    if (d.heart_failure_signs && d.heart_failure_signs.length > 0) {
        clinParts.push(`Signes IC : ${d.heart_failure_signs.join(', ')}`);
    }
    if (clinParts.length > 0) {
        lines.push(`EXAMEN CLINIQUE : ${clinParts.join('. ')}.`);
        lines.push('');
    }

    // History
    const histItems: string[] = [];
    if (d.has_hta) histItems.push('HTA');
    if (d.has_diabetes) histItems.push(d.has_diabetes_insulin ? 'Diabète insulino-traité' : 'Diabète');
    if (d.has_afib) histItems.push('FA');
    if (d.has_mi) histItems.push('IDM');
    if (d.has_stroke) histItems.push('AVC/AIT');
    if (d.has_heart_failure) histItems.push('IC');
    if (d.has_arteriopathy) histItems.push('Artériopathie');
    if (d.has_valvulopathy) histItems.push('Valvulopathie');
    if (d.has_active_smoking) histItems.push('Tabac actif');
    if (d.has_stopped_smoking) histItems.push('Tabac sevré');
    if (d.has_dyslipidemia) histItems.push('Dyslipidémie');
    if (d.has_endocarditis) histItems.push('Endocardite');
    if (d.has_prior_cardiac_surgery) histItems.push('Chirurgie cardiaque antérieure');
    if (d.has_chronic_lung_disease) histItems.push('Maladie pulmonaire chronique');
    if (d.has_reduced_mobility) histItems.push('Mobilité réduite');
    if (histItems.length > 0) {
        lines.push(`ANTÉCÉDENTS : ${histItems.join(', ')}.`);
        lines.push('');
    }

    // ECG
    if ((d as any).ecg_result) {
        const ecgLabels: Record<string, string> = {
            sinusal_normal: 'Rythme sinusal normal', fa: 'Fibrillation auriculaire', flutter: 'Flutter auriculaire',
            bbg: 'BBG', bbd: 'BBD', bav: 'BAV', hvg: 'HVG', ischemie: 'Signes d\'ischémie',
            lesion: 'Signes de lésion', necrose: 'Signes de nécrose', autre: 'Autre',
        };
        let ecgText = `ECG : ${ecgLabels[(d as any).ecg_result] || (d as any).ecg_result}`;
        if ((d as any).ecg_detail) ecgText += ` — ${(d as any).ecg_detail}`;
        if ((d as any).ecg_st_deviation) ecgText += '. Déviation ST présente';
        lines.push(`${ecgText}.`);
    }

    // Echo
    const echoParts: string[] = [];
    if (d.echo_lvef != null) echoParts.push(`FEVG ${d.echo_lvef}%`);
    if ((d as any).echo_lvedd != null) echoParts.push(`DTDVG ${(d as any).echo_lvedd} mm`);
    if (d.echo_lvesd != null) echoParts.push(`DTSVG ${d.echo_lvesd} mm`);
    if (d.echo_ivs_thickness != null) echoParts.push(`SIV ${d.echo_ivs_thickness} mm`);
    if (d.echo_pw_thickness != null) echoParts.push(`PP ${d.echo_pw_thickness} mm`);
    if ((d as any).echo_la_size != null) echoParts.push(`OG ${(d as any).echo_la_size} mm`);
    if (d.echo_tapse != null) echoParts.push(`TAPSE ${d.echo_tapse} mm`);
    if (d.echo_pulmonary_htn != null) echoParts.push(`HTAP ${d.echo_pulmonary_htn} mmHg`);
    if (d.echo_wall_motion && d.echo_wall_motion !== 'normal') {
        const wmLabels: Record<string, string> = { hypokinesia: 'Hypokinésie', akinesia: 'Akinésie', dyskinesia: 'Dyskinésie' };
        let wmText = `Cinétique segmentaire : ${wmLabels[d.echo_wall_motion] || d.echo_wall_motion}`;
        if (d.echo_wall_motion_detail) wmText += ` (${d.echo_wall_motion_detail})`;
        echoParts.push(wmText);
    } else if (d.echo_wall_motion === 'normal') {
        echoParts.push('Cinétique segmentaire normale');
    }
    if (d.echo_diastolic_function) {
        const dfLabels: Record<string, string> = { normal: 'normale', relaxation_impaired: 'trouble de la relaxation', pseudonormal: 'pseudo-normale', restrictive: 'restrictive' };
        echoParts.push(`Fonction diastolique ${dfLabels[d.echo_diastolic_function] || d.echo_diastolic_function}`);
    }
    if (d.echo_pericardial_effusion && d.echo_pericardial_effusion !== 'absent') {
        const peLabels: Record<string, string> = { minime: 'minime', modere: 'modéré', important: 'important' };
        echoParts.push(`Épanchement péricardique ${peLabels[d.echo_pericardial_effusion] || d.echo_pericardial_effusion}`);
    }
    if ((d as any).echo_valvulopathies?.length > 0) {
        const sevLabels: Record<string, string> = { legere: 'légère', moderee: 'modérée', severe: 'sévère' };
        const valveParts = ((d as any).echo_valvulopathies as string[]).map((v: string) => {
            const sev = d.echo_valvulopathy_severity?.[v];
            return sev ? `${v} ${sevLabels[sev] || sev}` : v;
        });
        echoParts.push(`Valvulopathies : ${valveParts.join(', ')}`);
    }
    if (echoParts.length > 0) {
        lines.push(`ÉCHOCARDIOGRAPHIE : ${echoParts.join('. ')}.`);
    }

    // Bio
    const bioParts: string[] = [];
    if (d.bio_ldl != null) bioParts.push(`LDL ${d.bio_ldl} g/L`);
    if (d.bio_hdl != null) bioParts.push(`HDL ${d.bio_hdl} g/L`);
    if (d.bio_total_cholesterol != null) bioParts.push(`CT ${d.bio_total_cholesterol} g/L`);
    if (d.bio_triglycerides != null) bioParts.push(`TG ${d.bio_triglycerides} g/L`);
    if (d.bio_hba1c != null) bioParts.push(`HbA1c ${d.bio_hba1c}%`);
    if (d.bio_creatinine != null) bioParts.push(`Créat. ${d.bio_creatinine} µmol/L`);
    if (d.bio_bnp != null) bioParts.push(`BNP ${d.bio_bnp}`);
    if (d.bio_troponin != null) bioParts.push(`Troponine ${d.bio_troponin}`);
    if (d.bio_inr != null) bioParts.push(`INR ${d.bio_inr}`);
    if (bioParts.length > 0) {
        lines.push(`BIOLOGIE : ${bioParts.join(', ')}.`);
    }

    lines.push('');

    // Scores
    const scoreParts: string[] = [];
    for (const s of scores) {
        if (s.value != null) {
            const levelText = s.level ? ` (${RISK_LABELS[s.level] || s.level})` : '';
            if (s.label === 'Framingham' || s.label === 'SCORE2' || s.label === 'SCORE2-OP' || s.label === 'EuroSCORE II') {
                scoreParts.push(`${s.label} : ${s.value}%${levelText}`);
            } else if (s.label === 'NYHA') {
                scoreParts.push(`NYHA : Classe ${s.value}`);
            } else if (typeof s.maxValue === 'string') {
                scoreParts.push(`${s.label} : ${s.value}${levelText}`);
            } else {
                scoreParts.push(`${s.label} : ${s.value}/${s.maxValue}${levelText}`);
            }
        }
    }
    if (scoreParts.length > 0) {
        lines.push(`SCORES : ${scoreParts.join(', ')}.`);
        lines.push('');
    }

    // Free notes
    if ((d as any).free_notes) {
        lines.push(`NOTES : ${(d as any).free_notes}`);
        lines.push('');
    }

    lines.push('CONCLUSION : ');

    return lines.join('\n');
}

// ============================================
// PROPS
// ============================================

interface CardiologyReportModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    patientName: string;
    patientFamilyName: string;
    patientAge?: number | null;
    patientSex?: string | null;
    patientWeight?: number | null;
    patientHeight?: number | null;
    onSuccess?: () => void;
    editReport?: any;
}

// ============================================
// COMPONENT
// ============================================

export default function CardiologyReportModal({
    isOpen,
    onClose,
    patientId,
    patientName,
    patientFamilyName,
    patientAge,
    patientSex,
    patientWeight,
    patientHeight,
    onSuccess,
    editReport,
}: CardiologyReportModalProps) {
    const [formData, setFormData] = useState<CardiologyFormData>({
        patient_age: patientAge ?? null,
        patient_sex: patientSex ?? null,
        patient_weight: patientWeight ?? null,
        patient_height: patientHeight ?? null,
        ...editReport,
    });

    const [generatedReport, setGeneratedReport] = useState<string>(editReport?.generated_report || '');
    const [showReport, setShowReport] = useState(!!editReport?.generated_report);
    const [editMode, setEditMode] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [showSuccess, setShowSuccess] = useState(false);
    const [createdId, setCreatedId] = useState<number | null>(editReport?.id || null);
    const reportRef = useRef<HTMLTextAreaElement>(null);

    const [voiceTranscription, setVoiceTranscription] = useState<string | null>(null);
    const [formKey, setFormKey] = useState(0);

    const handleFormChange = useCallback((data: CardiologyFormData) => {
        setFormData(data);
    }, []);

    const handleVoiceData = useCallback((data: Partial<CardiologyFormData>, additionalInfo: string | null, transcription: string) => {
        setFormData(prev => {
            const merged = { ...prev };
            for (const [key, value] of Object.entries(data)) {
                if (value === null || value === undefined || value === false) continue;
                if (typeof value === 'string' && value === '') continue;
                if (Array.isArray(value) && value.length === 0) continue;
                (merged as any)[key] = value;
            }
            if (additionalInfo) {
                merged.free_notes = merged.free_notes
                    ? `${merged.free_notes}\n\nInformations supplémentaires (dictée) :\n${additionalInfo}`
                    : `Informations supplémentaires (dictée) :\n${additionalInfo}`;
            }
            return merged;
        });
        setVoiceTranscription(transcription);
        setFormKey(k => k + 1);
    }, []);

    const fullName = `${patientFamilyName ?? ''} ${patientName ?? ''}`.trim() || undefined;

    const handleGenerateReport = useCallback(() => {
        const text = generateReportText(formData, fullName);
        setGeneratedReport(text);
        setShowReport(true);
        setTimeout(() => reportRef.current?.focus(), 100);
    }, [formData, fullName]);

    const handleSubmit = async () => {
        setLoading(true);
        setError('');

        try {
            const payload = {
                ...formData,
                generated_report: generatedReport || null,
            };

            let response;
            if (editReport?.id) {
                response = await axios.patch(
                    `${API_URL}/api/cardiology-reports/${editReport.id}`,
                    payload,
                    { withCredentials: true }
                );
            } else {
                response = await axios.post(
                    `${API_URL}/api/patients/${patientId}/cardiology-reports`,
                    payload,
                    { withCredentials: true }
                );
            }

            if (response.data.success) {
                setCreatedId(response.data.data.id);
                setShowSuccess(true);
                onSuccess?.();
            }
        } catch (err: any) {
            console.error('Save cardiology report error:', err);
            setError(err.response?.data?.error || 'Erreur lors de la sauvegarde');
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        setFormData({
            patient_age: patientAge ?? null,
            patient_sex: patientSex ?? null,
            patient_weight: patientWeight ?? null,
            patient_height: patientHeight ?? null,
        });
        setGeneratedReport('');
        setShowReport(false);
        setError('');
        setShowSuccess(false);
        setCreatedId(null);
        onClose();
    };

    if (!isOpen) return null;

    // Success state
    if (showSuccess) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4">
                    <div className="p-6 text-center">
                        <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                            <HeartIcon className="w-8 h-8 text-green-600 dark:text-green-400" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                            Compte-rendu cardiologique enregistré
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                            Le compte-rendu pour <strong>{patientName} {patientFamilyName}</strong> a été sauvegardé avec succès.
                        </p>
                        <div className="flex flex-col gap-3">
                            <button
                                onClick={handleClose}
                                className="w-full px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                            >
                                Fermer
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-6xl w-full mx-4 my-4 transform transition-all max-h-[95vh] flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                            <HeartIcon className="w-6 h-6 text-red-500" />
                            Nouveau compte-rendu cardiologique
                        </h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-0.5">
                            {patientName} {patientFamilyName}
                            {patientAge ? ` • ${patientAge} ans` : ''}
                            {patientSex ? ` • ${patientSex === 'homme' ? 'H' : 'F'}` : ''}
                        </p>
                    </div>
                    <button onClick={handleClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                        <XMarkIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Body — scrollable */}
                <div className="flex-1 overflow-y-auto p-5">
                    {error && (
                        <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                            <p className="text-sm text-red-800 dark:text-red-300">{error}</p>
                        </div>
                    )}

                    {/* Voice Dictation — AI auto-fill */}
                    <div className="mb-5 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/10 dark:to-orange-900/10 border border-red-200/50 dark:border-red-800/20 rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-sm">🎤</span>
                            <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-200">Dictée vocale cardiologique</h3>
                            <span className="text-[9px] bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded px-1.5 py-0.5 font-medium">IA</span>
                        </div>
                        <CardiologyVoiceButton
                            onDataExtracted={handleVoiceData}
                            disabled={loading}
                        />
                        {voiceTranscription && (
                            <details className="mt-3">
                                <summary className="text-[10px] text-gray-400 dark:text-gray-500 cursor-pointer hover:text-gray-600">Voir la transcription brute</summary>
                                <p className="mt-1 text-[10px] text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 rounded p-2 border border-gray-200 dark:border-gray-700 max-h-20 overflow-y-auto">{voiceTranscription}</p>
                            </details>
                        )}
                    </div>

                    {/* Cardiology Form with scores */}
                    <CardiologyReportForm
                        key={formKey}
                        initialData={formData}
                        patientFullName={fullName}
                        patientAge={patientAge}
                        patientSex={patientSex}
                        patientWeight={patientWeight}
                        patientHeight={patientHeight}
                        onChange={handleFormChange}
                    />

                    {/* Generate Report Button */}
                    <div className="mt-6 flex justify-center">
                        <button
                            type="button"
                            onClick={handleGenerateReport}
                            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium shadow-md"
                        >
                            <DocumentArrowDownIcon className="w-5 h-5" />
                            Générer le compte-rendu
                        </button>
                    </div>

                    {/* Generated Report — Styled Preview + Edit Toggle */}
                    {showReport && (
                        <div className="mt-6 bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4">
                            <div className="flex items-center justify-between mb-3">
                                <h3 className="text-base font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2">
                                    <DocumentTextIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                                    Compte-rendu généré
                                </h3>
                                <button
                                    type="button"
                                    onClick={() => setEditMode(!editMode)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-600"
                                >
                                    {editMode ? <><EyeIcon className="w-3.5 h-3.5" /> Aperçu</> : <><PencilIcon className="w-3.5 h-3.5" /> Modifier</>}
                                </button>
                            </div>

                            {editMode ? (
                                <textarea
                                    ref={reportRef}
                                    value={generatedReport}
                                    onChange={e => setGeneratedReport(e.target.value)}
                                    rows={16}
                                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-y font-mono leading-relaxed"
                                    placeholder="Le compte-rendu apparaîtra ici..."
                                />
                            ) : (
                                <div className="bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg p-4 space-y-3 text-sm text-gray-800 dark:text-gray-200">
                                    {(() => {
                                        const SECTION_RE = /^(EXAMEN CLINIQUE|ANTÉCÉDENTS|ECG|ÉCHOCARDIOGRAPHIE|BIOLOGIE|SCORES|NOTES|CONCLUSION)\s*:?\s*(.*)/;
                                        const lines = generatedReport.split('\n').filter((l: string) => l.trim() !== '');
                                        const elements: any[] = [];
                                        for (let idx = 0; idx < lines.length; idx++) {
                                            const line = lines[idx] as string;
                                            const m = line.match(SECTION_RE);
                                            if (m) {
                                                const title = m[1] || '';
                                                let content = (m[2] || '').trim();
                                                const next = idx + 1 < lines.length ? (lines[idx + 1] as string) : '';
                                                if (!content && next && !next.match(SECTION_RE) && !next.startsWith('Patient de ')) {
                                                    content = next;
                                                    idx++;
                                                }
                                                elements.push(
                                                    <div key={idx} className="border-l-3 border-indigo-500 pl-3">
                                                        <span className="font-bold text-indigo-700 dark:text-indigo-400 text-xs uppercase tracking-wide">{title}</span>
                                                        {content && <p className="mt-0.5 text-gray-700 dark:text-gray-300">{content}</p>}
                                                    </div>
                                                );
                                            } else if (line.startsWith('Patient de ')) {
                                                elements.push(<p key={idx} className="font-semibold text-gray-900 dark:text-gray-100 text-base pb-1 border-b border-gray-200 dark:border-gray-600">{line}</p>);
                                            } else {
                                                elements.push(<p key={idx} className="text-gray-600 dark:text-gray-400">{line}</p>);
                                            }
                                        }
                                        return elements;
                                    })()}
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="flex gap-3 p-5 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="flex-1 px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                        disabled={loading}
                    >
                        Annuler
                    </button>
                    <button
                        type="button"
                        onClick={handleSubmit}
                        className="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={loading}
                    >
                        {loading ? (
                            <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
                                Enregistrement...
                            </>
                        ) : (
                            <>
                                <HeartIcon className="w-5 h-5" />
                                Créer
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
}
