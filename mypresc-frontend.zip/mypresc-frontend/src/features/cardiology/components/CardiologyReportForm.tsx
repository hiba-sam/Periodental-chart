'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/outline';
import type { CardiologyFormData } from '@/utils/cardiologyScores';
import { computeAllScores } from '@/utils/cardiologyScores';
import CardiologyScoreCards from './CardiologyScoreCards';

// ============================================
// SELECT OPTIONS
// ============================================

const AUSCULTATION_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'normal', label: 'Normal' },
    { value: 'souffle_systolique', label: 'Souffle systolique' },
    { value: 'souffle_diastolique', label: 'Souffle diastolique' },
    { value: 'souffle_continu', label: 'Souffle continu' },
    { value: 'galop_b3', label: 'Galop B3' },
    { value: 'galop_b4', label: 'Galop B4' },
    { value: 'frottement_pericardique', label: 'Frottement péricardique' },
    { value: 'arythmie', label: 'Arythmie' },
];

const EDEMA_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'absent', label: 'Absents' },
    { value: 'discrets', label: 'Discrets' },
    { value: 'moderes', label: 'Modérés' },
    { value: 'importants', label: 'Importants' },
];

const CHEST_PAIN_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'absent', label: 'Absente' },
    { value: 'typique', label: 'Typique (angor)' },
    { value: 'atypique', label: 'Atypique' },
    { value: 'non_cardiaque', label: 'Non cardiaque' },
];

const HF_SIGNS = [
    'Dyspnée', 'Orthopnée', 'DPN', 'Turgescence jugulaire',
    'Râles crépitants', 'Hépatomégalie', 'Reflux hépato-jugulaire',
];

const ECG_RESULTS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'sinusal_normal', label: 'Rythme sinusal normal' },
    { value: 'fa', label: 'Fibrillation auriculaire' },
    { value: 'flutter', label: 'Flutter auriculaire' },
    { value: 'bbg', label: 'BBG' },
    { value: 'bbd', label: 'BBD' },
    { value: 'bav', label: 'BAV' },
    { value: 'hvg', label: 'HVG' },
    { value: 'ischemie', label: 'Signes d\'ischémie' },
    { value: 'lesion', label: 'Signes de lésion' },
    { value: 'necrose', label: 'Signes de nécrose' },
    { value: 'autre', label: 'Autre' },
];

const VALVULOPATHIES = ['IM', 'IA', 'RM', 'RA', 'IT', 'IP'];

const VALVULOPATHY_SEVERITY_OPTIONS = [
    { value: '', label: '—' },
    { value: 'legere', label: 'Légère' },
    { value: 'moderee', label: 'Modérée' },
    { value: 'severe', label: 'Sévère' },
];

const WALL_MOTION_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'normal', label: 'Normale' },
    { value: 'hypokinesia', label: 'Hypokinésie' },
    { value: 'akinesia', label: 'Akinésie' },
    { value: 'dyskinesia', label: 'Dyskinésie' },
];

const DIASTOLIC_FUNCTION_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'normal', label: 'Normale' },
    { value: 'relaxation_impaired', label: 'Trouble de la relaxation' },
    { value: 'pseudonormal', label: 'Pseudo-normale' },
    { value: 'restrictive', label: 'Restrictive' },
];

const PERICARDIAL_EFFUSION_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'absent', label: 'Absent' },
    { value: 'minime', label: 'Minime' },
    { value: 'modere', label: 'Modéré' },
    { value: 'important', label: 'Important' },
];

// Range validation rules (visual warning only, no blocking)
const RANGE_RULES: Record<string, { min: number; max: number; label: string }> = {
    echo_lvef: { min: 5, max: 85, label: 'FEVG' },
    echo_lvedd: { min: 20, max: 90, label: 'DTDVG' },
    echo_lvesd: { min: 15, max: 60, label: 'DTSVG' },
    echo_ivs_thickness: { min: 4, max: 20, label: 'SIV' },
    echo_pw_thickness: { min: 4, max: 20, label: 'PP' },
    echo_la_size: { min: 15, max: 70, label: 'OG' },
    echo_pulmonary_htn: { min: 15, max: 120, label: 'HTAP' },
    echo_tapse: { min: 5, max: 35, label: 'TAPSE' },
    heart_rate: { min: 30, max: 250, label: 'FC' },
    systolic_bp: { min: 60, max: 260, label: 'PAS' },
    diastolic_bp: { min: 30, max: 160, label: 'PAD' },
    spo2: { min: 50, max: 100, label: 'SpO2' },
};

function isOutOfRange(field: string, value: number | null | undefined): boolean {
    if (value == null) return false;
    const rule = RANGE_RULES[field];
    if (!rule) return false;
    return value < rule.min || value > rule.max;
}

const URGENCY_OPTIONS = [
    { value: '', label: '— Sélectionner —' },
    { value: 'elective', label: 'Élective' },
    { value: 'urgent', label: 'Urgente' },
    { value: 'emergency', label: 'Émergence' },
    { value: 'salvage', label: 'Sauvetage' },
];

const SURGERY_TYPES = [
    { value: '', label: '— Sélectionner —' },
    { value: 'cabg_isole', label: 'Pontage coronarien isolé' },
    { value: 'valve_seule', label: 'Chirurgie valvulaire seule' },
    { value: 'cabg_valve', label: 'Pontage + valve' },
    { value: 'aorte', label: 'Chirurgie aortique' },
    { value: 'autre', label: 'Autre chirurgie cardiaque' },
];

// ============================================
// PROPS
// ============================================

interface CardiologyReportFormProps {
    initialData?: Partial<CardiologyFormData>;
    patientFullName?: string;
    patientAge?: number | null;
    patientSex?: string | null;
    patientWeight?: number | null;
    patientHeight?: number | null;
    readOnly?: boolean;
    onChange?: (data: CardiologyFormData) => void;
    onGenerateReport?: (data: CardiologyFormData) => void;
}

// ============================================
// COMPONENT
// ============================================

export default function CardiologyReportForm({
    initialData,
    patientFullName,
    patientAge,
    patientSex,
    patientWeight,
    patientHeight,
    readOnly = false,
    onChange,
    onGenerateReport,
}: CardiologyReportFormProps) {
    const [form, setForm] = useState<CardiologyFormData>({
        patient_age: patientAge ?? null,
        patient_sex: patientSex ?? null,
        patient_weight: patientWeight ?? null,
        patient_height: patientHeight ?? null,
        ...initialData,
    });

    const [showPreop, setShowPreop] = useState(
        !!(initialData?.preop_urgency || initialData?.preop_surgery_type)
    );

    // Sync patient info from props
    useEffect(() => {
        setForm(prev => ({
            ...prev,
            patient_age: patientAge ?? prev.patient_age,
            patient_sex: patientSex ?? prev.patient_sex,
            patient_weight: patientWeight ?? prev.patient_weight,
            patient_height: patientHeight ?? prev.patient_height,
        }));
    }, [patientAge, patientSex, patientWeight, patientHeight]);

    // Calculate BMI
    const bmi = useMemo(() => {
        if (form.patient_weight && form.patient_height && form.patient_height > 0) {
            const h = form.patient_height / 100;
            return Math.round((form.patient_weight / (h * h)) * 10) / 10;
        }
        return null;
    }, [form.patient_weight, form.patient_height]);

    // Compute scores in real-time
    const scores = useMemo(() => computeAllScores(form), [form]);

    // Notify parent of changes
    const updateField = useCallback((field: string, value: any) => {
        setForm(prev => {
            const next = { ...prev, [field]: value };
            onChange?.(next);
            return next;
        });
    }, [onChange]);

    const toggleArrayItem = useCallback((field: string, item: string) => {
        setForm(prev => {
            const arr = (prev as any)[field] || [];
            const next = arr.includes(item) ? arr.filter((x: string) => x !== item) : [...arr, item];
            const updated = { ...prev, [field]: next };
            onChange?.(updated);
            return updated;
        });
    }, [onChange]);

    // ============================================
    // RENDER HELPERS
    // ============================================

    const inputCls = 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed';
    const rangeInputCls = (field: string, value: number | null | undefined) =>
        `${inputCls}${isOutOfRange(field, value) ? ' !border-red-500 !ring-red-300' : ''}`;
    const labelCls = 'block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1';
    const checkCls = 'w-4 h-4 text-indigo-600 border-gray-300 dark:border-gray-600 rounded focus:ring-indigo-500 disabled:opacity-50';
    const sectionCls = 'bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 space-y-4';
    const sectionTitle = 'text-base font-semibold text-gray-800 dark:text-gray-200 mb-3 flex items-center gap-2';

    return (
        <div className="space-y-6">
            {/* ====== SCORES DISPLAY ====== */}
            <div>
                <h3 className={sectionTitle}>
                    <span className="text-lg">📊</span> Scores cardiologiques
                </h3>
                <CardiologyScoreCards scores={scores} />
            </div>

            {/* ====== SECTION 1: Patient Info ====== */}
            <div className={sectionCls}>
                <h3 className={sectionTitle}>
                    <span className="text-lg">👤</span> Informations patient
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                    {patientFullName && (
                        <div className="col-span-2">
                            <label className={labelCls}>Nom du patient</label>
                            <div className={`${inputCls} bg-gray-100 dark:bg-gray-600 cursor-default font-medium`}>
                                {patientFullName}
                            </div>
                        </div>
                    )}
                    <div>
                        <label className={labelCls}>Âge</label>
                        <input type="number" value={form.patient_age ?? ''} onChange={e => updateField('patient_age', e.target.value ? parseInt(e.target.value) : null)} className={inputCls} disabled={readOnly} min={0} max={120} />
                    </div>
                    <div>
                        <label className={labelCls}>Sexe</label>
                        <select value={form.patient_sex ?? ''} onChange={e => updateField('patient_sex', e.target.value || null)} className={inputCls} disabled={readOnly}>
                            <option value="">—</option>
                            <option value="homme">Homme</option>
                            <option value="femme">Femme</option>
                        </select>
                    </div>
                    <div>
                        <label className={labelCls}>Poids (kg)</label>
                        <input type="number" value={form.patient_weight ?? ''} onChange={e => updateField('patient_weight', e.target.value ? parseFloat(e.target.value) : null)} className={inputCls} disabled={readOnly} step="0.1" />
                    </div>
                    <div>
                        <label className={labelCls}>Taille (cm)</label>
                        <input type="number" value={form.patient_height ?? ''} onChange={e => updateField('patient_height', e.target.value ? parseFloat(e.target.value) : null)} className={inputCls} disabled={readOnly} step="0.1" />
                    </div>
                    <div>
                        <label className={labelCls}>IMC</label>
                        <div className={`${inputCls} bg-gray-100 dark:bg-gray-600 cursor-default`}>
                            {bmi ? `${bmi} kg/m²` : '—'}
                        </div>
                    </div>
                </div>
            </div>

            {/* ====== SECTION 2: Clinical Exam ====== */}
            <div className={sectionCls}>
                <h3 className={sectionTitle}>
                    <span className="text-lg">🩺</span> Examen clinique
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                    <div>
                        <label className={labelCls}>FC (bpm)</label>
                        <input type="number" value={form.heart_rate ?? ''} onChange={e => updateField('heart_rate', e.target.value ? parseInt(e.target.value) : null)} className={rangeInputCls('heart_rate', form.heart_rate)} disabled={readOnly} />
                        {isOutOfRange('heart_rate', form.heart_rate) && <p className="text-xs text-red-500 mt-0.5">Valeur hors plage (30-250)</p>}
                    </div>
                    <div>
                        <label className={labelCls}>PA systolique (mmHg)</label>
                        <input type="number" value={form.systolic_bp ?? ''} onChange={e => updateField('systolic_bp', e.target.value ? parseInt(e.target.value) : null)} className={rangeInputCls('systolic_bp', form.systolic_bp)} disabled={readOnly} />
                        {isOutOfRange('systolic_bp', form.systolic_bp) && <p className="text-xs text-red-500 mt-0.5">Valeur hors plage (60-260)</p>}
                    </div>
                    <div>
                        <label className={labelCls}>PA diastolique (mmHg)</label>
                        <input type="number" value={form.diastolic_bp ?? ''} onChange={e => updateField('diastolic_bp', e.target.value ? parseInt(e.target.value) : null)} className={rangeInputCls('diastolic_bp', form.diastolic_bp)} disabled={readOnly} />
                        {isOutOfRange('diastolic_bp', form.diastolic_bp) && <p className="text-xs text-red-500 mt-0.5">Valeur hors plage (30-160)</p>}
                    </div>
                    <div>
                        <label className={labelCls}>SpO₂ (%)</label>
                        <input type="number" value={form.spo2 ?? ''} onChange={e => updateField('spo2', e.target.value ? parseInt(e.target.value) : null)} className={rangeInputCls('spo2', form.spo2)} disabled={readOnly} min={0} max={100} />
                        {isOutOfRange('spo2', form.spo2) && <p className="text-xs text-red-500 mt-0.5">Valeur hors plage (50-100)</p>}
                    </div>
                    <div>
                        <label className={labelCls}>Auscultation</label>
                        <select value={form.auscultation ?? ''} onChange={e => updateField('auscultation', e.target.value || null)} className={inputCls} disabled={readOnly}>
                            {AUSCULTATION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={labelCls}>Œdèmes MI</label>
                        <select value={form.lower_limb_edema ?? ''} onChange={e => updateField('lower_limb_edema', e.target.value || null)} className={inputCls} disabled={readOnly}>
                            {EDEMA_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className={labelCls}>Classe NYHA</label>
                        <select value={form.nyha_class ?? ''} onChange={e => updateField('nyha_class', e.target.value ? parseInt(e.target.value) : null)} className={inputCls} disabled={readOnly}>
                            <option value="">—</option>
                            <option value="1">I</option>
                            <option value="2">II</option>
                            <option value="3">III</option>
                            <option value="4">IV</option>
                        </select>
                    </div>
                    <div>
                        <label className={labelCls}>Douleur thoracique</label>
                        <select value={form.chest_pain ?? ''} onChange={e => updateField('chest_pain', e.target.value || null)} className={inputCls} disabled={readOnly}>
                            {CHEST_PAIN_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                    </div>
                </div>
                {/* Heart failure signs */}
                <div>
                    <label className={labelCls}>Signes d&apos;insuffisance cardiaque</label>
                    <div className="flex flex-wrap gap-3">
                        {HF_SIGNS.map(sign => (
                            <label key={sign} className="flex items-center gap-1.5 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={(form.heart_failure_signs || []).includes(sign)}
                                    onChange={() => toggleArrayItem('heart_failure_signs', sign)}
                                    className={checkCls}
                                    disabled={readOnly}
                                />
                                {sign}
                            </label>
                        ))}
                    </div>
                </div>
            </div>

            {/* ====== SECTION 3: History ====== */}
            <div className={sectionCls}>
                <h3 className={sectionTitle}>
                    <span className="text-lg">📋</span> Antécédents cardiologiques
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {[
                        { key: 'has_hta', label: 'HTA' },
                        { key: 'has_diabetes', label: 'Diabète' },
                        { key: 'has_diabetes_insulin', label: '↳ Sous insuline' },
                        { key: 'has_afib', label: 'Fibrillation auriculaire' },
                        { key: 'has_mi', label: 'IDM' },
                        { key: 'has_stroke', label: 'AVC / AIT' },
                        { key: 'has_heart_failure', label: 'Insuffisance cardiaque' },
                        { key: 'has_arteriopathy', label: 'Artériopathie' },
                        { key: 'has_valvulopathy', label: 'Valvulopathie' },
                        { key: 'has_active_smoking', label: 'Tabac actif' },
                        { key: 'has_stopped_smoking', label: 'Tabac sevré' },
                        { key: 'has_dyslipidemia', label: 'Dyslipidémie' },
                        { key: 'has_endocarditis', label: 'Endocardite' },
                        { key: 'has_prior_cardiac_surgery', label: 'Chirurgie cardiaque antérieure' },
                        { key: 'has_chronic_lung_disease', label: 'Maladie pulmonaire chronique' },
                        { key: 'has_reduced_mobility', label: 'Mobilité réduite' },
                        { key: 'has_hepatic_anomaly', label: 'Anomalie hépatique' },
                        { key: 'has_bleeding_history', label: 'Antécédent hémorragique' },
                        { key: 'has_nsaid_antiplatelet', label: 'AINS / Antiagrégants' },
                        { key: 'has_excessive_alcohol', label: 'Alcool excessif' },
                    ].map(({ key, label }) => (
                        <label key={key} className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                            <input
                                type="checkbox"
                                checked={!!(form as any)[key]}
                                onChange={e => updateField(key, e.target.checked)}
                                className={checkCls}
                                disabled={readOnly}
                            />
                            {label}
                        </label>
                    ))}
                </div>
                <div className="grid grid-cols-2 gap-3 mt-3">
                    <div>
                        <label className={labelCls}>FEVG connue (%)</label>
                        <input type="number" value={form.known_lvef ?? ''} onChange={e => updateField('known_lvef', e.target.value ? parseFloat(e.target.value) : null)} className={inputCls} disabled={readOnly} min={0} max={100} step="0.1" />
                    </div>
                    <div>
                        <label className={labelCls}>Créatinine (µmol/L)</label>
                        <input type="number" value={form.creatinine ?? ''} onChange={e => updateField('creatinine', e.target.value ? parseFloat(e.target.value) : null)} className={inputCls} disabled={readOnly} step="0.1" />
                    </div>
                </div>
            </div>

            {/* ====== SECTION 4: Complementary Exams ====== */}
            <div className={sectionCls}>
                <h3 className={sectionTitle}>
                    <span className="text-lg">🔬</span> Examens complémentaires
                </h3>

                {/* ECG */}
                <div>
                    <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">ECG</h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                            <label className={labelCls}>Résultat principal</label>
                            <select value={(form as any).ecg_result ?? ''} onChange={e => updateField('ecg_result', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {ECG_RESULTS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className={labelCls}>Détail (texte libre)</label>
                            <input type="text" value={(form as any).ecg_detail ?? ''} onChange={e => updateField('ecg_detail', e.target.value || null)} className={inputCls} disabled={readOnly} placeholder="Précisions..." />
                        </div>
                        <div className="flex items-end pb-2">
                            <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" checked={!!(form as any).ecg_st_deviation} onChange={e => updateField('ecg_st_deviation', e.target.checked)} className={checkCls} disabled={readOnly} />
                                Déviation ST
                            </label>
                        </div>
                    </div>
                </div>

                {/* Echo */}
                <div className="mt-4">
                    <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Échocardiographie</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div>
                            <label className={labelCls}>FEVG (%)</label>
                            <input type="number" value={form.echo_lvef ?? ''} onChange={e => updateField('echo_lvef', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_lvef', form.echo_lvef)} disabled={readOnly} min={0} max={100} step="0.1" />
                            {isOutOfRange('echo_lvef', form.echo_lvef) && <p className="text-xs text-red-500 mt-0.5">Hors plage (5-85)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>DTDVG (mm)</label>
                            <input type="number" value={(form as any).echo_lvedd ?? ''} onChange={e => updateField('echo_lvedd', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_lvedd', (form as any).echo_lvedd)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_lvedd', (form as any).echo_lvedd) && <p className="text-xs text-red-500 mt-0.5">Hors plage (20-90)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>DTSVG (mm)</label>
                            <input type="number" value={form.echo_lvesd ?? ''} onChange={e => updateField('echo_lvesd', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_lvesd', form.echo_lvesd)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_lvesd', form.echo_lvesd) && <p className="text-xs text-red-500 mt-0.5">Hors plage (15-60)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>SIV (mm)</label>
                            <input type="number" value={form.echo_ivs_thickness ?? ''} onChange={e => updateField('echo_ivs_thickness', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_ivs_thickness', form.echo_ivs_thickness)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_ivs_thickness', form.echo_ivs_thickness) && <p className="text-xs text-red-500 mt-0.5">Hors plage (4-20)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>PP (mm)</label>
                            <input type="number" value={form.echo_pw_thickness ?? ''} onChange={e => updateField('echo_pw_thickness', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_pw_thickness', form.echo_pw_thickness)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_pw_thickness', form.echo_pw_thickness) && <p className="text-xs text-red-500 mt-0.5">Hors plage (4-20)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>Taille OG (mm)</label>
                            <input type="number" value={(form as any).echo_la_size ?? ''} onChange={e => updateField('echo_la_size', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_la_size', (form as any).echo_la_size)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_la_size', (form as any).echo_la_size) && <p className="text-xs text-red-500 mt-0.5">Hors plage (15-70)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>TAPSE (mm)</label>
                            <input type="number" value={form.echo_tapse ?? ''} onChange={e => updateField('echo_tapse', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_tapse', form.echo_tapse)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_tapse', form.echo_tapse) && <p className="text-xs text-red-500 mt-0.5">Hors plage (5-35)</p>}
                        </div>
                        <div>
                            <label className={labelCls}>HTAP estimée (mmHg)</label>
                            <input type="number" value={form.echo_pulmonary_htn ?? ''} onChange={e => updateField('echo_pulmonary_htn', e.target.value ? parseFloat(e.target.value) : null)} className={rangeInputCls('echo_pulmonary_htn', form.echo_pulmonary_htn)} disabled={readOnly} step="0.1" />
                            {isOutOfRange('echo_pulmonary_htn', form.echo_pulmonary_htn) && <p className="text-xs text-red-500 mt-0.5">Hors plage (15-120)</p>}
                        </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                        <div>
                            <label className={labelCls}>Cinétique segmentaire</label>
                            <select value={form.echo_wall_motion ?? ''} onChange={e => updateField('echo_wall_motion', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {WALL_MOTION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        {form.echo_wall_motion && form.echo_wall_motion !== 'normal' && (
                            <div>
                                <label className={labelCls}>Territoire concerné</label>
                                <input type="text" value={form.echo_wall_motion_detail ?? ''} onChange={e => updateField('echo_wall_motion_detail', e.target.value || null)} className={inputCls} disabled={readOnly} placeholder="Ex: antéro-septal, inférieur..." />
                            </div>
                        )}
                        <div>
                            <label className={labelCls}>Fonction diastolique</label>
                            <select value={form.echo_diastolic_function ?? ''} onChange={e => updateField('echo_diastolic_function', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {DIASTOLIC_FUNCTION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className={labelCls}>Épanchement péricardique</label>
                            <select value={form.echo_pericardial_effusion ?? ''} onChange={e => updateField('echo_pericardial_effusion', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {PERICARDIAL_EFFUSION_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                    </div>
                    <div className="mt-3">
                        <label className={labelCls}>Valvulopathies</label>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                            {VALVULOPATHIES.map(v => {
                                const isChecked = ((form as any).echo_valvulopathies || []).includes(v);
                                const severity = (form.echo_valvulopathy_severity || {} as Record<string, string>)[v] || '';
                                return (
                                    <div key={v} className="space-y-1">
                                        <label className="flex items-center gap-1.5 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={isChecked}
                                                onChange={() => {
                                                    toggleArrayItem('echo_valvulopathies', v);
                                                    if (isChecked) {
                                                        const sev = { ...(form.echo_valvulopathy_severity || {}) };
                                                        delete sev[v];
                                                        updateField('echo_valvulopathy_severity', Object.keys(sev).length ? sev : null);
                                                    }
                                                }}
                                                className={checkCls}
                                                disabled={readOnly}
                                            />
                                            {v}
                                        </label>
                                        {isChecked && (
                                            <select
                                                value={severity}
                                                onChange={e => {
                                                    const sev = { ...(form.echo_valvulopathy_severity || {}), [v]: e.target.value };
                                                    if (!e.target.value) delete sev[v];
                                                    updateField('echo_valvulopathy_severity', Object.keys(sev).length ? sev : null);
                                                }}
                                                className={`${inputCls} text-xs py-1`}
                                                disabled={readOnly}
                                            >
                                                {VALVULOPATHY_SEVERITY_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                                            </select>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>

                {/* Bio */}
                <div className="mt-4">
                    <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Biologie</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                        {[
                            { key: 'bio_bnp', label: 'BNP/NT-proBNP', step: '0.01' },
                            { key: 'bio_troponin', label: 'Troponine', step: '0.0001' },
                            { key: 'bio_ldl', label: 'LDL (g/L)', step: '0.01' },
                            { key: 'bio_hdl', label: 'HDL (g/L)', step: '0.01' },
                            { key: 'bio_total_cholesterol', label: 'Cholestérol total (g/L)', step: '0.01' },
                            { key: 'bio_triglycerides', label: 'Triglycérides (g/L)', step: '0.01' },
                            { key: 'bio_hba1c', label: 'HbA1c (%)', step: '0.1' },
                            { key: 'bio_creatinine', label: 'Créatinine sérique (µmol/L)', step: '0.01' },
                            { key: 'bio_inr', label: 'INR', step: '0.01' },
                        ].map(({ key, label, step }) => (
                            <div key={key}>
                                <label className={labelCls}>{label}</label>
                                <input
                                    type="number"
                                    value={(form as any)[key] ?? ''}
                                    onChange={e => updateField(key, e.target.value ? parseFloat(e.target.value) : null)}
                                    className={inputCls}
                                    disabled={readOnly}
                                    step={step}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* ====== SECTION 5: Pre-operative (collapsible) ====== */}
            <div className={sectionCls}>
                <button
                    type="button"
                    onClick={() => setShowPreop(!showPreop)}
                    className="w-full flex items-center justify-between"
                >
                    <h3 className={sectionTitle}>
                        <span className="text-lg">🏥</span> Évaluation pré-opératoire (optionnel — EuroSCORE II)
                    </h3>
                    {showPreop ? <ChevronUpIcon className="w-5 h-5 text-gray-400" /> : <ChevronDownIcon className="w-5 h-5 text-gray-400" />}
                </button>
                {showPreop && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                        <div>
                            <label className={labelCls}>Urgence</label>
                            <select value={form.preop_urgency ?? ''} onChange={e => updateField('preop_urgency', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {URGENCY_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className={labelCls}>Type de chirurgie</label>
                            <select value={form.preop_surgery_type ?? ''} onChange={e => updateField('preop_surgery_type', e.target.value || null)} className={inputCls} disabled={readOnly}>
                                {SURGERY_TYPES.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                            </select>
                        </div>
                        <div className="flex flex-col gap-3 justify-end">
                            <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" checked={!!form.preop_critical_state} onChange={e => updateField('preop_critical_state', e.target.checked)} className={checkCls} disabled={readOnly} />
                                État critique pré-opératoire
                            </label>
                            <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" checked={!!form.preop_thoracic_aorta} onChange={e => updateField('preop_thoracic_aorta', e.target.checked)} className={checkCls} disabled={readOnly} />
                                Chirurgie aorte thoracique
                            </label>
                            <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                                <input type="checkbox" checked={!!form.preop_dialysis} onChange={e => updateField('preop_dialysis', e.target.checked)} className={checkCls} disabled={readOnly} />
                                Dialyse
                            </label>
                        </div>
                    </div>
                )}
            </div>

            {/* ====== SECTION 6: Free Notes ====== */}
            <div className={sectionCls}>
                <h3 className={sectionTitle}>
                    <span className="text-lg">📝</span> Notes libres
                </h3>
                <textarea
                    value={(form as any).free_notes ?? ''}
                    onChange={e => updateField('free_notes', e.target.value || null)}
                    rows={4}
                    placeholder="Notes additionnelles..."
                    className={`${inputCls} resize-none`}
                    disabled={readOnly}
                />
            </div>
        </div>
    );
}
