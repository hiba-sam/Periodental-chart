// ─── Enums ───────────────────────────────────────────────
export type EcgRythme = 'Sinusal' | 'FA' | 'Flutter' | 'ESV fréquentes' | 'BAV' | 'Autre';
export type EcgAxe = 'Normal' | 'Déviation gauche' | 'Déviation droite' | 'Indéterminé';
export type Pericarde = 'Sec' | 'Épanchement minime' | 'Épanchement modéré' | 'Épanchement abondant';

export const ECG_RYTHMES: EcgRythme[] = ['Sinusal', 'FA', 'Flutter', 'ESV fréquentes', 'BAV', 'Autre'];
export const ECG_AXES: EcgAxe[] = ['Normal', 'Déviation gauche', 'Déviation droite', 'Indéterminé'];
export const PERICARDES: Pericarde[] = ['Sec', 'Épanchement minime', 'Épanchement modéré', 'Épanchement abondant'];

// ─── Traitement ──────────────────────────────────────────
export interface Traitement {
    nom: string;
    dose: string;
    freq: string;
    actif: boolean;
}

// ─── Full DB Record ──────────────────────────────────────
export interface ActeCardiologue {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    date_acte: string;
    motif: string;

    // Constantes
    pa_systolique: number | null;
    pa_diastolique: number | null;
    frequence_cardiaque: number | null;
    spo2: number | null;
    frequence_respiratoire: number | null;
    poids: number | null;
    taille: number | null;

    // ECG
    ecg_rythme: EcgRythme | null;
    ecg_fc: number | null;
    ecg_pr: string;
    ecg_qrs: string;
    ecg_qtc: string;
    ecg_axe: EcgAxe | null;
    ecg_anomalies: string;
    ecg_conclusion: string;

    // ETT
    ett_fevg: number | null;
    ett_dtd_vg: number | null;
    ett_og: number | null;
    ett_cinetique: string;
    ett_valve_mitrale: string;
    ett_valve_aortique: string;
    ett_valve_tricuspide: string;
    ett_paps: number | null;
    ett_pericarde: Pericarde | null;
    ett_conclusion: string;

    // Biologie
    bio_glycemie: number | null;
    bio_hba1c: number | null;
    bio_cholesterol_total: number | null;
    bio_ldl: number | null;
    bio_hdl: number | null;
    bio_triglycerides: number | null;
    bio_creatinine: number | null;
    bio_uree: number | null;
    bio_potassium: number | null;
    bio_hemoglobine: number | null;
    bio_date: string | null;

    // Traitements & notes
    traitements: Traitement[];
    notes: string;
    conduite_a_tenir: string;
    prochain_rdv: string | null;

    // Audit
    created_at: string;
    updated_at: string;
    doctor_name?: string;
    doctor_family_name?: string;
}

// ─── Form Data (create/update payload) ───────────────────
export interface ActeCardiologueFormData {
    motif: string;
    pa_systolique: number | null;
    pa_diastolique: number | null;
    frequence_cardiaque: number | null;
    spo2: number | null;
    frequence_respiratoire: number | null;
    poids: number | null;
    taille: number | null;
    ecg_rythme: EcgRythme;
    ecg_fc: number | null;
    ecg_pr: string;
    ecg_qrs: string;
    ecg_qtc: string;
    ecg_axe: EcgAxe;
    ecg_anomalies: string;
    ecg_conclusion: string;
    ett_fevg: number | null;
    ett_dtd_vg: number | null;
    ett_og: number | null;
    ett_cinetique: string;
    ett_valve_mitrale: string;
    ett_valve_aortique: string;
    ett_valve_tricuspide: string;
    ett_paps: number | null;
    ett_pericarde: Pericarde;
    ett_conclusion: string;
    bio_glycemie: number | null;
    bio_hba1c: number | null;
    bio_cholesterol_total: number | null;
    bio_ldl: number | null;
    bio_hdl: number | null;
    bio_triglycerides: number | null;
    bio_creatinine: number | null;
    bio_uree: number | null;
    bio_potassium: number | null;
    bio_hemoglobine: number | null;
    bio_date: string | null;
    traitements: Traitement[];
    notes: string;
    conduite_a_tenir: string;
    prochain_rdv: string | null;
}

export const DEFAULT_FORM_DATA: ActeCardiologueFormData = {
    motif: '',
    pa_systolique: null,
    pa_diastolique: null,
    frequence_cardiaque: null,
    spo2: null,
    frequence_respiratoire: null,
    poids: null,
    taille: null,
    ecg_rythme: 'Sinusal',
    ecg_fc: null,
    ecg_pr: '',
    ecg_qrs: '',
    ecg_qtc: '',
    ecg_axe: 'Normal',
    ecg_anomalies: '',
    ecg_conclusion: '',
    ett_fevg: null,
    ett_dtd_vg: null,
    ett_og: null,
    ett_cinetique: '',
    ett_valve_mitrale: '',
    ett_valve_aortique: '',
    ett_valve_tricuspide: '',
    ett_paps: null,
    ett_pericarde: 'Sec',
    ett_conclusion: '',
    bio_glycemie: null,
    bio_hba1c: null,
    bio_cholesterol_total: null,
    bio_ldl: null,
    bio_hdl: null,
    bio_triglycerides: null,
    bio_creatinine: null,
    bio_uree: null,
    bio_potassium: null,
    bio_hemoglobine: null,
    bio_date: null,
    traitements: [],
    notes: '',
    conduite_a_tenir: '',
    prochain_rdv: null,
};

// ─── Biology reference ranges (Algerian lab context) ─────
export const BIO_REFS: Record<string, { label: string; unite: string; ref: string; min?: number; max?: number }> = {
    bio_glycemie:          { label: 'Glycémie',           unite: 'g/L',     ref: '0.70–1.10', min: 0.70, max: 1.10 },
    bio_hba1c:             { label: 'HbA1c',              unite: '%',       ref: '< 7.0',     max: 7.0 },
    bio_cholesterol_total: { label: 'Cholestérol total',  unite: 'g/L',     ref: '< 2.0',     max: 2.0 },
    bio_ldl:               { label: 'LDL',                unite: 'g/L',     ref: '< 0.55',    max: 0.55 },
    bio_hdl:               { label: 'HDL',                unite: 'g/L',     ref: '> 0.40',    min: 0.40 },
    bio_triglycerides:     { label: 'Triglycérides',      unite: 'g/L',     ref: '< 1.50',    max: 1.50 },
    bio_creatinine:        { label: 'Créatinine',         unite: 'µmol/L',  ref: '60–110',    min: 60, max: 110 },
    bio_uree:              { label: 'Urée',               unite: 'g/L',     ref: '0.15–0.45', min: 0.15, max: 0.45 },
    bio_potassium:         { label: 'K⁺',                 unite: 'mmol/L',  ref: '3.5–5.0',   min: 3.5, max: 5.0 },
    bio_hemoglobine:       { label: 'Hémoglobine',        unite: 'g/dL',    ref: '13–17',     min: 13, max: 17 },
};

// ─── Constantes reference ranges for alert colors ────────
export const CONSTANTES_REFS = {
    pa_systolique:         { min: 90,  max: 140, dangerHigh: 180, dangerLow: 80 },
    pa_diastolique:        { min: 60,  max: 90,  dangerHigh: 110, dangerLow: 50 },
    frequence_cardiaque:   { min: 50,  max: 100, dangerHigh: 130, dangerLow: 40 },
    spo2:                  { min: 95,  max: 100, dangerLow: 90 },
    frequence_respiratoire:{ min: 12,  max: 20,  dangerHigh: 30,  dangerLow: 8 },
};
