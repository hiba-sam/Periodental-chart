'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { XMarkIcon, DocumentTextIcon, PrinterIcon, MicrophoneIcon, StopIcon, SparklesIcon, PhotoIcon, TrashIcon, PlusIcon, ClipboardDocumentListIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import { ParodontalStatusModal } from '@/features/dental/components';
import type {
    AddMedicalReportModalProps,
    MedicalReportFormData,
    AIQuotaInfo,
    MedicalReportAI,
} from '../types';
import {
    createMedicalReport,
    fetchAIQuota,
    generateMedicalReportFromAudio,
    openMedicalReportPdf,
} from '../api';
import { fetchPatientDentalActs } from '../../dental/api/dental.api';

const MAX_RECORDING_SECONDS = 180; // 3 minutes

export default function AddMedicalReportModal({
    isOpen,
    onClose,
    patientId,
    patientName,
    patientFamilyName,
    patientDateNaissance,
    patientGenre,
    onSuccess
}: AddMedicalReportModalProps) {
    // États principaux
    const { t } = useLanguage();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [showPrintOption, setShowPrintOption] = useState(false);
    const [createdReportId, setCreatedReportId] = useState<number | null>(null);
    const [isPerioModalOpen, setIsPerioModalOpen] = useState(false);
    const [latestPerioExam, setLatestPerioExam] = useState<any>(null);
    const [todaysDentalActs, setTodaysDentalActs] = useState<any[]>([]);

    // États pour la dictée vocale
    const [isRecording, setIsRecording] = useState(false);
    const [isTranscribing, setIsTranscribing] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0);
    const [quotaInfo, setQuotaInfo] = useState<AIQuotaInfo | null>(null);

    // Refs
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

    // Formulaire
    const [formData, setFormData] = useState<MedicalReportFormData>({
        title: '',
        content: '',
        examination_date: new Date().toISOString().split('T')[0] ?? '',
        radiographs: []
    });

    // Charger le quota au montage
    useEffect(() => {
        if (isOpen) {
            loadQuota();
            fetchLatestPerioExam();
            fetchDentalActs();
        }
    }, [isOpen]);

    const fetchLatestPerioExam = async () => {
        try {
            const res = await fetch(`/api/perio/charts?patient_id=${patientId}&limit=1`);
            const data = await res.json();
            if (Array.isArray(data) && data.length > 0) {
                setLatestPerioExam(data[0]);
            }
        } catch (err) {
            console.error('Error fetching perio data:', err);
        }
    };

    const fetchDentalActs = async () => {
        try {
            const res = await fetchPatientDentalActs(patientId);
            if (res.success && res.data) {
                // Filter by today's date (or the examination date)
                const today = formData.examination_date;
                const filtered = res.data.filter(act => {
                    const actDate = act.date_act.split('T')[0];
                    return actDate === today;
                });
                setTodaysDentalActs(filtered);
            }
        } catch (err) {
            console.error('Error fetching dental acts:', err);
        }
    };

    // Refetch dental acts when examination date changes
    useEffect(() => {
        if (isOpen) {
            fetchDentalActs();
        }
    }, [formData.examination_date]);

    // Bloquer le scroll du body quand le modal est ouvert
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
        return () => {
            document.body.style.overflow = '';
        };
    }, [isOpen]);

    // Timer pour l'enregistrement
    useEffect(() => {
        if (isRecording) {
            timerIntervalRef.current = setInterval(() => {
                setRecordingTime(prev => {
                    const newTime = prev + 1;
                    if (newTime >= MAX_RECORDING_SECONDS) {
                        stopRecording();
                        return MAX_RECORDING_SECONDS;
                    }
                    return newTime;
                });
            }, 1000);
        } else {
            if (timerIntervalRef.current) {
                clearInterval(timerIntervalRef.current);
                timerIntervalRef.current = null;
            }
            setRecordingTime(0);
        }
        return () => {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        };
    }, [isRecording]);

    const formatTime = useCallback((seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }, []);

    const loadQuota = async () => {
        const quota = await fetchAIQuota();
        if (quota) {
            setQuotaInfo(quota);
        }
    };



    const handleAddRadiographs = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const newFiles = Array.from(e.target.files).map(file => ({
                file,
                caption: ''
            }));
            setFormData(prev => ({
                ...prev,
                radiographs: [...prev.radiographs, ...newFiles]
            }));
        }
    };

    const handleRemoveRadiograph = (index: number) => {
        setFormData(prev => ({
            ...prev,
            radiographs: prev.radiographs.filter((_, i) => i !== index)
        }));
    };

    const handleCaptionChange = (index: number, caption: string) => {
        setFormData(prev => ({
            ...prev,
            radiographs: prev.radiographs.map((item, i) => i === index ? { ...item, caption } : item)
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        // Validation frontend
        if (!formData.title.trim()) {
            setError('Le titre est obligatoire');
            setLoading(false);
            return;
        }

        if (!formData.content.trim()) {
            setError('Le contenu est obligatoire');
            setLoading(false);
            return;
        }

        const result = await createMedicalReport({
            patient_id: patientId,
            title: formData.title.trim(),
            content: formData.content.trim(),
            examination_date: formData.examination_date,
            radiographs: formData.radiographs.map(r => r.file),
            captions: formData.radiographs.map(r => r.caption)
        });

        if (result.success && result.data) {
            setCreatedReportId(result.data.report.id);
            setShowPrintOption(true);
        } else {
            setError(result.error || 'Erreur lors de la création du compte rendu');
        }

        setLoading(false);
    };

    const handlePrint = () => {
        if (createdReportId) {
            openMedicalReportPdf(createdReportId);
        }
    };

    const handleClose = () => {
        // Arrêter l'enregistrement si actif
        if (isRecording && mediaRecorderRef.current) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }

        setFormData({
            title: '',
            content: '',
            examination_date: new Date().toISOString().split('T')[0] ?? '',
            radiographs: []
        });
        setError('');
        setShowPrintOption(false);
        setCreatedReportId(null);
        if (onSuccess) onSuccess();
        onClose();
    };

    // Démarrer l'enregistrement audio
    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream);
            mediaRecorderRef.current = mediaRecorder;
            audioChunksRef.current = [];

            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunksRef.current.push(event.data);
                }
            };

            mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                await transcribeAudio(audioBlob);

                // Arrêter tous les tracks du stream
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorder.start();
            setIsRecording(true);
            setError('');
        } catch (err) {
            console.error('Erreur d\'accès au microphone:', err);
            setError('Impossible d\'accéder au microphone. Vérifiez les permissions.');
        }
    };

    // Arrêter l'enregistrement
    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    // Générer un compte rendu médical structuré avec IA
    const transcribeAudio = async (audioBlob: Blob) => {
        setIsTranscribing(true);
        setError('');

        const result = await generateMedicalReportFromAudio(audioBlob);

        if (result.success && result.data) {
            const { medical_report, quota } = result.data;

            // Formater le compte rendu structuré
            const structuredContent = formatMedicalReport(medical_report);

            // Remplir le formulaire avec le compte rendu généré
            setFormData(prev => ({
                ...prev,
                title: medical_report.titre || 'Compte rendu médical',
                content: structuredContent
            }));

            // Mettre à jour le quota
            setQuotaInfo({ remaining: quota.remaining, max: quota.max });
            console.log(`✅ Compte rendu généré. Quota restant: ${quota.remaining}/${quota.max}`);
        } else {
            setError(result.error || 'Erreur lors de la génération du compte rendu');
        }

        setIsTranscribing(false);
    };

    // Formater le compte rendu structuré pour l'affichage (style médical professionnel)
    const formatMedicalReport = (report: MedicalReportAI): string => {
        let content = '';

        if (report.date_consultation && report.date_consultation !== 'Non précisé') {
            content += `DATE DE CONSULTATION: ${report.date_consultation}\n\n`;
        }

        if (report.motif_consultation && report.motif_consultation !== 'Non précisé') {
            content += `MOTIF DE CONSULTATION:\n${report.motif_consultation}\n\n`;
        }

        if (report.anamnese && report.anamnese !== 'Non précisé') {
            content += `ANAMNÈSE:\n${report.anamnese}\n\n`;
        }

        if (report.examen_clinique && report.examen_clinique !== 'Non précisé') {
            content += `EXAMEN CLINIQUE:\n${report.examen_clinique}\n\n`;
        }

        if (report.diagnostic && report.diagnostic !== 'Non précisé') {
            content += `DIAGNOSTIC:\n${report.diagnostic}\n\n`;
        }

        if (report.traitement_prescrit && report.traitement_prescrit !== 'Non précisé') {
            content += `TRAITEMENT PRESCRIT:\n${report.traitement_prescrit}\n\n`;
        }

        if (report.recommandations && report.recommandations !== 'Non précisé') {
            content += `RECOMMANDATIONS:\n${report.recommandations}\n\n`;
        }

        if (report.suivi_propose && report.suivi_propose !== 'Non précisé') {
            content += `SUIVI PROPOSÉ:\n${report.suivi_propose}\n\n`;
        }

        if (report.observations_complementaires && report.observations_complementaires !== 'Non précisé') {
            content += `OBSERVATIONS COMPLÉMENTAIRES:\n${report.observations_complementaires}`;
        }

        return content.trim();
    };

    const injectPerioData = () => {
        if (!latestPerioExam) return;

        const dateStr = new Date(latestPerioExam.exam_date || latestPerioExam.created_at).toLocaleDateString('fr-FR');
        const perioText = `\n\n[CONSTATATIONS PARODONTALES DU ${dateStr}]\n` +
            `- Indice de Plaque: ${latestPerioExam.pi_pct}%\n` +
            `- Saignement (BOP): ${latestPerioExam.bop_pct}%\n` +
            `- Sondage Max: ${latestPerioExam.avg_pd} mm\n` +
            `- CAL Moyen: ${latestPerioExam.avg_cal} mm\n`;

        setFormData(prev => ({
            ...prev,
            content: prev.content + perioText
        }));
    };

    const injectDentalActs = () => {
        if (todaysDentalActs.length === 0) return;

        let actsText = `\n\n[ACTES DENTAIRES RÉALISÉS LE ${new Date(formData.examination_date).toLocaleDateString('fr-FR')}]\n`;
        todaysDentalActs.forEach(act => {
            actsText += `- ${act.act_label || act.notes || 'Acte sans libellé'} ${act.teeth ? `(Dents: ${act.teeth})` : ''}\n`;
        });

        setFormData(prev => ({
            ...prev,
            content: prev.content + actsText
        }));
    };

    if (!isOpen) return null;

    // Success state after creation
    if (showPrintOption && createdReportId) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 transform transition-all">
                    <div className="p-6">
                        <div className="text-center">
                            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                                <DocumentTextIcon className="w-8 h-8 text-green-600 dark:text-green-400" />
                            </div>
                            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                                {t('medicalReport.successTitle')}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                                {t('medicalReport.successDescription')} <strong>{patientName} {patientFamilyName}</strong>.
                            </p>

                            <div className="flex flex-col gap-3">
                                <button
                                    onClick={handlePrint}
                                    className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                                >
                                    <PrinterIcon className="w-5 h-5" />
                                    {t('medicalReport.print')}
                                </button>
                                <button
                                    onClick={handleClose}
                                    className="w-full px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                                >
                                    {t('common.close')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    // Form state
    return (
        <>
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full mx-4 flex flex-col transform transition-all" style={{ maxHeight: '96vh' }}>
                {/* Fixed Header */}
                <div className="flex-shrink-0 flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 rounded-t-2xl">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                            <DocumentTextIcon className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                            {t('medicalReport.newReport')}
                        </h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {t('medicalReport.for')} {patientName} {patientFamilyName}
                            {patientDateNaissance && ` • ${t('medicalReport.bornOn')} ${new Date(patientDateNaissance).toLocaleDateString('fr-FR')}`}
                            {patientGenre && ` • ${patientGenre === 'homme' ? t('medicalReport.male') : t('medicalReport.female')}`}
                        </p>
                    </div>
                    <div className="flex items-center gap-3">
                        <button
                            type="button"
                            onClick={() => setIsPerioModalOpen(true)}
                            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-lg shadow-indigo-200 dark:shadow-none transition-all font-medium text-sm"
                        >
                            <PlusIcon className="w-5 h-5" />
                            status parodontale
                        </button>
                        <button
                            onClick={handleClose}
                            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                        >
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>
                </div>

                {/* Periodontal KPIs - New section from image */}
                <div className="flex-shrink-0 px-6 py-4 bg-gray-50/50 dark:bg-gray-900/10 border-b border-gray-200 dark:border-gray-700">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {/* Plaque Index */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 border-yellow-500 shadow-sm border border-gray-100 dark:border-gray-700">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">PLAQUE INDEX</p>
                            <div className="flex items-baseline gap-1">
                                <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">{latestPerioExam?.pi_pct ?? '--'}</span>
                                <span className="text-sm font-bold text-gray-900 dark:text-gray-100">%</span>
                            </div>
                        </div>

                        {/* BOP */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 border-red-500 shadow-sm border border-gray-100 dark:border-gray-700">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">BOP (SAIGNEMENT)</p>
                            <div className="flex items-baseline gap-1">
                                <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">{latestPerioExam?.bop_pct ?? '--'}</span>
                                <span className="text-sm font-bold text-gray-900 dark:text-gray-100">%</span>
                            </div>
                        </div>

                        {/* Sondage Max */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 border-rose-700 shadow-sm border border-gray-100 dark:border-gray-700">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">SONDAGE MAX</p>
                            <div className="flex items-baseline gap-1">
                                <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">{latestPerioExam?.avg_pd ?? '--'}</span>
                                <span className="text-xs text-gray-500 font-medium ml-1 text-gray-400">mm</span>
                            </div>
                        </div>

                        {/* CAL Moyen */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 border-orange-400 shadow-sm border border-gray-100 dark:border-gray-700">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">CAL MOYEN</p>
                            <div className="flex items-baseline gap-1">
                                <span className="text-2xl font-bold text-gray-900 dark:text-gray-100">{latestPerioExam?.avg_cal ?? '--'}</span>
                                <span className="text-xs text-gray-500 font-medium ml-1 text-gray-400">mm</span>
                            </div>
                        </div>
                    </div>
                    {latestPerioExam && (
                        <div className="mt-3 flex justify-end">
                            <button
                                type="button"
                                onClick={injectPerioData}
                                className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-600 hover:text-indigo-700 uppercase tracking-widest bg-indigo-50 dark:bg-indigo-900/30 px-3 py-1.5 rounded-lg transition-colors border border-indigo-100 dark:border-indigo-800"
                            >
                                <ClipboardDocumentListIcon className="w-3.5 h-3.5" />
                                Insérer dans le rapport
                            </button>
                        </div>
                    )}
                </div>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto p-6">
                    {error && (
                        <div className="mb-4 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                            <p className="text-sm text-red-800 dark:text-red-300">{error}</p>
                        </div>
                    )}

                    {/* Bouton Dictée IA avec Quota et Timer */}
                    <div className="mb-4 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg border border-indigo-200 dark:border-indigo-800">
                        {/* Quota Display */}
                        {quotaInfo && (
                            <div className="flex items-center justify-between mb-3 pb-3 border-b border-indigo-200 dark:border-indigo-700">
                                <div className="flex items-center gap-2">
                                    <SparklesIcon className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                                    <span className="text-sm text-gray-700 dark:text-gray-300">Quota mensuel</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className={`text-sm font-bold ${quotaInfo.remaining === 0 ? 'text-red-600' : 'text-indigo-600 dark:text-indigo-400'}`}>
                                        {quotaInfo.remaining}/{quotaInfo.max}
                                    </span>
                                    <div className="w-20 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                        <div
                                            className={`h-2 rounded-full ${quotaInfo.remaining === 0 ? 'bg-red-500' : 'bg-indigo-600'}`}
                                            style={{ width: `${(quotaInfo.remaining / quotaInfo.max) * 100}%` }}
                                        />
                                    </div>
                                </div>
                            </div>
                        )}

                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <SparklesIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                                <div>
                                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t('medicalReport.aiDictation')}</p>
                                    <p className="text-xs text-gray-600 dark:text-gray-400">{t('medicalReport.dictationDescription')}</p>
                                </div>
                            </div>
                            {!isRecording && !isTranscribing && (
                                <button
                                    type="button"
                                    onClick={startRecording}
                                    className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                    disabled={loading || quotaInfo?.remaining === 0}
                                >
                                    <MicrophoneIcon className="w-5 h-5" />
                                    {t('medicalReport.startDictation')}
                                </button>
                            )}
                            {isRecording && (
                                <div className="flex items-center gap-3">
                                    {/* Timer Display */}
                                    <div className="flex items-center gap-2 bg-red-100 dark:bg-red-900/30 px-3 py-1 rounded-lg">
                                        <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                                        <span className="text-lg font-mono font-bold text-red-600 dark:text-red-400">
                                            {formatTime(recordingTime)}
                                        </span>
                                        <span className="text-xs text-gray-500">/ {formatTime(MAX_RECORDING_SECONDS)}</span>
                                    </div>
                                    <button
                                        type="button"
                                        onClick={stopRecording}
                                        className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                                    >
                                        <StopIcon className="w-5 h-5" />
                                        Stop
                                    </button>
                                </div>
                            )}
                            {isTranscribing && (
                                <div className="flex items-center gap-2 px-4 py-2 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 rounded-lg">
                                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-indigo-600 dark:border-indigo-400"></div>
                                    {t('medicalReport.transcribing')}
                                </div>
                            )}
                        </div>

                        {/* Recording Progress Bar */}
                        {isRecording && (
                            <div className="mt-3">
                                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                                    <div
                                        className="bg-red-500 h-1.5 rounded-full transition-all"
                                        style={{ width: `${(recordingTime / MAX_RECORDING_SECONDS) * 100}%` }}
                                    />
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="space-y-6">
                        {/* Title */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                {t('medicalReport.title')} <span className="text-red-500">*</span>
                            </label>
                            <input
                                type="text"
                                value={formData.title}
                                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                                placeholder={t('medicalReport.titlePlaceholder')}
                                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                required
                                disabled={loading}
                            />
                        </div>

                        {/* Examination Date */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                {t('medicalReport.examinationDate')} <span className="text-red-500">*</span>
                            </label>
                            <input
                                type="date"
                                value={formData.examination_date}
                                onChange={(e) => setFormData({ ...formData, examination_date: e.target.value })}
                                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                                required
                                disabled={loading}
                            />
                        </div>

                        {/* Content */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                {t('medicalReport.detailedReport')} <span className="text-red-500">*</span>
                            </label>
                            <textarea
                                value={formData.content}
                                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                                placeholder={t('medicalReport.contentPlaceholder')}
                                rows={12}
                                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                                required
                                disabled={loading}
                            />
                            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                                {t('medicalReport.contentHelper')}
                            </p>
                        </div>

                        {/* Radiographies Section */}
                        <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                            <div className="flex items-center justify-between mb-4">
                                <label className="text-sm font-semibold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                                    <PhotoIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                                    Radiographies et documents
                                </label>
                                <label className="cursor-pointer bg-white dark:bg-gray-700 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all flex items-center gap-2">
                                    <PlusIcon className="w-4 h-4" />
                                    Ajouter
                                    <input
                                        type="file"
                                        multiple
                                        accept="image/*,application/pdf"
                                        className="hidden"
                                        onChange={handleAddRadiographs}
                                        disabled={loading}
                                    />
                                </label>
                            </div>

                            {formData.radiographs.length > 0 ? (
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    {formData.radiographs.map((item, index) => (
                                        <div key={index} className="relative group bg-gray-50 dark:bg-gray-900/30 border border-gray-200 dark:border-gray-700 rounded-xl p-3">
                                            <div className="flex gap-3">
                                                <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-lg flex-shrink-0 overflow-hidden flex items-center justify-center">
                                                    {item.file.type.startsWith('image/') ? (
                                                        <img
                                                            src={URL.createObjectURL(item.file)}
                                                            alt={`Radio ${index}`}
                                                            className="w-full h-full object-cover"
                                                        />
                                                    ) : (
                                                        <DocumentTextIcon className="w-8 h-8 text-gray-400" />
                                                    )}
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <p className="text-xs font-medium text-gray-900 dark:text-gray-100 truncate mb-1">
                                                        {item.file.name}
                                                    </p>
                                                    <input
                                                        type="text"
                                                        value={item.caption}
                                                        onChange={(e) => handleCaptionChange(index, e.target.value)}
                                                        placeholder="Légende de l'image..."
                                                        className="w-full text-xs px-2 py-1.5 border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-indigo-500"
                                                        disabled={loading}
                                                    />
                                                </div>
                                            </div>
                                            <button
                                                type="button"
                                                onClick={() => handleRemoveRadiograph(index)}
                                                className="absolute -top-2 -right-2 bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400 p-1.5 rounded-full shadow-sm hover:bg-red-200 dark:hover:bg-red-800 transition-colors"
                                                disabled={loading}
                                            >
                                                <XMarkIcon className="w-3.5 h-3.5" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-6 bg-gray-50 dark:bg-gray-900/20 rounded-xl border border-dashed border-gray-300 dark:border-gray-700">
                                    <PhotoIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                                    <p className="text-sm text-gray-500 text-gray-400">Aucune radiographie ajoutée</p>
                                </div>
                            )}
                        </div>

                        {/* Dental Acts Injection Button */}
                        {todaysDentalActs.length > 0 && (
                            <div className="pt-6 border-t border-gray-200 dark:border-gray-700">
                                <button
                                    type="button"
                                    onClick={injectDentalActs}
                                    className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 rounded-xl hover:bg-emerald-100 transition-all font-semibold text-sm"
                                >
                                    <ClipboardDocumentListIcon className="w-5 h-5" />
                                    Insérer les {todaysDentalActs.length} actes du {new Date(formData.examination_date).toLocaleDateString('fr-FR')}
                                </button>
                            </div>
                        )}
                    </div>
                </div>

                {/* Fixed Footer */}
                <div className="flex-shrink-0 flex gap-3 p-6 border-t border-gray-200 dark:border-gray-700 rounded-b-2xl bg-white dark:bg-gray-800">
                    <button
                        type="button"
                        onClick={handleClose}
                        className="flex-1 px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                        disabled={loading}
                    >
                        {t('common.cancel')}
                    </button>
                    <button
                        type="button"
                        onClick={handleSubmit}
                        className="flex-1 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                        disabled={loading}
                    >
                        {loading ? (
                            <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                                <span>{t('medicalReport.creating')}</span>
                            </>
                        ) : (
                            <>
                                <DocumentTextIcon className="w-5 h-5" />
                                <span>{t('medicalReport.create')}</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>

        {isPerioModalOpen && (
                <ParodontalStatusModal
                    isOpen={isPerioModalOpen}
                    onClose={() => setIsPerioModalOpen(false)}
                    patientId={patientId}
                    patientName={`${patientName} ${patientFamilyName}`}
                    onSaved={fetchLatestPerioExam}
                />
            )}
        </>
    );
}