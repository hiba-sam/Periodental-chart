// Components barrel export
export { default as AddMedicalReportModal } from './AddMedicalReportModal';
export { default as VoiceDictationButton } from './VoiceDictationButton';
