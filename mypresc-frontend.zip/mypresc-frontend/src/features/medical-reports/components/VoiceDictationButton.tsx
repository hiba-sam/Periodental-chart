'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { MicrophoneIcon, StopIcon, SparklesIcon } from '@heroicons/react/24/outline';
import type { VoiceDictationButtonProps, AIQuotaInfo, MedicalReportAI } from '../types';
import { fetchAIQuota, generateMedicalReportFromAudio } from '../api';

const MAX_RECORDING_SECONDS = 180; // 3 minutes

export default function VoiceDictationButton({ onSuccess, onError }: VoiceDictationButtonProps) {
    const [isRecording, setIsRecording] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [recordingTime, setRecordingTime] = useState(0); // en secondes
    const [quotaInfo, setQuotaInfo] = useState<AIQuotaInfo | null>(null);
    const [error, setError] = useState<string>('');

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

    // Charger le quota au montage
    useEffect(() => {
        loadQuota();
    }, []);

    // Timer pour l'enregistrement
    useEffect(() => {
        if (isRecording) {
            timerIntervalRef.current = setInterval(() => {
                setRecordingTime(prev => {
                    const newTime = prev + 1;
                    // Auto-stop à 3 minutes
                    if (newTime >= MAX_RECORDING_SECONDS) {
                        stopRecording();
                        return MAX_RECORDING_SECONDS;
                    }
                    return newTime;
                });
            }, 1000);
        } else {
            if (timerIntervalRef.current) {
                clearInterval(timerIntervalRef.current);
                timerIntervalRef.current = null;
            }
            setRecordingTime(0);
        }

        return () => {
            if (timerIntervalRef.current) {
                clearInterval(timerIntervalRef.current);
            }
        };
    }, [isRecording]);

    // Formater le temps en MM:SS
    const formatTime = useCallback((seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }, []);

    const loadQuota = async () => {
        const quota = await fetchAIQuota();
        if (quota) {
            setQuotaInfo(quota);
        }
    };

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm;codecs=opus'
            });

            mediaRecorderRef.current = mediaRecorder;
            audioChunksRef.current = [];

            mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    audioChunksRef.current.push(event.data);
                }
            };

            mediaRecorder.onstop = async () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
                await processAudio(audioBlob);

                // Arrêter tous les tracks du stream
                stream.getTracks().forEach(track => track.stop());
            };

            mediaRecorder.start();
            setIsRecording(true);
            setError('');
        } catch (err: any) {
            const errorMsg = 'Impossible d\'accéder au microphone. Vérifiez les permissions.';
            setError(errorMsg);
            if (onError) onError(errorMsg);
        }
    };

    const stopRecording = () => {
        if (mediaRecorderRef.current && isRecording) {
            mediaRecorderRef.current.stop();
            setIsRecording(false);
        }
    };

    const processAudio = async (audioBlob: Blob) => {
        setIsProcessing(true);
        setError('');

        const result = await generateMedicalReportFromAudio(audioBlob);

        if (result.success && result.data) {
            // Mettre à jour le quota
            setQuotaInfo(result.data.quota);
            // Appeler le callback de succès
            onSuccess(result.data.medical_report);
        } else {
            setError(result.error || 'Erreur lors de la génération');
            if (onError) onError(result.error || 'Erreur lors de la génération');
        }

        setIsProcessing(false);
    };

    const isDisabled = isRecording || isProcessing || (quotaInfo?.remaining === 0);

    return (
        <div className="space-y-4">
            {/* Quota Display */}
            {quotaInfo && (
                <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <SparklesIcon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                            <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
                                Quota IA
                            </span>
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                            <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                                {quotaInfo.remaining}
                            </span>
                            {' / '}
                            {quotaInfo.max}
                            {quotaInfo.period && <span className="text-xs ml-1">({quotaInfo.period})</span>}
                        </div>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-2 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                            className="bg-indigo-600 dark:bg-indigo-400 h-2 rounded-full transition-all"
                            style={{
                                width: `${((quotaInfo.max - quotaInfo.remaining) / quotaInfo.max) * 100}%`
                            }}
                        />
                    </div>
                </div>
            )}

            {/* Error Display */}
            {error && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3">
                    <p className="text-sm text-red-800 dark:text-red-400">{error}</p>
                </div>
            )}

            {/* Recording Button */}
            <div className="flex flex-col items-center gap-3">
                {!isRecording && !isProcessing && (
                    <button
                        onClick={startRecording}
                        disabled={isDisabled}
                        className={`
                            flex items-center justify-center gap-3 px-6 py-4 rounded-xl font-medium
                            transition-all transform hover:scale-105 active:scale-95
                            ${isDisabled
                                ? 'bg-gray-300 dark:bg-gray-700 text-gray-500 cursor-not-allowed'
                                : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg'
                            }
                        `}
                    >
                        <MicrophoneIcon className="w-6 h-6" />
                        <span>Dicter un compte rendu</span>
                        <SparklesIcon className="w-5 h-5" />
                    </button>
                )}

                {isRecording && (
                    <div className="flex flex-col items-center gap-3">
                        {/* Timer Display */}
                        <div className="flex items-center gap-4 bg-red-50 dark:bg-red-900/20 rounded-xl px-6 py-3">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                                <span className="text-2xl font-mono font-bold text-red-600 dark:text-red-400">
                                    {formatTime(recordingTime)}
                                </span>
                                <span className="text-sm text-gray-500 dark:text-gray-400">
                                    / {formatTime(MAX_RECORDING_SECONDS)}
                                </span>
                            </div>
                        </div>

                        {/* Progress bar */}
                        <div className="w-full max-w-xs bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div
                                className="bg-red-500 h-2 rounded-full transition-all"
                                style={{ width: `${(recordingTime / MAX_RECORDING_SECONDS) * 100}%` }}
                            />
                        </div>

                        <button
                            onClick={stopRecording}
                            className="flex items-center justify-center gap-3 px-6 py-4 bg-red-600 hover:bg-red-700 text-white rounded-xl font-medium shadow-lg transition-all"
                        >
                            <StopIcon className="w-6 h-6" />
                            <span>Arrêter l'enregistrement</span>
                        </button>
                    </div>
                )}

                {isProcessing && (
                    <div className="flex flex-col items-center gap-3 px-6 py-4">
                        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                            Génération du compte rendu en cours...
                        </p>
                    </div>
                )}

                <p className="text-xs text-gray-500 dark:text-gray-400 text-center max-w-md">
                    {isRecording
                        ? '🎤 Enregistrement en cours... Parlez clairement.'
                        : 'Cliquez pour démarrer l\'enregistrement vocal (max 3 minutes)'
                    }
                </p>
            </div>
        </div>
    );
}
