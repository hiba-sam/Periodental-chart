// Medical Reports Types - Core type definitions for medical report-related data

/**
 * AI-generated medical report structure
 */
export interface MedicalReportAI {
    titre: string;
    date_consultation: string;
    motif_consultation: string;
    anamnese: string;
    examen_clinique: string;
    diagnostic: string;
    traitement_prescrit: string;
    recommandations: string;
    suivi_propose: string;
    observations_complementaires?: string;
}

/**
 * Medical report form data
 */
export interface MedicalReportFormData {
    title: string;
    content: string;
    examination_date: string;
    radiographs: { file: File; caption: string }[];
}

/**
 * Medical report from database
 */
export interface MedicalReport {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    title: string;
    content: string;
    examination_date: string;
    images?: { url: string; caption: string }[] | null;
    created_at: string;
    updated_at: string;
}

/**
 * Payload for creating a medical report
 */
export interface CreateMedicalReportPayload {
    patient_id: string;
    title: string;
    content: string;
    examination_date: string;
    radiographs?: File[];
    captions?: string[];
}

/**
 * API quota information for AI features
 */
export interface AIQuotaInfo {
    remaining: number;
    max: number;
    period?: string;
}

/**
 * Props for AddMedicalReportModal component
 */
export interface AddMedicalReportModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    patientName: string;
    patientFamilyName: string;
    patientDateNaissance?: string | null;
    patientGenre?: string;
    onSuccess?: () => void;
}

/**
 * Props for VoiceDictationButton component
 */
export interface VoiceDictationButtonProps {
    onSuccess: (report: MedicalReportAI) => void;
    onError?: (error: string) => void;
}
