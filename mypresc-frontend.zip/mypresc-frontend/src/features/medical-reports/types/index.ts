// Types barrel export
export * from './medical-report.types';
