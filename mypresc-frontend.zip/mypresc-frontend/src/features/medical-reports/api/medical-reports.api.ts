// Medical Reports API - Centralized API functions for medical report operations
import axios from 'axios';
import type {
    MedicalReport,
    MedicalReportAI,
    CreateMedicalReportPayload,
    AIQuotaInfo,
} from '../types';
import type { CardiologyFormData } from '@/utils/cardiologyScores';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// Axios instance for medical reports
const medicalReportsApi = axios.create({
    baseURL: `${API_URL}/medical-reports`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

// Axios instance for AI features
const aiApi = axios.create({
    baseURL: `${API_URL}/api/ai`,
    withCredentials: true,
});

/**
 * Create a new medical report
 */
export async function createMedicalReport(
    payload: CreateMedicalReportPayload
): Promise<{ success: boolean; data?: { report: MedicalReport }; error?: string }> {
    try {
        let requestData: any = payload;
        let headers: any = { 'Content-Type': 'application/json' };

        if (payload.radiographs && payload.radiographs.length > 0) {
            const formData = new FormData();
            formData.append('patient_id', payload.patient_id);
            formData.append('title', payload.title);
            formData.append('content', payload.content);
            formData.append('examination_date', payload.examination_date);

            payload.radiographs.forEach((file) => {
                formData.append('radiographs', file);
            });

            if (payload.captions) {
                payload.captions.forEach((caption) => {
                    formData.append('captions[]', caption);
                });
            }

            requestData = formData;
            headers = { 'Content-Type': 'multipart/form-data' };
        }

        const response = await medicalReportsApi.post('/', requestData, { headers });
        return { success: true, data: response.data.data };
    } catch (err: any) {
        console.error('Create medical report error:', err);
        return {
            success: false,
            error: err.response?.data?.error || 'Erreur lors de la création du compte rendu',
        };
    }
}

/**
 * Get PDF URL for a medical report
 */
export function getMedicalReportPdfUrl(reportId: number): string {
    return `${API_URL}/medical-reports/${reportId}/pdf`;
}

/**
 * Open medical report PDF in new tab
 */
export function openMedicalReportPdf(reportId: number): void {
    window.open(getMedicalReportPdfUrl(reportId), '_blank');
}

/**
 * Fetch AI quota information
 */
export async function fetchAIQuota(): Promise<AIQuotaInfo | null> {
    try {
        const response = await aiApi.get('/medical-report/quota');
        if (response.data.success) {
            return {
                remaining: response.data.data.remaining,
                max: response.data.data.max,
                period: response.data.data.period,
            };
        }
        return null;
    } catch (err) {
        console.error('Failed to fetch AI quota:', err);
        return null;
    }
}

/**
 * Generate medical report from audio using AI
 */
export async function generateMedicalReportFromAudio(
    audioBlob: Blob
): Promise<{
    success: boolean;
    data?: { medical_report: MedicalReportAI; transcription: string; quota: AIQuotaInfo };
    error?: string;
    errorType?: 'quota' | 'file_size' | 'format' | 'empty_transcription' | 'unknown';
}> {
    try {
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.webm');

        const response = await aiApi.post('/medical-report', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
            timeout: 60000, // 60s timeout
        });

        if (response.data.success) {
            return { success: true, data: response.data.data };
        }
        return { success: false, error: 'Erreur lors de la génération du compte rendu' };
    } catch (err: any) {
        console.error('AI Medical Report Error:', err);

        let errorMessage = 'Erreur lors de la génération du compte rendu';
        let errorType: 'quota' | 'file_size' | 'format' | 'empty_transcription' | 'unknown' = 'unknown';

        if (err.response?.status === 403) {
            errorMessage = 'Quota mensuel atteint (30 comptes rendus max par mois)';
            errorType = 'quota';
        } else if (err.response?.status === 413) {
            errorMessage = 'Fichier audio trop volumineux (max 20 MB)';
            errorType = 'file_size';
        } else if (err.response?.status === 415) {
            errorMessage = 'Format audio non supporté';
            errorType = 'format';
        } else if (err.response?.status === 422) {
            errorMessage = 'La transcription est vide. Parlez plus clairement.';
            errorType = 'empty_transcription';
        } else if (err.response?.data?.error) {
            errorMessage = err.response.data.error;
        }

        return { success: false, error: errorMessage, errorType };
    }
}

/**
 * Generate cardiology structured data from audio using AI
 * Returns CardiologyFormData fields mapped from voice dictation
 */
export async function generateCardiologyReportFromAudio(
    audioBlob: Blob
): Promise<{
    success: boolean;
    data?: {
        cardiology_data: Partial<CardiologyFormData> & { additional_info?: string | null };
        transcription: string;
        quota: AIQuotaInfo;
    };
    error?: string;
    errorType?: 'quota' | 'file_size' | 'format' | 'empty_transcription' | 'unknown';
}> {
    try {
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.webm');

        const response = await aiApi.post('/medical-report/cardiology', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
            timeout: 90000, // 90s timeout (transcription + GPT extraction)
        });

        if (response.data.success) {
            return { success: true, data: response.data.data };
        }
        return { success: false, error: 'Erreur lors de l\'extraction des données cardiologiques' };
    } catch (err: any) {
        console.error('AI Cardiology Report Error:', err);

        let errorMessage = 'Erreur lors de l\'extraction des données cardiologiques';
        let errorType: 'quota' | 'file_size' | 'format' | 'empty_transcription' | 'unknown' = 'unknown';

        if (err.response?.status === 403) {
            errorMessage = 'Quota mensuel atteint (30 comptes rendus max par mois)';
            errorType = 'quota';
        } else if (err.response?.status === 413) {
            errorMessage = 'Fichier audio trop volumineux (max 20 MB)';
            errorType = 'file_size';
        } else if (err.response?.status === 415) {
            errorMessage = 'Format audio non supporté';
            errorType = 'format';
        } else if (err.response?.status === 422) {
            errorMessage = 'La transcription est vide. Parlez plus clairement.';
            errorType = 'empty_transcription';
        } else if (err.response?.data?.error) {
            errorMessage = err.response.data.error;
        }

        return { success: false, error: errorMessage, errorType };
    }
}
