// Dashboard Types - Type definitions for dashboard feature

import { Appointment } from '@/contexts/AppointmentContext';

// ==================== API Response Types ====================

/**
 * Dashboard stats returned from /dashboard/stats endpoint
 */
export interface DashboardStatsResponse {
  success: boolean;
  data: {
    stats: {
      totalAppointmentsToday: number;
      completedAppointments: number;
      waitingPatients: number;
    };
    todayAppointments: Appointment[];
  };
}

/**
 * Processed dashboard stats for components
 */
export interface DashboardStats {
  totalAppointments: number;
  completedAppointments: number;
  waitingPatients: number;
}

// ==================== Chart Types ====================

/**
 * Data point for patient statistics charts
 */
export interface PatientChartDataPoint {
  period: string;
  patients: number;
}

/**
 * Patient statistics data structure
 */
export interface PatientStatistics {
  weeklyData: PatientChartDataPoint[];
  monthlyData: PatientChartDataPoint[];
  yearlyData: PatientChartDataPoint[];
}

/**
 * Chart period options
 */
export type ChartPeriod = 'week' | 'month' | 'year';

/**
 * Patient chart variant
 */
export type PatientChartVariant = 'new' | 'old';

// ==================== Widget Types ====================

/**
 * Props for StatsCard component
 */
export interface StatsCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  onClick?: () => void;
  isLoading?: boolean;
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

/**
 * Quick stats configuration
 */
export interface QuickStatsConfig {
  totalAppointments: {
    onClick?: () => void;
  };
  completedAppointments: {
    onClick?: () => void;
  };
  waitingPatients: {
    onClick?: () => void;
  };
}
