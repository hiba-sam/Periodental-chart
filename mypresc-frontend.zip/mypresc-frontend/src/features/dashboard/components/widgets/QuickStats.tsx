'use client';

import React, { memo } from 'react';
import {
    CalendarDaysIcon,
    CheckCircleIcon,
    UsersIcon,
} from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQuickStats } from '../../hooks';
import { StatsCard } from './StatsCard';
import type { QuickStatsConfig } from '../../types';

interface QuickStatsProps {
    userId?: string;
    config?: QuickStatsConfig;
}

function QuickStatsBase({ userId, config }: QuickStatsProps) {
    const { t } = useLanguage();
    const { totalAppointments, completedAppointments, waitingPatients, isLoading } =
        useQuickStats(userId);

    return (
        <div className="grid grid-cols-1 gap-6 mb-6 sm:grid-cols-2 lg:grid-cols-3">
            <StatsCard
                title={t('dashboard.totalAppointments')}
                value={totalAppointments}
                icon={<CalendarDaysIcon className="w-6 h-6 text-blue-500" />}
                onClick={config?.totalAppointments?.onClick}
                isLoading={isLoading}
            />
            <StatsCard
                title={t('dashboard.completedAppointments') || 'RDV effectués'}
                value={completedAppointments}
                icon={<CheckCircleIcon className="w-6 h-6 text-green-500" />}
                onClick={config?.completedAppointments?.onClick}
                isLoading={isLoading}
            />
            <StatsCard
                title={t('dashboard.waitingPatients')}
                value={waitingPatients}
                icon={<UsersIcon className="w-6 h-6 text-green-500" />}
                onClick={config?.waitingPatients?.onClick}
                isLoading={isLoading}
            />
        </div>
    );
}

// Memoized export
export const QuickStats = memo(QuickStatsBase);
