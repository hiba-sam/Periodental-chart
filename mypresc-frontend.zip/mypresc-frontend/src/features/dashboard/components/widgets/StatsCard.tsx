'use client';

import React, { memo } from 'react';
import Link from 'next/link';
import { ChevronRightIcon, ChevronLeftIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import type { StatsCardProps } from '../../types';

// Loading skeleton for the card
const StatsCardSkeleton = memo(function StatsCardSkeleton() {
    return (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 flex flex-col justify-center border border-gray-200 dark:border-gray-700 animate-pulse">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-gray-200 dark:bg-gray-700 rounded-full w-10 h-10"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                </div>
            </div>
            <div className="flex items-center justify-between mt-4">
                <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-16"></div>
            </div>
        </div>
    );
});

function StatsCardBase({
    title,
    value,
    icon,
    onClick,
    isLoading = false,
    trend,
}: StatsCardProps) {
    const { t, isRTL } = useLanguage();
    const isClickable = !!onClick;

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;

    if (isLoading) {
        return <StatsCardSkeleton />;
    }
    return (
        <div
            className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 flex flex-col md:gap-4 justify-center border border-gray-200 dark:border-gray-700 transition-all duration-200 ${isClickable
                    ? 'cursor-pointer hover:shadow-lg hover:border-blue-400 dark:hover:border-blue-500 hover:scale-[1.02] group'
                    : ''
                }`}
            onClick={isMobile ? undefined : onClick}
        >
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div
                        className={`p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-600 dark:text-blue-400 mr-3 transition-colors ${isClickable ? 'group-hover:bg-blue-200 dark:group-hover:bg-blue-800/50' : ''
                            }`}
                    >
                        {icon}
                    </div>
                    <h3 className="text-sm font-bold text-gray-700 dark:text-gray-300 tracking-wide">
                        {title}
                    </h3>
                </div>
                <p className="text-3xl font-bold text-gray-900 dark:text-gray-100 md:hidden">{value}</p>

                {isClickable && !isMobile &&
                    (isRTL ? (
                        <ChevronLeftIcon className="h-5 w-5 text-gray-400 dark:text-gray-500 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors group-hover:-translate-x-1" />
                    ) : (
                        <ChevronRightIcon className="h-5 w-5 text-gray-400 dark:text-gray-500 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors group-hover:translate-x-1" />
                    ))}
            </div>

            <div className="flex items-center justify-between">
                <p className="text-3xl font-bold text-gray-900 dark:text-gray-100 hidden md:block">{value}</p>
                <div className="flex items-center gap-2">
                    {trend && (
                        <span
                            className={`text-xs font-medium ${trend.isPositive ? 'text-green-600' : 'text-red-600'
                                }`}
                        >
                            {trend.isPositive ? '+' : '-'}{trend.value}%
                        </span>
                    )}
                    {isClickable && !isMobile && (
                        <span className="text-xs text-gray-400 dark:text-gray-500 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                            {t('dashboard.clickForDetails')}
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
}

// Memoized export
export const StatsCard = memo(StatsCardBase);
