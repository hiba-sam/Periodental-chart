'use client';

import React, { memo } from 'react';
import Link from 'next/link';
import { UsersIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface DashboardHeaderProps {
    userRole?: string;
    onNextPatientClick: () => void;
}

function DashboardHeaderBase({ userRole, onNextPatientClick }: DashboardHeaderProps) {
    const { t } = useLanguage();

    const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;


    return (
        <div className="flex flex-col items-start justify-between mb-8 sm:flex-row sm:items-center sm:mb-10">
            <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-gray-800 dark:text-gray-100 sm:text-4xl">
                    {userRole === 'assistant' ? t('dashboard.title.assistant') : t('dashboard.title.doctor')}
                </h1>
                <p className="mt-1 text-base text-gray-500 dark:text-gray-400 sm:mt-2 sm:text-lg">
                    {t('dashboard.subtitle')}
                </p>
            </div>
            <div className="flex gap-3 md:mt-4 sm:mt-0 md:min-h-[48px] items-center">
                {!isMobile && userRole === 'doctor' && (
                    <button
                        onClick={onNextPatientClick}
                        className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-green-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-green-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 min-w-[140px] sm:min-w-[180px] justify-center"
                    >
                        {t('dashboard.nextPatient') || 'Patient suivant'}
                    </button>
                )}
                {!isMobile && userRole === 'assistant' && (
                    <Link href="/patients/new?from=dashboard">
                        <button className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-green-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-green-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 min-w-[160px] sm:min-w-[200px] justify-center">
                            <UsersIcon className="w-5 h-5 mr-2" />
                            {t('dashboard.addPatient') || 'Ajouter un patient'}
                        </button>
                    </Link>
                )}
                {!isMobile && (
                    <Link href="/calendar">
                        <button className="inline-flex items-center px-4 py-2 text-sm font-bold text-white transition-all duration-300 transform bg-blue-600 border border-transparent rounded-full shadow-lg sm:px-6 sm:py-3 sm:text-base hover:bg-blue-700 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 min-w-[120px] sm:min-w-[160px] justify-center">
                            {t('dashboard.createAppointment')}
                        </button>
                    </Link>
                )}
            </div>
        </div>
    );
}

export const DashboardHeader = memo(DashboardHeaderBase);
