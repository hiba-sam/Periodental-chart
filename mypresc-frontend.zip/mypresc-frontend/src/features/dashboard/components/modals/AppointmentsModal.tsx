'use client';

import React, { memo } from 'react';
import Modal from '@/components/ui/Modal';
import { useLanguage } from '@/contexts/LanguageContext';
import { Appointment } from '@/contexts/AppointmentContext';

type ModalType = 'all' | 'today' | 'completed' | null;

interface AppointmentsModalProps {
    isOpen: ModalType;
    onClose: () => void;
    appointments: Appointment[];
}

function AppointmentsModalBase({ isOpen, onClose, appointments }: AppointmentsModalProps) {
    const { t } = useLanguage();

    if (isOpen === null) return null;

    const getTitle = () => {
        switch (isOpen) {
            case 'completed':
                return t('dashboard.completedAppointments') || 'RDV effectués';
            case 'today':
                return t('dashboard.todayAppointmentsTitle');
            default:
                return t('dashboard.allAppointments');
        }
    };

    const getFilteredAppointments = () => {
        if (!appointments) return [];
        if (isOpen === 'completed') {
            return appointments.filter(app => app.is_done);
        }
        return appointments;
    };

    const filteredAppointments = getFilteredAppointments();

    return (
        <Modal
            isOpen={isOpen !== null}
            onClose={onClose}
            title={getTitle()}
            zIndex={14000}
        >
            <div className="max-h-[75vh] overflow-auto">
                <table className="w-full text-left border-collapse text-base dark:text-gray-300">
                    <thead>
                        <tr className="text-[15px] text-gray-700 dark:text-gray-400 border-b dark:border-gray-700">
                            <th className="py-3 pr-3">{t('common.patient')}</th>
                            <th className="py-3 pr-3">{t('common.date')}</th>
                            <th className="py-3 pr-3">
                                {isOpen === 'completed' ? 'Heure de passage' : t('common.time')}
                            </th>
                            <th className="py-3">{t('common.notes')}</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                        {filteredAppointments.map((a) => {
                            const d = new Date(a.date as any);
                            const dateStr = d.toLocaleDateString();
                            const servedAt = (a as any).served_at ? new Date((a as any).served_at) : null;
                            const timeStr = isOpen === 'completed' && servedAt
                                ? servedAt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
                                : (a.time || '').slice(0, 5);
                            const name = `${(a as any).patient_name || ''} ${(a as any).patient_family_name || ''}`.trim() || a.patient_id;

                            return (
                                <tr key={a.id} className="border-b dark:border-gray-800">
                                    <td className="py-3 pr-3 font-medium text-gray-900 dark:text-gray-100">
                                        {name}
                                    </td>
                                    <td className="py-3 pr-3 text-gray-700 dark:text-gray-300">{dateStr}</td>
                                    <td className="py-3 pr-3 text-gray-700 dark:text-gray-300">{timeStr}</td>
                                    <td className="py-3 text-gray-600 dark:text-gray-400">{a.notes || '-'}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                {filteredAppointments.length === 0 && (
                    <div className="py-6 text-center text-gray-500 dark:text-gray-400">
                        {t('dashboard.noAppointmentsToShow')}
                    </div>
                )}
            </div>
        </Modal>
    );
}

export const AppointmentsModal = memo(AppointmentsModalBase);
