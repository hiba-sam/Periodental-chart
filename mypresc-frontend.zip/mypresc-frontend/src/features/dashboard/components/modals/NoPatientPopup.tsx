'use client';

import React, { memo } from 'react';
import { UsersIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';

interface NoPatientPopupProps {
    isOpen: boolean;
    onClose: () => void;
}

function NoPatientPopupBase({ isOpen, onClose }: NoPatientPopupProps) {
    const { t } = useLanguage();

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50">
            <div className="p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 text-center">
                <div className="mb-4">
                    <div className="w-16 h-16 mx-auto bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center">
                        <UsersIcon className="w-8 h-8 text-orange-600 dark:text-orange-400" />
                    </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100 mb-4">
                    {t('dashboard.noPatientWaiting') || 'Aucun patient en attente'}
                </h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {t('dashboard.noPatientWaitingDesc') || "Il n'y a plus de patient dans la salle d'attente."}
                </p>
                <button
                    onClick={onClose}
                    className="px-6 py-3 bg-orange-600 text-white font-bold rounded-full hover:bg-orange-700 transition-all"
                >
                    OK
                </button>
            </div>
        </div>
    );
}

export const NoPatientPopup = memo(NoPatientPopupBase);
