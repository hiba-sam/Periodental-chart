// usePatient Hook - Fetches patient data with React Query
// Self-contained hook for patient detail page

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
    fetchPatientById,
    updatePatient as updatePatientApi,
    fetchVisitCount,
    fetchPatientHistory,
    updatePatientNin,
    markChartAsRead as markChartAsReadApi,
} from '../api';
import type { Patient, PatientFormData } from '../types';

// Query keys for cache management
export const patientKeys = {
    all: ['patients'] as const,
    detail: (id: string) => ['patient', id] as const,
    visitCount: (id: string) => ['patient', id, 'visitCount'] as const,
    history: (id: string) => ['patient', id, 'history'] as const,
};

/**
 * Hook to fetch a single patient by ID
 * Uses React Query for caching and automatic refetching
 */
export function usePatient(patientId: string) {
    return useQuery({
        queryKey: patientKeys.detail(patientId),
        queryFn: () => fetchPatientById(patientId),
        staleTime: 5 * 60 * 1000, // 5 minutes
        enabled: !!patientId,
    });
}

/**
 * Hook to fetch patient visit count
 */
export function usePatientVisitCount(patientId: string, enabled: boolean = true) {
    return useQuery({
        queryKey: patientKeys.visitCount(patientId),
        queryFn: () => fetchVisitCount(patientId),
        staleTime: 10 * 60 * 1000, // 10 minutes
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to fetch patient history
 */
export function usePatientHistory(patientId: string, enabled: boolean = false) {
    return useQuery({
        queryKey: patientKeys.history(patientId),
        queryFn: () => fetchPatientHistory(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to update patient data
 */
export function useUpdatePatient(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (data: Partial<PatientFormData>) => updatePatientApi(patientId, data),
        onSuccess: (updatedPatient) => {
            // Update the cache with the new data
            queryClient.setQueryData(patientKeys.detail(patientId), updatedPatient);
            // Invalidate the patients list
            queryClient.invalidateQueries({ queryKey: patientKeys.all });
        },
    });
}

/**
 * Hook to update patient NIN
 */
export function useUpdatePatientNin(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (nin: string) => updatePatientNin(patientId, nin),
        onSuccess: (updatedPatient) => {
            queryClient.setQueryData(patientKeys.detail(patientId), updatedPatient);
        },
    });
}

/**
 * Hook to mark patient chart as read
 */
export function useMarkChartAsRead(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (isPrivate: boolean) => markChartAsReadApi(patientId, isPrivate),
        onSuccess: (_, isPrivate) => {
            // Update the cache with the new privacy status
            queryClient.setQueryData(patientKeys.detail(patientId), (old: Patient | undefined) => {
                if (!old) return old;
                return { ...old, is_chart_readed: true, is_private: isPrivate };
            });
        },
    });
}

/**
 * Combined hook for patient detail page
 * Returns all patient-related data and mutations
 */
export function usePatientDetail(patientId: string, userRole?: string) {
    const queryClient = useQueryClient();

    // Patient data
    const patientQuery = usePatient(patientId);

    // Visit count (only for assistants)
    const visitCountQuery = usePatientVisitCount(patientId, userRole === 'assistant');

    // Mutations
    const updatePatient = useUpdatePatient(patientId);
    const updateNin = useUpdatePatientNin(patientId);
    const markChartAsRead = useMarkChartAsRead(patientId);

    // Refetch function
    const refetch = () => {
        queryClient.invalidateQueries({ queryKey: patientKeys.detail(patientId) });
    };

    // Local state update for optimistic UI
    const setPatientLocal = (updater: (prev: Patient | undefined) => Patient | undefined) => {
        queryClient.setQueryData(patientKeys.detail(patientId), updater);
    };

    return {
        // Data
        patient: patientQuery.data ?? null,
        visitCount: visitCountQuery.data ?? null,

        // Loading states
        isLoading: patientQuery.isLoading,
        isLoadingVisitCount: visitCountQuery.isLoading,

        // Error states
        error: patientQuery.error,
        visitCountError: visitCountQuery.error,

        // Mutations
        updatePatient: updatePatient.mutateAsync,
        updateNin: updateNin.mutateAsync,
        markChartAsRead: markChartAsRead.mutateAsync,

        // Mutation loading states
        isUpdating: updatePatient.isPending,
        isUpdatingNin: updateNin.isPending,
        isMarkingChartAsRead: markChartAsRead.isPending,

        // Utilities
        refetch,
        setPatientLocal,
    };
}
