// usePrimaryCare Hook - Manages primary care doctor info and sharing
// Self-contained hook for primary care functionality

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useCallback } from 'react';
import axios from 'axios';
import type { PrimaryCareInfo, MedicalShare, ShareRequestPayload } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Query keys for cache management
export const primaryCareKeys = {
    info: (patientId: string) => ['primaryCare', 'info', patientId] as const,
    activeShares: (patientId: string) => ['primaryCare', 'activeShares', patientId] as const,
    receivedShares: (patientId: string) => ['primaryCare', 'receivedShares', patientId] as const,
};

// ==================== API FUNCTIONS ====================

async function fetchPrimaryCareInfo(patientId: string): Promise<PrimaryCareInfo | null> {
    try {
        const response = await axios.get(`${API_URL}/patient/${patientId}/primary-care-info`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data;
        }
    } catch {
        // Silently fail - primary care info is optional
    }
    return null;
}

async function fetchActiveSharesForPatient(patientId: string): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/patient/${patientId}`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

async function fetchReceivedSharesForPatient(patientId: string): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/received`, { withCredentials: true });
        if (response.data.success) {
            // Filter only shares for this patient
            const sharesForPatient = (response.data.data || []).filter((s: MedicalShare) =>
                String(s.patient_id) === String(patientId) && s.status === 'active'
            );
            return sharesForPatient;
        }
    } catch {
        // Silently fail
    }
    return [];
}

async function togglePrimaryCareSharingApi(patientId: string, share: boolean): Promise<boolean> {
    const response = await axios.post(
        `${API_URL}/patient/${patientId}/share-primary-care`,
        { share },
        { withCredentials: true }
    );
    return response.data.success;
}

async function createMedicalShareApi(payload: ShareRequestPayload): Promise<boolean> {
    const response = await axios.post(`${API_URL}/medical-shares`, payload, { withCredentials: true });
    return response.data.success;
}

async function revokeMedicalShareApi(shareId: number): Promise<boolean> {
    const response = await axios.put(`${API_URL}/medical-shares/${shareId}/revoke`, {}, { withCredentials: true });
    return response.data.success;
}

// ==================== INDIVIDUAL HOOKS ====================

/**
 * Hook to fetch primary care info
 */
export function usePrimaryCareInfo(patientId: string, enabled: boolean = true) {
    return useQuery({
        queryKey: primaryCareKeys.info(patientId),
        queryFn: () => fetchPrimaryCareInfo(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to fetch active shares for a patient
 */
export function useActiveShares(patientId: string, primaryCareDoctorId?: number) {
    return useQuery({
        queryKey: primaryCareKeys.activeShares(patientId),
        queryFn: () => fetchActiveSharesForPatient(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && !!primaryCareDoctorId,
        select: (shares) => {
            // Find share with primary care doctor if specified
            const shareWithPrimaryCare = primaryCareDoctorId
                ? shares.find(s => s.shared_with_doctor_id === primaryCareDoctorId && s.status === 'active')
                : null;
            return { shares, shareWithPrimaryCare };
        },
    });
}

/**
 * Hook to fetch received shares for a patient
 */
export function useReceivedShares(patientId: string) {
    return useQuery({
        queryKey: primaryCareKeys.receivedShares(patientId),
        queryFn: () => fetchReceivedSharesForPatient(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId,
    });
}

// ==================== COMBINED HOOK ====================

interface UsePrimaryCareReturn {
    // Data
    primaryCareInfo: PrimaryCareInfo | null;
    activeShareWithPrimaryCare: MedicalShare | null;
    receivedShares: MedicalShare[];
    sharedDoctorIds: number[];

    // Loading states
    isLoadingPrimaryCare: boolean;
    isLoadingActiveShares: boolean;
    isLoadingReceivedShares: boolean;

    // Computed values
    isPatientOwner: boolean;
    isPrimaryCareDoctor: boolean;
    isSharingEnabled: boolean;
    canSeeOtherDoctorsPrescriptions: boolean;

    // Mutations
    togglePrimaryCareSharing: () => Promise<void>;
    shareWithPrimaryCareDoctor: () => Promise<void>;
    revokeShareWithPrimaryCareDoctor: () => Promise<void>;

    // Mutation loading states
    isTogglingSharing: boolean;
    isCreatingShare: boolean;
    isRevokingShare: boolean;

    // Refetch
    refetchAll: () => void;
}

/**
 * Combined hook for primary care management
 * Handles primary care info, sharing toggle, and medical shares
 */
export function usePrimaryCare(patientId: string): UsePrimaryCareReturn {
    const queryClient = useQueryClient();

    // Queries
    const primaryCareQuery = usePrimaryCareInfo(patientId);
    const primaryCareDoctorId = primaryCareQuery.data?.primaryCareDoctor?.id;
    const activeSharesQuery = useActiveShares(patientId, primaryCareDoctorId);
    const receivedSharesQuery = useReceivedShares(patientId);

    // Toggle sharing mutation
    const toggleSharingMutation = useMutation({
        mutationFn: async () => {
            if (!primaryCareQuery.data) throw new Error('No primary care info');
            const isCurrentlyShared = primaryCareQuery.data.shared;
            await togglePrimaryCareSharingApi(patientId, !isCurrentlyShared);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: primaryCareKeys.info(patientId) });
        },
    });

    // Share with primary care doctor mutation
    const createShareMutation = useMutation({
        mutationFn: async () => {
            if (!primaryCareDoctorId) throw new Error('No primary care doctor');

            const expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + 30); // 30 days default

            const payload: ShareRequestPayload = {
                patient_id: patientId,
                shared_with_doctor_ids: [primaryCareDoctorId],
                share_prescriptions: true,
                share_medical_reports: true,
                visible_until_date: null,
                expires_at: expiresAt.toISOString(),
                reason: 'Partage avec le médecin traitant',
            };

            await createMedicalShareApi(payload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: primaryCareKeys.activeShares(patientId) });
        },
    });

    // Revoke share mutation
    const revokeShareMutation = useMutation({
        mutationFn: async () => {
            const shareId = activeSharesQuery.data?.shareWithPrimaryCare?.id;
            if (!shareId) throw new Error('No active share to revoke');
            await revokeMedicalShareApi(shareId);
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: primaryCareKeys.activeShares(patientId) });
        },
    });

    // Handlers with confirmation
    const handleTogglePrimaryCareSharing = useCallback(async () => {
        if (!primaryCareQuery.data) return;
        const isCurrentlyShared = primaryCareQuery.data.shared;
        const confirmMsg = `Êtes-vous sûr de vouloir ${isCurrentlyShared ? 'retirer' : 'activer'} le partage ?`;
        if (!confirm(confirmMsg)) return;
        await toggleSharingMutation.mutateAsync();
    }, [primaryCareQuery.data, toggleSharingMutation]);

    const handleShareWithPrimaryCareDoctor = useCallback(async () => {
        if (!primaryCareQuery.data?.primaryCareDoctor) return;
        const doctor = primaryCareQuery.data.primaryCareDoctor;
        const confirmMsg = `Partager le dossier avec Dr. ${doctor.name} ${doctor.family_name} ?`;
        if (!confirm(confirmMsg)) return;
        await createShareMutation.mutateAsync();
        alert('Dossier partagé avec succès');
    }, [primaryCareQuery.data, createShareMutation]);

    const handleRevokeShareWithPrimaryCareDoctor = useCallback(async () => {
        if (!activeSharesQuery.data?.shareWithPrimaryCare) return;
        if (!confirm('Arrêter le partage avec le médecin traitant ?')) return;
        await revokeShareMutation.mutateAsync();
        alert('Partage arrêté');
    }, [activeSharesQuery.data, revokeShareMutation]);

    // Refetch all queries
    const refetchAll = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: primaryCareKeys.info(patientId) });
        queryClient.invalidateQueries({ queryKey: primaryCareKeys.activeShares(patientId) });
        queryClient.invalidateQueries({ queryKey: primaryCareKeys.receivedShares(patientId) });
    }, [queryClient, patientId]);

    // Computed values
    const primaryCareInfo = primaryCareQuery.data ?? null;
    const isPatientOwner = primaryCareInfo?.isPatientOwner ?? false;
    const isPrimaryCareDoctor = primaryCareInfo?.isCurrentDoctor ?? false;
    const isSharingEnabled = primaryCareInfo?.shared ?? false;
    const canSeeOtherDoctorsPrescriptions = isPrimaryCareDoctor || isSharingEnabled;

    const receivedShares = receivedSharesQuery.data ?? [];
    const sharedDoctorIds = receivedShares
        .filter(s => s.status === 'active' && s.share_prescriptions)
        .map(s => Number(s.shared_by_doctor_id));

    return {
        // Data
        primaryCareInfo,
        activeShareWithPrimaryCare: activeSharesQuery.data?.shareWithPrimaryCare ?? null,
        receivedShares,
        sharedDoctorIds,

        // Loading states
        isLoadingPrimaryCare: primaryCareQuery.isLoading,
        isLoadingActiveShares: activeSharesQuery.isLoading,
        isLoadingReceivedShares: receivedSharesQuery.isLoading,

        // Computed values
        isPatientOwner,
        isPrimaryCareDoctor,
        isSharingEnabled,
        canSeeOtherDoctorsPrescriptions,

        // Mutations
        togglePrimaryCareSharing: handleTogglePrimaryCareSharing,
        shareWithPrimaryCareDoctor: handleShareWithPrimaryCareDoctor,
        revokeShareWithPrimaryCareDoctor: handleRevokeShareWithPrimaryCareDoctor,

        // Mutation loading states
        isTogglingSharing: toggleSharingMutation.isPending,
        isCreatingShare: createShareMutation.isPending,
        isRevokingShare: revokeShareMutation.isPending,

        // Refetch
        refetchAll,
    };
}
