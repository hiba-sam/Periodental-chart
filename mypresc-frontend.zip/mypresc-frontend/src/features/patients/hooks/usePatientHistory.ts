// usePatientHistory Hook - Manages patient history modal and data
// Self-contained hook for patient history functionality

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState, useCallback } from 'react';
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Query keys for cache management
export const patientHistoryKeys = {
    history: (patientId: string) => ['patient', patientId, 'history'] as const,
};

/**
 * History metadata returned from API
 */
export interface HistoryMetadata {
    patientCount: number;
    searchMethod: 'nin' | 'demographic';
    hasDuplicates: boolean;
}

/**
 * History entry from API
 */
export interface HistoryEntry {
    id: string | number;
    type: 'prescription' | 'appointment' | 'medical_report' | 'invoice' | 'visit';
    date: string;
    description: string;
    doctorName?: string;
    doctorId?: number;
    metadata?: Record<string, any>;
}

/**
 * Response from history API
 */
interface HistoryResponse {
    data: HistoryEntry[];
    metadata: HistoryMetadata | null;
}

// ==================== API FUNCTION ====================

async function fetchPatientHistoryApi(patientId: string): Promise<HistoryResponse> {
    const response = await axios.get(`${API_URL}/patient/${patientId}/history`, { withCredentials: true });
    if (response.data.success) {
        return {
            data: response.data.data || [],
            metadata: response.data.metadata || null,
        };
    }
    throw new Error(response.data.error || 'Failed to fetch patient history');
}

// ==================== MAIN HOOK ====================

interface UsePatientHistoryReturn {
    // Data
    history: HistoryEntry[];
    metadata: HistoryMetadata | null;

    // Loading & Error
    isLoading: boolean;
    error: Error | null;

    // Modal state
    showHistoryModal: boolean;

    // Actions
    openHistoryModal: () => void;
    closeHistoryModal: () => void;
    fetchHistory: () => Promise<void>;
    refetch: () => void;
}

/**
 * Hook for patient history management
 * Handles fetching history data and modal visibility
 */
export function usePatientHistory(patientId: string): UsePatientHistoryReturn {
    const queryClient = useQueryClient();

    // Modal state
    const [showHistoryModal, setShowHistoryModal] = useState(false);

    // Query - enabled only when modal is requested
    const historyQuery = useQuery({
        queryKey: patientHistoryKeys.history(patientId),
        queryFn: () => fetchPatientHistoryApi(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && showHistoryModal, // Only fetch when modal is open
    });

    /**
     * Open history modal (triggers fetch)
     */
    const openHistoryModal = useCallback(() => {
        setShowHistoryModal(true);
    }, []);

    /**
     * Close history modal
     */
    const closeHistoryModal = useCallback(() => {
        setShowHistoryModal(false);
    }, []);

    /**
     * Manually fetch history (and open modal)
     */
    const fetchHistory = useCallback(async () => {
        setShowHistoryModal(true);
        await queryClient.fetchQuery({
            queryKey: patientHistoryKeys.history(patientId),
            queryFn: () => fetchPatientHistoryApi(patientId),
        });
    }, [queryClient, patientId]);

    /**
     * Refetch history data
     */
    const refetch = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: patientHistoryKeys.history(patientId) });
    }, [queryClient, patientId]);

    return {
        // Data
        history: historyQuery.data?.data ?? [],
        metadata: historyQuery.data?.metadata ?? null,

        // Loading & Error
        isLoading: historyQuery.isLoading,
        error: historyQuery.error,

        // Modal state
        showHistoryModal,

        // Actions
        openHistoryModal,
        closeHistoryModal,
        fetchHistory,
        refetch,
    };
}
