// usePatientPrivacy Hook - Manages privacy choice state and API calls
// Self-contained hook for patient privacy management

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useState, useEffect, useCallback } from 'react';
import {
    fetchPrivacyChoice,
    savePrivacyChoice,
    fetchPrimaryCareInfo,
    togglePrimaryCareSharing,
    fetchPatientShares,
} from '../api';
import type { PrivacyChoice, PrimaryCareInfo, MedicalShare } from '../types';

// Query keys for cache management
export const privacyKeys = {
    choice: (patientId: string) => ['privacy', 'choice', patientId] as const,
    primaryCare: (patientId: string) => ['privacy', 'primaryCare', patientId] as const,
    shares: (patientId: string) => ['privacy', 'shares', patientId] as const,
};

/**
 * Hook to fetch privacy choice for a patient
 */
export function usePrivacyChoice(patientId: string, enabled: boolean = true) {
    return useQuery({
        queryKey: privacyKeys.choice(patientId),
        queryFn: () => fetchPrivacyChoice(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to fetch primary care info for a patient
 */
export function usePrimaryCareInfo(patientId: string, enabled: boolean = true) {
    return useQuery({
        queryKey: privacyKeys.primaryCare(patientId),
        queryFn: () => fetchPrimaryCareInfo(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to fetch active shares for a patient
 */
export function usePatientShares(patientId: string, enabled: boolean = true) {
    return useQuery({
        queryKey: privacyKeys.shares(patientId),
        queryFn: () => fetchPatientShares(patientId),
        staleTime: 5 * 60 * 1000,
        enabled: !!patientId && enabled,
    });
}

/**
 * Hook to save privacy choice
 */
export function useSavePrivacyChoice(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (choice: PrivacyChoice) => savePrivacyChoice(patientId, choice),
        onSuccess: (_, choice) => {
            // Update the cache with the new choice
            queryClient.setQueryData(privacyKeys.choice(patientId), choice);
        },
    });
}

/**
 * Hook to toggle primary care sharing
 */
export function useTogglePrimaryCareSharing(patientId: string) {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (share: boolean) => togglePrimaryCareSharing(patientId, share),
        onSuccess: () => {
            // Invalidate primary care info to refetch
            queryClient.invalidateQueries({ queryKey: privacyKeys.primaryCare(patientId) });
            // Invalidate shares to refetch
            queryClient.invalidateQueries({ queryKey: privacyKeys.shares(patientId) });
        },
    });
}

interface UsePatientPrivacyReturn {
    // Data
    myPrivacyChoice: PrivacyChoice | null;
    primaryCareInfo: PrimaryCareInfo | null;
    activeShares: MedicalShare[];

    // Loading states
    isLoadingPrivacyChoice: boolean;
    isLoadingPrimaryCare: boolean;
    isLoadingShares: boolean;
    privacyChoiceLoaded: boolean;

    // Error states
    privacyChoiceError: Error | null;
    primaryCareError: Error | null;
    sharesError: Error | null;

    // Mutations
    savePrivacyChoice: (choice: PrivacyChoice) => Promise<boolean>;
    toggleSharing: (share: boolean) => Promise<boolean>;

    // Mutation loading states
    isSavingPrivacyChoice: boolean;
    isTogglingSharing: boolean;

    // Computed values
    isPatientOwner: boolean;
    isPrimaryCareDoctor: boolean;
    isSharedWithMe: boolean;
    sharingEnabled: boolean;
}

/**
 * Combined hook for patient privacy management
 * Handles privacy choice, primary care info, and medical shares
 */
export function usePatientPrivacy(
    patientId: string,
    isSharedWithMe: boolean = false
): UsePatientPrivacyReturn {
    // Queries
    const privacyChoiceQuery = usePrivacyChoice(patientId);
    const primaryCareQuery = usePrimaryCareInfo(patientId);
    const sharesQuery = usePatientShares(patientId);

    // Mutations
    const savePrivacyMutation = useSavePrivacyChoice(patientId);
    const toggleSharingMutation = useTogglePrimaryCareSharing(patientId);

    // Track if privacy choice has been loaded (including null result)
    const [privacyChoiceLoaded, setPrivacyChoiceLoaded] = useState(false);

    // Update privacyChoiceLoaded when query completes
    useEffect(() => {
        if (privacyChoiceQuery.isFetched && !privacyChoiceQuery.isLoading) {
            setPrivacyChoiceLoaded(true);
        }
    }, [privacyChoiceQuery.isFetched, privacyChoiceQuery.isLoading]);

    // Save privacy choice wrapper
    const handleSavePrivacyChoice = useCallback(async (choice: PrivacyChoice): Promise<boolean> => {
        try {
            await savePrivacyMutation.mutateAsync(choice);
            return true;
        } catch {
            return false;
        }
    }, [savePrivacyMutation]);

    // Toggle sharing wrapper
    const handleToggleSharing = useCallback(async (share: boolean): Promise<boolean> => {
        try {
            await toggleSharingMutation.mutateAsync(share);
            return true;
        } catch {
            return false;
        }
    }, [toggleSharingMutation]);

    // Computed values
    const primaryCareInfo = primaryCareQuery.data ?? null;
    const isPatientOwner = primaryCareInfo?.isPatientOwner ?? false;
    const isPrimaryCareDoctor = primaryCareInfo?.isCurrentDoctor ?? false;
    const sharingEnabled = primaryCareInfo?.shared ?? false;

    return {
        // Data
        myPrivacyChoice: privacyChoiceQuery.data ?? null,
        primaryCareInfo,
        activeShares: sharesQuery.data ?? [],

        // Loading states
        isLoadingPrivacyChoice: privacyChoiceQuery.isLoading,
        isLoadingPrimaryCare: primaryCareQuery.isLoading,
        isLoadingShares: sharesQuery.isLoading,
        privacyChoiceLoaded,

        // Error states
        privacyChoiceError: privacyChoiceQuery.error,
        primaryCareError: primaryCareQuery.error,
        sharesError: sharesQuery.error,

        // Mutations
        savePrivacyChoice: handleSavePrivacyChoice,
        toggleSharing: handleToggleSharing,

        // Mutation loading states
        isSavingPrivacyChoice: savePrivacyMutation.isPending,
        isTogglingSharing: toggleSharingMutation.isPending,

        // Computed values
        isPatientOwner,
        isPrimaryCareDoctor,
        isSharedWithMe,
        sharingEnabled,
    };
}
