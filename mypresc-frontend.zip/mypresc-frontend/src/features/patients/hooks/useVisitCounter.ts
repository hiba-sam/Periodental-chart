// useVisitCounter Hook - Manages visit counting and NIN popup logic
// Self-contained hook for visit tracking and NIN reminders

import { useQuery } from '@tanstack/react-query';
import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import type { Patient } from '../types';
import { safeStorage } from '@/utils/safeStorage';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Query keys
export const visitCounterKeys = {
    count: (patientId: string) => ['patient', patientId, 'visitCount'] as const,
};

/**
 * Storage data for NIN popup tracking
 */
interface NinPopupStorage {
    visits: number;
    lastPopupDate: string;
    lastVisitDate: string;
}

// ==================== API FUNCTION ====================

async function fetchVisitCountApi(patientId: string): Promise<number> {
    try {
        const response = await axios.get(`${API_URL}/patient/${patientId}/visit-count`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data.visitCount;
        }
    } catch {
        // Silently fail
    }
    return 0;
}

// ==================== STORAGE HELPERS ====================

function getStorageKey(patientId: string): string {
    return `nin_popup_${patientId}`;
}

function getStoredVisitData(patientId: string): NinPopupStorage {
    const storageKey = getStorageKey(patientId);
    const storedData = safeStorage.getItem(storageKey);

    if (storedData) {
        try {
            return JSON.parse(storedData);
        } catch {
            // Ignore parse errors
        }
    }

    return { visits: 0, lastPopupDate: '', lastVisitDate: '' };
}

function setStoredVisitData(patientId: string, data: NinPopupStorage): void {
    const storageKey = getStorageKey(patientId);
    safeStorage.setItem(storageKey, JSON.stringify(data));
}

// ==================== MAIN HOOK ====================

interface UseVisitCounterProps {
    patientId: string;
    patient: Patient | null;
    userRole?: string;
}

interface UseVisitCounterReturn {
    // Data
    visitCount: number | null;

    // Loading
    isLoading: boolean;

    // NIN popup state
    showNinPopup: boolean;
    ninInput: string;
    savingNin: boolean;

    // NIN popup actions
    setNinInput: (value: string) => void;
    closeNinPopup: () => void;
    markNinPopupShown: () => void;
}

/**
 * Hook for visit counting and NIN popup logic
 * 
 * NIN popup logic:
 * - Only shows for doctors when patient has no NIN
 * - Tracks visits per day using localStorage
 * - Shows popup after 2nd visit on the same day
 * - Only shows once per day
 */
export function useVisitCounter({
    patientId,
    patient,
    userRole,
}: UseVisitCounterProps): UseVisitCounterReturn {
    // NIN popup state
    const [showNinPopup, setShowNinPopup] = useState(false);
    const [ninInput, setNinInput] = useState('');
    const [savingNin, setSavingNin] = useState(false);

    // Visit count query (only for assistants)
    const visitCountQuery = useQuery({
        queryKey: visitCounterKeys.count(patientId),
        queryFn: () => fetchVisitCountApi(patientId),
        staleTime: 10 * 60 * 1000, // 10 minutes
        enabled: !!patientId && userRole === 'assistant',
    });

    /**
     * Effect to check if NIN popup should be shown
     * Only for doctors viewing patients without NIN
     */
    useEffect(() => {
        if (!patient || userRole !== 'doctor') return;
        if (patient.nin) return; // Already has NIN

        const today = new Date().toISOString().split('T')[0];
        let visitData = getStoredVisitData(patientId);

        // Reset visits if it's a new day
        if (visitData.lastVisitDate !== today) {
            visitData.visits = 0;
            visitData.lastVisitDate = today;
        }

        // Increment visit count
        visitData.visits += 1;

        // Show popup after 2nd visit, but only once per day
        if (visitData.visits >= 2 && visitData.lastPopupDate !== today) {
            setShowNinPopup(true);
            visitData.lastPopupDate = today;
        }

        // Save updated data
        setStoredVisitData(patientId, visitData);
    }, [patient, patientId, userRole]);

    /**
     * Close NIN popup
     */
    const closeNinPopup = useCallback(() => {
        setShowNinPopup(false);
        setNinInput('');
    }, []);

    /**
     * Mark NIN popup as shown (prevent re-showing)
     */
    const markNinPopupShown = useCallback(() => {
        const today = new Date().toISOString().split('T')[0];
        const visitData = getStoredVisitData(patientId);
        visitData.lastPopupDate = today;
        setStoredVisitData(patientId, visitData);
    }, [patientId]);

    return {
        // Data
        visitCount: visitCountQuery.data ?? null,

        // Loading
        isLoading: visitCountQuery.isLoading,

        // NIN popup state
        showNinPopup,
        ninInput,
        savingNin,

        // NIN popup actions
        setNinInput,
        closeNinPopup,
        markNinPopupShown,
    };
}
