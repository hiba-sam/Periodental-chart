// Patient API - All patient-related API calls
// Self-contained API layer for the patients feature

import axios from 'axios';
import type { Patient, PatientFormData, PatientFilters, PatientStatistics } from '../types';
import type { PrivacyChoice, PrimaryCareInfo, MedicalShare, ShareRequestPayload } from '../types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

// Create axios instance for patient API
const patientApi = axios.create({
    baseURL: `${API_URL}/patient`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

// ==================== PATIENT CRUD ====================

/**
 * Fetch all patients
 */
export async function fetchPatients(): Promise<Patient[]> {
    const response = await patientApi.get('/');
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to fetch patients');
}

/**
 * Fetch a single patient by ID
 */
export async function fetchPatientById(id: string): Promise<Patient> {
    const response = await patientApi.get(`/${id}`);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Patient not found');
}

/**
 * Search patients with filters
 */
export async function searchPatients(filters: PatientFilters): Promise<Patient[]> {
    const params = new URLSearchParams();
    if (filters.searchTerm) params.append('search', filters.searchTerm);
    if (filters.limit) params.append('limit', filters.limit.toString());
    if (filters.includeAll !== undefined) params.append('includeAll', filters.includeAll.toString());

    const response = await patientApi.get(`/search?${params.toString()}`);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Search failed');
}

/**
 * Create a new patient
 */
export async function createPatient(data: PatientFormData): Promise<Patient> {
    const response = await patientApi.post('/', data);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to create patient');
}

/**
 * Update an existing patient
 */
export async function updatePatient(id: string, data: Partial<PatientFormData>): Promise<Patient> {
    const response = await patientApi.put(`/${id}`, data);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to update patient');
}

/**
 * Delete a patient
 */
export async function deletePatient(id: string): Promise<boolean> {
    const response = await patientApi.delete(`/${id}`);
    return response.data.success;
}

// ==================== PATIENT DETAIL ====================

/**
 * Fetch patient history
 */
export async function fetchPatientHistory(patientId: string): Promise<{ data: any[]; metadata: any }> {
    const response = await axios.get(`${API_URL}/patient/${patientId}/history`, { withCredentials: true });
    if (response.data.success) {
        return {
            data: response.data.data,
            metadata: response.data.metadata || null,
        };
    }
    throw new Error(response.data.error || 'Failed to fetch patient history');
}

/**
 * Fetch visit count for a patient
 */
export async function fetchVisitCount(patientId: string): Promise<number> {
    const response = await axios.get(`${API_URL}/patient/${patientId}/visit-count`, { withCredentials: true });
    if (response.data.success) {
        return response.data.data.visitCount;
    }
    return 0;
}

/**
 * Mark patient chart as read
 */
export async function markChartAsRead(patientId: string, isPrivate: boolean): Promise<boolean> {
    const response = await patientApi.put(`/${patientId}/mark-chart-read`, { is_private: isPrivate });
    return response.data.success;
}

/**
 * Update patient NIN
 */
export async function updatePatientNin(patientId: string, nin: string): Promise<Patient> {
    const response = await patientApi.put(`/${patientId}`, { nin: nin.trim() });
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to update NIN');
}

// ==================== PRIMARY CARE ====================

/**
 * Fetch primary care info for a patient
 */
export async function fetchPrimaryCareInfo(patientId: string): Promise<PrimaryCareInfo | null> {
    try {
        const response = await axios.get(`${API_URL}/patient/${patientId}/primary-care-info`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data;
        }
    } catch {
        // Silently fail - primary care info is optional
    }
    return null;
}

/**
 * Toggle primary care sharing
 */
export async function togglePrimaryCareSharing(patientId: string, share: boolean): Promise<boolean> {
    const response = await axios.post(
        `${API_URL}/patient/${patientId}/share-primary-care`,
        { share },
        { withCredentials: true }
    );
    return response.data.success;
}

// ==================== PRIVACY ====================

/**
 * Fetch privacy choice for a patient
 */
export async function fetchPrivacyChoice(patientId: string): Promise<PrivacyChoice | null> {
    try {
        const response = await axios.get(
            `${API_URL}/doctor-patient-privacy/patient/${patientId}`,
            { withCredentials: true }
        );
        if (response.data.success && response.data.data.privacy_choice) {
            return response.data.data.privacy_choice;
        }
    } catch {
        // Silently fail
    }
    return null;
}

/**
 * Save privacy choice for a patient
 */
export async function savePrivacyChoice(patientId: string, choice: PrivacyChoice): Promise<boolean> {
    try {
        const response = await axios.post(
            `${API_URL}/doctor-patient-privacy/patient/${patientId}`,
            { privacy_choice: choice },
            { withCredentials: true }
        );
        return response.data.success;
    } catch {
        return false;
    }
}

// ==================== MEDICAL SHARES ====================

/**
 * Fetch active shares for a patient
 */
export async function fetchPatientShares(patientId: string): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(
            `${API_URL}/medical-shares/patient/${patientId}`,
            { withCredentials: true }
        );
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

/**
 * Fetch shares received by current doctor
 */
export async function fetchReceivedShares(): Promise<MedicalShare[]> {
    try {
        const response = await axios.get(`${API_URL}/medical-shares/received`, { withCredentials: true });
        if (response.data.success) {
            return response.data.data || [];
        }
    } catch {
        // Silently fail
    }
    return [];
}

/**
 * Create a new medical share
 */
export async function createMedicalShare(payload: ShareRequestPayload): Promise<boolean> {
    const response = await axios.post(`${API_URL}/medical-shares`, payload, { withCredentials: true });
    return response.data.success;
}

/**
 * Revoke a medical share
 */
export async function revokeMedicalShare(shareId: number): Promise<boolean> {
    const response = await axios.put(
        `${API_URL}/medical-shares/${shareId}/revoke`,
        {},
        { withCredentials: true }
    );
    return response.data.success;
}

// ==================== STATISTICS ====================

/**
 * Fetch patient statistics
 */
export async function fetchPatientStatistics(): Promise<PatientStatistics | null> {
    try {
        const response = await patientApi.get('/statistics');
        if (response.data.success) {
            return response.data.data;
        }
    } catch {
        // Silently fail
    }
    return null;
}
