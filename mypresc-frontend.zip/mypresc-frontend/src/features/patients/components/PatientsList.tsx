"use client";

import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  MagnifyingGlassIcon,
  AdjustmentsHorizontalIcon,
  PencilSquareIcon,
  TrashIcon,
  ShareIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import Link from "next/link";
import MobileFullModal from "@/components/ui/MobileFullModal";

import { ApiPatient, usePatients } from "@/contexts/PatientsContext";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";

type PatientsListProps = {
  className?: string;
};

export function PatientsList({ className = "" }: PatientsListProps) {
  const {
    patients: apiPatients,
    loading,
    error,
    searchPatients,
    hasMore,
    loadMorePatients,
    loadingMore,
  } = usePatients();

  const { user } = useAuth();
  const { t, formatDate } = useLanguage();

  const [serverResults, setServerResults] = useState<ApiPatient[] | null>(null);

  const patients: ApiPatient[] = useMemo(() => {
    return apiPatients.map((p) => ({
      ...p,
      gender: p.genre,
      problem: "N/A",
      date: p.created_at,
      name: `${p.name} ${p.family_name}`,
      phone: p.telephone,
    })) as ApiPatient[];
  }, [apiPatients]);

  const [searchQuery, setSearchQuery] = useState("");

  // --- Mobile Search State ---
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [mobileSearchQuery, setMobileSearchQuery] = useState("");
  const [mobileServerResults, setMobileServerResults] = useState<ApiPatient[] | null>(null);
  const [isMobileSearching, setIsMobileSearching] = useState(false);

  const mobileFilteredLocalPatients = useMemo(() => {
    if (!mobileSearchQuery.trim()) return [];
    const term = mobileSearchQuery.toLowerCase();
    return patients.filter((p) =>
      p.name.toLowerCase().includes(term) ||
      (p.nin && p.nin.includes(term)) ||
      (p.telephone && p.telephone.includes(term))
    );
  }, [patients, mobileSearchQuery]);

  // Debounced live search for Mobile
  useEffect(() => {
    const run = async () => {
      if (!mobileSearchQuery.trim()) {
        setMobileServerResults(null);
        setIsMobileSearching(false);
        return;
      }
      if (mobileFilteredLocalPatients.length > 0) {
        setMobileServerResults(null);
        setIsMobileSearching(false);
        return;
      }
      setIsMobileSearching(true);
      const results = await searchPatients(mobileSearchQuery.trim(), 15);
      setMobileServerResults(results);
      setIsMobileSearching(false);
    };
    const id = setTimeout(run, 300);
    return () => clearTimeout(id);
  }, [mobileSearchQuery, mobileFilteredLocalPatients.length, searchPatients]);

  // --- Sort & Filter State ---
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const filterMenuRef = useRef<HTMLDivElement>(null);
  const sortMenuRef = useRef<HTMLDivElement>(null);
  const [filters, setFilters] = useState({
    gender: "",
    problems: [] as string[],
    ageRange: { min: 0, max: 100 },
  });
  const [tempFilters, setTempFilters] = useState(filters);
  const [ageMinInput, setAgeMinInput] = useState("0");
  const [ageMaxInput, setAgeMaxInput] = useState("100");
  const listContainerRef = useRef<HTMLDivElement>(null);
  // ⚡ Fix: separate sentinels so each observer has its own target
  const desktopSentinelRef = useRef<HTMLDivElement>(null);
  const mobileSentinelRef = useRef<HTMLDivElement>(null);
  const loadingRef = useRef(false);

  const isMobile = useMemo(() => {
    return typeof window !== "undefined" && window.innerWidth < 768;
  }, []);

  useEffect(() => {
    loadingRef.current = loadingMore;
  }, [loadingMore]);

  // Debounced live search for Desktop
  useEffect(() => {
    const run = async () => {
      if (!searchQuery.trim()) {
        setServerResults(null);
        return;
      }
      const results = await searchPatients(searchQuery.trim(), 10);
      setServerResults(results);
    };
    const id = setTimeout(run, 300);
    return () => clearTimeout(id);
  }, [searchQuery, searchPatients]);

  const sortPatients = (a: ApiPatient, b: ApiPatient) => {
    if (sortBy === "name") {
      return sortOrder === "asc"
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    } else if (sortBy === "age") {
      return sortOrder === "asc" ? a.age - b.age : b.age - a.age;
    } else if (sortBy === "date") {
      return sortOrder === "asc"
        ? new Date(a.created_at!).getTime() - new Date(b.created_at!).getTime()
        : new Date(b.created_at!).getTime() - new Date(a.created_at!).getTime();
    } else if (sortBy === "problem") {
      const aProblem = a.chronicDiseases || "";
      const bProblem = b.chronicDiseases || "";
      return sortOrder === "asc"
        ? aProblem.localeCompare(bProblem)
        : bProblem.localeCompare(aProblem);
    } else if (sortBy === "id") {
      return sortOrder === "asc"
        ? a.id.localeCompare(b.id)
        : b.id.localeCompare(a.id);
    }
    return 0;
  };

  const uniqueProblems = Array.from(
    new Set(patients.map((patient) => patient.chronicDiseases))
  );

  const tablePatients = useMemo(() => {
    return patients
      .filter((patient) => {
        const matchesGender =
          filters.gender === "" || patient.genre === filters.gender;
        const matchesProblem =
          filters.problems.length === 0 ||
          filters.problems.includes(patient.chronicDiseases!);
        const matchesAge =
          patient.age >= filters.ageRange.min &&
          patient.age <= filters.ageRange.max;

        return matchesGender && matchesProblem && matchesAge;
      })
      .sort(sortPatients);
  }, [patients, filters, sortBy, sortOrder]);

  const handleClearSearch = () => {
    setSearchQuery("");
    setServerResults(null);
  };

  // ⚡ Desktop: observe sentinel relative to the TABLE container (not the window)
  // The table has overflow-auto + maxHeight, so window.scrollY never changes.
  useEffect(() => {
    const sentinel = desktopSentinelRef.current;
    const container = listContainerRef.current;
    if (!sentinel || !container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry?.isIntersecting && !loadingRef.current && hasMore) {
          loadingRef.current = true;
          loadMorePatients();
        }
      },
      {
        root: container,
        rootMargin: "200px",
        threshold: 0,
      }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMore, loadMorePatients]);

  // ⚡ Mobile: observe sentinel relative to the VIEWPORT
  useEffect(() => {
    const sentinel = mobileSentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry?.isIntersecting && !loadingRef.current && hasMore) {
          loadingRef.current = true;
          loadMorePatients();
        }
      },
      {
        root: null,
        rootMargin: "200px",
        threshold: 0,
      }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasMore, loadMorePatients]);

  if (loading) {
    return (
      <div
        className={`flex flex-col items-center justify-center flex-1 py-12 ${className}`}
      >
        <div className="w-8 h-8 border-b-2 border-blue-600 rounded-full animate-spin"></div>
        <p className="mt-4 text-gray-600 dark:text-gray-400">{t('patients.list.loadingPatients')}</p>
      </div>
    );
  }

  if (error) {
    return (
      <div
        className={`flex flex-col items-center justify-center flex-1 py-12 ${className}`}
      >
        <p className="font-medium text-red-500">{t('patients.list.error')} {error}</p>
        <p className="mt-2 text-gray-500 dark:text-gray-400">
          {t('patients.list.unableToLoad')}
        </p>
      </div>
    );
  }

  return (
    <>
      <div className={`flex flex-col flex-1 ${className}`}>
        {/* ── Toolbar ── */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-6">
          <div className="hidden md:block relative max-w-full" style={{ width: '32rem' }}>
            <input
              type="text"
              placeholder={t('patients.list.searchPlaceholder')}
              className="w-full h-12 text-base py-3 pl-12 pr-12 border border-gray-300 dark:border-gray-600 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <MagnifyingGlassIcon className="absolute w-6 h-6 text-gray-400 dark:text-gray-500 left-4 top-1/2 -translate-y-1/2" />
            {searchQuery && (
              <button
                className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                onClick={handleClearSearch}
              >
                {t('patients.list.clear')}
              </button>
            )}

            {searchQuery && (
              <div className="absolute z-20 mt-2 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg max-h-80 overflow-auto">
                {serverResults === null ? (
                  <div className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400">
                    {t('patients.list.typeToSearch')}
                  </div>
                ) : serverResults.length === 0 ? (
                  <div className="px-4 py-3 text-sm text-gray-500">
                    {t('patients.list.noResults')}
                  </div>
                ) : (
                  serverResults.map((p) => (
                    <Link
                      key={p.id}
                      href={`/patients/${p.id}`}
                      className="block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-medium text-gray-900 dark:text-gray-100">
                          {p.name} {p.family_name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {p.telephone}
                        </div>
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {p.genre?.toUpperCase()} · {p.age} ans · {' '} NIN :
                        {p.nin || t('patients.list.notProvided')}
                      </div>
                    </Link>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Mobile Search Trigger */}
          <div className="md:hidden block relative w-full" onClick={() => setIsMobileSearchOpen(true)}>
            <div className="w-full h-12 flex items-center px-4 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-text shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
              <MagnifyingGlassIcon className="w-5 h-5 mr-3 shrink-0" />
              <span className="pl-2 truncate">{t('patients.list.searchPlaceholder')}</span>
            </div>
          </div>

          <div className={`flex gap-2 md:gap-4 ${isMobile ? 'w-full' : ''}`}>
            <div className="relative flex-1">
              <button
                className="flex w-full items-center px-4 py-2 gap-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200"
                onClick={() => setShowSortMenu(!showSortMenu)}
              >
                <span>
                  {t('patients.list.sortBy')}: {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}{" "}
                  ({sortOrder === "asc" ? t('patients.list.aToZ') : t('patients.list.zToA')})
                </span>
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M19 9l-7 7-7-7"
                  ></path>
                </svg>
              </button>

              {showSortMenu && (
                <div
                  ref={sortMenuRef}
                  className="absolute right-0 z-10 w-48 mt-2 bg-white dark:bg-gray-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5"
                >
                  <div className="py-1">
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortBy("name");
                        setSortOrder(
                          sortBy === "name" && sortOrder === "asc"
                            ? "desc"
                            : "asc"
                        );
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.name')}{" "}
                      {sortBy === "name" && (sortOrder === "asc" ? "↑" : "↓")}
                    </button>
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortBy("age");
                        setSortOrder(
                          sortBy === "age" && sortOrder === "asc"
                            ? "desc"
                            : "asc"
                        );
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.age')}{" "}
                      {sortBy === "age" && (sortOrder === "asc" ? "↑" : "↓")}
                    </button>
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortBy("date");
                        setSortOrder(
                          sortBy === "date" && sortOrder === "asc"
                            ? "desc"
                            : "asc"
                        );
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.date')}{" "}
                      {sortBy === "date" && (sortOrder === "asc" ? "↑" : "↓")}
                    </button>
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortBy("problem");
                        setSortOrder(
                          sortBy === "problem" && sortOrder === "asc"
                            ? "desc"
                            : "asc"
                        );
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.problem')}{" "}
                      {sortBy === "problem" &&
                        (sortOrder === "asc" ? "↑" : "↓")}
                    </button>
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortBy("id");
                        setSortOrder(
                          sortBy === "id" && sortOrder === "asc"
                            ? "desc"
                            : "asc"
                        );
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.id')} {sortBy === "id" && (sortOrder === "asc" ? "↑" : "↓")}
                    </button>
                    <div className="my-1 border-t border-gray-100 dark:border-gray-700"></div>
                    <button
                      className="block w-full px-4 py-2 text-sm text-left text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                      onClick={() => {
                        setSortOrder(sortOrder === "asc" ? "desc" : "asc");
                        setShowSortMenu(false);
                      }}
                    >
                      {t('patients.list.reverseOrder')} ({sortOrder === "asc" ? t('patients.list.aToZ') : t('patients.list.zToA')})
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                className="flex items-center px-4 py-2 gap-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200"
                onClick={() => {
                  setTempFilters(filters);
                  setAgeMinInput(filters.ageRange.min.toString());
                  setAgeMaxInput(filters.ageRange.max.toString());
                  setShowFilterMenu(!showFilterMenu);
                }}
              >
                <AdjustmentsHorizontalIcon className="w-5 h-5" />
                <span>
                  {t('patients.list.filters')}{" "}
                  {(filters.gender ||
                    filters.problems.length > 0 ||
                    filters.ageRange.min > 0 ||
                    filters.ageRange.max < 100) &&
                    t('patients.list.active')}
                </span>
              </button>

              {showFilterMenu && (
                <div
                  ref={filterMenuRef}
                  className="absolute right-0 z-10 w-64 p-4 mt-2 bg-white dark:bg-gray-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5"
                >
                  <h3 className="mb-3 text-lg font-medium text-gray-900 dark:text-gray-100">
                    {t('patients.list.filters')}
                  </h3>

                  <div className="mb-4">
                    <label className="block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
                      {t('patients.list.gender')}
                    </label>
                    <select
                      className="block w-full py-2 pl-3 pr-10 mt-1 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      value={tempFilters.gender}
                      onChange={(e) =>
                        setTempFilters({
                          ...tempFilters,
                          gender: e.target.value as "homme" | "femme" | "",
                        })
                      }
                    >
                      <option value="">{t('patients.list.all')}</option>
                      <option value="homme">{t('patients.list.male')}</option>
                      <option value="femme">{t('patients.list.female')}</option>
                    </select>
                  </div>

                  <div className="mb-4">
                    <label className="block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
                      {t('patients.list.problem')}
                    </label>
                    <select
                      className="block w-full py-2 pl-3 pr-10 mt-1 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      multiple
                      value={
                        tempFilters.problems.length === 0
                          ? [""]
                          : tempFilters.problems
                      }
                      onChange={(e) => {
                        const selectedOptions = Array.from(
                          e.target.selectedOptions
                        ).map((option) => option.value);
                        if (selectedOptions.includes("")) {
                          setTempFilters({ ...tempFilters, problems: [] });
                        } else {
                          setTempFilters({
                            ...tempFilters,
                            problems: selectedOptions,
                          });
                        }
                      }}
                    >
                      <option value="">{t('patients.list.all')}</option>
                      {uniqueProblems.map((problem) => (
                        <option key={problem} value={problem}>
                          {problem}
                        </option>
                      ))}
                    </select>
                    <p className="mt-1 text-xs text-gray-500">
                      {t('patients.list.holdCtrl')}
                    </p>
                  </div>

                  <div className="mb-4">
                    <label className="block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300">
                      {t('patients.list.age')}: {ageMinInput === "" ? "0" : ageMinInput} -{" "}
                      {ageMaxInput === "" ? "100" : ageMaxInput}
                    </label>
                    <div className="flex gap-4">
                      <input
                        type="number"
                        min="0"
                        max="100"
                        className="block w-full py-2 pl-3 pr-3 mt-1 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        value={ageMinInput}
                        onChange={(e) => {
                          setAgeMinInput(e.target.value);
                          if (e.target.value !== "") {
                            setTempFilters({
                              ...tempFilters,
                              ageRange: {
                                ...tempFilters.ageRange,
                                min: parseInt(e.target.value) || 0,
                              },
                            });
                          }
                        }}
                      />
                      <input
                        type="number"
                        min="0"
                        max="100"
                        className="block w-full py-2 pl-3 pr-3 mt-1 text-base border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        value={ageMaxInput}
                        onChange={(e) => {
                          setAgeMaxInput(e.target.value);
                          if (e.target.value !== "") {
                            setTempFilters({
                              ...tempFilters,
                              ageRange: {
                                ...tempFilters.ageRange,
                                max: parseInt(e.target.value) || 100,
                              },
                            });
                          }
                        }}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      onClick={() => {
                        const resetFilters = {
                          gender: "",
                          problems: [] as string[],
                          ageRange: { min: 0, max: 100 },
                        };
                        setTempFilters(resetFilters);
                        setFilters(resetFilters);
                        setAgeMinInput("0");
                        setAgeMaxInput("100");
                      }}
                    >
                      {t('patients.list.reset')}
                    </button>
                    <button
                      className="inline-flex justify-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      onClick={() => {
                        const finalMin =
                          ageMinInput === "" ? 0 : parseInt(ageMinInput) || 0;
                        const finalMax =
                          ageMaxInput === ""
                            ? 100
                            : parseInt(ageMaxInput) || 100;
                        const newFilters = {
                          ...tempFilters,
                          ageRange: { min: finalMin, max: finalMax },
                        };
                        setTempFilters(newFilters);
                        setFilters(newFilters);
                        setShowFilterMenu(false);
                      }}
                    >
                      {t('patients.list.apply')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ── Desktop table (hidden on mobile) ─────────────────────────── */}
        <div
          className="hidden md:block flex-1 overflow-auto bg-white dark:bg-gray-800 rounded-lg shadow-sm"
          style={{ maxHeight: "calc(100vh - 240px)", height: "auto" }}
          ref={listContainerRef}
        >
          <table className="w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-[1]">
              <tr>
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.nameHeader')}</th>
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.ageHeader')}</th>
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.genderHeader')}</th>
                {user?.role === 'doctor' && (<th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.problemHeader')}</th>)}
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.createdDateHeader')}</th>
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.ninHeader')}</th>
                <th className="px-6 py-3 text-xs font-medium tracking-wider text-left text-gray-500 dark:text-gray-300 uppercase">{t('patients.list.phoneHeader')}</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {tablePatients.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-sm text-center text-gray-500 dark:text-gray-400">
                    {apiPatients.length === 0 ? t('patients.list.noPatients') : t('patients.list.noResultsMatch')}
                  </td>
                </tr>
              ) : (
                tablePatients.map((patient) => (
                  <tr key={patient.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-gray-100 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <Link href={`/patients/${patient.id}`} className="text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline">{patient.name}</Link>
                        {(patient as any).is_shared_with_me && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-purple-700 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-300 rounded-full">
                            <ShareIcon className="w-3 h-3" />
                            {t('patients.list.shared')}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">{patient.age}</td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">{patient.genre.toUpperCase()}</td>
                    {user?.role === 'doctor' && (<td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap">{patient.chronicDiseases || t('patients.list.na')}</td>)}
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap" dir="ltr">{formatDate(patient.created_at as any)}</td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap" dir="ltr">{patient.nin || t('patients.list.notProvided')}</td>
                    <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 whitespace-nowrap" dir="ltr">{patient.telephone}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Skeleton rows while loading more */}
          {loadingMore && (
            <div className="w-full">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-4 px-6 py-4 border-b border-gray-100 dark:border-gray-700 animate-pulse">
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-48" />
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-8 ml-4" />
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-12 ml-4" />
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-16 ml-auto" />
                </div>
              ))}
            </div>
          )}

          {/* Desktop sentinel — observed relative to this container */}
          <div ref={desktopSentinelRef} className="h-1" aria-hidden />

          {!hasMore && !loadingMore && (
            <div className="py-5 text-center text-xs text-gray-400 dark:text-gray-500 flex items-center justify-center gap-2">
              <span className="h-px w-12 bg-gray-200 dark:bg-gray-700 rounded" />
              {t('patients.list.noMorePatients')}
              <span className="h-px w-12 bg-gray-200 dark:bg-gray-700 rounded" />
            </div>
          )}
        </div>

        {/* ── Mobile card list (hidden on md+) ─────────────────────────── */}
        <div className="md:hidden flex flex-col gap-3 pb-4">
          {tablePatients.length === 0 ? (
            <p className="py-12 text-sm text-center text-gray-500 dark:text-gray-400">
              {apiPatients.length === 0 ? t('patients.list.noPatients') : t('patients.list.noResultsMatch')}
            </p>
          ) : (
            tablePatients.map((patient) => (
              <Link
                key={patient.id}
                href={`/patients/${patient.id}`}
                className="flex items-center gap-4 bg-white dark:bg-gray-800 rounded-xl px-4 py-3 shadow-sm border border-gray-100 dark:border-gray-700 active:bg-gray-50 dark:active:bg-gray-700/60 transition-colors"
              >
                {/* Avatar */}
                <div className="w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center shrink-0">
                  <span className="text-base font-semibold text-blue-600 dark:text-blue-400">
                    {patient.name.charAt(0).toUpperCase()}
                  </span>
                </div>

                {/* Main info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">
                      {patient.name}
                    </span>
                    {(patient as any).is_shared_with_me && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 text-xs font-medium text-purple-700 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-300 rounded-full shrink-0">
                        <ShareIcon className="w-3 h-3" />
                        {t('patients.list.shared')}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                    <span>{patient.age} {t('patients.list.age')}</span>
                    <span>·</span>
                    <span>{patient.genre.toUpperCase()}</span>
                    {patient.telephone && (
                      <>
                        <span>·</span>
                        <span dir="ltr">{patient.telephone}</span>
                      </>
                    )}
                    <span>·</span>
                    <span className="truncate">NIN: {patient.nin || t('patients.list.notProvided')}</span>
                  </div>
                </div>

                {/* Chevron */}
                <svg className="w-4 h-4 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            ))
          )}
          {/* Skeleton cards while loading more — mobile */}
          {loadingMore && (
            <>
              {[1, 2].map((i) => (
                <div key={i} className="flex items-center gap-4 bg-white dark:bg-gray-800 rounded-xl px-4 py-3 shadow-sm border border-gray-100 dark:border-gray-700 animate-pulse">
                  <div className="w-11 h-11 rounded-full bg-gray-200 dark:bg-gray-700 shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Mobile sentinel — observed relative to viewport */}
          <div ref={mobileSentinelRef} className="h-1" aria-hidden />

          {!hasMore && !loadingMore && (
            <div className="py-5 text-center text-xs text-gray-400 dark:text-gray-500 flex items-center justify-center gap-2">
              <span className="h-px w-12 bg-gray-200 dark:bg-gray-700 rounded" />
              {t('patients.list.noMorePatients')}
              <span className="h-px w-12 bg-gray-200 dark:bg-gray-700 rounded" />
            </div>
          )}
        </div>
      </div>

      {/* ── Mobile Search Modal ── */}
      <MobileFullModal
        isOpen={isMobileSearchOpen}
        onClose={() => {
          setIsMobileSearchOpen(false);
          setMobileSearchQuery("");
        }}
        title={t('patients.list.searchMobile')}
      >
        {/* Sticky Search Input Bar */}
        <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 px-4 py-3 border-b border-gray-100 dark:border-gray-800 shadow-sm">
          <div className="relative">
            <input
              type="text"
              autoFocus
              placeholder={t('patients.list.searchMobile')}
              className="w-full h-10 pl-10 pr-10 text-sm bg-gray-100 dark:bg-gray-800 border-transparent rounded-lg focus:border-transparent focus:ring-0 text-gray-900 dark:text-white placeholder-gray-500 outline-none"
              value={mobileSearchQuery}
              onChange={(e) => setMobileSearchQuery(e.target.value)}
            />
            <MagnifyingGlassIcon className="absolute w-5 h-5 text-gray-500 left-3 top-1/2 -translate-y-1/2" />
            {mobileSearchQuery && (
              <button
                onClick={() => setMobileSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
              >
                <XMarkIcon className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Results Area */}
        <div className="px-4 py-2">
          {!mobileSearchQuery.trim() && (
            <div className="py-8 text-center text-gray-500 dark:text-gray-400 text-sm">
              {t('patients.list.typeToSearch')}
            </div>
          )}

          {mobileSearchQuery.trim() && mobileFilteredLocalPatients.length > 0 && (
            <div className="flex flex-col">
              {mobileFilteredLocalPatients.map((patient) => (
                <Link
                  key={patient.id}
                  href={`/patients/${patient.id}`}
                  className="flex items-center gap-4 py-3 active:bg-gray-50 dark:active:bg-gray-800/60 transition-colors border-b border-gray-50 dark:border-gray-800/50 last:border-0"
                  onClick={() => setIsMobileSearchOpen(false)}
                >
                  <div className="w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center shrink-0">
                    <span className="text-base font-semibold text-blue-600 dark:text-blue-400">
                      {patient.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">
                        {patient.name}
                      </span>
                      {(patient as any).is_shared_with_me && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-medium text-purple-700 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-300 rounded-full shrink-0">
                          <ShareIcon className="w-3 h-3" />
                          {t('patients.list.shared')}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                      <span>{patient.age} {t('patients.list.age')}</span>
                      <span>·</span>
                      <span>{patient.genre.toUpperCase()}</span>
                      {patient.telephone && (
                        <>
                          <span>·</span>
                          <span dir="ltr">{patient.telephone}</span>
                        </>
                      )}
                      <span>·</span>
                      <span className="truncate">NIN: {patient.nin || t('patients.list.notProvided')}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {mobileSearchQuery.trim() && mobileFilteredLocalPatients.length === 0 && (
            <div className="flex flex-col">
              {isMobileSearching ? (
                <div className="py-8 flex justify-center">
                  <div className="w-6 h-6 border-b-2 border-blue-600 rounded-full animate-spin"></div>
                </div>
              ) : mobileServerResults === null || mobileServerResults.length === 0 ? (
                <div className="py-8 text-center text-gray-500 dark:text-gray-400 text-sm">
                  {t('patients.list.noResultsMatch')}
                </div>
              ) : (
                mobileServerResults.map((patient) => (
                  <Link
                    key={patient.id}
                    href={`/patients/${patient.id}`}
                    className="flex items-center gap-4 py-3 active:bg-gray-50 dark:active:bg-gray-800/60 transition-colors border-b border-gray-50 dark:border-gray-800/50 last:border-0"
                    onClick={() => setIsMobileSearchOpen(false)}
                  >
                    <div className="w-11 h-11 rounded-full bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center shrink-0">
                      <span className="text-base font-semibold text-blue-600 dark:text-blue-400">
                        {patient.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">
                          {patient.name}
                        </span>
                        {(patient as any).is_shared_with_me && (
                          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 text-[10px] font-medium text-purple-700 bg-purple-100 dark:bg-purple-900/30 dark:text-purple-300 rounded-full shrink-0">
                            <ShareIcon className="w-3 h-3" />
                            {t('patients.list.shared')}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                        <span>{patient.age} {t('patients.list.age')}</span>
                        <span>·</span>
                        <span>{patient.genre?.toUpperCase()}</span>
                        {patient.telephone && (
                          <>
                            <span>·</span>
                            <span dir="ltr">{patient.telephone}</span>
                          </>
                        )}
                        <span>·</span>
                        <span className="truncate">NIN: {patient.nin || t('patients.list.notProvided')}</span>
                      </div>
                    </div>
                  </Link>
                ))
              )}
            </div>
          )}
        </div>
      </MobileFullModal>
    </>
  );
}

export default PatientsList;

