'use client';

import React, { useState, useEffect } from 'react';
import { XMarkIcon, ClockIcon, DocumentTextIcon, UserCircleIcon, ChatBubbleLeftIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import { useRouter } from 'next/navigation';
import { ListSkeleton } from '@/components/feedback';
import MobileFullModal from '@/components/ui/MobileFullModal';

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface DoctorHistory {
    doctorId: number;
    doctorName: string;
    doctorFamilyName: string;
    doctorEmail: string;
    doctorPhone: string;
    doctorSpeciality: string;
    prescriptionCount: number;
    medicalReportCount: number;
    dentalActCount: number;
    lastInteraction: string;
    interactions: Array<{
        type: 'prescription' | 'medical_report' | 'dental_act';
        id: string;
        date: string;
    }>;
}

interface HistoryMetadata {
    patientCount: number;
    searchMethod: 'nin' | 'demographic';
    hasDuplicates: boolean;
}

interface PatientHistoryModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    patientName: string;
    currentUserId?: number;
}

// ─── Shared content component ────────────────────────────────────────────────
// Used by both the desktop overlay and the mobile full-screen sheet.

interface HistoryContentProps {
    isLoading: boolean;
    error: string | null;
    history: DoctorHistory[];
    metadata?: HistoryMetadata;
    currentUserId?: number;
    loadingDoctorId: number | null;
    formatDate: (d: string) => string;
    fetchHistory: () => void;
    handleMessageDoctor: (id: number) => void;
}

function HistoryContent({
    isLoading,
    error,
    history,
    metadata,
    currentUserId,
    loadingDoctorId,
    formatDate,
    fetchHistory,
    handleMessageDoctor,
}: HistoryContentProps) {
    return (
        <div className="p-4 space-y-4">
            {/* Duplicate Warning */}
            {metadata?.hasDuplicates && (
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3">
                    <p className="text-amber-800 dark:text-amber-200 text-sm flex items-center gap-2">
                        <ExclamationTriangleIcon className="w-5 h-5 flex-shrink-0" />
                        <span>
                            Historique agrégé de <strong>{metadata.patientCount}</strong> dossiers correspondants
                            {metadata.searchMethod === 'nin' ? ' (même NIN)' : ' (même nom/prénom/date de naissance)'}
                        </span>
                    </p>
                </div>
            )}

            {/* Loading */}
            {isLoading && <ListSkeleton count={3} />}

            {/* Error */}
            {error && !isLoading && (
                <div className="text-center py-12">
                    <ExclamationTriangleIcon className="w-16 h-16 text-red-300 dark:text-red-600 mx-auto mb-4" />
                    <p className="text-red-500 dark:text-red-400">{error}</p>
                    <button
                        onClick={fetchHistory}
                        className="mt-4 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg"
                    >
                        Réessayer
                    </button>
                </div>
            )}

            {/* Empty */}
            {!isLoading && !error && history.length === 0 && (
                <div className="text-center py-12">
                    <ClockIcon className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                    <p className="text-gray-500 dark:text-gray-400">
                        Aucune interaction enregistrée pour ce patient
                    </p>
                </div>
            )}

            {/* History list */}
            {!isLoading && !error && history.length > 0 && (
                <div className="space-y-4">
                    {history.map((doctor) => (
                        <div
                            key={doctor.doctorId}
                            className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 border border-gray-200 dark:border-gray-600 hover:shadow-md transition-shadow"
                        >
                            {/* Doctor info row */}
                            <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center gap-3">
                                    <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center shrink-0">
                                        <UserCircleIcon className="w-7 h-7 text-blue-600 dark:text-blue-400" />
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-gray-900 dark:text-white text-sm">
                                            Dr. {doctor.doctorName} {doctor.doctorFamilyName}
                                        </h3>
                                        <p className="text-xs text-gray-600 dark:text-gray-400">
                                            {doctor.doctorSpeciality || 'Médecin'}
                                        </p>
                                        {doctor.doctorPhone && (
                                            <p className="text-xs text-gray-500 dark:text-gray-500">
                                                📞 {doctor.doctorPhone}
                                            </p>
                                        )}
                                    </div>
                                </div>

                                {/* Message button */}
                                {currentUserId !== doctor.doctorId && (
                                    <button
                                        onClick={() => handleMessageDoctor(doctor.doctorId)}
                                        disabled={loadingDoctorId === doctor.doctorId}
                                        className="flex items-center gap-1.5 px-3 py-2 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-400 text-white text-xs font-medium rounded-lg transition-colors shrink-0"
                                        title="Envoyer un message"
                                    >
                                        {loadingDoctorId === doctor.doctorId ? (
                                            <>
                                                <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                                <span className="hidden sm:inline">Ouverture...</span>
                                            </>
                                        ) : (
                                            <>
                                                <ChatBubbleLeftIcon className="w-3.5 h-3.5" />
                                                <span className="hidden sm:inline">Message</span>
                                            </>
                                        )}
                                    </button>
                                )}
                            </div>

                            {/* Stats badges */}
                            <div className="flex flex-wrap gap-2 mb-3">
                                <div className="flex items-center gap-1.5 bg-green-100 dark:bg-green-900/30 px-2.5 py-1 rounded-lg">
                                    <DocumentTextIcon className="w-3.5 h-3.5 text-green-600 dark:text-green-400" />
                                    <span className="text-xs font-medium text-green-800 dark:text-green-300">
                                        {doctor.prescriptionCount} ordonnance{doctor.prescriptionCount > 1 ? 's' : ''}
                                    </span>
                                </div>
                                <div className="flex items-center gap-1.5 bg-purple-100 dark:bg-purple-900/30 px-2.5 py-1 rounded-lg">
                                    <DocumentTextIcon className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                                    <span className="text-xs font-medium text-purple-800 dark:text-purple-300">
                                        {doctor.medicalReportCount} CR{doctor.medicalReportCount > 1 ? 's' : ''}
                                    </span>
                                </div>
                                {doctor.dentalActCount > 0 && (
                                    <div className="flex items-center gap-1.5 bg-cyan-100 dark:bg-cyan-900/30 px-2.5 py-1 rounded-lg">
                                        <svg className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                            <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
                                        </svg>
                                        <span className="text-xs font-medium text-cyan-800 dark:text-cyan-300">
                                            {doctor.dentalActCount} acte{doctor.dentalActCount > 1 ? 's' : ''}
                                        </span>
                                    </div>
                                )}
                            </div>

                            {/* Last interaction */}
                            <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400 mb-3">
                                <ClockIcon className="w-3.5 h-3.5 shrink-0" />
                                <span>Dernière interaction: {formatDate(doctor.lastInteraction)}</span>
                            </div>

                            {/* Recent interactions */}
                            <div className="pt-3 border-t border-gray-200 dark:border-gray-600">
                                <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-2">
                                    Dernières interactions:
                                </p>
                                <div className="space-y-1">
                                    {doctor.interactions.slice(0, 3).map((interaction, idx) => (
                                        <div
                                            key={idx}
                                            className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-700 rounded px-2 py-1"
                                        >
                                            <span className="flex items-center gap-1.5">
                                                <DocumentTextIcon className="w-3 h-3" />
                                                {interaction.type === 'prescription' ? 'Ordonnance' :
                                                    interaction.type === 'medical_report' ? 'Compte rendu' : 'Acte dentaire'}
                                            </span>
                                            <span>{formatDate(interaction.date)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

// ─── Main component ───────────────────────────────────────────────────────────

/**
 * PatientHistoryModal
 *
 * - Mobile  (< md): renders inside MobileFullModal (full-screen slide-up)
 * - Desktop (≥ md): renders as the original centred overlay modal
 */
export function PatientHistoryModal({
    isOpen,
    onClose,
    patientId,
    patientName,
    currentUserId,
}: PatientHistoryModalProps) {
    const router = useRouter();
    const [loadingDoctorId, setLoadingDoctorId] = useState<number | null>(null);
    const [history, setHistory] = useState<DoctorHistory[]>([]);
    const [metadata, setMetadata] = useState<HistoryMetadata | undefined>();
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isMobile, setIsMobile] = useState(false);

    // Track mobile breakpoint (md = 768px)
    useEffect(() => {
        const mq = window.matchMedia('(max-width: 767px)');
        setIsMobile(mq.matches);
        const handler = (e: MediaQueryListEvent) => setIsMobile(e.matches);
        mq.addEventListener('change', handler);
        return () => mq.removeEventListener('change', handler);
    }, []);

    // Fetch history when modal opens
    useEffect(() => {
        if (isOpen && patientId) fetchHistory();
    }, [isOpen, patientId]);

    const fetchHistory = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const response = await fetch(`${API_URL}/patient/${patientId}/history`, {
                credentials: 'include',
            });
            if (!response.ok) throw new Error('Failed to fetch history');
            const data = await response.json();
            setHistory(data.data || []);
            setMetadata(data.metadata);
        } catch (err) {
            console.error('Error fetching patient history:', err);
            setError("Impossible de charger l'historique");
            setHistory([]);
        } finally {
            setIsLoading(false);
        }
    };

    const formatDate = (dateString: string) =>
        new Intl.DateTimeFormat('fr-FR', {
            day: '2-digit',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        }).format(new Date(dateString));

    const handleMessageDoctor = async (doctorId: number) => {
        setLoadingDoctorId(doctorId);
        try {
            const response = await fetch(`${API_URL}/messaging/conversations`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ peerUserId: doctorId }),
            });
            if (response.ok) {
                const data = await response.json();
                const convId = data.data?.conversationId || data.data?.conversation?.id;
                router.push(convId ? `/messages?conversation=${convId}` : `/messages?doctor=${doctorId}`);
            } else {
                router.push(`/messages?doctor=${doctorId}`);
            }
        } catch {
            router.push(`/messages?doctor=${doctorId}`);
        } finally {
            setLoadingDoctorId(null);
        }
    };

    const sharedProps: HistoryContentProps = {
        isLoading,
        error,
        history,
        metadata,
        currentUserId,
        loadingDoctorId,
        formatDate,
        fetchHistory,
        handleMessageDoctor,
    };

    if (!isOpen) return null;

    // ── Mobile: full-screen slide-up ──────────────────────────────────────────
    if (isMobile) {
        return (
            <MobileFullModal
                isOpen={isOpen}
                onClose={onClose}
                title={`Historique — ${patientName}`}
            >
                <HistoryContent {...sharedProps} />
            </MobileFullModal>
        );
    }

    // ── Desktop: original centred overlay (unchanged) ─────────────────────────
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
                {/* Header */}
                <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between bg-gradient-to-r from-blue-500 to-blue-600">
                    <div className="flex items-center gap-3">
                        <ClockIcon className="w-6 h-6 text-white" />
                        <div>
                            <h2 className="text-xl font-bold text-white">
                                Historique des interactions
                            </h2>
                            <p className="text-sm text-blue-100">Patient: {patientName}</p>
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                    >
                        <XMarkIcon className="w-6 h-6 text-white" />
                    </button>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto">
                    <HistoryContent {...sharedProps} />
                </div>

                {/* Footer */}
                <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                    <button
                        onClick={onClose}
                        className="w-full px-4 py-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-medium rounded-lg transition-colors"
                    >
                        Fermer
                    </button>
                </div>
            </div>
        </div>
    );
}

export default PatientHistoryModal;
