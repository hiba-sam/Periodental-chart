// Privacy Types - Type definitions for patient privacy and access control

/**
 * Privacy choice options
 */
export type PrivacyChoice = 'private' | 'shared';

/**
 * Access state for patient detail page
 */
export interface AccessState {
    showAccessConfirmation: boolean;
    accessConfirmed: boolean;
    patientPresentCheckbox: boolean;
    showPrivacyChoicePopup: boolean;
    myPrivacyChoice: PrivacyChoice | null;
    privacyChoiceLoaded: boolean;
}

/**
 * Primary care doctor information
 */
export interface PrimaryCareDoctor {
    id: number;
    name: string;
    family_name: string;
    phone?: string;
    email?: string;
    specialty?: string;
}

/**
 * Primary care information for a patient
 */
export interface PrimaryCareInfo {
    primaryCareDoctor: PrimaryCareDoctor | null;
    isCurrentDoctor: boolean;
    isPatientOwner: boolean;
    shared: boolean;
    shareId?: number;
    shareDate?: string;
}

/**
 * Medical share record
 */
export interface MedicalShare {
    id: number;
    patient_id: string;
    shared_by_doctor_id: number;
    shared_with_doctor_id: number;
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date: string | null;
    expires_at: string | null;
    status: 'active' | 'revoked' | 'expired';
    reason?: string;
    created_at: string;
    updated_at: string;
}

/**
 * Share request payload
 */
export interface ShareRequestPayload {
    patient_id: string;
    shared_with_doctor_ids: number[];
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date?: string | null;
    expires_at?: string;
    reason?: string;
}

/**
 * Privacy choice response from API
 */
export interface PrivacyChoiceResponse {
    success: boolean;
    data: {
        privacy_choice: PrivacyChoice | null;
    };
}

/**
 * Initial access state
 */
export const initialAccessState: AccessState = {
    showAccessConfirmation: false,
    accessConfirmed: false,
    patientPresentCheckbox: false,
    showPrivacyChoicePopup: false,
    myPrivacyChoice: null,
    privacyChoiceLoaded: false,
};
