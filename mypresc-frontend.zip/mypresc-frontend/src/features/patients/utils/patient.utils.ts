// Patient Utilities - Helper functions for patient-related operations

import type { Patient } from '../types';

/**
 * Format patient full name
 */
export function formatPatientName(patient: Patient): string {
    return `${patient.name} ${patient.family_name}`;
}

/**
 * Format patient age display
 */
export function formatPatientAge(patient: Patient): string {
    return `${patient.age} ans`;
}

/**
 * Get patient initials for avatar
 */
export function getPatientInitials(patient: Patient): string {
    return `${patient.name.charAt(0)}${patient.family_name.charAt(0)}`.toUpperCase();
}

/**
 * Check if patient has complete profile
 */
export function isPatientProfileComplete(patient: Patient): boolean {
    return !!(
        patient.name &&
        patient.family_name &&
        patient.dateNaissance &&
        patient.telephone &&
        patient.genre
    );
}

/**
 * Check if patient has NIN
 */
export function patientHasNin(patient: Patient): boolean {
    return !!patient.nin && patient.nin.trim().length > 0;
}

/**
 * Calculate age from date of birth
 */
export function calculateAge(dateOfBirth: string): number {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

    return age;
}

/**
 * Format phone number for display
 */
export function formatPhoneNumber(phone: string): string {
    if (!phone) return '';
    // Remove all non-digits
    const cleaned = phone.replace(/\D/g, '');
    // Format as XX XX XX XX XX (Algerian format)
    if (cleaned.length === 10) {
        return cleaned.replace(/(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1 $2 $3 $4 $5');
    }
    return phone;
}

/**
 * Get gender label
 */
export function getGenderLabel(genre: 'homme' | 'femme', language: 'fr' | 'en' | 'ar' = 'fr'): string {
    const labels = {
        fr: { homme: 'Homme', femme: 'Femme' },
        en: { homme: 'Male', femme: 'Female' },
        ar: { homme: 'ذكر', femme: 'أنثى' },
    };
    return labels[language][genre];
}

/**
 * Sort patients by name
 */
export function sortPatientsByName(patients: Patient[], order: 'asc' | 'desc' = 'asc'): Patient[] {
    return [...patients].sort((a, b) => {
        const nameA = `${a.family_name} ${a.name}`.toLowerCase();
        const nameB = `${b.family_name} ${b.name}`.toLowerCase();
        const comparison = nameA.localeCompare(nameB);
        return order === 'asc' ? comparison : -comparison;
    });
}

/**
 * Filter patients by search term
 */
export function filterPatientsBySearch(patients: Patient[], searchTerm: string): Patient[] {
    if (!searchTerm.trim()) return patients;

    const term = searchTerm.toLowerCase();
    return patients.filter((patient) => {
        return (
            patient.name.toLowerCase().includes(term) ||
            patient.family_name.toLowerCase().includes(term) ||
            patient.telephone?.includes(term) ||
            patient.nin?.includes(term) ||
            patient.email?.toLowerCase().includes(term)
        );
    });
}
