// Calendar Feature - Main barrel export

// Types and constants (centralized)
export * from './types';

// API
export * from './api';

// Hooks
export * from './hooks';

// Utilities
export * from './utils';

// Grid Components
export {
    TimeSlot,
    EventBlock,
    getEventColors,
    DayCell,
    DayGrid,
    WeekGrid,
    MonthGrid,
    MobileMonthView,
    CalendarGridContainer,
    WeekDayColumn,
    CurrentTimeIndicator,
} from './components';

// Event Components
export {
    EventFormContainer,
    EventTypeSelector,
    PatientSearchField,
    EventFormFields,
    AppointmentForm,
    StandaloneEventForm,
    EventCard,
    EventDetails,
    MobileEventDetails,
    MobileEventEditForm,
    DraggableEvent,
    useEventForm,
} from './components';

// Standalone Components
export {
    MiniMonth,
    DeleteConfirmModal,
} from './components';

// Types from events
export type {
    EventType,
    EventFormData,
    PreselectedPatient,
    UseEventFormOptions,
} from './components';
