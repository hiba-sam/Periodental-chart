// DeleteConfirmModal - Confirmation dialog for event deletion
'use client';

import React from 'react';
import Modal from '@/components/ui/Modal';
import { useLanguage } from '@/contexts/LanguageContext';
import { ExclamationTriangleIcon, PhoneIcon } from '@heroicons/react/24/outline';
import { usePatients } from '@/contexts/PatientsContext';
import type { CalendarEvent } from '../types';

interface DeleteConfirmModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    event: CalendarEvent | null;
    isDeleting?: boolean;
}

/**
 * Confirmation modal for deleting calendar events
 */
export function DeleteConfirmModal({
    isOpen,
    onClose,
    onConfirm,
    event,
    isDeleting = false,
}: DeleteConfirmModalProps) {
    const { t, language } = useLanguage();
    const { patients } = usePatients();

    if (!event) return null;

    const patientData = patients.find((p) => p.id === event.patientId);
    const displayPhone = event.patientPhone || patientData?.telephone;

    const formatDate = (date: Date): string => {
        const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        return date.toLocaleDateString(locale, {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="" closeOnBackdrop={false}>
            <div className="space-y-5">
                {/* Warning Icon */}
                <div className="flex justify-center">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                        <ExclamationTriangleIcon className="w-10 h-10 text-red-600" />
                    </div>
                </div>

                {/* Title */}
                <div className="text-center">
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
                        {t('calendar.deleteAppointmentTitle')}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                        {t('calendar.deleteWarning')}
                    </p>
                </div>

                {/* Event Details Summary */}
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 space-y-2">
                    <div className="flex items-start gap-3">
                        <div className="flex-1">
                            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{event.title}</p>
                            <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{formatDate(event.date)}</p>
                            <p className="text-xs text-gray-600 dark:text-gray-400">
                                {event.time} - {event.endTime} ({event.duration} {t('calendar.min')})
                            </p>
                            {event.description && (
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 line-clamp-2">{event.description}</p>
                            )}
                        </div>
                    </div>
                </div>

                {/* Warning Message */}
                <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-400 dark:border-red-500 p-4">
                    <div className="flex">
                        <div className="flex-shrink-0 mt-0.5">
                            <ExclamationTriangleIcon className="h-5 w-5 text-red-400 dark:text-red-300" />
                        </div>
                        <div className="ml-3 flex-1 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                            <p className="text-sm text-red-700 dark:text-red-300">
                                {t('calendar.patientNotNotified')}
                            </p>
                            {displayPhone && (
                                <>
                                    {/* Mobile view: call button */}
                                    <a
                                        href={`tel:${displayPhone}`}
                                        className="md:hidden inline-flex items-center justify-center gap-2 px-4 py-2 bg-green-500 text-white hover:bg-green-600 rounded-md transition-colors text-sm font-medium shadow-sm flex-shrink-0"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <PhoneIcon className="w-4 h-4 flex-shrink-0" />
                                        <span>{t('calendar.callPatient') || 'Appeler le patient'}</span>
                                    </a>
                                    {/* Desktop view: text link only */}
                                    <a
                                        href={`tel:${displayPhone}`}
                                        className="hidden md:flex items-center gap-2 text-red-700 dark:text-red-300 hover:text-red-800 dark:hover:text-red-200 text-sm font-medium transition-colors"
                                        onClick={(e) => e.stopPropagation()}
                                    >
                                        <PhoneIcon className="w-4 h-4 flex-shrink-0" />
                                        <span>{displayPhone}</span>
                                    </a>
                                </>
                            )}
                        </div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-2">
                    <button
                        type="button"
                        onClick={onClose}
                        disabled={isDeleting}
                        className="flex-1 px-4 py-2 bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {t('calendar.cancel')}
                    </button>
                    <button
                        type="button"
                        onClick={onConfirm}
                        disabled={isDeleting}
                        className="flex-1 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isDeleting ? t('calendar.deleting') : t('calendar.delete')}
                    </button>
                </div>
            </div>
        </Modal>
    );
}

export default DeleteConfirmModal;
