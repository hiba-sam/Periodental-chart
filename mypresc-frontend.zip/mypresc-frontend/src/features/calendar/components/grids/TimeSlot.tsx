// TimeSlot Component - Individual time slot in day/week grid
'use client';

import React from 'react';
import { DroppableSlot } from '@/components/calendar/DroppableSlot';

export interface TimeSlotProps {
    slotId: string;
    hour: number;
    minute: number;
    isPast: boolean;
    isDropTarget?: boolean;
    onClick: (hour: number, minute: number) => void;
    height?: number;
    className?: string;
}

/**
 * Individual clickable/droppable time slot
 */
export function TimeSlot({
    slotId,
    hour,
    minute,
    isPast,
    isDropTarget,
    onClick,
    height = 40,
    className = '',
}: TimeSlotProps) {
    const handleClick = () => {
        if (!isPast) {
            onClick(hour, minute);
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (!isPast && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault();
            onClick(hour, minute);
        }
    };

    const timeLabel = `${String(hour >= 24 ? hour - 24 : hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;

    return (
        <DroppableSlot
            id={slotId}
            disabled={isPast}
            className={className}
            style={{ height: `${height}px` }}
        >
            <div
                role="button"
                tabIndex={isPast ? -1 : 0}
                aria-label={`Create event at ${timeLabel}`}
                className={`
                    w-full h-full transition-colors
                    ${isPast
                        ? 'bg-gray-100 dark:bg-gray-900/80 cursor-not-allowed'
                        : 'cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30 active:bg-blue-100 dark:active:bg-blue-900/50'
                    }
                    ${isDropTarget ? 'bg-blue-100 dark:bg-blue-900/50' : ''}
                `}
                style={{ pointerEvents: 'auto' }}
                onClick={handleClick}
                onKeyDown={handleKeyDown}
            />
        </DroppableSlot>
    );
}

export default TimeSlot;
