// Calendar Grids - Barrel export
// Components
export { TimeSlot } from './TimeSlot';
export type { TimeSlotProps } from './TimeSlot';

export { EventBlock, getEventColors } from './EventBlock';
export type { EventBlockProps } from './EventBlock';

export { DayCell } from './DayCell';
export type { DayCellProps } from './DayCell';

export { DayGrid } from './DayGrid';
export { WeekGrid } from './WeekGrid';
export { MonthGrid } from './MonthGrid';
export { MobileMonthView } from './MobileMonthView';
export { CalendarGridContainer } from './CalendarGridContainer';

export { WeekDayColumn } from './WeekDayColumn';
export { CurrentTimeIndicator } from './CurrentTimeIndicator';

// Re-export hooks from hooks folder
export {
    useDayGrid,
    useWeekGrid,
    useMonthGrid,
    getSaturdayWeekStart,
} from '../../hooks';

// Re-export types and constants from types folder
export {
    HOURS_START,
    HOURS_END,
    SLOT_HEIGHT,
    QUARTER_SLOT_HEIGHT,
    DAY_COLUMN_WIDTH,
    TIME_LABEL_WIDTH,
} from '../../types';

export type {
    DayColumn,
    TimeSlotData,
    EventStyle,
    DayCellData,
} from '../../types';
