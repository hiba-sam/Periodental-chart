// MonthGrid Component - Month view calendar grid
'use client';

import React, { useCallback } from 'react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { DayCell } from './DayCell';
import { useMonthGrid } from '../../hooks/useMonthGrid';

interface MonthGridProps {
    onDayClick?: (date: Date) => void;
    onEventClick?: (event: CalendarEvent) => void;
}

/**
 * Month view grid - displays calendar month with day cells
 */
export function MonthGrid({ onDayClick, onEventClick }: MonthGridProps) {
    const { selectedDate, getEventsForMonth, selectEvent } = useCalendar();

    // Month grid logic
    const {
        weekDays,
        calendarCells,
        monthLabel,
        isRTL,
        getOccupationRate,
        getOccupationColor,
    } = useMonthGrid({ selectedDate, getEventsForMonth });

    // Handle day click
    const handleDayClick = useCallback((date: Date) => {
        onDayClick?.(date);
    }, [onDayClick]);

    // Handle event click
    const handleEventClick = useCallback((event: CalendarEvent, e: React.MouseEvent) => {
        e.stopPropagation();
        selectEvent(event);
        onEventClick?.(event);
    }, [selectEvent, onEventClick]);

    return (
        <div className="month-grid-container bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
            {/* Month Header */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
                <h3 className="text-lg font-semibold capitalize text-gray-800 dark:text-gray-100">
                    {monthLabel}
                </h3>
            </div>

            {/* Calendar Grid */}
            <div className="p-4">
                {/* Week day headers */}
                <div className="grid grid-cols-7 mb-2" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
                    {weekDays.map((day, idx) => (
                        <div key={idx} className="text-center text-sm font-semibold text-gray-600 dark:text-gray-400 py-2">
                            {day}
                        </div>
                    ))}
                </div>

                {/* Calendar cells */}
                <div className="grid grid-cols-7 gap-2" style={{ direction: isRTL ? 'rtl' : 'ltr' }}>
                    {calendarCells.map((cell, idx) => {
                        const occupationRate = getOccupationRate(cell.events);
                        const occupationColor = getOccupationColor(occupationRate);

                        return (
                            <DayCell
                                key={idx}
                                cell={cell}
                                occupationColor={occupationColor}
                                onClick={handleDayClick}
                                onEventClick={handleEventClick}
                            />
                        );
                    })}
                </div>

                {/* Legend */}
                <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">
                        Taux d'occupation
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border-2 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">Faible (&lt;40%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border-2 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">Modéré (40-70%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border-2 bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">Élevé (70-90%)</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded border-2 bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800" />
                            <span className="text-xs text-gray-600 dark:text-gray-400">Complet (&gt;90%)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default MonthGrid;
