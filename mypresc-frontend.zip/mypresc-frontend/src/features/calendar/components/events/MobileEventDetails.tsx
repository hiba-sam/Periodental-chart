// MobileEventDetails — Native-mobile appointment details screen
// Replaces the desktop EventDetails card inside MobileFullModal with a
// purpose-built mobile UI: colour hero strip, large patient name, clean info
// rows, pill toggle buttons, and sticky action bar.
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
    UserIcon,
    PhoneIcon,
    ClockIcon,
    CalendarDaysIcon,
    DocumentTextIcon,
    PencilSquareIcon,
    TrashIcon,
    CheckCircleIcon,
    ChevronRightIcon,
} from '@heroicons/react/24/outline';
import { CheckCircleIcon as CheckCircleSolid } from '@heroicons/react/24/solid';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePatients, ApiPatient } from '@/contexts/PatientsContext';
import { UpdateConfirmModal } from '../UpdateConfirmModal';

// ─── Types ────────────────────────────────────────────────────────────────────

interface MobileEventDetailsProps {
    event: CalendarEvent;
    onEdit: (event: CalendarEvent) => void;
    onDelete: (event: CalendarEvent) => void;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatFullDate(date: Date, language: string): string {
    const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
    return date.toLocaleDateString(locale, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
    });
}

function hexToRgb(hex: string): string {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result || !result[1] || !result[2] || !result[3]) return '37, 99, 235'; // default blue
    return `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`;
}

// ─── Info Row ─────────────────────────────────────────────────────────────────

function InfoRow({
    icon,
    label,
    value,
    href,
    accent,
}: {
    icon: React.ReactNode;
    label: string;
    value: string;
    href?: string;
    accent?: boolean;
}) {
    return (
        <div className="flex items-center gap-4 py-3.5">
            <div className="w-9 h-9 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center flex-shrink-0">
                {icon}
            </div>
            <div className="flex-1 min-w-0">
                <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-0.5">
                    {label}
                </p>
                {href ? (
                    <Link href={href}>
                        <span className={`text-sm font-semibold ${accent ? 'text-blue-500 dark:text-blue-400' : 'text-gray-900 dark:text-white'} truncate block`}>
                            {value}
                        </span>
                    </Link>
                ) : (
                    <p className={`text-sm font-semibold ${accent ? 'text-blue-500 dark:text-blue-400' : 'text-gray-900 dark:text-white'} truncate`}>
                        {value}
                    </p>
                )}
            </div>
            {href && (
                <ChevronRightIcon className="w-4 h-4 text-gray-300 dark:text-gray-600 flex-shrink-0" />
            )}
        </div>
    );
}

// ─── Toggle Pill ──────────────────────────────────────────────────────────────

function StatusToggle({
    active,
    activeLabel,
    inactiveLabel,
    activeColor,
    loading,
    onClick,
}: {
    active: boolean;
    activeLabel: string;
    inactiveLabel: string;
    activeColor: 'green' | 'blue';
    loading: boolean;
    onClick: () => void;
}) {
    const colors = {
        green: {
            on: 'bg-green-500',
            off: 'bg-gray-200 dark:bg-gray-700',
            text: 'text-green-600 dark:text-green-400',
            textOff: 'text-gray-500 dark:text-gray-400',
        },
        blue: {
            on: 'bg-blue-500',
            off: 'bg-gray-200 dark:bg-gray-700',
            text: 'text-blue-600 dark:text-blue-400',
            textOff: 'text-gray-500 dark:text-gray-400',
        },
    }[activeColor];

    return (
        <button
            onClick={onClick}
            disabled={loading}
            className={`flex items-center justify-between w-full px-4 py-3.5 rounded-2xl transition-all duration-200
                ${active ? `${activeColor === 'green' ? 'bg-green-50 dark:bg-green-900/20' : 'bg-blue-50 dark:bg-blue-900/20'} ring-1 ${activeColor === 'green' ? 'ring-green-200 dark:ring-green-800' : 'ring-blue-200 dark:ring-blue-800'}` : 'bg-gray-50 dark:bg-gray-800/60'}
                disabled:opacity-60`}
        >
            <div className="flex items-center gap-3">
                {active ? (
                    <CheckCircleSolid className={`w-5 h-5 ${colors.text} flex-shrink-0`} />
                ) : (
                    <CheckCircleIcon className="w-5 h-5 text-gray-300 dark:text-gray-600 flex-shrink-0" />
                )}
                <span className={`text-sm font-semibold ${active ? colors.text : colors.textOff}`}>
                    {active ? activeLabel : inactiveLabel}
                </span>
            </div>
            {/* iOS-style toggle switch */}
            <div className={`relative w-11 h-6 rounded-full transition-colors duration-300 ${active ? colors.on : colors.off}`}>
                <div className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 bg-white rounded-full shadow transition-transform duration-300 ${active ? 'translate-x-5' : 'translate-x-1'}`} />
            </div>
        </button>
    );
}

// ─── Component ────────────────────────────────────────────────────────────────

export function MobileEventDetails({ event, onEdit, onDelete }: MobileEventDetailsProps) {
    const { updateEvent, updateEventOptimistic } = useCalendar();
    const { t, language, isRTL } = useLanguage();
    const { getPatient } = usePatients();

    const [isUpdatingConfirmed, setIsUpdatingConfirmed] = useState(false);
    const [isUpdatingDone, setIsUpdatingDone] = useState(false);
    const [localConfirmed, setLocalConfirmed] = useState(event.venueConfirmed ?? false);
    const [localDone, setLocalDone] = useState(event.isDone ?? false);

    const [patientData, setPatientData] = useState<ApiPatient | null>(null);
    const [isLoadingPatient, setIsLoadingPatient] = useState(false);
    const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);

    useEffect(() => {
        const loadPatient = async () => {
            if (event.isAppointmentLinked && event.patientId && !event.patientPhone) {
                setIsLoadingPatient(true);
                try {
                    const p = await getPatient(event.patientId.toString());
                    if (p) {
                        setPatientData(p);
                    }
                } catch (error) {
                    console.error("Error fetching patient details:", error);
                } finally {
                    setIsLoadingPatient(false);
                }
            }
        };

        loadPatient();
    }, [event.patientId, event.isAppointmentLinked, event.patientPhone, getPatient]);

    useEffect(() => {
        setLocalConfirmed(event.venueConfirmed ?? false);
        setLocalDone(event.isDone ?? false);
    }, [event.venueConfirmed, event.isDone, event.id]);

    const handleToggleConfirmed = async () => {
        const newValue = !localConfirmed;
        setLocalConfirmed(newValue);
        setIsUpdatingConfirmed(true);
        updateEventOptimistic(event.id, { venueConfirmed: newValue });
        try {
            await updateEvent({ id: event.id, venue_confirmed: newValue }, true);
        } catch {
            setLocalConfirmed(!newValue);
            updateEventOptimistic(event.id, { venueConfirmed: !newValue });
        } finally {
            setIsUpdatingConfirmed(false);
        }
    };

    const handleToggleDone = async () => {
        const newValue = !localDone;
        setLocalDone(newValue);
        setIsUpdatingDone(true);
        updateEventOptimistic(event.id, { isDone: newValue });
        try {
            await updateEvent({ id: event.id, is_done: newValue }, true);
        } catch {
            setLocalDone(!newValue);
            updateEventOptimistic(event.id, { isDone: !newValue });
        } finally {
            setIsUpdatingDone(false);
        }
    };

    const rgb = hexToRgb(event.color ?? '#2563eb');
    const dateStr = formatFullDate(event.date, language);
    const timeStr = event.endTime
        ? `${event.time ?? ''} – ${event.endTime}${event.duration ? ` · ${event.duration} ${t('calendar.min')}` : ''}`
        : (event.time ?? t('calendar.allDay'));

    const displayPhone = event.patientPhone || patientData?.telephone;

    const handleEditClick = () => {
        // If it's an appointment with a patient and they have a phone, show the warning modal
        if (event.isAppointmentLinked && displayPhone) {
            setIsUpdateModalOpen(true);
        } else {
            onEdit(event);
        }
    };

    const handleSkipUpdateAction = () => {
        setIsUpdateModalOpen(false);
        onEdit(event);
    };

    console.log(event);
    return (
        <div className="flex flex-col h-full" dir={isRTL ? 'rtl' : 'ltr'}>

            {/* ── Hero colour strip ─────────────────────────────────────── */}
            <div
                className="relative px-6 pt-6 pb-8 overflow-hidden"
                style={{
                    background: `linear-gradient(135deg, rgba(${rgb}, 0.9) 0%, rgba(${rgb}, 0.65) 100%)`,
                }}
            >
                {/* Background circle decoration */}
                <div
                    className="absolute -top-10 -right-10 w-44 h-44 rounded-full opacity-20"
                    style={{ backgroundColor: event.color }}
                />
                <div
                    className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full opacity-10"
                    style={{ backgroundColor: event.color }}
                />

                {/* Type badge */}
                <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold bg-white/20 text-white uppercase tracking-widest mb-3 backdrop-blur-sm">
                    {event.isAppointmentLinked ? t('calendar.appointment') : t('calendar.event')}
                </span>

                {/* Patient / event name */}
                <h2 className="text-2xl font-bold text-white leading-tight mb-1">
                    {event.title}
                </h2>

                {/* Quick time summary */}
                <p className="text-sm text-white/80 font-medium mt-2">
                    {dateStr}
                </p>
                <p className="text-sm text-white/70 mt-0.5 mb-4">
                    {timeStr}
                </p>

                {/* Call Action Button */}
                {displayPhone && (
                    <a
                        href={`tel:${displayPhone}`}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-green-500 text-white font-medium shadow-lg shadow-green-500/30 hover:bg-green-600 active:bg-green-700 transition-[background,transform] active:scale-95"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <PhoneIcon className="w-5 h-5 flex-shrink-0" />
                        <span>{t('calendar.callPatient') || 'Appeler le patient'}</span>
                    </a>
                )}
            </div>

            {/* ── Scrollable content ────────────────────────────────────── */}
            <div className="flex-1 overflow-y-auto pb-28">

                {/* Info rows */}
                <div className="px-5 mt-2 divide-y divide-gray-100 dark:divide-gray-800">

                    {/* Patient info */}
                    {event.isAppointmentLinked && (
                        <InfoRow
                            icon={<UserIcon className="w-4.5 h-4.5 text-gray-500 dark:text-gray-400 w-5 h-5" />}
                            label={t('calendar.patient')}
                            value={event.title}
                            href={event.patientId ? `/patients/${event.patientId}` : undefined}
                            accent={!!event.patientId}
                        />
                    )}

                    {/* Date */}
                    <InfoRow
                        icon={<CalendarDaysIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />}
                        label={t('calendar.date')}
                        value={dateStr}
                    />

                    {/* Time */}
                    <InfoRow
                        icon={<ClockIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />}
                        label={t('calendar.time')}
                        value={timeStr}
                    />

                    {/* Notes / description */}
                    {event.description && (
                        <InfoRow
                            icon={<DocumentTextIcon className="w-5 h-5 text-gray-500 dark:text-gray-400" />}
                            label={event.isAppointmentLinked ? t('calendar.consultationNotes') : t('calendar.description')}
                            value={event.description}
                        />
                    )}
                </div>

                {/* Status toggles */}
                {event.isAppointmentLinked && (
                    <div className="px-5 mt-4 space-y-3">
                        <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400 dark:text-gray-500 mb-2">
                            {t('calendar.status')}
                        </p>
                        <StatusToggle
                            active={localConfirmed}
                            activeLabel={t('calendar.confirmed')}
                            inactiveLabel={t('calendar.notConfirmed')}
                            activeColor="green"
                            loading={isUpdatingConfirmed}
                            onClick={handleToggleConfirmed}
                        />
                        <StatusToggle
                            active={localDone}
                            activeLabel={t('calendar.completed')}
                            inactiveLabel={t('calendar.pending')}
                            activeColor="blue"
                            loading={isUpdatingDone}
                            onClick={handleToggleDone}
                        />
                    </div>
                )}
            </div>

            {/* ── Sticky action bar ─────────────────────────────────────── */}
            <div className="absolute bottom-0 left-0 w-full right-0 px-5 pb-8 pt-4 bg-white dark:bg-gray-950 border-t border-gray-100 dark:border-gray-800 flex gap-3">
                <button
                    onClick={handleEditClick}
                    className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm transition-colors shadow-lg shadow-blue-500/25"
                >
                    <PencilSquareIcon className="w-4 h-4" />
                    {t('calendar.edit')}
                </button>
                <button
                    onClick={() => onDelete(event)}
                    className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/40 active:bg-red-200 text-red-600 dark:text-red-400 font-semibold text-sm transition-colors border border-red-200 dark:border-red-800"
                >
                    <TrashIcon className="w-4 h-4" />
                    {t('calendar.delete')}
                </button>
            </div>

            <UpdateConfirmModal
                isOpen={isUpdateModalOpen}
                onClose={() => setIsUpdateModalOpen(false)}
                onSkip={handleSkipUpdateAction}
                event={event}
            />
        </div>
    );
}

export default MobileEventDetails;
