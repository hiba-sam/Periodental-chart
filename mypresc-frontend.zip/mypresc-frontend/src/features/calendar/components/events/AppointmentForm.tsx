// AppointmentForm - Patient appointment form
'use client';

import React from 'react';
import { UserIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import { PatientSearchField } from './PatientSearchField';
import { EventFormFields } from './EventFormFields';
import type { EventFormData, PreselectedPatient } from './useEventForm';
import type { ApiPatient } from '@/contexts/PatientsContext';

interface AppointmentFormProps {
    formData: EventFormData;
    errors: Record<string, string>;
    timeOptions: { value: string; label: string }[];
    durationOptions: { value: number; label: string }[];
    patientSearch: string;
    serverResults: ApiPatient[] | null;
    showPatientDropdown: boolean;
    preselectedPatient: PreselectedPatient | null;
    isEditMode: boolean;
    hideDateInput?: boolean;
    onInputChange: (field: keyof EventFormData, value: unknown) => void;
    onPatientSearchChange: (query: string) => void;
    onPatientSearchFocus: () => void;
    onPatientSelect: (patient: ApiPatient) => void;
    onPatientClear: () => void;
    onBack: () => void;
}

/**
 * Patient appointment form
 */
export function AppointmentForm({
    formData,
    errors,
    timeOptions,
    durationOptions,
    patientSearch,
    serverResults,
    showPatientDropdown,
    preselectedPatient,
    isEditMode,
    hideDateInput = false,
    onInputChange,
    onPatientSearchChange,
    onPatientSearchFocus,
    onPatientSelect,
    onPatientClear,
    onBack,
}: AppointmentFormProps) {
    const { t } = useLanguage();

    return (
        <>
            {/* Preselected Patient Indicator */}
            {preselectedPatient && !isEditMode && (
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-l-4 border-blue-500 rounded-lg p-4 flex items-start gap-3 shadow-sm">
                    <div className="flex-shrink-0 w-10 h-10 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center">
                        <UserIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div className="flex-1">
                        <p className="text-xs font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wide mb-1">
                            {t('calendar.patientSelected')}
                        </p>
                        <p className="text-base font-bold text-gray-900 dark:text-gray-100">
                            {preselectedPatient.name} {preselectedPatient.familyName}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                            {t('calendar.appointmentWillBeCreated')}
                        </p>
                    </div>
                </div>
            )}

            {/* Back button for type selection */}
            {!isEditMode && !preselectedPatient && (
                <button
                    type="button"
                    onClick={onBack}
                    className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                    {t('calendar.changeType')}
                </button>
            )}

            {/* Patient Selection */}
            <PatientSearchField
                patientId={formData.patientId}
                patientName={formData.patient_name}
                patientFamilyName={formData.patient_family_name}
                searchValue={patientSearch}
                searchResults={serverResults}
                showDropdown={showPatientDropdown}
                error={errors.patientId}
                onSearchChange={onPatientSearchChange}
                onSearchFocus={onPatientSearchFocus}
                onSelect={onPatientSelect}
                onClear={onPatientClear}
            />

            {/* Confirmed Coming Checkbox */}
            <div className="flex items-center gap-2">
                <input
                    type="checkbox"
                    id="confirmedComing"
                    checked={formData.confirmedComing}
                    onChange={(e) => onInputChange('confirmedComing', e.target.checked)}
                    className="w-4 h-4 text-blue-600 border-gray-300 dark:border-gray-600 rounded focus:ring-blue-500 dark:bg-gray-700"
                />
                <label htmlFor="confirmedComing" className="text-sm text-gray-700 dark:text-gray-300">
                    {t('calendar.confirmed')}
                </label>
            </div>

            {/* Common form fields */}
            <EventFormFields
                formData={formData}
                errors={errors}
                timeOptions={timeOptions}
                durationOptions={durationOptions}
                eventType="patient"
                hideDateInput={hideDateInput}
                onChange={onInputChange}
            />
        </>
    );
}

export default AppointmentForm;
