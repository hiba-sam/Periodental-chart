// StandaloneEventForm - Free event form
'use client';

import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { EventFormFields } from './EventFormFields';
import type { EventFormData } from './useEventForm';

interface StandaloneEventFormProps {
    formData: EventFormData;
    errors: Record<string, string>;
    timeOptions: { value: string; label: string }[];
    durationOptions: { value: number; label: string }[];
    isEditMode: boolean;
    hideDateInput?: boolean;
    onInputChange: (field: keyof EventFormData, value: unknown) => void;
    onBack: () => void;
}

/**
 * Standalone (free) event form
 */
export function StandaloneEventForm({
    formData,
    errors,
    timeOptions,
    durationOptions,
    isEditMode,
    hideDateInput = false,
    onInputChange,
    onBack,
}: StandaloneEventFormProps) {
    const { t } = useLanguage();

    return (
        <>
            {/* Back button for type selection */}
            {!isEditMode && (
                <button
                    type="button"
                    onClick={onBack}
                    className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                    {t('calendar.changeType')}
                </button>
            )}

            {/* Title */}
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    {t('calendar.title')} <span className="text-red-500">*</span>
                </label>
                <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => onInputChange('title', e.target.value)}
                    placeholder={t('calendar.titlePlaceholder')}
                    className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
            </div>

            {/* Common form fields */}
            <EventFormFields
                formData={formData}
                errors={errors}
                timeOptions={timeOptions}
                durationOptions={durationOptions}
                eventType="free"
                hideDateInput={hideDateInput}
                onChange={onInputChange}
            />
        </>
    );
}

export default StandaloneEventForm;
