// MobileEventEditForm — Edit form for MobileFullModal
// Renders the same form content as EventFormContainer but WITHOUT the desktop
// Modal wrapper, so it can sit naturally inside MobileFullModal.
'use client';

import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { type CalendarEvent } from '@/contexts/CalendarContext';
import { useEventForm, type PreselectedPatient } from './useEventForm';
import { AppointmentForm } from './AppointmentForm';
import { StandaloneEventForm } from './StandaloneEventForm';

interface MobileEventEditFormProps {
    /** The event to edit (required — this form is edit-only on mobile) */
    editEvent: CalendarEvent;
    /** Called on cancel or after a successful update */
    onClose: (wasSuccessful?: boolean) => void;
    preselectedPatient?: PreselectedPatient | null;
}

/**
 * Mobile-native edit form — renders AppointmentForm / StandaloneEventForm
 * directly (no Modal shell) so it fills MobileFullModal naturally.
 */
export function MobileEventEditForm({
    editEvent,
    onClose,
    preselectedPatient = null,
}: MobileEventEditFormProps) {
    const { t } = useLanguage();

    const form = useEventForm({
        isOpen: true,
        editEvent,
        preselectedPatient,
        preselectedEventType: null,
        onSuccess: (wasCreation) => onClose(wasCreation),
    });

    return (
        <div className="flex flex-col pb-8">
            <form onSubmit={form.handleSubmit} className="space-y-5 px-4 pt-4">

                {/* Form fields — AppointmentForm or StandaloneEventForm */}
                {form.eventType === 'patient' ? (
                    <AppointmentForm
                        formData={form.formData}
                        errors={form.errors}
                        timeOptions={form.timeOptions}
                        durationOptions={form.durationOptions}
                        patientSearch={form.patientSearch}
                        serverResults={form.serverResults}
                        showPatientDropdown={form.showPatientDropdown}
                        preselectedPatient={preselectedPatient}
                        isEditMode={form.isEditMode}
                        hideDateInput={false}
                        onInputChange={form.handleInputChange}
                        onPatientSearchChange={(query) => {
                            form.setPatientSearch(query);
                            form.setShowPatientDropdown(true);
                        }}
                        onPatientSearchFocus={() => form.setShowPatientDropdown(true)}
                        onPatientSelect={form.handlePatientSelect}
                        onPatientClear={form.handlePatientClear}
                        onBack={() => onClose(false)}
                    />
                ) : (
                    <StandaloneEventForm
                        formData={form.formData}
                        errors={form.errors}
                        timeOptions={form.timeOptions}
                        durationOptions={form.durationOptions}
                        isEditMode={form.isEditMode}
                        hideDateInput={false}
                        onInputChange={form.handleInputChange}
                        onBack={() => onClose(false)}
                    />
                )}

                {/* ── Action buttons ─────────────────────────────────── */}
                <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <button
                        type="button"
                        onClick={() => onClose(false)}
                        disabled={form.isSubmitting || form.isLoading}
                        className="flex-1 py-3 rounded-2xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 font-semibold text-sm hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                    >
                        {t('calendar.cancel')}
                    </button>
                    <button
                        type="submit"
                        disabled={form.isSubmitting || form.isLoading}
                        className="flex-1 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold text-sm transition-colors shadow-lg shadow-blue-500/25 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {form.isSubmitting || form.isLoading
                            ? t('calendar.loading')
                            : t('calendar.update')}
                    </button>
                </div>
            </form>
        </div>
    );
}

export default MobileEventEditForm;
