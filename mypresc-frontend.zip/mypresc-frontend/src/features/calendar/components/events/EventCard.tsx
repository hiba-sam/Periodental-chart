// EventCard - Compact event display card
'use client';

import React from 'react';
import { ClockIcon, UserIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon } from '@heroicons/react/24/solid';
import type { CalendarEvent } from '../../types';

interface EventCardProps {
    event: CalendarEvent;
    onClick?: () => void;
    compact?: boolean;
    showTime?: boolean;
    className?: string;
}

/**
 * Compact event card for calendar display
 */
export function EventCard({
    event,
    onClick,
    compact = false,
    showTime = true,
    className = ''
}: EventCardProps) {
    const backgroundColor = `${event.color}20`;
    const borderColor = event.color;
    const textColor = event.color;

    return (
        <div
            onClick={onClick}
            className={`
                rounded-md border-l-3 cursor-pointer transition-all
                hover:shadow-md hover:scale-[1.02]
                ${compact ? 'p-1.5' : 'p-2'}
                ${className}
            `}
            style={{
                backgroundColor,
                borderLeftColor: borderColor,
                borderLeftWidth: '3px',
            }}
        >
            {/* Title */}
            <p
                className={`font-medium text-gray-900 dark:text-gray-100 truncate ${compact ? 'text-xs' : 'text-sm'}`}
                style={{ color: textColor }}
            >
                {event.title}
            </p>

            {/* Time and Status */}
            {showTime && !compact && (
                <div className="flex items-center gap-2 mt-1">
                    <ClockIcon className="w-3.5 h-3.5 text-gray-500 dark:text-gray-400" />
                    <span className="text-xs text-gray-600 dark:text-gray-400">
                        {event.time} ({event.duration}min)
                    </span>
                </div>
            )}

            {/* Patient indicator */}
            {event.isAppointmentLinked && !compact && (
                <div className="flex items-center gap-1.5 mt-1">
                    <UserIcon className="w-3.5 h-3.5 text-blue-500" />
                    {event.venueConfirmed && (
                        <CheckCircleIcon className="w-3.5 h-3.5 text-green-500" />
                    )}
                    {event.isDone && (
                        <CheckCircleIcon className="w-3.5 h-3.5 text-blue-500" />
                    )}
                </div>
            )}

            {/* Compact time display */}
            {showTime && compact && (
                <span className="text-[10px] text-gray-500 dark:text-gray-400">
                    {event.time}
                </span>
            )}
        </div>
    );
}

export default EventCard;
