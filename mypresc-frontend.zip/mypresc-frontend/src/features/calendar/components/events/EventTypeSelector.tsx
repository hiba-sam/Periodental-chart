// EventTypeSelector - Type selection screen for new events
'use client';

import React from 'react';
import { UserIcon, CalendarIcon } from '@heroicons/react/24/outline';
import { useLanguage } from '@/contexts/LanguageContext';
import Modal from '@/components/ui/Modal';
import type { EventType } from './useEventForm';

interface EventTypeSelectorProps {
    isOpen: boolean;
    onClose: () => void;
    onSelect: (type: EventType) => void;
}

/**
 * Type selection screen for new events
 */
export function EventTypeSelector({ isOpen, onClose, onSelect }: EventTypeSelectorProps) {
    const { t } = useLanguage();

    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={t('calendar.newAppointment')}
            closeOnBackdrop={false}
        >
            <div className="space-y-4 py-6">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                    {t('calendar.whatTypeQuestion')}
                </p>

                {/* Patient Appointment Option */}
                <button
                    onClick={() => onSelect('patient')}
                    className="
                        w-full p-6 border-2 border-gray-200 dark:border-gray-700 rounded-lg
                        hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all
                        text-left group
                    "
                >
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 bg-blue-100 dark:bg-blue-900/40 rounded-lg flex items-center justify-center group-hover:bg-blue-200 dark:group-hover:bg-blue-900/60 transition-colors">
                            <UserIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div className="flex-1">
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                                {t('calendar.patientAppointment')}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                                {t('calendar.patientAppointmentDesc')}
                            </p>
                        </div>
                    </div>
                </button>

                {/* Free Event Option */}
                <button
                    onClick={() => onSelect('free')}
                    className="
                        w-full p-6 border-2 border-gray-200 dark:border-gray-700 rounded-lg
                        hover:border-green-500 hover:bg-green-50 dark:hover:bg-green-900/20 transition-all
                        text-left group
                    "
                >
                    <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 bg-green-100 dark:bg-green-900/40 rounded-lg flex items-center justify-center group-hover:bg-green-200 dark:group-hover:bg-green-900/60 transition-colors">
                            <CalendarIcon className="w-6 h-6 text-green-600 dark:text-green-400" />
                        </div>
                        <div className="flex-1">
                            <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-1">
                                {t('calendar.freeEvent')}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                                {t('calendar.freeEventDesc')}
                            </p>
                        </div>
                    </div>
                </button>
            </div>
        </Modal>
    );
}

export default EventTypeSelector;
