// EventDetails - Event details panel with status toggles
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { UserIcon, PhoneIcon, ClockIcon, CalendarIcon, DocumentTextIcon } from '@heroicons/react/24/outline';
import { CheckCircleIcon, XCircleIcon } from '@heroicons/react/24/solid';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePatients } from '@/contexts/PatientsContext';
import { ApiPatient } from '@/types/patient';

interface EventDetailsProps {
    event: CalendarEvent;
    onEdit: (event: CalendarEvent) => void;
    onDelete: (event: CalendarEvent) => void;
}

/**
 * Event details panel with status toggles
 */
export function EventDetails({ event, onEdit, onDelete }: EventDetailsProps) {
    const { updateEvent, updateEventOptimistic } = useCalendar();
    const { t, language } = useLanguage();
    const { getPatient } = usePatients();
    const [isUpdatingConfirmed, setIsUpdatingConfirmed] = useState(false);
    const [isUpdatingDone, setIsUpdatingDone] = useState(false);

    const [patientData, setPatientData] = useState<ApiPatient | null>(null);
    const [isLoadingPatient, setIsLoadingPatient] = useState(false);

    // Local state for instant UI feedback (optimistic updates)
    const [localConfirmed, setLocalConfirmed] = useState(event.venueConfirmed);
    const [localDone, setLocalDone] = useState(event.isDone);

    // Sync local state when event prop changes
    useEffect(() => {
        setLocalConfirmed(event.venueConfirmed);
        setLocalDone(event.isDone);
    }, [event.venueConfirmed, event.isDone, event.id]);

    // Fetch patient data if phone is missing
    useEffect(() => {
        const loadPatient = async () => {
            if (event.isAppointmentLinked && event.patientId && !event.patientPhone) {
                setIsLoadingPatient(true);
                try {
                    const p = await getPatient(event.patientId.toString());
                    if (p) {
                        setPatientData(p);
                    }
                } catch (error) {
                    console.error("Error fetching patient details:", error);
                } finally {
                    setIsLoadingPatient(false);
                }
            }
        };

        loadPatient();
    }, [event.patientId, event.isAppointmentLinked, event.patientPhone, getPatient]);

    // Format helpers
    const formatDate = (date: Date): string => {
        const locale = language === 'ar' ? 'ar-DZ' : language === 'fr' ? 'fr-FR' : 'en-US';
        return date.toLocaleDateString(locale, {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
        });
    };

    const formatTime = (time: string): string => time;

    // Event handlers
    const handleToggleConfirmed = async () => {
        const newValue = !localConfirmed;
        setLocalConfirmed(newValue);
        setIsUpdatingConfirmed(true);
        updateEventOptimistic(event.id, { venueConfirmed: newValue });

        try {
            await updateEvent({ id: event.id, venue_confirmed: newValue }, true);
        } catch {
            setLocalConfirmed(!newValue);
            updateEventOptimistic(event.id, { venueConfirmed: !newValue });
        } finally {
            setIsUpdatingConfirmed(false);
        }
    };

    const handleToggleDone = async () => {
        const newValue = !localDone;
        setLocalDone(newValue);
        setIsUpdatingDone(true);
        updateEventOptimistic(event.id, { isDone: newValue });

        try {
            await updateEvent({ id: event.id, is_done: newValue }, true);
        } catch {
            setLocalDone(!newValue);
            updateEventOptimistic(event.id, { isDone: !newValue });
        } finally {
            setIsUpdatingDone(false);
        }
    };

    // Styling
    const borderColor = event.color;
    const backgroundColor = `${event.color}15`;
    const displayPhone = event.patientPhone || patientData?.telephone;

    return (
        <div className="event-details-panel bg-white dark:bg-gray-800 rounded-lg shadow-md border-s-4" style={{ borderInlineStartColor: borderColor }}>
            {/* Header */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700 transition-colors" style={{ backgroundColor }}>
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-1">
                    {event.isAppointmentLinked ? t('calendar.eventDetails') : t('calendar.eventTitle')}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-200">
                    {formatDate(event.date)} à {formatTime(event.time)}
                </p>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4">
                {/* Patient Information */}
                {event.isAppointmentLinked && (
                    <div className="space-y-3">
                        <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">{t('calendar.patient')}</h4>
                        <div className="flex items-start gap-3">
                            <UserIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
                            <div>
                                {event.patientId ? (
                                    <Link href={`/patients/${event.patientId}`}>
                                        <p className="text-base font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 hover:underline">{event.title}</p>
                                    </Link>
                                ) : (
                                    <p className="text-base font-medium text-gray-900 dark:text-gray-100">{event.title}</p>
                                )}
                                {event.patientAge && (
                                    <p className="text-sm text-gray-500 dark:text-gray-400">{event.patientAge} {t('calendar.years')}</p>
                                )}
                            </div>
                        </div>
                        {displayPhone && (
                            <div className="flex items-center gap-3">
                                <PhoneIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                                <a href={`tel:${displayPhone}`} className="text-sm text-blue-600 dark:text-blue-400 hover:underline">
                                    {displayPhone}
                                </a>
                            </div>
                        )}
                    </div>
                )}

                {/* Event Title for free events */}
                {!event.isAppointmentLinked && (
                    <div className="space-y-3">
                        <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">{t('calendar.event')}</h4>
                        <div className="flex items-start gap-3">
                            <CalendarIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
                            <p className="text-base font-medium text-gray-900 dark:text-gray-100">{event.title}</p>
                        </div>
                    </div>
                )}

                {/* Date and Time */}
                <div className={`space-y-3 ${event.isAppointmentLinked ? 'pt-4 border-t border-gray-200 dark:border-gray-700' : ''}`}>
                    <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide">
                        {event.isAppointmentLinked ? t('calendar.appointment') : t('calendar.schedule')}
                    </h4>
                    <div className="flex items-center gap-3">
                        <CalendarIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                        <p className="text-sm text-gray-700 dark:text-gray-300">{formatDate(event.date)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                        <ClockIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                        <p className="text-sm text-gray-700 dark:text-gray-300">
                            {formatTime(event.time)} - {formatTime(event.endTime || '')} ({event.duration} {t('calendar.min')})
                        </p>
                    </div>
                    {event.description && (
                        <div className="flex items-start gap-3">
                            <DocumentTextIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 mt-0.5 flex-shrink-0" />
                            <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{event.description}</p>
                        </div>
                    )}
                </div>

                {/* Status Toggles */}
                {event.isAppointmentLinked && (
                    <div className="space-y-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 uppercase tracking-wide mb-3">{t('calendar.status')}</h4>

                        <button
                            onClick={handleToggleConfirmed}
                            disabled={isUpdatingConfirmed}
                            className={`w-full flex items-center gap-3 p-3 rounded-md border-2 transition-all ${localConfirmed
                                ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 hover:bg-green-100'
                                : 'bg-gray-50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 hover:bg-gray-100'
                                } disabled:opacity-50`}
                        >
                            {localConfirmed ? (
                                <CheckCircleIcon className="w-5 h-5 text-green-600 dark:text-green-500 flex-shrink-0" />
                            ) : (
                                <XCircleIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                            )}
                            <span className={`text-sm font-medium ${localConfirmed ? 'text-green-700 dark:text-green-400' : 'text-gray-600 dark:text-gray-300'}`}>
                                {localConfirmed ? t('calendar.confirmed') : t('calendar.notConfirmed')}
                            </span>
                        </button>

                        <button
                            onClick={handleToggleDone}
                            disabled={isUpdatingDone}
                            className={`w-full flex items-center gap-3 p-3 rounded-md border-2 transition-all ${localDone
                                ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 hover:bg-blue-100'
                                : 'bg-gray-50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 hover:bg-gray-100'
                                } disabled:opacity-50`}
                        >
                            {localDone ? (
                                <CheckCircleIcon className="w-5 h-5 text-blue-600 dark:text-blue-500 flex-shrink-0" />
                            ) : (
                                <XCircleIcon className="w-5 h-5 text-gray-400 dark:text-gray-500 flex-shrink-0" />
                            )}
                            <span className={`text-sm font-medium ${localDone ? 'text-blue-700 dark:text-blue-400' : 'text-gray-600 dark:text-gray-300'}`}>
                                {localDone ? t('calendar.completed') : t('calendar.pending')}
                            </span>
                        </button>
                    </div>
                )}
            </div>

            {/* Action Buttons */}
            <div className="p-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 flex gap-3">
                <button
                    onClick={() => onEdit(event)}
                    className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium text-sm"
                >
                    {t('calendar.edit')}
                </button>
                <button
                    onClick={() => onDelete(event)}
                    className="flex-1 px-4 py-2 bg-white dark:bg-gray-800 text-red-600 dark:text-red-400 border-2 border-red-600 dark:border-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors font-medium text-sm"
                >
                    {t('calendar.delete')}
                </button>
            </div>
        </div>
    );
}

export default EventDetails;
