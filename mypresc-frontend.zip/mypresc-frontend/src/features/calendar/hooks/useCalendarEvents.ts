// useCalendarEvents - React Query hook for calendar events with socket integration
'use client';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useCallback } from 'react';
import { fetchCalendarEvents, mapApiEventToCalendarEvent } from '../api';
import type { CalendarEvent, CalendarFilters, CalendarView } from '../types';
import { getWeekStart, getWeekEnd, getMonthStart, getMonthEnd, isSameDay } from '../utils';
import socketClient from '@/utils/socketClient';

/**
 * Query key factory for calendar events
 */
export const calendarKeys = {
    all: ['calendar'] as const,
    events: () => [...calendarKeys.all, 'events'] as const,
    eventsByRange: (start: Date, end: Date) =>
        [...calendarKeys.events(), start.toISOString(), end.toISOString()] as const,
};

interface UseCalendarEventsOptions {
    selectedDate: Date;
    view: CalendarView;
    enabled?: boolean;
}

/**
 * Hook to fetch calendar events with React Query
 * Includes socket integration for real-time updates
 */
export function useCalendarEvents(options: UseCalendarEventsOptions) {
    const { selectedDate, view, enabled = true } = options;
    const queryClient = useQueryClient();

    // Calculate date range based on view
    const getDateRange = useCallback(() => {
        let start: Date;
        let end: Date;

        switch (view) {
            case 'day':
                start = new Date(selectedDate);
                start.setHours(0, 0, 0, 0);
                end = new Date(selectedDate);
                end.setHours(23, 59, 59, 999);
                break;
            case 'week':
                start = getWeekStart(selectedDate);
                end = getWeekEnd(selectedDate);
                break;
            case 'month':
                start = getMonthStart(selectedDate);
                end = getMonthEnd(selectedDate);
                break;
            default:
                start = getWeekStart(selectedDate);
                end = getWeekEnd(selectedDate);
        }

        return { start, end };
    }, [selectedDate, view]);

    const { start, end } = getDateRange();

    // Query for events
    const query = useQuery({
        queryKey: calendarKeys.eventsByRange(start, end),
        queryFn: () => fetchCalendarEvents({ startDate: start, endDate: end }),
        enabled,
        staleTime: 1000 * 60 * 5, // 5 minutes
        refetchOnWindowFocus: true,
    });

    // Socket event handlers for real-time updates
    useEffect(() => {
        const handleEventCreated = (newEvent: unknown) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
        };

        const handleEventUpdated = (updatedEvent: unknown) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
        };

        const handleEventDeleted = (data: { id: string }) => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
        };

        const handleAppointmentChange = () => {
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
        };

        // Subscribe to socket events
        socketClient.on('calendarEventCreated', handleEventCreated);
        socketClient.on('calendarEventUpdated', handleEventUpdated);
        socketClient.on('calendarEventDeleted', handleEventDeleted);
        socketClient.on('appointmentUpdated', handleAppointmentChange);
        socketClient.on('appointmentCreated', handleAppointmentChange);

        return () => {
            socketClient.off('calendarEventCreated', handleEventCreated);
            socketClient.off('calendarEventUpdated', handleEventUpdated);
            socketClient.off('calendarEventDeleted', handleEventDeleted);
            socketClient.off('appointmentUpdated', handleAppointmentChange);
            socketClient.off('appointmentCreated', handleAppointmentChange);
        };
    }, [queryClient]);

    // Helper functions
    const getEventsForDate = useCallback((date: Date): CalendarEvent[] => {
        return (query.data || []).filter(event => isSameDay(event.date, date));
    }, [query.data]);

    const getEventAtDateTime = useCallback((date: Date, time: string): CalendarEvent | null => {
        const dayEvents = getEventsForDate(date);
        return dayEvents.find(e => e.time === time) || null;
    }, [getEventsForDate]);

    const refreshEvents = useCallback(() => {
        return queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
    }, [queryClient]);

    return {
        events: query.data || [],
        isLoading: query.isLoading,
        error: query.error,
        refetch: query.refetch,
        getEventsForDate,
        getEventAtDateTime,
        refreshEvents,
    };
}

export default useCalendarEvents;
