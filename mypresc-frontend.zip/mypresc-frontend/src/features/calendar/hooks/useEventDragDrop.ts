// useEventDragDrop - Hook for drag-drop event rescheduling
'use client';

import { useState, useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import type { CalendarEvent, DragDropData } from '../types';
import { calendarKeys } from './useCalendarEvents';
import { updateCalendarEvent } from '../api';
import { isSameDay, doTimesOverlap, snapToSlot } from '../utils';

interface UseEventDragDropOptions {
    events: CalendarEvent[];
    onError?: (error: Error) => void;
    onSuccess?: (event: CalendarEvent) => void;
}

/**
 * Hook for drag-drop event rescheduling with optimistic updates
 */
export function useEventDragDrop(options: UseEventDragDropOptions) {
    const { events, onError, onSuccess } = options;
    const queryClient = useQueryClient();

    const [isDragging, setIsDragging] = useState(false);
    const [draggedEvent, setDraggedEvent] = useState<CalendarEvent | null>(null);
    const [dragData, setDragData] = useState<DragDropData | null>(null);

    // Start dragging an event
    const startDrag = useCallback((event: CalendarEvent) => {
        setIsDragging(true);
        setDraggedEvent(event);
        setDragData({
            eventId: event.id,
            originalDate: event.date,
            originalTime: event.time,
            newDate: event.date,
            newTime: event.time,
        });
    }, []);

    // Update drag position
    const updateDrag = useCallback((newDate: Date, newTime: string) => {
        if (!dragData) return;

        const snappedTime = snapToSlot(newTime);
        setDragData(prev => prev ? {
            ...prev,
            newDate,
            newTime: snappedTime,
        } : null);
    }, [dragData]);

    // Check for collision with other events
    const checkCollision = useCallback((
        date: Date,
        time: string,
        duration: number,
        excludeEventId?: string
    ): CalendarEvent | null => {
        const dayEvents = events.filter(e =>
            isSameDay(e.date, date) && e.id !== excludeEventId
        );

        for (const event of dayEvents) {
            if (doTimesOverlap(time, duration, event.time, event.duration)) {
                return event;
            }
        }

        return null;
    }, [events]);

    // End dragging and apply changes
    const endDrag = useCallback(async () => {
        if (!dragData || !draggedEvent) {
            cancelDrag();
            return;
        }

        const { newDate, newTime, originalDate, originalTime } = dragData;

        // Check if position actually changed
        if (isSameDay(newDate, originalDate) && newTime === originalTime) {
            cancelDrag();
            return;
        }

        // Check for collisions
        const collision = checkCollision(newDate, newTime, draggedEvent.duration, draggedEvent.id);
        if (collision) {
            onError?.(new Error(`Conflit avec: ${collision.title || 'un autre événement'}`));
            cancelDrag();
            return;
        }

        // Optimistic update
        const previousEvents = queryClient.getQueryData<CalendarEvent[]>(calendarKeys.events());

        queryClient.setQueriesData<CalendarEvent[]>(
            { queryKey: calendarKeys.events() },
            (old) => old?.map(e =>
                e.id === draggedEvent.id
                    ? { ...e, date: newDate, time: newTime }
                    : e
            )
        );

        setIsDragging(false);
        setDraggedEvent(null);
        setDragData(null);

        try {
            // API update
            const updatedEvent = await updateCalendarEvent({
                id: draggedEvent.id,
                date: newDate,
                time: newTime,
            });

            onSuccess?.(updatedEvent);
            queryClient.invalidateQueries({ queryKey: calendarKeys.events() });
        } catch (error) {
            // Rollback on error
            if (previousEvents) {
                queryClient.setQueriesData(
                    { queryKey: calendarKeys.events() },
                    previousEvents
                );
            }
            onError?.(error instanceof Error ? error : new Error('Failed to update event'));
        }
    }, [dragData, draggedEvent, checkCollision, queryClient, onError, onSuccess]);

    // Cancel dragging
    const cancelDrag = useCallback(() => {
        setIsDragging(false);
        setDraggedEvent(null);
        setDragData(null);
    }, []);

    // Get preview position for dragged event
    const getPreviewPosition = useCallback(() => {
        if (!dragData) return null;
        return {
            date: dragData.newDate,
            time: dragData.newTime,
        };
    }, [dragData]);

    return {
        // State
        isDragging,
        draggedEvent,
        dragData,

        // Actions
        startDrag,
        updateDrag,
        endDrag,
        cancelDrag,

        // Utilities
        checkCollision,
        getPreviewPosition,
    };
}

export default useEventDragDrop;
