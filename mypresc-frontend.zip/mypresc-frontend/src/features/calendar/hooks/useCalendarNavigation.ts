// useCalendarNavigation - Hook for date and view navigation
'use client';

import { useState, useCallback, useMemo } from 'react';
import type { CalendarView, WeekDay } from '../types';
import {
    getWeekStart,
    addDays,
    addWeeks,
    addMonths,
    isToday as checkIsToday,
    isSameDay
} from '../utils';
import { buildWeekDays, getMonthYearDisplay, getWeekRangeDisplay } from '../utils';

interface UseCalendarNavigationOptions {
    initialDate?: Date;
    initialView?: CalendarView;
}

/**
 * Hook for calendar date/view navigation
 */
export function useCalendarNavigation(options: UseCalendarNavigationOptions = {}) {
    const { initialDate = new Date(), initialView = 'week' } = options;

    const [selectedDate, setSelectedDate] = useState<Date>(initialDate);
    const [calendarView, setCalendarView] = useState<CalendarView>(initialView);

    // Navigate to today
    const goToToday = useCallback(() => {
        setSelectedDate(new Date());
    }, []);

    // Navigate to previous period
    const goPrevious = useCallback(() => {
        setSelectedDate(prev => {
            switch (calendarView) {
                case 'day':
                    return addDays(prev, -1);
                case 'week':
                    return addWeeks(prev, -1);
                case 'month':
                    return addMonths(prev, -1);
                default:
                    return prev;
            }
        });
    }, [calendarView]);

    // Navigate to next period
    const goNext = useCallback(() => {
        setSelectedDate(prev => {
            switch (calendarView) {
                case 'day':
                    return addDays(prev, 1);
                case 'week':
                    return addWeeks(prev, 1);
                case 'month':
                    return addMonths(prev, 1);
                default:
                    return prev;
            }
        });
    }, [calendarView]);

    // Get week start for current selection
    const weekStart = useMemo(() => getWeekStart(selectedDate), [selectedDate]);

    // Get week days for header
    const weekDays = useMemo((): WeekDay[] => {
        return buildWeekDays(weekStart, selectedDate);
    }, [weekStart, selectedDate]);

    // Get display title based on view
    const displayTitle = useMemo(() => {
        switch (calendarView) {
            case 'day':
                return selectedDate.toLocaleDateString('fr-FR', {
                    weekday: 'long',
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                });
            case 'week':
                return getWeekRangeDisplay(weekStart);
            case 'month':
                return getMonthYearDisplay(selectedDate);
            default:
                return '';
        }
    }, [calendarView, selectedDate, weekStart]);

    // Check if selected date is today
    const isToday = useMemo(() => checkIsToday(selectedDate), [selectedDate]);

    // Select a specific date
    const selectDate = useCallback((date: Date) => {
        setSelectedDate(date);
    }, []);

    // Switch calendar view
    const switchView = useCallback((view: CalendarView) => {
        setCalendarView(view);
    }, []);

    return {
        // State
        selectedDate,
        calendarView,
        weekStart,
        weekDays,
        displayTitle,
        isToday,

        // Actions
        setSelectedDate: selectDate,
        setCalendarView: switchView,
        goToToday,
        goPrevious,
        goNext,
    };
}

export default useCalendarNavigation;
