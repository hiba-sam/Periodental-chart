// Calendar Date Calculations - Date manipulation utilities

/**
 * Get the start of the week (Monday) for a given date
 */
export function getWeekStart(date: Date): Date {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust for Monday start
    d.setDate(diff);
    d.setHours(0, 0, 0, 0);
    return d;
}

/**
 * Get the end of the week (Sunday) for a given date
 */
export function getWeekEnd(date: Date): Date {
    const start = getWeekStart(date);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    end.setHours(23, 59, 59, 999);
    return end;
}

/**
 * Get the start of the month for a given date
 */
export function getMonthStart(date: Date): Date {
    return new Date(date.getFullYear(), date.getMonth(), 1);
}

/**
 * Get the end of the month for a given date
 */
export function getMonthEnd(date: Date): Date {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59, 999);
}

/**
 * Check if two dates are the same day
 */
export function isSameDay(date1: Date, date2: Date): boolean {
    return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    );
}

/**
 * Check if two dates are in the same week
 */
export function isSameWeek(date1: Date, date2: Date): boolean {
    const week1Start = getWeekStart(date1);
    const week2Start = getWeekStart(date2);
    return isSameDay(week1Start, week2Start);
}

/**
 * Check if a date is today
 */
export function isToday(date: Date): boolean {
    return isSameDay(date, new Date());
}

/**
 * Check if a date is in the past
 */
export function isPast(date: Date): boolean {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
}

/**
 * Check if a date is in the future
 */
export function isFuture(date: Date): boolean {
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    return date > today;
}

/**
 * Add days to a date
 */
export function addDays(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

/**
 * Add weeks to a date
 */
export function addWeeks(date: Date, weeks: number): Date {
    return addDays(date, weeks * 7);
}

/**
 * Add months to a date
 */
export function addMonths(date: Date, months: number): Date {
    const result = new Date(date);
    result.setMonth(result.getMonth() + months);
    return result;
}

/**
 * Get array of week days starting from a date
 */
export function getWeekDays(weekStart: Date, selectedDate: Date): Date[] {
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
        days.push(addDays(weekStart, i));
    }
    return days;
}

/**
 * Get the number of days in a month
 */
export function getDaysInMonth(date: Date): number {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
}

/**
 * Get calendar grid for a month (includes days from prev/next months)
 */
export function getMonthCalendarGrid(date: Date): Date[] {
    const monthStart = getMonthStart(date);
    const monthEnd = getMonthEnd(date);
    const startDay = monthStart.getDay();

    // Adjust for Monday start (0 = Sunday in JS)
    const daysFromPrevMonth = startDay === 0 ? 6 : startDay - 1;

    const grid: Date[] = [];

    // Add days from previous month
    for (let i = daysFromPrevMonth; i > 0; i--) {
        grid.push(addDays(monthStart, -i));
    }

    // Add days of current month
    const daysInMonth = getDaysInMonth(date);
    for (let i = 0; i < daysInMonth; i++) {
        grid.push(addDays(monthStart, i));
    }

    // Add days from next month to complete the grid (6 rows x 7 days)
    const remaining = 42 - grid.length;
    for (let i = 1; i <= remaining; i++) {
        grid.push(addDays(monthEnd, i));
    }

    return grid;
}
