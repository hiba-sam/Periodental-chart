// Time Slot Generator - Generate time slots for calendar grid

import type { TimeSlot } from '../types';

/**
 * Default working hours configuration
 */
export const DEFAULT_START_HOUR = 8;  // 08:00
export const DEFAULT_END_HOUR = 18;   // 18:00
export const DEFAULT_SLOT_MINUTES = 30;

/**
 * Generate time slots for a day
 * @param startHour - Start hour (0-23)
 * @param endHour - End hour (0-23)
 * @param slotMinutes - Minutes per slot (default 30)
 */
export function generateTimeSlots(
    startHour: number = DEFAULT_START_HOUR,
    endHour: number = DEFAULT_END_HOUR,
    slotMinutes: number = DEFAULT_SLOT_MINUTES
): TimeSlot[] {
    const slots: TimeSlot[] = [];

    for (let hour = startHour; hour < endHour; hour++) {
        for (let minute = 0; minute < 60; minute += slotMinutes) {
            const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
            slots.push({
                time,
                label: time,
                isHour: minute === 0,
            });
        }
    }

    return slots;
}

/**
 * Calculate slot position (top offset in pixels)
 * @param time - Time string in HH:mm format
 * @param startHour - Start hour of the calendar
 * @param slotHeight - Height of each slot in pixels
 * @param slotMinutes - Minutes per slot
 */
export function calculateSlotPosition(
    time: string,
    startHour: number = DEFAULT_START_HOUR,
    slotHeight: number = 40,
    slotMinutes: number = DEFAULT_SLOT_MINUTES
): number {
    const [hours, minutes] = time.split(':').map(Number);
    const totalMinutes = (hours! - startHour) * 60 + minutes!;
    return (totalMinutes / slotMinutes) * slotHeight;
}

/**
 * Calculate event height based on duration
 * @param duration - Duration in minutes
 * @param slotHeight - Height of each slot in pixels
 * @param slotMinutes - Minutes per slot
 */
export function calculateEventHeight(
    duration: number,
    slotHeight: number = 40,
    slotMinutes: number = DEFAULT_SLOT_MINUTES
): number {
    return (duration / slotMinutes) * slotHeight;
}

/**
 * Get time from slot position (reverse of calculateSlotPosition)
 * @param position - Y position in pixels
 * @param startHour - Start hour of the calendar
 * @param slotHeight - Height of each slot in pixels
 * @param slotMinutes - Minutes per slot
 */
export function getTimeFromPosition(
    position: number,
    startHour: number = DEFAULT_START_HOUR,
    slotHeight: number = 40,
    slotMinutes: number = DEFAULT_SLOT_MINUTES
): string {
    const totalSlots = Math.floor(position / slotHeight);
    const totalMinutes = startHour * 60 + totalSlots * slotMinutes;

    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
}

/**
 * Snap time to nearest slot
 * @param time - Time string in HH:mm format
 * @param slotMinutes - Minutes per slot
 */
export function snapToSlot(time: string, slotMinutes: number = DEFAULT_SLOT_MINUTES): string {
    const [hours, minutes] = time.split(':').map(Number);
    const snappedMinutes = Math.round(minutes! / slotMinutes) * slotMinutes;

    let finalHours = hours;
    let finalMinutes = snappedMinutes;

    if (snappedMinutes >= 60) {
        finalHours! += 1;
        finalMinutes = 0;
    }

    return `${finalHours!.toString().padStart(2, '0')}:${finalMinutes.toString().padStart(2, '0')}`;
}

/**
 * Check if two time ranges overlap
 */
export function doTimesOverlap(
    start1: string,
    duration1: number,
    start2: string,
    duration2: number
): boolean {
    const [h1, m1] = start1.split(':').map(Number);
    const [h2, m2] = start2.split(':').map(Number);

    const minutes1Start = h1! * 60 + m1!;
    const minutes1End = minutes1Start + duration1;
    const minutes2Start = h2! * 60 + m2!;
    const minutes2End = minutes2Start + duration2;

    return minutes1Start < minutes2End && minutes2Start < minutes1End;
}
