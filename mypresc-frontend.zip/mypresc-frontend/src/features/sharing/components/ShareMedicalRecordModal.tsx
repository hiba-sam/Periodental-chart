'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/contexts/ProfileContext';
import { 
  XMarkIcon, 
  ShareIcon, 
  MagnifyingGlassIcon,
  UserCircleIcon,
  DocumentTextIcon,
  ClipboardDocumentListIcon,
  CalendarIcon,
  ClockIcon,
  CheckIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline';
import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

interface Doctor {
  id: number;
  name: string;
  family_name: string;
  email: string;
  speciality?: string;
  phone_number?: string;
  work_location?: string;
}

interface ShareMedicalRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
  patientName: string;
  onShareSuccess?: () => void;
}

type Step = 'select' | 'configure' | 'confirm';

export function ShareMedicalRecordModal({
  isOpen,
  onClose,
  patientId,
  patientName,
  onShareSuccess
}: ShareMedicalRecordModalProps) {
  const { user } = useAuth();
  const { profile } = useProfile();
  
  // Check if current user is a dentist (handles multiple specialities)
  const isDentist = profile?.speciality?.toLowerCase().includes('dentiste') || 
                    profile?.speciality?.toLowerCase().includes('dentaire') ||
                    profile?.speciality?.toLowerCase().includes('dental') ||
                    profile?.speciality?.toLowerCase().includes('orthodont') ||
                    profile?.speciality?.toLowerCase().includes('parodont') ||
                    profile?.speciality?.toLowerCase().includes('implanto') ||
                    profile?.speciality?.toLowerCase().includes('bucco-dentaire') ||
                    profile?.speciality?.toLowerCase().includes('stomatolog');
  
  // Step management
  const [currentStep, setCurrentStep] = useState<Step>('select');
  
  // Doctor search
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Doctor[]>([]);
  const [selectedDoctors, setSelectedDoctors] = useState<Doctor[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  
  // Share options
  const [sharePrescriptions, setSharePrescriptions] = useState(true);
  const [shareMedicalReports, setShareMedicalReports] = useState(true);
  const [shareDentalActs, setShareDentalActs] = useState(false);
  const [visibleUntilDate, setVisibleUntilDate] = useState<string>('');
  const [shareDuration, setShareDuration] = useState<string>('7'); // days
  const [shareReason, setShareReason] = useState<string>('');
  const [patientInformedConfirmed, setPatientInformedConfirmed] = useState(false);
  
  // Submission
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentStep('select');
      setSearchQuery('');
      setSearchResults([]);
      setSelectedDoctors([]);
      setSharePrescriptions(true);
      setShareMedicalReports(true);
      setShareDentalActs(isDentist!);
      setVisibleUntilDate('');
      setShareDuration('7');
      setShareReason('');
      setPatientInformedConfirmed(false);
      setError(null);
    }
  }, [isOpen, isDentist]);

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (searchQuery.length >= 2) {
        setIsSearching(true);
        try {
          const response = await axios.get(
            `${API_URL}/medical-shares/search-doctors`,
            { 
              params: { q: searchQuery },
              withCredentials: true 
            }
          );
          if (response.data.success) {
            setSearchResults(response.data.data);
          }
        } catch (err) {
          console.error('Error searching doctors:', err);
        } finally {
          setIsSearching(false);
        }
      } else {
        setSearchResults([]);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const toggleDoctorSelection = (doctor: Doctor) => {
    setSelectedDoctors(prev => {
      const exists = prev.find(d => d.id === doctor.id);
      if (exists) {
        return prev.filter(d => d.id !== doctor.id);
      }
      return [...prev, doctor];
    });
  };

  const handleSubmit = async () => {
    if (selectedDoctors.length === 0) {
      setError('Veuillez sélectionner au moins un médecin');
      return;
    }

    if (!sharePrescriptions && !shareMedicalReports && !shareDentalActs) {
      setError('Veuillez sélectionner au moins un type de document à partager');
      return;
    }

    if (!shareReason.trim()) {
      setError('Veuillez indiquer la raison du partage');
      return;
    }

    if (!patientInformedConfirmed) {
      setError('Veuillez confirmer que le patient a été informé du partage');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + parseInt(shareDuration));

      const response = await axios.post(
        `${API_URL}/medical-shares`,
        {
          patient_id: patientId,
          shared_with_doctor_ids: selectedDoctors.map(d => d.id),
          share_prescriptions: sharePrescriptions,
          share_medical_reports: shareMedicalReports,
          share_dental_acts: shareDentalActs,
          visible_until_date: visibleUntilDate || null,
          expires_at: expiresAt.toISOString(),
          reason: shareReason.trim()
        },
        { withCredentials: true }
      );

      if (response.data.success) {
        onShareSuccess?.();
        onClose();
      } else {
        setError(response.data.error || 'Erreur lors du partage');
      }
    } catch (err: any) {
      console.error('Error creating share:', err);
      setError(err.response?.data?.error || 'Erreur lors du partage');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between bg-gradient-to-r from-indigo-500 to-purple-600">
          <div className="flex items-center gap-3">
            <ShareIcon className="w-6 h-6 text-white" />
            <div>
              <h2 className="text-xl font-bold text-white">
                Partager le dossier médical
              </h2>
              <p className="text-sm text-indigo-100">
                Patient: {patientName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <XMarkIcon className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-3 bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-center gap-4">
            {[
              { key: 'select', label: '1. Médecins' },
              { key: 'configure', label: '2. Options' },
              { key: 'confirm', label: '3. Confirmer' }
            ].map((step, idx) => (
              <div key={step.key} className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  currentStep === step.key 
                    ? 'bg-indigo-600 text-white' 
                    : idx < ['select', 'configure', 'confirm'].indexOf(currentStep)
                      ? 'bg-green-500 text-white'
                      : 'bg-gray-300 dark:bg-gray-600 text-gray-600 dark:text-gray-300'
                }`}>
                  {idx < ['select', 'configure', 'confirm'].indexOf(currentStep) ? (
                    <CheckIcon className="w-4 h-4" />
                  ) : (
                    idx + 1
                  )}
                </div>
                <span className={`text-sm font-medium ${
                  currentStep === step.key 
                    ? 'text-indigo-600 dark:text-indigo-400' 
                    : 'text-gray-500 dark:text-gray-400'
                }`}>
                  {step.label}
                </span>
                {idx < 2 && (
                  <div className="w-8 h-0.5 bg-gray-300 dark:bg-gray-600 mx-2" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg flex items-center gap-2 text-red-700 dark:text-red-300">
              <ExclamationTriangleIcon className="w-5 h-5" />
              {error}
            </div>
          )}

          {/* Step 1: Select Doctors */}
          {currentStep === 'select' && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Rechercher un médecin
                </label>
                <div className="relative">
                  <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Nom, spécialité, email..."
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
              </div>

              {/* Search Results */}
              {searchQuery.length >= 2 && (
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg max-h-60 overflow-y-auto">
                  {isSearching ? (
                    <div className="p-4 text-center text-gray-500">Recherche...</div>
                  ) : searchResults.length === 0 ? (
                    <div className="p-4 text-center text-gray-500">Aucun médecin trouvé</div>
                  ) : (
                    searchResults.map(doctor => (
                      <button
                        key={doctor.id}
                        onClick={() => toggleDoctorSelection(doctor)}
                        className={`w-full p-3 flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors border-b border-gray-100 dark:border-gray-700 last:border-0 ${
                          selectedDoctors.find(d => d.id === doctor.id) 
                            ? 'bg-indigo-50 dark:bg-indigo-900/30' 
                            : ''
                        }`}
                      >
                        <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center">
                          <UserCircleIcon className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                        </div>
                        <div className="flex-1 text-left">
                          <p className="font-medium text-gray-900 dark:text-white">
                            Dr. {doctor.name} {doctor.family_name}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {doctor.speciality || 'Médecin'} • {doctor.email}
                          </p>
                        </div>
                        {selectedDoctors.find(d => d.id === doctor.id) && (
                          <CheckIcon className="w-5 h-5 text-indigo-600" />
                        )}
                      </button>
                    ))
                  )}
                </div>
              )}

              {/* Selected Doctors */}
              {selectedDoctors.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Médecins sélectionnés ({selectedDoctors.length})
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {selectedDoctors.map(doctor => (
                      <span
                        key={doctor.id}
                        className="inline-flex items-center gap-1 px-3 py-1 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded-full text-sm"
                      >
                        Dr. {doctor.name} {doctor.family_name}
                        <button
                          onClick={() => toggleDoctorSelection(doctor)}
                          className="p-0.5 hover:bg-indigo-200 dark:hover:bg-indigo-800 rounded-full"
                        >
                          <XMarkIcon className="w-4 h-4" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 2: Configure Share */}
          {currentStep === 'configure' && (
            <div className="space-y-6">
              {/* Document Types */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                  Documents à partager
                </label>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-3 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <input
                      type="checkbox"
                      checked={sharePrescriptions}
                      onChange={(e) => setSharePrescriptions(e.target.checked)}
                      className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500"
                    />
                    <ClipboardDocumentListIcon className="w-6 h-6 text-green-600" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Ordonnances</p>
                      <p className="text-sm text-gray-500">Toutes les prescriptions médicales</p>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-3 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <input
                      type="checkbox"
                      checked={shareMedicalReports}
                      onChange={(e) => setShareMedicalReports(e.target.checked)}
                      className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500"
                    />
                    <DocumentTextIcon className="w-6 h-6 text-purple-600" />
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">Comptes rendus</p>
                      <p className="text-sm text-gray-500">Tous les rapports médicaux</p>
                    </div>
                  </label>
                  {isDentist && (
                    <label className="flex items-center gap-3 p-3 border border-gray-200 dark:border-gray-700 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50">
                      <input
                        type="checkbox"
                        checked={shareDentalActs}
                        onChange={(e) => setShareDentalActs(e.target.checked)}
                        className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500"
                      />
                      <svg className="w-6 h-6 text-cyan-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M12 2C8.5 2 6 4 6 7c0 2 .5 3.5 1 5 .5 1.5 1 3 1 5 0 3 1 5 4 5s4-2 4-5c0-2 .5-3.5 1-5s1-3 1-5c0-3-2.5-5-6-5z" />
                      </svg>
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white">Actes dentaires</p>
                        <p className="text-sm text-gray-500">Tous les soins dentaires</p>
                      </div>
                    </label>
                  )}
                </div>
              </div>

              {/* Visibility Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <CalendarIcon className="w-4 h-4 inline mr-1" />
                  Montrer les documents jusqu'à (optionnel)
                </label>
                <input
                  type="date"
                  value={visibleUntilDate}
                  onChange={(e) => setVisibleUntilDate(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Laissez vide pour partager tous les documents
                </p>
              </div>

              {/* Share Duration */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <ClockIcon className="w-4 h-4 inline mr-1" />
                  Durée du partage
                </label>
                <select
                  value={shareDuration}
                  onChange={(e) => setShareDuration(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="1">1 jour</option>
                  <option value="3">3 jours</option>
                  <option value="7">7 jours</option>
                  <option value="14">14 jours</option>
                  <option value="30">30 jours</option>
                  <option value="90">3 mois</option>
                  <option value="180">6 mois</option>
                  <option value="365">1 an</option>
                </select>
              </div>
            </div>
          )}

          {/* Step 3: Confirm */}
          {currentStep === 'confirm' && (
            <div className="space-y-6">
              {/* Raison du partage */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Raison du partage <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={shareReason}
                  onChange={(e) => setShareReason(e.target.value)}
                  placeholder="Ex: Avis spécialisé, suivi post-opératoire, deuxième opinion..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-indigo-500 resize-none"
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  Cette information sera enregistrée dans le journal d'audit pour des raisons légales.
                </p>
              </div>

              {/* Notice légale */}
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <ExclamationTriangleIcon className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">
                      Obligation légale - Code de déontologie médicale algérien
                    </h3>
                    <p className="text-sm text-red-700 dark:text-red-300 mt-2">
                      Conformément à la <strong>loi n°18-11 relative à la santé</strong> et au 
                      <strong> décret exécutif n°92-276 portant code de déontologie médicale</strong>, 
                      vous êtes tenu d'informer le patient du partage de son dossier médical avec un confrère.
                    </p>
                    <ul className="text-sm text-red-700 dark:text-red-300 mt-2 list-disc list-inside space-y-1">
                      <li>Le patient doit être informé de l'identité du médecin destinataire</li>
                      <li>Le patient doit connaître la nature des informations partagées</li>
                      <li>Le patient a le droit de s'opposer à ce partage</li>
                    </ul>
                    <p className="text-sm text-red-700 dark:text-red-300 mt-2 font-medium">
                      En confirmant ce partage, vous attestez avoir informé le patient et obtenu son accord.
                    </p>
                  </div>
                </div>
              </div>

              {/* Checkbox de confirmation */}
              <div className="flex items-start gap-3 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg border-2 border-gray-200 dark:border-gray-600">
                <input
                  type="checkbox"
                  id="patientInformedConfirmed"
                  checked={patientInformedConfirmed}
                  onChange={(e) => setPatientInformedConfirmed(e.target.checked)}
                  className="mt-1 w-5 h-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                />
                <label htmlFor="patientInformedConfirmed" className="text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
                  <strong>Je confirme avoir informé le patient {patientName}</strong> du partage de son dossier médical 
                  avec {selectedDoctors.length > 1 ? 'les médecins sélectionnés' : `Dr. ${selectedDoctors[0]?.name} ${selectedDoctors[0]?.family_name}`} et 
                  avoir obtenu son accord conformément à la législation algérienne.
                </label>
              </div>

              {/* Récapitulatif */}
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 space-y-3">
                <h4 className="font-medium text-gray-800 dark:text-gray-200 mb-2">Récapitulatif du partage</h4>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Patient:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{patientName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Médecin(s):</span>
                  <span className="font-medium text-gray-900 dark:text-white text-right">
                    {selectedDoctors.map(d => `Dr. ${d.name} ${d.family_name}`).join(', ')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Documents:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {[
                      sharePrescriptions && 'Ordonnances',
                      shareMedicalReports && 'Comptes rendus',
                      (isDentist && shareDentalActs) && 'Actes dentaires'
                    ].filter(Boolean).join(', ')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Visibilité:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {visibleUntilDate 
                      ? `Jusqu'au ${new Date(visibleUntilDate).toLocaleDateString('fr-FR')}`
                      : 'Tous les documents'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Durée:</span>
                  <span className="font-medium text-gray-900 dark:text-white">
                    {shareDuration} jour(s)
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex justify-between">
          {currentStep === 'select' ? (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => setCurrentStep('configure')}
                disabled={selectedDoctors.length === 0}
                className="px-6 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Suivant
              </button>
            </>
          ) : currentStep === 'configure' ? (
            <>
              <button
                onClick={() => setCurrentStep('select')}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                Retour
              </button>
              <button
                onClick={() => setCurrentStep('confirm')}
                disabled={!sharePrescriptions && !shareMedicalReports && !shareDentalActs}
                className="px-6 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Suivant
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setCurrentStep('configure')}
                className="px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                Retour
              </button>
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-6 py-2 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 disabled:opacity-50 transition-colors flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Partage en cours...
                  </>
                ) : (
                  <>
                    <CheckIcon className="w-5 h-5" />
                    Confirmer le partage
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default ShareMedicalRecordModal;