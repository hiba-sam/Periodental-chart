import axios from 'axios';
import type {
    OpticalCorrection,
    CreateOpticalCorrectionPayload,
    OpticalCorrectionFilters,
} from '../types/opticalCorrection.types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3333';

const opticalCorrectionApi = axios.create({
    baseURL: `${API_URL}/optical-correction`,
    withCredentials: true,
    headers: { 'Content-Type': 'application/json' },
});

/**
 * Fetch optical corrections for a specific patient
 */
export async function fetchOpticalCorrectionsByPatient(
    patientId: string, 
    filters?: Omit<OpticalCorrectionFilters, 'patientId'>
): Promise<OpticalCorrection[]> {
    const params = new URLSearchParams();
    if (filters?.limit) params.append('limit', filters.limit.toString());
    if (filters?.offset) params.append('offset', filters.offset.toString());

    const url = `/patient/${patientId}${params.toString() ? `?${params.toString()}` : ''}`;
    const response = await opticalCorrectionApi.get(url);

    if (response.data.success) {
        return response.data.data || [];
    }
    throw new Error(response.data.error || 'Failed to fetch optical corrections');
}

/**
 * Fetch a single optical correction by ID
 */
export async function fetchOpticalCorrectionById(id: number): Promise<OpticalCorrection> {
    const response = await opticalCorrectionApi.get(`/${id}`);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Optical correction not found');
}

/**
 * Create a new optical correction
 */
export async function createOpticalCorrection(payload: CreateOpticalCorrectionPayload): Promise<OpticalCorrection> {
    const response = await opticalCorrectionApi.post('/', payload);
    if (response.data.success) {
        return response.data.data;
    }
    throw new Error(response.data.error || 'Failed to create optical correction');
}

/**
 * Generate and download optical correction PDF
 */
export async function generateOpticalCorrectionPdf(id: number): Promise<void> {
    const response = await opticalCorrectionApi.get(`/${id}/pdf`, {
        responseType: 'blob',
    });

    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `ordonnance_optique_${id}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
}

/**
 * Open the optical correction PDF in a new browser tab (for printing)
 */
export function openOpticalCorrectionPdf(id: number): void {
    const url = `${API_URL}/optical-correction/${id}/pdf`;
    window.open(url, '_blank');
}
