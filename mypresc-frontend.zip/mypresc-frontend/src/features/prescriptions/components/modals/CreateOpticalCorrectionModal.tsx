import React, { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/components/ui/use-toast';
import { OpticalCorrectionForm } from '../forms/OpticalCorrectionForm';
import { createOpticalCorrection, openOpticalCorrectionPdf } from '../../api/opticalCorrection.api';
import type { CreateOpticalCorrectionPayload, OpticalCorrection } from '../../types/opticalCorrection.types';
import { Eye, X, Printer } from 'lucide-react';

interface CreateOpticalCorrectionModalProps {
    isOpen: boolean;
    onClose: () => void;
    patientId: string;
    patientName?: string;
    patientFamilyName?: string;
    patientDateNaissance?: string;
    patientGenre?: string;
    onSuccess: () => void;
}

export function CreateOpticalCorrectionModal({ 
    isOpen, 
    onClose, 
    patientId, 
    patientName,
    patientFamilyName,
    patientDateNaissance,
    patientGenre,
    onSuccess 
}: CreateOpticalCorrectionModalProps) {
    const { t } = useLanguage();
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showPrintOption, setShowPrintOption] = useState(false);
    const [createdCorrection, setCreatedCorrection] = useState<OpticalCorrection | null>(null);

    if (!isOpen) return null;

    const handleSubmit = async (data: CreateOpticalCorrectionPayload) => {
        try {
            setIsSubmitting(true);
            const result = await createOpticalCorrection(data);
            setCreatedCorrection(result);
            // Show success modal first — onSuccess/onClose are deferred to handleClose
            // so the parent doesn't unmount this modal before the success state renders.
            setShowPrintOption(true);
        } catch (error: any) {
            console.error('Error creating optical correction:', error);
            toast({
                title: 'Erreur',
                description: error.message || 'Erreur lors de la création',
                variant: 'destructive',
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    const handlePrint = () => {
        if (createdCorrection?.id) {
            openOpticalCorrectionPdf(createdCorrection.id);
            handleClose();
        }
    };

    const handleClose = () => {
        setShowPrintOption(false);
        setCreatedCorrection(null);
        // Notify parent to refresh the list, then close
        onSuccess();
        onClose();
    };

    /* ------------------------------------------------------------------ */
    /* Success state — shown after saving                                   */
    /* ------------------------------------------------------------------ */
    if (showPrintOption && createdCorrection) {
        return (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
                <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 transform transition-all">
                    <div className="p-8">
                        <div className="text-center">
                            {/* Icon */}
                            <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Eye className="w-8 h-8 text-green-600 dark:text-green-400" />
                            </div>

                            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                                Ordonnance créée avec succès
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                                L'ordonnance optique pour <strong>{patientName} {patientFamilyName}</strong> a été enregistrée.
                            </p>

                            <div className="flex flex-col gap-3">
                                <button
                                    onClick={handlePrint}
                                    className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                                >
                                    <Printer className="w-5 h-5" />
                                    Imprimer l'ordonnance
                                </button>
                                <button
                                    onClick={handleClose}
                                    className="w-full px-6 py-3 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                                >
                                    {t('common.close')}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    /* ------------------------------------------------------------------ */
    /* Form state                                                           */
    /* ------------------------------------------------------------------ */
    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full mx-4 my-8 transform transition-all overflow-y-auto flex flex-col max-h-[90vh]">
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700 shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 flex items-center gap-2">
                            <span className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg text-indigo-600 dark:text-indigo-400">
                                <Eye className="w-5 h-5" />
                            </span>
                            Nouvelle Ordonnance Optique
                        </h2>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            Pour {patientName} {patientFamilyName}
                            {patientDateNaissance && ` • Né(e) le ${new Date(patientDateNaissance).toLocaleDateString('fr-FR')}`}
                            {patientGenre && ` • ${patientGenre === 'homme' ? 'Homme' : 'Femme'}`}
                        </p>
                    </div>
                    <button
                        onClick={handleClose}
                        className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                    >
                        <X className="w-6 h-6" />
                    </button>
                </div>

                {/* Form */}
                <div className="p-6 overflow-y-auto">
                    <OpticalCorrectionForm 
                        onSubmit={handleSubmit}
                        onCancel={handleClose}
                        patientId={patientId}
                        isSubmitting={isSubmitting}
                    />
                </div>
            </div>
        </div>
    );
}
