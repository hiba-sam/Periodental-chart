// Optical Correction Types - Type definitions for optical correction data

export interface OpticalCorrection {
    id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
    od_sph: string | null;
    od_cyl: string | null;
    od_axis: string | null;
    od_add: string | null;
    od_pd: string | null;
    os_sph: string | null;
    os_cyl: string | null;
    os_axis: string | null;
    os_add: string | null;
    os_pd: string | null;
    remarks: string | null;
    created_at: string | Date;
    updated_at?: string | Date;
    patient?: {
        id: string;
        name: string;
        family_name: string;
        age: number;
        genre: 'homme' | 'femme';
        telephone: string;
        email?: string;
    };
    doctor?: {
        id: number;
        name: string;
        family_name: string;
        email: string;
    };
}

export interface CreateOpticalCorrectionPayload {
    patient_id: string; // UUID
    od_sph?: string;
    od_cyl?: string;
    od_axis?: string;
    od_add?: string;
    od_pd?: string;
    os_sph?: string;
    os_cyl?: string;
    os_axis?: string;
    os_add?: string;
    os_pd?: string;
    remarks?: string;
}

export interface OpticalCorrectionFilters {
    patientId?: string; // UUID
    limit?: number;
    offset?: number;
}
