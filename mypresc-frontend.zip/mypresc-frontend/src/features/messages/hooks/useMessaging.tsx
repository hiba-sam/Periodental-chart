'use client';

/**
 * useMessaging.ts
 * ───────────────
 * React context provider and hooks for the messaging feature.
 * Migrated from `contexts/MessagingContext.tsx`.
 *
 * Provides:
 *   - <MessagingProvider> — wrap your page/layout with this
 *   - useMessaging()     — throws if used outside provider
 *   - useMessagingSafe() — returns null if used outside provider
 */

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import socketClient from '@/utils/socketClient';
import useSWR from 'swr';
import { useAuth } from '@/contexts/AuthContext';
import logger from '@/utils/logger';
import { conversationsFetcher, partnerFetcher, API_URL } from '../api';
import type {
    Message,
    Conversation,
    ConversationPartner,
    MessageCache,
    MessagingContextType,
} from '../types';

// ─── Context ───────────────────────────────────────────────────────────────

const MessagingContext = createContext<MessagingContextType | undefined>(undefined);

// ─── Provider ──────────────────────────────────────────────────────────────

export function MessagingProvider({ children }: { children: React.ReactNode }) {
    const { user } = useAuth();

    const { data: conversations, error, isLoading, mutate } = useSWR<Conversation[]>(
        `${API_URL}/messaging/conversations`,
        conversationsFetcher,
        {
            refreshInterval: 30000,
            revalidateOnFocus: true,
        }
    );

    const { data: conversationPartner, error: partnerError, isLoading: partnerLoading } =
        useSWR<ConversationPartner | null>(
            `${API_URL}/messaging/conversation-partner`,
            partnerFetcher,
            {
                refreshInterval: 30000,
                revalidateOnFocus: true,
            }
        );

    const [localConversations, setLocalConversations] = useState<Conversation[]>([]);
    const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
    const [messageCache, setMessageCache] = useState<MessageCache>({});

    // ─── Conversation Helpers ───────────────────────────────────────────────

    const refreshConversations = useCallback(() => {
        mutate();
    }, [mutate]);

    const updateConversation = useCallback((conversationId: number, updates: Partial<Conversation>) => {
        setLocalConversations(prev =>
            prev.map(conv => (conv.id === conversationId ? { ...conv, ...updates } : conv))
        );
    }, []);

    const incrementUnread = useCallback((conversationId: number) => {
        setLocalConversations(prev =>
            prev.map(conv =>
                conv.id === conversationId ? { ...conv, unread_count: conv.unread_count + 1 } : conv
            )
        );
    }, []);

    const resetUnread = useCallback((conversationId: number) => {
        setLocalConversations(prev =>
            prev.map(conv =>
                conv.id === conversationId ? { ...conv, unread_count: 0 } : conv
            )
        );
    }, []);

    // ─── Message Cache Helpers ──────────────────────────────────────────────

    const getMessagesForConversation = useCallback(
        (conversationId: number): Message[] => messageCache[conversationId] || [],
        [messageCache]
    );

    const setMessagesForConversation = useCallback((conversationId: number, messages: Message[]) => {
        setMessageCache(prev => ({ ...prev, [conversationId]: messages }));
    }, []);

    const addMessageToConversation = useCallback((conversationId: number, message: Message) => {
        setMessageCache(prev => {
            const existing = prev[conversationId] || [];
            const exists = existing.some(m => {
                if (m.id && message.id && m.id === message.id) return true;
                if ((m as any).tempId && (message as any).tempId && (m as any).tempId === (message as any).tempId) return true;
                if (m.content === message.content && m.created_at === message.created_at && m.sender_id === message.sender_id) return true;
                return false;
            });
            if (exists) return prev;
            return { ...prev, [conversationId]: [...existing, message] };
        });
    }, []);

    const updateMessageInConversation = useCallback(
        (conversationId: number, messageId: number | null, updates: Partial<Message>) => {
            setMessageCache(prev => ({
                ...prev,
                [conversationId]: (prev[conversationId] || []).map(msg =>
                    msg.id === messageId ? { ...msg, ...updates } : msg
                ),
            }));
        },
        []
    );

    // ─── Sync SWR → Local State ─────────────────────────────────────────────

    useEffect(() => {
        logger.log('📊 MessagingContext: conversations:', conversations);
        logger.log('🤝 MessagingContext: conversationPartner:', conversationPartner);
        logger.log('⚠️ MessagingContext: error:', error);
        logger.log('⚠️ MessagingContext: partnerError:', partnerError);

        if (conversations) {
            const uniqueConversations = Array.from(
                new Map(conversations.map(conv => [conv.id, conv])).values()
            );

            const sortedConversations = [...uniqueConversations];
            if (conversationPartner) {
                const partnerIndex = sortedConversations.findIndex(conv => conv.id === conversationPartner.id);
                if (partnerIndex > 0) {
                    const [partnerConv] = sortedConversations.splice(partnerIndex, 1);
                    sortedConversations.unshift(partnerConv!);
                }
                logger.log('✅ Sorted conversations with partner first:', sortedConversations);
            }

            setLocalConversations(prev => {
                if (!prev || prev.length === 0) return sortedConversations;
                const localUnreadMap = new Map(
                    prev.filter(c => c.unread_count === 0).map(c => [c.id, 0])
                );
                return sortedConversations.map(conv =>
                    localUnreadMap.has(conv.id) ? { ...conv, unread_count: 0 } : conv
                );
            });
        }
    }, [conversations, conversationPartner]);

    // ─── Socket Listeners ───────────────────────────────────────────────────

    const updateConversationRef = useRef(updateConversation);
    const incrementUnreadRef = useRef(incrementUnread);
    const currentUserIdRef = useRef<number | null>(null);
    const activeConversationIdRef = useRef<number | null>(null);

    useEffect(() => {
        updateConversationRef.current = updateConversation;
        incrementUnreadRef.current = incrementUnread;
        const realUserId = (user as any)?.assistant_id || user?.id;
        currentUserIdRef.current = realUserId ? Number(realUserId) : null;
        activeConversationIdRef.current = activeConversationId;
    }, [updateConversation, incrementUnread, user, activeConversationId]);

    useEffect(() => {
        socketClient.connect();

        const handleNewMessage = (data: { message: Message; conversationId: number; senderId?: number }) => {
            updateConversationRef.current(data.conversationId, {
                last_message: data.message.content,
                last_message_at: data.message.created_at,
            });
            const senderId = data.senderId || data.message.sender_id;
            const isConversationOpen = activeConversationIdRef.current === data.conversationId;
            if (senderId && currentUserIdRef.current && senderId !== currentUserIdRef.current && !isConversationOpen) {
                incrementUnreadRef.current(data.conversationId);
            }
        };

        const handleConversationUpdated = (data: {
            conversationId: number;
            lastMessage: string;
            unreadCount: number;
        }) => {
            updateConversationRef.current(data.conversationId, { last_message: data.lastMessage });
        };

        const attachListeners = () => {
            const socket = socketClient.getSocket();
            if (!socket) return;
            logger.log('📨 [MessagingContext] Attaching message:new listener');
            socket.off('message:new', handleNewMessage);
            socket.on('message:new', handleNewMessage);
            socket.off('conversation:updated', handleConversationUpdated);
            socket.on('conversation:updated', handleConversationUpdated);
            socketClient.updatePresence('online');
        };

        const cleanupOnConnect = socketClient.onConnect(attachListeners);

        return () => {
            cleanupOnConnect();
            socketClient.updatePresence('offline');
            const socket = socketClient.getSocket();
            if (socket) {
                socket.off('message:new', handleNewMessage);
                socket.off('conversation:updated', handleConversationUpdated);
            }
        };
    }, []);

    // ─── Provider Return ────────────────────────────────────────────────────

    return (
        <MessagingContext.Provider
      value= {{
        conversations: localConversations || [],
            conversationPartner: conversationPartner || null,
                isLoading,
                partnerLoading,
                error,
                partnerError,
                refreshConversations,
                updateConversation,
                incrementUnread,
                resetUnread,
                activeConversationId,
                setActiveConversationId,
                getMessagesForConversation,
                setMessagesForConversation,
                addMessageToConversation,
                updateMessageInConversation,
      }}>
    { children }
    </MessagingContext.Provider>
  );
}

// ─── Hooks ─────────────────────────────────────────────────────────────────

/** Throws if used outside <MessagingProvider>. */
export function useMessaging() {
    const context = useContext(MessagingContext);
    if (context === undefined) {
        throw new Error('useMessaging must be used within a MessagingProvider');
    }
    return context;
}

/** Safe version — returns null if used outside <MessagingProvider>. */
export function useMessagingSafe() {
    const context = useContext(MessagingContext);
    return context ?? null;
}
