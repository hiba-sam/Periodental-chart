/**
 * messaging.types.ts
 * ──────────────────
 * All TypeScript interfaces and types for the messages feature.
 * Extracted from MessagingContext.tsx and component-level type definitions.
 */

// ─── Core Messaging Entities ───────────────────────────────────────────────

export interface Message {
    id: number | null;
    conversation_id: number;
    sender_id: number;
    sender_name: string;
    content: string;
    is_read: boolean;
    created_at: string;
    read_at?: string;
    is_edited?: boolean;
    tempId?: string;
    isPending?: boolean;
    isFailed?: boolean;
    attachment_url?: string;
    attachment_type?: 'image' | 'pdf';
    attachment_name?: string;
}

export interface Conversation {
    id: number;
    other_user_id: number;
    other_user_name: string;
    last_message?: string;
    last_message_at?: string;
    unread_count: number;
}

export interface ConversationPartner {
    id: number;
    other_user_id: number;
    other_user_name: string;
    last_message?: string;
    last_message_at?: string;
    unread_count: number;
}

// Cache keyed by conversationId
export interface MessageCache {
    [conversationId: number]: Message[];
}

// ─── Context ───────────────────────────────────────────────────────────────

export interface MessagingContextType {
    conversations: Conversation[];
    conversationPartner: ConversationPartner | null;
    isLoading: boolean;
    partnerLoading: boolean;
    error: any;
    partnerError: any;
    refreshConversations: () => void;
    updateConversation: (conversationId: number, updates: Partial<Conversation>) => void;
    incrementUnread: (conversationId: number) => void;
    resetUnread: (conversationId: number) => void;
    activeConversationId: number | null;
    setActiveConversationId: (id: number | null) => void;
    // Message cache
    getMessagesForConversation: (conversationId: number) => Message[];
    setMessagesForConversation: (conversationId: number, messages: Message[]) => void;
    addMessageToConversation: (conversationId: number, message: Message) => void;
    updateMessageInConversation: (
        conversationId: number,
        messageId: number | null,
        updates: Partial<Message>
    ) => void;
}

// ─── Presence ──────────────────────────────────────────────────────────────

export type PresenceStatus = 'online' | 'away' | 'offline';

export interface PresenceData {
    status: PresenceStatus;
    last_seen_at?: string;
}

// ─── Connection ────────────────────────────────────────────────────────────

export type ConnectionState = 'connected' | 'disconnected' | 'reconnecting';

// ─── Search ────────────────────────────────────────────────────────────────

export interface MessageSearchResult {
    id: number;
    content: string;
    sender_name: string;
    created_at: string;
}

// ─── Doctor / User Search ──────────────────────────────────────────────────

export interface Doctor {
    id: number;
    name: string;
    family_name: string;
    full_name: string;
    speciality?: string;
}
