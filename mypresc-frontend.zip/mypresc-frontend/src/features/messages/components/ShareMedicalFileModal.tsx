'use client';

import React, { useState, useEffect } from 'react';
import { X, Share2, AlertTriangle, FileText, Pill, Calendar, Clock, Search, CheckCircle, Loader2 } from 'lucide-react';
import axios from 'axios';
import MobileFullModal from '@/components/ui/MobileFullModal';

interface Patient {
    id: string;
    name: string;
    family_name: string;
    birth_date?: string;
}

interface ShareMedicalFileModalProps {
    isOpen: boolean;
    onClose: () => void;
    recipientDoctorId: number;
    recipientDoctorName: string;
    conversationId: number;
    onShareComplete: (message: string) => void;
}

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

export default function ShareMedicalFileModal({
    isOpen,
    onClose,
    recipientDoctorId,
    recipientDoctorName,
    conversationId,
    onShareComplete,
}: ShareMedicalFileModalProps) {
    const [step, setStep] = useState<'select' | 'confirm' | 'success'>('select');
    const [patients, setPatients] = useState<Patient[]>([]);
    const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
    const [sharePrescriptions, setSharePrescriptions] = useState(true);
    const [shareMedicalReports, setShareMedicalReports] = useState(true);
    const [linkDuration, setLinkDuration] = useState('7');
    const [historyLimit, setHistoryLimit] = useState('30');
    const [reason, setReason] = useState('');
    const [patientInformedConfirmed, setPatientInformedConfirmed] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [shareToken, setShareToken] = useState('');

    // Detect mobile viewport
    const [isMobile, setIsMobile] = useState(false);
    useEffect(() => {
        const mq = window.matchMedia('(max-width: 767px)');
        setIsMobile(mq.matches);
        const handler = (e: MediaQueryListEvent) => setIsMobile(e.matches);
        mq.addEventListener('change', handler);
        return () => mq.removeEventListener('change', handler);
    }, []);

    useEffect(() => {
        if (isOpen) {
            fetchPatients();
            setStep('select');
            setSelectedPatient(null);
            setSearchQuery('');
            setSharePrescriptions(true);
            setShareMedicalReports(true);
            setLinkDuration('7');
            setHistoryLimit('30');
            setReason('');
            setPatientInformedConfirmed(false);
            setError('');
            setShareToken('');
        }
    }, [isOpen]);

    useEffect(() => {
        if (searchQuery.trim()) {
            const query = searchQuery.toLowerCase();
            setFilteredPatients(
                patients.filter(
                    p =>
                        p.name?.toLowerCase().includes(query) ||
                        p.family_name?.toLowerCase().includes(query)
                )
            );
        } else {
            setFilteredPatients(patients);
        }
    }, [searchQuery, patients]);

    const fetchPatients = async () => {
        try {
            const response = await axios.get(`${API_URL}/patient?limit=100`, { withCredentials: true });
            if (response.data?.success && response.data?.data) {
                setPatients(response.data.data);
                setFilteredPatients(response.data.data);
            }
        } catch (err: any) {
            console.error('Error fetching patients:', err);
            setError(err.response?.data?.error || 'Erreur lors du chargement des patients');
        }
    };

    const handleProceedToConfirm = () => {
        if (!selectedPatient) { setError('Veuillez sélectionner un patient'); return; }
        if (!sharePrescriptions && !shareMedicalReports) { setError('Veuillez sélectionner au moins un type de document à partager'); return; }
        if (!reason.trim()) { setError('Veuillez indiquer la raison du partage'); return; }
        setError('');
        setStep('confirm');
    };

    const handleConfirmShare = async () => {
        if (!patientInformedConfirmed) { setError('Vous devez confirmer que le patient a été informé'); return; }
        setIsLoading(true);
        setError('');
        try {
            const expiresAt = new Date();
            expiresAt.setDate(expiresAt.getDate() + parseInt(linkDuration));
            const visibleUntilDate = new Date();
            visibleUntilDate.setDate(visibleUntilDate.getDate() - parseInt(historyLimit));

            const response = await axios.post(
                `${API_URL}/medical-shares`,
                {
                    patient_id: selectedPatient!.id,
                    shared_with_doctor_ids: [recipientDoctorId],
                    share_prescriptions: sharePrescriptions,
                    share_medical_reports: shareMedicalReports,
                    visible_until_date: visibleUntilDate.toISOString(),
                    expires_at: expiresAt.toISOString(),
                    reason: reason.trim(),
                },
                { withCredentials: true }
            );

            if (response.data?.success && response.data?.data?.length > 0) {
                const share = response.data.data[0];
                setShareToken(share.share_token);
                setStep('success');

                const patientName = `${selectedPatient!.name} ${selectedPatient!.family_name}`;
                const shareUrl = `${window.location.origin}/shared-medical-file/${share.share_token}`;
                const shareTypes: string[] = [];
                if (sharePrescriptions) shareTypes.push('prescriptions');
                if (shareMedicalReports) shareTypes.push('comptes rendus médicaux');

                const message = `Bonjour Docteur ${recipientDoctorName.split(' ')[0]},\n\nJe vous partage le dossier médical de ${patientName} (${shareTypes.join(' et ')}).\n\n🔗 Accéder au dossier: ${shareUrl}\n\n⚠️ Ce lien est personnel et non transférable.\n📅 Valide jusqu'au: ${expiresAt.toLocaleDateString('fr-FR')}\n📋 Historique visible: ${historyLimit} derniers jours\n\nRaison du partage: ${reason.trim()}\n\nCordialement.`;
                onShareComplete(message);
            } else {
                throw new Error('Erreur lors de la création du partage');
            }
        } catch (err: any) {
            console.error('Error creating share:', err);
            setError(err.response?.data?.error || 'Erreur lors du partage');
        } finally {
            setIsLoading(false);
        }
    };

    if (!isOpen) return null;

    // ── Shared content (rendered in both mobile & desktop containers) ─────────
    const content = (
        <div className="p-4 space-y-5">
            {error && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-300 text-sm">
                    {error}
                </div>
            )}

            {step === 'select' && (
                <div className="space-y-5">
                    {/* Patient Selection */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Sélectionner un patient</label>
                        <div className="relative mb-3">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="Rechercher un patient..."
                                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                            />
                        </div>
                        <div className="max-h-48 overflow-y-auto border border-gray-200 dark:border-gray-700 rounded-lg">
                            {filteredPatients.length === 0 ? (
                                <div className="p-4 text-center text-gray-500 dark:text-gray-400">Aucun patient trouvé</div>
                            ) : (
                                filteredPatients.slice(0, 50).map((patient) => (
                                    <button
                                        key={patient.id}
                                        onClick={() => setSelectedPatient(patient)}
                                        className={`w-full px-4 py-3 text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors flex items-center justify-between ${selectedPatient?.id === patient.id ? 'bg-blue-50 dark:bg-blue-900/30 border-l-4 border-blue-500' : ''}`}
                                    >
                                        <div>
                                            <p className="font-medium text-gray-900 dark:text-white">{patient.name} {patient.family_name}</p>
                                            {patient.birth_date && (
                                                <p className="text-sm text-gray-500 dark:text-gray-400">Né(e) le {new Date(patient.birth_date).toLocaleDateString('fr-FR')}</p>
                                            )}
                                        </div>
                                        {selectedPatient?.id === patient.id && <CheckCircle className="w-5 h-5 text-blue-500" />}
                                    </button>
                                ))
                            )}
                        </div>
                    </div>

                    {/* Document Types */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Documents à partager</label>
                        <div className="grid grid-cols-2 gap-3">
                            <label className={`flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer transition-all ${sharePrescriptions ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-200 dark:border-gray-700'}`}>
                                <input type="checkbox" checked={sharePrescriptions} onChange={(e) => setSharePrescriptions(e.target.checked)} className="sr-only" />
                                <Pill className={`w-5 h-5 ${sharePrescriptions ? 'text-blue-500' : 'text-gray-400'}`} />
                                <span className={`text-sm font-medium ${sharePrescriptions ? 'text-blue-700 dark:text-blue-300' : 'text-gray-600 dark:text-gray-400'}`}>Prescriptions</span>
                            </label>
                            <label className={`flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer transition-all ${shareMedicalReports ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20' : 'border-gray-200 dark:border-gray-700'}`}>
                                <input type="checkbox" checked={shareMedicalReports} onChange={(e) => setShareMedicalReports(e.target.checked)} className="sr-only" />
                                <FileText className={`w-5 h-5 ${shareMedicalReports ? 'text-purple-500' : 'text-gray-400'}`} />
                                <span className={`text-sm font-medium ${shareMedicalReports ? 'text-purple-700 dark:text-purple-300' : 'text-gray-600 dark:text-gray-400'}`}>Comptes Rendus</span>
                            </label>
                        </div>
                    </div>

                    {/* Duration Settings */}
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                                <Calendar className="w-3.5 h-3.5 inline mr-1" />Durée du lien
                            </label>
                            <select value={linkDuration} onChange={(e) => setLinkDuration(e.target.value)} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white">
                                <option value="1">1 jour</option>
                                <option value="3">3 jours</option>
                                <option value="7">7 jours</option>
                                <option value="14">14 jours</option>
                                <option value="30">30 jours</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1.5">
                                <Clock className="w-3.5 h-3.5 inline mr-1" />Historique visible
                            </label>
                            <select value={historyLimit} onChange={(e) => setHistoryLimit(e.target.value)} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-sm text-gray-900 dark:text-white">
                                <option value="7">7 derniers jours</option>
                                <option value="30">30 derniers jours</option>
                                <option value="90">90 derniers jours</option>
                                <option value="180">6 derniers mois</option>
                                <option value="365">1 an</option>
                                <option value="9999">Tout l'historique</option>
                            </select>
                        </div>
                    </div>

                    {/* Reason */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Raison du partage (obligatoire)</label>
                        <textarea
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Ex: Demande d'avis pour diagnostic, Suivi post-opératoire, Transfert de patient..."
                            rows={3}
                            className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                        />
                    </div>

                    <button
                        onClick={handleProceedToConfirm}
                        disabled={!selectedPatient}
                        className="w-full py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Continuer
                    </button>
                </div>
            )}

            {step === 'confirm' && (
                <div className="space-y-5">
                    <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl">
                        <div className="flex items-start gap-3">
                            <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                            <div>
                                <h3 className="font-bold text-amber-800 dark:text-amber-200 mb-1 text-sm">⚖️ Respect de la Déontologie Médicale</h3>
                                <p className="text-xs text-amber-700 dark:text-amber-300 mb-2">
                                    Conformément au <strong>Code de déontologie médicale algérien</strong> et à la <strong>Loi n°18-11</strong>, le partage nécessite :
                                </p>
                                <ul className="text-xs text-amber-700 dark:text-amber-300 space-y-0.5 list-disc list-inside">
                                    <li>L'information préalable du patient</li>
                                    <li>Une raison médicale légitime</li>
                                    <li>La protection du secret médical</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl space-y-1.5">
                        <h4 className="font-medium text-gray-900 dark:text-white mb-2 text-sm">Résumé :</h4>
                        {[
                            ['Patient', `${selectedPatient?.name} ${selectedPatient?.family_name}`],
                            ['Destinataire', `Dr. ${recipientDoctorName}`],
                            ['Documents', [sharePrescriptions && 'Prescriptions', shareMedicalReports && 'Comptes Rendus'].filter(Boolean).join(', ')],
                            ['Validité', `${linkDuration} jour(s)`],
                            ['Historique', historyLimit === '9999' ? 'Tout' : `${historyLimit} derniers jours`],
                            ['Raison', reason],
                        ].map(([label, value]) => (
                            <p key={label as string} className="text-xs text-gray-600 dark:text-gray-300">
                                <strong>{label} :</strong> {value}
                            </p>
                        ))}
                    </div>

                    <label className="flex items-start gap-3 p-3 border-2 border-gray-200 dark:border-gray-700 rounded-xl cursor-pointer hover:border-blue-500 transition-colors">
                        <input
                            type="checkbox"
                            checked={patientInformedConfirmed}
                            onChange={(e) => setPatientInformedConfirmed(e.target.checked)}
                            className="mt-0.5 w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-xs text-gray-700 dark:text-gray-300">
                            Je confirme que le patient <strong>{selectedPatient?.name} {selectedPatient?.family_name}</strong> a été informé et que ce partage respecte les obligations déontologiques et légales.
                        </span>
                    </label>

                    <div className="flex gap-3">
                        <button onClick={() => setStep('select')} className="flex-1 py-2.5 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 font-medium rounded-xl hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-sm">
                            Retour
                        </button>
                        <button
                            onClick={handleConfirmShare}
                            disabled={!patientInformedConfirmed || isLoading}
                            className="flex-1 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm"
                        >
                            {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" />Partage...</> : <><Share2 className="w-4 h-4" />Confirmer</>}
                        </button>
                    </div>
                </div>
            )}

            {step === 'success' && (
                <div className="text-center py-8">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                        <CheckCircle className="w-8 h-8 text-green-500" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Partage créé avec succès !</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">Un message avec le lien de partage a été préparé pour le Dr. {recipientDoctorName}.</p>
                    <button onClick={onClose} className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-xl transition-all">
                        Fermer
                    </button>
                </div>
            )}
        </div>
    );

    // ── Mobile: MobileFullModal full-screen sheet ─────────────────────────────
    if (isMobile) {
        return (
            <MobileFullModal
                isOpen={isOpen}
                onClose={onClose}
                title="Partager un Dossier Médical"
                zIndex={10050}
            >
                {content}
            </MobileFullModal>
        );
    }

    // ── Desktop: centered dialog (unchanged) ──────────────────────────────────
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-600 to-purple-600">
                    <div className="flex items-center gap-3 text-white">
                        <Share2 className="w-6 h-6" />
                        <h2 className="text-xl font-bold">Partager un Dossier Médical</h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-full transition-colors">
                        <X className="w-5 h-5 text-white" />
                    </button>
                </div>
                <div className="overflow-y-auto max-h-[calc(90vh-80px)]">
                    {content}
                </div>
            </div>
        </div>
    );
}
