'use client';

import React, { useEffect, useState } from 'react';
import { WifiOff, Loader2, CheckCircle } from 'lucide-react';
import socketClient from '@/utils/socketClient';

type ConnectionState = 'connected' | 'disconnected' | 'reconnecting';

export default function ConnectionStatus() {
    const [state, setState] = useState<ConnectionState>('connected');
    const [reconnectAttempt, setReconnectAttempt] = useState(0);
    const [showConnected, setShowConnected] = useState(false);

    useEffect(() => {
        // Set initial state
        const { isConnected, isReconnecting } = socketClient.connectionState;
        if (isReconnecting) {
            setState('reconnecting');
        } else if (!isConnected) {
            setState('disconnected');
        }

        // Subscribe to connection events
        socketClient.setConnectionCallbacks({
            onConnect: () => {
                setState('connected');
                setShowConnected(true);
                // Hide the "connected" message after 2 seconds
                setTimeout(() => setShowConnected(false), 2000);
            },
            onDisconnect: () => {
                setState('disconnected');
            },
            onReconnecting: (attempt) => {
                setState('reconnecting');
                setReconnectAttempt(attempt);
            },
            onReconnectFailed: () => {
                setState('disconnected');
            },
        });

        return () => {
            socketClient.clearConnectionCallbacks();
        };
    }, []);

    // Don't show anything when connected (after initial animation)
    if (state === 'connected' && !showConnected) {
        return null;
    }

    return (
        <div
            className={`fixed top-0 left-0 right-0 z-50 px-4 py-2 text-sm font-medium text-center transition-all duration-300 ${state === 'connected'
                ? 'bg-green-500 text-white'
                : state === 'reconnecting'
                    ? 'bg-yellow-500 text-gray-900'
                    : 'bg-red-500 text-white'
                }`}
        >
            <div className="flex items-center justify-center gap-2">
                {state === 'connected' && (
                    <>
                        <CheckCircle className="w-4 h-4" />
                        <span>Connexion rétablie</span>
                    </>
                )}
                {state === 'reconnecting' && (
                    <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Reconnexion en cours... (tentative {reconnectAttempt})</span>
                    </>
                )}
                {state === 'disconnected' && (
                    <>
                        <WifiOff className="w-4 h-4" />
                        <span>Connexion perdue. Vérifiez votre connexion internet.</span>
                    </>
                )}
            </div>
        </div>
    );
}
