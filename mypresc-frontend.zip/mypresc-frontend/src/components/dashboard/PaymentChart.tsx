import { useState, useMemo, useEffect } from 'react';
import { ArrowTopRightOnSquareIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { createPortal } from 'react-dom';
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Area, AreaChart, XAxis, YAxis, LabelList, ResponsiveContainer } from 'recharts';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';
import { usePatients, InvoiceStatistics } from '@/contexts/PatientsContext';

export default function PaymentChart() {
  const { t } = useLanguage();
  const { theme } = useTheme();
  const { fetchPaymentStatistics } = usePatients();

  const [stats, setStats] = useState<InvoiceStatistics | null>(null);
  const [loading, setLoading] = useState(true);

  const isMobile = useMemo(() => {
    return typeof window !== 'undefined' && window.innerWidth < 768;
  }, []);

  const chartConfig = useMemo(() => ({
    paiements: {
      label: t('charts.paymentChart.payments'),
      color: 'hsl(var(--chart-1))',
    },
  } satisfies ChartConfig), [t]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<'week' | 'month' | 'year'>('month');

  useEffect(() => {
    const loadStats = async () => {
      console.log('Loading stats...');
      setLoading(true);
      const data = await fetchPaymentStatistics();
      console.log('Fetched stats:', data);
      if (data) {
        setStats(data);
      }
      setLoading(false);
    };
    loadStats();
  }, [fetchPaymentStatistics]);

  const getData = () => {
    if (!stats) return [];
    console.log('Selected period:', selectedPeriod);
    console.log('Stats:', stats);
    switch (selectedPeriod) {
      case 'week': return stats.weeklyData;
      case 'month': return stats.monthlyData;
      case 'year': return stats.yearlyData;
      default: return stats.monthlyData;
    }
  };

  const formatValue = (value: number) => {
    return `${value} DA`;
  };

  const getTitle = () => {
    switch (selectedPeriod) {
      case 'week': return t('charts.paymentChart.weekTitle');
      case 'month': return t('charts.paymentChart.monthTitle');
      case 'year': return t('charts.paymentChart.yearTitle');
      default: return t('charts.paymentChart.title');
    }
  };

  const getFullPeriodName = (period: string) => {
    if (selectedPeriod === 'week') {
      const dayMap: Record<string, string> = {
        'Lun': t('daysFull.monday'),
        'Mar': t('daysFull.tuesday'),
        'Mer': t('daysFull.wednesday'),
        'Jeu': t('daysFull.thursday'),
        'Ven': t('daysFull.friday'),
        'Sam': t('daysFull.saturday'),
        'Dim': t('daysFull.sunday'),
      };
      return dayMap[period] || period;
    } else if (selectedPeriod === 'month') {
      const monthMap: Record<string, string> = {
        'Jan': t('monthsFull.january'),
        'Fév': t('monthsFull.february'),
        'Mar': t('monthsFull.march'),
        'Avr': t('monthsFull.april'),
        'Mai': t('monthsFull.may'),
        'Jui': t('monthsFull.june'),
        'Juil': t('monthsFull.july'),
        'Août': t('monthsFull.august'),
        'Sep': t('monthsFull.september'),
        'Oct': t('monthsFull.october'),
        'Nov': t('monthsFull.november'),
        'Déc': t('monthsFull.december'),
      };
      return monthMap[period] || period;
    }
    return period; // For years, return as is
  };

  const Modal = () => (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
      onClick={() => setIsModalOpen(false)}
    >

      <div
        className="p-6 m-4 bg-white dark:bg-gray-800 rounded-lg shadow-xl"
        style={{ width: '80vw', height: '70vh', maxWidth: '1000px' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">{getTitle()}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{t('charts.paymentChart.detailedView')}</p>
          </div>
          <button
            onClick={() => setIsModalOpen(false)}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <XMarkIcon className="w-6 h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Sélecteur de période dans la modal */}
        <div className="flex bg-gray-100 dark:bg-gray-700 rounded-lg p-1 mb-6 w-fit">
          <button
            onClick={() => setSelectedPeriod('week')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'week'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.paymentChart.periodWeek')}
          </button>
          <button
            onClick={() => setSelectedPeriod('month')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'month'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.paymentChart.periodMonth')}
          </button>
          <button
            onClick={() => setSelectedPeriod('year')}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedPeriod === 'year'
              ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
              : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
          >
            {t('charts.paymentChart.periodYear')}
          </button>
        </div>

        <div style={{ height: 'calc(100% - 140px)', width: '100%' }} dir='ltr'>
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            <ChartContainer config={chartConfig} className="h-full w-full">
              <AreaChart data={getData()} margin={{ top: 30, right: 40, left: 20, bottom: 20 }}>
                <defs>
                  <linearGradient id="fillPaiementsModal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4a69ff" stopOpacity={0.8} />
                    <stop offset="95%" stopColor={theme === 'dark' ? '#1f2937' : '#a155ff'} stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <XAxis
                  dataKey="period"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={12}
                  tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tickMargin={28}
                  tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                  tickFormatter={formatValue}
                  width={80}
                />
                <ChartTooltip
                  content={<ChartTooltipContent
                    formatter={(value) => [formatValue(Number(value)), ` ${t('charts.paymentChart.payments')}`]}
                    labelFormatter={(label) => getFullPeriodName(String(label))}
                    className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                    labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                  />}
                />
                <Area
                  dataKey="paiements"
                  type="monotone"
                  fill="url(#fillPaiementsModal)"
                  fillOpacity={0.6}
                  stroke="#4a69ff"
                  strokeWidth={3}
                  dot={{ fill: '#4a69ff', strokeWidth: 3, stroke: '#fff', r: 6 }}
                >
                  <LabelList
                    dataKey="paiements"
                    position="top"
                    formatter={(value) => formatValue(Number(value))}
                    style={{
                      fontSize: '12px',
                      fontWeight: 'bold',
                      fill: theme === 'dark' ? '#9ca3af' : '#374151'
                    }}
                    offset={10}
                  />
                </Area>
              </AreaChart>
            </ChartContainer>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <>
      {isModalOpen && typeof window !== 'undefined' && createPortal(<Modal />, document.body)}

      <div
        className="h-[400px] dashboard-chart-container"
        style={{
          padding: '0',
          margin: '0',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* En-tête avec titre et sélecteur */}
        <div className="flex items-center justify-between md:p-4 pb-2">
          <div className="flex flex-1 md:flex-none items-center justify-between gap-3 ">
            <h3 className="text-sm font-semibold text-gray-800 dark:text-gray-100">{t('charts.paymentChart.title')}</h3>

            {/* Sélecteur de période compact */}
            <div className="flex bg-gray-100 dark:bg-gray-700 rounded-md p-0.5">
              <button
                onClick={() => setSelectedPeriod('week')}
                className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'week'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                  }`}
              >
                {t('charts.paymentChart.periodWeekShort')}
              </button>
              <button
                onClick={() => setSelectedPeriod('month')}
                className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'month'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                  }`}
              >
                {t('charts.paymentChart.periodMonthShort')}
              </button>
              <button
                onClick={() => setSelectedPeriod('year')}
                className={`px-2 py-1 text-xs font-medium rounded transition-all ${selectedPeriod === 'year'
                  ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-gray-100 shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-gray-100'
                  }`}
              >
                {t('charts.paymentChart.periodYearShort')}
              </button>
            </div>
          </div>

          <ArrowTopRightOnSquareIcon
            className="w-4 h-4 text-gray-400 cursor-pointer hover:text-gray-600 dark:hover:text-gray-300 hidden md:block"
            onClick={() => setIsModalOpen(true)}
          />
        </div>

        {/* Container du graphique */}
        <div
          className="relative flex-1 w-full overflow-x-auto"
          style={{
            padding: isMobile ? '0 0px 0px' : '0 16px 16px',
            minHeight: '300px'
          }}
          dir="ltr"
        >
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500"></div>
            </div>
          ) : (
            <ChartContainer config={chartConfig} className="h-full min-w-[900px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={getData()} margin={{ top: 30, right: 40, left: 20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="fillPaiementsModal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4a69ff" stopOpacity={0.8} />
                      <stop offset="95%" stopColor={theme === 'dark' ? '#1f2937' : '#a155ff'} stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="period"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={12}
                    tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={28}
                    tick={{ fontSize: 14, fill: theme === 'dark' ? '#9ca3af' : '#4b5563' }}
                    tickFormatter={formatValue}
                    width={80}
                  />
                  <ChartTooltip
                    content={<ChartTooltipContent
                      formatter={(value) => [formatValue(Number(value)), ` ${t('charts.paymentChart.payments')}`]}
                      labelFormatter={(label) => getFullPeriodName(String(label))}
                      className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 shadow-lg"
                      labelClassName="font-semibold text-gray-900 dark:text-gray-100"
                    />}
                  />
                  <Area
                    dataKey="paiements"
                    type="monotone"
                    fill="url(#fillPaiementsModal)"
                    fillOpacity={0.6}
                    stroke="#4a69ff"
                    strokeWidth={3}
                    dot={{ fill: '#4a69ff', strokeWidth: 3, stroke: '#fff', r: 6 }}
                  >
                    <LabelList
                      dataKey="paiements"
                      position="top"
                      formatter={(value) => formatValue(Number(value))}
                      style={{
                        fontSize: '12px',
                        fontWeight: 'bold',
                        fill: theme === 'dark' ? '#9ca3af' : '#374151'
                      }}
                      offset={10}
                    />
                  </Area>
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          )}
        </div>
      </div>
    </>
  );
}