'use client';

import { XMarkIcon } from '@heroicons/react/24/outline';

interface PopupProps {
    onClose: () => void;
    title: string;
    children: React.ReactNode;
}


export default function Popup({ onClose, title, children }) {
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-[100] flex justify-center items-center">
      <div className="w-full max-w-md p-6 mx-4 bg-white rounded-lg shadow-xl sm:mx-0">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 transition-colors hover:text-gray-600"
          >
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>
        <div className="text-gray-700">
          {children}
        </div>
      </div>
    </div>
  );
}