'use client';
import { useWaitingRoom } from '@/contexts/WaitingRoomContext';
import { useLanguage } from '@/contexts/LanguageContext';
import Link from 'next/link';
import { ChevronRightIcon, CalendarIcon, ClockIcon, UserGroupIcon } from '@heroicons/react/24/solid';
import { useRef } from 'react';

export default function RecentPatients() {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { t } = useLanguage();

  const { schedule, loading } = useWaitingRoom();

  // Map schedule to display rows with badges and enhanced info
  const scheduleRows = (schedule || []).map((item, idx) => {
    if ((item as any).type === 'appointment') {
      const a: any = (item as any).appointment || {};
      const name = `${a.patient_name || ''} ${a.patient_family_name || ''}`.trim() || a.patient_id || 'Patient';
      const time = (a.time || '').slice(0, 5);
      return {
        key: `appt-${a.id || idx}`,
        name,
        href: a.patient_id ? `/patients/${a.patient_id}` : '#',
        time: time || '',
        type: 'appointment',
        badgeText: t('badges.appointment'),
        badgeClass: 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300',
        icon: CalendarIcon,
        iconColor: 'text-blue-600 dark:text-blue-400',
      };
    } else {
      const w: any = (item as any).waiting || {};
      const name = `${w.patient_name || ''} ${w.patient_family_name || ''}`.trim() || w.patient_id || 'Patient';
      return {
        key: `wait-${w.id || idx}`,
        name,
        href: w.patient_id ? `/patients/${w.patient_id}` : '#',
        time: '',
        type: 'waiting',
        badgeText: t('badges.waiting'),
        badgeClass: 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300',
        icon: UserGroupIcon,
        iconColor: 'text-amber-600 dark:text-amber-400',
      };
    }
  });

  return (
    <div ref={containerRef} className="bg-white dark:bg-gray-800 rounded-lg p-5 shadow-sm h-full flex flex-col border border-gray-200 dark:border-gray-700">
      <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">{t('dashboard.passageOrder')}</h3>

      <div ref={contentRef} className="space-y-2 flex-grow flex flex-col justify-start overflow-y-auto overflow-x-hidden max-h-[400px]">
        {scheduleRows.length > 0 ? (
          scheduleRows.map((row, index) => {
            const Icon = row.icon;
            const isFirst = index === 0;
            return (
              <Link key={row.key} href={row.href} passHref>
                <div className={`relative flex items-center gap-3 p-3 rounded-lg cursor-pointer group transition-all ${
                  isFirst
                    ? 'bg-green-50 dark:bg-green-900/20 border-2 border-green-500 dark:border-green-600 shadow-md hover:shadow-lg'
                    : 'bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}>
                  {/* Numéro d'ordre */}
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                    isFirst
                      ? 'bg-green-500 text-white shadow-md'
                      : 'bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300'
                  }`}>
                    {index + 1}
                  </div>

                  {/* Icône de type */}
                  <div className="flex-shrink-0">
                    <Icon className={`w-5 h-5 ${row.iconColor}`} />
                  </div>

                  {/* Informations patient */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`font-semibold truncate ${
                        isFirst
                          ? 'text-green-900 dark:text-green-100'
                          : 'text-gray-900 dark:text-gray-100'
                      }`}>
                        {row.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${row.badgeClass}`}>
                        {row.badgeText}
                      </span>
                      {row.time && (
                        <div className="flex items-center gap-1 text-xs text-gray-600 dark:text-gray-400">
                          <ClockIcon className="w-3 h-3" />
                          <span>{row.time}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Flèche */}
                  <ChevronRightIcon className={`w-5 h-5 flex-shrink-0 ${
                    isFirst
                      ? 'text-green-600 dark:text-green-400'
                      : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-600 dark:group-hover:text-gray-300'
                  }`} />

                  {/* Badge "À venir" pour le premier */}
                  {isFirst && (
                    <div className="absolute top-1 right-1 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                      {t('dashboard.nextPatient')}
                    </div>
                  )}
                </div>
              </Link>
            );
          })
        ) : (
          <div className="py-6 text-center text-gray-500">
            <p className="mt-2">{t('dashboard.noScheduleData')}</p>
          </div>
        )}
      </div>
    </div>
  );
}