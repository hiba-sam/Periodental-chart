'use client';

import React from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

interface MiniMonthProps {
	activeDate: Date;
	onChangeMonth: (date: Date) => void;
	onSelectDate: (date: Date) => void;
}

interface CalendarDay { day: number; currentMonth: boolean; date: Date }

const daysOfWeek = ['S', 'D', 'L', 'M', 'M', 'J', 'V'];

const buildMonth = (date: Date): CalendarDay[] => {
	const year = date.getFullYear();
	const month = date.getMonth();
	const first = new Date(year, month, 1);
	// Week starts Saturday; JS getDay() returns 0=Sunday, 6=Saturday
	// Calculate offset: Saturday=0, Sunday=1, Monday=2, etc.
	const startOffset = (first.getDay() + 1) % 7;
	const daysInMonth = new Date(year, month + 1, 0).getDate();
	const prevMonthDays = new Date(year, month, 0).getDate();
	const cells: CalendarDay[] = [];
	for (let i = startOffset - 1; i >= 0; i--) {
		cells.push({ day: prevMonthDays - i, currentMonth: false, date: new Date(year, month - 1, prevMonthDays - i) });
	}
	for (let d = 1; d <= daysInMonth; d++) {
		cells.push({ day: d, currentMonth: true, date: new Date(year, month, d) });
	}
	while (cells.length % 7 !== 0) {
		const nextIndex = cells.length - (startOffset + daysInMonth) + 1;
		cells.push({ day: nextIndex, currentMonth: false, date: new Date(year, month + 1, nextIndex) });
	}
	return cells;
};

export default function MiniMonth({ activeDate, onChangeMonth, onSelectDate }: MiniMonthProps) {
	const { locale } = useLanguage();
	const monthLabel = activeDate.toLocaleDateString(locale, { month: 'long', year: 'numeric' });
	const cells = buildMonth(activeDate);
	const today = new Date();

	return (
		<div className="bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-3xl">
			<div className="flex items-center justify-between px-3 py-2 border-b dark:border-gray-700">
				<div className="inline-flex items-center gap-1">
					<button className="w-7 h-7 rounded border dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700" aria-label="Précédent" onClick={() => onChangeMonth(new Date(activeDate.getFullYear(), activeDate.getMonth() - 1, 1))}>◀</button>
					<button className="w-7 h-7 rounded border dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700" onClick={() => onChangeMonth(new Date())}>•</button>
					<button className="w-7 h-7 rounded border dark:border-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700" aria-label="Suivant" onClick={() => onChangeMonth(new Date(activeDate.getFullYear(), activeDate.getMonth() + 1, 1))}>▶</button>
				</div>
				<div className="text-sm font-medium capitalize text-gray-900 dark:text-gray-100">{monthLabel}</div>
			</div>
			<div className="px-3 py-2">
				<div className="grid grid-cols-7 text-center text-[11px] text-gray-500 dark:text-gray-400 mb-1">
					{daysOfWeek.map((d, i) => <div key={i}>{d}</div>)}
				</div>
				<div className="grid grid-cols-7 gap-1">
					{cells.map((c, i) => {
						const isToday = c.date.toDateString() === today.toDateString();
						const isActive = c.date.toDateString() === activeDate.toDateString();
						return (
							<button
								key={i}
								onClick={() => onSelectDate(c.date)}
								className={`h-8 text-xs flex items-center justify-center transition-colors 
									${c.currentMonth ? 'text-gray-800 dark:text-gray-200' : 'text-gray-400 dark:text-gray-600'}
									${isActive ? 'bg-blue-600 text-white rounded-full' : isToday ? 'rounded-full border border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400' : 'rounded hover:bg-gray-50 dark:hover:bg-gray-700 border border-transparent'}`}
							>
								{c.day}
							</button>
						);
					})}
				</div>
			</div>
		</div>
	);
}


