'use client';

import React from 'react';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';

type CalendarView = 'day' | 'week' | 'month';


interface CalendarHeaderProps {
	currentLabel: string;
	onPrev: () => void;
	onNext: () => void;
	onToday: () => void;
	view: CalendarView;
	onViewChange: (view: CalendarView) => void;
	hideViewTabs?: boolean;
}

const tabs: Array<{ key: CalendarView; label: string }> = [
	{ key: 'day', label: 'Journée' },
	{ key: 'week', label: 'Semaine' },
	{ key: 'month', label: 'Mois' }
];

export default function CalendarHeader({ currentLabel, onPrev, onNext, onToday, view, onViewChange, hideViewTabs }: CalendarHeaderProps) {
	return (
		<div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
			<div className="flex items-center gap-3">
				{/* Bouton Précédent */}
				<button
					className="p-2 rounded-lg border border-gray-300 dark:border-gray-600 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 transition-all duration-200 shadow-sm hover:shadow-md group"
					onClick={onPrev}
					aria-label="Mois précédent"
				>
					<ChevronLeft className="w-5 h-5 text-gray-600 dark:text-gray-300 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
				</button>

				{/* Bouton Aujourd'hui */}
				<button
					className="px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 transition-all duration-200 shadow-sm hover:shadow-md font-medium text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-2"
					onClick={onToday}
				>
					<Calendar className="w-4 h-4" />
					Aujourd'hui
				</button>

				{/* Bouton Suivant */}
				<button
					className="p-2 rounded-lg border border-gray-300 dark:border-gray-600 hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30 transition-all duration-200 shadow-sm hover:shadow-md group"
					onClick={onNext}
					aria-label="Mois suivant"
				>
					<ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-300 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors" />
				</button>

				{/* Label du mois/date */}
				<h2 className="ml-2 text-xl font-semibold text-gray-800 dark:text-gray-100">{currentLabel}</h2>
			</div>
			{!hideViewTabs && (
				<div className="inline-flex rounded-md border dark:border-gray-600 bg-white dark:bg-gray-800 overflow-hidden">
					{tabs.map(t => (
						<button
							key={t.key}
							className={`px-4 py-2 text-sm ${view === t.key ? 'bg-blue-600 text-white' : 'text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700'}`}
							onClick={() => onViewChange(t.key)}
						>
							{t.label}
						</button>
					))}
				</div>
			)}
		</div>
	);
}


