'use client';

import { Appointment } from '@/contexts/AppointmentContext';
import React from 'react';


interface WeekGridProps {
	weekStart: Date; // Monday of week
	appointments: Appointment[];
	onSlotClick?: (date: Date) => void;
}

const addDays = (date: Date, days: number) => {
	const d = new Date(date);
	d.setDate(d.getDate() + days);
	return d;
};

const hours = Array.from({ length: 12 }, (_, i) => 8 + i); // 8..19

const dayLabel = (date: Date) => date.toLocaleDateString('fr-FR', { weekday: 'short', day: '2-digit', month: '2-digit' });

const toMinutes = (t: string) => {
	const [h, m] = t.split(':').map(Number);
	return h * 60 + m;
};

export default function WeekGrid({ weekStart, appointments, onSlotClick }: WeekGridProps) {
	const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

	const matchesDay = (a: Appointment, d: Date) => {
		const aDate = new Date(a.date);
		return aDate.getFullYear() === d.getFullYear() && aDate.getMonth() === d.getMonth() && aDate.getDate() === d.getDate();
	};

	return (
		<div className="w-full overflow-x-auto">
			<div className="grid text-[13px]" style={{ gridTemplateColumns: '64px repeat(7, minmax(180px, 1fr))' }}>
				<div></div>
				{days.map((d, i) => (
					<div key={i} className="px-2 py-2 font-medium text-gray-700 dark:text-gray-300 text-center border-b dark:border-gray-700">
						{dayLabel(d)}
					</div>
				))}
				{hours.map((h) => (
					<React.Fragment key={h}>
						<div className="h-20 border-r dark:border-gray-700 pr-2 text-[11px] text-right text-gray-500 dark:text-gray-400 flex items-start pt-2">{`${h.toString().padStart(2, '0')}:00`}</div>
						{days.map((d, di) => {
							const dayAppointments = appointments.filter(a => matchesDay(a, d));
							return (
								<div key={`${h}-${di}`} className="relative h-20 border dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer" onClick={() => onSlotClick && onSlotClick(d)}>
									{dayAppointments.map(a => {
										const startMinutes = toMinutes(a.time);
										const startHour = Math.floor(startMinutes / 60);
										if (startHour !== h) return null; // render only in the starting hour cell

										const minutesFromHourStart = startMinutes - h * 60;
										const top = (minutesFromHourStart / 60) * 100; // percent within current hour
										const height = Math.min((a.duration || 15), 60 - minutesFromHourStart) / 60 * 100; // clamp within hour cell
										return (
											<div key={a.id} className={`absolute left-1 right-1 text-white rounded-md px-2 py-1 text-[11px] overflow-hidden shadow`}

												style={{ top: `${top}%`, height: `${height}%`, backgroundColor: a.color || '#2563eb' }}>
												{a.time} • {a.patientName || 'RDV'}
											</div>
										);
									})}
								</div>
							);
						})}
					</React.Fragment>
				))}
			</div>
		</div>
	);
}



