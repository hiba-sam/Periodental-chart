/**
 * DroppableSlot.tsx
 *
 * Wrapper component for time slots that can receive dropped events.
 * Provides visual feedback when hovering with a dragged event.
 */

import React from 'react';
import { useDroppable } from '@dnd-kit/core';

interface DroppableSlotProps {
  id: string;
  children: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  disabled?: boolean;
}

/**
 * Makes a time slot droppable for calendar events
 *
 * CRITICAL: The wrapper div MUST have measurable dimensions for @dnd-kit collision detection.
 * We ensure this by NOT using position:absolute on the wrapper itself.
 * Instead, we position it relatively or statically so it has actual width/height.
 */
export const DroppableSlot: React.FC<DroppableSlotProps> = ({
  id,
  children,
  className = '',
  style = {},
  disabled = false,
}) => {
  const { setNodeRef, isOver } = useDroppable({
    id,
    disabled,
    data: {
      type: 'calendar-slot',
      slotId: id, // Store ID in data for debugging
    },
  });

  // Add visual feedback when hovering
  const dropStyle: React.CSSProperties = {
    ...style,
    backgroundColor: isOver
      ? 'rgba(59, 130, 246, 0.2)' // Blue highlight
      : style.backgroundColor,
    transition: 'background-color 150ms ease',
  };

  return (
    <div
      ref={setNodeRef}
      className={className}
      style={dropStyle}
    >
      {children}
    </div>
  );
};
