'use client';

import React, { useState, useMemo } from 'react';
import { useCalendar, type CalendarEvent } from '@/contexts/CalendarContext';
import EventModal from './EventModal';
import EventDetailsPanel from './EventDetailsPanel';
import DeleteConfirmModal from './DeleteConfirmModal';
import { XMarkIcon, PlusIcon } from '@heroicons/react/24/outline';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface TimeSlot {
  hour: number;
  minute: number;
  label: string;
}

interface DayViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date;
}

// ============================================================================
// CONSTANTS
// ============================================================================

const HOURS_START = 8; // 8:00 AM
const HOURS_END = 31; // 7:00 AM next day (8 + 24 - 1)
const SLOT_HEIGHT = 60; // pixels per hour
const EVENT_MIN_HEIGHT = 30; // minimum height for event blocks
const EVENT_COMPACT_HEIGHT = 28; // compact fixed height for events

// Color palette with transparency for event blocks
const COLOR_VARIANTS: Record<string, { bg: string; border: string; text: string }> = {
  '#2563eb': { bg: 'rgba(37, 99, 235, 0.15)', border: '#2563eb', text: '#1e40af' },
  '#10b981': { bg: 'rgba(16, 185, 129, 0.15)', border: '#10b981', text: '#047857' },
  '#ef4444': { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#b91c1c' },
  '#f59e0b': { bg: 'rgba(245, 158, 11, 0.15)', border: '#f59e0b', text: '#d97706' },
  '#8b5cf6': { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#6d28d9' },
  '#6b7280': { bg: 'rgba(107, 114, 128, 0.15)', border: '#6b7280', text: '#4b5563' },
};

// ============================================================================
// COMPONENT
// ============================================================================

export const DayViewModal: React.FC<DayViewModalProps> = ({ isOpen, onClose, selectedDate }) => {
  const { getEventsForDate, selectEvent, selectedEvent, deleteEvent } = useCalendar();

  // ============================================================================
  // LOCAL STATE
  // ============================================================================

  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [modalInitialTime, setModalInitialTime] = useState<string | undefined>();
  const [editingEvent, setEditingEvent] = useState<CalendarEvent | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // ============================================================================
  // UTILITY FUNCTIONS
  // ============================================================================

  const isToday = (date: Date): boolean => {
    const today = new Date();
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    );
  };

  const isPast = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return date < today;
  };

  const timeToMinutes = (time: string): number => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const isTimeSlotPast = (date: Date, hour: number): boolean => {
    const now = new Date();
    const slotDate = new Date(date);

    // Handle hours beyond 23 (next day)
    if (hour >= 24) {
      slotDate.setDate(slotDate.getDate() + 1);
      slotDate.setHours(hour - 24, 0, 0, 0);
    } else {
      slotDate.setHours(hour, 0, 0, 0);
    }

    return slotDate < now;
  };

  const getEventStyle = (event: CalendarEvent) => {
    const startMinutes = timeToMinutes(event.time);
    let offsetMinutes = startMinutes - HOURS_START * 60;

    // Handle events in the early morning (00:00 - 07:59) - they should appear at the bottom
    if (startMinutes < HOURS_START * 60) {
      offsetMinutes = (24 * 60) + startMinutes - HOURS_START * 60;
    }

    const top = (offsetMinutes / 60) * SLOT_HEIGHT;

    return {
      top: `${top}px`,
      height: `${EVENT_COMPACT_HEIGHT}px`,
    };
  };

  const getEventColors = (color: string) => {
    return COLOR_VARIANTS[color] || COLOR_VARIANTS['#2563eb'];
  };

  // ============================================================================
  // COMPUTED DATA
  // ============================================================================

  const timeSlots: TimeSlot[] = useMemo(() => {
    const slots: TimeSlot[] = [];
    for (let i = 0; i < 24; i++) {
      const hour = (HOURS_START + i) % 24;
      slots.push({
        hour: HOURS_START + i,
        minute: 0,
        label: `${String(hour).padStart(2, '0')}:00`,
      });
    }
    return slots;
  }, []);

  const dayEvents = useMemo(() => {
    return getEventsForDate(selectedDate);
  }, [selectedDate, getEventsForDate]);

  const dateLabel = useMemo(() => {
    return selectedDate.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }, [selectedDate]);

  const dayIsPast = isPast(selectedDate);
  const dayIsToday = isToday(selectedDate);

  // ============================================================================
  // EVENT HANDLERS
  // ============================================================================

  const handleSlotClick = (hour: number) => {
    if (isTimeSlotPast(selectedDate, hour)) {
      return;
    }

    const actualHour = hour >= 24 ? hour - 24 : hour;
    const time = `${String(actualHour).padStart(2, '0')}:00`;
    setEditingEvent(null);
    setModalInitialTime(time);
    setIsEventModalOpen(true);
  };

  const handleEventClick = (event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    selectEvent(event);
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setEditingEvent(event);
    setModalInitialTime(undefined);
    setIsEventModalOpen(true);
  };

  const handleDeleteEventClick = (event: CalendarEvent) => {
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!selectedEvent) return;

    setIsDeleting(true);
    try {
      const success = await deleteEvent(selectedEvent.id);
      if (success) {
        setIsDeleteModalOpen(false);
        selectEvent(null);
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const handleEventModalClose = () => {
    setIsEventModalOpen(false);
    setEditingEvent(null);
    setModalInitialTime(undefined);
  };

  const handleCreateAppointment = () => {
    setEditingEvent(null);
    setModalInitialTime(undefined);
    setIsEventModalOpen(true);
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={onClose} />

      {/* Modal */}
      <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-6xl max-h-[90vh] flex flex-col">
          {/* Modal Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div>
              <h2 className={`text-2xl font-bold capitalize ${dayIsToday ? 'text-blue-600' : 'text-gray-800'}`}>
                {dateLabel}
              </h2>
              {dayIsToday && <p className="text-sm text-blue-600 mt-1">Aujourd'hui</p>}
              {dayEvents.length > 0 && (
                <p className="text-sm text-gray-600 mt-1">
                  {dayEvents.length} rendez-vous
                </p>
              )}
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handleCreateAppointment}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm"
              >
                <PlusIcon className="w-5 h-5" />
                Nouveau rendez-vous
              </button>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <XMarkIcon className="w-6 h-6 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-hidden flex">
            {/* Day View Grid */}
            <div className="flex-1 overflow-y-auto p-6">
              <div className="relative">
                <div className="grid grid-cols-[80px_1fr]">
                  {/* Time labels column */}
                  <div className="border-r border-gray-200 bg-gray-50 relative z-10">
                    {timeSlots.map((slot) => (
                      <div
                        key={slot.hour}
                        className="relative text-sm font-medium text-gray-600 text-right pr-3"
                        style={{ height: `${SLOT_HEIGHT}px`, lineHeight: `${SLOT_HEIGHT}px` }}
                      >
                        {slot.label}
                      </div>
                    ))}
                  </div>

                  {/* Day column with events */}
                  <div className="relative">
                    {/* Time slot cells */}
                    {timeSlots.map((slot) => {
                      const slotIsPast = isTimeSlotPast(selectedDate, slot.hour);

                      return (
                        <div
                          key={slot.hour}
                          className="relative"
                          style={{ height: `${SLOT_HEIGHT}px` }}
                        >
                          {/* Clickable slot - first half (0-30 min) */}
                          <div
                            className={`
                              absolute top-0 left-0 right-0 transition-colors
                              ${slotIsPast ? 'bg-gray-100 cursor-not-allowed' : 'bg-white cursor-pointer hover:bg-blue-50'}
                            `}
                            style={{ height: `${SLOT_HEIGHT / 2}px` }}
                            onClick={() => !slotIsPast && handleSlotClick(slot.hour)}
                          />

                          {/* Clickable slot - second half (30-60 min) */}
                          <div
                            className={`
                              absolute left-0 right-0 transition-colors
                              ${slotIsPast ? 'bg-gray-100 cursor-not-allowed' : 'bg-white cursor-pointer hover:bg-blue-50'}
                            `}
                            style={{ top: `${SLOT_HEIGHT / 2}px`, height: `${SLOT_HEIGHT / 2}px` }}
                            onClick={() => !slotIsPast && handleSlotClick(slot.hour)}
                          />
                        </div>
                      );
                    })}

                    {/* Event blocks (absolute positioned) */}
                    <div className="absolute top-0 left-0 right-0 pointer-events-none px-2 z-20">
                      {dayEvents.map((event) => {
                        const style = getEventStyle(event);
                        const colors = getEventColors(event.color);
                        const isSelected = selectedEvent?.id === event.id;

                        return (
                          <div
                            key={event.id}
                            className={`
                              absolute left-2 right-2 rounded-md border-l-4 px-2 py-1 cursor-pointer
                              transition-all duration-150 pointer-events-auto overflow-hidden
                              ${isSelected ? 'ring-2 ring-blue-500 shadow-lg' : 'shadow-sm hover:shadow-md'}
                            `}
                            style={{
                              ...style,
                              backgroundColor: colors.bg,
                              borderLeftColor: colors.border,
                            }}
                            onClick={(e) => handleEventClick(event, e)}
                            title={`${event.time} - ${event.endTime}: ${event.title}`}
                          >
                            {/* Compact event display */}
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] font-bold whitespace-nowrap" style={{ color: colors.text }}>
                                {event.time}
                              </span>
                              <span className="text-[11px] font-medium truncate flex-1" style={{ color: colors.text }}>
                                {event.title}
                              </span>
                              {/* Status indicator dots */}
                              {event.venueConfirmed && (
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500 flex-shrink-0" title="Confirmé" />
                              )}
                              {event.isDone && (
                                <span className="w-1.5 h-1.5 rounded-full bg-gray-500 flex-shrink-0" title="Terminé" />
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Horizontal grid lines */}
                <div className="absolute inset-0 pointer-events-none" style={{ left: '80px' }}>
                  {timeSlots.map((slot, index) => (
                    <React.Fragment key={slot.hour}>
                      {/* Solid hour line */}
                      <div
                        className="absolute left-0 right-0 border-t border-gray-400"
                        style={{ top: `${index * SLOT_HEIGHT}px` }}
                      />
                      {/* Dashed 30-minute line */}
                      <div
                        className="absolute left-0 right-0 border-t border-dashed border-gray-300"
                        style={{ top: `${index * SLOT_HEIGHT + SLOT_HEIGHT / 2}px` }}
                      />
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* No events message */}
              {dayEvents.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="text-center">
                    <div className="text-gray-400 text-5xl mb-4">📅</div>
                    <p className="text-gray-500 text-lg font-medium">Aucun rendez-vous ce jour</p>
                    <p className="text-gray-400 text-sm mt-2">
                      Cliquez sur un créneau horaire pour créer un rendez-vous
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Event Details Sidebar */}
            {selectedEvent && (
              <div className="w-80 border-l border-gray-200 p-6 overflow-y-auto bg-gray-50">
                <EventDetailsPanel
                  event={selectedEvent}
                  onEdit={handleEditEvent}
                  onDelete={handleDeleteEventClick}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Event Create/Edit Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={handleEventModalClose}
        initialDate={selectedDate}
        initialTime={modalInitialTime}
        editEvent={editingEvent}
        hideDateInput={true}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        event={selectedEvent}
        isDeleting={isDeleting}
      />
    </>
  );
};

export default DayViewModal;
