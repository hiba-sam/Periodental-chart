'use client';

import React from 'react';
import DayScheduler from '@/components/appointments/DayScheduler';

interface DayViewProps {
	date: Date;
	existingAppointments: any[];
	onTimeSlotSelect: (startTime: string, endTime: string) => void;
	onAppointmentDeleted?: () => void;
	onAppointmentEdit?: (appointment: any) => void;
}

export default function DayView({ date, existingAppointments, onTimeSlotSelect, onAppointmentDeleted, onAppointmentEdit }: DayViewProps) {
	return (
		<div className="bg-gray-50 rounded-lg border border-gray-200 p-4 h-[600px] flex flex-col">
			<DayScheduler
				selectedDate={date}
				onTimeSlotSelect={onTimeSlotSelect}
				existingAppointments={existingAppointments}
				onAppointmentDeleted={onAppointmentDeleted}
				onAppointmentEdit={onAppointmentEdit}
			/>
		</div>
	);
}

