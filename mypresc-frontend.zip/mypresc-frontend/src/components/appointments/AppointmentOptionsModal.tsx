'use client';

import { useState, useEffect } from 'react';
import { XMarkIcon, PhoneIcon, PencilIcon, TrashIcon } from '@heroicons/react/24/outline';
import { Appointment, useAppointments } from '@/contexts/AppointmentContext';
import { usePatients, ApiPatient } from '@/contexts/PatientsContext';


interface AppointmentOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointment: Appointment | null;
  onEdit: (appointment: Appointment) => void;
  onDelete: (appointment: Appointment) => void;
}

export default function AppointmentOptionsModal({
  isOpen,
  onClose,
  appointment,
  onEdit,
  onDelete
}: AppointmentOptionsModalProps) {
  const { getPatient } = usePatients();
  const { updateAppointment } = useAppointments();
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [showNotifyConfirmation, setShowNotifyConfirmation] = useState(false);
  const [patientData, setPatientData] = useState<ApiPatient | null>(null);
  const [isLoadingPatient, setIsLoadingPatient] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!appointment) return;
      setIsLoadingPatient(true);
      try {
        if (appointment.patient_id) {
          const p = await getPatient(appointment.patient_id);
          setPatientData(p || null);
        } else {
          setPatientData(null);
        }
      } finally {
        setIsLoadingPatient(false);
      }
    };
    if (isOpen) load();
  }, [isOpen, appointment]);

  if (!isOpen || !appointment) return null;

  const getPatientFullName = () => {
    if (isLoadingPatient) return 'Chargement...';
    if (patientData) return `${patientData.name} ${patientData.family_name}`;
    return 'Inconnu';
  };

  const getPatientPhone = () => {
    if (isLoadingPatient) return 'Chargement...';
    const phone = patientData?.telephone;
    if (!phone) return 'Non disponible';
    return phone.length === 10 ? phone.replace(/(.{2})(?=.)/g, '$1 ') : phone;
  };

  const handleDelete = () => {
    // Supprimer le rendez-vous
    onDelete(appointment);

    // Attendre un court instant pour que la suppression soit prise en compte
    setTimeout(() => {
      // Passer à la fenêtre de contact du patient
      setShowDeleteConfirmation(false);
      setShowNotifyConfirmation(true);
    }, 50);
  };

  const handleEdit = () => {
    onEdit(appointment);
    onClose();
  };

  const handleNotifyConfirm = () => {
    // Ici, on pourrait intégrer une API d'envoi de SMS
    // Pour l'instant, on ferme simplement la fenêtre
    setShowNotifyConfirmation(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70">
      <div
        className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl w-full max-w-3xl mx-4 transform transition-all animate-fadeIn border border-gray-300 dark:border-gray-700"
        onClick={(e) => e.stopPropagation()}
      >
        {showNotifyConfirmation ? (
          <>
            <div className="flex justify-between items-center p-4 border-b border-gray-300 dark:border-gray-700 bg-blue-50 dark:bg-blue-900/30">
              <h2 className="text-xl font-semibold text-blue-700 dark:text-blue-300">
                Notifier le patient
              </h2>
              <button
                type="button"
                className="text-gray-600 hover:text-gray-800 focus:outline-none"
                onClick={onClose}
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <div className="flex items-center mb-4 text-blue-600 dark:text-blue-400">
                  <PhoneIcon className="h-6 w-6 mr-2" />
                  <span className="font-medium">Contacter le patient</span>
                </div>

                <p className="text-gray-700 dark:text-gray-300 mb-4">
                  Le rendez-vous a été supprimé. Souhaitez-vous informer le patient de cette annulation ?
                </p>

                <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 mb-4">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Informations de contact :</h3>
                  <p><span className="font-medium">Patient :</span> {getPatientFullName()}</p>
                  <p><span className="font-medium">Téléphone :</span> {getPatientPhone()}</p>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  type="button"
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  onClick={handleNotifyConfirm}
                >
                  OK
                </button>
              </div>
            </div>
          </>
        ) : showDeleteConfirmation ? (
          // Confirmation de suppression
          <>
            <div className="flex justify-between items-center p-4 border-b border-gray-300 dark:border-gray-700 bg-red-50 dark:bg-red-900/30">
              <h2 className="text-xl font-semibold text-red-700 dark:text-red-300">
                Confirmer la suppression
              </h2>
              <button
                type="button"
                className="text-gray-600 hover:text-gray-800 focus:outline-none"
                onClick={onClose}
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <p className="text-gray-800 dark:text-gray-200 mb-4">
                  Êtes-vous sûr de vouloir supprimer ce rendez-vous ?
                </p>

                <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg border border-gray-200 dark:border-gray-600">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-2">Détails du rendez-vous :</h3>
                  <ul className="space-y-2 text-sm">
                    <li><span className="font-medium">Patient :</span> {getPatientFullName()}</li>
                    <li><span className="font-medium">Date :</span> {new Date(appointment.date as any).toLocaleDateString('fr-FR')}</li>
                    <li><span className="font-medium">Heure :</span> {appointment.time}</li>
                    {appointment.notes && (
                      <li><span className="font-medium">Notes :</span> {appointment.notes}</li>
                    )}
                  </ul>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  type="button"
                  className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 font-medium"
                  onClick={handleDelete}
                >
                  OK
                </button>
              </div>
            </div>
          </>
        ) : (
          // Options principales
          <>
            <div className="flex justify-between items-center p-4 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
                Détails du rendez-vous
              </h2>
              <button
                type="button"
                className="text-gray-600 hover:text-gray-800 focus:outline-none"
                onClick={onClose}
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <div className="bg-gray-50 dark:bg-gray-700/30 p-4 rounded-lg border border-gray-200 dark:border-gray-600 mb-6">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100 mb-3">Informations du rendez-vous :</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <span className="font-medium w-24">Patient :</span>
                      <span className="flex-1">
                        {patientData ? (
                          <a href={`/patients/${patientData.id}`} className="text-blue-600 dark:text-blue-400 hover:underline">
                            {getPatientFullName()}
                          </a>
                        ) : (
                          getPatientFullName()
                        )}
                      </span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium w-24">Téléphone :</span>
                      <span className="flex-1">{getPatientPhone()}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium w-24">Date :</span>
                      <span className="flex-1">{new Date(appointment.date as any).toLocaleDateString('fr-FR')}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium w-24">Heure :</span>
                      <span className="flex-1">{appointment.time}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium w-24">Durée :</span>
                      <span className="flex-1">{appointment.duration} minutes</span>
                    </li>
                    {appointment.notes && (
                      <li className="flex items-start">
                        <span className="font-medium w-24">Notes :</span>
                        <span className="flex-1">{appointment.notes}</span>
                      </li>
                    )}
                  </ul>
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <label className="inline-flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={!!appointment.confirmed_coming}
                        onChange={async (e) => {
                          await updateAppointment(appointment.id, { confirmed_coming: e.target.checked });
                        }}
                      />
                      Confirmé
                    </label>
                    <label className="inline-flex items-center gap-2 text-sm">
                      <input
                        type="checkbox"
                        checked={!!appointment.is_done}
                        onChange={async (e) => {
                          await updateAppointment(appointment.id, { is_done: e.target.checked });
                        }}
                      />
                      Terminé
                    </label>
                    {appointment.color && (
                      <div className="flex items-center gap-2 text-sm">
                        <span className="w-4 h-4 rounded" style={{ backgroundColor: appointment.color }}></span>
                        <span className="text-gray-600">Couleur</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    className="flex items-center justify-center px-4 py-3 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-md hover:bg-blue-100 dark:hover:bg-blue-900/50 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium border border-blue-200 dark:border-blue-800"
                    onClick={handleEdit}
                  >
                    <PencilIcon className="h-5 w-5 mr-2" />
                    Modifier
                  </button>
                  <button
                    type="button"
                    className="flex items-center justify-center px-4 py-3 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 rounded-md hover:bg-red-100 dark:hover:bg-red-900/50 focus:outline-none focus:ring-2 focus:ring-red-500 font-medium border border-red-200 dark:border-red-800"
                    onClick={() => setShowDeleteConfirmation(true)}
                  >
                    <TrashIcon className="h-5 w-5 mr-2" />
                    Supprimer
                  </button>
                </div>
              </div>
            </div>
          </>
        )
        }
      </div >
    </div >
  );
}
