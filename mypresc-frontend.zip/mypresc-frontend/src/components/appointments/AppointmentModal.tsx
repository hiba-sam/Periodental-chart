"use client";

import { useState, useEffect } from "react";
import { XMarkIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import DayScheduler from "./DayScheduler";
import { usePatients, ApiPatient } from "@/contexts/PatientsContext";
import { Appointment, useAppointments } from "@/contexts/AppointmentContext";
import { useAuth } from "@/contexts/AuthContext";
import ColorSelect from "../ui/ColorSelect";

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: Date | null;
  onAppointmentAdded: () => void;
}

export default function AppointmentModal({
  isOpen,
  onClose,
  selectedDate,
  onAppointmentAdded,
}: AppointmentModalProps) {
  const { searchPatients } = usePatients();
  const { createAppointment, fetchAppointmentsByDate, updateAppointment } =
    useAppointments();
  const { user } = useAuth();
  const doctorUserId = user?.id as number | string;

  const [patientQuery, setPatientQuery] = useState("");
  const [patientResults, setPatientResults] = useState<ApiPatient[] | null>(
    null
  );
  const [searchOpen, setSearchOpen] = useState(false);
  const [patientId, setPatientId] = useState("");
  const [time, setTime] = useState("09:00");
  const [endTime, setEndTime] = useState("09:30");
  const [duration, setDuration] = useState("30");
  const [notes, setNotes] = useState("");
  const [color, setColor] = useState<string>("#2563eb");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [existingAppointments, setExistingAppointments] = useState<
    Appointment[]
  >([]);
  const [editingAppointment, setEditingAppointment] =
    useState<Appointment | null>(null);
  console.log(editingAppointment);

  // Réinitialiser le formulaire et charger les rendez-vous existants lorsque la modal s'ouvre
  useEffect(() => {
    if (isOpen && selectedDate) {
      setSearchOpen(false);
      setIsSubmitting(false);

      if (editingAppointment) {
        console.log("inside the if ", editingAppointment);
        // Prefill for edit
        setPatientId(editingAppointment.patient_id || "");
        setPatientQuery(
          `${editingAppointment.patient_family_name || ""} ${editingAppointment.patient_name || ""
            }`.trim()
        );
        setTime(editingAppointment.time || "09:00");
        const newDuration = editingAppointment.duration
          ? String(editingAppointment.duration)
          : "30";
        setDuration(newDuration);
        const startMinutes = timeToMinutes(editingAppointment.time || "09:00");
        const endMinutes = startMinutes + parseInt(newDuration);
        const hours = Math.floor(endMinutes / 60);
        const minutes = endMinutes % 60;
        setEndTime(
          `${hours.toString().padStart(2, "0")}:${minutes
            .toString()
            .padStart(2, "0")}`
        );
        setNotes(editingAppointment.notes || "");
        setColor(editingAppointment.color || "#2563eb");
      } else {
        // New appointment defaults
        setPatientQuery("");
        setPatientResults(null);
        setPatientId("");
        setTime("09:00");
        setEndTime("09:30");
        setDuration("30");
        setNotes("");
        setColor("#2563eb");
      }

      // Charger les rendez-vous existants pour cette date
      fetchAppointmentsByDate(selectedDate).then((appointments) => {
        setExistingAppointments(appointments);
      });
    }
  }, [isOpen, selectedDate, editingAppointment]);

  // Fonction pour convertir une heure au format HH:MM en minutes depuis minuit
  const timeToMinutes = (timeString: string): number => {
    const [hours, minutes] = timeString.split(":").map(Number);
    return hours * 60 + minutes;
  };

  // Fonction pour calculer la durée entre deux heures
  const calculateDuration = (startTime: string, endTime: string): number => {
    const startMinutes = timeToMinutes(startTime);
    const endMinutes = timeToMinutes(endTime);
    return endMinutes - startMinutes;
  };

  // Gestionnaire de sélection de plage horaire depuis le DayScheduler
  const handleTimeSlotSelect = (startTime: string, endTime: string) => {
    setTime(startTime);
    setEndTime(endTime);
    setDuration(calculateDuration(startTime, endTime).toString());
  };

  const formatDateISO = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedDate || !patientId || !doctorUserId) return;

    setIsSubmitting(true);

    try {
      const payload = {
        patient_id: patientId,
        date: formatDateISO(selectedDate),
        time,
        notes,
        duration: parseInt(duration),
        color,
        confirmed_coming: editingAppointment?.confirmed_coming || false,
        is_done: editingAppointment?.is_done || false,
      };

      if (editingAppointment) {
        const updated = await updateAppointment(editingAppointment.id, payload);
        if (updated) {
          onClose();
        }
      } else {
        const created = await createAppointment(payload);
        if (created) {
          onClose();
        }
      }
    } catch (error) {
      console.error("Erreur lors de la création du rendez-vous:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  // Titre dynamique basé sur le mode édition ou création
  const modalTitle = editingAppointment
    ? "Modifier le rendez-vous"
    : "Nouveau rendez-vous";



  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70">
      <div
        className="w-full max-w-5xl mx-4  transition-all transform bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg shadow-2xl animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">
            {modalTitle} -{" "}
            {selectedDate ? new Date(selectedDate).toLocaleDateString() : ""}
          </h2>
          <button
            type="button"
            className="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 focus:outline-none"
            onClick={() => {
              onClose();
              setExistingAppointments([]);
              setEditingAppointment(null);
            }}
          >
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4">
          <div className="space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                {/* Heure et durée du rendez-vous */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label
                      htmlFor="time"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                    >
                      Heure de début *
                    </label>
                    <input
                      type="time"
                      id="time"
                      value={time}
                      onChange={(e) => {
                        setTime(e.target.value);
                        // Calculer l'heure de fin en fonction de la durée
                        const startMinutes = timeToMinutes(e.target.value);
                        const endMinutes = startMinutes + parseInt(duration);
                        const hours = Math.floor(endMinutes / 60);
                        const minutes = endMinutes % 60;
                        setEndTime(
                          `${hours.toString().padStart(2, "0")}:${minutes
                            .toString()
                            .padStart(2, "0")}`
                        );
                      }}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="endTime"
                      className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                    >
                      Heure de fin *
                    </label>
                    <input
                      type="time"
                      id="endTime"
                      value={endTime}
                      readOnly
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-gray-50 dark:bg-gray-700/50 dark:text-gray-300"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="duration"
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                  >
                    Durée *
                  </label>
                  <select
                    id="duration"
                    value={duration}
                    onChange={(e) => {
                      setDuration(e.target.value);
                      // Calculer l'heure de fin en fonction de la durée
                      const startMinutes = timeToMinutes(time);
                      const endMinutes =
                        startMinutes + parseInt(e.target.value);
                      const hours = Math.floor(endMinutes / 60);
                      const minutes = endMinutes % 60;
                      setEndTime(
                        `${hours.toString().padStart(2, "0")}:${minutes
                          .toString()
                          .padStart(2, "0")}`
                      );
                    }}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  >
                    <option value="15">15 minutes</option>
                    <option value="30">30 minutes</option>
                    <option value="45">45 minutes</option>
                    <option value="60">1 heure</option>
                    <option value="90">1 heure 30</option>
                    <option value="120">2 heures</option>
                  </select>
                </div>

                {/* Recherche et sélection du patient */}
                <div className="relative">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Patient *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={patientQuery}
                      onChange={async (e) => {
                        setPatientQuery(e.target.value);
                        setSearchOpen(true);
                        if (e.target.value.trim().length > 1) {
                          const results = await searchPatients(e.target.value);
                          setPatientResults(results);
                        } else {
                          setPatientResults(null);
                        }
                      }}
                      onFocus={() => setSearchOpen(true)}
                      placeholder="Rechercher un patient (nom, prénom, NIN)"
                      className="w-full h-11 py-2 pl-10 pr-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                      disabled={editingAppointment !== null}
                    />
                    <MagnifyingGlassIcon className="absolute w-5 h-5 text-gray-400 left-3 top-1/2 -translate-y-1/2" />
                  </div>
                  {searchOpen && patientQuery && patientResults && (
                    <div className="absolute z-20 mt-2 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg max-h-64 overflow-auto">
                      {patientResults.length === 0 ? (
                        <div className="p-3 text-sm text-gray-500 dark:text-gray-400">
                          Aucun résultat
                        </div>
                      ) : (
                        patientResults.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            className={`block px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700/50 w-full text-left transition-colors ${patientId === p.id ? "bg-blue-50 dark:bg-blue-900/20" : ""
                              }`}
                            onClick={() => {
                              setPatientId(p.id);
                              setPatientQuery(`${p.family_name} ${p.name}`);
                              setSearchOpen(false);
                            }}
                          >
                            <div className="flex items-center justify-between">
                              <div className="font-medium text-gray-900 dark:text-gray-100">
                                {p.name} {p.family_name}
                              </div>
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                {p.telephone}
                              </div>
                            </div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {p.genre?.toUpperCase()} · {p.age} ans · #
                              {p.id.substring(0, 8)}…
                            </div>
                          </button>
                        ))
                      )}
                    </div>
                  )}
                </div>

                <ColorSelect color={color} setColor={setColor} />

                {editingAppointment && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">
                      Statut
                    </h3>

                    {/* Switch: confirmed_coming */}
                    <div className="flex items-center justify-between p-3 border dark:border-gray-700 rounded-lg">
                      <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-gray-200">
                          Patient a confirmé sa venue
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          Marquez comme confirmé si le patient a validé sa
                          présence
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setEditingAppointment(prev =>
                            prev
                              ? { ...prev, confirmed_coming: !editingAppointment.confirmed_coming || false }
                              : null
                          )
                        }
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${editingAppointment.confirmed_coming
                          ? "bg-blue-600"
                          : "bg-gray-200 dark:bg-gray-600"
                          }`}
                        aria-pressed={!!editingAppointment.confirmed_coming}
                        aria-label="Toggle confirmed"
                      >
                        <span
                          className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${editingAppointment.confirmed_coming
                            ? "translate-x-5"
                            : "translate-x-1"
                            }`}
                        />
                      </button>
                    </div>

                    {/* Switch: is_done */}
                    <div className="flex items-center justify-between p-3 border dark:border-gray-700 rounded-lg">
                      <div className="mr-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-gray-200">
                          Rendez-vous effectué
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          Indiquez si le rendez-vous a été réalisé
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          setEditingAppointment(prev =>
                            prev
                              ? { ...prev, is_done: !editingAppointment.is_done || false }
                              : null // or a default Appointment object
                          )
                        }
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${editingAppointment.is_done ? "bg-blue-600" : "bg-gray-200 dark:bg-gray-600"
                          }`}
                        aria-pressed={!!editingAppointment.is_done}
                        aria-label="Toggle done"
                      >
                        <span
                          className={`inline-block h-5 w-5 transform rounded-full bg-white transition-transform ${editingAppointment.is_done ? "translate-x-5" : "translate-x-1"
                            }`}
                        />
                      </button>
                    </div>
                  </div>
                )}

                {/* Notes */}
                <div>
                  <label
                    htmlFor="notes"
                    className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                  >
                    Notes
                  </label>
                  <textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Détails du rendez-vous"
                    rows={3}
                  />
                </div>
              </div>

              {/* Calendrier journalier avec glisser-déposer */}
              <div className={`lg:fixed right-10 lg:w-[45%] bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg p-4 ${editingAppointment ? 'h-[70vh]' : 'h-[60vh]'} flex flex-col shadow-md z-40`}>
                <DayScheduler
                  setEditingAppointment={setEditingAppointment}
                  selectedDate={selectedDate || new Date()}
                  onTimeSlotSelect={handleTimeSlotSelect}
                  existingAppointments={existingAppointments}
                  onAppointmentDeleted={onAppointmentAdded} // Utiliser la même fonction de callback pour rafraîchir les rendez-vous
                />
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900/50 flex justify-end space-x-3 z-9999">
            <button
              type="button"
              className="px-5 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 font-medium shadow-sm"
              onClick={onClose}
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 disabled:opacity-50 font-medium shadow-sm"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Enregistrement..." : "Enregistrer"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
