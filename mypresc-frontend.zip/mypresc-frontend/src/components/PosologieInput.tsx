'use client';

import { useState, useEffect, useCallback } from 'react';

interface PosologieInputProps {
  value: string;
  onChange: (value: string) => void;
  isRTL?: boolean;
}

// Options for the structured posologie dropdowns
const COMPRIMES_OPTIONS = ['1/4', '1/2', '3/4', '1', '1+1/2', '2', '3', '4', '5'];
const FOIS_PAR_JOUR_OPTIONS = [1, 2, 3, 4, 5];
const DUREE_OPTIONS = [1, 2, 3, 4, 5, 7, 10, 14, 21, 30];
const DUREE_UNITE_OPTIONS = ['jours', 'semaines', 'mois'] as const;

type DureeUnite = typeof DUREE_UNITE_OPTIONS[number];

// Parse a structured posologie string back into parts
// Format: "X comprimé(s), Y fois/jour, pendant Z jours"
function parseStructuredPosologie(value: string): {
  comprimes: string;
  foisParJour: number;
  duree: number;
  unite: DureeUnite;
} | null {
  if (!value) return null;

  const match = value.match(
    /^(.+?)\s+comprimé\(s\),\s*(\d+)\s+fois\/jour,\s*pendant\s+(\d+)\s+(jours|semaines|mois)$/
  );

  if (!match || !match[1] || !match[2] || !match[3] || !match[4]) return null;

  const comprimes = match[1].trim();
  const foisParJour = parseInt(match[2]);
  const duree = parseInt(match[3]);
  const unite = match[4] as DureeUnite;

  if (
    COMPRIMES_OPTIONS.includes(comprimes) &&
    FOIS_PAR_JOUR_OPTIONS.includes(foisParJour) &&
    DUREE_OPTIONS.includes(duree) &&
    DUREE_UNITE_OPTIONS.includes(unite)
  ) {
    return { comprimes, foisParJour, duree, unite };
  }

  return null;
}

function buildPosologieString(
  comprimes: string,
  foisParJour: number,
  duree: number,
  unite: DureeUnite
): string {
  return `${comprimes} comprimé(s), ${foisParJour} fois/jour, pendant ${duree} ${unite}`;
}

export default function PosologieInput({ value, onChange, isRTL }: PosologieInputProps) {
  // Determine initial mode based on value
  const parsed = parseStructuredPosologie(value);
  const [isStructured, setIsStructured] = useState(parsed !== null || !value);

  // Structured fields
  const [comprimes, setComprimes] = useState(parsed?.comprimes || '1');
  const [foisParJour, setFoisParJour] = useState(parsed?.foisParJour || 1);
  const [duree, setDuree] = useState(parsed?.duree || 5);
  const [unite, setUnite] = useState<DureeUnite>(parsed?.unite || 'jours');

  // Free text field
  const [freeText, setFreeText] = useState(!parsed ? value : '');

  // Emit default structured value on mount when value is empty
  useEffect(() => {
    if (!value && isStructured) {
      onChange(buildPosologieString(comprimes, foisParJour, duree, unite));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Build and emit the structured string when dropdowns change
  const emitStructured = useCallback((c: string, f: number, d: number, u: DureeUnite) => {
    onChange(buildPosologieString(c, f, d, u));
  }, [onChange]);

  // When switching to structured mode, emit the current dropdown values
  const handleToggle = () => {
    if (!isStructured) {
      // Switching to structured
      setIsStructured(true);
      emitStructured(comprimes, foisParJour, duree, unite);
    } else {
      // Switching to free text
      setIsStructured(false);
      onChange(freeText);
    }
  };

  const selectClass = "px-2 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white transition-colors text-sm";

  return (
    <div className="space-y-2">
      {/* Toggle between structured and free text */}
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Posologie <span className="text-red-500">*</span>
        </label>
        <button
          type="button"
          onClick={handleToggle}
          className="text-xs px-2 py-1 rounded-md border transition-colors flex items-center gap-1"
          style={{
            borderColor: isStructured ? '#3B82F6' : '#9CA3AF',
            backgroundColor: isStructured ? '#EFF6FF' : 'transparent',
            color: isStructured ? '#2563EB' : '#6B7280',
          }}
        >
          {isStructured ? (
            <>
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h7" />
              </svg>
              Structurée
            </>
          ) : (
            <>
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
              Texte libre
            </>
          )}
        </button>
      </div>

      {isStructured ? (
        /* ── Structured mode: 3 dropdowns ── */
        <div className="grid grid-cols-3 gap-2">
          {/* Nombre de comprimés */}
          <div>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">
              Comprimé(s)
            </label>
            <select
              value={comprimes}
              onChange={(e) => {
                setComprimes(e.target.value);
                emitStructured(e.target.value, foisParJour, duree, unite);
              }}
              className={`w-full ${selectClass}`}
            >
              {COMPRIMES_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          </div>

          {/* Nombre de fois par jour */}
          <div>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">
              Fois / jour
            </label>
            <select
              value={foisParJour}
              onChange={(e) => {
                const v = parseInt(e.target.value);
                setFoisParJour(v);
                emitStructured(comprimes, v, duree, unite);
              }}
              className={`w-full ${selectClass}`}
            >
              {FOIS_PAR_JOUR_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>{opt} / jour</option>
              ))}
            </select>
          </div>

          {/* Durée */}
          <div>
            <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">
              Pendant
            </label>
            <div className="flex gap-1">
              <select
                value={duree}
                onChange={(e) => {
                  const v = parseInt(e.target.value);
                  setDuree(v);
                  emitStructured(comprimes, foisParJour, v, unite);
                }}
                className={`flex-1 ${selectClass}`}
              >
                {DUREE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
              <select
                value={unite}
                onChange={(e) => {
                  const v = e.target.value as DureeUnite;
                  setUnite(v);
                  emitStructured(comprimes, foisParJour, duree, v);
                }}
                className={`w-20 ${selectClass} text-xs`}
              >
                {DUREE_UNITE_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      ) : (
        /* ── Free text mode ── */
        <input
          type="text"
          value={freeText}
          onChange={(e) => {
            setFreeText(e.target.value);
            onChange(e.target.value);
          }}
          placeholder="Ex: 1 comprimé le matin et 1 le soir"
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white transition-colors"
          required
        />
      )}

      {/* Preview of what will appear on the PDF */}
      {isStructured && value && (
        <p className="text-xs text-gray-400 dark:text-gray-500 italic">
          → {value}
        </p>
      )}
    </div>
  );
}
