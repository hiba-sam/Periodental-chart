// CardSkeleton - Generic card loading placeholder
'use client';

interface CardSkeletonProps {
    className?: string;
}

/**
 * Simple card skeleton for any card-based content loading
 */
export function CardSkeleton({ className = '' }: CardSkeletonProps) {
    return (
        <div className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 animate-pulse ${className}`}>
            <div className="space-y-4">
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3" />
                <div className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full" />
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
                </div>
            </div>
        </div>
    );
}

export default CardSkeleton;
