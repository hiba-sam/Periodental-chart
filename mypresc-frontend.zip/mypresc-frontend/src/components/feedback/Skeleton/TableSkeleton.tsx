// TableSkeleton - Generic table loading placeholder
'use client';

interface TableSkeletonProps {
    /** Number of rows to show */
    rows?: number;
    className?: string;
}

/**
 * Simple table skeleton for any table-based content loading
 */
export function TableSkeleton({ rows = 3, className = '' }: TableSkeletonProps) {
    return (
        <div className={`bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4 animate-pulse ${className}`}>
            <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-28 mb-4" />
            <div className="space-y-2">
                {Array.from({ length: rows }).map((_, i) => (
                    <div key={i} className="h-10 bg-gray-100 dark:bg-gray-700/50 rounded" />
                ))}
            </div>
        </div>
    );
}

export default TableSkeleton;
