import React, { useState, useRef, useEffect } from 'react';
import { Check, Search } from 'lucide-react';

interface Color {
  value: string;
  name: string;
  label: string;
}

export const COLORS: Color[] = [
  { value: '#2563eb', name: 'Bleu', label: 'Blue' },
  { value: '#10b981', name: 'Vert', label: 'Green' },
  { value: '#ef4444', name: 'Rouge', label: 'Red' },
  { value: '#f59e0b', name: 'Orange', label: 'Orange' },
  { value: '#8b5cf6', name: 'Violet', label: 'Purple' },
  { value: '#6b7280', name: 'Gris', label: 'Gray' }
];

interface ColorSelectProps {
  color: string;
  setColor: (color: string) => void;
}

export default function ColorSelect({ color, setColor }: ColorSelectProps) {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const selectedColor = COLORS.find(c => c.value === color);

  const filteredColors = COLORS.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchQuery('');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center gap-3 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
      >
        <div
          className="w-5 h-5 rounded flex-shrink-0 border border-gray-200 dark:border-gray-500"
          style={{ backgroundColor: color }}
        />
        <span className="flex-1 text-left text-sm text-gray-700 dark:text-gray-200">
          {selectedColor?.name || 'Sélectionner une couleur'}
        </span>
        <svg
          className={`w-4 h-4 text-gray-400 dark:text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg overflow-hidden">
          <div className="p-2 border-b border-gray-100 dark:border-gray-700">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-gray-400 dark:text-gray-500" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher une couleur..."
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-200 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="max-h-64 overflow-y-auto py-1">
            {filteredColors.length > 0 ? (
              filteredColors.map((colorOption) => (
                <button
                  key={colorOption.value}
                  type="button"
                  onClick={() => {
                    setColor(colorOption.value);
                    setIsOpen(false);
                    setSearchQuery('');
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left"
                >
                  <div
                    className="w-5 h-5 rounded flex-shrink-0 border border-gray-200 dark:border-gray-500"
                    style={{ backgroundColor: colorOption.value }}
                  />
                  <span className="flex-1 text-sm text-gray-700 dark:text-gray-200">
                    {colorOption.name}
                  </span>
                  {color === colorOption.value && (
                    <Check className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  )}
                </button>
              ))
            ) : (
              <div className="px-3 py-6 text-center text-sm text-gray-500 dark:text-gray-400">
                Aucune couleur trouvée
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};