'use client';

import { useEffect, useState } from 'react';
import LogoDonut from '@/components/ui/Logo';

/**
 * Realistic PQRST ECG waveform path.
 * One full heartbeat cycle ≈ 120 units wide.
 * The path is designed at y-center = 50, with:
 *   - P-wave:  gentle upward bump
 *   - QRS:     sharp spike (tall narrow peak up then dip down)
 *   - T-wave:  smooth rounded bump
 */
function buildEcgPath(cycles: number, width: number, height: number): string {
    const cycleWidth = width / cycles;
    const midY = height / 2;
    const parts: string[] = [];

    for (let i = 0; i < cycles; i++) {
        const x = i * cycleWidth;
        const cw = cycleWidth;

        if (i === 0) {
            parts.push(`M ${x},${midY}`);
        }

        // ── Flat baseline lead-in (0 → 12 %)
        parts.push(`L ${x + cw * 0.12},${midY}`);

        // ── P-wave: gentle upward bump (12 → 22 %)
        parts.push(
            `C ${x + cw * 0.15},${midY - height * 0.06} ` +
            `${x + cw * 0.19},${midY - height * 0.06} ` +
            `${x + cw * 0.22},${midY}`
        );

        // ── Short flat PR segment (22 → 28 %)
        parts.push(`L ${x + cw * 0.28},${midY}`);

        // ── Q dip (28 → 32 %)
        parts.push(`L ${x + cw * 0.32},${midY + height * 0.06}`);

        // ── R spike UP (32 → 37 %)  — the tall sharp peak
        parts.push(`L ${x + cw * 0.37},${midY - height * 0.42}`);

        // ── S dip DOWN (37 → 42 %)
        parts.push(`L ${x + cw * 0.42},${midY + height * 0.12}`);

        // ── Return to baseline (42 → 46 %)
        parts.push(`L ${x + cw * 0.46},${midY}`);

        // ── ST segment flat (46 → 56 %)
        parts.push(`L ${x + cw * 0.56},${midY}`);

        // ── T-wave: smooth rounded bump (56 → 72 %)
        parts.push(
            `C ${x + cw * 0.60},${midY - height * 0.12} ` +
            `${x + cw * 0.68},${midY - height * 0.12} ` +
            `${x + cw * 0.72},${midY}`
        );

        // ── Flat baseline tail-out (72 → 100 %)
        parts.push(`L ${x + cw * 1.0},${midY}`);
    }

    return parts.join(' ');
}

export default function Loader() {
    const [progress, setProgress] = useState(0);

    // Animated fake progress: fast 0→70 % in 800 ms, then slow 70→90 %
    useEffect(() => {
        let raf: number;
        let start: number | null = null;

        const step = (ts: number) => {
            if (!start) start = ts;
            const elapsed = ts - start;
            const fast = Math.min(elapsed / 800, 1) * 70;
            const slow = elapsed > 800 ? Math.min((elapsed - 800) / 2000, 1) * 20 : 0;
            setProgress(Math.min(fast + slow, 90));
            raf = requestAnimationFrame(step);
        };

        raf = requestAnimationFrame(step);
        return () => cancelAnimationFrame(raf);
    }, []);

    // Build 3 heartbeat cycles across a 600×100 SVG viewBox
    const ecgPath = buildEcgPath(3, 600, 100);

    return (
        <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-white dark:bg-gray-950 select-none overflow-hidden">

            {/* Radial glow backdrop */}
            <div
                className="absolute inset-0 pointer-events-none"
                style={{
                    background:
                        'radial-gradient(ellipse 60% 50% at 50% 50%, rgba(26,35,126,0.07) 0%, transparent 100%)',
                }}
            />

            {/* Medical cross — top-right accent */}
            <div className="absolute top-6 right-6 opacity-[0.08] dark:opacity-[0.05] pointer-events-none">
                <MedicalCross size={80} />
            </div>

            {/* Medical cross — bottom-left accent */}
            <div
                className="absolute bottom-6 left-6 opacity-[0.08] dark:opacity-[0.05] pointer-events-none"
                style={{ transform: 'rotate(12deg)' }}
            >
                <MedicalCross size={56} />
            </div>

            {/* ── Main content ─────────────────────────────────────────────────── */}
            <div className="relative z-10 flex flex-col items-center gap-5 px-6 w-full max-w-xs sm:max-w-sm">

                {/* Logo + brand name */}
                <div className="flex items-center gap-3">
                    <div className="relative shrink-0">
                        <span className="absolute inset-0 rounded-full bg-[#1a237e]/25 animate-ping" />
                        <div className="relative bg-[#1a237e] p-2.5 rounded-full shadow-lg shadow-blue-900/30">
                            <LogoDonut sizeClass="w-8 h-8" />
                        </div>
                    </div>
                    <span className="text-2xl font-bold text-[#1a237e] dark:text-white tracking-tight">
                        MyPrescription
                    </span>
                </div>

                {/* ── ECG heartbeat strip ──────────────────────────────────────── */}
                <div className="w-full relative overflow-hidden rounded-xl border border-indigo-100 dark:border-gray-700/50 bg-[#fafbff] dark:bg-gray-900/70">

                    {/* Faint grid lines – like ECG paper */}
                    <div
                        className="absolute inset-0 pointer-events-none opacity-30 dark:opacity-15"
                        style={{
                            backgroundImage:
                                'linear-gradient(to right, #c7d2fe 1px, transparent 1px), linear-gradient(to bottom, #c7d2fe 1px, transparent 1px)',
                            backgroundSize: '20px 20px',
                        }}
                    />

                    {/* The ECG waveform */}
                    <svg
                        viewBox="0 0 600 100"
                        preserveAspectRatio="none"
                        className="relative w-full h-16 sm:h-20"
                    >
                        {/* Baseline reference (faint) */}
                        <line x1="0" y1="50" x2="600" y2="50" stroke="#c7d2fe" strokeWidth="0.5" className="dark:stroke-gray-700" />

                        {/* The ECG line */}
                        <path
                            d={ecgPath}
                            fill="none"
                            stroke="#1a237e"
                            strokeWidth="2.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="dark:stroke-blue-400 ecg-line"
                        />
                    </svg>

                    {/* Sweeping scan beam */}
                    <div className="absolute inset-y-0 w-16 bg-gradient-to-r from-transparent via-[#1a237e]/15 to-transparent ecg-sweep pointer-events-none dark:via-blue-400/15" />

                    {/* Live pulse dot on right end */}
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-red-500 shadow-[0_0_6px_2px_rgba(239,68,68,0.55)] animate-pulse" />
                </div>

                {/* Shimmer progress bar */}
                <div className="w-full h-1.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
                    <div
                        className="h-full rounded-full loader-shimmer transition-all duration-300 ease-out"
                        style={{ width: `${progress}%` }}
                    />
                </div>

                {/* Status text */}
                <p className="text-[10px] tracking-[0.25em] uppercase text-gray-400 dark:text-gray-500 animate-pulse">
                    Chargement en cours…
                </p>
            </div>

            {/* ── Keyframes ─────────────────────────────────────────────────────── */}
            <style>{`
        /* ECG line draw-on + looping pulse */
        .ecg-line {
          stroke-dasharray: 1800;
          stroke-dashoffset: 1800;
          animation: ecg-draw 2s ease-out forwards, ecg-breathe 2s 2s ease-in-out infinite;
        }
        @keyframes ecg-draw {
          to { stroke-dashoffset: 0; }
        }
        @keyframes ecg-breathe {
          0%, 100% { opacity: 1; }
          50%      { opacity: 0.6; }
        }

        /* Sweeping scan beam */
        @keyframes sweep {
          0%   { left: -4rem; }
          100% { left: 100%;  }
        }
        .ecg-sweep {
          animation: sweep 2.5s linear infinite;
        }

        /* Progress bar shimmer */
        @keyframes shimmer-bar {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
        .loader-shimmer {
          background: linear-gradient(90deg, #1a237e 0%, #4a69ff 50%, #1a237e 100%);
          background-size: 200% 100%;
          animation: shimmer-bar 1.8s linear infinite;
        }
      `}</style>
        </div>
    );
}

// ── Medical cross SVG icon ─────────────────────────────────────────────────
function MedicalCross({ size }: { size: number }) {
    const arm = size * 0.32;
    const c = size / 2;
    return (
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none">
            <rect x={c - arm / 2} y={c - arm * 1.5} width={arm} height={arm * 3} rx={arm * 0.2} fill="#1a237e" />
            <rect x={c - arm * 1.5} y={c - arm / 2} width={arm * 3} height={arm} rx={arm * 0.2} fill="#1a237e" />
        </svg>
    );
}