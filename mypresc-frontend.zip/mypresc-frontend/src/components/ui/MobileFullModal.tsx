'use client';

import { ReactNode, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useLanguage } from '@/contexts/LanguageContext';

// ─── Types ────────────────────────────────────────────────────────────────────

type MobileFullModalProps = {
    /** Controls visibility */
    isOpen: boolean;
    /** Called when the back button is tapped */
    onClose: () => void;
    /** Header title */
    title: string;
    /** Main content */
    children: ReactNode;
    /**
     * Optional sticky footer (e.g. submit button).
     * Rendered below the scrollable content area.
     */
    footer?: ReactNode;
    /** Additional classes applied to the inner container */
    className?: string;
    /** z-index override (default 10000) */
    zIndex?: number;
};

// ─── Component ────────────────────────────────────────────────────────────────

/**
 * MobileFullModal
 *
 * A full-screen modal optimised for mobile — slide-up from the bottom with:
 *   • A sticky header bar containing a back arrow + title
 *   • A scrollable content area
 *   • An optional sticky footer
 *
 * Usage:
 * ```tsx
 * <MobileFullModal isOpen={open} onClose={() => setOpen(false)} title="Notifications">
 *   <NotificationsList />
 * </MobileFullModal>
 * ```
 */
export default function MobileFullModal({
    isOpen,
    onClose,
    title,
    children,
    footer,
    className = '',
    zIndex = 10000,
}: MobileFullModalProps) {
    const { isRTL } = useLanguage();

    // Lock body scroll while open
    useEffect(() => {
        if (!isOpen) return;
        const prev = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        document.documentElement.style.overflow = 'hidden';
        return () => {
            document.body.style.overflow = prev;
            document.documentElement.style.overflow = '';
        };
    }, [isOpen]);

    // Close on Escape key
    useEffect(() => {
        if (!isOpen) return;
        const handle = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
        window.addEventListener('keydown', handle);
        return () => window.removeEventListener('keydown', handle);
    }, [isOpen, onClose]);

    if (!isOpen || typeof window === 'undefined') return null;

    return createPortal(
        <div
            className="fixed inset-0 flex flex-col bg-white dark:bg-gray-900 animate-slide-up"
            style={{ zIndex }}
            dir={isRTL ? 'rtl' : 'ltr'}
        >
            {/* ── Header ─────────────────────────────────────────────────────────── */}
            <div className="sticky top-0 z-10 flex items-center gap-3 px-4 h-14 min-h-[56px] bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 shrink-0">
                {/* Back button */}
                <button
                    onClick={onClose}
                    aria-label="Go back"
                    className="flex items-center justify-center w-9 h-9 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-200 transition-colors shrink-0"
                >
                    {/* Arrow flips in RTL via the dir attribute on the parent */}
                    <svg
                        className="w-5 h-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2.2}
                    >
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                    </svg>
                </button>

                {/* Title */}
                <h2 className="flex-1 text-base font-semibold text-gray-900 dark:text-white truncate">
                    {title}
                </h2>
            </div>

            {/* ── Content (scrollable) ────────────────────────────────────────────── */}
            <div className={`flex-1 overflow-y-auto overscroll-contain ${className}`}>
                {children}
            </div>

            {/* ── Optional footer ────────────────────────────────────────────────── */}
            {footer && (
                <div className="shrink-0 border-t border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900 px-4 py-3 safe-area-inset-bottom">
                    {footer}
                </div>
            )}
        </div>,
        document.body,
    );
}
