"use client"

import * as React from "react"
import { format, parse, isValid } from "date-fns"
import { fr } from "date-fns/locale"
import { CalendarIcon } from "lucide-react"

import { cn } from "@/lib/utils"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

interface DatePickerProps {
  value: string // ISO format: YYYY-MM-DD
  onChange: (value: string) => void
  error?: string
  placeholder?: string
  className?: string
  minYear?: number
  maxYear?: number
  id?: string
  required?: boolean
}

export function DatePicker({
  value,
  onChange,
  error,
  placeholder = "Sélectionner une date",
  className,
  minYear = 1900,
  maxYear,
  id,
  required,
}: DatePickerProps) {
  const [open, setOpen] = React.useState(false)

  const currentYear = new Date().getFullYear()
  const effectiveMaxYear = maxYear ?? currentYear

  // Parse the ISO date string to Date object
  const selectedDate = value
    ? parse(value, "yyyy-MM-dd", new Date())
    : undefined

  const handleSelect = React.useCallback(
    (date: Date | undefined) => {
      if (date) {
        const isoDate = format(date, "yyyy-MM-dd")
        onChange(isoDate)
      }
      setOpen(false)
    },
    [onChange]
  )

  // Date constraints
  const fromDate = new Date(minYear, 0, 1)
  const toDate = new Date(effectiveMaxYear, 11, 31)

  return (
    <div className={className}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            id={id}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2 rounded-lg border text-left transition-colors",
              "focus:outline-none focus:ring-2 focus:ring-green-500",
              "dark:bg-gray-700 dark:text-white",
              error
                ? "border-red-500 dark:border-red-500"
                : "border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500",
              !value && "text-gray-400 dark:text-gray-400"
            )}
          >
            <span className={value ? "text-gray-900 dark:text-white" : ""}>
              {value && isValid(selectedDate)
                ? format(selectedDate!, "d MMMM yyyy", { locale: fr })
                : placeholder}
            </span>
            <CalendarIcon className="h-4 w-4 text-gray-400" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={isValid(selectedDate) ? selectedDate : undefined}
            onSelect={handleSelect}
            locale={fr}
            defaultMonth={
              isValid(selectedDate) ? selectedDate : new Date(effectiveMaxYear, 0)
            }
            startMonth={fromDate}
            endMonth={toDate}
            captionLayout="dropdown"
            showOutsideDays
            fixedWeeks
          />
        </PopoverContent>
      </Popover>
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  )
}

export default DatePicker
