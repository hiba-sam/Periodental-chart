import React from 'react'

export default function LogoDonut({ sizeClass = "w-10" }) {
  return (
    <div className={`${sizeClass} aspect-square shrink-0 flex-none`}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <circle
          cx="50"
          cy="50"
          r="40"
          fill="none"
          stroke="#FFFFFF"
          strokeWidth="16"
          strokeDasharray="260 6"
          strokeLinecap="round"
          transform="rotate(-90 50 50)"
        />
      </svg>
    </div>
  );
}
