'use client';

import { useLanguage } from '@/contexts/LanguageContext';
import { LanguageIcon } from '@heroicons/react/24/outline';

export default function LanguageSwitcher() {
  const { language, changeLanguage } = useLanguage();

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
        <LanguageIcon className="w-4 h-4 inline mr-1" />
        Langue
      </label>
      <select
        value={language}
        onChange={(e) => changeLanguage(e.target.value)}
        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
      >
        <option value="fr">Français</option>
        <option value="en">English</option>
        <option value="ar">العربية</option> 
      </select>
    </div>
  );
}
