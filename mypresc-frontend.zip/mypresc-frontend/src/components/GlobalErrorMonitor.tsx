'use client';

/**
 * GlobalErrorMonitor
 *
 * Mounts a single window-level listener for unhandled promise rejections.
 * This catches any async exceptions that escape React's error boundaries
 * (e.g., fire-and-forget fetch calls, socket handlers, post-navigation state
 * updates) and forwards them to Sentry for full stack-trace visibility.
 *
 * Without this, these errors show only as the generic Next.js
 * "Application error: a client-side exception has occurred" overlay
 * with no actionable stack trace in production.
 *
 * Renders nothing — purely a side-effect component.
 */

import { useEffect } from 'react';
import * as Sentry from '@sentry/nextjs';

export default function GlobalErrorMonitor() {
  useEffect(() => {
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;

      // Log to console in development for immediate visibility
      console.error('[GlobalErrorMonitor] Unhandled Promise Rejection:', reason);

      // Forward to Sentry with extra context
      Sentry.captureException(reason instanceof Error ? reason : new Error(String(reason)), {
        tags: {
          errorType: 'unhandled_promise_rejection',
        },
        extra: {
          promiseRejectionReason: String(reason),
        },
      });

      // Prevent Next.js from showing the generic error screen for non-fatal rejections.
      // Comment this out if you WANT the error overlay to still appear.
      // event.preventDefault();
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []); // Registers once on mount, cleans up on unmount

  return null; // Renders nothing
}
