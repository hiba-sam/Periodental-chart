
import { useEffect, useState } from "react";
import Modal from "../ui/Modal";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { ArrowRightOnRectangleIcon, CreditCardIcon, CheckIcon } from "@heroicons/react/24/outline";

export default function RenewAlert() {
    const { isExpiredPlan, user, logout, subscribe } = useAuth();
    const { t } = useLanguage();
    const [isOpen, setIsOpen] = useState(false);
    const [showPlans, setShowPlans] = useState(false);
    const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
    const [processing, setProcessing] = useState(false);

    useEffect(() => {
        if (isExpiredPlan) {
            setIsOpen(true);
        } else {
            setIsOpen(false);
        }
    }, [isExpiredPlan]);

    if (!isOpen || !user) return null;

    const isTrial = user.plan?.toLowerCase().includes("test") || user.plan?.toLowerCase().includes("trial") || user.plan?.toLowerCase().includes("gratuit");

    const plans = [
        {
            id: "flex",
            name: t('subscription.plans.flex.name'),
            price: "3 000",
            period: t('subscription.perMonth'),
            features: [
                t('subscription.plans.flex.features.noSavings'),
                t('subscription.plans.flex.features.idealTest'),
                t('subscription.plans.flex.features.support57')
            ],
            recommended: false
        },
        {
            id: "pro",
            name: t('subscription.plans.pro.name'),
            price: "30 000",
            period: t('subscription.perYear'),
            features: [
                t('subscription.plans.pro.features.savings17'),
                t('subscription.plans.pro.features.badgePlus'),
                t('subscription.plans.pro.features.support77')
            ],
            recommended: true
        },
        {
            id: "smart",
            name: t('subscription.plans.smart.name'),
            price: "16 800",
            period: t('subscription.perSemester'),
            features: [
                t('subscription.plans.smart.features.savings07'),
                t('subscription.plans.smart.features.badge'),
                t('subscription.plans.smart.features.support57')
            ],
            recommended: false
        }
    ];

    const handleCheckout = async () => {
        if (selectedPlan && !processing) {
            setProcessing(true);
            try {
                await subscribe(selectedPlan);
            } catch (error) {
                console.error("Checkout failed", error);
            } finally {
                setProcessing(false);
            }
        }
    };

    return (
        <Modal
            isOpen={isOpen}
            onClose={() => { }} // Block closing
            title={showPlans ? t('subscription.choosePlan') : (isTrial ? t('subscription.trialEnded') : t('subscription.subscriptionExpired'))}
            closeOnBackdrop={false}
            showCloseIcon={false}
            className={showPlans ? "max-w-6xl" : "max-w-2xl"}
            zIndex={50}
        >
            {!showPlans ? (
                <div className="flex flex-col items-center text-center space-y-6">
                    <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-full">
                        <CreditCardIcon className="w-12 h-12 text-red-500" />
                    </div>

                    <div className="space-y-2">
                        <p className="text-gray-600 dark:text-gray-300 text-lg">
                            {isTrial
                                ? t('subscription.trialEndedMessage')
                                : t('subscription.subscriptionExpiredMessage', { plan: user.plan || '', date: user.end_date ? new Date(user.end_date).toLocaleDateString() : '?' })
                            }
                        </p>
                        <p className="text-sm text-gray-500">
                            {t('subscription.dataSecure')}
                        </p>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 w-full justify-center pt-8">
                        <button
                            onClick={logout}
                            className="flex items-center justify-center gap-2 px-6 py-3 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                        >
                            <ArrowRightOnRectangleIcon className="w-5 h-5" />
                            <span>{t('subscription.logout')}</span>
                        </button>

                        <button
                            onClick={() => setShowPlans(true)}
                            className="flex items-center justify-center gap-2 px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg shadow-blue-500/30 transition-all transform hover:scale-105 font-medium"
                        >
                            <CreditCardIcon className="w-5 h-5" />
                            <span>{isTrial ? t('subscription.choosePlanBtn') : t('subscription.renewSubscriptionBtn')}</span>
                        </button>
                    </div>
                </div>
            ) : (
                <div className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {plans.map((plan) => (
                            <div
                                key={plan.id}
                                onClick={() => setSelectedPlan(plan.id)}
                                className={`relative rounded-2xl border-2 cursor-pointer transition-all duration-200 overflow-hidden flex flex-col
                            ${selectedPlan === plan.id
                                        ? 'border-blue-600 ring-2 ring-blue-600 ring-offset-2 dark:ring-offset-gray-800'
                                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                                    } 
                            ${plan.recommended ? 'shadow-xl bg-indigo-900 border-indigo-900 text-white' : 'bg-white dark:bg-gray-800'}
                             ${plan.recommended && selectedPlan === plan.id ? 'bg-indigo-900 border-indigo-900 ring-indigo-900' : ''}
                        `}
                            >
                                {plan.recommended && (
                                    <div className="absolute top-0 right-0 bg-cyan-400 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm z-10">
                                        {t('subscription.recommended')}
                                    </div>
                                )}

                                <div className="p-6 flex flex-col h-full">
                                    <h3 className={`text-xl font-bold mb-4 ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-gray-100'}`}>
                                        {plan.name}
                                    </h3>

                                    <div className="mb-6">
                                        <span className={`text-4xl font-bold ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                                            {plan.price}
                                        </span>
                                        <span className={`text-base font-normal ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                            DZD
                                        </span>
                                        <div className={`text-sm ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                            {plan.period}
                                        </div>
                                    </div>

                                    <ul className="space-y-4 mb-4 flex-1">
                                        {plan.features.map((feature, i) => (
                                            <li key={i} className="flex items-start gap-3">
                                                <div className="mt-1 p-0.5 rounded-full bg-cyan-400 shrink-0">
                                                    <CheckIcon className="w-3 h-3 text-white" strokeWidth={3} />
                                                </div>
                                                <span className={`text-sm font-medium ${plan.recommended ? 'text-white' : 'text-gray-600 dark:text-gray-300'}`}>
                                                    {feature}
                                                </span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="flex justify-between items-center border-t border-gray-200 dark:border-gray-700 pt-6">
                        <button
                            onClick={() => setShowPlans(false)}
                            disabled={processing}
                            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                        >
                            {t('subscription.back')}
                        </button>
                        <button
                            onClick={handleCheckout}
                            disabled={!selectedPlan || processing}
                            className={`px-8 py-3 rounded-xl font-medium shadow-lg transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center gap-2 ${!selectedPlan
                                ? 'bg-gray-200 text-gray-400 dark:bg-gray-700 dark:text-gray-500'
                                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30'
                                }`}
                        >
                            {processing ? (
                                <>
                                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                                    <span>{t('subscription.processing')}</span>
                                </>
                            ) : (
                                <span>{t('subscription.payActivate')}</span>
                            )}
                        </button>
                    </div>
                </div>
            )}
        </Modal>
    );
}