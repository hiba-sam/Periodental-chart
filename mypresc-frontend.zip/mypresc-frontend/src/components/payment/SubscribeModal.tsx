
import { useState, useEffect } from "react";
import Modal from "../ui/Modal";
import MobileFullModal from "../ui/MobileFullModal";
import { CreditCardIcon, CheckIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";

interface SubscribeModalProps {
    isOpen: boolean;
    onClose: () => void;
}

interface Plan {
    id: string;
    name: string;
    price: string;
    period: string;
    features: string[];
    recommended: boolean;
}

// ─── Plan cards (shared) ──────────────────────────────────────────────────────

function PlanCards({
    plans,
    selectedPlan,
    setSelectedPlan,
    t,
}: {
    plans: Plan[];
    selectedPlan: string | null;
    setSelectedPlan: (id: string) => void;
    t: (key: string) => string;
}) {
    return (
        <div className="flex flex-col gap-4">
            {plans.map((plan) => (
                <div
                    key={plan.id}
                    onClick={() => setSelectedPlan(plan.id)}
                    className={`relative rounded-2xl border-2 cursor-pointer transition-all duration-200 overflow-hidden flex flex-col
                        ${selectedPlan === plan.id
                            ? 'border-cyan-400 ring-4 ring-cyan-400/50 shadow-[0_0_20px_rgba(34,211,238,0.4)]'
                            : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'}
                        ${plan.recommended ? 'shadow-xl bg-indigo-900 text-white' : 'bg-white dark:bg-gray-800'}`}
                >
                    {selectedPlan === plan.id && (
                        <div className="absolute top-3 left-3 z-20">
                            <div className="w-6 h-6 rounded-full bg-cyan-400 flex items-center justify-center shadow-lg">
                                <CheckIcon className="w-4 h-4 text-white" strokeWidth={3} />
                            </div>
                        </div>
                    )}
                    {plan.recommended && (
                        <div className="absolute top-0 right-0 bg-cyan-400 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm z-10">
                            {t('subscription.recommended')}
                        </div>
                    )}
                    <div className="p-5 flex flex-col h-full">
                        <h3 className={`text-lg font-bold mb-3 ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-gray-100'}`}>
                            {plan.name}
                        </h3>
                        <div className="mb-4">
                            <span className={`text-3xl font-bold ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                                {plan.price}
                            </span>
                            <span className={`text-sm font-normal ml-1 ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                DZD
                            </span>
                            <div className={`text-xs mt-0.5 ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                {plan.period}
                            </div>
                        </div>
                        <ul className="space-y-2 flex-1">
                            {plan.features.map((feature, i) => (
                                <li key={i} className="flex items-start gap-2">
                                    <div className="mt-0.5 p-0.5 rounded-full bg-cyan-400 shrink-0">
                                        <CheckIcon className="w-3 h-3 text-white" strokeWidth={3} />
                                    </div>
                                    <span className={`text-sm font-medium ${plan.recommended ? 'text-white' : 'text-gray-600 dark:text-gray-300'}`}>
                                        {feature}
                                    </span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            ))}
        </div>
    );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function SubscribeModal({ isOpen, onClose }: SubscribeModalProps) {
    const { subscribe } = useAuth();
    const { t } = useLanguage();
    const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
    const [processing, setProcessing] = useState(false);
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        const mq = window.matchMedia('(max-width: 767px)');
        setIsMobile(mq.matches);
        const handler = (e: MediaQueryListEvent) => setIsMobile(e.matches);
        mq.addEventListener('change', handler);
        return () => mq.removeEventListener('change', handler);
    }, []);

    const plans: Plan[] = [
        {
            id: "flex",
            name: t('subscription.plans.flex.name'),
            price: "3 000",
            period: t('subscription.perMonth'),
            features: [
                t('subscription.plans.flex.features.noSavings'),
                t('subscription.plans.flex.features.idealTest'),
                t('subscription.plans.flex.features.support57'),
            ],
            recommended: false,
        },
        {
            id: "pro",
            name: t('subscription.plans.pro.name'),
            price: "30 000",
            period: t('subscription.perYear'),
            features: [
                t('subscription.plans.pro.features.savings17'),
                t('subscription.plans.pro.features.badgePlus'),
                t('subscription.plans.pro.features.support77'),
            ],
            recommended: true,
        },
        {
            id: "smart",
            name: t('subscription.plans.smart.name'),
            price: "16 800",
            period: t('subscription.perSemester'),
            features: [
                t('subscription.plans.smart.features.savings07'),
                t('subscription.plans.smart.features.badge'),
                t('subscription.plans.smart.features.support57'),
            ],
            recommended: false,
        },
    ];

    const handleCheckout = async () => {
        if (selectedPlan && !processing) {
            setProcessing(true);
            try {
                await subscribe(selectedPlan);
                onClose();
            } catch (error) {
                console.error("Checkout failed", error);
            } finally {
                setProcessing(false);
            }
        }
    };

    // Sticky footer — passed to MobileFullModal so it never scrolls
    const mobileFooter = (
        <div className="flex flex-col gap-2">
            <button
                onClick={handleCheckout}
                disabled={!selectedPlan || processing}
                className={`flex items-center justify-center gap-2 w-full px-6 py-3.5 rounded-xl font-semibold shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed ${!selectedPlan
                        ? 'bg-gray-200 text-gray-400 dark:bg-gray-700 dark:text-gray-500'
                        : 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white shadow-blue-500/30'
                    }`}
            >
                {processing ? (
                    <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                        <span>{t('subscription.processing')}</span>
                    </>
                ) : (
                    <>
                        <CreditCardIcon className="w-5 h-5" />
                        <span>{t('subscription.payActivate')}</span>
                    </>
                )}
            </button>
            <button
                onClick={onClose}
                disabled={processing}
                className="w-full px-6 py-3 rounded-xl border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 active:bg-gray-100 transition-colors font-medium"
            >
                {t('subscription.cancel')}
            </button>
        </div>
    );

    // ── Mobile: full-screen slide-up / only cards scroll / buttons fixed ──────
    if (isMobile) {
        return (
            <MobileFullModal
                isOpen={isOpen}
                onClose={onClose}
                title={t('subscription.choosePlan')}
                footer={mobileFooter}
                className="p-4"
            >
                <PlanCards
                    plans={plans}
                    selectedPlan={selectedPlan}
                    setSelectedPlan={setSelectedPlan}
                    t={t}
                />
            </MobileFullModal>
        );
    }

    // ── Desktop: original centred modal (unchanged) ───────────────────────────
    return (
        <Modal
            isOpen={isOpen}
            onClose={onClose}
            title={t('subscription.choosePlan')}
            className="max-w-6xl"
        >
            <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {plans.map((plan) => (
                        <div
                            key={plan.id}
                            onClick={() => setSelectedPlan(plan.id)}
                            className={`relative rounded-2xl border-2 cursor-pointer transition-all duration-200 overflow-hidden flex flex-col
                                ${selectedPlan === plan.id
                                    ? 'border-cyan-400 ring-4 ring-cyan-400/50 shadow-[0_0_20px_rgba(34,211,238,0.4)]'
                                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'}
                                ${plan.recommended ? 'shadow-xl bg-indigo-900 text-white' : 'bg-white dark:bg-gray-800'}`}
                        >
                            {selectedPlan === plan.id && (
                                <div className="absolute top-3 left-3 z-20">
                                    <div className="w-6 h-6 rounded-full bg-cyan-400 flex items-center justify-center shadow-lg">
                                        <CheckIcon className="w-4 h-4 text-white" strokeWidth={3} />
                                    </div>
                                </div>
                            )}
                            {plan.recommended && (
                                <div className="absolute top-0 right-0 bg-cyan-400 text-white text-xs font-bold px-3 py-1 rounded-bl-xl shadow-sm z-10">
                                    {t('subscription.recommended')}
                                </div>
                            )}
                            <div className="p-6 flex flex-col h-full">
                                <h3 className={`text-xl font-bold mb-4 ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-gray-100'}`}>
                                    {plan.name}
                                </h3>
                                <div className="mb-6">
                                    <span className={`text-4xl font-bold ${plan.recommended ? 'text-white' : 'text-gray-900 dark:text-white'}`}>
                                        {plan.price}
                                    </span>
                                    <span className={`text-base font-normal ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                        DZD
                                    </span>
                                    <div className={`text-sm ${plan.recommended ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'}`}>
                                        {plan.period}
                                    </div>
                                </div>
                                <ul className="space-y-4 mb-4 flex-1">
                                    {plan.features.map((feature, i) => (
                                        <li key={i} className="flex items-start gap-3">
                                            <div className="mt-1 p-0.5 rounded-full bg-cyan-400 shrink-0">
                                                <CheckIcon className="w-3 h-3 text-white" strokeWidth={3} />
                                            </div>
                                            <span className={`text-sm font-medium ${plan.recommended ? 'text-white' : 'text-gray-600 dark:text-gray-300'}`}>
                                                {feature}
                                            </span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="flex justify-end items-center border-t border-gray-200 dark:border-gray-700 pt-6 gap-4">
                    <button
                        onClick={onClose}
                        disabled={processing}
                        className="px-6 py-2.5 rounded-xl border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                    >
                        {t('subscription.cancel')}
                    </button>
                    <button
                        onClick={handleCheckout}
                        disabled={!selectedPlan || processing}
                        className={`flex items-center gap-2 px-8 py-2.5 rounded-xl font-medium shadow-lg transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none ${!selectedPlan
                                ? 'bg-gray-200 text-gray-400 dark:bg-gray-700 dark:text-gray-500'
                                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/30'
                            }`}
                    >
                        {processing ? (
                            <>
                                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                                <span>{t('subscription.processing')}</span>
                            </>
                        ) : (
                            <>
                                <CreditCardIcon className="w-5 h-5" />
                                <span>{t('subscription.payActivate')}</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        </Modal>
    );
}