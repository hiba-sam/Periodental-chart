
"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Modal from "../ui/Modal";
import SubscribeModal from "./SubscribeModal";
import { useLanguage } from "@/contexts/LanguageContext";
import { CheckCircleIcon, XCircleIcon, ArrowPathIcon, QuestionMarkCircleIcon, XMarkIcon } from "@heroicons/react/24/outline";

function StatusAlertContent() {
    const searchParams = useSearchParams();
    const router = useRouter();
    const { t } = useLanguage();
    const status = searchParams.get("status");

    const [isOpen, setIsOpen] = useState(false);
    const [showSubscribe, setShowSubscribe] = useState(false);

    useEffect(() => {
        if (status === "success" || status === "failed") {
            setIsOpen(true);
        } else {
            setIsOpen(false);
        }
    }, [status]);

    const handleClose = () => {
        setIsOpen(false);
        // Remove status param
        const newParams = new URLSearchParams(searchParams.toString());
        newParams.delete("status");
        router.replace(`?${newParams.toString()}`);
    };

    const handleRetry = () => {
        handleClose();
        setShowSubscribe(true);
    };

    const handleContact = () => {
        window.open(`${process.env.NEXT_PUBLIC_FRONTEND_URL || ""}/aide/#contact`, '_blank');
    };

    if (!isOpen && !showSubscribe) return null;

    return (
        <>
            <Modal
                isOpen={isOpen}
                onClose={handleClose}
                title=""
                className="max-w-xl"
                showCloseIcon={true}
            >
                <div className="flex flex-col items-center text-center p-4">
                    {status === "success" ? (
                        <>
                            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                                <CheckCircleIcon className="w-10 h-10 text-green-600" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                                {t('subscription.alert.successTitle')}
                            </h3>
                            <p className="text-gray-600 dark:text-gray-300 mb-6">
                                {t('subscription.alert.successMessage')}
                                <br />
                                {t('subscription.alert.successInvoice')}
                            </p>
                            <button
                                onClick={handleClose}
                                className="px-6 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-xl transition-colors font-medium shadow-lg shadow-green-500/30"
                            >
                                {t('subscription.alert.continueDashboard')}
                            </button>
                        </>
                    ) : (
                        <>
                            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-6">
                                <XCircleIcon className="w-10 h-10 text-red-600" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                                {t('subscription.alert.failedTitle')}
                            </h3>
                            <p className="text-gray-600 dark:text-gray-300 mb-6">
                                {t('subscription.alert.failedMessage')}
                                <br />
                                {t('subscription.alert.failedAction')}
                            </p>
                            <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
                                <button
                                    onClick={handleContact}
                                    className="flex items-center justify-center gap-2 px-6 py-2.5 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                                >
                                    <QuestionMarkCircleIcon className="w-5 h-5" />
                                    <span>{t('subscription.alert.helpSupport')}</span>
                                </button>
                                <button
                                    onClick={handleRetry}
                                    className="flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-colors font-medium shadow-lg shadow-blue-500/30"
                                >
                                    <ArrowPathIcon className="w-5 h-5" />
                                    <span>{t('subscription.alert.retry')}</span>
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </Modal>

            <SubscribeModal
                isOpen={showSubscribe}
                onClose={() => setShowSubscribe(false)}
            />
        </>
    );
}

export default function StatusAlert() {
    return (
        <Suspense fallback={null}>
            <StatusAlertContent />
        </Suspense>
    );
}
