"use client";
import { useEffect, useRef, useCallback } from "react";

interface UseIdleTimeoutOptions {
    /** Timeout in milliseconds before triggering onIdle (default: 15 minutes) */
    timeout: number;
    /** Callback function to execute when user becomes idle */
    onIdle: () => void;
    /** Optional callback to trigger a warning before logout */
    onWarning?: () => void;
    /** Milliseconds before timeout to trigger warning (default: 60000 = 1 min) */
    warningBefore?: number;
    /** Whether the idle detection is enabled (default: true) */
    enabled?: boolean;
}

/**
 * Custom hook to detect user inactivity and trigger callbacks.
 * Tracks mouse, keyboard, touch, and scroll events.
 */
export const useIdleTimeout = ({
    timeout,
    onIdle,
    onWarning,
    warningBefore = 60000, // 1 minute before by default
    enabled = true,
}: UseIdleTimeoutOptions) => {
    const idleTimerRef = useRef<NodeJS.Timeout | null>(null);
    const warningTimerRef = useRef<NodeJS.Timeout | null>(null);
    const warningTriggeredRef = useRef(false);

    // Events that indicate user activity
    const activityEvents = [
        "mousemove",
        "mousedown",
        "mouseup",
        "keydown",
        "keypress",
        "keyup",
        "scroll",
        "touchstart",
        "touchmove",
        "click",
    ];

    const resetTimers = useCallback(() => {
        // Clear existing timers
        if (idleTimerRef.current) {
            clearTimeout(idleTimerRef.current);
        }
        if (warningTimerRef.current) {
            clearTimeout(warningTimerRef.current);
        }

        // Reset warning state
        warningTriggeredRef.current = false;

        // Set warning timer if callback provided
        if (onWarning && warningBefore < timeout) {
            warningTimerRef.current = setTimeout(() => {
                if (!warningTriggeredRef.current) {
                    warningTriggeredRef.current = true;
                    onWarning();
                }
            }, timeout - warningBefore);
        }

        // Set idle timer
        idleTimerRef.current = setTimeout(() => {
            console.log("⏰ Idle timeout reached - triggering logout");
            onIdle();
        }, timeout);
    }, [timeout, onIdle, onWarning, warningBefore]);

    useEffect(() => {
        if (!enabled) {
            // Clean up timers if disabled
            if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
            if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
            return;
        }

        // Handler for activity events
        const handleActivity = () => {
            resetTimers();
        };

        // Add event listeners
        activityEvents.forEach((event) => {
            window.addEventListener(event, handleActivity, { passive: true });
        });

        // Start initial timer
        resetTimers();

        // Cleanup
        return () => {
            activityEvents.forEach((event) => {
                window.removeEventListener(event, handleActivity);
            });
            if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
            if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
        };
    }, [enabled, resetTimers]);

    // Return a function to manually reset the timer (e.g., after user confirms they're still active)
    return { resetTimers };
};
