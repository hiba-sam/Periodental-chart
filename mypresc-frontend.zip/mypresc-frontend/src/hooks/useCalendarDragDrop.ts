/**
 * useCalendarDragDrop.ts
 *
 * Custom hook for handling drag & drop functionality in calendar views.
 * Provides drag handlers, drop logic, and time recalculation utilities.
 */

import { useCallback, useState, useRef, useEffect } from 'react';
import { DragEndEvent, DragStartEvent, DragOverEvent, rectIntersection, CollisionDetection } from '@dnd-kit/core';
import { useCalendar, CalendarEvent } from '@/contexts/CalendarContext';
import { useAppointmentsContext } from '@/contexts/AppointmentContext';
import { toast } from '@/components/ui/use-toast';

interface DropTarget {
  date: Date;
  time: string; // HH:mm format
  column?: number; // For week view (0-6)
}

interface DragState {
  isDragging: boolean;
  draggedEventId: string | null;
  dropTarget: DropTarget | null;
}

/**
 * Custom collision detection that uses the TOP EDGE of the dragged block
 * instead of the mouse pointer position.
 *
 * This ensures that when dragging an appointment, the drop position is based
 * on where the TOP of the block is, not where the mouse cursor is.
 * 
 * Strategy:
 * 1. Calculate a virtual point at the center-top of the dragged element
 * 2. Find which droppable slot contains that point
 * 3. Return that slot as the collision target
 */
export const customCollisionDetection: CollisionDetection = (args) => {
  const { droppableRects, droppableContainers, active } = args;
  
  if (!active || !active.rect.current.translated) {
    return [];
  }
  
  // Get the translated rectangle of the dragged element (its current position)
  const dragRect = active.rect.current.translated;
  
  // Use the TOP-CENTER point of the dragged block as reference
  const topCenterX = dragRect.left + dragRect.width / 2;
  const topY = dragRect.top + 10; // Add small offset to be inside the slot
  
  // Find the droppable that contains this point
  const collisions: ReturnType<CollisionDetection> = [];
  
  for (const droppableContainer of droppableContainers) {
    const { id } = droppableContainer;
    const rect = droppableRects.get(id);
    
    if (!rect) continue;
    
    // Check if the top-center point is inside this droppable
    if (
      topCenterX >= rect.left &&
      topCenterX <= rect.right &&
      topY >= rect.top &&
      topY <= rect.bottom
    ) {
      collisions.push({
        id,
        data: { droppableContainer, value: 0 },
      });
    }
  }
  
  if (collisions.length > 0) {
    return collisions;
  }
  
  // Fallback: use rectangle intersection if no point collision found
  const intersectionCollisions = rectIntersection(args);
  return intersectionCollisions;
};

/**
 * Round a time string to the nearest 15-minute interval (quarter hour)
 *
 * This is a defensive utility to ensure proper 15-minute snapping even if
 * there are edge cases in collision detection or time parsing.
 *
 * Examples:
 * - "09:07" → "09:00"
 * - "09:15" → "09:15"
 * - "09:22" → "09:15"
 * - "09:32" → "09:30"
 * - "09:47" → "09:45"
 * - "23:58" → "23:45"
 *
 * @param time - Time string in HH:mm format
 * @returns Rounded time in HH:mm format, snapped to nearest 15-min interval
 */
const roundToQuarterHour = (time: string): string => {
  const [hoursStr, minutesStr] = time.split(':');
  const hours = parseInt(hoursStr!, 10);
  const minutes = parseInt(minutesStr!, 10);

  // Validate input
  if (isNaN(hours) || isNaN(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
    console.warn('[roundToQuarterHour] Invalid time format:', time);
    return time; // Return original if invalid
  }

  // Round down to nearest 15-minute interval
  const quarterMinutes = Math.floor(minutes / 15) * 15;

  // Format back to HH:mm
  return `${String(hours).padStart(2, '0')}:${String(quarterMinutes).padStart(2, '0')}`;
};

/**
 * Parse drop target ID into structured data
 *
 * Supported formats:
 * - Week view: "slot-{column}-{ISO-date}-{HH:mm}"
 *   Example: "slot-6-2025-10-18T00:00:00.000Z-09:15"
 * - Day view: "slot-{ISO-date}-{HH:mm}"
 *   Example: "slot-2025-10-18T00:00:00.000Z-09:30"
 *
 * The time portion (HH:mm) is always at the end after the last dash
 *
 * @param dropId - The drop target ID string
 * @returns Parsed DropTarget or null if invalid
 */
const parseDropTargetId = (dropId: string): DropTarget | null => {
  if (!dropId || !dropId.startsWith('slot-')) {
    return null;
  }

  // Remove "slot-" prefix
  const withoutPrefix = dropId.substring(5);

  // The time (HH:mm format) is always the last part after a dash
  // Strategy: Find the last segment that matches HH:mm format
  // This avoids confusion with dashes in ISO dates (e.g., 2025-10-17)

  // Split by dash and find the last valid time segment
  const parts = withoutPrefix.split('-');
  let timePart = '';
  let timePartIndex = -1;

  // Search backwards for HH:mm format
  for (let i = parts.length - 1; i >= 0; i--) {
    if (/^\d{2}:\d{2}$/.test(parts[i]!)) {
      timePart = parts[i]!;
      timePartIndex = i;
      break;
    }
  }

  if (!timePart || timePartIndex === -1) {
    return null;
  }

  // Reconstruct the part before time by joining all parts before the time index
  const beforeTime = parts.slice(0, timePartIndex).join('-');

  // Try to match week view format: {column}-{ISO-date}
  // Column is 0-6 (single digit) or potentially 0-99 (double digit)
  // Use \d{1,2} to match only 1-2 digits (not 4-digit years like 2025)
  const weekViewMatch = beforeTime.match(/^(\d{1,2})-(.+)$/);

  if (weekViewMatch) {
    const [, columnStr, isoDatePart] = weekViewMatch;
    const column = parseInt(columnStr!, 10);

    // Parse the ISO date - it should be the full date string
    const date = new Date(isoDatePart!);

    // Validate column is reasonable (0-6 for days, or up to 99 for extended grids)
    if (isNaN(column) || column > 99 || isNaN(date.getTime())) {
      // Don't return null here - fall through to day view parsing
    } else {
      return { column, date, time: timePart };
    }
  }

  // If not week view, try day view format: just {ISO-date}
  const date = new Date(beforeTime);

  if (isNaN(date.getTime())) {
    return null;
  }

  return { date, time: timePart };
};

/**
 * Hook for managing calendar event drag & drop
 */
export const useCalendarDragDrop = () => {
  const { updateEvent, updateEventOptimistic, events } = useCalendar();
  const { fetchAppointments } = useAppointmentsContext();

  // Track whether this hook's owner is still mounted.
  // Guards all post-await state updates in handleDragEnd so we don't
  // call setState / toast after the user has navigated away.
  const mountedRef = useRef(true);
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const [dragState, setDragState] = useState<DragState>({
    isDragging: false,
    draggedEventId: null,
    dropTarget: null,
  });

  /**
   * Calculate new time based on drop target
   */
  const calculateNewTime = useCallback((
    originalEvent: CalendarEvent,
    dropTarget: DropTarget
  ): { date: Date; time: string; duration: number } => {
    return {
      date: dropTarget.date,
      time: dropTarget.time,
      duration: originalEvent.duration || 30,
    };
  }, []);

  /**
   * Handle drag start
   */
  const handleDragStart = useCallback((event: DragStartEvent) => {
    const eventId = event.active.id as string;

    setDragState({
      isDragging: true,
      draggedEventId: eventId,
      dropTarget: null,
    });
  }, []);

  /**
   * Handle drag over - provides visual feedback
   */
  const handleDragOver = useCallback((event: DragOverEvent) => {
    if (!event.over) {
      setDragState(prev => ({ ...prev, dropTarget: null }));
      return;
    }

    // Parse drop target ID using the new parser
    const dropId = event.over.id as string;
    const dropTarget = parseDropTargetId(dropId);

    if (!dropTarget) {
      setDragState(prev => ({ ...prev, dropTarget: null }));
      return;
    }

    setDragState(prev => ({ ...prev, dropTarget }));
  }, []);

  /**
   * Handle drag end - update event position
   * Implements optimistic UI updates with automatic rollback on failure
   */
  const handleDragEnd = useCallback(async (event: DragEndEvent) => {
    const eventId = event.active.id as string;
    const dropId = event.over?.id as string;

    // Reset drag state
    setDragState({
      isDragging: false,
      draggedEventId: null,
      dropTarget: null,
    });

    // If no drop target, do nothing
    if (!dropId) {
      return;
    }

    // Find the original event
    const originalEvent = events.find(e => e.id === eventId);
    if (!originalEvent) {
      return;
    }

    // Store original values for potential rollback
    const originalDate = originalEvent.date;
    const originalTime = originalEvent.time;
    const originalDuration = originalEvent.duration;

    // Parse drop target using the new parser
    const dropTarget = parseDropTargetId(dropId);

    if (!dropTarget) {
      toast.error('Position de dépôt invalide', 'Erreur');
      return;
    }

    // Calculate new time (parseDropTargetId already extracts the exact 15-min time)
    const { date, time: rawTime, duration } = calculateNewTime(originalEvent, dropTarget);

    // Apply defensive quarter-hour rounding to ensure 15-minute snapping
    const time = roundToQuarterHour(rawTime);

    // Check if anything actually changed
    const isSameDate =
      date.getDate() === originalEvent.date.getDate() &&
      date.getMonth() === originalEvent.date.getMonth() &&
      date.getFullYear() === originalEvent.date.getFullYear();

    const isSameTime = time === originalEvent.time;

    if (isSameDate && isSameTime) {
      return;
    }

    // ============================================================================
    // VALIDATION - Block drops on past dates (instant client-side check)
    // ============================================================================
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dropDate = new Date(date);
    dropDate.setHours(0, 0, 0, 0);

    if (dropDate < today) {
      toast.error('Impossible de déplacer un rendez-vous dans le passé', 'Date invalide');
      return;
    }

    // ============================================================================
    // OPTIMISTIC UPDATE - Update UI immediately for instant feedback
    // ============================================================================
    updateEventOptimistic(eventId, {
      date,
      time,
      duration,
    });

    // ============================================================================
    // BACKGROUND API UPDATE - Send update to backend
    // ============================================================================
    try {
      const updatedEvent = await updateEvent({
        id: eventId,
        date,
        time,
        duration,
      }, true); // skipLoading=true to prevent scroll reset

      // ⚠️ Guard: user may have navigated away while the API call was in flight.
      //    Without this, we update state / show toasts on unmounted components.
      if (!mountedRef.current) return;

      if (updatedEvent) {
        toast.success('Rendez-vous déplacé avec succès');
        // Refresh appointments for dashboard sync
        fetchAppointments();
      } else {
        // Backend returned null - rollback optimistic update
        updateEventOptimistic(eventId, {
          date: originalDate,
          time: originalTime,
          duration: originalDuration,
        });
        toast.error('Erreur lors du déplacement du rendez-vous', 'Erreur');
      }
    } catch (error) {
      // ⚠️ Guard: same unmount protection on error path
      if (!mountedRef.current) return;

      // Backend error - rollback optimistic update
      updateEventOptimistic(eventId, {
        date: originalDate,
        time: originalTime,
        duration: originalDuration,
      });
      toast.error('Erreur lors du déplacement du rendez-vous', 'Erreur');
    }
  }, [events, calculateNewTime, updateEvent, updateEventOptimistic, fetchAppointments]);

  /**
   * Handle drag cancel
   */
  const handleDragCancel = useCallback(() => {
    setDragState({
      isDragging: false,
      draggedEventId: null,
      dropTarget: null,
    });
  }, []);

  return {
    dragState,
    handlers: {
      onDragStart: handleDragStart,
      onDragOver: handleDragOver,
      onDragEnd: handleDragEnd,
      onDragCancel: handleDragCancel,
    },
  };
};
