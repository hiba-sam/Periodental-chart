"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useCallback,
  useRef,
} from "react";
import axios, { AxiosError } from "axios";
import { toast } from "@/components/ui/use-toast";
import { useAuth } from "./AuthContext";
import socketClient from "@/utils/socketClient";
import logger from "@/utils/logger";

// --- Types aligned with backend ---
export interface ApiPatient {
  id: string;
  name: string;
  family_name: string;
  age: number;
  genre: "homme" | "femme";
  telephone: string;
  email?: string;
  adresse?: string;
  dateNaissance: string; // ISO string per backend
  numeroSecuriteSociale?: string;
  medecinTraitant?: string;
  chronicDiseases?: string;
  consultations?: number;
  allergies?: string[] | string | null;
  notes?: string | null;
  nin?: string;
  created_at?: Date | string;
  emergencyPhone?: string;
  emergencyContact?: string;
  is_private?: boolean;
  assignedDoctor?: {
    name: string;
    phone: string;
  } | null;
  assistant_id?: number | null;
  is_chart_readed?: boolean;
}

export interface PatientData {
  name: string;
  family_name: string;
  dateNaissance?: string;
  genre: string;
  telephone?: string;
  email?: string;
  adresse?: string;
  numeroSecuriteSociale?: string;
  medecinTraitant?: string;
  allergies?: string[] | string | null;
  notes?: string | null;
  nin?: string;
  age?: number | string; // Can be provided directly if dateNaissance not given
  is_private?: boolean;
}

// --- Invoice Types ---
export interface InvoiceItem {
  tarification_id?: number;
  label: string;
  price: number;
}

export interface Invoice {
  id: number;
  patient_id: string; // generated UUID
  doctor_user_id: number;
  total_price: string; // decimal string from DB
  amount_paid: string; // decimal string from DB
  status: 'paid' | 'unpaid' | 'partial' | 'free';
  created_at: string;
  updated_at: string;
  items: InvoiceItem[];
  patient_name?: string;
  patient_family_name?: string;
}

export interface CreateInvoicePayload {
  patient_id: string;
  total_price: number;
  items: InvoiceItem[];
}

// Statistics data structure
export interface PatientStatistics {
  weeklyData: Array<{ period: string; patients: number }>;
  monthlyData: Array<{ period: string; patients: number }>;
  yearlyData: Array<{ period: string; patients: number }>;
}

export interface InvoiceStatistics {
  weeklyData: Array<{ period: string; paiements: number }>;
  monthlyData: Array<{ period: string; paiements: number }>;
  yearlyData: Array<{ period: string; paiements: number }>;
}

export interface PatientUnpaidSummary {
  patient_id: string;
  patient_name: string;
  patient_family_name: string;
  total_unpaid: string;
  invoice_count: string;
  invoices: Invoice[];
}

interface PatientsContextType {
  patients: ApiPatient[];
  relatedPatients: ApiPatient[];
  addPatient: (patientData: PatientData) => Promise<boolean | ApiPatient>;
  updatePatient: (
    id: string,
    patientData: Partial<PatientData>
  ) => Promise<ApiPatient | undefined>;
  deletePatient: (id: string) => Promise<boolean>;
  getPatient: (id: string) => Promise<ApiPatient | undefined>;
  fetchPatients: (
    limit?: number,
    offset?: number,
    append?: boolean,
    force?: boolean
  ) => Promise<void>;
  fetchRelatedPatients: () => Promise<void>;
  loadMorePatients: () => Promise<void>;
  hasMore: boolean;
  loadingMore: boolean;
  searchPatients: (searchTerm: string, limit?: number, includeAll?: boolean) => Promise<ApiPatient[]>;
  loading: boolean;
  error: string | null;
  markChartAsRead: (id: string, isPrivate?: boolean) => Promise<boolean>;

  // Optimized statistics fetching
  fetchPatientStatistics: (type: 'new' | 'old') => Promise<void>;
  oldPatientStat?: PatientStatistics | null;
  newPatientStat?: PatientStatistics | null;
  statisticsLoading: { new: boolean; old: boolean };
  statisticsError: { new: string | null; old: string | null };

  // Export functionality
  exportPatientData: () => Promise<void>;

  // Invoice functionality
  getInvoicesByPatient: (patientId: string) => Promise<Invoice[]>;
  createInvoice: (payload: CreateInvoicePayload) => Promise<Invoice | null>;
  updateInvoiceStatus: (id: number, status: 'paid' | 'unpaid' | 'partial') => Promise<boolean>;
  addInvoicePayment: (id: number, amount: number) => Promise<Invoice | null>;
  distributePayment: (patientId: string, amount: number) => Promise<{ success: boolean; updatedInvoices: Invoice[]; appliedPayments: Array<{ invoiceId: number; amount: number }>; remainingAmount: number } | null>;
  deleteInvoice: (id: number) => Promise<boolean>;
  getTodayInvoices: () => Promise<Invoice[]>;
  fetchPaymentStatistics: () => Promise<InvoiceStatistics | null>;
  getUnpaidByPatient: (searchTerm?: string) => Promise<PatientUnpaidSummary[]>;
}

const PatientsContext = createContext<PatientsContextType | undefined>(
  undefined
);

// Axios instance
const API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/patient";
const INVOICE_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/consultation-invoice";

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

const invoiceAxiosInstance = axios.create({
  baseURL: INVOICE_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

// Using shadcn toast

export function PatientsProvider({ children }: { children: ReactNode }) {
  const [patients, setPatients] = useState<ApiPatient[]>([]);
  const [relatedPatients, setRelatedPatients] = useState<ApiPatient[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  // ⚡ Task 4.3: Store next cursor for keyset pagination (O(1) at any page depth)
  const nextCursorRef = useRef<string | null>(null);

  // Optimized statistics states with separate loading/error tracking
  const [newPatientStat, setNewPatientStat] = useState<PatientStatistics | null>(null);
  const [oldPatientStat, setOldPatientStat] = useState<PatientStatistics | null>(null);
  const [statisticsLoading, setStatisticsLoading] = useState({ new: false, old: false });
  const [statisticsError, setStatisticsError] = useState<{ new: string | null; old: string | null }>({
    new: null,
    old: null
  });

  logger.log("[PatientsContext] Rendered PatientsProvider", patients);
  // Cache to prevent redundant API calls for patients list
  const patientsCache = useRef<{
    data: ApiPatient[];
    timestamp: number | null;
  }>({
    data: [],
    timestamp: null
  });

  // Cache to prevent redundant API calls for statistics
  const statisticsCache = useRef<{
    new: PatientStatistics | null;
    old: PatientStatistics | null;
    timestamp: { new: number | null; old: number | null };
  }>({
    new: null,
    old: null,
    timestamp: { new: null, old: null }
  });

  // Abort controller to cancel pending requests
  const abortControllerRef = useRef<{ new: AbortController | null; old: AbortController | null }>({
    new: null,
    old: null
  });

  const { user } = useAuth();

  // --- FETCH PATIENTS (C-R-U-D: Read) with 10-minute cache; supports append for pagination ---
  const fetchPatients = useCallback(
    async (
      limit: number = 20,
      offset: number = 0,
      append: boolean = false,
      force: boolean = false
    ) => {
      // Check cache first (10-minute cache for initial load)
      const CACHE_DURATION = 10 * 60 * 1000;
      const now = Date.now();
      const cachedTimestamp = patientsCache.current.timestamp;

      // Use cache only for the first page when not forced and not appending
      if (
        !append &&
        offset === 0 &&
        !force &&
        cachedTimestamp &&
        patientsCache.current.data.length > 0 &&
        now - cachedTimestamp < CACHE_DURATION
      ) {
        logger.log('[PatientsContext] Using cached patients data');
        setPatients(patientsCache.current.data);
        setHasMore(patientsCache.current.data.length === limit);
        return;
      }

      if (append) {
        setLoadingMore(true);
      } else {
        setLoading(true);
        // Reset cursor on a fresh (non-append) fetch
        nextCursorRef.current = null;
      }
      setError(null);
      try {
        const response = await axiosInstance.get("/", {
          params: { limit, offset },
        });
        if (response.data?.success) {
          const incoming = response.data.data as ApiPatient[];
          // ⚡ Task 4.3: Store the next cursor for loadMorePatients to use
          nextCursorRef.current = response.data.pagination?.nextCursor ?? null;

          if (append) {
            setPatients((prev) => {
              const existingIds = new Set(prev.map((p) => p.id));
              const toAdd = incoming.filter((p) => !existingIds.has(p.id));
              if (toAdd.length === 0) {
                setHasMore(false);
                return prev;
              }
              setHasMore(response.data.pagination?.hasMore ?? incoming.length === limit);
              const newData = [...prev, ...toAdd];
              patientsCache.current.data = newData;
              return newData;
            });
          } else {
            setPatients(incoming);
            setHasMore(response.data.pagination?.hasMore ?? incoming.length === limit);
            patientsCache.current.data = incoming;
            patientsCache.current.timestamp = Date.now();
            logger.log('[PatientsContext] Successfully fetched and cached patients data');
          }
        } else {
          const msg =
            response.data?.error || "\u00c9chec du chargement des patients.";
          setError(msg);
          toast.error(msg, "Erreur");
        }
      } catch (err) {
        console.error("Erreur fetchPatients:", err);
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data && (axiosErr.response.data as any).error
            ? (axiosErr.response.data as any).error
            : "\u00c9chec du chargement des patients.";
        setError(message);
        toast.error(message, "Erreur");
      } finally {
        if (append) {
          setLoadingMore(false);
        } else {
          setLoading(false);
        }
      }
    },
    []
  );

  // ⚡ Task 4.3: loadMorePatients now uses cursor when available (O(1)), falls back to offset (O(n))
  const loadMorePatients = useCallback(async () => {
    if (loadingMore || !hasMore) return;

    if (nextCursorRef.current) {
      // Cursor mode: O(1) regardless of page depth
      if (loadingMore) return;
      setLoadingMore(true);
      setError(null);
      try {
        const response = await axiosInstance.get("/", {
          params: { limit: 20, cursor: nextCursorRef.current },
        });
        if (response.data?.success) {
          const incoming = response.data.data as ApiPatient[];
          nextCursorRef.current = response.data.pagination?.nextCursor ?? null;
          setPatients((prev) => {
            const existingIds = new Set(prev.map((p) => p.id));
            const toAdd = incoming.filter((p) => !existingIds.has(p.id));
            if (toAdd.length === 0) { setHasMore(false); return prev; }
            setHasMore(response.data.pagination?.hasMore ?? incoming.length === 20);
            const newData = [...prev, ...toAdd];
            patientsCache.current.data = newData;
            return newData;
          });
        }
      } catch (err) {
        console.error("Erreur loadMorePatients (cursor):", err);
      } finally {
        setLoadingMore(false);
      }
    } else {
      // Fallback: offset mode (backward compat, O(n))
      const nextOffset = patients.length;
      await fetchPatients(20, nextOffset, true, true);
    }
  }, [patients.length, fetchPatients, loadingMore, hasMore]);

  // --- FETCH RELATED PATIENTS ---
  const fetchRelatedPatients = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.get("/related");
      if (response.data?.success) {
        const relatedPatientsData = response.data.data as ApiPatient[];
        setRelatedPatients(relatedPatientsData);
        logger.log('[PatientsContext] Successfully fetched related patients:', relatedPatientsData);
      } else {
        const msg = response.data?.error || "Échec du chargement des patients liés.";
        setError(msg);
        toast.error(msg, "Erreur");
      }
    } catch (err) {
      console.error("Erreur fetchRelatedPatients:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement des patients liés.";
      setError(message);
      toast.error(message, "Erreur");
    } finally {
      setLoading(false);
    }
  }, []);

  // --- SEARCH PATIENTS ---
  const searchPatients = async (
    searchTerm: string,
    limit: number = 50,
    includeAll: boolean = true
  ): Promise<ApiPatient[]> => {
    setError(null);
    try {
      const response = await axiosInstance.get("/search", {
        params: { searchTerm, limit, includeAll: includeAll ? 'true' : 'false' },
      });
      if (response.data?.success) {
        const results = response.data.data as ApiPatient[];
        toast.success(`Recherche: ${results.length} patient(s) trouvé(s)`);
        return results;
      }
      const msg = response.data?.error || "Échec de la recherche des patients.";
      setError(msg);
      toast.error(msg, "Erreur");
      return [];
    } catch (err) {
      console.error("Erreur searchPatients:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la recherche des patients.";
      setError(message);
      toast.error(message, "Erreur");
      return [];
    } finally {
      setLoading(false);
    }
  };

  // --- ADD PATIENT (C-R-U-D: Create) ---
  const addPatient = async (patientData: PatientData): Promise<boolean | ApiPatient> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.post("/", patientData);
      if (response.status === 201 && response.data?.success) {
        const newPatient = response.data.data as ApiPatient;
        setPatients((prev) => {
          const updated = [...prev, newPatient];
          // Update cache
          patientsCache.current.data = updated;
          return updated;
        });
        toast.success(response.data?.message || "Patient créé avec succès");
        setError(null);
        return newPatient;
      }
      const msg =
        response.data?.error || "Erreur lors de la création du patient.";
      setError(msg);
      toast.error(msg, "Erreur");
      return false;
    } catch (err) {
      console.error("Erreur addPatient:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Erreur lors de la création du patient.";
      setError(message);
      toast.error(message, "Erreur");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // --- UPDATE PATIENT (C-R-U-D: Update) ---
  const updatePatient = async (
    id: string,
    patientData: Partial<PatientData>
  ): Promise<ApiPatient | undefined> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.put(`/${id}`, patientData);
      if (response.data?.success) {
        const updatedPatient = response.data.data as ApiPatient;
        setPatients((prev) => {
          const updated = prev.map((p) => (p.id === id ? updatedPatient : p));
          // Update cache
          patientsCache.current.data = updated;
          return updated;
        });
        toast.success(
          response.data?.message || "Patient mis à jour avec succès"
        );
        return updatedPatient;
      }
      const msg =
        response.data?.error || "Erreur lors de la mise à jour du patient.";
      setError(msg);
      toast.error(msg, "Erreur");
      return undefined;
    } catch (err) {
      console.error("Erreur updatePatient:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Erreur lors de la mise à jour du patient.";
      setError(message);
      toast.error(message, "Erreur");
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  // --- DELETE PATIENT (C-R-U-D: Delete) ---
  const deletePatient = async (id: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.delete(`/${id}`);
      if (response.data?.success) {
        setPatients((prev) => {
          const updated = prev.filter((patient) => patient.id !== id);
          // Update cache
          patientsCache.current.data = updated;
          return updated;
        });
        toast.success(response.data?.message || "Patient supprimé avec succès");
        return true;
      }
      const msg =
        response.data?.error || "Erreur lors de la suppression du patient.";
      setError(msg);
      toast.error(msg, "Erreur");
      return false;
    } catch (err) {
      console.error("Erreur deletePatient:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Erreur lors de la suppression du patient.";
      setError(message);
      toast.error(message, "Erreur");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // --- GET SINGLE PATIENT (Local Read) ---
  const getPatient = async (id: string): Promise<ApiPatient | undefined> => {
    const local = patients.find((patient) => patient.id === id);
    if (local) return local;
    try {
      const response = await axiosInstance.get(`/${id}`);
      logger.log("[patientContext] getPatient response:", response);
      if (response.data?.success && response.data.data) {
        const fetched = response.data.data as ApiPatient;
        logger.log("[patientContext] Fetched patient:", fetched);
        // Cache it locally (avoid duplicate)
        setPatients((prev) => {
          const existing = prev.find((p) => p.id === fetched.id);
          let updated: ApiPatient[];
          if (existing) {
            updated = prev.map((p) => (p.id === fetched.id ? fetched : p));
          } else {
            updated = [...prev, fetched];
          }
          // Update cache
          patientsCache.current.data = updated;
          return updated;
        });

        return fetched;
      }
      return undefined;
    } catch (e) {
      return undefined;
    }
  };

  // --- MARK CHART AS READ ---
  const markChartAsRead = async (id: string, isPrivate?: boolean): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const payload: any = { is_chart_readed: true };
      if (isPrivate !== undefined) {
        payload.is_private = isPrivate;
      }
      const response = await axiosInstance.put(`/${id}`, payload);
      if (response.data?.success) {
        const updatedPatient = response.data.data as ApiPatient;
        setPatients((prev) => {
          const updated = prev.map((p) => (p.id === id ? updatedPatient : p));
          // Update cache
          patientsCache.current.data = updated;
          return updated;
        });
        toast.success(
          response.data?.message || "Dossier marqué comme lu"
        );
        return true;
      }
      const msg =
        response.data?.error || "Erreur lors de la mise à jour du dossier.";
      setError(msg);
      toast.error(msg, "Erreur");
      return false;
    } catch (err) {
      console.error("Erreur markChartAsRead:", err);
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Erreur lors de la mise à jour du dossier.";
      setError(message);
      toast.error(message, "Erreur");
      return false;
    } finally {
      setLoading(false);
    }
  };


  // --- EXPORT PATIENT DATA ---
  const exportPatientData = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      logger.log("🔐 Export patients attempt");

      const response = await axiosInstance.get("/export/data", {
        responseType: "blob",
      });

      logger.log("✅ Export response received", response.status);

      if (response.status !== 200) throw new Error("Erreur lors de l'export");

      const contentType = response.headers["content-type"];
      if (!contentType || (!contentType.includes("text/csv") && !contentType.includes("application/csv"))) {
        throw new Error("Format de réponse invalide - CSV attendu");
      }

      // Convert blob to CSV and trigger download
      const blob = new Blob([response.data], { type: "text/csv;charset=utf-8;" });
      const url = window.URL.createObjectURL(blob);

      // Create temporary link to trigger download
      const link = document.createElement("a");
      link.href = url;

      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      link.download = `patients_export_${timestamp}.csv`;

      // Trigger download
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success("Export des patients réussi", "Succès");

    } catch (err) {
      console.error("❌ Export error:", err);

      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Erreur lors de l'export des patients";

      setError(message);
      toast.error(message, "Erreur");

    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Optimized lazy loading for patient statistics
   * - Only fetches data when requested (tab becomes active)
   * - Uses cache to prevent redundant API calls
   * - Supports request cancellation for rapid tab switching
   * - Separate loading and error states for each type
   *
   * @param type - 'new' or 'old' patient statistics
   */
  const fetchPatientStatistics = useCallback(async (type: 'new' | 'old') => {
    // Check cache first (5-minute cache)
    const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
    const now = Date.now();
    const cachedTimestamp = statisticsCache.current.timestamp[type];

    if (
      statisticsCache.current[type] &&
      cachedTimestamp &&
      now - cachedTimestamp < CACHE_DURATION
    ) {
      // Return cached data without making API call
      logger.log(`[PatientsContext] Using cached ${type} patient statistics`);
      if (type === 'new') {
        setNewPatientStat(statisticsCache.current.new);
      } else {
        setOldPatientStat(statisticsCache.current.old);
      }
      return;
    }

    // Cancel any pending request for this type
    if (abortControllerRef.current[type]) {
      abortControllerRef.current[type]!.abort();
    }

    // Create new abort controller for this request
    const abortController = new AbortController();
    abortControllerRef.current[type] = abortController;

    // Set loading state for this specific type
    setStatisticsLoading(prev => ({ ...prev, [type]: true }));
    setStatisticsError(prev => ({ ...prev, [type]: null }));

    try {
      const response = await axiosInstance.get(
        `/stat?doctorUserId=${user?.id}`,
        { signal: abortController.signal }
      );

      if (response.data?.success) {
        const stats = response.data.data;
        const statisticsData: PatientStatistics = type === 'new'
          ? stats.newPatients
          : stats.oldPatients;

        // Update cache
        statisticsCache.current[type] = statisticsData;
        statisticsCache.current.timestamp[type] = Date.now();

        // Update state
        if (type === 'new') {
          setNewPatientStat(statisticsData);
        } else {
          setOldPatientStat(statisticsData);
        }

        logger.log(`[PatientsContext] Successfully fetched ${type} patient statistics`);
      } else {
        const errorMsg = response.data?.error || `Échec du chargement des statistiques ${type}`;
        setStatisticsError(prev => ({ ...prev, [type]: errorMsg }));
      }
    } catch (err: any) {
      // Ignore abort errors (user switched tabs quickly)
      if (err.name === 'AbortError' || err.name === 'CanceledError') {
        logger.log(`[PatientsContext] Request for ${type} statistics was cancelled`);
        return;
      }

      console.error(`[PatientsContext] Error fetching ${type} patient statistics:`, err);
      const axiosErr = err as AxiosError<{ error?: string }>;
      const errorMessage = axiosErr.response?.data?.error ||
        `Erreur lors du chargement des statistiques ${type}`;

      setStatisticsError(prev => ({ ...prev, [type]: errorMessage }));
    } finally {
      setStatisticsLoading(prev => ({ ...prev, [type]: false }));

      // Clean up abort controller reference
      if (abortControllerRef.current[type] === abortController) {
        abortControllerRef.current[type] = null;
      }
    }
  }, [user?.id]);

  // --- INVOICE FUNCTIONS ---

  const getInvoicesByPatient = useCallback(async (patientId: string): Promise<Invoice[]> => {
    try {
      const response = await invoiceAxiosInstance.get(`/patient/${patientId}`);
      if (response.data?.success) {
        return response.data.data as Invoice[];
      }
      return [];
    } catch (err) {
      console.error("Error fetching invoices:", err);
      toast.error("Erreur lors du chargement des factures");
      return [];
    }
  }, []);

  const createInvoice = useCallback(async (payload: CreateInvoicePayload): Promise<Invoice | null> => {
    try {
      const response = await invoiceAxiosInstance.post("/", payload);
      if (response.data?.success) {
        toast.success("Facture créée avec succès");
        return response.data.data as Invoice;
      }
      toast.error(response.data?.message || "Erreur lors de la création de la facture");
      return null;
    } catch (err) {
      console.error("Error creating invoice:", err);
      toast.error("Erreur lors de la création de la facture");
      return null;
    }
  }, []);

  const updateInvoiceStatus = useCallback(async (id: number, status: 'paid' | 'unpaid' | 'partial'): Promise<boolean> => {
    try {
      const response = await invoiceAxiosInstance.patch(`/${id}/status`, { status });
      if (response.data?.success) {
        toast.success("Statut mis à jour");
        return true;
      }
      return false;
    } catch (err) {
      console.error("Error updating invoice status:", err);
      toast.error("Erreur mise à jour statut");
      return false;
    }
  }, []);

  const addInvoicePayment = useCallback(async (id: number, amount: number): Promise<Invoice | null> => {
    try {
      const response = await invoiceAxiosInstance.post(`/${id}/payment`, { amount });
      if (response.data?.success) {
        toast.success(response.data.message || "Paiement enregistré");
        return response.data.data as Invoice;
      }
      toast.error(response.data?.error || "Erreur lors de l'enregistrement du paiement");
      return null;
    } catch (err) {
      console.error("Error adding invoice payment:", err);
      toast.error("Erreur lors de l'enregistrement du paiement");
      return null;
    }
  }, []);

  const distributePayment = useCallback(async (patientId: string, amount: number): Promise<{ success: boolean; updatedInvoices: Invoice[]; appliedPayments: Array<{ invoiceId: number; amount: number }>; remainingAmount: number } | null> => {
    try {
      const response = await invoiceAxiosInstance.post('/distribute-payment', { patientId, amount });
      if (response.data?.success) {
        toast.success(response.data.message || "Paiement réparti avec succès");
        return {
          success: true,
          updatedInvoices: response.data.data.updatedInvoices as Invoice[],
          appliedPayments: response.data.data.appliedPayments,
          remainingAmount: response.data.data.remainingAmount
        };
      }
      toast.error(response.data?.error || "Erreur lors de la répartition du paiement");
      return null;
    } catch (err) {
      console.error("Error distributing payment:", err);
      toast.error("Erreur lors de la répartition du paiement");
      return null;
    }
  }, []);

  const deleteInvoice = useCallback(async (id: number): Promise<boolean> => {
    try {
      const response = await invoiceAxiosInstance.delete(`/${id}`);
      if (response.data?.success) { // Typically delete returns success or 204
        toast.success("Facture supprimée");
        return true;
      }
      return false;
    } catch (err) {
      console.error("Error deleting invoice:", err);
      toast.error("Erreur suppression facture");
      return false;
    }
  }, []);

  const getTodayInvoices = useCallback(async (): Promise<Invoice[]> => {
    try {
      const response = await invoiceAxiosInstance.get(`/today`);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching today invoices:', error);
      return [];
    }
  }, []);

  const fetchPaymentStatistics = useCallback(async (): Promise<InvoiceStatistics | null> => {
    try {
      const response = await invoiceAxiosInstance.get(`/statistics`);
      return response.data.data;
    } catch (error) {
      console.error('Error fetching payment statistics:', error);
      return null;
    }
  }, []);

  const getUnpaidByPatient = useCallback(async (searchTerm?: string): Promise<PatientUnpaidSummary[]> => {
    try {
      const params = searchTerm ? `?search=${encodeURIComponent(searchTerm)}` : '';
      const response = await invoiceAxiosInstance.get(`/unpaid-by-patient${params}`);
      if (response.data?.success) {
        return response.data.data as PatientUnpaidSummary[];
      }
      return [];
    } catch (err) {
      console.error("Error fetching unpaid invoices by patient:", err);
      return [];
    }
  }, []);

  // Initial data load on mount - only fetch patients list
  // Statistics are lazy loaded when tabs are activated
  useEffect(() => {
    if (user) {
      fetchPatients();
    }
    setError(null);
  }, [user, fetchPatients]);

  // 🔄 Real-time sync: Listen for patient:created events from assistant
  // This invalidates the cache and adds the new patient to the list
  useEffect(() => {
    if (!user || user.role !== 'doctor') return;

    const handlePatientCreated = (data: { patient: ApiPatient; createdBy: { id: number; name: string; role: string } }) => {
      logger.log('[PatientsContext] Received patient:created event:', data);

      // Add the new patient to the list if not already present
      setPatients((prev) => {
        const exists = prev.some((p) => p.id === data.patient.id);
        if (exists) return prev;

        const updated = [data.patient, ...prev];
        // Update cache
        patientsCache.current.data = updated;
        patientsCache.current.timestamp = Date.now();
        return updated;
      });

      // Show toast notification
      toast.success(
        `${data.createdBy.name} a ajouté: ${data.patient.name} ${data.patient.family_name}`,
        "Nouveau patient"
      );
    };

    // Subscribe to patient:created events
    socketClient.on('patient:created', handlePatientCreated);

    return () => {
      socketClient.off('patient:created', handlePatientCreated);
    };
  }, [user]);

  const value: PatientsContextType = {
    patients,
    relatedPatients,
    addPatient,
    updatePatient,
    deletePatient,
    getPatient,
    fetchPatients,
    fetchRelatedPatients,
    loadMorePatients,
    hasMore,
    loadingMore,
    searchPatients,
    loading,
    error,
    markChartAsRead,
    fetchPatientStatistics,
    newPatientStat,
    oldPatientStat,
    statisticsLoading,
    statisticsError,
    exportPatientData,
    getInvoicesByPatient,
    createInvoice,
    updateInvoiceStatus,
    addInvoicePayment,
    distributePayment,
    deleteInvoice,
    getTodayInvoices,
    fetchPaymentStatistics,
    getUnpaidByPatient
  };

  return (
    <PatientsContext.Provider value={value}>
      {children}
    </PatientsContext.Provider>
  );
}

// Hook personnalisé pour utiliser le contexte
export function usePatients() {
  const context = useContext(PatientsContext);
  if (context === undefined) {
    throw new Error("usePatients must be used within a PatientsProvider");
  }
  return context;
}
