"use client";
import {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";
import axios, { AxiosError } from "axios";
import { usePathname, useRouter } from "next/navigation";
import { getCsrfToken } from "@/utils/csrf";
import { useIdleTimeout } from "@/hooks/useIdleTimeout";
import logger from "@/utils/logger";
import { safeStorage } from "@/utils/safeStorage";

// Types
interface User {
  id: string;
  name: string;
  family_name: string;
  email: string;
  role: string;
  is_active: boolean;
  assistant_id?: string;
  plan?: string;
  end_date?: string;
  is_plan_expired?: boolean;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  checking: boolean;
  slowConnection: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string, router: any, setError: (error: string) => void) => Promise<void>;
  logout: () => Promise<void>;
  checkSession: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  changePassword: (token: string, password: string, confirmPassword: string) => Promise<{ success: boolean; error?: string }>;
  isExpiredPlan: boolean;
  subscribe: (plan: string) => Promise<void>;
}

interface AuthProviderProps {
  children: ReactNode;
}

// API Base URL - Update this to match your backend
const API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/auth";
const PAYMENT_API_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/payment";

// Configure axios instance
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true, // Important for sending/receiving cookies
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000, // 30 seconds timeout - allows for slow connections
});

// Add CSRF token interceptor for protected methods
axiosInstance.interceptors.request.use((config) => {
  const protectedMethods = ['post', 'put', 'delete', 'patch'];
  if (config.method && protectedMethods.includes(config.method.toLowerCase())) {
    const csrfToken = getCsrfToken();
    if (csrfToken) {
      config.headers['X-CSRF-Token'] = csrfToken;
    }
  }
  return config;
});

// Intercepteur de réponses : Redirection automatique si session expirée (backend redémarré)
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    const isAuthError = error.response?.status === 401;
    const isNetworkError = error.code === 'ERR_NETWORK' || error.code === 'ECONNABORTED';

    if (isAuthError || isNetworkError) {
      console.warn('🔒 Session expirée ou backend inaccessible - Redirection vers authentification');

      if (typeof window !== 'undefined') {
        const currentPath = window.location.pathname;
        const isPublicPath = currentPath === '/' ||
          currentPath.startsWith('/admin') ||
          currentPath.startsWith('/resset_password');

        if (!isPublicPath) {
          // Sauvegarder l'URL actuelle pour y revenir après reconnexion
          const urlToSave = currentPath + window.location.search;
          logger.log('💾 Saving returnUrl:', urlToSave);
          safeStorage.setItem('returnUrl', urlToSave);
          window.location.href = '/';
        }
      }
    }
    return Promise.reject(error);
  }
);

// Create Context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auth Provider Component
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [slowConnection, setSlowConnection] = useState(false);
  const [isExpiredPlan, setIsExpiredPlan] = useState(false);
  const [checking, setChecking] = useState(true);
  const pathname = usePathname();
  const router = useRouter();

  logger.log("User state changed:", user);

  // Check session ONLY on mount (not on every pathname change)
  // Skip session check entirely for admin pages
  useEffect(() => {
    if (!pathname?.startsWith('/admin')) {
      checkSession();
    } else {
      setChecking(false);
    }
  }, []); // Empty array = runs only once

  // Auto-logout after 15 minutes of inactivity
  const IDLE_TIMEOUT = 15 * 60 * 1000; // 15 minutes in milliseconds
  const isProtectedPage = pathname !== '/' &&
    !pathname?.startsWith('/admin') &&
    !pathname?.startsWith('/resset_password') &&
    !pathname?.startsWith('/shared-medical-file');

  useIdleTimeout({
    timeout: IDLE_TIMEOUT,
    onIdle: () => {
      logger.log('⏰ User idle for 15 minutes - logging out');
      logout();
    },
    enabled: isProtectedPage && !!user, // Only enable on protected pages when user is logged in
  });

  // Heartbeat: Vérifier la session toutes les 10 secondes pour détecter si le backend redémarre
  useEffect(() => {
    // Ne pas faire de heartbeat sur les pages publiques
    if (pathname === '/' || pathname?.startsWith('/admin') || pathname?.startsWith('/resset_password')) {
      return;
    }

    const heartbeatInterval = setInterval(async () => {
      try {
        await axiosInstance.get("/");
      } catch (error) {
        // L'intercepteur gère la redirection automatiquement
        console.warn('💓 Heartbeat failed - session check');
      }
    }, 10000); // Vérifier toutes les 10 secondes

    return () => clearInterval(heartbeatInterval);
  }, [pathname]);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const checkSession = async () => {

    setChecking(true);
    try {
      const response = await axiosInstance.get("/");

      if (response.data.success && response.data.data) {
        setUser(response.data.data.user);
        // Check for plan expiration in response data or user object
        if (response.data.data.is_plan_expired !== undefined) {
          setIsExpiredPlan(response.data.data.is_plan_expired);
        } else if (response.data.data.user?.is_plan_expired !== undefined) {
          setIsExpiredPlan(response.data.data.user.is_plan_expired);
        }
        // Only redirect to dashboard if on login page (and no returnUrl pending)
        if (pathname === "/") {
          const returnUrl = safeStorage.getItem('returnUrl');
          if (returnUrl) {
            logger.log('🔄 checkSession: Found returnUrl, redirecting to:', returnUrl);
            safeStorage.removeItem('returnUrl');
            router.push(returnUrl);
          } else {
            router.push("/dashboard");
          }
        }
      } else {
        // No valid session, clear user
        setUser(null);
        setIsExpiredPlan(false);
        // Only redirect to login if not already there and not on admin pages
        if (pathname !== "/" && !pathname?.startsWith('/admin') && !pathname?.startsWith('/resset_password')) {
          router.push("/");
        }
      }
    } catch (error) {
      // 401 means no session - this is expected when not logged in
      if (axios.isAxiosError(error) && error.response?.status === 401) {
        setUser(null);
        setIsExpiredPlan(false);
        // Only redirect to login if not already there and not on admin pages
        logger.log("Pathname :", pathname);
        if (pathname !== "/" && !pathname?.startsWith('/admin') && !pathname?.startsWith('/resset_password')) {
          router.push("/");
        }
      } else if (axios.isAxiosError(error) && (error.code === 'ECONNABORTED' || error.code === 'ERR_NETWORK')) {
        // Timeout or network error - backend unreachable
        console.error("⚠️ Backend unreachable:", error.message);
        setUser(null);
        setIsExpiredPlan(false);
      } else {
        // Unexpected error
        console.error("❌ Session check failed:", error);
        setUser(null);
        setIsExpiredPlan(false);
      }
    } finally {
      // ALWAYS stop checking to remove spinner
      setChecking(false);
    }
  };

  const login = async (email: string, password: string, router, setError): Promise<void> => {
    setLoading(true);
    setSlowConnection(false);
    logger.log("🔐 Login attempt:", { email, url: `${API_BASE_URL}/login` });

    // Timer to detect slow connection after 5 seconds
    const slowConnectionTimer = setTimeout(() => {
      setSlowConnection(true);
      logger.log("⏳ Slow connection detected, still waiting...");
    }, 5000);

    try {
      const response = await axiosInstance.post("/login", {
        email,
        password,
      });

      // Clear the slow connection timer on success
      clearTimeout(slowConnectionTimer);
      setSlowConnection(false);

      logger.log("✅ Login response:", response.data);

      if (response.data.success && response.data.data?.user) {
        setUser(response.data.data.user);

        // Check for plan expiration in response data or user object
        if (response.data.data.is_plan_expired !== undefined) {
          setIsExpiredPlan(response.data.data.is_plan_expired);
        } else if (response.data.data.user?.is_plan_expired !== undefined) {
          setIsExpiredPlan(response.data.data.user.is_plan_expired);
        }

        // Keep loading=true to show the loader
        // Show success loader for 2.5 seconds total (1s button + 1.5s spinner)
        setTimeout(() => {
          setLoading(false);
          // Vérifier s'il y a une URL de retour sauvegardée
          const returnUrl = safeStorage.getItem('returnUrl');
          logger.log('🔍 Checking returnUrl:', returnUrl);
          if (returnUrl) {
            logger.log('✅ Redirecting to saved URL:', returnUrl);
            safeStorage.removeItem('returnUrl');
            window.location.href = returnUrl; // Force navigation complète
          } else {
            logger.log('➡️ No returnUrl, going to dashboard');
            window.location.href = "/dashboard"; // Force navigation complète
          }
        }, 2500);

        // Return resolved promise so the caller knows login succeeded
        return Promise.resolve();
      } else {
        console.error("❌ Invalid response structure:", response.data);
        setError("Invalid response from server !");
        setLoading(false);
        throw new Error("Invalid response from server");
      }
    } catch (error) {
      // Clear the slow connection timer on error
      clearTimeout(slowConnectionTimer);
      setSlowConnection(false);
      console.error("❌ Login error:", error);

      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError<{ error: string }>;
        console.error("📊 Error details:", {
          status: axiosError.response?.status,
          statusText: axiosError.response?.statusText,
          data: axiosError.response?.data,
          message: axiosError.message
        });

        // Handle timeout specifically
        if (axiosError.code === 'ECONNABORTED' || axiosError.message?.includes('timeout')) {
          setError("Connexion trop lente - Veuillez réessayer");
        } else if (axiosError.code === 'ERR_NETWORK') {
          setError("Erreur réseau - Vérifiez votre connexion internet");
        } else {
          setError(axiosError.response?.data?.error || "Échec de connexion");
        }
      } else {
        console.error("📊 Non-Axios error:", error);
        setError("Erreur réseau - Vérifiez si le serveur est accessible");
      }

      setLoading(false);
      throw error;
    }
  };

  const logout = async () => {
    try {
      const response = await axiosInstance.post("/logout");

      if (response.data.success) {
        window.location.href = "/";
        setUser(null);
        setIsExpiredPlan(false);
      } else {
        console.error("Logout failed:", response.data);
        // Still logout on client side even if server logout fails
        window.location.href = "/";
        setUser(null);
        setIsExpiredPlan(false);
      }
    } catch (error) {
      console.error("Logout error:", error);
      // Even if logout request fails, clear user locally and redirect
      // This ensures user is logged out on client side
      window.location.href = "/";
      setUser(null);
      setIsExpiredPlan(false);
    }
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    logger.log("🔐 Reset password attempt:", { email, url: `${API_BASE_URL}/reset-password` });

    try {
      const response = await axiosInstance.post("/reset-password", {
        email: email.trim(),
      });

      logger.log("✅ Reset password response:", response.data);

      if (response.data.success) {
        return { success: true };
      } else {
        return {
          success: false,
          error: response.data.error || "Une erreur est survenue"
        };
      }
    } catch (error) {
      console.error("❌ Reset password error:", error);

      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError<{ error: string; message: string }>;
        const errorMessage = axiosError.response?.data?.error ||
          axiosError.response?.data?.message ||
          "Impossible de se connecter au serveur";
        return { success: false, error: errorMessage };
      }

      return { success: false, error: "Une erreur inattendue est survenue" };
    }
  };

  const changePassword = async (
    token: string,
    password: string,
    confirmPassword: string
  ): Promise<{ success: boolean; error?: string }> => {
    logger.log("🔐 Change password attempt:", { url: `${API_BASE_URL}/change-password` });

    try {
      const response = await axiosInstance.post("/change-password", {
        token,
        password,
        confirmPassword,
      });

      logger.log("✅ Change password response:", response.data);

      if (response.data.success) {
        return { success: true };
      } else {
        return {
          success: false,
          error: response.data.error || "Une erreur est survenue"
        };
      }
    } catch (error) {
      console.error("❌ Change password error:", error);

      if (axios.isAxiosError(error)) {
        const axiosError = error as AxiosError<{ error: string; message: string }>;
        const errorMessage = axiosError.response?.data?.error ||
          axiosError.response?.data?.message ||
          "Impossible de se connecter au serveur";
        return { success: false, error: errorMessage };
      }

      return { success: false, error: "Une erreur inattendue est survenue" };
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    slowConnection,
    isAuthenticated: !!user,
    login,
    checking,
    logout,
    checkSession,
    resetPassword,
    changePassword,
    isExpiredPlan,
    subscribe: async (plan: string) => {
      setLoading(true);
      try {
        const response = await axios.post(`${PAYMENT_API_URL}/subscribe`, {
          plan
        }, {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json"
          }
        });

        if (response.data.success && response.data.data.checkout_url) {
          window.location.href = response.data.data.checkout_url;
        } else {
          // throw error if needed or let the component handle it via catch if I re-throw,
          // but here I'm catching and just logging. Ideally I should let component know.
          // For now, let's keep it simple as requested: "function should redirect".
          console.error("Subscription failed: No checkout URL");
        }
      } catch (error) {
        console.error("Subscription error:", error);
        // Rethrow so components can turn off loading state
        throw error;
      } finally {
        setLoading(false);
      }
    },
  };

  return <AuthContext.Provider value={value}>
    {children}
  </AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
