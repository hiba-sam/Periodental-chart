'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import axios from 'axios';

// ============================================
// TYPES
// ============================================

interface Admin {
    id: number;
    name: string;
    email: string;
    role: 'admin' | 'super_admin';
}

interface AdminAuthContextType {
    admin: Admin | null;
    loading: boolean;
    login: (email: string, password: string) => Promise<void>;
    logout: () => Promise<void>;
    checkSession: () => Promise<void>;
    isAuthenticated: boolean;
}

// ============================================
// CONTEXT
// ============================================

const AdminAuthContext = createContext<AdminAuthContextType | undefined>(undefined);

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

// Configure axios instance for admin with 401 interceptor
const adminAxiosInstance = axios.create({
    baseURL: API_URL,
    withCredentials: true,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Intercepteur de réponses : Redirection automatique si session expirée (backend redémarré)
adminAxiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
        const isAuthError = error.response?.status === 401;
        const isNetworkError = error.code === 'ERR_NETWORK' || error.code === 'ECONNABORTED';
        
        if (isAuthError || isNetworkError) {
            console.warn('🔒 Admin session expirée ou backend inaccessible - Redirection vers authentification');
            
            if (typeof window !== 'undefined') {
                const currentPath = window.location.pathname;
                // Si on est sur une page admin protégée, rediriger vers login admin
                if (currentPath.startsWith('/admin') && currentPath !== '/admin/login') {
                    window.location.href = '/admin/login';
                }
            }
        }
        return Promise.reject(error);
    }
);

// ============================================
// PROVIDER
// ============================================

export function AdminAuthProvider({ children }: { children: ReactNode }) {
    const [admin, setAdmin] = useState<Admin | null>(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    // Check session on mount
    const checkSession = async () => {
        try {
            const response = await adminAxiosInstance.get('/admin/session');
            
            if (response.data.success) {
                setAdmin(response.data.data.admin);
            } else {
                setAdmin(null);
            }
        } catch (error) {
            setAdmin(null);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        checkSession();
    }, []);

    // Login
    const login = async (email: string, password: string) => {
        setLoading(true);
        try {
            const response = await adminAxiosInstance.post('/admin/login', { email, password });

            if (response.data.success) {
                setAdmin(response.data.data.admin);
                // Note: la redirection est gérée par la page de login
                // pour utiliser le returnUrl
            } else {
                throw new Error(response.data.error || 'Login failed');
            }
        } catch (error: any) {
            console.error('Login error:', error);
            throw new Error(error.response?.data?.error || 'Login failed');
        } finally {
            setLoading(false);
        }
    };

    // Logout
    const logout = async () => {
        try {
            await adminAxiosInstance.post('/admin/logout');
            setAdmin(null);
            router.push('/admin/login');
        } catch (error) {
            console.error('Logout error:', error);
            // Force logout on client side even if request fails
            setAdmin(null);
            router.push('/admin/login');
        }
    };

    const value = {
        admin,
        loading,
        login,
        logout,
        checkSession,
        isAuthenticated: admin !== null
    };

    return (
        <AdminAuthContext.Provider value={value}>
            {children}
        </AdminAuthContext.Provider>
    );
}

// ============================================
// HOOK
// ============================================

export function useAdminAuth() {
    const context = useContext(AdminAuthContext);
    if (!context) {
        throw new Error('useAdminAuth must be used within AdminAuthProvider');
    }
    return context;
}
