'use client';

/**
 * HeaderContext
 * ─────────────
 * Lets any page/component tell the mobile header to switch into
 * "back mode" — replacing the hamburger menu icon with a back arrow
 * and optionally showing a page title next to it.
 *
 * It also supports "hide mode" — completely hiding the header on
 * pages that don't need it (e.g. full-screen views).
 *
 * Usage in a page component:
 *   const { setBackMode, clearBackMode, setHidden } = useHeaderContext();
 *
 *   useEffect(() => {
 *     setBackMode({ title: 'Patient Detail', href: '/patients' });
 *     return () => clearBackMode();
 *   }, []);
 *
 *   // To hide the header entirely:
 *   useEffect(() => {
 *     setHidden(true);
 *     return () => setHidden(false);
 *   }, []);
 */

import React, { createContext, useContext, useState, useCallback } from 'react';

export interface BackModeConfig {
    /** Optional label shown next to the arrow */
    title?: string;
    /** If provided, clicking the arrow navigates to this URL */
    href?: string;
    /** If provided (and no href), called on arrow click */
    onBack?: () => void;
}

interface HeaderContextValue {
    backMode: BackModeConfig | null;
    setBackMode: (config: BackModeConfig) => void;
    clearBackMode: () => void;
    /** When true the header should be hidden entirely */
    hidden: boolean;
    setHidden: (hidden: boolean) => void;
}

const HeaderContext = createContext<HeaderContextValue>({
    backMode: null,
    setBackMode: () => { },
    clearBackMode: () => { },
    hidden: false,
    setHidden: () => { },
});

export function HeaderProvider({ children }: { children: React.ReactNode }) {
    const [backMode, setBackModeState] = useState<BackModeConfig | null>(null);
    const [hidden, setHiddenState] = useState(false);

    const setBackMode = useCallback((config: BackModeConfig) => {
        setBackModeState(config);
    }, []);

    const clearBackMode = useCallback(() => {
        setBackModeState(null);
    }, []);

    const setHidden = useCallback((value: boolean) => {
        setHiddenState(value);
    }, []);

    return (
        <HeaderContext.Provider value={{ backMode, setBackMode, clearBackMode, hidden, setHidden }}>
            {children}
        </HeaderContext.Provider>
    );
}

export function useHeaderContext() {
    return useContext(HeaderContext);
}
