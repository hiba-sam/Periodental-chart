"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from "react";
import axios, { AxiosError } from "axios";
import { useAuth } from "./AuthContext";
import { toast } from "@/components/ui/use-toast";
import socketClient from "@/utils/socketClient";
import logger from "@/utils/logger";
import { useQueryClient } from "@tanstack/react-query";
import { dashboardKeys } from "@/features/dashboard/hooks/useDashboardStats";

// Types alignés au backend
export interface Appointment {
  id: string;
  patient_id: string;
  doctor_user_id?: number | string;
  date: Date | string; // ISO yyyy-mm-dd
  time: string; // HH:mm ou HH:mm:ss
  duration?: number;
  notes?: string;
  confirmed_coming: boolean;
  is_done: boolean;
  color?: string;
  created_at?: string | Date;
  updated_at?: string | Date;
  arrived_at?: string | Date | null;
  patient_name?: string;
  patient_family_name?: string;
  patientName?: string
}

export type CreateAppointmentPayload = {
  patient_id: string;
  date: string; // ISO yyyy-mm-dd
  time: string; // HH:mm ou HH:mm:ss
  duration?: number;
  notes?: string;
  confirmed_coming?: boolean;
  is_done?: boolean;
  color?: string;
};

export type UpdateAppointmentPayload = Partial<CreateAppointmentPayload>;

interface AppointmentsContextType {
  appointments: Appointment[];
  loading: boolean;
  error: string | null;

  fetchAppointments: (
    limit?: number,
    offset?: number
  ) => Promise<Appointment[]>;
  fetchAppointmentsByDate: (
    date: string | Date,
    limit?: number,
    offset?: number
  ) => Promise<Appointment[]>;
  fetchAppointmentsByPatient: (
    patientId: string,
    limit?: number,
    offset?: number
  ) => Promise<Appointment[]>;

  getAppointment: (
    id: string,
  ) => Promise<Appointment | undefined>;
  createAppointment: (
    payload: CreateAppointmentPayload,
  ) => Promise<Appointment | undefined>;
  updateAppointment: (
    id: string,
    payload: UpdateAppointmentPayload,
  ) => Promise<Appointment | undefined>;
  deleteAppointment: (
    id: string,
  ) => Promise<boolean>;
}

const AppointmentsContext = createContext<AppointmentsContextType | undefined>(
  undefined
);

const API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/appointment";
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

export function AppointmentsProvider({ children }: { children: ReactNode }) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { user } = useAuth();
  const doctorUserId = user?.id;
  const queryClient = useQueryClient();

  // API operations
  const fetchAppointments = async (
    limit: number = 50,
    offset: number = 0
  ): Promise<Appointment[]> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.get("/", {
        params: { doctorUserId, limit, offset },
      });
      if (response.data?.success) {
        const data = response.data.data as Appointment[];
        setAppointments(data);
        return data;
      }
      const msg =
        response.data?.error || "Échec du chargement des rendez-vous.";
      setError(msg);
      return [];
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement des rendez-vous.";
      setError(message);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const fetchAppointmentsByDate = async (
    date: string | Date,
    limit: number = 100,
    offset: number = 0
  ): Promise<Appointment[]> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.get("/date", {
        params: { date, doctorUserId, limit, offset },
      });
      if (response.data?.success) {
        return response.data.data as Appointment[];
      }
      const msg =
        response.data?.error || "Échec du chargement des rendez-vous par date.";
      setError(msg);
      return [];
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement des rendez-vous par date.";
      setError(message);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const fetchAppointmentsByPatient = async (
    patientId: string,
    limit: number = 50,
    offset: number = 0
  ): Promise<Appointment[]> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.get(`/patient/${patientId}`, {
        params: { doctorUserId, limit, offset },
      });
      if (response.data?.success) {
        return response.data.data as Appointment[];
      }
      const msg =
        response.data?.error || "Échec du chargement des rendez-vous patient.";
      setError(msg);
      return [];
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement des rendez-vous patient.";
      setError(message);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const getAppointment = async (
    id: string,
  ): Promise<Appointment | undefined> => {
    setError(null);
    try {
      const response = await axiosInstance.get(`/${id}`, {
        params: { doctorUserId },
      });
      if (response.data?.success) {
        return response.data.data as Appointment;
      }
      const msg =
        response.data?.error || "Échec de la récupération du rendez-vous.";
      setError(msg);
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la récupération du rendez-vous.";
      setError(message);
      return undefined;
    }
  };

  const createAppointment = async (
    payload: CreateAppointmentPayload,
  ): Promise<Appointment | undefined> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.post("/", payload, {
        params: { doctorUserId },
      });
      if (response.status === 201 && response.data?.success) {
        const created = response.data.data as Appointment;
        setAppointments((prev) => [...prev, created]);
        toast.success("Rendez-vous créé avec succès");
        return created;
      }
      const msg =
        response.data?.error || "Échec de la création du rendez-vous.";
      setError(msg);
      toast.error(msg, "Erreur");
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la création du rendez-vous.";
      setError(message);
      toast.error(message, "Erreur");
      logger.log(err);
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  const updateAppointment = async (
    id: string,
    payload: UpdateAppointmentPayload,
  ): Promise<Appointment | undefined> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.put(`/${id}`, payload, {
        params: { doctorUserId },
      });
      if (response.data?.success) {
        const updated = response.data.data as Appointment;
        setAppointments((prev) => prev.map((a) => (a.id === id ? updated : a)));
        toast.success("Rendez-vous mis à jour avec succès");
        return updated;
      }
      const msg =
        response.data?.error || "Échec de la mise à jour du rendez-vous.";
      setError(msg);
      toast.error(msg, "Erreur");
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la mise à jour du rendez-vous.";
      setError(message);
      toast.error(message, "Erreur");
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  const deleteAppointment = async (
    id: string,
  ): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const response = await axiosInstance.delete(`/${id}`, {
        params: { doctorUserId },
      });
      if (response.data?.success) {
        setAppointments((prev) => prev.filter((a) => a.id !== id));
        toast.success("Rendez-vous supprimé avec succès");
        return true;
      }
      const msg =
        response.data?.error || "Échec de la suppression du rendez-vous.";
      setError(msg);
      toast.error(msg, "Erreur");
      return false;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la suppression du rendez-vous.";
      setError(message);
      toast.error(message, "Erreur");
      return false;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [doctorUserId]);

  // Socket.IO Integration for real-time appointment updates
  useEffect(() => {
    const socket = socketClient.connect();

    if (!socket) {
      return;
    }

    const handleAppointmentCreated = (newAppointment: Appointment) => {
      setAppointments(prev => {
        // Avoid duplicates
        if (prev.some(a => a.id === newAppointment.id)) return prev;
        return [newAppointment, ...prev];
      });
      // Invalidate dashboard stats to show updated appointment count
      queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    const handleAppointmentUpdated = (updatedAppointment: Appointment) => {
      setAppointments(prev => {
        const oldAppointment = prev.find(a => a.id === updatedAppointment.id);
        const isDoneChanged = oldAppointment && oldAppointment.is_done !== updatedAppointment.is_done;

        // If completion status changed, invalidate dashboard stats
        if (isDoneChanged) {
          queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
        }

        return prev.map(a => a.id === updatedAppointment.id ? { ...a, ...updatedAppointment } : a);
      });
    };

    const handleAppointmentDeleted = (data: { id: string }) => {
      setAppointments(prev => prev.filter(a => a.id !== data.id));
      // Invalidate dashboard stats to show updated appointment count
      queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    socket.on('appointment:created', handleAppointmentCreated);
    socket.on('appointment:updated', handleAppointmentUpdated);
    socket.on('appointment:deleted', handleAppointmentDeleted);

    return () => {
      socket.off('appointment:created', handleAppointmentCreated);
      socket.off('appointment:updated', handleAppointmentUpdated);
      socket.off('appointment:deleted', handleAppointmentDeleted);
    };
  }, []);



  // ⚠️ [error] dep is required — without it, a new 5s timer is created on EVERY
  //    render, which floods the call stack during navigation and fires setError(null)
  //    on unmounted components.
  useEffect(() => {
    if (!error) return;
    const resetError = setTimeout(() => {
      setError(null);
    }, 5000);

    return () => clearTimeout(resetError);
  }, [error]); // ← was missing entirely

  const value: AppointmentsContextType = {
    appointments,
    loading,
    error,
    fetchAppointments,
    fetchAppointmentsByDate,
    fetchAppointmentsByPatient,
    getAppointment,
    createAppointment,
    updateAppointment,
    deleteAppointment,
  };

  return (
    <AppointmentsContext.Provider value={value}>
      {children}
    </AppointmentsContext.Provider>
  );
}

// Hook personnalisé pour utiliser le contexte
export function useAppointmentsContext() {
  const context = useContext(AppointmentsContext);
  if (context === undefined) {
    throw new Error(
      "useAppointmentsContext must be used within an AppointmentsProvider"
    );
  }
  return context;
}

// Alias pour compatibilité
export const useAppointments = useAppointmentsContext;
