'use client';

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import { safeStorage } from '@/utils/safeStorage';

export type Theme = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: Theme;
  actualTheme: 'light' | 'dark';
  setTheme: (newTheme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const pathname = usePathname();
  const [mounted, setMounted] = useState(false);
  // Initialize with default values to match server render (prevents hydration error)
  const [theme, setTheme] = useState<Theme>('light');
  const [actualTheme, setActualTheme] = useState<'light' | 'dark'>('light');

  // Load theme from localStorage and apply it AFTER mount (client-side only)
  useEffect(() => {
    setMounted(true);
    const savedTheme = safeStorage.getItem('theme') as Theme;
    const initialTheme = savedTheme || 'light'; // Default to 'light' if no saved theme

    setTheme(initialTheme); // Set the theme state based on localStorage or default

    // Calculate and apply the effective theme immediately
    let effectiveTheme: 'light' | 'dark' = 'light';
    if (pathname?.startsWith('/admin')) {
      effectiveTheme = 'light'; // Force light theme for admin pages
    } else if (initialTheme === 'dark') {
      effectiveTheme = 'dark';
    } else if (initialTheme === 'system') {
      effectiveTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    setActualTheme(effectiveTheme);
    if (effectiveTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [pathname]); // Depend on pathname for initial admin check

  // Effect to handle theme changes (from user interaction or system preference)
  useEffect(() => {
    if (!mounted) return; // Only run after initial mount and setup

    // Save the theme to localStorage
    safeStorage.setItem('theme', theme);

    // Calculate the effective theme
    let effectiveTheme: 'light' | 'dark' = 'light';

    // Force light theme for admin pages
    if (pathname?.startsWith('/admin')) {
      effectiveTheme = 'light';
    } else if (theme === 'dark') {
      effectiveTheme = 'dark';
    } else if (theme === 'system') {
      // Detect system preference
      effectiveTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    setActualTheme(effectiveTheme);

    // Apply CSS classes to the document
    if (effectiveTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme, pathname, mounted]); // Re-run when theme, pathname, or mounted state changes

  // Listen for system preference changes
  useEffect(() => {
    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

      const handleChange = () => {
        const systemTheme = mediaQuery.matches ? 'dark' : 'light';
        setActualTheme(systemTheme);

        if (systemTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      };

      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, actualTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
