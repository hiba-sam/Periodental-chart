'use client';

import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import axios from 'axios';
import { getBcp47Locale, formatDateWithOptions, type SupportedLanguage as SupportedLang } from '@/utils/formatDate';
import { safeStorage } from '@/utils/safeStorage';

// Import all locale files
import enLocale from '../../locales/en.json';
import frLocale from '../../locales/fr.json';
import arLocale from '../../locales/ar.json';

type LocaleData = Record<string, any>;

type SupportedLanguage = 'en' | 'fr' | 'ar';

const locales: Record<SupportedLanguage, LocaleData> = {
  en: enLocale,
  fr: frLocale,
  ar: arLocale,
};

// Default language
const DEFAULT_LANGUAGE: SupportedLanguage = 'fr';
const STORAGE_KEY = 'mypresc_language';
const BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3333';

interface LanguageContextType {
  language: SupportedLanguage;
  locale: string;
  changeLanguage: (newLanguage: string) => Promise<void>;
  t: (key: string, optionsOrFallback?: string | Record<string, any>) => string;
  formatDate: (date: Date | string | number, options?: Intl.DateTimeFormatOptions) => string;
  availableLanguages: string[];
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<SupportedLanguage>(DEFAULT_LANGUAGE);
  const [isClient, setIsClient] = useState(false);

  // Type guard to check if a string is a supported language
  const isSupportedLanguage = (lang: string): lang is SupportedLanguage => {
    return lang === 'en' || lang === 'fr' || lang === 'ar';
  };

  // Initialize language from localStorage on mount (client-side only)
  useEffect(() => {
    setIsClient(true);
    const savedLanguage = safeStorage.getItem(STORAGE_KEY);
    if (savedLanguage && isSupportedLanguage(savedLanguage)) {
      setLanguage(savedLanguage);
    }
  }, []);

  // Update localStorage and HTML dir/lang attributes when language changes
  useEffect(() => {
    if (isClient) {
      safeStorage.setItem(STORAGE_KEY, language);

      // Update HTML attributes
      const htmlElement = document.documentElement;
      htmlElement.setAttribute('lang', language);

      // Set RTL for Arabic
      if (language === 'ar') {
        htmlElement.setAttribute('dir', 'rtl');
        document.body.style.textAlign = 'right';
        // Apply Cairo font for Arabic
        document.body.style.fontFamily = "'Cairo', 'Arial', sans-serif";
      } else {
        htmlElement.setAttribute('dir', 'ltr');
        document.body.style.textAlign = 'left';
        // Reset to default font
        document.body.style.fontFamily = '';
      }
    }
  }, [language, isClient]);

  // Translation function with dot notation support (e.g., "home.title")
  const t = (key: string, optionsOrFallback?: string | Record<string, any>): string => {
    const keys = key.split('.');
    let value: any = locales[language];

    // Determine arguments
    let fallback = key;
    let options: Record<string, any> = {};

    if (typeof optionsOrFallback === 'string') {
      fallback = optionsOrFallback;
    } else if (typeof optionsOrFallback === 'object' && optionsOrFallback !== null) {
      options = optionsOrFallback;
    }

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to English if key doesn't exist
        value = locales[DEFAULT_LANGUAGE];
        for (const k of keys) {
          if (value && typeof value === 'object' && k in value) {
            value = value[k];
          } else {
            return fallback;
          }
        }
        break;
      }
    }

    if (typeof value === 'string') {
      // Interpolation logic: replace {{key}} with options[key]
      return value.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        return options[key] !== undefined ? String(options[key]) : match;
      });
    }

    return fallback;
  };

  // Function to change language
  const changeLanguage = async (newLanguage: string): Promise<void> => {
    if (isSupportedLanguage(newLanguage)) {
      setLanguage(newLanguage);

      // Update language on server
      try {
        await axios.put(`${BASE_URL}/user/language`,
          { language: newLanguage },
          { withCredentials: true }
        );
      } catch (error) {
        // Silently fail or log error - we don't want to block the UI change
        console.error('Failed to update language on server:', error);
      }
    } else {
      console.warn(`Language "${newLanguage}" not found. Available languages: ${Object.keys(locales).join(', ')}`);
    }
  };

  // Memoized locale value based on language
  const locale = getBcp47Locale(language as SupportedLang);

  // Format date helper using current language
  const formatDate = useCallback(
    (date: Date | string | number, options?: Intl.DateTimeFormatOptions) => {
      return formatDateWithOptions(date, language as SupportedLang, options);
    },
    [language]
  );

  const value = {
    language,
    locale,
    changeLanguage,
    t,
    formatDate,
    availableLanguages: Object.keys(locales),
    isRTL: language === 'ar',
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

// Custom hook to use the language context
export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
