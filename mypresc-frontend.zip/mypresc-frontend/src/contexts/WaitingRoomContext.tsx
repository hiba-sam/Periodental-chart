"use client";

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import axios, { AxiosError } from "axios";
import { useAuth } from "./AuthContext";
import { toast } from "@/components/ui/use-toast";
import { useAppointments } from "./AppointmentContext";
import socketClient from "@/utils/socketClient";
import logger from "@/utils/logger";
import { useQueryClient } from "@tanstack/react-query";
import { dashboardKeys } from "@/features/dashboard/hooks/useDashboardStats";

export type WaitingStatus = string;

export interface WaitingEntry {
  id: string;
  patient_id: string;
  doctor_user_id: number;
  status?: WaitingStatus;
  arrived_at?: string | Date;
  called_at?: string | Date;
  notes?: string;
  created_at?: string | Date;
  updated_at?: string | Date;
  patient_name?: string;
  patient_family_name?: string;
}

export type CreateWaitingEntryPayload = {
  patient_id: string;
  status?: WaitingStatus;
  arrived_at?: string; // ISO
  called_at?: string; // ISO
  notes?: string;
};

export type UpdateWaitingEntryPayload = Partial<CreateWaitingEntryPayload>;

type TodayScheduleItem =
  | { type: "appointment"; appointment: any }
  | { type: "waiting"; waiting: WaitingEntry };

export interface NextPatientData {
  type: 'appointment' | 'waiting';
  id: string;
  patientId: string;
  patientName: string;
}

export interface CurrentCallData {
  patientId: string;
  patientName: string;
  type: string;
  consultationStartedAt: string;
}

interface WaitingRoomContextType {
  entries: WaitingEntry[];
  loading: boolean;
  error: string | null;
  fetchEntries: (
    doctorUserId: number | string,
    limit?: number,
    offset?: number
  ) => Promise<WaitingEntry[]>;
  getEntry: (
    id: string,
    doctorUserId: number | string
  ) => Promise<WaitingEntry | undefined>;
  createEntry: (
    payload: CreateWaitingEntryPayload,
    doctorUserId: number | string
  ) => Promise<WaitingEntry | undefined>;
  updateEntry: (
    id: string,
    payload: UpdateWaitingEntryPayload,
    doctorUserId: number | string
  ) => Promise<WaitingEntry | undefined>;
  deleteEntry: (id: string, doctorUserId: number | string) => Promise<boolean>;
  getTodaySchedule: (
    doctorUserId: number | string
  ) => Promise<TodayScheduleItem[]>;
  schedule: TodayScheduleItem[];
  peekNextPatient: (doctorUserId: number | string) => Promise<NextPatientData | null>;
  callNextPatient: (doctorUserId: number | string) => Promise<NextPatientData | null>;
  getCurrentCall: (doctorUserId: number | string) => Promise<CurrentCallData | null>;
  currentCall: CurrentCallData | null;
}

const WaitingRoomContext = createContext<WaitingRoomContextType | undefined>(
  undefined
);

const API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/waiting-room";
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

export function WaitingRoomProvider({ children }: { children: ReactNode }) {
  const [entries, setEntries] = useState<WaitingEntry[]>([]);
  const [schedule, setSchedule] = useState<TodayScheduleItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentCall, setCurrentCall] = useState<CurrentCallData | null>(null);
  const { appointments } = useAppointments();

  const { user } = useAuth();
  const doctorUserId = user?.id;
  const queryClient = useQueryClient();


  const fetchEntries = async (
    doctorUserId: number | string,
    limit: number = 50,
    offset: number = 0
  ): Promise<WaitingEntry[]> => {
    setLoading(true);
    setError(null);
    try {
      const res = await axiosInstance.get("/", {
        params: { doctorUserId, limit, offset },
      });
      if (res.data?.success) {
        const data = res.data.data as WaitingEntry[];
        setEntries(data);
        return data;
      }
      const msg =
        res.data?.error || "Échec du chargement de la salle d'attente.";
      setError(msg);
      return [];
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement de la salle d'attente.";
      setError(message);
      return [];
    } finally {
      setLoading(false);
    }
  };

  const getEntry = async (
    id: string,
    doctorUserId: number | string
  ): Promise<WaitingEntry | undefined> => {
    setError(null);
    try {
      const res = await axiosInstance.get(`/${id}`, {
        params: { doctorUserId },
      });
      if (res.data?.success) return res.data.data as WaitingEntry;
      const msg = res.data?.error || "Échec de la récupération de l'entrée.";
      setError(msg);
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la récupération de l'entrée.";
      setError(message);
      return undefined;
    }
  };

  const createEntry = async (
    payload: CreateWaitingEntryPayload,
    doctorUserId: number | string
  ): Promise<WaitingEntry | undefined> => {
    setLoading(true);
    setError(null);
    try {
      const res = await axiosInstance.post("/", payload, {
        params: { doctorUserId },
      });
      if (res.status === 201 && res.data?.success) {
        const created = res.data.data as WaitingEntry;
        // Note: Ne pas faire de mise à jour optimiste ici car le socket va envoyer l'événement
        // et le handler handleWaitingRoomCreated va mettre à jour entries et schedule
        toast.success("Patient ajouté à la salle d'attente");
        return created;
      }
      const msg = res.data?.error || "Échec de la création de l'entrée.";
      setError(msg);
      toast.error(msg, "Erreur");
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la création de l'entrée.";
      setError(message);
      toast.error(message, "Erreur");
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  const updateEntry = async (
    id: string,
    payload: UpdateWaitingEntryPayload,
    doctorUserId: number | string
  ): Promise<WaitingEntry | undefined> => {
    setLoading(true);
    setError(null);
    try {
      const res = await axiosInstance.put(`/${id}`, payload, {
        params: { doctorUserId },
      });
      if (res.data?.success) {
        const updated = res.data.data as WaitingEntry;
        setEntries((prev) => prev.map((e) => (e.id === id ? updated : e)));
        toast.success("Entrée mise à jour");
        return updated;
      }
      const msg = res.data?.error || "Échec de la mise à jour de l'entrée.";
      setError(msg);
      toast.error(msg, "Erreur");
      return undefined;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la mise à jour de l'entrée.";
      setError(message);
      toast.error(message, "Erreur");
      return undefined;
    } finally {
      setLoading(false);
    }
  };

  const deleteEntry = async (
    id: string,
    doctorUserId: number | string
  ): Promise<boolean> => {
    setLoading(true);
    setError(null);
    try {
      const res = await axiosInstance.delete(`/${id}`, {
        params: { doctorUserId },
      });
      if (res.data?.success) {
        setEntries((prev) => prev.filter((e) => e.id !== id));
        // Mise à jour optimiste du schedule (ordre de passage)
        setSchedule((prev) => prev.filter((item) => {
          if (item.type === 'waiting' && (item as any).waiting?.id === id) return false;
          return true;
        }));
        toast.success("Entrée supprimée");
        return true;
      }
      const msg = res.data?.error || "Échec de la suppression de l'entrée.";
      setError(msg);
      toast.error(msg, "Erreur");
      return false;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec de la suppression de l'entrée.";
      setError(message);
      toast.error(message, "Erreur");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const getTodaySchedule = async (
    doctorUserId: number | string
  ): Promise<TodayScheduleItem[]> => {
    setError(null);
    try {
      logger.log('[WaitingRoom] Fetching schedule for doctorUserId:', doctorUserId);
      const res = await axiosInstance.get("/schedule", {
        params: { doctorUserId },
      });
      logger.log('[WaitingRoom] Schedule API response:', res.data);
      if (res.data?.success) {
        const data = res.data.data as TodayScheduleItem[];
        logger.log('[WaitingRoom] Schedule data:', data);
        setSchedule(data);
        return data;
      }
      const msg = res.data?.error || "Échec du chargement du planning du jour.";
      setError(msg);
      return [];
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data && (axiosErr.response.data as any).error
          ? (axiosErr.response.data as any).error
          : "Échec du chargement du planning du jour.";
      setError(message);
      return [];
    }
  };

  useEffect(() => {
    if (doctorUserId) {
      logger.log('[WaitingRoom] Fetching entries for doctorUserId:', doctorUserId);
      fetchEntries(doctorUserId as string, 50, 0).then(data => {
        logger.log('[WaitingRoom] Fetched entries:', data);
      });
      getTodaySchedule(doctorUserId as string);
    }
  }, [doctorUserId]);

  // Socket.IO Integration for real-time waiting room updates
  useEffect(() => {
    if (!doctorUserId) return;

    const socket = socketClient.connect();

    if (!socket) {
      return;
    }

    // Set the doctor-assistants room to join (socketClient handles auto-join on connect)
    socketClient.joinDoctorAssistantsRoom(doctorUserId);

    // Track processed event IDs to prevent duplicates
    const processedIds = new Set<string>();

    const handleWaitingRoomCreated = (data: WaitingEntry) => {
      logger.log('[WaitingRoom Socket] Received waitingRoom:created event:', data);

      // Skip if already processed this event
      if (processedIds.has(data.id)) {
        logger.log('[WaitingRoom Socket] Event already processed, skipping');
        return;
      }
      processedIds.add(data.id);

      // Mise à jour des entries avec vérification de doublon
      setEntries(prev => {
        if (prev.some(e => e.id === data.id)) {
          logger.log('[WaitingRoom Socket] Entry already exists in state, skipping');
          return prev;
        }
        logger.log('[WaitingRoom Socket] Adding new entry to state');
        return [data, ...prev];
      });

      // Mise à jour optimiste du schedule avec vérification de doublon
      setSchedule(prev => {
        if (prev.some(item => item.type === 'waiting' && (item as any).waiting?.id === data.id)) return prev;
        return [...prev, { type: 'waiting', waiting: data }];
      });

      // Invalidate dashboard stats to show updated waiting patients count
      queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    const handleWaitingRoomUpdated = (data: WaitingEntry) => {
      setEntries(prev => prev.map(e => e.id === data.id ? data : e));
      // Rafraîchir le schedule pour mettre à jour l'ordre de passage
      if (doctorUserId) {
        getTodaySchedule(doctorUserId);
      }
    };

    const handleWaitingRoomDeleted = (data: { id: string }) => {
      setEntries(prev => prev.filter(e => e.id !== data.id));
      // Rafraîchir le schedule pour mettre à jour l'ordre de passage
      if (doctorUserId) {
        getTodaySchedule(doctorUserId);
      }
      // Invalidate dashboard stats to show updated waiting patients count
      queryClient.invalidateQueries({ queryKey: dashboardKeys.stats() });
    };

    // Handler pour les mises à jour de RDV (notamment changement de arrived_at)
    const handleAppointmentUpdated = () => {
      // Rafraîchir le schedule car le statut arrivé peut avoir changé
      if (doctorUserId) {
        getTodaySchedule(doctorUserId);
      }
    };

    // Attach listeners when socket connects
    let listenersAttached = false;

    const attachListeners = () => {
      if (listenersAttached) return;
      const currentSocket = socketClient.getSocket();
      if (!currentSocket) return;

      listenersAttached = true;
      logger.log('[WaitingRoom Socket] Attaching listeners to socket:', currentSocket.id);
      currentSocket.on('waitingRoom:created', handleWaitingRoomCreated);
      currentSocket.on('waitingRoom:updated', handleWaitingRoomUpdated);
      currentSocket.on('waitingRoom:deleted', handleWaitingRoomDeleted);
      currentSocket.on('appointment:updated', handleAppointmentUpdated);
      logger.log('[WaitingRoom Socket] Listeners attached for waitingRoom and appointment events');
    };

    // Use socketClient.onConnect which handles both immediate and delayed connection
    const cleanupOnConnect = socketClient.onConnect(attachListeners);

    return () => {
      cleanupOnConnect();
      const currentSocket = socketClient.getSocket();
      if (currentSocket) {
        currentSocket.off('waitingRoom:created', handleWaitingRoomCreated);
        currentSocket.off('waitingRoom:updated', handleWaitingRoomUpdated);
        currentSocket.off('waitingRoom:deleted', handleWaitingRoomDeleted);
        currentSocket.off('appointment:updated', handleAppointmentUpdated);
      }
    };
  }, [doctorUserId]);

  const peekNextPatient = async (
    doctorUserId: number | string
  ): Promise<NextPatientData | null> => {
    setError(null);
    try {
      const res = await axiosInstance.get("/schedule/peek-next-patient", {
        params: { doctorUserId },
      });
      if (res.data?.success) {
        return res.data.data as NextPatientData | null;
      }
      return null;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message = axiosErr.response?.data?.error || "Erreur lors de la récupération du patient suivant";
      setError(message);
      return null;
    }
  };

  const callNextPatient = async (
    doctorUserId: number | string
  ): Promise<NextPatientData | null> => {
    setError(null);
    try {
      const res = await axiosInstance.post("/schedule/next-patient", {}, {
        params: { doctorUserId },
      });
      if (res.data?.success) {
        const data = res.data.data as NextPatientData | null;
        if (data) {
          setCurrentCall({
            patientId: data.patientId,
            patientName: data.patientName,
            type: data.type,
            consultationStartedAt: new Date().toISOString()
          });
          // Rafraîchir le schedule après avoir appelé le patient suivant
          getTodaySchedule(doctorUserId);
        }
        return data;
      }
      return null;
    } catch (err) {
      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message = axiosErr.response?.data?.error || "Erreur lors de l'appel du patient suivant";
      setError(message);
      toast.error(message, "Erreur");
      return null;
    }
  };

  const getCurrentCall = async (
    doctorUserId: number | string
  ): Promise<CurrentCallData | null> => {
    try {
      const res = await axiosInstance.get("/schedule/current-call", {
        params: { doctorUserId },
      });
      if (res.data?.success && res.data.data) {
        const data = res.data.data as CurrentCallData;
        setCurrentCall(data);
        return data;
      }
      setCurrentCall(null);
      return null;
    } catch (err) {
      return null;
    }
  };

  const value: WaitingRoomContextType = {
    entries,
    loading,
    error,
    fetchEntries,
    getEntry,
    createEntry,
    updateEntry,
    deleteEntry,
    getTodaySchedule,
    schedule,
    peekNextPatient,
    callNextPatient,
    getCurrentCall,
    currentCall,
  };

  return (
    <WaitingRoomContext.Provider value={value}>
      {children}
    </WaitingRoomContext.Provider>
  );
}

export function useWaitingRoom() {
  const ctx = useContext(WaitingRoomContext);
  if (ctx === undefined)
    throw new Error("useWaitingRoom must be used within a WaitingRoomProvider");
  return ctx;
}
