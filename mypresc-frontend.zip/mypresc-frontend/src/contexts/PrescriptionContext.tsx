"use client";

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useCallback,
} from "react";
import axios, { AxiosError } from "axios";
import { toast } from "@/components/ui/use-toast";
import { useAuth } from "./AuthContext";
import logger from "@/utils/logger";
import {
  fetchMyTypes,
  createType,
  updateType,
  deleteType,
  createTypeFromPrescription,
} from "@/features/prescriptions/api/prescriptionType.api";
import type { PrescriptionType, CreatePrescriptionTypePayload } from "@/features/prescriptions/types/prescription.types";

// --- Types aligned with backend ---
export interface Medication {
  id: number;
  nom_de_marque: string;
  denomination_commune_internationale: string;
  dosage: string;
  forme: string;
  created_at?: string | Date;
  updated_at?: string | Date;
}

export interface PrescriptionMedication {
  id?: number;
  medication_id: number;
  denomination_commune_internationale: string;
  nom_de_marque: string;
  quantity: number;
  dosage: string;
  note?: string;
  med_dosage?: string;
  is_custom?: boolean;
  custom_medication_id?: number;
}

export interface ApiPrescription {
  id: number;
  patient_id: number;
  doctor_user_id: number;
  confirmed_count?: number;
  remarks?: string;
  medication_ids: number[];
  created_at: string | Date;
  updated_at?: string | Date;
  // Extended details when fetched with full details
  patient?: {
    id: number;
    name: string;
    family_name: string;
    age: number;
    genre: "homme" | "femme";
    telephone: string;
    email?: string;
  };
  doctor?: {
    id: number;
    name: string;
    family_name: string;
    email: string;
  };
  medications?: PrescriptionMedication[];
}

export interface CreatePrescriptionData {
  patient_id: string;
  confirmed_count?: number;
  remarks?: string;
  medications: PrescriptionMedication[];
}

export interface PrescriptionFilters {
  patientId?: string;
  doctorId?: number;
  limit?: number;
  offset?: number;
}

export interface MedicationSearchFilters {
  searchTerm?: string;
  limit?: number;
  offset?: number;
}

interface PrescriptionContextType {
  prescriptions: ApiPrescription[];
  currentPrescription: ApiPrescription | null;
  medications: Medication[];
  currentMedication: Medication | null;
  loading: boolean;
  error: string | null;

  // Prescription CRUD operations
  createPrescription: (
    data: CreatePrescriptionData
  ) => Promise<ApiPrescription | null>;
  getPrescriptionById: (id: number) => Promise<ApiPrescription | null>;
  getPrescriptionsByPatient: (
    patientId: string,
    limit?: number,
    offset?: number
  ) => Promise<ApiPrescription[]>;
  getPrescriptionsByDoctor: (
    doctorId: number,
    limit?: number,
    offset?: number
  ) => Promise<ApiPrescription[]>;
  getAllPrescriptions: (
    limit?: number,
    offset?: number
  ) => Promise<ApiPrescription[]>;

  // Medication operations
  getMedicationById: (id: number) => Promise<Medication | null>;
  searchMedications: (
    searchTerm: string,
    limit?: number
  ) => Promise<Medication[]>;
  getAllMedications: (limit?: number, offset?: number) => Promise<Medication[]>;
  fetchMedications: (filters?: MedicationSearchFilters) => Promise<void>;

  // Utility functions
  fetchPrescriptions: (filters?: PrescriptionFilters) => Promise<void>;
  clearError: () => void;
  setCurrentPrescription: (prescription: ApiPrescription | null) => void;
  setCurrentMedication: (medication: Medication | null) => void;
  generatePrescriptionPdf: (id: number) => Promise<void>;
  exportPrescriptionData: (data?: { patients?: string[]; is_all?: boolean }) => Promise<void>;

  // Prescription Types (Models)
  prescriptionTypes: PrescriptionType[];
  prescriptionTypesLoading: boolean;
  fetchPrescriptionTypes: () => Promise<void>;
  createPrescriptionType: (data: CreatePrescriptionTypePayload) => Promise<PrescriptionType | null>;
  updatePrescriptionType: (id: number, data: Partial<CreatePrescriptionTypePayload>) => Promise<PrescriptionType | null>;
  deletePrescriptionType: (id: number) => Promise<boolean>;
  savePrescriptionAsType: (prescriptionId: number, name: string) => Promise<PrescriptionType | null>;
}

const PrescriptionContext = createContext<PrescriptionContextType | undefined>(
  undefined
);

// Axios instances
const PRESCRIPTION_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/prescription";
const MEDICATION_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/medication";

const prescriptionAxiosInstance = axios.create({
  baseURL: PRESCRIPTION_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

const medicationAxiosInstance = axios.create({
  baseURL: MEDICATION_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

export function PrescriptionProvider({ children }: { children: ReactNode }) {
  const [prescriptions, setPrescriptions] = useState<ApiPrescription[]>([]);
  const [currentPrescription, setCurrentPrescription] =
    useState<ApiPrescription | null>(null);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [currentMedication, setCurrentMedication] = useState<Medication | null>(
    null
  );
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  // Prescription Types State
  const [prescriptionTypes, setPrescriptionTypes] = useState<PrescriptionType[]>([]);
  const [prescriptionTypesLoading, setPrescriptionTypesLoading] = useState(false);

  // Clear error function
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Create prescription
  const createPrescription = useCallback(
    async (data: CreatePrescriptionData): Promise<ApiPrescription | null> => {
      setLoading(true);
      setError(null);

      // 🚀 OPEN POPUP IMMEDIATELY — browser allows this!
      const pdfWindow = window.open("", "_blank");

      if (!pdfWindow) {
        toast({
          title: "Popup bloqué",
          description:
            "Veuillez autoriser les popups pour pouvoir ouvrir l’ordonnance.",
          variant: "destructive",
        });
        setLoading(false);
        return null;
      }

      try {
        const response = await prescriptionAxiosInstance.post("/", data, {
          responseType: "blob",
        });

        const contentType = response.headers["content-type"];

        if (contentType === "application/pdf") {
          // Convert to Blob
          const blob = new Blob([response.data], { type: "application/pdf" });
          const url = URL.createObjectURL(blob);

          // Load PDF into the previously-opened window
          pdfWindow.location.href = url;

          toast({
            title: "Succès",
            description: "Ordonnance créée et affichée.",
          });

          return { id: 0 } as ApiPrescription; // success placeholder
        }

        // JSON fallback
        const jsonResponse = JSON.parse(await response.data.text());
        pdfWindow.close(); // No PDF → close popup

        return jsonResponse.data;
      } catch (err) {
        pdfWindow.close();
        const axiosErr = err as AxiosError<{ error?: string }>;
        const message =
          axiosErr.response?.data?.error ||
          axiosErr.message ||
          "Erreur lors de la création de l'ordonnance";

        setError(message);

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        });

        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );


  // Get prescription by ID
  const getPrescriptionById = useCallback(
    async (id: number): Promise<ApiPrescription | null> => {
      setLoading(true);
      setError(null);

      try {
        const response = await prescriptionAxiosInstance.get(`/${id}`);

        if (response.data?.success) {
          const prescription = response.data.data as ApiPrescription;
          setCurrentPrescription(prescription);
          return prescription;
        } else {
          const errorMsg = response.data?.error || "Ordonnance non trouvée";
          setError(errorMsg);
          return null;
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération de l'ordonnance";

        setError(message);
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Get prescriptions by patient
  const getPrescriptionsByPatient = useCallback(
    async (
      patientId: string,
      limit: number = 50,
      offset: number = 0
    ): Promise<ApiPrescription[]> => {
      setLoading(true);
      setError(null);
      // Clear previous prescriptions to avoid showing stale data from another patient
      setPrescriptions([]);

      try {
        const response = await prescriptionAxiosInstance.get(
          `/patient/${patientId}`,
          {
            params: { limit, offset },
          }
        );

        if (response.data?.success) {
          const fetchedPrescriptions = response.data.data as ApiPrescription[];
          setPrescriptions(fetchedPrescriptions);
          return fetchedPrescriptions;
        } else {
          const errorMsg =
            response.data?.error ||
            "Erreur lors de la récupération des ordonnances";
          setError(errorMsg);
          return [];
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération des ordonnances du patient";

        setError(message);
        return [];
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Get prescriptions by doctor
  const getPrescriptionsByDoctor = useCallback(
    async (
      doctorId: number,
      limit: number = 50,
      offset: number = 0
    ): Promise<ApiPrescription[]> => {
      setLoading(true);
      setError(null);

      try {
        const response = await prescriptionAxiosInstance.get(
          `/doctor/${doctorId}`,
          {
            params: { limit, offset },
          }
        );

        if (response.data?.success) {
          const prescriptions = response.data.data as ApiPrescription[];
          setPrescriptions(prescriptions);
          return prescriptions;
        } else {
          const errorMsg =
            response.data?.error ||
            "Erreur lors de la récupération des ordonnances";
          setError(errorMsg);
          return [];
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération des ordonnances du médecin";

        setError(message);
        return [];
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Get all prescriptions
  const getAllPrescriptions = useCallback(
    async (
      limit: number = 50,
      offset: number = 0
    ): Promise<ApiPrescription[]> => {
      setLoading(true);
      setError(null);

      try {
        const response = await prescriptionAxiosInstance.get("/", {
          params: { limit, offset },
        });

        if (response.data?.success) {
          const prescriptions = response.data.data as ApiPrescription[];
          setPrescriptions(prescriptions);
          return prescriptions;
        } else {
          const errorMsg =
            response.data?.error ||
            "Erreur lors de la récupération des ordonnances";
          setError(errorMsg);
          return [];
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération des ordonnances";

        setError(message);
        return [];
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Get medication by ID
  const getMedicationById = useCallback(
    async (id: number): Promise<Medication | null> => {
      setLoading(true);
      setError(null);

      try {
        const response = await medicationAxiosInstance.get(`/${id}`);

        if (response.data?.success) {
          const medication = response.data.data as Medication;
          setCurrentMedication(medication);
          return medication;
        } else {
          const errorMsg = response.data?.error || "Médicament non trouvé";
          setError(errorMsg);
          return null;
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération du médicament";

        setError(message);
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Search medications
  const searchMedications = useCallback(
    async (searchTerm: string, limit: number = 50): Promise<Medication[]> => {
      setLoading(true);
      setError(null);

      try {
        const response = await medicationAxiosInstance.get("/search", {
          params: { searchTerm, limit },
        });

        if (response.data?.success) {
          const medications = response.data.data as Medication[];
          setMedications(medications);
          return medications;
        } else {
          const errorMsg =
            response.data?.error ||
            "Erreur lors de la recherche de médicaments";
          setError(errorMsg);
          return [];
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la recherche de médicaments";

        setError(message);
        return [];
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Get all medications
  const getAllMedications = useCallback(
    async (limit: number = 50, offset: number = 0): Promise<Medication[]> => {
      setLoading(true);
      setError(null);

      try {
        const response = await medicationAxiosInstance.get("/", {
          params: { limit, offset },
        });

        if (response.data?.success) {
          const medications = response.data.data as Medication[];
          setMedications(medications);
          return medications;
        } else {
          const errorMsg =
            response.data?.error ||
            "Erreur lors de la récupération des médicaments";
          setError(errorMsg);
          return [];
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          "Erreur lors de la récupération des médicaments";

        setError(message);
        return [];
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Generic fetch function for medications
  const fetchMedications = useCallback(
    async (filters?: MedicationSearchFilters): Promise<void> => {
      if (filters?.searchTerm) {
        await searchMedications(filters.searchTerm, filters.limit);
      } else {
        await getAllMedications(filters?.limit, filters?.offset);
      }
    },
    [searchMedications, getAllMedications]
  );

  // Generic fetch function with filters
  const fetchPrescriptions = useCallback(
    async (filters?: PrescriptionFilters): Promise<void> => {
      if (filters?.patientId) {
        await getPrescriptionsByPatient(
          filters.patientId,
          filters.limit,
          filters.offset
        );
      } else if (filters?.doctorId) {
        await getPrescriptionsByDoctor(
          filters.doctorId,
          filters.limit,
          filters.offset
        );
      } else {
        await getAllPrescriptions(filters?.limit, filters?.offset);
      }
    },
    [getPrescriptionsByPatient, getPrescriptionsByDoctor, getAllPrescriptions]
  );

  // generate a pdf for prescripiton
  const generatePrescriptionPdf = useCallback(
    async (id: number): Promise<void> => {
      if (!id) return;
      setLoading(true);
      setError(null);
      try {
        const response = await prescriptionAxiosInstance.get(`/pdf/${id}`, {
          responseType: "blob", // Important: expect binary data (PDF)
        });

        if (response.status === 200) {
          // Check if response is PDF (Content-Type: application/pdf)
          const contentType = response.headers["content-type"];

          if (contentType === "application/pdf") {
            // Create blob URL and open PDF in new tab
            const blob = new Blob([response.data], { type: "application/pdf" });
            const url = window.URL.createObjectURL(blob);

            // Open in new window
            window.open(url, "_blank");

            // Clean up after a delay to ensure the window has loaded
            setTimeout(() => window.URL.revokeObjectURL(url), 100);

            toast({
              title: "Succès",
              description: "Ordonnance créée avec succès et PDF téléchargé",
            });

            // Since we can't get the prescription data from PDF response,
            // we'll need to refetch prescriptions to update the list
            // This will be handled by the calling component
          } else {
            // Handle JSON response (fallback)
            const jsonResponse = JSON.parse(await response.data.text());
            if (jsonResponse.success) {
              const newPrescription = jsonResponse.data as ApiPrescription;
              setPrescriptions((prev) => [newPrescription, ...prev]);

              toast({
                title: "Succès",
                description: "Ordonnance créée avec succès",
              });
            } else {
              throw new Error(
                jsonResponse.error ||
                "Erreur lors de la création de l'ordonnance"
              );
            }
          }
        } else {
          throw new Error("Erreur lors de la création de l'ordonnance");
        }
      } catch (err) {
        const axiosErr = err as AxiosError<{ error?: string } | undefined>;
        const message =
          axiosErr.response?.data?.error ||
          axiosErr.message ||
          "Erreur lors de la pdf generation de l'ordonnance";

        setError(message);
        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Export all prescriptions data as CSV
  const exportPrescriptionData = useCallback(async (data?: { patients?: string[]; is_all?: boolean }): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      logger.log("🔐 Export prescriptions attempt", data);

      const response = await prescriptionAxiosInstance.post("/export/data", data || {}, {
        responseType: "blob",
      });

      logger.log("✅ Export response received", response.status);

      if (response.status !== 200) throw new Error("Erreur lors de l'export");

      const contentType = response.headers["content-type"];
      if (!contentType || (!contentType.includes("text/csv") && !contentType.includes("application/csv"))) {
        throw new Error("Format de réponse invalide - CSV attendu");
      }

      // Convert blob to CSV and trigger download
      const blob = new Blob([response.data], { type: "text/csv;charset=utf-8;" });
      const url = window.URL.createObjectURL(blob);

      // Create temporary link to trigger download
      const link = document.createElement("a");
      link.href = url;

      // Generate filename with timestamp
      const timestamp = new Date().toISOString().split('T')[0];
      link.download = `prescriptions_export_${timestamp}.csv`;

      // Trigger download
      document.body.appendChild(link);
      link.click();

      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Succès",
        description: "Export des ordonnances réussi",
      });

    } catch (err) {
      console.error("❌ Export error:", err);

      const axiosErr = err as AxiosError<{ error?: string } | undefined>;
      const message =
        axiosErr.response?.data?.error ||
        axiosErr.message ||
        "Erreur lors de l'export des ordonnances";

      setError(message);

      toast({
        title: "Erreur",
        description: message,
        variant: "destructive",
      });

    } finally {
      setLoading(false);
    }
  }, []);


  // Fetch Prescription Types
  const fetchPrescriptionTypes = useCallback(async () => {
    setPrescriptionTypesLoading(true);
    try {
      const types = await fetchMyTypes(true); // withMedications=true
      setPrescriptionTypes(types);
    } catch (err) {
      console.error("Failed to fetch prescription types:", err);
      // We don't want to show a toast every time fetching fails silently on mount
    } finally {
      setPrescriptionTypesLoading(false);
    }
  }, []);

  const createPrescriptionType = useCallback(async (data: CreatePrescriptionTypePayload) => {
    setLoading(true);
    try {
      const result = await createType(data);
      setPrescriptionTypes(prev => [result, ...prev]);
      toast({ title: "Modèle créé", description: "Le modèle d'ordonnance a été enregistré." });
      return result;
    } catch (err: any) {
      toast({ title: "Erreur", description: err.response?.data?.error || "Erreur lors de la création", variant: "destructive" });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const updatePrescriptionType = useCallback(async (id: number, data: Partial<CreatePrescriptionTypePayload>) => {
    setLoading(true);
    try {
      const result = await updateType(id, data);
      setPrescriptionTypes(prev => prev.map(t => t.id === id ? result : t));
      toast({ title: "Modèle mis à jour", description: "Les modifications ont été enregistrées." });
      return result;
    } catch (err: any) {
      toast({ title: "Erreur", description: err.response?.data?.error || "Erreur lors de la mise à jour", variant: "destructive" });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const deletePrescriptionType = useCallback(async (id: number) => {
    setLoading(true);
    try {
      await deleteType(id);
      setPrescriptionTypes(prev => prev.filter(t => t.id !== id));
      toast({ title: "Modèle supprimé", description: "Le modèle a été supprimé." });
      return true;
    } catch (err: any) {
      toast({ title: "Erreur", description: err.response?.data?.error || "Erreur lors de la suppression", variant: "destructive" });
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  const savePrescriptionAsType = useCallback(async (prescriptionId: number, name: string) => {
    setLoading(true);
    try {
      const result = await createTypeFromPrescription(prescriptionId, name);
      setPrescriptionTypes(prev => [result, ...prev]);
      toast({ title: "Modèle enregistré", description: "Cette ordonnance a été enregistrée comme modèle." });
      return result;
    } catch (err: any) {
      toast({ title: "Erreur", description: err.response?.data?.error || "Erreur lors de l'enregistrement", variant: "destructive" });
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Auto-fetch prescriptions and types for current doctor on mount
  useEffect(() => {
    if (user?.id) {
      const doctorId = parseInt(user.id);
      if (!isNaN(doctorId)) {
        getPrescriptionsByDoctor(doctorId);
        fetchPrescriptionTypes();
      }
    }
  }, [user?.id, getPrescriptionsByDoctor, fetchPrescriptionTypes]);

  const value: PrescriptionContextType = {
    prescriptions,
    currentPrescription,
    medications,
    currentMedication,
    loading,
    error,
    createPrescription,
    getPrescriptionById,
    getPrescriptionsByPatient,
    getPrescriptionsByDoctor,
    getAllPrescriptions,
    getMedicationById,
    searchMedications,
    getAllMedications,
    fetchMedications,
    fetchPrescriptions,
    clearError,
    setCurrentPrescription,
    setCurrentMedication,
    generatePrescriptionPdf,
    exportPrescriptionData,
    prescriptionTypes,
    prescriptionTypesLoading,
    fetchPrescriptionTypes,
    createPrescriptionType,
    updatePrescriptionType,
    deletePrescriptionType,
    savePrescriptionAsType,
  };

  return (
    <PrescriptionContext.Provider value={value}>
      {children}
    </PrescriptionContext.Provider>
  );
}

// Custom hook to use the context
export function usePrescription() {
  const context = useContext(PrescriptionContext);
  if (context === undefined) {
    throw new Error(
      "usePrescription must be used within a PrescriptionProvider"
    );
  }
  return context;
}
