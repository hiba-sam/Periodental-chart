'use client';

import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';
import logger from '@/utils/logger';


// Axios instances
const PROFILE_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/user";
const TARIFICATION_API_BASE_URL = (process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:3333") + "/tarification";

const axiosInstance = axios.create({
  baseURL: PROFILE_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

const tarificationAxiosInstance = axios.create({
  baseURL: TARIFICATION_API_BASE_URL,
  withCredentials: true,
  headers: { "Content-Type": "application/json" },
});

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

/**
 * Base User fields from the backend
 */
interface User {
  id: number;
  name: string;
  family_name: string;
  email: string;
  role: 'doctor' | 'user' | 'admin' | 'assistant';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

/**
 * Doctor-specific fields (merged with User when role === 'doctor')
 */
interface WorkTime {
  [day: string]: string; // e.g., "Monday": "09:00 - 17:00", "Saturday": "Closed"
}

interface Doctor {
  user_id: number;
  birth_date?: string;
  birth_place?: string;
  work_location?: string;
  home_location?: string;
  diploma_file?: string;
  certificates?: string[] | null;
  order_num?: string;
  order_num_file?: string | null;
  id_card_file?: string | null;
  phone_number?: string;
  work_time?: WorkTime;
  languages?: string[];
  about?: string | null;
  speciality?: string;
  experience?: number;
  plan?: string;
  end_date?: string;
  is_plan_expired?: boolean;
  statistics?: {
    patientsFollowed: number;
    consultationsThisMonth: number;
  };
}

/**
 * Assistant-specific fields (merged with User when role === 'assistant')
 */
interface Assistant {
  assistant_id?: number;
  phone_number?: string;
  work_location?: string;
  work_time?: WorkTime;
  doctor_email?: string;
  doctor_family_name?: string;
  doctor_name?: string;
  doctor_phone_number?: string;
}

/**
 * Combined profile type (User + optional Doctor/Assistant fields)
 */
export type Profile = User & Partial<Doctor> & Partial<Assistant>;

/**
 * Data structure for updating profile
 * Accepts both user fields and doctor fields
 */
export interface UpdateProfileData {
  // User fields
  name?: string;
  family_name?: string;
  password?: string;
  currentPassword?: string;
  is_active?: boolean;

  // Doctor fields (only used if user.role === 'doctor')
  birth_date?: string;
  birth_place?: string;
  work_location?: string;
  home_location?: string;
  diploma_file?: string;
  certificates?: string[] | null;
  order_num?: string;
  order_num_file?: string | null;
  id_card_file?: string | null;
  phone_number?: string;
  work_time?: WorkTime;
  languages?: string[];
  about?: string | null;
  speciality?: string;
  experience?: number;
}

/**
 * Backend API response structure
 */
interface ProfileApiResponse {
  success: boolean;
  data: Profile;
  message?: string;
  error?: string;
}

/**
 * Tarification interface
 */
export interface Tarification {
  id: number;
  doctor_user_id: number;
  service_label: string;
  price: number;
  created_at: string;
  updated_at: string;
}

/**
 * Create tarification data structure
 */
export interface CreateTarificationData {
  service_label: string;
  price: number;
}

/**
 * Update tarification data structure
 */
export interface UpdateTarificationData {
  service_label?: string;
  price?: number;
}

/**
 * Tarification API response structure
 */
interface TarificationApiResponse {
  success: boolean;
  data?: Tarification | Tarification[];
  message?: string;
  error?: string;
}

/**
 * Context state interface
 */
interface ProfileContextState {
  profile: Profile | null;
  loading: boolean;
  error: string | null;
  fetchProfile: () => Promise<void>;
  updateProfile: (data: UpdateProfileData) => Promise<boolean>;
  clearError: () => void;
  isDoctor: boolean;
  isAdmin: boolean;
  isAssistant: boolean;

  // Tarification methods
  tarifications: Tarification[];
  tarificationsLoading: boolean;
  tarificationsError: string | null;
  getTarificationsByDoctor: () => Promise<void>;
  getTarificationById: (id: number) => Promise<Tarification | null>;
  createTarification: (data: CreateTarificationData) => Promise<Tarification | null>;
  updateTarification: (id: number, data: UpdateTarificationData) => Promise<Tarification | null>;
  deleteTarification: (id: number) => Promise<boolean>;
  clearTarificationsError: () => void;
}

// ============================================================================
// CONTEXT CREATION
// ============================================================================

const ProfileContext = createContext<ProfileContextState | undefined>(undefined);

// ============================================================================
// PROVIDER COMPONENT
// ============================================================================

interface ProfileProviderProps {
  children: ReactNode;
  autoFetch?: boolean; // Whether to auto-fetch profile on mount
}


export const ProfileProvider: React.FC<ProfileProviderProps> = ({
  children,
  autoFetch = true
}) => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  logger.log("ProfileContext: profile state changed:", profile);

  const { user } = useAuth();

  // Tarification state
  const [tarifications, setTarifications] = useState<Tarification[]>([]);
  const [tarificationsLoading, setTarificationsLoading] = useState<boolean>(false);
  const [tarificationsError, setTarificationsError] = useState<string | null>(null);

  const { isAuthenticated } = useAuth();

  /**
   * Fetches the current user's profile from the backend
   * Calls GET /api/profile (getMe controller)
   */
  const fetchProfile = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axiosInstance.get<ProfileApiResponse>('');

      if (response.data.success && response.data.data) {
        setProfile(response.data.data);
      } else {
        throw new Error(response.data.error || 'Failed to fetch profile');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while fetching profile';

      setError(errorMessage);
      console.error('ProfileContext: fetchProfile error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Updates the current user's profile
   * Calls PUT /api/profile (updateMe controller)
   * Automatically refreshes profile data after successful update
   *
   * @param data - Partial profile data to update (user fields and/or doctor fields)
   * @returns Promise<boolean> - true if update succeeded, false otherwise
   */
  const updateProfile = useCallback(async (data: UpdateProfileData): Promise<boolean> => {
    setLoading(true);
    setError(null);

    try {
      logger.log("ProfileContext: updateProfile called with data:", data);
      const response = await axiosInstance.put<ProfileApiResponse>('', data);

      if (response.data.success && response.data.data) {
        // Update local state with the returned data
        setProfile(response.data.data);
        return true;
      } else {
        throw new Error(response.data.error || 'Failed to update profile');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while updating profile';

      setError(errorMessage);
      console.error('ProfileContext: updateProfile error:', err);
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  /**
   * Clears the current error state
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Clears the tarifications error state
   */
  const clearTarificationsError = useCallback(() => {
    setTarificationsError(null);
  }, []);

  // ============================================================================
  // TARIFICATION METHODS
  // ============================================================================

  /**
   * Fetches tarifications for the current doctor
   * Calls GET /tarification/doctor
   * Automatically initializes with default services if no tarifications exist
   */
  const getTarificationsByDoctor = useCallback(async () => {
    setTarificationsLoading(true);
    setTarificationsError(null);

    try {
      const response = await tarificationAxiosInstance.get<TarificationApiResponse>('/doctor');

      if (response.data.success && Array.isArray(response.data.data)) {
        setTarifications(response.data.data);
      } else {
        throw new Error(response.data.error || 'Failed to fetch tarifications');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while fetching tarifications';

      setTarificationsError(errorMessage);
      console.error('ProfileContext: getTarificationsByDoctor error:', err);
    } finally {
      setTarificationsLoading(false);
    }
  }, []);

  /**
   * Fetches a single tarification by ID
   * Calls GET /tarification/:id
   *
   * @param id - The tarification ID
   * @returns Promise<Tarification | null> - The tarification if found, null otherwise
   */
  const getTarificationById = useCallback(async (id: number): Promise<Tarification | null> => {
    setTarificationsLoading(true);
    setTarificationsError(null);

    try {
      const response = await tarificationAxiosInstance.get<TarificationApiResponse>(`/${id}`);

      if (response.data.success && response.data.data && !Array.isArray(response.data.data)) {
        return response.data.data;
      } else {
        throw new Error(response.data.error || 'Failed to fetch tarification');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while fetching tarification';

      setTarificationsError(errorMessage);
      console.error('ProfileContext: getTarificationById error:', err);
      return null;
    } finally {
      setTarificationsLoading(false);
    }
  }, []);

  /**
   * Creates a new tarification
   * Calls POST /tarification
   * Automatically refreshes tarifications list after successful creation
   *
   * @param data - The tarification data (service_label and price)
   * @returns Promise<Tarification | null> - The created tarification if successful, null otherwise
   */
  const createTarification = useCallback(async (data: CreateTarificationData): Promise<Tarification | null> => {
    setTarificationsLoading(true);
    setTarificationsError(null);

    try {
      const response = await tarificationAxiosInstance.post<TarificationApiResponse>('', data);

      if (response.data.success && response.data.data && !Array.isArray(response.data.data)) {
        // Refresh tarifications list
        await getTarificationsByDoctor();
        return response.data.data;
      } else {
        throw new Error(response.data.error || 'Failed to create tarification');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while creating tarification';

      setTarificationsError(errorMessage);
      console.error('ProfileContext: createTarification error:', err);
      return null;
    } finally {
      setTarificationsLoading(false);
    }
  }, [getTarificationsByDoctor]);

  /**
   * Updates an existing tarification
   * Calls PUT /tarification/:id
   * Automatically refreshes tarifications list after successful update
   *
   * @param id - The tarification ID
   * @param data - The partial tarification data to update
   * @returns Promise<Tarification | null> - The updated tarification if successful, null otherwise
   */
  const updateTarification = useCallback(async (id: number, data: UpdateTarificationData): Promise<Tarification | null> => {
    setTarificationsLoading(true);
    setTarificationsError(null);

    try {
      const response = await tarificationAxiosInstance.put<TarificationApiResponse>(`/${id}`, data);

      if (response.data.success && response.data.data && !Array.isArray(response.data.data)) {
        // Refresh tarifications list
        await getTarificationsByDoctor();
        return response.data.data;
      } else {
        throw new Error(response.data.error || 'Failed to update tarification');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while updating tarification';

      setTarificationsError(errorMessage);
      console.error('ProfileContext: updateTarification error:', err);
      return null;
    } finally {
      setTarificationsLoading(false);
    }
  }, [getTarificationsByDoctor]);

  /**
   * Deletes a tarification
   * Calls DELETE /tarification/:id
   * Automatically refreshes tarifications list after successful deletion
   *
   * @param id - The tarification ID
   * @returns Promise<boolean> - true if deletion succeeded, false otherwise
   */
  const deleteTarification = useCallback(async (id: number): Promise<boolean> => {
    setTarificationsLoading(true);
    setTarificationsError(null);

    try {
      const response = await tarificationAxiosInstance.delete<TarificationApiResponse>(`/${id}`);

      if (response.data.success) {
        // Refresh tarifications list
        await getTarificationsByDoctor();
        return true;
      } else {
        throw new Error(response.data.error || 'Failed to delete tarification');
      }
    } catch (err: any) {
      const errorMessage =
        err.response?.data?.error ||
        err.message ||
        'An error occurred while deleting tarification';

      setTarificationsError(errorMessage);
      console.error('ProfileContext: deleteTarification error:', err);
      return false;
    } finally {
      setTarificationsLoading(false);
    }
  }, [getTarificationsByDoctor]);

  /**
   * Auto-fetch profile on mount if autoFetch is enabled
   */
  useEffect(() => {
    if (autoFetch && isAuthenticated) {
      fetchProfile();
    }
  }, [autoFetch, fetchProfile, isAuthenticated]);

  // Computed values
  const isDoctor = profile?.role === 'doctor';
  const isAdmin = profile?.role === 'admin';
  const isAssistant = profile?.role === 'assistant';

  const value: ProfileContextState = {
    profile,
    loading,
    error,
    fetchProfile,
    updateProfile,
    clearError,
    isDoctor,
    isAdmin,
    isAssistant,

    // Tarification state and methods
    tarifications,
    tarificationsLoading,
    tarificationsError,
    getTarificationsByDoctor,
    getTarificationById,
    createTarification,
    updateTarification,
    deleteTarification,
    clearTarificationsError,
  };

  return (
    <ProfileContext.Provider value={value}>
      {children}
    </ProfileContext.Provider>
  );
};


export const useProfile = (): ProfileContextState => {
  const context = useContext(ProfileContext);

  if (context === undefined) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }

  return context;
};

// ============================================================================
// EXPORT TYPES FOR EXTERNAL USE
// ============================================================================

export type { User, Doctor, ProfileApiResponse };
