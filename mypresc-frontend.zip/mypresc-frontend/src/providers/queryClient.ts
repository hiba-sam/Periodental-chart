import { QueryClient } from '@tanstack/react-query';

/**
 * Shared QueryClient instance for manual cache operations
 * Use this when you need to invalidate queries outside of React components
 */
export const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            staleTime: 5 * 60 * 1000,
            retry: 2,
            refetchOnWindowFocus: false,
        },
    },
});
