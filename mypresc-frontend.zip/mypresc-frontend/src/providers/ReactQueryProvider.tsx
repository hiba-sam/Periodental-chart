'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactNode, useState } from 'react';

/**
 * React Query Provider for the application
 * Wraps components that need access to React Query hooks
 */
export function ReactQueryProvider({ children }: { children: ReactNode }) {
    const [queryClient] = useState(
        () =>
            new QueryClient({
                defaultOptions: {
                    queries: {
                        // Default stale time of 5 minutes
                        staleTime: 5 * 60 * 1000,
                        // Retry failed requests 2 times
                        retry: 2,
                        // Refetch on window focus
                        refetchOnWindowFocus: false,
                    },
                    mutations: {
                        // Retry mutations once
                        retry: 1,
                    },
                },
            })
    );

    return (
        <QueryClientProvider client={queryClient}>
            {children}
        </QueryClientProvider>
    );
}
