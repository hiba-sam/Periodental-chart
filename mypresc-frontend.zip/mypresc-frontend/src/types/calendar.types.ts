/**
 * Calendar Type Definitions
 *
 * Centralized type definitions for the calendar system.
 * These types are used across calendar components and context.
 */

// ============================================================================
// CALENDAR VIEW TYPES
// ============================================================================

/**
 * Available calendar view modes
 */
export type CalendarView = 'day' | 'week' | 'month';

// ============================================================================
// EVENT TYPES
// ============================================================================

/**
 * Main calendar event interface
 * Represents a scheduled appointment in the calendar
 */
export interface CalendarEvent {
  id: string;
  date: Date;
  time: string; // Format: HH:mm
  duration: number; // Duration in minutes
  title: string; // Patient full name
  description?: string; // Appointment notes
  color: string; // Hex color code (e.g., #2563eb)

  // Patient information
  patientId: string;
  patientName: string;
  patientFamilyName: string;
  patientPhone?: string;
  patientAge?: number;

  // Status flags
  confirmedComing: boolean;
  isDone: boolean;

  // Computed fields
  endTime?: string; // Format: HH:mm (calculated from time + duration)
}

/**
 * Data required to create a new calendar event
 */
export interface CreateEventData {
  patientId: string;
  date: Date;
  time: string; // Format: HH:mm
  duration?: number; // Default: 30 minutes
  notes?: string;
  color?: string; // Default: #2563eb
  confirmedComing?: boolean; // Default: false
}

/**
 * Data for updating an existing calendar event
 * All fields except 'id' are optional
 */
export interface UpdateEventData extends Partial<CreateEventData> {
  id: string;
  isDone?: boolean;
}

// ============================================================================
// TIME SLOT TYPES
// ============================================================================

/**
 * Represents a time slot in the calendar grid
 */
export interface TimeSlot {
  hour: number;
  minute: number;
  label: string; // Format: HH:mm
}

/**
 * Represents a day column in the weekly view
 */
export interface DayColumn {
  date: Date;
  dayName: string;
  dayNumber: number;
  isToday: boolean;
  isPast: boolean;
  events: CalendarEvent[];
}

// ============================================================================
// COLOR TYPES
// ============================================================================

/**
 * Color variant with transparency for event blocks
 */
export interface ColorVariant {
  bg: string; // Background color with transparency
  border: string; // Border color (solid)
  text: string; // Text color (solid)
}

/**
 * Available color options for events
 */
export const EVENT_COLORS = {
  BLUE: '#2563eb',
  GREEN: '#10b981',
  RED: '#ef4444',
  ORANGE: '#f59e0b',
  PURPLE: '#8b5cf6',
  GRAY: '#6b7280',
} as const;

// ============================================================================
// MODAL STATE TYPES
// ============================================================================

/**
 * Modal modes for event creation/editing
 */
export type EventModalMode = 'create' | 'edit';

/**
 * State for controlling event modal
 */
export interface EventModalState {
  isOpen: boolean;
  mode: EventModalMode;
  event?: CalendarEvent | null;
  initialDate?: Date;
  initialTime?: string;
}

// ============================================================================
// FILTER & QUERY TYPES
// ============================================================================

/**
 * Options for filtering calendar events
 */
export interface EventFilter {
  startDate?: Date;
  endDate?: Date;
  patientId?: string;
  isDone?: boolean;
  confirmedComing?: boolean;
}

/**
 * Date range for querying events
 */
export interface DateRange {
  start: Date;
  end: Date;
}

// ============================================================================
// APPOINTMENT API TYPES (Backend Integration)
// ============================================================================

/**
 * Appointment data as received from the API
 */
export interface ApiAppointment {
  id: string;
  patient_id: string;
  doctor_user_id: number;
  date: string | Date;
  time: string;
  duration: number;
  notes?: string | null;
  color: string;
  confirmed_coming: boolean;
  is_done: boolean;
  created_at?: string | Date;
  updated_at?: string | Date;
  patient_name?: string;
  patient_family_name?: string;
}

/**
 * Payload for creating a new appointment via API
 */
export interface CreateAppointmentPayload {
  patient_id: string;
  date: string; // ISO format: yyyy-mm-dd
  time: string; // Format: HH:mm
  duration?: number;
  notes?: string;
  color?: string;
  confirmed_coming?: boolean;
  is_done?: boolean;
}

/**
 * Payload for updating an existing appointment via API
 */
export interface UpdateAppointmentPayload extends Partial<CreateAppointmentPayload> {}

// ============================================================================
// CALENDAR CONTEXT TYPES
// ============================================================================

/**
 * Calendar context state and actions
 */
export interface CalendarContextValue {
  // State
  events: CalendarEvent[];
  selectedDate: Date;
  selectedEvent: CalendarEvent | null;
  calendarView: CalendarView;
  loading: boolean;
  error: string | null;

  // Date Navigation Actions
  setSelectedDate: (date: Date) => void;
  goToToday: () => void;
  goPrevious: () => void;
  goNext: () => void;

  // View Management Actions
  setCalendarView: (view: CalendarView) => void;

  // Event Selection Actions
  selectEvent: (event: CalendarEvent | null) => void;

  // CRUD Actions
  createEvent: (data: CreateEventData) => Promise<CalendarEvent | null>;
  updateEvent: (data: UpdateEventData) => Promise<CalendarEvent | null>;
  deleteEvent: (eventId: string) => Promise<boolean>;

  // Query Functions
  getEventsForDate: (date: Date) => CalendarEvent[];
  getEventsForWeek: (weekStart: Date) => CalendarEvent[];
  getEventsForMonth: (month: Date) => CalendarEvent[];
  getEventAtDateTime: (date: Date, time: string) => CalendarEvent | null;
}

// ============================================================================
// COMPONENT PROP TYPES
// ============================================================================

/**
 * Props for CalendarGrid component
 */
export interface CalendarGridProps {
  onSlotClick?: (date: Date, time: string) => void;
  onEventClick?: (event: CalendarEvent) => void;
}

/**
 * Props for EventDetailsPanel component
 */
export interface EventDetailsPanelProps {
  event: CalendarEvent;
  onEdit: (event: CalendarEvent) => void;
  onDelete: (event: CalendarEvent) => void;
}

/**
 * Props for EventModal component
 */
export interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDate?: Date;
  initialTime?: string;
  editEvent?: CalendarEvent | null;
}

/**
 * Props for DeleteConfirmModal component
 */
export interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  event: CalendarEvent | null;
  isDeleting?: boolean;
}

// ============================================================================
// UTILITY TYPES
// ============================================================================

/**
 * Duration options for appointments
 */
export interface DurationOption {
  value: number; // Duration in minutes
  label: string; // Display label
}

/**
 * Time option for time selector
 */
export interface TimeOption {
  value: string; // Time in HH:mm format
  label: string; // Display label
}

/**
 * Week day information
 */
export interface WeekDay {
  index: number; // 0 (Monday) to 6 (Sunday)
  name: string; // Full name (e.g., "Lundi")
  shortName: string; // Short name (e.g., "Lun")
}
