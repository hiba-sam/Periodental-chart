---
name: 🐛 Rapport de bug
about: Signaler un bug ou un comportement inattendu
title: "[Bug] - "
labels: bug
assignees: ''

---

## 🔎 Description du bug
Explique le problème rencontré de manière claire et concise.

## 🪜 Étapes pour reproduire le bug
1. Aller sur la page [...]
2. Cliquer sur [...]
3. Observer que [...]

## 🤖 Comportement attendu
Décris ce qui aurait dû se passer normalement.

## 📷 Capture d'écran ou vidéo (si utile)
Ajoute une image ou une vidéo pour illustrer le bug.

## 💻 Environnement
- Système d'exploitation : [Windows / macOS / Android / ...]
- Navigateur ou appareil utilisé : [Chrome / Firefox / Safari / APK / ...]
- Version du projet (si connu) : v1.0, etc.

## 📎 Fichiers joints (facultatif)
Ajoute un fichier si nécessaire pour reproduire le bug (ex : .PDF généré, .log, etc.)

## ❗ Priorité estimée
- [ ] Urgent (bloque le projet)
- [ ] Moyenne (peut attendre un peu)
- [ ] Faible (pas bloquant)
