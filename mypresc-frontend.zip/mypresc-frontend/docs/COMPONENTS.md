# Component API Documentation

## Overview

This document describes the reusable component APIs in the MyPresc frontend.

---

## Skeleton Components

**Location:** `@/components/feedback`

### CardSkeleton

Generic card loading placeholder.

```typescript
interface CardSkeletonProps {
  className?: string;
}

<CardSkeleton className="custom-class" />
```

### ListSkeleton

List loading placeholder with configurable items.

```typescript
interface ListSkeletonProps {
  count?: number;      // Default: 3
  className?: string;
}

<ListSkeleton count={5} />
```

### TableSkeleton

Table loading placeholder with configurable rows.

```typescript
interface TableSkeletonProps {
  rows?: number;       // Default: 3
  className?: string;
}

<TableSkeleton rows={4} />
```

---

## Patient Modals

**Location:** `@/features/patients/components`

### PatientHistoryModal

Shows doctor interaction history. Fetches data internally on open.

```typescript
interface PatientHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
  patientName: string;
  currentUserId?: number;
}

<PatientHistoryModal
  isOpen={showHistory}
  onClose={() => setShowHistory(false)}
  patientId="123"
  patientName="John Doe"
  currentUserId={1}
/>
```

### AccessConfirmationModal

Confirms access to patient data with checkbox agreement.

```typescript
interface AccessConfirmationModalProps {
  isOpen: boolean;
  patientName: string;
  onConfirm: () => void;
  onDeny: () => void;
}
```

### PrivacyChoiceModal

Allows doctor to choose privacy level for patient data.

```typescript
interface PrivacyChoiceModalProps {
  isOpen: boolean;
  patientName: string;
  onChoice: (choice: 'public' | 'private') => void;
}
```

---

## Invoice Components

**Location:** `@/features/invoices`

### PaymentModal

Modal for adding payment to an invoice.

```typescript
interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice;
  onPaymentAdded: () => void;
}
```

### GlobalPaymentModal

Modal for distributing payment across multiple invoices.

```typescript
interface GlobalPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
  totalUnpaid: number;
  onPaymentDistributed: () => void;
}
```

### InvoiceCreateModal

Modal for creating new invoices with tarification selection.

```typescript
interface InvoiceCreateModalProps {
  isOpen: boolean;
  tarifications: Tarification[];
  onClose: () => void;
  onCreate: (tarificationIds: number[], customItems: CustomItem[]) => Promise<void>;
}
```

---

## Prescription Components

**Location:** `@/features/prescriptions/components`

### PrescriptionPreviewModal

Displays prescription details with print option.

```typescript
interface PrescriptionPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  prescription: Prescription | null;
  patientName?: string;
  patientFamilyName?: string;
}
```

---

## Sharing Components

**Location:** `@/features/sharing/components`

### ShareMedicalRecordModal

Multi-step modal for sharing medical records with other doctors.

```typescript
interface ShareMedicalRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
  patientName: string;
}
```

---

## Usage Examples

### Loading States with Skeletons

```tsx
import { CardSkeleton, ListSkeleton } from '@/components/feedback';

function PatientPage() {
  const { data, isLoading } = usePatientDetail({ patientId });
  
  if (isLoading) {
    return (
      <div className="space-y-6">
        <CardSkeleton />
        <div className="grid grid-cols-2 gap-6">
          <ListSkeleton count={3} />
          <ListSkeleton count={3} />
        </div>
      </div>
    );
  }
  
  return <PatientContent data={data} />;
}
```

### Modal Pattern

```tsx
import { PatientHistoryModal } from '@/features/patients/components';

function PatientActions() {
  const [showHistory, setShowHistory] = useState(false);
  
  return (
    <>
      <button onClick={() => setShowHistory(true)}>
        View History
      </button>
      
      <PatientHistoryModal
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        patientId={patientId}
        patientName={patientName}
      />
    </>
  );
}
```
