# Project Architecture Documentation

## Overview

This document describes the feature-based architecture implemented in the MyPresc frontend application. The codebase has been refactored from a monolithic structure to a modular, domain-driven design for better maintainability and scalability.

---

## Folder Structure

```
src/
├── app/                          # Next.js App Router pages
│   ├── patients/
│   │   ├── [id]/
│   │   │   ├── _components/      # Page-specific components
│   │   │   │   ├── PatientProfile.tsx
│   │   │   │   ├── PrescriptionsSection.tsx
│   │   │   │   ├── MedicalReportsSection.tsx
│   │   │   │   ├── AppointmentsSection.tsx
│   │   │   │   ├── InvoicesSection.tsx
│   │   │   │   └── index.ts
│   │   │   └── page.tsx
│   │   └── page.tsx
│   └── ...
│
├── features/                     # Feature modules (domain-driven)
│   ├── patients/
│   │   ├── api/                  # API functions
│   │   ├── components/           # Reusable components
│   │   │   └── modals/           # Modal components
│   │   ├── hooks/                # Custom hooks
│   │   ├── types/                # TypeScript types
│   │   ├── utils/                # Utility functions
│   │   └── index.ts              # Barrel export
│   │
│   ├── invoices/
│   ├── prescriptions/
│   ├── medical-reports/
│   ├── dental/
│   └── sharing/
│
├── components/                   # Shared UI components
│   ├── feedback/
│   │   └── Skeleton/             # Loading skeletons
│   └── ...
│
├── contexts/                     # React Context providers
└── utils/                        # Global utilities
```

---

## Feature Module Structure

Each feature module follows a consistent pattern:

```
feature-name/
├── api/                  # API layer
│   ├── feature.api.ts    # Axios instance & API functions
│   └── index.ts          # Barrel export
├── components/           # UI components
│   ├── modals/           # Modal components (if any)
│   └── index.ts          # Barrel export
├── hooks/                # Custom React hooks
│   └── index.ts          # Barrel export
├── types/                # TypeScript definitions
│   └── index.ts          # Barrel export
└── index.ts              # Main barrel export
```

---

## Import Conventions

### From Feature Modules (Preferred)
```typescript
import { useInvoices, PaymentModal } from '@/features/invoices';
import { PatientHistoryModal } from '@/features/patients';
```

### From Shared Components
```typescript
import { CardSkeleton, ListSkeleton } from '@/components/feedback';
```

---

## Key Principles

1. **Feature Isolation**: Each feature is self-contained
2. **Barrel Exports**: Use `index.ts` files for clean imports
3. **Colocation**: Keep related code together
4. **Type Safety**: All components are fully typed

---

## File Naming

| Type | Convention | Example |
|------|------------|---------|
| Components | PascalCase | `PatientProfile.tsx` |
| Hooks | camelCase with `use` prefix | `usePatientDetail.ts` |
| Types | kebab-case with `.types` suffix | `invoice.types.ts` |
| API | kebab-case with `.api` suffix | `invoice.api.ts` |
