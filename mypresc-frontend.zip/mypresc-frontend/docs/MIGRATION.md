# Migration Notes

## Overview

This document describes the migration from the monolithic codebase to the feature-based architecture.

---

## What Changed

### Before (Monolithic)
```
src/
├── components/
│   ├── patients/
│   │   ├── PatientHistoryModal.tsx
│   │   ├── ShareMedicalRecordModal.tsx
│   │   └── detail/modals/...
│   ├── prescriptions/
│   └── invoices/
└── app/patients/[id]/page.tsx  (1500+ lines)
```

### After (Feature-Based)
```
src/
├── features/
│   ├── patients/
│   ├── invoices/
│   ├── prescriptions/
│   └── sharing/
├── components/feedback/        (shared skeletons)
└── app/patients/[id]/
    ├── _components/            (page-specific)
    └── page.tsx                (~400 lines)
```

---

## Breaking Changes

### Import Path Updates

| Old Path | New Path |
|----------|----------|
| `@/components/patients/PatientHistoryModal` | `@/features/patients/components` |
| `@/components/patients/ShareMedicalRecordModal` | `@/features/sharing/components` |
| `@/components/prescriptions/PrescriptionPreviewModal` | `@/features/prescriptions/components` |
| `@/components/patients/detail/modals/InvoiceCreateModal` | `@/features/invoices` |
| `@/shared` (skeletons) | `@/components/feedback` |

### Component API Changes

#### PatientHistoryModal

**Before:**
```typescript
<PatientHistoryModal
  isOpen={showModal}
  onClose={handleClose}
  history={historyData}           // ❌ Removed
  metadata={historyMetadata}      // ❌ Removed
  patientName={name}
  currentUserId={userId}
/>
```

**After:**
```typescript
<PatientHistoryModal
  isOpen={showModal}
  onClose={handleClose}
  patientId={patientId}           // ✅ New - fetches internally
  patientName={name}
  currentUserId={userId}
/>
```

---

## Migration Checklist

### Phase 1: Feature Modules ✅
- [x] Create features directory structure
- [x] Move patient-related code to features/patients
- [x] Move invoice-related code to features/invoices
- [x] Move prescription-related code to features/prescriptions
- [x] Create sharing feature module

### Phase 2: Hooks Refactoring ✅
- [x] Create usePatientDetail hook
- [x] Refactor useInvoices to use centralized API
- [x] Refactor useInvoiceMutations
- [x] Add skeleton loading states

### Phase 3: Component Migration ✅
- [x] Move modals to feature modules
- [x] Update modal APIs (PatientHistoryModal)
- [x] Create shared skeleton components
- [x] Delete old component files

### Phase 4: Documentation ✅
- [x] Document folder structure
- [x] Document hooks usage
- [x] Document component APIs
- [x] Create migration notes

---

## Files Removed

```
src/components/patients/PatientHistoryModal.tsx
src/components/patients/ShareMedicalRecordModal.tsx
src/components/patients/detail/modals/InvoiceCreateModal.tsx
src/components/patients/detail/modals/AccessConfirmationModal.tsx
src/components/patients/detail/modals/NinPopupModal.tsx
src/components/patients/detail/modals/PrivacyChoiceModal.tsx
src/components/patients/detail/modals/GlobalPaymentModal.tsx
src/shared/ (entire directory)
```

---

## Performance Improvements

1. **Code Splitting**: Components lazy-loaded with `next/dynamic`
2. **Skeleton Loading**: Immediate visual feedback during data fetch
3. **React Query Caching**: Reduced API calls via intelligent caching
4. **Bundle Optimization**: Feature-based chunking for smaller initial load
