import pool from '../db.js';
import { PatientModel } from './patient.model.js';

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface CardiologyReport {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    medical_report_id?: number | null;

    // Section 1: Patient info
    patient_age?: number | null;
    patient_sex?: string | null;
    patient_weight?: number | null;
    patient_height?: number | null;
    patient_bmi?: number | null;

    // Section 2: Clinical exam
    heart_rate?: number | null;
    systolic_bp?: number | null;
    diastolic_bp?: number | null;
    spo2?: number | null;
    auscultation?: string | null;
    lower_limb_edema?: string | null;
    nyha_class?: number | null;
    chest_pain?: string | null;
    heart_failure_signs?: string[] | null;

    // Section 3: History
    has_hta?: boolean;
    has_diabetes?: boolean;
    has_diabetes_insulin?: boolean;
    has_afib?: boolean;
    has_mi?: boolean;
    has_stroke?: boolean;
    has_heart_failure?: boolean;
    has_arteriopathy?: boolean;
    has_valvulopathy?: boolean;
    has_active_smoking?: boolean;
    has_stopped_smoking?: boolean;
    has_dyslipidemia?: boolean;
    has_endocarditis?: boolean;
    has_prior_cardiac_surgery?: boolean;
    has_chronic_lung_disease?: boolean;
    has_reduced_mobility?: boolean;
    has_hepatic_anomaly?: boolean;
    has_bleeding_history?: boolean;
    has_nsaid_antiplatelet?: boolean;
    has_excessive_alcohol?: boolean;
    known_lvef?: number | null;
    creatinine?: number | null;

    // Section 4: Exams
    ecg_result?: string | null;
    ecg_detail?: string | null;
    ecg_st_deviation?: boolean;
    echo_lvef?: number | null;
    echo_lvedd?: number | null;
    echo_la_size?: number | null;
    echo_valvulopathies?: string[] | null;
    echo_pulmonary_htn?: number | null;
    echo_lvesd?: number | null;
    echo_ivs_thickness?: number | null;
    echo_pw_thickness?: number | null;
    echo_tapse?: number | null;
    echo_wall_motion?: string | null;
    echo_wall_motion_detail?: string | null;
    echo_diastolic_function?: string | null;
    echo_pericardial_effusion?: string | null;
    echo_valvulopathy_severity?: Record<string, string> | null;
    bio_bnp?: number | null;
    bio_troponin?: number | null;
    bio_ldl?: number | null;
    bio_hdl?: number | null;
    bio_total_cholesterol?: number | null;
    bio_triglycerides?: number | null;
    bio_hba1c?: number | null;
    bio_creatinine?: number | null;
    bio_inr?: number | null;

    // Section 5: Pre-op
    preop_critical_state?: boolean;
    preop_urgency?: string | null;
    preop_surgery_type?: string | null;
    preop_thoracic_aorta?: boolean;
    preop_dialysis?: boolean;

    // Section 6
    free_notes?: string | null;

    // Scores
    score_cha2ds2_vasc?: number | null;
    score_has_bled?: number | null;
    score_grace?: number | null;
    score_framingham?: number | null;
    score_score2?: number | null;
    score_nyha?: number | null;
    score_euroscore2?: number | null;

    // Report
    generated_report?: string | null;

    // Audit
    created_at: Date;
    updated_at: Date;

    // Joined fields
    doctor_name?: string;
    doctor_family_name?: string;
}

export interface CreateCardiologyReportData {
    patient_id: string;
    doctor_user_id: number;
    medical_report_id?: number;
    [key: string]: any;
}

export interface UpdateCardiologyReportData {
    [key: string]: any;
}

// All mutable columns (excluding id, patient_id, doctor_user_id, timestamps)
const MUTABLE_COLUMNS = [
    'medical_report_id',
    'patient_age', 'patient_sex', 'patient_weight', 'patient_height', 'patient_bmi',
    'heart_rate', 'systolic_bp', 'diastolic_bp', 'spo2', 'auscultation', 'lower_limb_edema',
    'nyha_class', 'chest_pain', 'heart_failure_signs',
    'has_hta', 'has_diabetes', 'has_diabetes_insulin', 'has_afib', 'has_mi',
    'has_stroke', 'has_heart_failure', 'has_arteriopathy', 'has_valvulopathy',
    'has_active_smoking', 'has_stopped_smoking', 'has_dyslipidemia', 'has_endocarditis',
    'has_prior_cardiac_surgery', 'has_chronic_lung_disease', 'has_reduced_mobility',
    'has_hepatic_anomaly', 'has_bleeding_history', 'has_nsaid_antiplatelet', 'has_excessive_alcohol',
    'known_lvef', 'creatinine',
    'ecg_result', 'ecg_detail', 'ecg_st_deviation',
    'echo_lvef', 'echo_lvedd', 'echo_la_size', 'echo_valvulopathies', 'echo_pulmonary_htn',
    'echo_lvesd', 'echo_ivs_thickness', 'echo_pw_thickness', 'echo_tapse',
    'echo_wall_motion', 'echo_wall_motion_detail', 'echo_diastolic_function',
    'echo_pericardial_effusion', 'echo_valvulopathy_severity',
    'bio_bnp', 'bio_troponin', 'bio_ldl', 'bio_hdl', 'bio_total_cholesterol',
    'bio_triglycerides', 'bio_hba1c', 'bio_creatinine', 'bio_inr',
    'preop_critical_state', 'preop_urgency', 'preop_surgery_type', 'preop_thoracic_aorta', 'preop_dialysis',
    'free_notes',
    'score_cha2ds2_vasc', 'score_has_bled', 'score_grace', 'score_framingham',
    'score_score2', 'score_nyha', 'score_euroscore2',
    'generated_report'
];

// ============================================
// MODEL
// ============================================

export class CardiologyReportModel {
    /**
     * Create a new cardiology report
     */
    static async create(data: CreateCardiologyReportData): Promise<CardiologyReport> {
        const columns = ['patient_id', 'doctor_user_id'];
        const placeholders = ['$1', '$2'];
        const values: any[] = [data.patient_id, data.doctor_user_id];
        let paramIdx = 3;

        for (const col of MUTABLE_COLUMNS) {
            if (data[col] !== undefined) {
                columns.push(col);
                placeholders.push(`$${paramIdx}`);
                values.push(data[col]);
                paramIdx++;
            }
        }

        const query = `
            INSERT INTO cardiology_reports (${columns.join(', ')})
            VALUES (${placeholders.join(', ')})
            RETURNING *
        `;

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    /**
     * Find by ID
     */
    static async findById(id: number): Promise<CardiologyReport | null> {
        const query = `
            SELECT cr.*, 
                   u.name as doctor_name, 
                   u.family_name as doctor_family_name
            FROM cardiology_reports cr
            LEFT JOIN users u ON cr.doctor_user_id = u.id
            WHERE cr.id = $1
        `;
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Find all reports for a patient
     */
    static async findByPatient(patientId: string): Promise<CardiologyReport[]> {
        const query = `
            SELECT cr.*, 
                   u.name as doctor_name, 
                   u.family_name as doctor_family_name
            FROM cardiology_reports cr
            LEFT JOIN users u ON cr.doctor_user_id = u.id
            WHERE cr.patient_id = $1
            ORDER BY cr.created_at DESC
        `;
        const result = await pool.query(query, [patientId]);
        return result.rows;
    }

    /**
     * Update a cardiology report
     */
    static async update(id: number, data: UpdateCardiologyReportData): Promise<CardiologyReport | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let paramIdx = 1;

        for (const col of MUTABLE_COLUMNS) {
            if (data[col] !== undefined) {
                fields.push(`${col} = $${paramIdx}`);
                values.push(data[col]);
                paramIdx++;
            }
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `
            UPDATE cardiology_reports
            SET ${fields.join(', ')}
            WHERE id = $${paramIdx}
            RETURNING *
        `;

        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;

        return await this.findById(id);
    }

    /**
     * Delete a cardiology report
     */
    static async delete(id: number): Promise<boolean> {
        const result = await pool.query('DELETE FROM cardiology_reports WHERE id = $1', [id]);
        return (result.rowCount ?? 0) > 0;
    }

    /**
     * Check access (only creator can modify)
     */
    static async checkAccess(id: number, userId: number): Promise<boolean> {
        const result = await pool.query(
            'SELECT 1 FROM cardiology_reports WHERE id = $1 AND doctor_user_id = $2',
            [id, userId]
        );
        return result.rows.length > 0;
    }

    /**
     * Find by ID with patient and doctor details (for PDF generation)
     */
    static async findByIdWithPatient(id: number, requestingDoctorId?: number): Promise<(CardiologyReport & { patient?: any }) | null> {
        const query = `
            SELECT cr.*, 
                   u.name as doctor_name, 
                   u.family_name as doctor_family_name,
                   u.email as doctor_email
            FROM cardiology_reports cr
            LEFT JOIN users u ON cr.doctor_user_id = u.id
            WHERE cr.id = $1
        `;
        const result = await pool.query(query, [id]);
        if (result.rows.length === 0) return null;

        const row = result.rows[0];
        const patient = await PatientModel.findById(row.patient_id, requestingDoctorId);

        return { ...row, patient };
    }
}
