import pool from '../db';


export interface CalendarEvent {
    id: string;
    doctor_user_id: number;
    appointment_id: string | null;
    patient_id?: string | null;
    title: string;
    note: string | null;
    date: Date;
    time: string;
    duration: number;
    color: string;
    created_at: Date;
    updated_at: Date;
    confirmed_coming: boolean;
    venue_confirmed: boolean;
    is_done: boolean;

    // Appointment details (populated when appointment_id is not null)
    appointment?: {
        appointment_notes: string | null;
        patient_name: string;
        patient_family_name: string;
    } | null;
}

export interface CreateCalendarEventData {
    doctor_user_id: number;
    appointment_id?: string | null; // If provided, creates an appointment-linked event
    title?: string; // Required for standalone events, auto-set for appointment-linked events
    note?: string | null; // Optional for standalone events, always NULL for appointment-linked events
    date?: Date; // Required for standalone events, auto-set from appointment if appointment_id provided
    time?: string; // Required for standalone events, auto-set from appointment if appointment_id provided
    duration?: number; // Default 30 if not provided
    color?: string; // Default '#2563eb' if not provided
}

export interface UpdateCalendarEventData {
    doctor_user_id?: number;
    appointment_id?: string | null;
    title?: string;
    note?: string | null;
    date?: Date;
    time?: string;
    duration?: number;
    color?: string;
}

export class CalendarModel {
    private static readonly ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

    private static mapRow(row: any): CalendarEvent {
        const event: CalendarEvent = {
            id: row.id,
            doctor_user_id: row.doctor_user_id,
            appointment_id: row.appointment_id,
            confirmed_coming: row.confirmed_coming ?? false,
            venue_confirmed: row.venue_confirmed ?? false,
            is_done: row.is_done ?? false,
            patient_id: row.patient_id ?? null,
            title: row.title,
            note: row.note,
            date: row.date,
            time: row.time,
            duration: row.duration,
            color: row.color || '#2563eb',
            created_at: row.created_at,
            updated_at: row.updated_at
        };

        // Add appointment details if linked to an appointment and data exists
        if (row.appointment_id && row.patient_id) {
            event.appointment = {
                appointment_notes: row.appointment_notes,
                patient_name: row.patient_name,
                patient_family_name: row.patient_family_name
            };
        } else {
            event.appointment = null;
        }

        return event;
    }

    // Create a new calendar event
    static async create(data: CreateCalendarEventData): Promise<CalendarEvent> {
        // If appointment_id is provided, the trigger will auto-set title, date, time, etc.
        // If it's a standalone event, we need title, date, and time
        if (!data.appointment_id && (!data.title || !data.date || !data.time)) {
            throw new Error('For standalone events, title, date, and time are required');
        }

        const insertQuery = `
            INSERT INTO calendar (
                doctor_user_id,
                appointment_id,
                title,
                note,
                date,
                time,
                duration,
                color
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        `;

        const insertValues = [
            data.doctor_user_id,
            data.appointment_id ?? null,
            data.title ?? 'Untitled Event', // Will be overridden by trigger if appointment_id is set
            data.note ?? null,
            data.date ?? new Date(), // Will be overridden by trigger if appointment_id is set
            data.time ?? '00:00', // Will be overridden by trigger if appointment_id is set
            data.duration ?? 30,
            data.color ?? '#2563eb'
        ];

        const inserted = await pool.query(insertQuery, insertValues);
        const newId = inserted.rows[0].id as string;
        return await this.findById(newId) as CalendarEvent;
    }

    // Find by ID (optionally scoped to a doctor for security)
    static async findById(id: string, doctorUserId?: number): Promise<CalendarEvent | null> {
        let query: string;
        let params: any[];

        if (doctorUserId !== undefined) {
            query = `
                SELECT
                    c.*,
                    a.patient_id,
                    a.notes AS appointment_notes,
                    a.is_done,
                    a.confirmed_coming,
                    a.venue_confirmed,
                    pgp_sym_decrypt(p.name, $3) AS patient_name,
                    pgp_sym_decrypt(p.family_name, $3) AS patient_family_name
                FROM calendar c
                LEFT JOIN appointments a ON a.id = c.appointment_id
                LEFT JOIN patients p ON p.id = a.patient_id
                WHERE c.id = $1 AND c.doctor_user_id = $2
            `;
            params = [id, doctorUserId, this.ENCRYPTION_KEY];
        } else {
            query = `
                SELECT
                    c.*,
                    a.patient_id,
                    a.notes AS appointment_notes,
                    a.is_done,
                    a.confirmed_coming,
                    a.venue_confirmed,
                    pgp_sym_decrypt(p.name, $2) AS patient_name,
                    pgp_sym_decrypt(p.family_name, $2) AS patient_family_name
                FROM calendar c
                LEFT JOIN appointments a ON a.id = c.appointment_id
                LEFT JOIN patients p ON p.id = a.patient_id
                WHERE c.id = $1
            `;
            params = [id, this.ENCRYPTION_KEY];
        }

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    // Update calendar event
    static async update(id: string, data: UpdateCalendarEventData): Promise<CalendarEvent | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.doctor_user_id !== undefined) {
            fields.push(`doctor_user_id = $${idx++}`);
            values.push(data.doctor_user_id);
        }
        if (data.appointment_id !== undefined) {
            fields.push(`appointment_id = $${idx++}`);
            values.push(data.appointment_id);
        }
        if (data.title !== undefined) {
            fields.push(`title = $${idx++}`);
            values.push(data.title);
        }
        if (data.note !== undefined) {
            fields.push(`note = $${idx++}`);
            values.push(data.note);
        }
        if (data.date !== undefined) {
            fields.push(`date = $${idx++}`);
            values.push(data.date);
        }
        if (data.time !== undefined) {
            fields.push(`time = $${idx++}`);
            values.push(data.time);
        }
        if (data.duration !== undefined) {
            fields.push(`duration = $${idx++}`);
            values.push(data.duration);
        }
        if (data.color !== undefined) {
            fields.push(`color = $${idx++}`);
            values.push(data.color);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE calendar SET ${fields.join(', ')} WHERE id = $${idx} RETURNING id`;
        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;
        return await this.findById(id);
    }

    // Delete calendar event
    static async delete(id: string): Promise<boolean> {
        const query = 'DELETE FROM calendar WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // List all calendar events for a specific doctor
    static async findAll(doctorUserId: number, limit: number = 100, offset: number = 0): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $4) AS patient_name,
                pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.doctor_user_id = $1
            ORDER BY c.date DESC, c.time DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    // Find events by date for a specific doctor
    static async findByDate(date: Date, doctorUserId: number, limit: number = 100, offset: number = 0): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $5) AS patient_name,
                pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.date = $1 AND c.doctor_user_id = $2
            ORDER BY c.time ASC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [date, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    // Find events by date range for a specific doctor
    static async findByDateRange(
        startDate: Date,
        endDate: Date,
        doctorUserId: number,
        limit: number = 500,
        offset: number = 0
    ): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $6) AS patient_name,
                pgp_sym_decrypt(p.family_name, $6) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.date >= $1 AND c.date <= $2 AND c.doctor_user_id = $3
            ORDER BY c.date ASC, c.time ASC
            LIMIT $4 OFFSET $5
        `;
        const result = await pool.query(query, [startDate, endDate, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    // Find appointment-linked events for a specific doctor
    static async findAppointmentLinkedEvents(doctorUserId: number, limit: number = 100, offset: number = 0): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $4) AS patient_name,
                pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.doctor_user_id = $1 AND c.appointment_id IS NOT NULL
            ORDER BY c.date DESC, c.time DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    // Find standalone events (not linked to appointments) for a specific doctor
    static async findStandaloneEvents(doctorUserId: number, limit: number = 100, offset: number = 0): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $4) AS patient_name,
                pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.doctor_user_id = $1 AND c.appointment_id IS NULL
            ORDER BY c.date DESC, c.time DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    // Find event by appointment ID (optionally scoped to a doctor for security)
    static async findByAppointmentId(appointmentId: string, doctorUserId?: number): Promise<CalendarEvent | null> {
        let query: string;
        let params: any[];

        if (doctorUserId !== undefined) {
            query = `
                SELECT
                    c.*,
                    a.patient_id,
                    a.notes AS appointment_notes,
                    a.is_done,
                    a.confirmed_coming,
                    a.venue_confirmed,
                    pgp_sym_decrypt(p.name, $3) AS patient_name,
                    pgp_sym_decrypt(p.family_name, $3) AS patient_family_name
                FROM calendar c
                LEFT JOIN appointments a ON a.id = c.appointment_id
                LEFT JOIN patients p ON p.id = a.patient_id
                WHERE c.appointment_id = $1 AND c.doctor_user_id = $2
                LIMIT 1
            `;
            params = [appointmentId, doctorUserId, this.ENCRYPTION_KEY];
        } else {
            query = `
                SELECT
                    c.*,
                    a.patient_id,
                    a.notes AS appointment_notes,
                    a.is_done,
                    a.confirmed_coming,
                    a.venue_confirmed,
                    pgp_sym_decrypt(p.name, $2) AS patient_name,
                    pgp_sym_decrypt(p.family_name, $2) AS patient_family_name
                FROM calendar c
                LEFT JOIN appointments a ON a.id = c.appointment_id
                LEFT JOIN patients p ON p.id = a.patient_id
                WHERE c.appointment_id = $1
                LIMIT 1
            `;
            params = [appointmentId, this.ENCRYPTION_KEY];
        }

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    // Check if there is any calendar event overlapping with a time range
    static async existsInRange(doctorUserId: number, date: Date, startTime: string, endTime: string): Promise<boolean> {
        const query = `
            SELECT 1
            FROM calendar
            WHERE doctor_user_id = $1 AND date = $2
              AND (
                time < $4::time AND (time + make_interval(mins => duration)) > $3::time
              )
            LIMIT 1
        `;
        const result = await pool.query(query, [doctorUserId, date, startTime, endTime]);
        return result.rows.length > 0;
    }

    static async findInRange(doctorUserId: number, date: Date, startTime: string, endTime: string): Promise<CalendarEvent[]> {
        const query = `
            SELECT
                c.*,
                a.patient_id,
                a.notes AS appointment_notes,
                a.is_done,
                a.confirmed_coming,
                a.venue_confirmed,
                pgp_sym_decrypt(p.name, $5) AS patient_name,
                pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM calendar c
            LEFT JOIN appointments a ON a.id = c.appointment_id
            LEFT JOIN patients p ON p.id = a.patient_id
            WHERE c.doctor_user_id = $1 AND c.date = $2
              AND (
                c.time < $4::time AND (c.time + make_interval(mins => c.duration)) > $3::time
              )
            ORDER BY c.time ASC
        `;
        const result = await pool.query(query, [doctorUserId, date, startTime, endTime, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }
}
