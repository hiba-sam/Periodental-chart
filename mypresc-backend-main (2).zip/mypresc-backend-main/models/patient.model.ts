import pool from '../db';
import crypto from 'crypto';

export interface Patient {
    id: string;
    name: string;
    family_name: string;
    age?: number;
    genre: 'homme' | 'femme';
    telephone?: string;
    email?: string | null;
    adresse?: string | null;
    dateNaissance?: Date | string | null;
    numeroSecuriteSociale?: string | null;
    medecinTraitant?: number | null; // Now references users.id
    allergies?: string | null;
    consultations: number;
    chronicDiseases?: string | null;
    notes?: string | null;
    nin?: string | null;
    emergencyContact?: string | null;
    emergencyPhone?: string | null;
    is_private?: boolean;
    assistant_id?: number | null;
    is_chart_readed?: boolean;
    shared_with_primary_care?: boolean;
    created_by_doctor_id?: number | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreatePatientData {
    name: string;
    family_name: string;
    age: number;
    genre: 'homme' | 'femme';
    telephone: string;
    nin: string; // Now REQUIRED
    email?: string;
    adresse?: string;
    dateNaissance?: Date | string;
    numeroSecuriteSociale?: string;
    medecinTraitant?: number; // Now references users.id
    allergies?: string;
    chronicDiseases?: string;
    notes?: string;
    emergencyContact?: string;
    emergencyPhone?: string;
    is_private?: boolean;
    assistant_id?: number | null;
    is_chart_readed?: boolean;
    shared_with_primary_care?: boolean;
    created_by_doctor_id?: number | null;
}

export interface UpdatePatientData {
    name?: string;
    family_name?: string;
    age?: number;
    genre?: 'homme' | 'femme';
    telephone?: string;
    email?: string | null;
    adresse?: string | null;
    dateNaissance?: Date | string | null;
    numeroSecuriteSociale?: string | null;
    medecinTraitant?: number | null; // Now references users.id
    allergies?: string | null;
    chronicDiseases?: string | null;
    notes?: string | null;
    nin?: string | null;
    emergencyContact?: string | null;
    emergencyPhone?: string | null;
    is_private?: boolean | null;
    assistant_id?: number | null;
    is_chart_readed?: boolean;
    shared_with_primary_care?: boolean | null;
}

export class PatientModel {
    private static get ENCRYPTION_KEY() {
        return process.env.ENCRYPTION_KEY;
    }

    // Helper method to encrypt data
    private static async encrypt(data: string): Promise<Buffer> {
        const result = await pool.query('SELECT pgp_sym_encrypt($1, $2) as encrypted', [data, this.ENCRYPTION_KEY]);
        return result.rows[0].encrypted;
    }

    // Helper method to decrypt data
    private static async decrypt(encryptedData: Buffer): Promise<string> {
        const result = await pool.query('SELECT pgp_sym_decrypt($1, $2) as decrypted', [encryptedData, this.ENCRYPTION_KEY]);
        return result.rows[0].decrypted;
    }

    /**
     * Generate a blind index for a string value
     * Uses SHA256 hash to create a searchable index without revealing the original value
     *
     * @param value - The plaintext value to generate a blind index for
     * @returns SHA256 hash of the lowercase value (hex string)
     *
     * Example:
     *   generateBlindIndex("John") => "a8cfde6331bd59eb2ac96f8911c4b666"
     *   generateBlindIndex("john") => "a8cfde6331bd59eb2ac96f8911c4b666" (same hash)
     */
    private static generateBlindIndex(value: string): string {
        // Normalize to lowercase for case-insensitive searching
        const normalized = value.toLowerCase().trim();
        // Generate SHA256 hash
        return crypto.createHash('sha256').update(normalized).digest('hex');
    }

    /**
     * Generate a combined blind index for full name search
     * Combines name and family_name for "name family_name" searches
     *
     * @param name - Patient's last name
     * @param familyName - Patient's first name
     * @returns SHA256 hash of "name family_name" (lowercase, normalized)
     *
     * Example:
     *   generateFullNameBlindIndex("Doe", "John") => SHA256("doe john")
     */
    private static generateFullNameBlindIndex(name: string, familyName: string): string {
        // Combine name and family_name with a space, normalize
        const fullName = `${name.toLowerCase().trim()} ${familyName.toLowerCase().trim()}`;
        return crypto.createHash('sha256').update(fullName).digest('hex');
    }

    // Create a new patient
    static async create(data: CreatePatientData): Promise<Patient> {
        // Generate blind indexes for ALL searchable encrypted fields
        const nameBlindIndex = this.generateBlindIndex(data.name);
        const familyNameBlindIndex = this.generateBlindIndex(data.family_name);
        const fullNameBlindIndex = this.generateFullNameBlindIndex(data.name, data.family_name);
        const ninBlindIndex = this.generateBlindIndex(data.nin);

        const query = `
            INSERT INTO patients (
                name, family_name, age, genre, telephone, email, adresse,
                date_naissance, numero_securite_sociale, nin,
                emergencyContact, emergencyPhone,
                allergies, chronicDiseases, notes,
                name_blind_index, family_name_blind_index, full_name_blind_index, nin_blind_index,
                medecin_traitant_id, is_private, assistant_id, is_chart_readed, created_by_doctor_id
            ) VALUES (
                pgp_sym_encrypt($1, $25),   -- name (encrypted)
                pgp_sym_encrypt($2, $25),   -- family_name (encrypted)
                pgp_sym_encrypt($3::text, $25), -- age (encrypted)
                pgp_sym_encrypt($4, $25),   -- genre (encrypted)
                pgp_sym_encrypt($5, $25),   -- telephone (encrypted)
                pgp_sym_encrypt($6, $25),   -- email (encrypted)
                pgp_sym_encrypt($7, $25),   -- adresse (encrypted)
                pgp_sym_encrypt($8, $25),   -- date_naissance (encrypted)
                pgp_sym_encrypt($9, $25),   -- numero_securite_sociale (encrypted)
                pgp_sym_encrypt($10, $25),  -- nin (encrypted)
                pgp_sym_encrypt($11, $25),  -- emergencyContact (encrypted)
                pgp_sym_encrypt($12, $25),  -- emergencyPhone (encrypted)
                pgp_sym_encrypt($13, $25),  -- allergies (encrypted)
                pgp_sym_encrypt($14, $25),  -- chronicDiseases (encrypted)
                pgp_sym_encrypt($15, $25),  -- notes (encrypted)
                $16,                        -- name_blind_index
                $17,                        -- family_name_blind_index
                $18,                        -- full_name_blind_index
                $19,                        -- nin_blind_index
                $20,                        -- medecin_traitant_id
                $21,                        -- is_private
                $22,                        -- assistant_id
                $23,                        -- is_chart_readed
                $24                         -- created_by_doctor_id
            )
            RETURNING id, name, family_name, age, genre, telephone, email, adresse,
                      date_naissance, numero_securite_sociale, nin,
                      emergencyContact, emergencyPhone,
                      allergies, chronicDiseases, notes,
                      medecin_traitant_id, consultations, is_private, assistant_id, is_chart_readed,
                      created_by_doctor_id, created_at, updated_at
        `;

        const values = [
            data.name,
            data.family_name,
            data.age !== null && data.age !== undefined ? data.age.toString() : null,
            data.genre,
            data.telephone || null,
            data.email || null,
            data.adresse || null,
            data.dateNaissance || null,
            data.numeroSecuriteSociale || null,
            data.nin,
            data.emergencyContact || null,
            data.emergencyPhone || null,
            data.allergies || null,
            data.chronicDiseases || null,
            data.notes || null,
            nameBlindIndex,
            familyNameBlindIndex,
            fullNameBlindIndex,
            ninBlindIndex,
            data.medecinTraitant || null,
            data.is_private || false,
            data.assistant_id || null,         // $22
            data.is_chart_readed || false,     // $23
            data.created_by_doctor_id || null, // $24
            this.ENCRYPTION_KEY                // $25
        ];

        const result = await pool.query(query, values);
        const row = result.rows[0];

        // Decrypt ALL encrypted fields for response
        const [
            name, family_name, age, genre, telephone, email, adresse,
            dateNaissance, numeroSecuriteSociale, nin,
            emergencyContact, emergencyPhone,
            allergies, chronicDiseases, notes
        ] = await Promise.all([
            this.decrypt(row.name),
            this.decrypt(row.family_name),
            row.age ? this.decrypt(row.age) : null,
            this.decrypt(row.genre),
            row.telephone ? this.decrypt(row.telephone) : null,
            row.email ? this.decrypt(row.email) : null,
            row.adresse ? this.decrypt(row.adresse) : null,
            row.date_naissance ? this.decrypt(row.date_naissance) : null,
            row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
            row.nin ? this.decrypt(row.nin) : null,
            row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
            row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
            row.allergies ? this.decrypt(row.allergies) : null,
            row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
            row.notes ? this.decrypt(row.notes) : null
        ]);

        return {
            id: row.id,
            name,
            family_name,
            age: age ? parseInt(age) : undefined,
            genre: genre as 'homme' | 'femme',
            telephone: telephone ?? undefined,
            email: email ?? undefined,
            adresse: adresse ?? undefined,
            dateNaissance: dateNaissance ? new Date(dateNaissance) : null,
            numeroSecuriteSociale: numeroSecuriteSociale ?? undefined,
            nin: nin ?? undefined,
            emergencyContact: emergencyContact ?? undefined,
            emergencyPhone: emergencyPhone ?? undefined,
            medecinTraitant: row.medecin_traitant_id,
            allergies: allergies ?? undefined,
            consultations: row.consultations,
            chronicDiseases: chronicDiseases ?? undefined,
            notes: notes ?? undefined,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    /**
     * Find patient by ID.
     * ⚡ OPTIMIZED (Task 1.5): merges medical_shares check AND assigned-doctor info
     * into the main SELECT via subquery + LEFT JOIN — reducing 3 queries → 1 query.
     */
    static async findById(id: string, requestingDoctorId?: number): Promise<Patient | any | null> {
        const query = `
            SELECT
                p.id,
                pgp_sym_decrypt(p.name, $3) as name,
                pgp_sym_decrypt(p.family_name, $3) as family_name,
                CASE WHEN p.age IS NOT NULL THEN pgp_sym_decrypt(p.age, $3) ELSE NULL END as age,
                pgp_sym_decrypt(p.genre, $3) as genre,
                CASE WHEN p.telephone IS NOT NULL THEN pgp_sym_decrypt(p.telephone, $3) ELSE NULL END as telephone,
                CASE WHEN p.email IS NOT NULL THEN pgp_sym_decrypt(p.email, $3) ELSE NULL END as email,
                CASE WHEN p.adresse IS NOT NULL THEN pgp_sym_decrypt(p.adresse, $3) ELSE NULL END as adresse,
                CASE WHEN p.date_naissance IS NOT NULL THEN pgp_sym_decrypt(p.date_naissance, $3) ELSE NULL END as date_naissance,
                CASE WHEN p.numero_securite_sociale IS NOT NULL THEN pgp_sym_decrypt(p.numero_securite_sociale, $3) ELSE NULL END as numero_securite_sociale,
                CASE WHEN p.nin IS NOT NULL THEN pgp_sym_decrypt(p.nin, $3) ELSE NULL END as nin,
                CASE WHEN p.emergencyContact IS NOT NULL THEN pgp_sym_decrypt(p.emergencyContact, $3) ELSE NULL END as emergencyContact,
                CASE WHEN p.emergencyPhone IS NOT NULL THEN pgp_sym_decrypt(p.emergencyPhone, $3) ELSE NULL END as emergencyPhone,
                CASE WHEN p.allergies IS NOT NULL THEN pgp_sym_decrypt(p.allergies, $3) ELSE NULL END as allergies,
                CASE WHEN p.chronicDiseases IS NOT NULL THEN pgp_sym_decrypt(p.chronicDiseases, $3) ELSE NULL END as chronicDiseases,
                CASE WHEN p.notes IS NOT NULL THEN pgp_sym_decrypt(p.notes, $3) ELSE NULL END as notes,
                p.medecin_traitant_id,
                p.consultations,
                p.is_private,
                p.assistant_id,
                p.is_chart_readed,
                p.created_by_doctor_id,
                p.created_at,
                p.updated_at,
                -- ⚡ share check embedded (no second query)
                CASE
                    WHEN $2::int IS NULL THEN false
                    ELSE EXISTS (
                        SELECT 1 FROM medical_shares ms
                        WHERE ms.patient_id = p.id
                          AND ms.shared_with_doctor_id = $2
                          AND ms.status = 'active'
                          AND ms.expires_at > NOW()
                    )
                END AS is_shared_with_me,
                -- ⚡ assigned doctor info embedded via LEFT JOIN (no third query)
                u_assigned.name  AS assigned_doctor_name,
                u_assigned.family_name AS assigned_doctor_family_name,
                d_assigned.phone_number AS assigned_doctor_phone
            FROM patients p
            LEFT JOIN users u_assigned   ON p.medecin_traitant_id = u_assigned.id
            LEFT JOIN doctors d_assigned ON u_assigned.id = d_assigned.user_id
            WHERE p.id = $1
        `;

        const result = await pool.query(query, [id, requestingDoctorId ?? null, this.ENCRYPTION_KEY]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];

        const patient: Patient & {
            is_shared_with_me?: boolean;
            assigned_doctor_name?: string;
            assigned_doctor_family_name?: string;
            assigned_doctor_phone?: string;
            created_by_doctor_id?: number | null;
        } = {
            id: row.id,
            name: row.name,
            family_name: row.family_name,
            age: row.age ? parseInt(row.age) : undefined,
            genre: row.genre as 'homme' | 'femme',
            telephone: row.telephone,
            email: row.email,
            adresse: row.adresse,
            dateNaissance: row.date_naissance ? new Date(row.date_naissance) : null,
            numeroSecuriteSociale: row.numero_securite_sociale,
            nin: row.nin,
            emergencyContact: row.emergencycontact,
            emergencyPhone: row.emergencyphone,
            medecinTraitant: row.medecin_traitant_id,
            allergies: row.allergies,
            consultations: row.consultations,
            chronicDiseases: row.chronicdiseases,
            notes: row.notes,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            is_shared_with_me: row.is_shared_with_me ?? false,
            created_by_doctor_id: row.created_by_doctor_id,
            created_at: row.created_at,
            updated_at: row.updated_at,
            // Assigned doctor columns from LEFT JOIN
            assigned_doctor_name: row.assigned_doctor_name ?? undefined,
            assigned_doctor_family_name: row.assigned_doctor_family_name ?? undefined,
            assigned_doctor_phone: row.assigned_doctor_phone ?? undefined,
        };

        // Apply sync privacy filter (zero additional DB calls)
        if (requestingDoctorId !== undefined) {
            return this.applyPrivacyFilterSync(patient, requestingDoctorId);
        }

        return patient;
    }

    // Update patient
    static async update(id: string, data: UpdatePatientData): Promise<Patient | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        // If either name or family_name is being updated, we need to regenerate full_name_blind_index
        // First, fetch the current patient to get the other name field if only one is being updated
        let shouldUpdateFullNameIndex = false;
        let currentPatient: Patient | null = null;

        if (data.name !== undefined || data.family_name !== undefined) {
            shouldUpdateFullNameIndex = true;
            currentPatient = await this.findById(id);
        }

        // Update name with encryption AND blind index
        if (data.name !== undefined) {
            const nameBlindIndex = this.generateBlindIndex(data.name);
            fields.push(`name = pgp_sym_encrypt($${idx++}, $${idx++})`);
            fields.push(`name_blind_index = $${idx++}`);
            values.push(data.name, this.ENCRYPTION_KEY, nameBlindIndex);
        }
        // Update family_name with encryption AND blind index
        if (data.family_name !== undefined) {
            const familyNameBlindIndex = this.generateBlindIndex(data.family_name);
            fields.push(`family_name = pgp_sym_encrypt($${idx++}, $${idx++})`);
            fields.push(`family_name_blind_index = $${idx++}`);
            values.push(data.family_name, this.ENCRYPTION_KEY, familyNameBlindIndex);
        }

        // Update full_name_blind_index if either name changed
        if (shouldUpdateFullNameIndex && currentPatient) {
            const newName = data.name !== undefined ? data.name : currentPatient.name;
            const newFamilyName = data.family_name !== undefined ? data.family_name : currentPatient.family_name;
            const fullNameBlindIndex = this.generateFullNameBlindIndex(newName, newFamilyName);
            fields.push(`full_name_blind_index = $${idx++}`);
            values.push(fullNameBlindIndex);
        }
        if (data.age !== undefined) {
            fields.push(`age = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.age.toString(), this.ENCRYPTION_KEY);
        }
        if (data.genre !== undefined) {
            fields.push(`genre = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.genre, this.ENCRYPTION_KEY);
        }
        if (data.telephone !== undefined) {
            fields.push(`telephone = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.telephone, this.ENCRYPTION_KEY);
        }
        if (data.email !== undefined) {
            fields.push(`email = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.email, this.ENCRYPTION_KEY);
        }
        if (data.adresse !== undefined) {
            fields.push(`adresse = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.adresse, this.ENCRYPTION_KEY);
        }
        if (data.dateNaissance !== undefined) {
            fields.push(`date_naissance = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.dateNaissance, this.ENCRYPTION_KEY);
        }
        if (data.numeroSecuriteSociale !== undefined) {
            fields.push(`numero_securite_sociale = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.numeroSecuriteSociale, this.ENCRYPTION_KEY);
        }
        if (data.medecinTraitant !== undefined) {
            fields.push(`medecin_traitant_id = $${idx++}`);
            values.push(data.medecinTraitant);
        }
        if (data.allergies !== undefined) {
            fields.push(`allergies = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.allergies, this.ENCRYPTION_KEY);
        }
        if (data.notes !== undefined) {
            fields.push(`notes = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.notes, this.ENCRYPTION_KEY);
        }
        if (data.nin !== undefined && data.nin !== null) {
            const ninBlindIndex = this.generateBlindIndex(data.nin);
            fields.push(`nin = pgp_sym_encrypt($${idx++}, $${idx++})`);
            fields.push(`nin_blind_index = $${idx++}`);
            values.push(data.nin, this.ENCRYPTION_KEY, ninBlindIndex);
        }
        if (data.chronicDiseases !== undefined) {
            fields.push(`chronicdiseases = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.chronicDiseases, this.ENCRYPTION_KEY);
        }
        if (data.emergencyContact !== undefined) {
            fields.push(`emergencycontact = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.emergencyContact, this.ENCRYPTION_KEY);
        }
        if (data.emergencyPhone !== undefined) {
            fields.push(`emergencyphone = pgp_sym_encrypt($${idx++}, $${idx++})`);
            values.push(data.emergencyPhone, this.ENCRYPTION_KEY);
        }
        if (data.is_private !== undefined) {
            fields.push(`is_private = $${idx++}`);
            values.push(data.is_private);
        }
        if (data.assistant_id !== undefined) {
            fields.push(`assistant_id = $${idx++}`);
            values.push(data.assistant_id);
        }
        if (data.is_chart_readed !== undefined) {
            fields.push(`is_chart_readed = $${idx++}`);
            values.push(data.is_chart_readed);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE patients SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
        const result = await pool.query(query, values);

        if (result.rows.length === 0) return null;

        return await this.findById(id);
    }

    // Delete patient
    static async delete(id: string): Promise<boolean> {
        const query = 'DELETE FROM patients WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all patients with privacy filtering - OPTIMIZED VERSION
    static async findAll(limit: number = 50, offset: number = 0, requestingDoctorId?: number): Promise<Patient[] | any[]> {
        // ⚡ OPTIMIZATION: Decrypt ALL fields in a SINGLE SQL query instead of 15 queries per patient
        const query = `
            SELECT 
                id,
                pgp_sym_decrypt(name, $3) as name,
                pgp_sym_decrypt(family_name, $3) as family_name,
                pgp_sym_decrypt(age, $3) as age,
                pgp_sym_decrypt(genre, $3) as genre,
                pgp_sym_decrypt(telephone, $3) as telephone,
                CASE WHEN email IS NOT NULL THEN pgp_sym_decrypt(email, $3) ELSE NULL END as email,
                CASE WHEN adresse IS NOT NULL THEN pgp_sym_decrypt(adresse, $3) ELSE NULL END as adresse,
                CASE WHEN date_naissance IS NOT NULL THEN pgp_sym_decrypt(date_naissance, $3) ELSE NULL END as date_naissance,
                CASE WHEN numero_securite_sociale IS NOT NULL THEN pgp_sym_decrypt(numero_securite_sociale, $3) ELSE NULL END as numero_securite_sociale,
                pgp_sym_decrypt(nin, $3) as nin,
                CASE WHEN emergencyContact IS NOT NULL THEN pgp_sym_decrypt(emergencyContact, $3) ELSE NULL END as emergencyContact,
                CASE WHEN emergencyPhone IS NOT NULL THEN pgp_sym_decrypt(emergencyPhone, $3) ELSE NULL END as emergencyPhone,
                CASE WHEN allergies IS NOT NULL THEN pgp_sym_decrypt(allergies, $3) ELSE NULL END as allergies,
                CASE WHEN chronicDiseases IS NOT NULL THEN pgp_sym_decrypt(chronicDiseases, $3) ELSE NULL END as chronicDiseases,
                CASE WHEN notes IS NOT NULL THEN pgp_sym_decrypt(notes, $3) ELSE NULL END as notes,
                medecin_traitant_id,
                consultations,
                is_private,
                assistant_id,
                is_chart_readed,
                created_at,
                updated_at
            FROM patients
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        `;

        // Single query with all decryption done in PostgreSQL
        const result = await pool.query(query, [limit, offset, this.ENCRYPTION_KEY]);

        // Map results directly (already decrypted)
        const patients = result.rows.map((row) => ({
            id: row.id,
            name: row.name,
            family_name: row.family_name,
            age: parseInt(row.age),
            genre: row.genre as 'homme' | 'femme',
            telephone: row.telephone,
            email: row.email,
            adresse: row.adresse,
            dateNaissance: row.date_naissance ? new Date(row.date_naissance) : null,
            numeroSecuriteSociale: row.numero_securite_sociale,
            nin: row.nin,
            emergencyContact: row.emergencycontact,
            emergencyPhone: row.emergencyphone,
            medecinTraitant: row.medecin_traitant_id,
            allergies: row.allergies,
            consultations: row.consultations,
            chronicDiseases: row.chronicdiseases,
            notes: row.notes,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            created_at: row.created_at,
            updated_at: row.updated_at
        }));

        // Apply privacy filtering if requestingDoctorId is provided
        if (requestingDoctorId !== undefined) {
            return await Promise.all(
                patients.map(patient => this.applyPrivacyFilterAsync(patient, requestingDoctorId))
            );
        }

        return patients;
    }

    /**
     * Search patients using blind indexes for fully encrypted fields
     * Supports searching by:
     * - Full name (name + family_name combined, e.g., "John Doe")
     * - Name only
     * - Family name only
     * - NIN (national identity number)
     *
     * Uses blind indexes (SHA256 hashes) to search encrypted fields without decryption.
     *
     * @param searchTerm - The search term (will be normalized and hashed)
     * @param limit - Maximum number of results to return
     * @returns Array of fully decrypted Patient objects matching the search
     */
    static async search(searchTerm: string, limit: number = 50): Promise<Patient[]> {
        // Generate blind indexes from search term
        const searchBlindIndex = this.generateBlindIndex(searchTerm);

        // Also try to parse as "name family_name" for full name search
        const searchTerms = searchTerm.trim().split(/\s+/);
        let fullNameBlindIndex: string | null = null;

        if (searchTerms.length === 2 && searchTerms[0] && searchTerms[1]) {
            // If search has 2 words, try "name family_name" combination
            fullNameBlindIndex = this.generateFullNameBlindIndex(searchTerms[0], searchTerms[1]);
        }

        // ⚡ OPTIMIZATION: Decrypt ALL fields in a SINGLE SQL query instead of 15 queries per patient
        const query = `
            SELECT 
                id,
                pgp_sym_decrypt(name, $4) as name,
                pgp_sym_decrypt(family_name, $4) as family_name,
                pgp_sym_decrypt(age, $4) as age,
                pgp_sym_decrypt(genre, $4) as genre,
                pgp_sym_decrypt(telephone, $4) as telephone,
                CASE WHEN email IS NOT NULL THEN pgp_sym_decrypt(email, $4) ELSE NULL END as email,
                CASE WHEN adresse IS NOT NULL THEN pgp_sym_decrypt(adresse, $4) ELSE NULL END as adresse,
                CASE WHEN date_naissance IS NOT NULL THEN pgp_sym_decrypt(date_naissance, $4) ELSE NULL END as date_naissance,
                CASE WHEN numero_securite_sociale IS NOT NULL THEN pgp_sym_decrypt(numero_securite_sociale, $4) ELSE NULL END as numero_securite_sociale,
                pgp_sym_decrypt(nin, $4) as nin,
                CASE WHEN emergencyContact IS NOT NULL THEN pgp_sym_decrypt(emergencyContact, $4) ELSE NULL END as emergencyContact,
                CASE WHEN emergencyPhone IS NOT NULL THEN pgp_sym_decrypt(emergencyPhone, $4) ELSE NULL END as emergencyPhone,
                CASE WHEN allergies IS NOT NULL THEN pgp_sym_decrypt(allergies, $4) ELSE NULL END as allergies,
                CASE WHEN chronicDiseases IS NOT NULL THEN pgp_sym_decrypt(chronicDiseases, $4) ELSE NULL END as chronicDiseases,
                CASE WHEN notes IS NOT NULL THEN pgp_sym_decrypt(notes, $4) ELSE NULL END as notes,
                medecin_traitant_id,
                consultations,
                is_private,
                assistant_id,
                is_chart_readed,
                created_at,
                updated_at
            FROM patients
            WHERE name_blind_index = $1
               OR family_name_blind_index = $1
               OR nin_blind_index = $1
               OR ($2::text IS NOT NULL AND full_name_blind_index = $2)
            ORDER BY created_at DESC
            LIMIT $3
        `;

        // Single query with all decryption done in PostgreSQL
        const result = await pool.query(query, [searchBlindIndex, fullNameBlindIndex, limit, this.ENCRYPTION_KEY]);

        // Map results directly (already decrypted by PostgreSQL)
        const patients = result.rows.map((row) => ({
            id: row.id,
            name: row.name,
            family_name: row.family_name,
            age: parseInt(row.age),
            genre: row.genre as 'homme' | 'femme',
            telephone: row.telephone,
            email: row.email,
            adresse: row.adresse,
            dateNaissance: row.date_naissance ? new Date(row.date_naissance) : null,
            numeroSecuriteSociale: row.numero_securite_sociale,
            nin: row.nin,
            emergencyContact: row.emergencycontact,
            emergencyPhone: row.emergencyphone,
            medecinTraitant: row.medecin_traitant_id,
            allergies: row.allergies,
            consultations: row.consultations,
            chronicDiseases: row.chronicdiseases,
            notes: row.notes,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            created_at: row.created_at,
            updated_at: row.updated_at
        }));

        return patients;
    }

    // Check if patient exists by telephone
    static async findByTelephone(telephone: string): Promise<Patient | null> {
        const query = `
            SELECT id, name, family_name, age, genre, telephone, email, adresse,
                   date_naissance, numero_securite_sociale, medecin_traitant_id,
                   allergies, consultations, chronicDiseases, notes, nin,
                   emergencyContact, emergencyPhone, is_private, created_at, updated_at
            FROM patients
            WHERE pgp_sym_decrypt(telephone, $2) = $1
        `;
        const result = await pool.query(query, [telephone, this.ENCRYPTION_KEY]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];

        // Decrypt all encrypted fields
        const [name, family_name, age, genre, telephone_decrypted, email, adresse,
            dateNaissance, numeroSecuriteSociale, nin,
            emergencyContact, emergencyPhone,
            allergies, chronicDiseases, notes] = await Promise.all([
                this.decrypt(row.name),
                this.decrypt(row.family_name),
                this.decrypt(row.age),
                this.decrypt(row.genre),
                this.decrypt(row.telephone),
                row.email ? this.decrypt(row.email) : null,
                row.adresse ? this.decrypt(row.adresse) : null,
                row.date_naissance ? this.decrypt(row.date_naissance) : null,
                row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
                this.decrypt(row.nin),
                row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
                row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
                row.allergies ? this.decrypt(row.allergies) : null,
                row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
                row.notes ? this.decrypt(row.notes) : null
            ]);

        return {
            id: row.id,
            name,
            family_name,
            age: parseInt(age),
            genre: genre as 'homme' | 'femme',
            telephone: telephone_decrypted,
            email,
            adresse,
            dateNaissance: dateNaissance ? new Date(dateNaissance) : null,
            numeroSecuriteSociale,
            medecinTraitant: row.medecin_traitant_id,
            allergies,
            consultations: row.consultations,
            chronicDiseases,
            notes,
            nin,
            emergencyContact,
            emergencyPhone,
            is_private: row.is_private ?? false,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    // Check if patient exists by email
    static async findByEmail(email: string): Promise<Patient | null> {
        const query = `
            SELECT id, name, family_name, age, genre, telephone, email, adresse,
                   date_naissance, numero_securite_sociale, medecin_traitant_id,
                   allergies, consultations, chronicDiseases, notes, nin,
                   emergencyContact, emergencyPhone, is_private, created_at, updated_at
            FROM patients
            WHERE pgp_sym_decrypt(email, $2) = $1
        `;
        const result = await pool.query(query, [email, this.ENCRYPTION_KEY]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];

        // Decrypt all encrypted fields
        const [name, family_name, age, genre, telephone, email_decrypted, adresse,
            dateNaissance, numeroSecuriteSociale, nin,
            emergencyContact, emergencyPhone,
            allergies, chronicDiseases, notes] = await Promise.all([
                this.decrypt(row.name),
                this.decrypt(row.family_name),
                this.decrypt(row.age),
                this.decrypt(row.genre),
                this.decrypt(row.telephone),
                row.email ? this.decrypt(row.email) : null,
                row.adresse ? this.decrypt(row.adresse) : null,
                row.date_naissance ? this.decrypt(row.date_naissance) : null,
                row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
                this.decrypt(row.nin),
                row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
                row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
                row.allergies ? this.decrypt(row.allergies) : null,
                row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
                row.notes ? this.decrypt(row.notes) : null
            ]);

        return {
            id: row.id,
            name,
            family_name,
            age: parseInt(age),
            genre: genre as 'homme' | 'femme',
            telephone,
            email: email_decrypted,
            adresse,
            dateNaissance: dateNaissance ? new Date(dateNaissance) : null,
            numeroSecuriteSociale,
            medecinTraitant: row.medecin_traitant_id,
            allergies,
            consultations: row.consultations,
            chronicDiseases,
            notes,
            nin,
            emergencyContact,
            emergencyPhone,
            is_private: row.is_private ?? false,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    /**
     * Find ALL patients matching name + family_name + dateNaissance
     * Uses blind indexes for efficient name matching without decrypting all records
     * Returns array of all matching patients for history aggregation across duplicates
     */
    static async findByNameAndBirthDate(name: string, family_name: string, dateNaissance: string): Promise<Patient[]> {
        // Generate blind indexes for name matching
        const nameBlindIndex = this.generateBlindIndex(name);
        const familyNameBlindIndex = this.generateBlindIndex(family_name);

        const query = `
            SELECT id, name, family_name, age, genre, telephone, email, adresse,
                   date_naissance, numero_securite_sociale, medecin_traitant_id,
                   allergies, consultations, chronicDiseases, notes, nin,
                   emergencyContact, emergencyPhone, is_private, created_at, updated_at
            FROM patients
            WHERE name_blind_index = $1              -- Match using blind index
            AND family_name_blind_index = $2         -- Match using blind index
            AND pgp_sym_decrypt(date_naissance, $4) = $3  -- Decrypt to match birth date
        `;
        const result = await pool.query(query, [nameBlindIndex, familyNameBlindIndex, dateNaissance, this.ENCRYPTION_KEY]);

        if (result.rows.length === 0) return [];

        // Decrypt all matching rows
        return Promise.all(result.rows.map(async (row) => {
            const [name_decrypted, family_name_decrypted, age, genre, telephone, email, adresse,
                dateNaissance_decrypted, numeroSecuriteSociale, nin,
                emergencyContact, emergencyPhone,
                allergies, chronicDiseases, notes] = await Promise.all([
                    this.decrypt(row.name),
                    this.decrypt(row.family_name),
                    this.decrypt(row.age),
                    this.decrypt(row.genre),
                    this.decrypt(row.telephone),
                    row.email ? this.decrypt(row.email) : null,
                    row.adresse ? this.decrypt(row.adresse) : null,
                    row.date_naissance ? this.decrypt(row.date_naissance) : null,
                    row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
                    this.decrypt(row.nin),
                    row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
                    row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
                    row.allergies ? this.decrypt(row.allergies) : null,
                    row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
                    row.notes ? this.decrypt(row.notes) : null
                ]);

            return {
                id: row.id,
                name: name_decrypted,
                family_name: family_name_decrypted,
                age: parseInt(age),
                genre: genre as 'homme' | 'femme',
                telephone,
                email,
                adresse,
                dateNaissance: dateNaissance_decrypted ? new Date(dateNaissance_decrypted) : null,
                numeroSecuriteSociale,
                medecinTraitant: row.medecin_traitant_id,
                allergies,
                consultations: row.consultations,
                chronicDiseases,
                notes,
                nin,
                emergencyContact,
                emergencyPhone,
                is_private: row.is_private ?? false,
                created_at: row.created_at,
                updated_at: row.updated_at
            };
        }));
    }

    // Helper method to fetch doctor info by user ID (kept for isolated usages)
    private static async getDoctorInfo(doctorUserId: number): Promise<{ name: string; family_name: string; phone: string } | null> {
        try {
            const query = `
                SELECT u.name, u.family_name, d.phone_number
                FROM users u
                JOIN doctors d ON u.id = d.user_id
                WHERE u.id = $1
            `;
            const result = await pool.query(query, [doctorUserId]);

            if (result.rows.length === 0) return null;

            return {
                name: result.rows[0].name,
                family_name: result.rows[0].family_name,
                phone: result.rows[0].phone_number
            };
        } catch (error) {
            console.error('Error fetching doctor info:', error);
            return null;
        }
    }

    /**
     * ⚡ BATCH: Fetch doctor info for multiple doctors in a SINGLE query.
     * Replaces N individual getDoctorInfo() calls with one JOIN.
     * Returns a Map keyed by doctor user ID.
     */
    private static async getDoctorInfoBatch(
        doctorIds: number[]
    ): Promise<Map<number, { name: string; family_name: string; phone: string }>> {
        if (doctorIds.length === 0) return new Map();
        try {
            const result = await pool.query(
                `SELECT u.id, u.name, u.family_name, d.phone_number
                 FROM users u
                 JOIN doctors d ON u.id = d.user_id
                 WHERE u.id = ANY($1::int[])`,
                [doctorIds]
            );
            return new Map(
                result.rows.map(r => [r.id as number, {
                    name: r.name as string,
                    family_name: r.family_name as string,
                    phone: r.phone_number as string
                }])
            );
        } catch (error) {
            console.error('Error in getDoctorInfoBatch:', error);
            return new Map();
        }
    }

    /**
     * ⚡ SYNC privacy filter — zero DB calls.
     * Requires that the patient row already has assigned_doctor_name/family_name/phone
     * embedded from the SQL query (via LEFT JOIN users/doctors).
     * Use this for all list and paginated operations.
     */
    static applyPrivacyFilterSync(
        patient: any & { is_shared_with_me?: boolean },
        requestingDoctorId: number
    ): any {
        // Not private → return everything as-is
        if (!patient.is_private) {
            return {
                ...patient,
                is_shared_with_me: patient.is_shared_with_me ?? false
            };
        }

        // Private but requesting doctor IS the assigned doctor → full access
        if (patient.medecinTraitant === requestingDoctorId) {
            return {
                ...patient,
                is_shared_with_me: patient.is_shared_with_me ?? false
            };
        }

        // Private and requesting doctor is NOT the assigned doctor → restrict data
        // Assigned doctor info comes from LEFT JOIN columns embedded in the row
        const assignedDoctor =
            patient.assigned_doctor_name || patient.assigned_doctor_family_name
                ? {
                      name: `${patient.assigned_doctor_name ?? ''} ${patient.assigned_doctor_family_name ?? ''}`.trim(),
                      phone: patient.assigned_doctor_phone ?? null
                  }
                : null;

        return {
            id: patient.id,
            name: patient.name,
            family_name: patient.family_name,
            age: patient.age,
            genre: patient.genre,
            telephone: patient.telephone,
            email: patient.email,
            adresse: patient.adresse,
            dateNaissance: patient.dateNaissance,
            numeroSecuriteSociale: patient.numeroSecuriteSociale,
            consultations: patient.consultations,
            nin: patient.nin,
            emergencyContact: patient.emergencyContact,
            emergencyPhone: patient.emergencyPhone,
            is_private: patient.is_private,
            is_shared_with_me: patient.is_shared_with_me ?? false,
            created_at: patient.created_at,
            updated_at: patient.updated_at,
            // Sensitive fields hidden for non-assigned doctors
            allergies: null,
            chronicDiseases: null,
            notes: null,
            assignedDoctor,
        };
    }

    /**
     * @deprecated Use applyPrivacyFilterSync for list operations (no DB call).
     * Kept for isolated single-patient flows where doctor info is not pre-loaded.
     */
    static async applyPrivacyFilterAsync(patient: Patient & { is_shared_with_me?: boolean }, requestingDoctorId: number): Promise<any> {
        // If patient is not private, return full data (preserve is_shared_with_me)
        if (!patient.is_private) {
            return {
                ...patient,
                is_shared_with_me: patient.is_shared_with_me ?? false
            };
        }

        // If patient is private and requesting doctor is the assigned doctor, return full data
        if (patient.medecinTraitant === requestingDoctorId) {
            return {
                ...patient,
                is_shared_with_me: patient.is_shared_with_me ?? false
            };
        }

        // If patient is private and requesting doctor is NOT the assigned doctor
        // Fetch assigned doctor's information
        let doctorInfo = null;
        if (patient.medecinTraitant) {
            doctorInfo = await this.getDoctorInfo(patient.medecinTraitant);
        }

        // Return restricted data with doctor info
        return {
            id: patient.id,
            name: patient.name,
            family_name: patient.family_name,
            age: patient.age,
            genre: patient.genre,
            telephone: patient.telephone,
            email: patient.email,
            adresse: patient.adresse,
            dateNaissance: patient.dateNaissance,
            numeroSecuriteSociale: patient.numeroSecuriteSociale,
            consultations: patient.consultations,
            nin: patient.nin,
            emergencyContact: patient.emergencyContact,
            emergencyPhone: patient.emergencyPhone,
            is_private: patient.is_private,
            is_shared_with_me: patient.is_shared_with_me ?? false,
            created_at: patient.created_at,
            updated_at: patient.updated_at,
            // Hide sensitive fields
            allergies: null,
            chronicDiseases: null,
            notes: null,
            // Include assigned doctor info if available
            assignedDoctor: doctorInfo ? {
                name: `${doctorInfo.name} ${doctorInfo.family_name}`,
                phone: doctorInfo.phone
            } : null,
        };
    }

    // Synchronous version for backward compatibility (deprecated)
    static applyPrivacyFilter(patient: Patient, requestingDoctorId: number): Partial<Patient> {
        // If patient is not private, return full data
        if (!patient.is_private) {
            return patient;
        }

        // If patient is private and requesting doctor is the assigned doctor, return full data
        if (patient.medecinTraitant === requestingDoctorId) {
            return patient;
        }

        // If patient is private and requesting doctor is NOT the assigned doctor, return restricted data
        return {
            id: patient.id,
            name: patient.name,
            family_name: patient.family_name,
            age: patient.age,
            genre: patient.genre,
            telephone: patient.telephone,
            email: patient.email,
            adresse: patient.adresse,
            dateNaissance: patient.dateNaissance,
            numeroSecuriteSociale: patient.numeroSecuriteSociale,
            consultations: patient.consultations,
            nin: patient.nin,
            emergencyContact: patient.emergencyContact,
            emergencyPhone: patient.emergencyPhone,
            is_private: patient.is_private,
            created_at: patient.created_at,
            updated_at: patient.updated_at,
            // Hide sensitive fields
            allergies: null,
            chronicDiseases: null,
            notes: null,
        };
    }

    static async searchByNinExact(nin: string): Promise<Patient | null> {
        const ninBlindIndex = this.generateBlindIndex(nin);
        const result = await pool.query(`SELECT * FROM patients WHERE nin_blind_index = $1 LIMIT 1`, [ninBlindIndex]);
        if (result.rows.length === 0) return null;
        const row = result.rows[0];
        const [name, family_name, age, genre, telephone, email, adresse, dateNaissance, numeroSecuriteSociale, nin_decrypted, emergencyContact, emergencyPhone, allergies, chronicDiseases, notes] = await Promise.all([this.decrypt(row.name), this.decrypt(row.family_name), this.decrypt(row.age), this.decrypt(row.genre), this.decrypt(row.telephone), row.email ? this.decrypt(row.email) : null, row.adresse ? this.decrypt(row.adresse) : null, row.date_naissance ? this.decrypt(row.date_naissance) : null, row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null, this.decrypt(row.nin), row.emergencycontact ? this.decrypt(row.emergencycontact) : null, row.emergencyphone ? this.decrypt(row.emergencyphone) : null, row.allergies ? this.decrypt(row.allergies) : null, row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null, row.notes ? this.decrypt(row.notes) : null]);
        return { id: row.id, name, family_name, genre: genre as 'homme' | 'femme', age: parseInt(age), telephone, email, adresse, dateNaissance: dateNaissance ? new Date(dateNaissance) : null, numeroSecuriteSociale, nin: nin_decrypted, emergencyContact, emergencyPhone, medecinTraitant: row.medecin_traitant_id, allergies, consultations: row.consultations, chronicDiseases, notes, is_private: row.is_private ?? false, assistant_id: row.assistant_id, is_chart_readed: row.is_chart_readed ?? false, created_at: row.created_at, updated_at: row.updated_at };
    }

    /**
     * Check if a patient with the same name, family_name and birthDate already exists for this doctor
     * Returns true if a duplicate patient exists that this doctor has access to
     */
    static async isPatientDuplicateForDoctor(
        name: string, 
        family_name: string, 
        dateNaissance: string, 
        doctorUserId: number
    ): Promise<{ exists: boolean; patientName?: string }> {
        const nameBlindIndex = this.generateBlindIndex(name);
        const familyNameBlindIndex = this.generateBlindIndex(family_name);

        const query = `
            SELECT p.id,
                   pgp_sym_decrypt(p.name, $5) as name,
                   pgp_sym_decrypt(p.family_name, $5) as family_name
            FROM patients p
            WHERE p.name_blind_index = $1
            AND p.family_name_blind_index = $2
            AND pgp_sym_decrypt(p.date_naissance, $5) = $3
            AND (
                p.created_by_doctor_id = $4
                OR p.medecin_traitant_id = $4
                OR EXISTS (SELECT 1 FROM prescriptions pr WHERE pr.patient_id = p.id AND pr.doctor_user_id = $4)
                OR EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id = p.id AND a.doctor_user_id = $4 AND a.is_done = true)
                OR EXISTS (SELECT 1 FROM assistants ast WHERE p.assistant_id = ast.user_id AND ast.doctor_id = $4)
                OR EXISTS (SELECT 1 FROM doctor_patient_privacy dpp WHERE dpp.patient_id = p.id AND dpp.doctor_id = $4)
            )
            LIMIT 1
        `;

        const result = await pool.query(query, [nameBlindIndex, familyNameBlindIndex, dateNaissance, doctorUserId, this.ENCRYPTION_KEY]);

        if (result.rows.length > 0) {
            const row = result.rows[0];
            return {
                exists: true,
                patientName: `${row.name} ${row.family_name}`
            };
        }

        return { exists: false };
    }

    /**
     * Check if a NIN already exists for a doctor's accessible patients
     * Returns true if the NIN is already used by a patient that this doctor has access to
     * This prevents duplicate patients per doctor, but allows different doctors to have patients with the same NIN
     */
    static async isNinUsedByDoctor(nin: string, doctorUserId: number): Promise<{ exists: boolean; patientName?: string }> {
        if (!nin || nin.trim() === '') {
            return { exists: false };
        }

        const ninBlindIndex = this.generateBlindIndex(nin);

        const query = `
            SELECT p.id,
                   pgp_sym_decrypt(p.name, $3) as name,
                   pgp_sym_decrypt(p.family_name, $3) as family_name
            FROM patients p
            WHERE p.nin_blind_index = $1
            AND (
                p.created_by_doctor_id = $2
                OR p.medecin_traitant_id = $2
                OR EXISTS (SELECT 1 FROM prescriptions pr WHERE pr.patient_id = p.id AND pr.doctor_user_id = $2)
                OR EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id = p.id AND a.doctor_user_id = $2 AND a.is_done = true)
                OR EXISTS (SELECT 1 FROM assistants ast WHERE p.assistant_id = ast.user_id AND ast.doctor_id = $2)
                OR EXISTS (SELECT 1 FROM doctor_patient_privacy dpp WHERE dpp.patient_id = p.id AND dpp.doctor_id = $2)
            )
            LIMIT 1
        `;

        const result = await pool.query(query, [ninBlindIndex, doctorUserId, this.ENCRYPTION_KEY]);

        if (result.rows.length > 0) {
            const row = result.rows[0];
            return {
                exists: true,
                patientName: `${row.name} ${row.family_name}`
            };
        }

        return { exists: false };
    }

    /**
     * Find ALL patients matching a NIN (for duplicate detection)
     */
    static async findAllByNin(nin: string): Promise<Patient[]> {
        const ninBlindIndex = this.generateBlindIndex(nin);
        const result = await pool.query(`SELECT * FROM patients WHERE nin_blind_index = $1`, [ninBlindIndex]);

        if (result.rows.length === 0) return [];

        return Promise.all(result.rows.map(async (row) => {
            const [name, family_name, age, genre, telephone, email, adresse, dateNaissance, numeroSecuriteSociale, nin_decrypted, emergencyContact, emergencyPhone, allergies, chronicDiseases, notes] = await Promise.all([
                this.decrypt(row.name),
                this.decrypt(row.family_name),
                this.decrypt(row.age),
                this.decrypt(row.genre),
                this.decrypt(row.telephone),
                row.email ? this.decrypt(row.email) : null,
                row.adresse ? this.decrypt(row.adresse) : null,
                row.date_naissance ? this.decrypt(row.date_naissance) : null,
                row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
                this.decrypt(row.nin),
                row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
                row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
                row.allergies ? this.decrypt(row.allergies) : null,
                row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
                row.notes ? this.decrypt(row.notes) : null
            ]);

            return {
                id: row.id,
                name,
                family_name,
                genre: genre as 'homme' | 'femme',
                age: parseInt(age),
                telephone,
                email,
                adresse,
                dateNaissance: dateNaissance ? new Date(dateNaissance) : null,
                numeroSecuriteSociale,
                nin: nin_decrypted,
                emergencyContact,
                emergencyPhone,
                medecinTraitant: row.medecin_traitant_id,
                allergies,
                consultations: row.consultations,
                chronicDiseases,
                notes,
                is_private: row.is_private ?? false,
                assistant_id: row.assistant_id,
                is_chart_readed: row.is_chart_readed ?? false,
                created_at: row.created_at,
                updated_at: row.updated_at
            };
        }));
    }

    static async hasConsultedDoctor(patientId: string, doctorUserId: number): Promise<boolean> {
        const query = `SELECT EXISTS (SELECT 1 FROM prescriptions WHERE patient_id = $1 AND doctor_user_id = $2 UNION SELECT 1 FROM appointments WHERE patient_id = $1 AND doctor_user_id = $2 AND is_done = true UNION SELECT 1 FROM patients WHERE id = $1 AND medecin_traitant_id = $2 UNION SELECT 1 FROM patients p JOIN assistants a ON p.assistant_id = a.user_id WHERE p.id = $1 AND a.doctor_id = $2) as has_consulted`;
        const result = await pool.query(query, [patientId, doctorUserId]);
        return result.rows[0]?.has_consulted || false;
    }

    /**
     * Check if a doctor has access to a patient
     * Used for determining if a patient should appear in name search results
     */
    static async isDoctorAccessible(patientId: string, doctorUserId: number): Promise<boolean> {
        const query = `
            SELECT EXISTS (
                SELECT 1 FROM prescriptions WHERE patient_id = $1 AND doctor_user_id = $2
                UNION
                SELECT 1 FROM appointments WHERE patient_id = $1 AND doctor_user_id = $2 AND is_done = true
                UNION
                SELECT 1 FROM patients WHERE id = $1 AND medecin_traitant_id = $2
                UNION
                SELECT 1 FROM patients p JOIN assistants a ON p.assistant_id = a.user_id WHERE p.id = $1 AND a.doctor_id = $2
                UNION
                SELECT 1 FROM medical_shares WHERE patient_id = $1 AND shared_with_doctor_id = $2 AND status = 'active' AND expires_at > NOW()
                UNION
                SELECT 1 FROM patients WHERE id = $1 AND created_by_doctor_id = $2
                UNION
                SELECT 1 FROM doctor_patient_privacy WHERE patient_id = $1 AND doctor_id = $2
            ) as is_accessible
        `;
        const result = await pool.query(query, [patientId, doctorUserId]);
        return result.rows[0]?.is_accessible || false;
    }

    /**
     * Search patients that the doctor has access to (privacy-aware search)
     * Only returns patients visible to the requesting doctor
     * 
     * @param searchTerm - Name or family name to search for
     * @param doctorUserId - The requesting doctor's user ID
     * @param limit - Maximum number of results
     * @returns Array of accessible patients matching the search
     */
    static async searchAccessiblePatients(
        searchTerm: string,
        doctorUserId: number,
        limit: number = 50
    ): Promise<(Patient & { is_shared_with_me?: boolean })[]> {
        const searchBlindIndex = this.generateBlindIndex(searchTerm);

        // Also try to parse as "name family_name" for full name search
        const searchTerms = searchTerm.trim().split(/\s+/);
        let fullNameBlindIndex: string | null = null;

        if (searchTerms.length === 2 && searchTerms[0] && searchTerms[1]) {
            fullNameBlindIndex = this.generateFullNameBlindIndex(searchTerms[0], searchTerms[1]);
        }

        // ⚡ Task 1.4: Embed assigned-doctor info via LEFT JOIN so applyPrivacyFilterSync
        // needs zero additional DB calls for search results.
        const query = `
            SELECT DISTINCT ON (p.created_at, p.id)
                p.id,
                pgp_sym_decrypt(p.name, $5) as name,
                pgp_sym_decrypt(p.family_name, $5) as family_name,
                CASE WHEN p.age IS NOT NULL THEN pgp_sym_decrypt(p.age, $5) ELSE NULL END as age,
                pgp_sym_decrypt(p.genre, $5) as genre,
                CASE WHEN p.telephone IS NOT NULL THEN pgp_sym_decrypt(p.telephone, $5) ELSE NULL END as telephone,
                CASE WHEN p.email IS NOT NULL THEN pgp_sym_decrypt(p.email, $5) ELSE NULL END as email,
                CASE WHEN p.adresse IS NOT NULL THEN pgp_sym_decrypt(p.adresse, $5) ELSE NULL END as adresse,
                CASE WHEN p.date_naissance IS NOT NULL THEN pgp_sym_decrypt(p.date_naissance, $5) ELSE NULL END as date_naissance,
                CASE WHEN p.numero_securite_sociale IS NOT NULL THEN pgp_sym_decrypt(p.numero_securite_sociale, $5) ELSE NULL END as numero_securite_sociale,
                CASE WHEN p.nin IS NOT NULL THEN pgp_sym_decrypt(p.nin, $5) ELSE NULL END as nin,
                CASE WHEN p.emergencyContact IS NOT NULL THEN pgp_sym_decrypt(p.emergencyContact, $5) ELSE NULL END as emergencyContact,
                CASE WHEN p.emergencyPhone IS NOT NULL THEN pgp_sym_decrypt(p.emergencyPhone, $5) ELSE NULL END as emergencyPhone,
                CASE WHEN p.allergies IS NOT NULL THEN pgp_sym_decrypt(p.allergies, $5) ELSE NULL END as allergies,
                CASE WHEN p.chronicDiseases IS NOT NULL THEN pgp_sym_decrypt(p.chronicDiseases, $5) ELSE NULL END as chronicDiseases,
                CASE WHEN p.notes IS NOT NULL THEN pgp_sym_decrypt(p.notes, $5) ELSE NULL END as notes,
                p.medecin_traitant_id,
                p.consultations,
                p.is_private,
                p.assistant_id,
                p.is_chart_readed,
                p.created_by_doctor_id,
                p.created_at,
                p.updated_at,
                EXISTS (
                    SELECT 1 FROM medical_shares ms
                    WHERE ms.patient_id = p.id AND ms.shared_with_doctor_id = $3
                      AND ms.status = 'active' AND ms.expires_at > NOW()
                ) AS is_shared_with_me,
                -- ⚡ assigned doctor info embedded — no extra queries in privacy filter
                u_assigned.name               AS assigned_doctor_name,
                u_assigned.family_name         AS assigned_doctor_family_name,
                d_assigned.phone_number        AS assigned_doctor_phone
            FROM patients p
            LEFT JOIN users u_assigned   ON p.medecin_traitant_id = u_assigned.id
            LEFT JOIN doctors d_assigned ON u_assigned.id = d_assigned.user_id
            WHERE (p.name_blind_index = $1 OR p.family_name_blind_index = $1 OR ($2::text IS NOT NULL AND p.full_name_blind_index = $2))
            AND EXISTS (
                SELECT 1 FROM prescriptions pr WHERE pr.patient_id = p.id AND pr.doctor_user_id = $3
                UNION
                SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.doctor_user_id = $3 AND ap.is_done = true
                UNION
                SELECT 1 FROM patients p2 WHERE p2.id = p.id AND p2.medecin_traitant_id = $3
                UNION
                SELECT 1 FROM assistants a WHERE p.assistant_id = a.user_id AND a.doctor_id = $3
                UNION
                SELECT 1 FROM medical_shares ms WHERE ms.patient_id = p.id AND ms.shared_with_doctor_id = $3 AND ms.status = 'active' AND ms.expires_at > NOW()
                UNION
                SELECT 1 FROM patients p3 WHERE p3.id = p.id AND p3.created_by_doctor_id = $3
                UNION
                SELECT 1 FROM doctor_patient_privacy dpp WHERE dpp.patient_id = p.id AND dpp.doctor_id = $3
            )
            ORDER BY p.created_at DESC, p.id DESC
            LIMIT $4
        `;

        const result = await pool.query(query, [searchBlindIndex, fullNameBlindIndex, doctorUserId, limit, this.ENCRYPTION_KEY]);

        return result.rows.map((row) => ({
            id: row.id,
            name: row.name,
            family_name: row.family_name,
            age: row.age ? parseInt(row.age) : undefined,
            genre: row.genre as 'homme' | 'femme',
            telephone: row.telephone,
            email: row.email,
            adresse: row.adresse,
            dateNaissance: row.date_naissance ? new Date(row.date_naissance) : null,
            numeroSecuriteSociale: row.numero_securite_sociale,
            nin: row.nin,
            emergencyContact: row.emergencycontact,
            emergencyPhone: row.emergencyphone,
            medecinTraitant: row.medecin_traitant_id,
            allergies: row.allergies,
            consultations: row.consultations,
            chronicDiseases: row.chronicdiseases,
            notes: row.notes,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            is_shared_with_me: row.is_shared_with_me ?? false,
            created_by_doctor_id: row.created_by_doctor_id,
            created_at: row.created_at,
            updated_at: row.updated_at,
            // Pre-loaded from LEFT JOIN — used by applyPrivacyFilterSync
            assigned_doctor_name: row.assigned_doctor_name ?? undefined,
            assigned_doctor_family_name: row.assigned_doctor_family_name ?? undefined,
            assigned_doctor_phone: row.assigned_doctor_phone ?? undefined,
        }));
    }

    /**
     * ⚡ OPTIMIZED: Get patients who have consulted a specific doctor.
     * Task 1.3: Embeds assigned-doctor info via LEFT JOIN — 1 query per page.
     * Task 4.1: Supports cursor-based (keyset) pagination for O(1) cost at any depth.
     *           Falls back to OFFSET pagination for backward compatibility.
     */
    static async findAllByDoctorConsultations(
        limit: number,
        offset: number,
        doctorUserId: number,
        cursor?: { created_at: string; id: string } | null
    ): Promise<any[]> {
        // Build the pagination clause:
        // - Cursor: WHERE (created_at, id) < (cursor_date, cursor_id)  → O(1)
        // - Offset: OFFSET $2                                         → O(n), kept for compat
        const useCursor = cursor !== null && cursor !== undefined;

        const paginationWhere = useCursor
            ? `AND (p.created_at < $4::timestamptz OR (p.created_at = $4::timestamptz AND p.id < $5::uuid))`
            : '';

        // Parameter positions:
        // Cursor mode:  $1=limit  $2=doctorUserId  $3=encKey  $4=cursor_date  $5=cursor_id
        // Offset mode:  $1=limit  $2=offset        $3=doctorUserId             $4=encKey
        const offsetClause = useCursor ? '' : 'OFFSET $2';
        const doctorParam  = useCursor ? '$2' : '$3';
        const encKeyParam  = useCursor ? '$3' : '$4';
        const shareDocParam = useCursor ? '$2' : '$3';

        const query = `
            SELECT DISTINCT ON (p.created_at, p.id)
                p.id,
                pgp_sym_decrypt(p.name, ${encKeyParam}) as name,
                pgp_sym_decrypt(p.family_name, ${encKeyParam}) as family_name,
                CASE WHEN p.age IS NOT NULL THEN pgp_sym_decrypt(p.age, ${encKeyParam}) ELSE NULL END as age,
                pgp_sym_decrypt(p.genre, ${encKeyParam}) as genre,
                CASE WHEN p.telephone IS NOT NULL THEN pgp_sym_decrypt(p.telephone, ${encKeyParam}) ELSE NULL END as telephone,
                CASE WHEN p.email IS NOT NULL THEN pgp_sym_decrypt(p.email, ${encKeyParam}) ELSE NULL END as email,
                CASE WHEN p.adresse IS NOT NULL THEN pgp_sym_decrypt(p.adresse, ${encKeyParam}) ELSE NULL END as adresse,
                CASE WHEN p.date_naissance IS NOT NULL THEN pgp_sym_decrypt(p.date_naissance, ${encKeyParam}) ELSE NULL END as date_naissance,
                CASE WHEN p.numero_securite_sociale IS NOT NULL THEN pgp_sym_decrypt(p.numero_securite_sociale, ${encKeyParam}) ELSE NULL END as numero_securite_sociale,
                CASE WHEN p.nin IS NOT NULL THEN pgp_sym_decrypt(p.nin, ${encKeyParam}) ELSE NULL END as nin,
                CASE WHEN p.emergencyContact IS NOT NULL THEN pgp_sym_decrypt(p.emergencyContact, ${encKeyParam}) ELSE NULL END as emergencyContact,
                CASE WHEN p.emergencyPhone IS NOT NULL THEN pgp_sym_decrypt(p.emergencyPhone, ${encKeyParam}) ELSE NULL END as emergencyPhone,
                CASE WHEN p.allergies IS NOT NULL THEN pgp_sym_decrypt(p.allergies, ${encKeyParam}) ELSE NULL END as allergies,
                CASE WHEN p.chronicDiseases IS NOT NULL THEN pgp_sym_decrypt(p.chronicDiseases, ${encKeyParam}) ELSE NULL END as chronicDiseases,
                CASE WHEN p.notes IS NOT NULL THEN pgp_sym_decrypt(p.notes, ${encKeyParam}) ELSE NULL END as notes,
                p.medecin_traitant_id,
                p.consultations,
                p.is_private,
                p.assistant_id,
                p.is_chart_readed,
                p.created_by_doctor_id,
                p.created_at,
                p.updated_at,
                -- ⚡ share status inline — no second query
                EXISTS (
                    SELECT 1 FROM medical_shares ms
                    WHERE ms.patient_id = p.id
                      AND ms.shared_with_doctor_id = ${shareDocParam}
                      AND ms.status = 'active'
                      AND ms.expires_at > NOW()
                ) AS is_shared_with_me,
                -- ⚡ assigned doctor info inline — eliminates N getDoctorInfo() calls
                u_assigned.name               AS assigned_doctor_name,
                u_assigned.family_name         AS assigned_doctor_family_name,
                d_assigned.phone_number        AS assigned_doctor_phone
            FROM patients p
            LEFT JOIN users u_assigned   ON p.medecin_traitant_id = u_assigned.id
            LEFT JOIN doctors d_assigned ON u_assigned.id = d_assigned.user_id
            WHERE EXISTS (
                SELECT 1 FROM prescriptions pr WHERE pr.patient_id = p.id AND pr.doctor_user_id = ${doctorParam}
                UNION
                SELECT 1 FROM appointments ap WHERE ap.patient_id = p.id AND ap.doctor_user_id = ${doctorParam} AND ap.is_done = true
                UNION
                SELECT 1 FROM patients p2 WHERE p2.id = p.id AND p2.medecin_traitant_id = ${doctorParam}
                UNION
                SELECT 1 FROM assistants a WHERE p.assistant_id = a.user_id AND a.doctor_id = ${doctorParam}
                UNION
                SELECT 1 FROM medical_shares ms WHERE ms.patient_id = p.id AND ms.shared_with_doctor_id = ${doctorParam} AND ms.status = 'active' AND ms.expires_at > NOW()
                UNION
                SELECT 1 FROM patients p3 WHERE p3.id = p.id AND p3.created_by_doctor_id = ${doctorParam}
                UNION
                SELECT 1 FROM doctor_patient_privacy dpp WHERE dpp.patient_id = p.id AND dpp.doctor_id = ${doctorParam}
            )
            ${paginationWhere}
            ORDER BY p.created_at DESC, p.id DESC
            LIMIT $1 ${offsetClause}
        `;

        // Build params array based on mode
        const params = useCursor
            ? [limit, doctorUserId, this.ENCRYPTION_KEY, cursor!.created_at, cursor!.id]
            : [limit, offset, doctorUserId, this.ENCRYPTION_KEY];

        const result = await pool.query(query, params);

        return result.rows.map((row) => ({
            id: row.id,
            name: row.name,
            family_name: row.family_name,
            age: row.age ? parseInt(row.age) : undefined,
            genre: row.genre as 'homme' | 'femme',
            telephone: row.telephone,
            email: row.email,
            adresse: row.adresse,
            dateNaissance: row.date_naissance ? new Date(row.date_naissance) : null,
            numeroSecuriteSociale: row.numero_securite_sociale,
            nin: row.nin,
            emergencyContact: row.emergencycontact,
            emergencyPhone: row.emergencyphone,
            medecinTraitant: row.medecin_traitant_id,
            allergies: row.allergies,
            consultations: row.consultations,
            chronicDiseases: row.chronicdiseases,
            notes: row.notes,
            is_private: row.is_private ?? false,
            assistant_id: row.assistant_id,
            is_chart_readed: row.is_chart_readed ?? false,
            is_shared_with_me: row.is_shared_with_me ?? false,
            created_by_doctor_id: row.created_by_doctor_id,
            created_at: row.created_at,
            updated_at: row.updated_at,
            // Pre-loaded from LEFT JOIN — used by applyPrivacyFilterSync
            assigned_doctor_name: row.assigned_doctor_name ?? undefined,
            assigned_doctor_family_name: row.assigned_doctor_family_name ?? undefined,
            assigned_doctor_phone: row.assigned_doctor_phone ?? undefined,
        }));
    }


    // Find patients who have prescriptions from a specific doctor
    static async findByDoctorPrescriptions(doctorId: number): Promise<Patient[]> {
        const query = `
            SELECT DISTINCT p.id, p.name, p.family_name, p.age, p.genre, p.telephone, p.email, p.adresse,
                   p.date_naissance, p.numero_securite_sociale, p.medecin_traitant_id,
                   p.allergies, p.consultations, p.chronicDiseases, p.notes, p.nin,
                   p.emergencyContact, p.emergencyPhone, p.is_private, p.assistant_id, p.is_chart_readed,
                   p.created_at, p.updated_at
            FROM patients p
            JOIN prescriptions pr ON p.id = pr.patient_id
            WHERE pr.doctor_user_id = $1
            ORDER BY p.created_at DESC
        `;
        const result = await pool.query(query, [doctorId]);

        // Decrypt all patients
        const patients = await Promise.all(
            result.rows.map(async (row) => {
                const [name, family_name, age, genre, telephone, email, adresse,
                    dateNaissance, numeroSecuriteSociale, nin,
                    emergencyContact, emergencyPhone,
                    allergies, chronicDiseases, notes] = await Promise.all([
                        this.decrypt(row.name),
                        this.decrypt(row.family_name),
                        this.decrypt(row.age),
                        this.decrypt(row.genre),
                        this.decrypt(row.telephone),
                        row.email ? this.decrypt(row.email) : null,
                        row.adresse ? this.decrypt(row.adresse) : null,
                        row.date_naissance ? this.decrypt(row.date_naissance) : null,
                        row.numero_securite_sociale ? this.decrypt(row.numero_securite_sociale) : null,
                        this.decrypt(row.nin),
                        row.emergencycontact ? this.decrypt(row.emergencycontact) : null,
                        row.emergencyphone ? this.decrypt(row.emergencyphone) : null,
                        row.allergies ? this.decrypt(row.allergies) : null,
                        row.chronicdiseases ? this.decrypt(row.chronicdiseases) : null,
                        row.notes ? this.decrypt(row.notes) : null
                    ]);

                return {
                    id: row.id,
                    name,
                    family_name,
                    age: parseInt(age),
                    genre: genre as 'homme' | 'femme',
                    telephone,
                    email,
                    adresse,
                    dateNaissance: dateNaissance ? new Date(dateNaissance) : null,
                    numeroSecuriteSociale,
                    medecinTraitant: row.medecin_traitant_id,
                    allergies,
                    consultations: row.consultations,
                    chronicDiseases,
                    notes,
                    nin,
                    emergencyContact,
                    emergencyPhone,
                    is_private: row.is_private ?? false,
                    assistant_id: row.assistant_id,
                    is_chart_readed: row.is_chart_readed ?? false,
                    created_at: row.created_at,
                    updated_at: row.updated_at
                };
            })
        );

        return patients;
    }
} 