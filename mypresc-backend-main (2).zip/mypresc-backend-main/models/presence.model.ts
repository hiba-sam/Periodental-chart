import pool from '../db';

export type PresenceStatus = 'online' | 'away' | 'offline';

export interface UserPresence {
  user_id: number;
  status: PresenceStatus;
  last_seen_at: Date | null;
  socket_id: string | null;
  updated_at: Date;
}

export class PresenceModel {
  /**
   * Update user presence status
   */
  static async updateStatus(
    userId: number,
    status: PresenceStatus,
    socketId?: string
  ): Promise<void> {
    await pool.query(
      `INSERT INTO user_presence (user_id, status, last_seen_at, socket_id, updated_at)
       VALUES ($1, $2, NOW(), $3, NOW())
       ON CONFLICT (user_id) 
       DO UPDATE SET 
         status = $2,
         last_seen_at = NOW(),
         socket_id = $3,
         updated_at = NOW()`,
      [userId, status, socketId || null]
    );
  }

  /**
   * Get user presence
   */
  static async getStatus(userId: number): Promise<UserPresence | null> {
    const result = await pool.query(
      'SELECT * FROM user_presence WHERE user_id = $1',
      [userId]
    );
    return result.rows[0] || null;
  }

  /**
   * Set user offline by socket ID
   */
  static async setOfflineBySocket(socketId: string): Promise<void> {
    await pool.query(
      `UPDATE user_presence 
       SET status = 'offline', last_seen_at = NOW(), socket_id = NULL, updated_at = NOW()
       WHERE socket_id = $1`,
      [socketId]
    );
  }

  /**
   * Get multiple users presence
   */
  static async getMultipleStatus(
    userIds: number[]
  ): Promise<Map<number, UserPresence>> {
    const result = await pool.query(
      'SELECT * FROM user_presence WHERE user_id = ANY($1)',
      [userIds]
    );

    const map = new Map<number, UserPresence>();
    result.rows.forEach((row) => {
      map.set(row.user_id, row);
    });
    return map;
  }

  /**
   * Clean up stale online statuses (users online > 5 minutes without heartbeat)
   */
  static async cleanupStalePresence(): Promise<void> {
    await pool.query(
      `UPDATE user_presence 
       SET status = 'offline', socket_id = NULL
       WHERE status = 'online' 
       AND updated_at < NOW() - INTERVAL '5 minutes'`
    );
  }
}
