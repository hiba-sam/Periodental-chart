import pool from '../db';

export interface MedicalShare {
    id: number;
    shared_by_doctor_id: number;
    patient_id: string;
    shared_with_doctor_id: number;
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    share_dental_acts: boolean;
    visible_until_date: Date | null;
    expires_at: Date;
    reason?: string;
    status: 'active' | 'revoked' | 'expired';
    share_token: string;
    created_at: Date;
    updated_at: Date;
}

export interface MedicalShareWithDetails extends MedicalShare {
    shared_by_doctor_name?: string;
    shared_by_doctor_family_name?: string;
    shared_with_doctor_name?: string;
    shared_with_doctor_family_name?: string;
    patient_name?: string;
    patient_family_name?: string;
}

export interface CreateMedicalShareData {
    shared_by_doctor_id: number;
    patient_id: string;
    shared_with_doctor_id: number;
    share_prescriptions?: boolean;
    share_medical_reports?: boolean;
    share_dental_acts?: boolean;
    visible_until_date?: Date | null;
    expires_at: Date;
    reason?: string;
}

export class MedicalShareModel {

    // Expirer les partages dont la date est passée
    static async expireOldShares(): Promise<void> {
        await pool.query(`
            UPDATE medical_shares 
            SET status = 'expired' 
            WHERE status = 'active' 
            AND expires_at < NOW()
        `);
    }

    // Créer un nouveau partage
    static async create(data: CreateMedicalShareData): Promise<MedicalShare> {
        // D'abord expirer les anciens partages
        await this.expireOldShares();

        const query = `
            INSERT INTO medical_shares (
                shared_by_doctor_id, patient_id, shared_with_doctor_id,
                share_prescriptions, share_medical_reports, share_dental_acts,
                visible_until_date, expires_at, reason
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            ON CONFLICT (shared_by_doctor_id, patient_id, shared_with_doctor_id)
            DO UPDATE SET
                share_prescriptions = EXCLUDED.share_prescriptions,
                share_medical_reports = EXCLUDED.share_medical_reports,
                share_dental_acts = EXCLUDED.share_dental_acts,
                visible_until_date = EXCLUDED.visible_until_date,
                expires_at = EXCLUDED.expires_at,
                reason = EXCLUDED.reason,
                status = 'active',
                updated_at = NOW()
            RETURNING *
        `;

        const result = await pool.query(query, [
            data.shared_by_doctor_id,
            data.patient_id,
            data.shared_with_doctor_id,
            data.share_prescriptions ?? true,
            data.share_medical_reports ?? true,
            data.share_dental_acts ?? true,
            data.visible_until_date || null,
            data.expires_at,
            data.reason || null
        ]);

        return result.rows[0];
    }

    // Trouver un partage par ID
    static async findById(id: number): Promise<MedicalShare | null> {
        await this.expireOldShares();
        const result = await pool.query('SELECT * FROM medical_shares WHERE id = $1', [id]);
        return result.rows[0] || null;
    }

    // Trouver tous les partages actifs pour un patient (partagés PAR un médecin)
    static async findByPatientAndDoctor(patientId: string, doctorId: number): Promise<MedicalShareWithDetails[]> {
        await this.expireOldShares();

        const query = `
            SELECT 
                ms.*,
                u1.name as shared_by_doctor_name,
                u1.family_name as shared_by_doctor_family_name,
                u2.name as shared_with_doctor_name,
                u2.family_name as shared_with_doctor_family_name
            FROM medical_shares ms
            JOIN users u1 ON ms.shared_by_doctor_id = u1.id
            JOIN users u2 ON ms.shared_with_doctor_id = u2.id
            WHERE ms.patient_id = $1 
            AND ms.shared_by_doctor_id = $2
            AND ms.status = 'active'
            ORDER BY ms.created_at DESC
        `;

        const result = await pool.query(query, [patientId, doctorId]);
        return result.rows;
    }

    // Trouver tous les partages actifs REÇUS par un médecin
    static async findSharedWithDoctor(doctorId: number): Promise<MedicalShareWithDetails[]> {
        await this.expireOldShares();

        const query = `
            SELECT 
                ms.*,
                u1.name as shared_by_doctor_name,
                u1.family_name as shared_by_doctor_family_name,
                pgp_sym_decrypt(p.name, $2) as patient_name,
                pgp_sym_decrypt(p.family_name, $2) as patient_family_name
            FROM medical_shares ms
            JOIN users u1 ON ms.shared_by_doctor_id = u1.id
            JOIN patients p ON ms.patient_id = p.id
            WHERE ms.shared_with_doctor_id = $1
            AND ms.status = 'active'
            ORDER BY ms.created_at DESC
        `;

        const result = await pool.query(query, [doctorId, process.env.ENCRYPTION_KEY]);
        return result.rows;
    }

    // Vérifier si un médecin a accès aux données d'un patient via un partage
    static async checkAccess(
        patientId: string,
        doctorId: number,
        dataType: 'prescription' | 'medical_report' | 'dental_act'
    ): Promise<{ hasAccess: boolean; visibleUntilDate: Date | null }> {
        await this.expireOldShares();

        const shareColumnMap = {
            'prescription': 'share_prescriptions',
            'medical_report': 'share_medical_reports',
            'dental_act': 'share_dental_acts'
        };
        const shareColumn = shareColumnMap[dataType];

        const query = `
            SELECT visible_until_date
            FROM medical_shares
            WHERE patient_id = $1
            AND shared_with_doctor_id = $2
            AND status = 'active'
            AND ${shareColumn} = true
            AND expires_at > NOW()
            LIMIT 1
        `;

        const result = await pool.query(query, [patientId, doctorId]);

        if (result.rows.length === 0) {
            return { hasAccess: false, visibleUntilDate: null };
        }

        return {
            hasAccess: true,
            visibleUntilDate: result.rows[0].visible_until_date
        };
    }

    // Révoquer un partage
    static async revoke(id: number, doctorId: number): Promise<boolean> {
        const query = `
            UPDATE medical_shares 
            SET status = 'revoked', updated_at = NOW()
            WHERE id = $1 AND shared_by_doctor_id = $2
            RETURNING id
        `;

        const result = await pool.query(query, [id, doctorId]);
        return result.rowCount !== null && result.rowCount > 0;
    }

    // Supprimer un partage
    static async delete(id: number, doctorId: number): Promise<boolean> {
        const query = `
            DELETE FROM medical_shares 
            WHERE id = $1 AND shared_by_doctor_id = $2
            RETURNING id
        `;

        const result = await pool.query(query, [id, doctorId]);
        return result.rowCount !== null && result.rowCount > 0;
    }

    // Trouver un partage par token (pour le lien unique)
    // Accessible par le destinataire ET l'expéditeur pour vérification
    static async findByToken(token: string, requestingDoctorId: number): Promise<MedicalShareWithDetails | null> {
        await this.expireOldShares();

        const query = `
            SELECT 
                ms.*,
                u1.name as shared_by_doctor_name,
                u1.family_name as shared_by_doctor_family_name,
                pgp_sym_decrypt(p.name, $3) as patient_name,
                pgp_sym_decrypt(p.family_name, $3) as patient_family_name
            FROM medical_shares ms
            JOIN users u1 ON ms.shared_by_doctor_id = u1.id
            JOIN patients p ON ms.patient_id = p.id
            WHERE ms.share_token = $1
            AND (ms.shared_with_doctor_id = $2 OR ms.shared_by_doctor_id = $2)
            AND ms.status = 'active'
            AND ms.expires_at > NOW()
        `;

        const result = await pool.query(query, [token, requestingDoctorId, process.env.ENCRYPTION_KEY]);
        return result.rows[0] || null;
    }

    // Trouver un partage par ID avec token (pour retourner le lien)
    static async findByIdWithToken(id: number): Promise<MedicalShare | null> {
        const result = await pool.query('SELECT * FROM medical_shares WHERE id = $1', [id]);
        return result.rows[0] || null;
    }
}
