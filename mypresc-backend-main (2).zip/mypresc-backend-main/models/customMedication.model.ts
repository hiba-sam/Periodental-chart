import pool from '../db';

export interface CustomMedication {
    id: number;
    nom_de_marque: string;
    denomination_commune_internationale?: string;
    dosage?: string;
    forme?: string;
    laboratoire?: string;
    added_by_doctor_id: number;
    status: 'pending' | 'approved' | 'rejected';
    approved_at?: Date;
    approved_by_admin_id?: number;
    created_at: Date;
    updated_at: Date;
}

export interface CreateCustomMedicationData {
    nom_de_marque: string;
    denomination_commune_internationale?: string;
    dosage?: string;
    forme?: string;
    laboratoire?: string;
    added_by_doctor_id: number;
}

export class CustomMedicationModel {
    /**
     * Create a new custom medication
     */
    static async create(data: CreateCustomMedicationData): Promise<CustomMedication> {
        const query = `
            INSERT INTO custom_medications (
                nom_de_marque,
                denomination_commune_internationale,
                dosage,
                forme,
                laboratoire,
                added_by_doctor_id,
                status
            ) VALUES ($1, $2, $3, $4, $5, $6, 'pending')
            RETURNING *
        `;

        const values = [
            data.nom_de_marque,
            data.denomination_commune_internationale || null,
            data.dosage || null,
            data.forme || null,
            data.laboratoire || null,
            data.added_by_doctor_id
        ];

        const { rows } = await pool.query<CustomMedication>(query, values);
        return rows[0];
    }

    /**
     * Find custom medication by ID
     */
    static async findById(id: number): Promise<CustomMedication | null> {
        const query = `SELECT * FROM custom_medications WHERE id = $1`;
        const { rows } = await pool.query<CustomMedication>(query, [id]);
        return rows[0] || null;
    }

    /**
     * Get all pending custom medications (for admin review)
     */
    static async findAllPending(): Promise<CustomMedication[]> {
        const query = `
            SELECT cm.*, u.name as doctor_name, u.family_name as doctor_family_name
            FROM custom_medications cm
            JOIN users u ON cm.added_by_doctor_id = u.id
            WHERE cm.status = 'pending'
            ORDER BY cm.created_at DESC
        `;
        const { rows } = await pool.query(query);
        return rows;
    }

    /**
     * Get custom medications by doctor
     */
    static async findByDoctor(doctorId: number): Promise<CustomMedication[]> {
        const query = `
            SELECT * FROM custom_medications 
            WHERE added_by_doctor_id = $1
            ORDER BY created_at DESC
        `;
        const { rows } = await pool.query<CustomMedication>(query, [doctorId]);
        return rows;
    }

    /**
     * Search custom medications by name (for prescription search)
     */
    static async search(searchTerm: string, limit: number = 10): Promise<CustomMedication[]> {
        const query = `
            SELECT * FROM custom_medications 
            WHERE (
                nom_de_marque ILIKE $1 
                OR denomination_commune_internationale ILIKE $1
            )
            ORDER BY nom_de_marque
            LIMIT $2
        `;
        const { rows } = await pool.query<CustomMedication>(query, [`%${searchTerm}%`, limit]);
        return rows;
    }

    /**
     * Update custom medication status (admin action)
     */
    static async updateStatus(
        id: number, 
        status: 'approved' | 'rejected', 
        adminId: number
    ): Promise<CustomMedication | null> {
        const query = `
            UPDATE custom_medications 
            SET status = $1, 
                approved_at = CURRENT_TIMESTAMP,
                approved_by_admin_id = $2,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $3
            RETURNING *
        `;
        const { rows } = await pool.query<CustomMedication>(query, [status, adminId, id]);
        return rows[0] || null;
    }

    /**
     * Check if a similar custom medication already exists
     */
    static async findSimilar(nom_de_marque: string): Promise<CustomMedication | null> {
        const query = `
            SELECT * FROM custom_medications 
            WHERE LOWER(nom_de_marque) = LOWER($1)
            LIMIT 1
        `;
        const { rows } = await pool.query<CustomMedication>(query, [nom_de_marque]);
        return rows[0] || null;
    }

    /**
     * Delete a custom medication
     */
    static async delete(id: number): Promise<boolean> {
        const query = `DELETE FROM custom_medications WHERE id = $1`;
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }
}
