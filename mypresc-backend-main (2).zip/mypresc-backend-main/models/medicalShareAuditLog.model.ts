import pool from '../db';

export interface MedicalShareAuditLog {
    id: number;
    doctor_user_id: number;
    doctor_name: string;
    doctor_family_name: string;
    doctor_email: string;
    patient_id: string;
    patient_name: string;
    shared_with_doctor_id: number;
    shared_with_doctor_name: string;
    shared_with_doctor_family_name: string;
    shared_with_doctor_email: string;
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date: Date | null;
    expires_at: Date;
    reason: string;
    patient_informed_confirmed: boolean;
    action_type: 'share_created' | 'share_revoked' | 'share_deleted' | 'share_expired';
    medical_share_id: number | null;
    ip_address: string | null;
    user_agent: string | null;
    created_at: Date;
}

export interface CreateAuditLogData {
    doctor_user_id: number;
    doctor_name: string;
    doctor_family_name: string;
    doctor_email: string;
    patient_id: string;
    patient_name: string;
    shared_with_doctor_id: number;
    shared_with_doctor_name: string;
    shared_with_doctor_family_name: string;
    shared_with_doctor_email: string;
    share_prescriptions: boolean;
    share_medical_reports: boolean;
    visible_until_date: Date | null;
    expires_at: Date;
    reason: string;
    patient_informed_confirmed: boolean;
    action_type: 'share_created' | 'share_revoked' | 'share_deleted' | 'share_expired';
    medical_share_id: number | null;
    ip_address?: string;
    user_agent?: string;
}

export class MedicalShareAuditLogModel {
    static async create(data: CreateAuditLogData): Promise<MedicalShareAuditLog> {
        const query = `
            INSERT INTO medical_share_audit_logs (
                doctor_user_id, doctor_name, doctor_family_name, doctor_email,
                patient_id, patient_name,
                shared_with_doctor_id, shared_with_doctor_name, shared_with_doctor_family_name, shared_with_doctor_email,
                share_prescriptions, share_medical_reports, visible_until_date, expires_at,
                reason, patient_informed_confirmed, action_type, medical_share_id,
                ip_address, user_agent
            ) VALUES (
                $1, $2, $3, $4,
                $5, $6,
                $7, $8, $9, $10,
                $11, $12, $13, $14,
                $15, $16, $17, $18,
                $19, $20
            )
            RETURNING *
        `;

        const values = [
            data.doctor_user_id,
            data.doctor_name,
            data.doctor_family_name,
            data.doctor_email,
            data.patient_id,
            data.patient_name,
            data.shared_with_doctor_id,
            data.shared_with_doctor_name,
            data.shared_with_doctor_family_name,
            data.shared_with_doctor_email,
            data.share_prescriptions,
            data.share_medical_reports,
            data.visible_until_date,
            data.expires_at,
            data.reason,
            data.patient_informed_confirmed,
            data.action_type,
            data.medical_share_id,
            data.ip_address || null,
            data.user_agent || null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    static async findByDoctorId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<MedicalShareAuditLog[]> {
        const query = `
            SELECT * FROM medical_share_audit_logs
            WHERE doctor_user_id = $1
            ORDER BY created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset]);
        return result.rows;
    }

    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<MedicalShareAuditLog[]> {
        const query = `
            SELECT * FROM medical_share_audit_logs
            WHERE patient_id = $1
            ORDER BY created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [patientId, limit, offset]);
        return result.rows;
    }

    static async findAll(limit: number = 100, offset: number = 0): Promise<MedicalShareAuditLog[]> {
        const query = `
            SELECT * FROM medical_share_audit_logs
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }
}
