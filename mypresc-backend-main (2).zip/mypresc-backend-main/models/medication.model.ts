import pool from '../db';

export interface Medication {
    id: number;
    num_enregistrement: string | null;
    code: string | null;
    denomination_commune_internationale: string | null;
    nom_de_marque: string | null;
    forme: string | null;
    dosage: string | null;
    cond: string | null;
    liste: string | null;
    p1: string | null;
    p2: string | null;
    obs: string | null;
    laboratoire: string | null;
    pays_laboratoire: string | null;
    date_enregistrement_initial: Date | null;
    date_enregistrement_final: Date | null;
    type: string | null;
    statut: string | null;
    duree_stabilite: string | null;
    prix: string | null;
    remboursement: string | null;
    created_at: Date;
    updated_at: Date;
}

export class MedicationModel {
    // Find medication by ID
    static async findById(id: number): Promise<Medication | null> {
        const query = 'SELECT * FROM medications WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }
    // Search medications by name, code, or laboratory
    static async search(searchTerm: string, limit: number = 50): Promise<Medication[]> {
        const terms = searchTerm.trim().split(/\s+/);
    
        // Each word must match at least one field (AND between words)
        const conditions = terms.map((_, i) => `(
            nom_de_marque ILIKE $${i+1}
            OR denomination_commune_internationale ILIKE $${i+1}
            OR code ILIKE $${i+1}
            OR laboratoire ILIKE $${i+1}
            OR dosage ILIKE $${i+1}
            OR forme ILIKE $${i+1}
        )`).join(" AND ");
    
        const query = `
            SELECT *
            FROM medications
            WHERE ${conditions}
            ORDER BY nom_de_marque ASC
            LIMIT $${terms.length+1}
        `;
    
        const values = terms.map(t => `${t}%`);
        values.push(limit.toString());
    
        const result = await pool.query(query, values);
        return result.rows;
    }
    // Get all medications with pagination
    static async findAll(limit: number = 50, offset: number = 0): Promise<Medication[]> {
        const query = `
            SELECT * FROM medications 
            ORDER BY nom_de_marque ASC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }
} 