import pool from '../db';
import type { Patient } from './patient.model';
import type { User } from './user.model';

export interface PrescriptionHistory {
    id: number;
    prescription_id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
    created_at: Date;
}

export interface PrescriptionHistoryWithDetails extends PrescriptionHistory {
    patient: Patient;
    doctor: User;
}

export interface CreatePrescriptionHistoryData {
    prescription_id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
}

export class PrescriptionHistoryModel {
    // Create a new history record
    static async create(data: CreatePrescriptionHistoryData): Promise<PrescriptionHistory> {
        const query = `
            INSERT INTO prescription_history (
                prescription_id, patient_id, doctor_user_id
            ) VALUES ($1, $2, $3)
            RETURNING *
        `;
        
        const values = [
            data.prescription_id,
            data.patient_id,
            data.doctor_user_id
        ];
        
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Get history for a specific patient
    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<PrescriptionHistory[]> {
        const query = `
            SELECT * FROM prescription_history 
            WHERE patient_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [patientId, limit, offset]);
        return result.rows;
    }

    // Get history for a specific doctor
    static async findByDoctorId(doctorId: number, limit: number = 50, offset: number = 0): Promise<PrescriptionHistory[]> {
        const query = `
            SELECT * FROM prescription_history 
            WHERE doctor_user_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorId, limit, offset]);
        return result.rows;
    }

    // Get all history with pagination
    static async findAll(limit: number = 50, offset: number = 0): Promise<PrescriptionHistory[]> {
        const query = `
            SELECT * FROM prescription_history 
            ORDER BY created_at DESC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Get history within date range
    static async findByDateRange(startDate: Date, endDate: Date, limit: number = 50, offset: number = 0): Promise<PrescriptionHistory[]> {
        const query = `
            SELECT * FROM prescription_history 
            WHERE created_at BETWEEN $1 AND $2 
            ORDER BY created_at DESC 
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [startDate, endDate, limit, offset]);
        return result.rows;
    }

    // Delete history records (for cleanup)
    static async deleteByPrescriptionId(prescriptionId: number): Promise<boolean> {
        const query = 'DELETE FROM prescription_history WHERE prescription_id = $1';
        const result = await pool.query(query, [prescriptionId]);
        return (result.rowCount ?? 0) > 0;
    }
} 