import pool from '../db';

// Helper function to parse PostgreSQL array strings like {"path1","path2"} into JS arrays
function parsePostgresArray(value: any): string[] {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    if (typeof value === 'string') {
        // Handle PostgreSQL array format: {"value1","value2"}
        if (value.startsWith('{') && value.endsWith('}')) {
            const inner = value.slice(1, -1);
            if (!inner) return [];
            // Split by comma, but handle quoted strings
            return inner.split(',').map(s => s.replace(/^"|"$/g, '').trim());
        }
        return [value];
    }
    return [];
}

export interface Doctor {
    user_id: number;
    birth_date: Date;
    birth_place: string;
    work_location: string;
    home_location: string;
    diploma_file: string[];
    certificates: string[] | null;
    order_num: string;
    order_num_file: string;
    id_card_file: string;
    phone_number: string;
    work_time: Record<string, unknown> | null;
    languages: string[] | null;
    about: string | null;
    speciality: string | null;
    experience: number | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreateDoctorData {
    user_id: number;
    birth_date: string | Date;
    birth_place: string;
    work_location: string;
    home_location: string;
    diploma_file: string[];
    certificates?: string[];
    order_num: string;
    order_num_file: string;
    id_card_file: string;
    phone_number: string;
    work_time?: Record<string, unknown>;
    languages?: string[];
    about?: string;
    speciality?: string;
    experience?: number;
    nin?: string;
}

export interface UpdateDoctorData {
    birth_date?: string | Date;
    birth_place?: string;
    work_location?: string;
    home_location?: string;
    diploma_file?: string[];
    certificates?: string[] | null;
    order_num?: string;
    order_num_file?: string;
    id_card_file?: string;
    phone_number?: string;
    work_time?: Record<string, unknown> | null;
    languages?: string[] | null;
    about?: string | null;
    speciality?: string | null;
    experience?: number | null;
    nin?: string | null;
}

export class DoctorModel {
    // Create a new doctor profile
    static async create(doctorData: CreateDoctorData): Promise<Doctor> {
        const query = `
            INSERT INTO doctors (
                user_id, birth_date, birth_place, work_location,
                home_location, diploma_file, certificates, order_num,
                order_num_file, id_card_file, phone_number, work_time,
                languages, about, speciality, experience, nin
            ) VALUES (
                $1, $2, $3, $4,
                $5, $6, $7, $8,
                $9, $10, $11, $12,
                $13, $14, $15, $16,
                $17
            )
            RETURNING *
        `;

        const values = [
            doctorData.user_id,
            doctorData.birth_date,
            doctorData.birth_place,
            doctorData.work_location,
            doctorData.home_location,
            doctorData.diploma_file, // array
            doctorData.certificates ?? null,
            doctorData.order_num,
            doctorData.order_num_file,
            doctorData.id_card_file,
            doctorData.phone_number,
            doctorData.work_time ?? null,
            doctorData.languages ?? null,
            doctorData.about ?? null,
            doctorData.speciality ?? null,
            doctorData.experience ?? null,
            doctorData.nin ?? null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find doctor by user_id
    static async findByUserId(userId: number): Promise<Doctor | null> {
        const query = 'SELECT * FROM doctors WHERE user_id = $1';
        const result = await pool.query(query, [userId]);
        const doctor = result.rows[0];
        if (doctor) {
            // Parse PostgreSQL arrays to JS arrays
            doctor.diploma_file = parsePostgresArray(doctor.diploma_file);
            doctor.certificates = parsePostgresArray(doctor.certificates);
            doctor.languages = parsePostgresArray(doctor.languages);
        }
        return doctor || null;
    }

    // Update doctor profile
    static async update(userId: number, doctorData: UpdateDoctorData): Promise<Doctor | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (doctorData.birth_date !== undefined) {
            fields.push(`birth_date = $${idx++}`);
            values.push(doctorData.birth_date);
        }
        if (doctorData.birth_place !== undefined) {
            fields.push(`birth_place = $${idx++}`);
            values.push(doctorData.birth_place);
        }
        if (doctorData.work_location !== undefined) {
            fields.push(`work_location = $${idx++}`);
            values.push(doctorData.work_location);
        }
        if (doctorData.home_location !== undefined) {
            fields.push(`home_location = $${idx++}`);
            values.push(doctorData.home_location);
        }
        if (doctorData.diploma_file !== undefined) {
            fields.push(`diploma_file = $${idx++}`);
            values.push(doctorData.diploma_file);
        }
        if (doctorData.certificates !== undefined) {
            fields.push(`certificates = $${idx++}`);
            values.push(doctorData.certificates);
        }
        if (doctorData.order_num !== undefined) {
            fields.push(`order_num = $${idx++}`);
            values.push(doctorData.order_num);
        }
        if (doctorData.order_num_file !== undefined) {
            fields.push(`order_num_file = $${idx++}`);
            values.push(doctorData.order_num_file);
        }
        if (doctorData.id_card_file !== undefined) {
            fields.push(`id_card_file = $${idx++}`);
            values.push(doctorData.id_card_file);
        }
        if (doctorData.phone_number !== undefined) {
            fields.push(`phone_number = $${idx++}`);
            values.push(doctorData.phone_number);
        }
        if (doctorData.work_time !== undefined) {
            fields.push(`work_time = $${idx++}`);
            values.push(doctorData.work_time);
        }
        if (doctorData.languages !== undefined) {
            fields.push(`languages = $${idx++}`);
            values.push(doctorData.languages);
        }
        if (doctorData.about !== undefined) {
            fields.push(`about = $${idx++}`);
            values.push(doctorData.about);
        }
        if (doctorData.speciality !== undefined) {
            fields.push(`speciality = $${idx++}`);
            values.push(doctorData.speciality);
        }
        if (doctorData.experience !== undefined) {
            fields.push(`experience = $${idx++}`);
            values.push(doctorData.experience);
        }
        if (doctorData.nin !== undefined) {
            fields.push(`nin = $${idx++}`);
            values.push(doctorData.nin);
        }

        if (fields.length === 0) {
            return await this.findByUserId(userId);
        }

        values.push(userId);
        const query = `UPDATE doctors SET ${fields.join(', ')} WHERE user_id = $${idx} RETURNING *`;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Delete doctor profile
    static async delete(userId: number): Promise<boolean> {
        const query = 'DELETE FROM doctors WHERE user_id = $1';
        const result = await pool.query(query, [userId]);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all doctors
    static async findAll(limit: number = 50, offset: number = 0): Promise<Doctor[]> {
        const query = `
            SELECT * FROM doctors 
            ORDER BY created_at DESC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Search doctors by key fields
    static async search(searchTerm: string, limit: number = 50): Promise<Doctor[]> {
        const pattern = `%${searchTerm}%`;
        const query = `
            SELECT * FROM doctors 
            WHERE order_num ILIKE $1
               OR phone_number ILIKE $1
               OR $2 = ANY(languages)
               OR EXISTS (
                    SELECT 1 FROM unnest(certificates) AS c WHERE c ILIKE $1
               )
            ORDER BY created_at DESC 
            LIMIT $3
        `;
        const result = await pool.query(query, [pattern, searchTerm, limit]);
        return result.rows;
    }

    // Find doctor by NIN
    static async findByNin(nin: string): Promise<Doctor | null> {
        const query = 'SELECT * FROM doctors WHERE nin = $1';
        const result = await pool.query(query, [nin]);
        return result.rows[0] || null;
    }

    // Find doctor by Order Number
    static async findByOrderNum(orderNum: string): Promise<Doctor | null> {
        const query = 'SELECT * FROM doctors WHERE order_num = $1';
        const result = await pool.query(query, [orderNum]);
        return result.rows[0] || null;
    }

    // Rechercher des médecins pour le partage de dossier
    static async searchForShare(searchTerm: string, excludeUserId: number, limit: number = 20): Promise<any[]> {
        const pattern = `%${searchTerm}%`;
        const query = `
            SELECT 
                u.id,
                u.name,
                u.family_name,
                u.email,
                d.speciality,
                d.phone_number,
                d.work_location
            FROM users u
            JOIN doctors d ON u.id = d.user_id
            WHERE u.role = 'doctor'
            AND u.id != $1
            AND (
                u.name ILIKE $2
                OR u.family_name ILIKE $2
                OR u.email ILIKE $2
                OR d.speciality ILIKE $2
            )
            ORDER BY u.family_name, u.name
            LIMIT $3
        `;
        const result = await pool.query(query, [excludeUserId, pattern, limit]);
        return result.rows;
    }
}