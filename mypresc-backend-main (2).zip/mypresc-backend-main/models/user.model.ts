import pool from '../db';
import bcrypt from 'bcrypt';

export interface User {
    id: number;
    name: string;
    family_name: string;
    email: string;
    password: string;
    is_active: boolean;
    role: string;
    language: string;
    plan: string;
    end_date: Date | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreateUserData {
    name: string;
    family_name: string;
    email: string;
    password: string;
    role: string;
    language?: string;
}

export interface UpdateUserData {
    name?: string;
    family_name?: string;
    email?: string;
    password?: string;
    is_active?: boolean;
    role?: string;
    language?: string;
    plan?: string;
    end_date?: Date | null;
}

export class UserModel {
    // Create a new user
    static async create(userData: CreateUserData): Promise<User> {
        const query = `
            INSERT INTO users (
                name, family_name, email, password, role, language
            ) VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `;

        const values = [
            userData.name,
            userData.family_name,
            userData.email,
            userData.password,
            userData.role,
            userData.language || 'fr'
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find user by email
    static async findByEmail(email: string): Promise<User | null> {
        const query = 'SELECT * FROM users WHERE email = $1';
        const result = await pool.query(query, [email]);
        return result.rows[0] || null;
    }

    // Find user by ID
    static async findById(id: number): Promise<User | null> {
        const query = 'SELECT * FROM users WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Update user
    static async update(id: number, userData: UpdateUserData): Promise<User | null> {
        const fields = [];
        const values = [];
        let paramCount = 1;

        if (userData.name !== undefined) {
            fields.push(`name = $${paramCount++}`);
            values.push(userData.name);
        }
        if (userData.family_name !== undefined) {
            fields.push(`family_name = $${paramCount++}`);
            values.push(userData.family_name);
        }
        if (userData.email !== undefined) {
            fields.push(`email = $${paramCount++}`);
            values.push(userData.email);
        }
        if (userData.password !== undefined) {
            fields.push(`password = $${paramCount++}`);
            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(userData.password, saltRounds);
            values.push(hashedPassword);
        }
        if (userData.is_active !== undefined) {
            fields.push(`is_active = $${paramCount++}`);
            values.push(userData.is_active);
        }
        if (userData.role !== undefined) {
            fields.push(`role = $${paramCount++}`);
            values.push(userData.role);
        }
        if (userData.language !== undefined) {
            fields.push(`language = $${paramCount++}`);
            values.push(userData.language);
        }
        if (userData.plan !== undefined) {
            fields.push(`plan = $${paramCount++}`);
            values.push(userData.plan);
        }
        if (userData.end_date !== undefined) {
            fields.push(`end_date = $${paramCount++}`);
            values.push(userData.end_date);
        }

        if (fields.length === 0) {
            return null;
        }

        values.push(id);
        const query = `UPDATE users SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Delete user (hard delete from database)
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM users WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all active users
    static async findAll(limit: number = 50, offset: number = 0): Promise<User[]> {
        const query = `
            SELECT * FROM users 
            WHERE is_active = true 
            ORDER BY created_at DESC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Get all inactive users (pending registrations)
    static async getInactive(limit: number = 50, offset: number = 0): Promise<User[]> {
        const query = `
            SELECT * FROM users 
            WHERE is_active = false 
            ORDER BY created_at DESC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Search users by name or email
    static async search(searchTerm: string, limit: number = 50): Promise<User[]> {
        const query = `
            SELECT * FROM users 
            WHERE is_active = true 
            AND (name ILIKE $1 OR family_name ILIKE $1 OR email ILIKE $1)
            ORDER BY created_at DESC 
            LIMIT $2
        `;
        const result = await pool.query(query, [`%${searchTerm}%`, limit]);
        return result.rows;
    }

    // Find users by role
    static async findByRole(role: string, limit: number = 50, offset: number = 0): Promise<User[]> {
        const query = `
            SELECT * FROM users 
            WHERE role = $1 AND is_active = true 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [role, limit, offset]);
        return result.rows;
    }
}
