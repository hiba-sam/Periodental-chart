import pool from '../db';
import { PatientModel, type Patient } from './patient.model';
import type { User } from './user.model';
import type { PrescriptionMedication, PrescriptionMedicationWithDetails } from './prescriptionMedication.model';
import { PrescriptionMedicationModel } from './prescriptionMedication.model';
import type { isReturnStatement } from 'typescript';

export interface Prescription {
    id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
    confirmed_count: number;
    remarks: string | null;
    created_at: Date;
    updated_at: Date;
}

export interface PrescriptionWithDetails extends Prescription {
    patient: Patient | null;
    doctor: User;
    medications: PrescriptionMedicationWithDetails[];
}

export interface CreatePrescriptionData {
    patient_id: string; // UUID
    doctor_user_id: number;
    confirmed_count?: number;
    remarks?: string;
    medication_ids: number[]; // Array of prescription_medication IDs
}

export interface UpdatePrescriptionData {
    patient_id?: string; // UUID
    doctor_user_id?: number;
    confirmed_count?: number;
    remarks?: string;
    medication_ids?: number[]; // Array of prescription_medication IDs
}

export interface AddMedicationToPrescriptionData {
    medication_id: number;
    quantity: number;
    dosage: string;
    note: string
}

export class PrescriptionModel {
    // Create a new prescription
    static async create(data: CreatePrescriptionData): Promise<Prescription> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            // Create the prescription
            const prescriptionQuery = `
                INSERT INTO prescriptions (
                    patient_id, doctor_user_id, confirmed_count, remarks
                ) VALUES ($1, $2, $3, $4)
                RETURNING *
            `;

            const prescriptionValues = [
                data.patient_id,
                data.doctor_user_id,
                data.confirmed_count || 1,
                data.remarks || null
            ];

            const prescriptionResult = await client.query(prescriptionQuery, prescriptionValues);
            const prescription = prescriptionResult.rows[0];

            // Link prescription medications if provided
            if (data.medication_ids && data.medication_ids.length > 0) {
                for (const medicationId of data.medication_ids) {
                    await client.query(`
                        INSERT INTO prescription_medication_items (prescription_id, prescription_medication_id)
                        VALUES ($1, $2)
                    `, [prescription.id, medicationId]);
                }
            }

            await client.query('COMMIT');
            return prescription;

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    // Find prescription by ID
    static async findById(id: number): Promise<Prescription | null> {
        const query = 'SELECT * FROM prescriptions WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find prescription by ID with full details
    static async findByIdWithDetails(id: number): Promise<PrescriptionWithDetails | null> {
        const prescriptionQuery = `
        SELECT p.*, u.id as doctor_id, u.name as doctor_name, u.family_name as doctor_family_name,
               u.email as doctor_email, u.password, u.is_active, u.role,
               u.created_at as doctor_created_at, u.updated_at as doctor_updated_at
        FROM prescriptions p
        JOIN users u ON p.doctor_user_id = u.id
        WHERE p.id = $1
      `;

        const prescriptionResult = await pool.query(prescriptionQuery, [id]);

        if (prescriptionResult.rows.length === 0) return null;

        const row = prescriptionResult.rows[0];

        // Get prescription medications
        const medicationsQuery = `
            SELECT pmi.prescription_medication_id
            FROM prescription_medication_items pmi
            WHERE pmi.prescription_id = $1
        `;

        const medicationsResult = await pool.query(medicationsQuery, [id]);
        const medications: PrescriptionMedicationWithDetails[] = [];

        for (const medRow of medicationsResult.rows) {
            const medication = await PrescriptionMedicationModel.findByIdWithDetails(medRow.prescription_medication_id);
            if (medication) {
                medications.push(medication);
            }
        }

        const patient = await PatientModel.findById(row.patient_id);


        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            confirmed_count: row.confirmed_count,
            remarks: row.remarks,
            created_at: row.created_at,
            updated_at: row.updated_at,
            patient,
            doctor: {
                id: row.doctor_id,
                name: row.doctor_name,
                family_name: row.doctor_family_name,
                email: row.doctor_email,
                password: row.password,
                is_active: row.is_active,
                role: row.role,
                created_at: row.doctor_created_at,
                updated_at: row.doctor_updated_at
            },
            medications
        };
    }

    // Update prescription
    static async update(id: number, data: UpdatePrescriptionData): Promise<Prescription | null> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            // Update prescription fields
            const fields = [];
            const values = [];
            let paramCount = 1;

            if (data.patient_id !== undefined) {
                fields.push(`patient_id = $${paramCount++}`);
                values.push(data.patient_id);
            }
            if (data.doctor_user_id !== undefined) {
                fields.push(`doctor_user_id = $${paramCount++}`);
                values.push(data.doctor_user_id);
            }
            if (data.confirmed_count !== undefined) {
                fields.push(`confirmed_count = $${paramCount++}`);
                values.push(data.confirmed_count);
            }
            if (data.remarks !== undefined) {
                fields.push(`remarks = $${paramCount++}`);
                values.push(data.remarks);
            }

            if (fields.length > 0) {
                values.push(id);
                const query = `UPDATE prescriptions SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`;
                await client.query(query, values);
            }

            // Update medication relationships if provided
            if (data.medication_ids !== undefined) {
                // Remove existing medication relationships
                await client.query('DELETE FROM prescription_medication_items WHERE prescription_id = $1', [id]);

                // Add new medication relationships
                for (const medicationId of data.medication_ids) {
                    await client.query(`
                        INSERT INTO prescription_medication_items (prescription_id, prescription_medication_id)
                        VALUES ($1, $2)
                    `, [id, medicationId]);
                }
            }

            await client.query('COMMIT');
            return await this.findById(id);

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    // Delete prescription
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM prescriptions WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Add medication to prescription
    static async addMedication(prescriptionId: number, medicationData: AddMedicationToPrescriptionData): Promise<boolean> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            // Create prescription medication
            const prescriptionMedication = await PrescriptionMedicationModel.create({
                medication_id: medicationData.medication_id,
                quantity: medicationData.quantity,
                dosage: medicationData.dosage,
                note: medicationData.note
            });

            // Link to prescription
            await client.query(`
                INSERT INTO prescription_medication_items (prescription_id, prescription_medication_id)
                VALUES ($1, $2)
            `, [prescriptionId, prescriptionMedication.id]);

            await client.query('COMMIT');
            return true;

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    // Remove medication from prescription
    static async removeMedication(prescriptionId: number, prescriptionMedicationId: number): Promise<boolean> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            // Remove from junction table
            await client.query(`
                DELETE FROM prescription_medication_items 
                WHERE prescription_id = $1 AND prescription_medication_id = $2
            `, [prescriptionId, prescriptionMedicationId]);

            // Delete the prescription medication if it's not used elsewhere
            const usageCheck = await client.query(`
                SELECT COUNT(*) as count FROM prescription_medication_items 
                WHERE prescription_medication_id = $1
            `, [prescriptionMedicationId]);

            if (parseInt(usageCheck.rows[0].count) === 0) {
                await PrescriptionMedicationModel.delete(prescriptionMedicationId);
            }

            await client.query('COMMIT');
            return true;

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    // Find prescriptions by patient ID
    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<PrescriptionWithDetails[]> {
        const query = `
            SELECT * FROM prescriptions 
            WHERE patient_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;

        const result = await pool.query(query, [patientId, limit, offset]);
        // Get prescription medications
        const medicationsQuery = `
                SELECT pmi.prescription_medication_id
                FROM prescription_medication_items pmi
                WHERE pmi.prescription_id = $1
            `;

        let returnResult: PrescriptionWithDetails[] = [];
        for (const row of result.rows) {
            const medicationsResult = await pool.query(medicationsQuery, [row.id]);
            const medications: PrescriptionMedicationWithDetails[] = [];

            for (const med of medicationsResult.rows) {
                const medication = await PrescriptionMedicationModel.findByIdWithDetails(med.prescription_medication_id);
                if (medication) {
                    medications.push(medication);
                }
            }

            returnResult.push({
                ...row,
                medications
            });
        }

        return returnResult;
    }

    // Find prescriptions by patient ID AND doctor ID (for private patients)
    static async findByPatientIdAndDoctor(patientId: string, doctorId: number, limit: number = 50, offset: number = 0): Promise<PrescriptionWithDetails[]> {
        const query = `
            SELECT * FROM prescriptions 
            WHERE patient_id = $1 AND doctor_user_id = $2
            ORDER BY created_at DESC 
            LIMIT $3 OFFSET $4
        `;

        const result = await pool.query(query, [patientId, doctorId, limit, offset]);
        
        const medicationsQuery = `
            SELECT pmi.prescription_medication_id
            FROM prescription_medication_items pmi
            WHERE pmi.prescription_id = $1
        `;

        let returnResult: PrescriptionWithDetails[] = [];
        for (const row of result.rows) {
            const medicationsResult = await pool.query(medicationsQuery, [row.id]);
            const medications: PrescriptionMedicationWithDetails[] = [];

            for (const med of medicationsResult.rows) {
                const medication = await PrescriptionMedicationModel.findByIdWithDetails(med.prescription_medication_id);
                if (medication) {
                    medications.push(medication);
                }
            }

            returnResult.push({
                ...row,
                medications
            });
        }

        return returnResult;
    }

    // Find prescriptions by doctor ID
    static async findByDoctorId(doctorId: number, limit: number = 50, offset: number = 0): Promise<Prescription[]> {
        const query = `
            SELECT * FROM prescriptions 
            WHERE doctor_user_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorId, limit, offset]);
        return result.rows;
    }


    // Get all prescriptions with pagination
    static async findAll(limit: number = 50, offset: number = 0): Promise<Prescription[]> {
        const query = `
            SELECT * FROM prescriptions 
            ORDER BY created_at DESC 
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Find prescriptions by doctor ID and patient IDs
    static async findByDoctorIdAndPatientIds(doctorId: number, patientIds: string[]): Promise<Prescription[]> {
        if (patientIds.length === 0) return [];

        const query = `
            SELECT * FROM prescriptions 
            WHERE doctor_user_id = $1 AND patient_id = ANY($2)
            ORDER BY created_at DESC 
        `;
        const result = await pool.query(query, [doctorId, patientIds]);
        return result.rows;
    }

} 