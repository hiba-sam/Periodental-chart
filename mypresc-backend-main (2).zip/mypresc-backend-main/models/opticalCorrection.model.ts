import pool from '../db';
import { PatientModel, type Patient } from './patient.model';
import type { User } from './user.model';

export interface OpticalCorrection {
    id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
    od_sph: string | null;
    od_cyl: string | null;
    od_axis: string | null;
    od_add: string | null;
    od_pd: string | null;
    os_sph: string | null;
    os_cyl: string | null;
    os_axis: string | null;
    os_add: string | null;
    os_pd: string | null;
    remarks: string | null;
    created_at: Date;
    updated_at: Date;
}

export interface OpticalCorrectionWithDetails extends OpticalCorrection {
    patient: Patient | null;
    doctor: User;
}

export interface CreateOpticalCorrectionData {
    patient_id: string;
    doctor_user_id: number;
    od_sph?: string;
    od_cyl?: string;
    od_axis?: string;
    od_add?: string;
    od_pd?: string;
    os_sph?: string;
    os_cyl?: string;
    os_axis?: string;
    os_add?: string;
    os_pd?: string;
    remarks?: string;
}

export class OpticalCorrectionModel {
    // Create a new optical correction
    static async create(data: CreateOpticalCorrectionData): Promise<OpticalCorrection> {
        const query = `
            INSERT INTO optical_corrections (
                patient_id, doctor_user_id, 
                od_sph, od_cyl, od_axis, od_add, od_pd,
                os_sph, os_cyl, os_axis, os_add, os_pd,
                remarks
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            RETURNING *
        `;

        const values = [
            data.patient_id,
            data.doctor_user_id,
            data.od_sph || null,
            data.od_cyl || null,
            data.od_axis || null,
            data.od_add || null,
            data.od_pd || null,
            data.os_sph || null,
            data.os_cyl || null,
            data.os_axis || null,
            data.os_add || null,
            data.os_pd || null,
            data.remarks || null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find optical correction by ID
    static async findById(id: number): Promise<OpticalCorrection | null> {
        const query = 'SELECT * FROM optical_corrections WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find optical correction by ID with full details (patient & doctor)
    static async findByIdWithDetails(id: number): Promise<OpticalCorrectionWithDetails | null> {
        const query = `
            SELECT oc.*, 
                   u.id as doctor_id, u.name as doctor_name, u.family_name as doctor_family_name,
                   u.email as doctor_email, u.is_active, u.role,
                   u.created_at as doctor_created_at, u.updated_at as doctor_updated_at
            FROM optical_corrections oc
            JOIN users u ON oc.doctor_user_id = u.id
            WHERE oc.id = $1
        `;

        const result = await pool.query(query, [id]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];
        const patient = await PatientModel.findById(row.patient_id);

        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            od_sph: row.od_sph,
            od_cyl: row.od_cyl,
            od_axis: row.od_axis,
            od_add: row.od_add,
            od_pd: row.od_pd,
            os_sph: row.os_sph,
            os_cyl: row.os_cyl,
            os_axis: row.os_axis,
            os_add: row.os_add,
            os_pd: row.os_pd,
            remarks: row.remarks,
            created_at: row.created_at,
            updated_at: row.updated_at,
            patient,
            doctor: {
                id: row.doctor_id,
                name: row.doctor_name,
                family_name: row.doctor_family_name,
                email: row.doctor_email,
                is_active: row.is_active,
                role: row.role,
                created_at: row.doctor_created_at,
                updated_at: row.doctor_updated_at
            }
        };
    }

    // Find optical corrections by patient ID (handling privacy logic if needed)
    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<OpticalCorrection[]> {
        const query = `
            SELECT * FROM optical_corrections 
            WHERE patient_id = $1 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [patientId, limit, offset]);
        return result.rows;
    }

    // Delete optical correction
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM optical_corrections WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }
}
