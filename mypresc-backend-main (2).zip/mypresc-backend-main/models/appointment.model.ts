import pool from '../db';

export interface Appointment {
    id: string;
    patient_id: string;
    doctor_user_id: number;
    date: Date;
    time: string;
    duration: number;
    notes?: string | null;
    color: string; // Added color field
    created_at: Date;
    updated_at: Date;
    is_done: boolean;
    confirmed_coming: boolean;
    venue_confirmed: boolean;
    arrived_at: Date | null;
    served_at: Date | null;
    patient_name: string;
    patient_family_name: string;
}

export interface CreateAppointmentData {
    patient_id: string;
    doctor_user_id: number;
    date: Date;
    time: string;
    duration?: number; // default 30 if not provided
    notes?: string;
    color?: string; // default '#2563eb' if not provided
    confirmed_coming?: boolean; // default false if not provided
    is_done?: boolean; // default false if not provided
    venue_confirmed?: boolean; // default false if not provided
    arrived_at?: Date; // when patient actually arrived
}

export interface UpdateAppointmentData {
    patient_id?: string | null;
    doctor_user_id?: number;
    date?: Date;
    time?: string;
    duration?: number;
    notes?: string | null;
    color?: string; // Added color field for updates
    confirmed_coming?: boolean;
    is_done?: boolean;
    venue_confirmed?: boolean;
    arrived_at?: Date | null;
    served_at?: Date | null;
}

export class AppointmentModel {
    private static readonly ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

    // Helper method to decrypt data
    private static async decrypt(encryptedData: Buffer): Promise<string> {
        const result = await pool.query('SELECT pgp_sym_decrypt($1, $2) as decrypted', [encryptedData, this.ENCRYPTION_KEY]);
        return result.rows[0].decrypted;
    }

    // ⚡ OPTIMIZED: Map row directly (decryption already done in SQL)
    private static mapRow(row: any): Appointment {
        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            date: row.date,
            time: row.time,
            duration: row.duration,
            notes: row.notes,
            color: row.color || '#2563eb',
            created_at: row.created_at,
            updated_at: row.updated_at,
            is_done: row.is_done,
            confirmed_coming: row.confirmed_coming,
            venue_confirmed: row.venue_confirmed,
            arrived_at: row.arrived_at,
            served_at: row.served_at,
            patient_name: row.patient_name,
            patient_family_name: row.patient_family_name
        };
    }

    // Utility: check if a doctor has any appointment overlapping a given time range
    // Overlap logic: (start_time < endTime AND (start_time + duration) > startTime)
    static async existsInRange(doctorUserId: number, date: Date, startTime: string, endTime: string): Promise<boolean> {
        const query = `
            SELECT 1
            FROM appointments
            WHERE doctor_user_id = $1 AND date = $2
              AND (
                time < $4::time AND (time + make_interval(mins => duration)) > $3::time
              )
            LIMIT 1
        `;
        const result = await pool.query(query, [doctorUserId, date, startTime, endTime]);
        return result.rows.length > 0;
    }

    // ⚡ OPTIMIZED: Find all appointments overlapping a given range for a doctor on a date
    static async findInRange(doctorUserId: number, date: Date, startTime: string, endTime: string): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.doctor_user_id = $1 AND a.date = $2
              AND (
                a.time < $4::time AND (a.time + make_interval(mins => a.duration)) > $3::time
              )
            ORDER BY a.time ASC
        `;
        const result = await pool.query(query, [doctorUserId, date, startTime, endTime, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // Find next available slot on the same date starting from startFromTime for given duration
    static async findNextAvailableSlot(doctorUserId: number, date: Date, durationMinutes: number, startFromTime: string): Promise<{ date: Date; time: string } | null> {
        const toTimeString = (d: Date) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;

        const startCursor = new Date(date);
        const [hh, mm, ss] = (startFromTime || '00:00:00').split(':').map((v) => parseInt(v || '0', 10));
        startCursor.setHours(hh!, mm, ss || 0, 0);

        // Search up to 12 hours forward on the same day in 5-minute increments
        const maxEnd = new Date(date);
        maxEnd.setHours(23, 59, 59, 0);
        const stepMinutes = 5;

        for (let cursor = new Date(startCursor); cursor <= maxEnd; cursor = new Date(cursor.getTime() + stepMinutes * 60000)) {
            const candidateStart = new Date(cursor);
            const candidateEnd = new Date(candidateStart.getTime() + durationMinutes * 60000);
            if (candidateEnd > maxEnd) break;

            const startStr = toTimeString(candidateStart);
            const endStr = toTimeString(candidateEnd);

            const hasApptOverlap = await this.existsInRange(doctorUserId, date, startStr, endStr);
            // Also ensure no calendar events overlap this candidate window
            const calendarOverlapQuery = `
                SELECT 1
                FROM calendar
                WHERE doctor_user_id = $1 AND date = $2
                  AND (time < $4::time AND (time + make_interval(mins => duration)) > $3::time)
                LIMIT 1
            `;
            const calendarOverlap = await pool.query(calendarOverlapQuery, [doctorUserId, date, startStr, endStr]);
            if (!hasApptOverlap && calendarOverlap.rows.length === 0) {
                return { date, time: startStr };
            }
        }
        return null;
    }

    // Create a new appointment
    static async create(data: CreateAppointmentData): Promise<Appointment> {
        const insertQuery = `
            INSERT INTO appointments (
                patient_id,
                doctor_user_id,
                date,
                time,
                duration,
                notes,
                color,
                confirmed_coming,
                is_done
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, COALESCE($9, false))
            RETURNING id
        `;

        const insertValues = [
            data.patient_id,
            data.doctor_user_id,
            data.date,
            data.time,
            data.duration ?? 30,
            data.notes ?? null,
            data.color ?? '#2563eb',
            data.confirmed_coming ?? false,
            data.is_done ?? null
        ];

        const inserted = await pool.query(insertQuery, insertValues);
        const newId = inserted.rows[0].id as string;
        return await this.findById(newId) as Appointment;
    }

    // ⚡ OPTIMIZED: Find by ID (with patient name fields)
    static async findById(id: string): Promise<Appointment | null> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $2) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $2) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.id = $1
        `;
        const result = await pool.query(query, [id, this.ENCRYPTION_KEY]);
        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    // Update appointment
    static async update(id: string, data: UpdateAppointmentData): Promise<Appointment | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.patient_id !== undefined) {
            fields.push(`patient_id = $${idx++}`);
            values.push(data.patient_id);
        }
        if (data.doctor_user_id !== undefined) {
            fields.push(`doctor_user_id = $${idx++}`);
            values.push(data.doctor_user_id);
        }
        if (data.date !== undefined) {
            fields.push(`date = $${idx++}`);
            values.push(data.date);
        }
        if (data.time !== undefined) {
            fields.push(`time = $${idx++}`);
            values.push(data.time);
        }
        if (data.duration !== undefined) {
            fields.push(`duration = $${idx++}`);
            values.push(data.duration);
        }
        if (data.notes !== undefined) {
            fields.push(`notes = $${idx++}`);
            values.push(data.notes);
        }
        if (data.color !== undefined) {
            fields.push(`color = $${idx++}`);
            values.push(data.color);
        }
        if (data.confirmed_coming !== undefined) {
            fields.push(`confirmed_coming = $${idx++}`);
            values.push(data.confirmed_coming);
        }
        if (data.is_done !== undefined) {
            fields.push(`is_done = $${idx++}`);
            values.push(data.is_done);
        }
        if (data.venue_confirmed !== undefined) {
            fields.push(`venue_confirmed = $${idx++}`);
            values.push(data.venue_confirmed);
        }
        if (data.arrived_at !== undefined) {
            fields.push(`arrived_at = $${idx++}`);
            values.push(data.arrived_at);
        }
        if (data.served_at !== undefined) {
            fields.push(`served_at = $${idx++}`);
            values.push(data.served_at);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE appointments a SET ${fields.join(', ')} WHERE a.id = $${idx} RETURNING a.id`;
        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;
        return await this.findById(id);
    }

    // Hard delete appointment
    static async delete(id: string): Promise<boolean> {
        const query = 'DELETE FROM appointments WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // ⚡ OPTIMIZED: List appointments (doctor scoped handled by callers via specific methods)
    static async findAll(limit: number = 50, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $3) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $3) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            ORDER BY a.date DESC, a.time DESC
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // ⚡ OPTIMIZED
    static async findByDate(date: Date, limit: number = 100, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $4) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.date = $1
            ORDER BY a.time ASC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [date, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // ⚡ OPTIMIZED
    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $4) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.patient_id = $1
            ORDER BY a.date DESC, a.time DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [patientId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // ⚡ OPTIMIZED
    static async findByDoctorUserId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $4) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.doctor_user_id = $1
            ORDER BY a.date DESC, a.time DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // ⚡ OPTIMIZED
    static async findByDateAndDoctor(date: Date, doctorUserId: number, limit: number = 100, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.date = $1 AND a.doctor_user_id = $2
            ORDER BY a.time ASC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [date, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }

    // ⚡ OPTIMIZED
    static async findByPatientAndDoctor(patientId: string, doctorUserId: number, limit: number = 50, offset: number = 0): Promise<Appointment[]> {
        const query = `
            SELECT a.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM appointments a
            JOIN patients p ON p.id = a.patient_id
            WHERE a.patient_id = $1 AND a.doctor_user_id = $2
            ORDER BY a.date DESC, a.time DESC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [patientId, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(row => this.mapRow(row));
    }
}