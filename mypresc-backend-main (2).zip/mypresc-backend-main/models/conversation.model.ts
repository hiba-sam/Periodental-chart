import pool from '../db';

export interface Conversation {
  id: number;
  type: 'direct';
  created_by: number;
  created_at: Date;
  updated_at: Date;
}

export interface ConversationWithDetails extends Conversation {
  other_user_id: number;
  other_user_name: string;
  other_user_avatar?: string;
  last_message?: string;
  last_message_at?: Date;
  unread_count: number;
}

export class ConversationModel {
  /**
   * Get or create direct conversation between two users
   */
  static async getOrCreateDirectConversation(
    userId1: number,
    userId2: number
  ): Promise<number> {
    const client = await pool.connect();
    try {
      // Try to get existing conversation
      const existingResult = await client.query(
        'SELECT get_direct_conversation($1, $2) AS conv_id',
        [userId1, userId2]
      );

      if (existingResult.rows[0].conv_id) {
        return existingResult.rows[0].conv_id;
      }

      // Create new conversation
      const newResult = await client.query(
        'SELECT create_direct_conversation($1, $2) AS conv_id',
        [userId1, userId2]
      );

      return newResult.rows[0].conv_id;
    } finally {
      client.release();
    }
  }

  /**
   * Get all conversations for a user with details
   */
  static async getUserConversations(
    userId: number
  ): Promise<ConversationWithDetails[]> {
    const result = await pool.query(
      `
      SELECT 
        c.id,
        c.type,
        c.created_at,
        c.updated_at,
        -- Find the other user in the conversation
        CASE 
          WHEN cm1.user_id = $1 THEN cm2.user_id
          ELSE cm1.user_id
        END AS other_user_id,
        CASE 
          WHEN cm1.user_id = $1 THEN u2.name || ' ' || u2.family_name
          ELSE u1.name || ' ' || u1.family_name
        END AS other_user_name,
        -- Last message
        (
          SELECT content 
          FROM messages 
          WHERE conversation_id = c.id 
            AND deleted_at IS NULL
          ORDER BY created_at DESC 
          LIMIT 1
        ) AS last_message,
        (
          SELECT created_at 
          FROM messages 
          WHERE conversation_id = c.id 
            AND deleted_at IS NULL
          ORDER BY created_at DESC 
          LIMIT 1
        ) AS last_message_at,
        -- Unread count
        (
          SELECT COUNT(*) 
          FROM messages m
          LEFT JOIN message_reads mr ON m.id = mr.message_id AND mr.user_id = $1
          WHERE m.conversation_id = c.id 
            AND m.sender_id != $1
            AND m.deleted_at IS NULL
            AND mr.message_id IS NULL
        )::int AS unread_count
      FROM conversations c
      JOIN conversation_members cm1 ON cm1.conversation_id = c.id
      JOIN conversation_members cm2 ON cm2.conversation_id = c.id AND cm2.user_id != cm1.user_id
      JOIN users u1 ON u1.id = cm1.user_id
      JOIN users u2 ON u2.id = cm2.user_id
      WHERE cm1.user_id = $1 OR cm2.user_id = $1
      ORDER BY COALESCE(
        (SELECT created_at FROM messages WHERE conversation_id = c.id AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 1),
        c.created_at
      ) DESC
      `,
      [userId]
    );

    return result.rows;
  }

  /**
   * Check if user is member of conversation
   */
  static async isUserMember(
    conversationId: number,
    userId: number
  ): Promise<boolean> {
    const result = await pool.query(
      'SELECT 1 FROM conversation_members WHERE conversation_id = $1 AND user_id = $2',
      [conversationId, userId]
    );
    return result.rows.length > 0;
  }

  /**
   * Get conversation by ID
   */
  static async getById(conversationId: number): Promise<Conversation | null> {
    const result = await pool.query(
      'SELECT * FROM conversations WHERE id = $1',
      [conversationId]
    );
    return result.rows[0] || null;
  }

  /**
   * Get other user ID in direct conversation
   */
  static async getOtherUserId(
    conversationId: number,
    currentUserId: number
  ): Promise<number | null> {
    const result = await pool.query(
      `SELECT user_id 
       FROM conversation_members 
       WHERE conversation_id = $1 AND user_id != $2
       LIMIT 1`,
      [conversationId, currentUserId]
    );
    return result.rows[0]?.user_id || null;
  }
}
