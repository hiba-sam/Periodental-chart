import pool from '../db';

export interface Message {
  id: number;
  conversation_id: number;
  sender_id: number;
  content: string;
  is_edited: boolean;
  edited_at?: Date;
  deleted_at?: Date;
  created_at: Date;
  updated_at: Date;
  attachment_url?: string;
  attachment_type?: 'image' | 'pdf';
  attachment_name?: string;
}

export interface MessageWithSender extends Message {
  sender_name: string;
  is_read: boolean;
}

export class MessageModel {
  /**
   * Create a new message
   */
  static async create(
    conversationId: number,
    senderId: number,
    content: string,
    attachment?: { url: string; type: 'image' | 'pdf'; name: string }
  ): Promise<Message> {
    let result;

    if (attachment) {
      result = await pool.query(
        `INSERT INTO messages (conversation_id, sender_id, content, attachment_url, attachment_type, attachment_name)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
        [conversationId, senderId, content, attachment.url, attachment.type, attachment.name]
      );
    } else {
      result = await pool.query(
        `INSERT INTO messages (conversation_id, sender_id, content)
         VALUES ($1, $2, $3)
         RETURNING *`,
        [conversationId, senderId, content]
      );
    }

    // Update conversation updated_at
    await pool.query(
      'UPDATE conversations SET updated_at = NOW() WHERE id = $1',
      [conversationId]
    );

    return result.rows[0];
  }

  /**
   * Get messages for a conversation (paginated)
   */
  static async getByConversation(
    conversationId: number,
    currentUserId: number,
    page: number = 1,
    pageSize: number = 50
  ): Promise<MessageWithSender[]> {
    const offset = (page - 1) * pageSize;

    const result = await pool.query(
      `SELECT 
        m.id,
        m.conversation_id,
        m.sender_id,
        m.content,
        m.is_edited,
        m.edited_at,
        m.created_at,
        m.updated_at,
        m.attachment_url,
        m.attachment_type,
        m.attachment_name,
        u.name || ' ' || u.family_name AS sender_name,
        EXISTS(
          SELECT 1 FROM message_reads mr 
          WHERE mr.message_id = m.id 
          AND mr.user_id != $2
        ) AS is_read
      FROM messages m
      JOIN users u ON u.id = m.sender_id
      WHERE m.conversation_id = $1
        AND m.deleted_at IS NULL
      ORDER BY m.created_at DESC
      LIMIT $3 OFFSET $4`,
      [conversationId, currentUserId, pageSize, offset]
    );

    return result.rows;
  }

  /**
   * Mark message as read by user
   */
  static async markAsRead(messageId: number, userId: number): Promise<void> {
    await pool.query(
      `INSERT INTO message_reads (message_id, user_id, read_at)
       VALUES ($1, $2, NOW())
       ON CONFLICT (message_id, user_id) DO NOTHING`,
      [messageId, userId]
    );
  }

  /**
   * Mark all messages in conversation as read
   */
  static async markAllAsRead(
    conversationId: number,
    userId: number
  ): Promise<void> {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      console.log(`[MessageModel.markAllAsRead] Starting for conversationId: ${conversationId}, userId: ${userId}`);

      // Insert read receipts for unread messages
      const insertResult = await client.query(
        `INSERT INTO message_reads (message_id, user_id)
         SELECT m.id, $2
         FROM messages m
         LEFT JOIN message_reads mr ON mr.message_id = m.id AND mr.user_id = $2
         WHERE m.conversation_id = $1
           AND m.sender_id != $2
           AND m.deleted_at IS NULL
           AND mr.message_id IS NULL
         ON CONFLICT (message_id, user_id) DO NOTHING`,
        [conversationId, userId]
      );
      console.log(`[MessageModel.markAllAsRead] Inserted ${insertResult.rowCount} read receipts`);

      // Update last_read_at
      const updateResult = await client.query(
        `UPDATE conversation_members
         SET last_read_at = NOW()
         WHERE conversation_id = $1 AND user_id = $2`,
        [conversationId, userId]
      );
      console.log(`[MessageModel.markAllAsRead] Updated ${updateResult.rowCount} conversation_members`);

      await client.query('COMMIT');
      console.log(`[MessageModel.markAllAsRead] Committed successfully`);
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get message by ID
   */
  static async getById(messageId: number): Promise<Message | null> {
    const result = await pool.query(
      'SELECT * FROM messages WHERE id = $1 AND deleted_at IS NULL',
      [messageId]
    );
    return result.rows[0] || null;
  }

  /**
   * Soft delete message
   */
  static async softDelete(messageId: number, userId: number): Promise<boolean> {
    const result = await pool.query(
      `UPDATE messages 
       SET deleted_at = NOW()
       WHERE id = $1 AND sender_id = $2 AND deleted_at IS NULL
       RETURNING id`,
      [messageId, userId]
    );
    return result.rows.length > 0;
  }

  /**
   * Search messages in a conversation by content
   */
  static async searchByContent(
    conversationId: number,
    query: string,
    currentUserId: number,
    limit: number = 50
  ): Promise<MessageWithSender[]> {
    // Sanitize and prepare search query
    const searchQuery = `%${query.toLowerCase()}%`;

    const result = await pool.query(
      `SELECT 
        m.id,
        m.conversation_id,
        m.sender_id,
        m.content,
        m.is_edited,
        m.edited_at,
        m.created_at,
        m.updated_at,
        m.attachment_url,
        m.attachment_type,
        m.attachment_name,
        u.name || ' ' || u.family_name AS sender_name,
        EXISTS(
          SELECT 1 FROM message_reads mr 
          WHERE mr.message_id = m.id 
          AND mr.user_id != $3
        ) AS is_read
      FROM messages m
      JOIN users u ON u.id = m.sender_id
      WHERE m.conversation_id = $1
        AND m.deleted_at IS NULL
        AND LOWER(m.content) LIKE $2
      ORDER BY m.created_at DESC
      LIMIT $4`,
      [conversationId, searchQuery, currentUserId, limit]
    );

    return result.rows;
  }
}

