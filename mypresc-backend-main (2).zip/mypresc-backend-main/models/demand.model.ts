import pool from '../db';
import crypto from 'crypto';

export interface Demand {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    specialty: string;
    created_at: Date;
    updated_at: Date;
}

export interface CreateDemandData {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    specialty: string;
}

export class DemandModel {
    private static readonly ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

    // Helper method to encrypt data
    private static async encrypt(data: string): Promise<Buffer> {
        const result = await pool.query('SELECT pgp_sym_encrypt($1, $2) as encrypted', [data, this.ENCRYPTION_KEY]);
        return result.rows[0].encrypted;
    }

    // Helper method to decrypt data
    private static async decrypt(encryptedData: Buffer): Promise<string> {
        const result = await pool.query('SELECT pgp_sym_decrypt($1, $2) as decrypted', [encryptedData, this.ENCRYPTION_KEY]);
        return result.rows[0].decrypted;
    }

    /**
     * Generate a blind index for a string value
     * Uses SHA256 hash to create a searchable index without revealing the original value
     *
     * @param value - The plaintext value to generate a blind index for
     * @returns SHA256 hash of the lowercase value (hex string)
     */
    private static generateBlindIndex(value: string): string {
        // Normalize to lowercase for case-insensitive searching
        const normalized = value.toLowerCase().trim();
        // Generate SHA256 hash
        return crypto.createHash('sha256').update(normalized).digest('hex');
    }

    /**
     * Create a new demand registration
     * All sensitive data is encrypted using pgcrypto
     */
    static async create(data: CreateDemandData): Promise<Demand> {
        const { firstName, lastName, email, phone, specialty } = data;

        // Generate blind indexes for searchable fields
        const emailBlindIndex = this.generateBlindIndex(email);
        const phoneBlindIndex = this.generateBlindIndex(phone);

        // Insert encrypted data with blind indexes
        const result = await pool.query(
            `INSERT INTO demands (
                first_name,
                last_name,
                email,
                phone,
                specialty,
                email_blind_index,
                phone_blind_index
            ) VALUES (
                pgp_sym_encrypt($1, $2),
                pgp_sym_encrypt($3, $4),
                pgp_sym_encrypt($5, $6),
                pgp_sym_encrypt($7, $8),
                pgp_sym_encrypt($9, $10),
                $11,
                $12
            ) RETURNING id, created_at, updated_at`,
            [
                firstName, this.ENCRYPTION_KEY,
                lastName, this.ENCRYPTION_KEY,
                email, this.ENCRYPTION_KEY,
                phone, this.ENCRYPTION_KEY,
                specialty, this.ENCRYPTION_KEY,
                emailBlindIndex,
                phoneBlindIndex
            ]
        );

        // Return the demand with decrypted data
        return {
            id: result.rows[0].id,
            firstName,
            lastName,
            email,
            phone,
            specialty,
            created_at: result.rows[0].created_at,
            updated_at: result.rows[0].updated_at
        };
    }

    /**
     * Find a demand by email (using blind index for search)
     */
    static async findByEmail(email: string): Promise<Demand | null> {
        const emailBlindIndex = this.generateBlindIndex(email);

        const result = await pool.query(
            `SELECT
                id,
                pgp_sym_decrypt(first_name, $1) as first_name,
                pgp_sym_decrypt(last_name, $2) as last_name,
                pgp_sym_decrypt(email, $3) as email,
                pgp_sym_decrypt(phone, $4) as phone,
                pgp_sym_decrypt(specialty, $5) as specialty,
                created_at,
                updated_at
            FROM demands
            WHERE email_blind_index = $6`,
            [
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                emailBlindIndex
            ]
        );

        if (result.rows.length === 0) {
            return null;
        }

        const row = result.rows[0];
        return {
            id: row.id,
            firstName: row.first_name,
            lastName: row.last_name,
            email: row.email,
            phone: row.phone,
            specialty: row.specialty,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    /**
     * Find a demand by phone (using blind index for search)
     */
    static async findByPhone(phone: string): Promise<Demand | null> {
        const phoneBlindIndex = this.generateBlindIndex(phone);

        const result = await pool.query(
            `SELECT
                id,
                pgp_sym_decrypt(first_name, $1) as first_name,
                pgp_sym_decrypt(last_name, $2) as last_name,
                pgp_sym_decrypt(email, $3) as email,
                pgp_sym_decrypt(phone, $4) as phone,
                pgp_sym_decrypt(specialty, $5) as specialty,
                created_at,
                updated_at
            FROM demands
            WHERE phone_blind_index = $6`,
            [
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                phoneBlindIndex
            ]
        );

        if (result.rows.length === 0) {
            return null;
        }

        const row = result.rows[0];
        return {
            id: row.id,
            firstName: row.first_name,
            lastName: row.last_name,
            email: row.email,
            phone: row.phone,
            specialty: row.specialty,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    /**
     * Get all demands (with decrypted data)
     */
    static async findAll(): Promise<Demand[]> {
        const result = await pool.query(
            `SELECT
                id,
                pgp_sym_decrypt(first_name, $1) as first_name,
                pgp_sym_decrypt(last_name, $2) as last_name,
                pgp_sym_decrypt(email, $3) as email,
                pgp_sym_decrypt(phone, $4) as phone,
                pgp_sym_decrypt(specialty, $5) as specialty,
                created_at,
                updated_at
            FROM demands
            ORDER BY created_at DESC`,
            [
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY
            ]
        );

        return result.rows.map(row => ({
            id: row.id,
            firstName: row.first_name,
            lastName: row.last_name,
            email: row.email,
            phone: row.phone,
            specialty: row.specialty,
            created_at: row.created_at,
            updated_at: row.updated_at
        }));
    }

    /**
     * Find a demand by ID
     */
    static async findById(id: string): Promise<Demand | null> {
        const result = await pool.query(
            `SELECT
                id,
                pgp_sym_decrypt(first_name, $1) as first_name,
                pgp_sym_decrypt(last_name, $2) as last_name,
                pgp_sym_decrypt(email, $3) as email,
                pgp_sym_decrypt(phone, $4) as phone,
                pgp_sym_decrypt(specialty, $5) as specialty,
                created_at,
                updated_at
            FROM demands
            WHERE id = $6`,
            [
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                this.ENCRYPTION_KEY,
                id
            ]
        );

        if (result.rows.length === 0) {
            return null;
        }

        const row = result.rows[0];
        return {
            id: row.id,
            firstName: row.first_name,
            lastName: row.last_name,
            email: row.email,
            phone: row.phone,
            specialty: row.specialty,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    /**
     * Delete a demand by ID
     */
    static async delete(id: string): Promise<boolean> {
        const result = await pool.query(
            'DELETE FROM demands WHERE id = $1 RETURNING id',
            [id]
        );
        return result.rows.length > 0;
    }
}
