import pool from "../db";

// ============================================
// TYPES & INTERFACES
// ============================================

export interface AuditLog {
    id: number;
    admin_id: number | null;
    admin_name: string;
    admin_email: string;
    action: string;
    target_type?: string;
    target_id?: number;
    target_name?: string;
    timestamp: Date;
    ip_address?: string;
    user_agent?: string;
    session_id?: string;
    notes?: string;
    metadata?: any;
    status: 'success' | 'failed' | 'pending';
}

export interface CreateAuditLogData {
    admin_id: number | null;
    admin_name: string;
    admin_email: string;
    action: string;
    target_type?: string;
    target_id?: number;
    target_name?: string;
    ip_address?: string;
    user_agent?: string;
    session_id?: string;
    notes?: string;
    metadata?: any;
    status?: 'success' | 'failed' | 'pending';
}

export interface AuditLogFilters {
    admin_id?: number;
    action?: string;
    target_type?: string;
    target_id?: number;
    status?: string;
    start_date?: Date;
    end_date?: Date;
}

// ============================================
// AUDIT MODEL
// ============================================

export class AuditModel {
    
    /**
     * Create new audit log entry
     */
    static async create(data: CreateAuditLogData): Promise<AuditLog> {
        const query = `
            INSERT INTO audit_logs (
                admin_id, admin_name, admin_email, action, 
                target_type, target_id, target_name,
                ip_address, user_agent, session_id, notes, metadata, status
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            RETURNING *
        `;
        
        const values = [
            data.admin_id,
            data.admin_name,
            data.admin_email,
            data.action,
            data.target_type || null,
            data.target_id || null,
            data.target_name || null,
            data.ip_address || null,
            data.user_agent || null,
            data.session_id || null,
            data.notes || null,
            data.metadata ? JSON.stringify(data.metadata) : null,
            data.status || 'success'
        ];
        
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    /**
     * Get audit log by ID
     */
    static async findById(id: number): Promise<AuditLog | null> {
        const query = `SELECT * FROM audit_logs WHERE id = $1`;
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Get audit logs with filters and pagination
     */
    static async getFiltered(
        filters: AuditLogFilters = {},
        limit: number = 50,
        offset: number = 0
    ): Promise<AuditLog[]> {
        const conditions: string[] = [];
        const values: any[] = [];
        let paramCount = 1;

        if (filters.admin_id) {
            conditions.push(`admin_id = $${paramCount}`);
            values.push(filters.admin_id);
            paramCount++;
        }

        if (filters.action) {
            conditions.push(`action = $${paramCount}`);
            values.push(filters.action);
            paramCount++;
        }

        if (filters.target_type) {
            conditions.push(`target_type = $${paramCount}`);
            values.push(filters.target_type);
            paramCount++;
        }

        if (filters.target_id) {
            conditions.push(`target_id = $${paramCount}`);
            values.push(filters.target_id);
            paramCount++;
        }

        if (filters.status) {
            conditions.push(`status = $${paramCount}`);
            values.push(filters.status);
            paramCount++;
        }

        if (filters.start_date) {
            conditions.push(`timestamp >= $${paramCount}`);
            values.push(filters.start_date);
            paramCount++;
        }

        if (filters.end_date) {
            conditions.push(`timestamp <= $${paramCount}`);
            values.push(filters.end_date);
            paramCount++;
        }

        const whereClause = conditions.length > 0 
            ? `WHERE ${conditions.join(' AND ')}`
            : '';

        values.push(limit, offset);
        
        const query = `
            SELECT * FROM audit_logs 
            ${whereClause}
            ORDER BY timestamp DESC
            LIMIT $${paramCount} OFFSET $${paramCount + 1}
        `;

        const result = await pool.query(query, values);
        return result.rows;
    }

    /**
     * Get audit logs for specific admin
     */
    static async getByAdmin(adminId: number, limit: number = 50, offset: number = 0): Promise<AuditLog[]> {
        return this.getFiltered({ admin_id: adminId }, limit, offset);
    }

    /**
     * Get audit logs for specific target (user, doctor, etc.)
     */
    static async getByTarget(
        targetType: string, 
        targetId: number, 
        limit: number = 50, 
        offset: number = 0
    ): Promise<AuditLog[]> {
        return this.getFiltered({ target_type: targetType, target_id: targetId }, limit, offset);
    }

    /**
     * Get audit logs for specific action
     */
    static async getByAction(action: string, limit: number = 50, offset: number = 0): Promise<AuditLog[]> {
        return this.getFiltered({ action }, limit, offset);
    }

    /**
     * Get recent audit logs
     */
    static async getRecent(limit: number = 20): Promise<AuditLog[]> {
        const query = `
            SELECT * FROM audit_logs 
            ORDER BY timestamp DESC 
            LIMIT $1
        `;
        
        const result = await pool.query(query, [limit]);
        return result.rows;
    }

    /**
     * Get audit logs count with filters
     */
    static async getCount(filters: AuditLogFilters = {}): Promise<number> {
        const conditions: string[] = [];
        const values: any[] = [];
        let paramCount = 1;

        if (filters.admin_id) {
            conditions.push(`admin_id = $${paramCount}`);
            values.push(filters.admin_id);
            paramCount++;
        }

        if (filters.action) {
            conditions.push(`action = $${paramCount}`);
            values.push(filters.action);
            paramCount++;
        }

        if (filters.target_type) {
            conditions.push(`target_type = $${paramCount}`);
            values.push(filters.target_type);
            paramCount++;
        }

        if (filters.status) {
            conditions.push(`status = $${paramCount}`);
            values.push(filters.status);
            paramCount++;
        }

        const whereClause = conditions.length > 0 
            ? `WHERE ${conditions.join(' AND ')}`
            : '';

        const query = `SELECT COUNT(*) as count FROM audit_logs ${whereClause}`;
        const result = await pool.query(query, values);
        return parseInt(result.rows[0].count);
    }

    /**
     * Get statistics by action
     */
    static async getActionStats(): Promise<{ action: string; count: number }[]> {
        const query = `
            SELECT action, COUNT(*) as count
            FROM audit_logs
            GROUP BY action
            ORDER BY count DESC
        `;
        
        const result = await pool.query(query);
        return result.rows.map(row => ({
            action: row.action,
            count: parseInt(row.count)
        }));
    }

    /**
     * Get statistics by admin
     */
    static async getAdminStats(days: number = 30): Promise<{ admin_name: string; action_count: number }[]> {
        const query = `
            SELECT admin_name, COUNT(*) as action_count
            FROM audit_logs
            WHERE timestamp >= CURRENT_TIMESTAMP - INTERVAL '${days} days'
            GROUP BY admin_name
            ORDER BY action_count DESC
        `;
        
        const result = await pool.query(query);
        return result.rows.map(row => ({
            admin_name: row.admin_name,
            action_count: parseInt(row.action_count)
        }));
    }

    /**
     * Delete old audit logs (data retention policy)
     */
    static async deleteOlderThan(days: number): Promise<number> {
        const query = `
            DELETE FROM audit_logs
            WHERE timestamp < CURRENT_TIMESTAMP - INTERVAL '${days} days'
            RETURNING id
        `;
        
        const result = await pool.query(query);
        return result.rows.length;
    }
}
