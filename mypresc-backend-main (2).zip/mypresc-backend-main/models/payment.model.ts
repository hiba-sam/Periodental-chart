import pool from '../db';

export interface Payment {
    id: number;
    doctor_user_id: number;
    checkout_id: string;
    plan: 'flex' | 'smart' | 'pro';
    amount: number;
    currency: string;
    status: 'pending' | 'paid' | 'failed' | 'expired' | 'canceled';
    payment_method: string | null;
    transaction_id: string | null;
    checkout_url: string | null;
    expires_at: Date | null;
    paid_at: Date | null;
    metadata: Record<string, unknown> | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreatePaymentData {
    doctor_user_id: number;
    checkout_id: string;
    plan: 'flex' | 'smart' | 'pro';
    amount: number;
    currency?: string;
    checkout_url?: string;
    expires_at?: Date;
    metadata?: Record<string, unknown>;
}

export interface UpdatePaymentData {
    status?: 'pending' | 'paid' | 'failed' | 'expired' | 'canceled';
    payment_method?: string;
    transaction_id?: string;
    paid_at?: Date;
    expires_at?: Date;
    metadata?: Record<string, unknown>;
}

export class PaymentModel {
    // Create a new payment record
    static async create(paymentData: CreatePaymentData): Promise<Payment> {
        const query = `
            INSERT INTO payments (
                doctor_user_id, checkout_id, plan, amount, currency,
                checkout_url, expires_at, metadata
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING *
        `;

        const values = [
            paymentData.doctor_user_id,
            paymentData.checkout_id,
            paymentData.plan,
            paymentData.amount,
            paymentData.currency || 'DZD',
            paymentData.checkout_url || null,
            paymentData.expires_at || null,
            paymentData.metadata ? JSON.stringify(paymentData.metadata) : null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find payment by checkout ID
    static async findByCheckoutId(checkoutId: string): Promise<Payment | null> {
        const query = 'SELECT * FROM payments WHERE checkout_id = $1';
        const result = await pool.query(query, [checkoutId]);
        return result.rows[0] || null;
    }

    // Find payment by ID
    static async findById(id: number): Promise<Payment | null> {
        const query = 'SELECT * FROM payments WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find payments by doctor user ID
    static async findByDoctorUserId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<Payment[]> {
        const query = `
            SELECT * FROM payments
            WHERE doctor_user_id = $1
            ORDER BY created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset]);
        return result.rows;
    }

    // Update payment
    static async update(checkoutId: string, paymentData: UpdatePaymentData): Promise<Payment | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (paymentData.status !== undefined) {
            fields.push(`status = $${idx++}`);
            values.push(paymentData.status);
        }
        if (paymentData.payment_method !== undefined) {
            fields.push(`payment_method = $${idx++}`);
            values.push(paymentData.payment_method);
        }
        if (paymentData.transaction_id !== undefined) {
            fields.push(`transaction_id = $${idx++}`);
            values.push(paymentData.transaction_id);
        }
        if (paymentData.paid_at !== undefined) {
            fields.push(`paid_at = $${idx++}`);
            values.push(paymentData.paid_at);
        }
        if (paymentData.metadata !== undefined) {
            fields.push(`metadata = $${idx++}`);
            values.push(JSON.stringify(paymentData.metadata));
        }
        if (paymentData.expires_at !== undefined) {
            fields.push(`expires_at = $${idx++}`);
            values.push(paymentData.expires_at);
        }

        if (fields.length === 0) {
            return await this.findByCheckoutId(checkoutId);
        }

        values.push(checkoutId);
        const query = `UPDATE payments SET ${fields.join(', ')} WHERE checkout_id = $${idx} RETURNING *`;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Get all payments with filters
    static async findAll(
        filters?: {
            status?: string;
            plan?: string;
            limit?: number;
            offset?: number;
        }
    ): Promise<Payment[]> {
        let query = 'SELECT * FROM payments WHERE 1=1';
        const values: any[] = [];
        let idx = 1;

        if (filters?.status) {
            query += ` AND status = $${idx++}`;
            values.push(filters.status);
        }
        if (filters?.plan) {
            query += ` AND plan = $${idx++}`;
            values.push(filters.plan);
        }

        query += ` ORDER BY created_at DESC LIMIT $${idx++} OFFSET $${idx++}`;
        values.push(filters?.limit || 50);
        values.push(filters?.offset || 0);

        const result = await pool.query(query, values);
        return result.rows;
    }

    // Get the latest successful payment for a doctor
    static async getLatestSuccessfulPayment(doctorUserId: number): Promise<Payment | null> {
        const query = `
            SELECT * FROM payments
            WHERE doctor_user_id = $1 AND status = 'paid'
            ORDER BY paid_at DESC
            LIMIT 1
        `;
        const result = await pool.query(query, [doctorUserId]);
        return result.rows[0] || null;
    }

    // Delete a payment
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM payments WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }
}
