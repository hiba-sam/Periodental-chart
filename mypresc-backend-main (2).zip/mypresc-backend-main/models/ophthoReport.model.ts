import pool from '../db.js';
import { PatientModel } from './patient.model.js';

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface OphthalmologyReport {
    id: number;
    patient_id: string;
    doctor_user_id: number;

    // Machine metadata
    machine_company?:     string | null;
    machine_model?:       string | null;
    machine_no?:          string | null;
    machine_rom_version?: string | null;
    schema_version?:      string | null;
    exam_date:            string;  // ISO date
    exam_time:            string;  // HH:MM:SS
    exam_duration?:       string | null;
    xml_raw?:             string | null;

    // Prescription — Far distance
    rx_far_right_sph?:   number | null;
    rx_far_right_cyl?:   number | null;
    rx_far_right_axis?:  number | null;
    rx_far_right_h_pri?: number | null;
    rx_far_right_v_pri?: number | null;
    rx_far_left_sph?:    number | null;
    rx_far_left_cyl?:    number | null;
    rx_far_left_axis?:   number | null;
    rx_far_left_h_pri?:  number | null;
    rx_far_left_v_pri?:  number | null;
    rx_far_vd?:          number | null;
    rx_far_pd_r?:        number | null;
    rx_far_pd_l?:        number | null;
    rx_far_pd_b?:        number | null;

    // Prescription — Near distance
    rx_near_right_sph?:   number | null;
    rx_near_right_cyl?:   number | null;
    rx_near_right_axis?:  number | null;
    rx_near_right_h_pri?: number | null;
    rx_near_right_v_pri?: number | null;
    rx_near_left_sph?:    number | null;
    rx_near_left_cyl?:    number | null;
    rx_near_left_axis?:   number | null;
    rx_near_left_h_pri?:  number | null;
    rx_near_left_v_pri?:  number | null;
    rx_near_vd?:          number | null;
    rx_near_pd_r?:        number | null;
    rx_near_pd_l?:        number | null;
    rx_near_pd_b?:        number | null;

    // Doctor annotations
    clinical_notes?: string | null;
    diagnosis?:      string | null;

    // Raw measurement dump
    raw_measurements?: any | null;

    // Audit
    created_at: Date;
    updated_at: Date;

    // Joined fields
    doctor_name?:        string;
    doctor_family_name?: string;
    doctor_email?:       string;
    patient?:            any;
}

export interface CreateOphthoReportData {
    patient_id:    string;
    doctor_user_id: number;
    [key: string]: any;
}

export interface UpdateOphthoReportData {
    clinical_notes?: string | null;
    diagnosis?:      string | null;
}

// Mutable columns for update (doctor annotations only after import)
const ANNOTATION_COLUMNS = ['clinical_notes', 'diagnosis'];

// All columns inserted from the parser flat object
const INSERT_COLUMNS = [
    'machine_company', 'machine_model', 'machine_no', 'machine_rom_version', 'schema_version',
    'exam_date', 'exam_time', 'exam_duration', 'xml_raw',
    'rx_far_right_sph', 'rx_far_right_cyl', 'rx_far_right_axis', 'rx_far_right_h_pri', 'rx_far_right_v_pri',
    'rx_far_left_sph',  'rx_far_left_cyl',  'rx_far_left_axis',  'rx_far_left_h_pri',  'rx_far_left_v_pri',
    'rx_far_vd', 'rx_far_pd_r', 'rx_far_pd_l', 'rx_far_pd_b',
    'rx_near_right_sph', 'rx_near_right_cyl', 'rx_near_right_axis', 'rx_near_right_h_pri', 'rx_near_right_v_pri',
    'rx_near_left_sph',  'rx_near_left_cyl',  'rx_near_left_axis',  'rx_near_left_h_pri',  'rx_near_left_v_pri',
    'rx_near_vd', 'rx_near_pd_r', 'rx_near_pd_l', 'rx_near_pd_b',
    'clinical_notes', 'diagnosis',
    'raw_measurements',
];

// ============================================
// MODEL
// ============================================

export class OphthoReportModel {

    /**
     * Create a new ophthalmology report from parsed XML data
     */
    static async create(data: CreateOphthoReportData): Promise<OphthalmologyReport> {
        const columns = ['patient_id', 'doctor_user_id'];
        const placeholders = ['$1', '$2'];
        const values: any[] = [data.patient_id, data.doctor_user_id];
        let paramIdx = 3;

        for (const col of INSERT_COLUMNS) {
            if (data[col] !== undefined) {
                columns.push(col);
                placeholders.push(`$${paramIdx}`);
                // raw_measurements needs to be cast to jsonb
                values.push(col === 'raw_measurements' && typeof data[col] === 'string'
                    ? data[col]
                    : data[col]);
                paramIdx++;
            }
        }

        const query = `
            INSERT INTO ophthalmology_reports (${columns.join(', ')})
            VALUES (${placeholders.join(', ')})
            RETURNING *
        `;

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    /**
     * Find all reports for a patient, ordered by exam date desc
     */
    static async findByPatient(patientId: string): Promise<OphthalmologyReport[]> {
        const query = `
            SELECT r.*,
                   u.name         AS doctor_name,
                   u.family_name  AS doctor_family_name
            FROM ophthalmology_reports r
            LEFT JOIN users u ON r.doctor_user_id = u.id
            WHERE r.patient_id = $1
            ORDER BY r.exam_date DESC, r.exam_time DESC
        `;
        const result = await pool.query(query, [patientId]);
        return result.rows;
    }

    /**
     * Find a single report by ID (with doctor join)
     */
    static async findById(id: number): Promise<OphthalmologyReport | null> {
        const query = `
            SELECT r.*,
                   u.name         AS doctor_name,
                   u.family_name  AS doctor_family_name,
                   u.email        AS doctor_email
            FROM ophthalmology_reports r
            LEFT JOIN users u ON r.doctor_user_id = u.id
            WHERE r.id = $1
        `;
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Find by ID with full patient data (for PDF generation)
     */
    static async findByIdWithPatient(
        id: number,
        requestingDoctorId?: number
    ): Promise<(OphthalmologyReport & { patient?: any }) | null> {
        const row = await this.findById(id);
        if (!row) return null;

        const patient = await PatientModel.findById(row.patient_id, requestingDoctorId);
        return { ...row, patient };
    }

    /**
     * Update doctor annotations (clinical_notes, diagnosis)
     */
    static async update(id: number, data: UpdateOphthoReportData): Promise<OphthalmologyReport | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let paramIdx = 1;

        for (const col of ANNOTATION_COLUMNS) {
            if ((data as any)[col] !== undefined) {
                fields.push(`${col} = $${paramIdx}`);
                values.push((data as any)[col]);
                paramIdx++;
            }
        }

        if (fields.length === 0) return this.findById(id);

        values.push(id);
        const query = `
            UPDATE ophthalmology_reports
            SET ${fields.join(', ')}
            WHERE id = $${paramIdx}
            RETURNING *
        `;
        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;
        return this.findById(id);
    }

    /**
     * Delete a report (doctor can only delete own reports — enforce at controller level)
     */
    static async delete(id: number): Promise<boolean> {
        const result = await pool.query(
            'DELETE FROM ophthalmology_reports WHERE id = $1',
            [id]
        );
        return (result.rowCount ?? 0) > 0;
    }

    /**
     * Check ownership — returns true if this report belongs to the given doctor
     */
    static async checkOwnership(id: number, doctorUserId: number): Promise<boolean> {
        const result = await pool.query(
            'SELECT 1 FROM ophthalmology_reports WHERE id = $1 AND doctor_user_id = $2',
            [id, doctorUserId]
        );
        return result.rows.length > 0;
    }
}
