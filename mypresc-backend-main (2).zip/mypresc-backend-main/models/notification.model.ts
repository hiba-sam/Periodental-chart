import pool from '../db';

export interface Notification {
    id: string;
    user_id: number;
    title: string;
    description: string;
    link: string | null;
    type: 'alert' | 'check' | 'error' | 'info';
    is_seen: boolean;
    created_at: Date;
    updated_at: Date;
}

export interface CreateNotificationData {
    user_id: number;
    title: string;
    description: string;
    link?: string | null;
    type: 'alert' | 'check' | 'error' | 'info';
    is_seen?: boolean;
}

export interface UpdateNotificationData {
    title?: string;
    description?: string;
    link?: string | null;
    type?: 'alert' | 'check' | 'error' | 'info';
    is_seen?: boolean;
}

export class NotificationModel {
    private static mapRow(row: any): Notification {
        return {
            id: row.id,
            user_id: row.user_id,
            title: row.title,
            description: row.description,
            link: row.link,
            type: row.type,
            is_seen: row.is_seen,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    // Create a new notification
    static async create(data: CreateNotificationData): Promise<Notification> {
        const query = `
            INSERT INTO notifications (
                user_id,
                title,
                description,
                link,
                type,
                is_seen
            ) VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id
        `;

        const values = [
            data.user_id,
            data.title,
            data.description,
            data.link ?? null,
            data.type,
            data.is_seen ?? false
        ];

        const inserted = await pool.query(query, values);
        const newId = inserted.rows[0].id as string;
        return await this.findById(newId) as Notification;
    }

    // Find by ID (optionally scoped to a user for security)
    static async findById(id: string, userId?: number): Promise<Notification | null> {
        let query: string;
        let params: any[];

        if (userId !== undefined) {
            query = 'SELECT * FROM notifications WHERE id = $1 AND user_id = $2';
            params = [id, userId];
        } else {
            query = 'SELECT * FROM notifications WHERE id = $1';
            params = [id];
        }

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    // Update notification (optionally scoped to a user for security)
    static async update(id: string, data: UpdateNotificationData, userId?: number): Promise<Notification | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.title !== undefined) {
            fields.push(`title = $${idx++}`);
            values.push(data.title);
        }
        if (data.description !== undefined) {
            fields.push(`description = $${idx++}`);
            values.push(data.description);
        }
        if (data.link !== undefined) {
            fields.push(`link = $${idx++}`);
            values.push(data.link);
        }
        if (data.type !== undefined) {
            fields.push(`type = $${idx++}`);
            values.push(data.type);
        }
        if (data.is_seen !== undefined) {
            fields.push(`is_seen = $${idx++}`);
            values.push(data.is_seen);
        }

        if (fields.length === 0) {
            return await this.findById(id, userId);
        }

        values.push(id);
        let query = `UPDATE notifications SET ${fields.join(', ')} WHERE id = $${idx}`;
        
        if (userId !== undefined) {
            values.push(userId);
            query += ` AND user_id = $${idx + 1}`;
        }
        
        query += ' RETURNING id';
        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;
        return await this.findById(id, userId);
    }

    // Delete notification (optionally scoped to a user for security)
    static async delete(id: string, userId?: number): Promise<boolean> {
        let query: string;
        let params: any[];

        if (userId !== undefined) {
            query = 'DELETE FROM notifications WHERE id = $1 AND user_id = $2';
            params = [id, userId];
        } else {
            query = 'DELETE FROM notifications WHERE id = $1';
            params = [id];
        }

        const result = await pool.query(query, params);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all notifications for a specific user (sorted by created_at DESC)
    static async findAll(userId: number, limit: number = 50, offset: number = 0): Promise<Notification[]> {
        const query = `
            SELECT * FROM notifications 
            WHERE user_id = $1
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [userId, limit, offset]);
        return result.rows.map(this.mapRow);
    }

    // Get notifications by type for a specific user
    static async findByType(userId: number, type: 'alert' | 'check' | 'error' | 'info', limit: number = 50, offset: number = 0): Promise<Notification[]> {
        const query = `
            SELECT * FROM notifications 
            WHERE user_id = $1 AND type = $2
            ORDER BY created_at DESC 
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [userId, type, limit, offset]);
        return result.rows.map(this.mapRow);
    }

    // Get seen notifications for a specific user
    static async findSeen(userId: number, limit: number = 50, offset: number = 0): Promise<Notification[]> {
        const query = `
            SELECT * FROM notifications 
            WHERE user_id = $1 AND is_seen = true 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [userId, limit, offset]);
        return result.rows.map(this.mapRow);
    }

    // Get unseen notifications for a specific user
    static async findUnseen(userId: number, limit: number = 50, offset: number = 0): Promise<Notification[]> {
        const query = `
            SELECT * FROM notifications 
            WHERE user_id = $1 AND is_seen = false 
            ORDER BY created_at DESC 
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [userId, limit, offset]);
        return result.rows.map(this.mapRow);
    }

    // Mark notification as seen (optionally scoped to a user for security)
    static async markAsSeen(id: string, userId?: number): Promise<Notification | null> {
        let query: string;
        let params: any[];

        if (userId !== undefined) {
            query = `
                UPDATE notifications 
                SET is_seen = true 
                WHERE id = $1 AND user_id = $2
                RETURNING id
            `;
            params = [id, userId];
        } else {
            query = `
                UPDATE notifications 
                SET is_seen = true 
                WHERE id = $1
                RETURNING id
            `;
            params = [id];
        }

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return null;
        return await this.findById(id, userId);
    }

    // Mark notification as unseen (optionally scoped to a user for security)
    static async markAsUnseen(id: string, userId?: number): Promise<Notification | null> {
        let query: string;
        let params: any[];

        if (userId !== undefined) {
            query = `
                UPDATE notifications 
                SET is_seen = false 
                WHERE id = $1 AND user_id = $2
                RETURNING id
            `;
            params = [id, userId];
        } else {
            query = `
                UPDATE notifications 
                SET is_seen = false 
                WHERE id = $1
                RETURNING id
            `;
            params = [id];
        }

        const result = await pool.query(query, params);
        if (result.rows.length === 0) return null;
        return await this.findById(id, userId);
    }

    // Mark all notifications as seen for a specific user
    static async markAllAsSeen(userId: number): Promise<number> {
        const query = `
            UPDATE notifications 
            SET is_seen = true 
            WHERE user_id = $1 AND is_seen = false
        `;
        const result = await pool.query(query, [userId]);
        return result.rowCount ?? 0;
    }

    // Count total notifications for a specific user
    static async count(userId: number): Promise<number> {
        const query = 'SELECT COUNT(*) as count FROM notifications WHERE user_id = $1';
        const result = await pool.query(query, [userId]);
        return parseInt(result.rows[0].count);
    }

    // Count unseen notifications for a specific user
    static async countUnseen(userId: number): Promise<number> {
        const query = 'SELECT COUNT(*) as count FROM notifications WHERE user_id = $1 AND is_seen = false';
        const result = await pool.query(query, [userId]);
        return parseInt(result.rows[0].count);
    }

    // Search notifications by title or description for a specific user
    static async search(userId: number, searchTerm: string, limit: number = 50, offset: number = 0): Promise<Notification[]> {
        const query = `
            SELECT * FROM notifications 
            WHERE user_id = $1 AND (title ILIKE $2 OR description ILIKE $2)
            ORDER BY created_at DESC 
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [userId, `%${searchTerm}%`, limit, offset]);
        return result.rows.map(this.mapRow);
    }
}
