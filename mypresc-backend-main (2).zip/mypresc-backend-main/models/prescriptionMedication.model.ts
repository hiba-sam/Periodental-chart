import pool from '../db';
import { MedicationModel, type Medication } from './medication.model';

export interface PrescriptionMedication {
    id: number;
    medication_id: number;
    quantity: number;
    dosage: string;
    note: string;
    is_custom?: boolean;
    custom_medication_id?: number;
    created_at: Date;
    updated_at: Date;
}

export interface PrescriptionMedicationWithDetails extends PrescriptionMedication {
    medication: Medication;
}

export interface CreatePrescriptionMedicationData {
    medication_id: number | null;
    quantity: number;
    dosage: string;
    note: string;
    is_custom?: boolean;
    custom_medication_id?: number;
}

export interface UpdatePrescriptionMedicationData {
    medication_id?: number | null;
    quantity?: number;
    dosage?: string;
    note? : string
}

export class PrescriptionMedicationModel {
    // Create a new prescription medication
    static async create(data: CreatePrescriptionMedicationData): Promise<PrescriptionMedication> {
        const query = `
            INSERT INTO prescription_medications (
                medication_id, quantity, dosage, note, is_custom, custom_medication_id
            ) VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `;
        
        const values = [
            data.medication_id,
            data.quantity,
            data.dosage,
            data.note,
            data.is_custom || false,
            data.custom_medication_id || null
        ];
        
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find prescription medication by ID
    static async findById(id: number): Promise<PrescriptionMedication | null> {
        const query = 'SELECT * FROM prescription_medications WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find prescription medication by ID with medication details
    static async findByIdWithDetails(id: number): Promise<PrescriptionMedicationWithDetails | null> {
        // First check if it's a custom medication
        const checkQuery = 'SELECT is_custom, custom_medication_id FROM prescription_medications WHERE id = $1';
        const checkResult = await pool.query(checkQuery, [id]);
        
        if (checkResult.rows.length === 0) return null;
        
        const { is_custom, custom_medication_id } = checkResult.rows[0];
        
        if (is_custom && custom_medication_id) {
            // Query for custom medication
            const customQuery = `
                SELECT 
                    pm.*,
                    cm.nom_de_marque, cm.denomination_commune_internationale,
                    cm.dosage as med_dosage, cm.forme, cm.laboratoire
                FROM prescription_medications pm
                JOIN custom_medications cm ON pm.custom_medication_id = cm.id
                WHERE pm.id = $1
            `;
            const result = await pool.query(customQuery, [id]);
            
            if (result.rows.length === 0) return null;
            
            const row = result.rows[0];
            return {
                id: row.id,
                medication_id: row.medication_id,
                quantity: row.quantity,
                dosage: row.dosage,
                note: row.note,
                is_custom: true,
                custom_medication_id: row.custom_medication_id,
                created_at: row.created_at,
                updated_at: row.updated_at,
                medication: {
                    id: row.custom_medication_id,
                    num_enregistrement: null,
                    code: null,
                    denomination_commune_internationale: row.denomination_commune_internationale,
                    nom_de_marque: row.nom_de_marque,
                    forme: row.forme,
                    dosage: row.med_dosage,
                    cond: null,
                    liste: null,
                    p1: null,
                    p2: null,
                    obs: null,
                    laboratoire: row.laboratoire,
                    pays_laboratoire: null,
                    date_enregistrement_initial: null,
                    date_enregistrement_final: null,
                    type: null,
                    statut: null,
                    duree_stabilite: null,
                    prix: null,
                    remboursement: null,
                    created_at: row.created_at,
                    updated_at: row.updated_at
                }
            };
        }
        
        // Standard medication query
        const query = `
            SELECT 
                pm.*,
                m.num_enregistrement, m.code, m.denomination_commune_internationale,
                m.nom_de_marque, m.forme, m.dosage as med_dosage, m.cond, m.liste,
                m.p1, m.p2, m.obs, m.laboratoire, m.pays_laboratoire,
                m.date_enregistrement_initial, m.date_enregistrement_final,
                m.type, m.statut, m.duree_stabilite, m.prix, m.remboursement,
                m.created_at as med_created_at, m.updated_at as med_updated_at
            FROM prescription_medications pm
            JOIN medications m ON pm.medication_id = m.id
            WHERE pm.id = $1
        `;
        const result = await pool.query(query, [id]);
        
        if (result.rows.length === 0) return null;
        
        const row = result.rows[0];
        return {
            id: row.id,
            medication_id: row.medication_id,
            quantity: row.quantity,
            dosage: row.dosage,
            note: row.note,
            is_custom: false,
            created_at: row.created_at,
            updated_at: row.updated_at,
            medication: {
                id: row.medication_id,
                num_enregistrement: row.num_enregistrement,
                code: row.code,
                denomination_commune_internationale: row.denomination_commune_internationale,
                nom_de_marque: row.nom_de_marque,
                forme: row.forme,
                dosage: row.med_dosage,
                cond: row.cond,
                liste: row.liste,
                p1: row.p1,
                p2: row.p2,
                obs: row.obs,
                laboratoire: row.laboratoire,
                pays_laboratoire: row.pays_laboratoire,
                date_enregistrement_initial: row.date_enregistrement_initial,
                date_enregistrement_final: row.date_enregistrement_final,
                type: row.type,
                statut: row.statut,
                duree_stabilite: row.duree_stabilite,
                prix: row.prix,
                remboursement: row.remboursement,
                created_at: row.med_created_at,
                updated_at: row.med_updated_at
            }
        };
    }

    // Update prescription medication
    static async update(id: number, data: UpdatePrescriptionMedicationData): Promise<PrescriptionMedication | null> {
        const fields = [] as string[];
        const values = [] as any[];
        let paramCount = 1;

        if (data.medication_id !== undefined) {
            fields.push(`medication_id = $${paramCount++}`);
            values.push(data.medication_id);
        }
        if (data.quantity !== undefined) {
            fields.push(`quantity = $${paramCount++}`);
            values.push(data.quantity);
        }
        if (data.dosage !== undefined) {
            fields.push(`dosage = $${paramCount++}`);
            values.push(data.dosage);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE prescription_medications SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`;
        
        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Delete prescription medication
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM prescription_medications WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Find prescription medications by medication ID
    static async findByMedicationId(medicationId: number): Promise<PrescriptionMedication[]> {
        const query = `
            SELECT * FROM prescription_medications 
            WHERE medication_id = $1 
            ORDER BY created_at DESC
        `;
        const result = await pool.query(query, [medicationId]);
        return result.rows;
    }
} 