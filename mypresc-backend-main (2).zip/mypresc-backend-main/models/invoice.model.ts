import pool from '../db';

export interface Invoice {
    id: number;
    invoice_number: string;
    payment_id: number;
    doctor_user_id: number;
    plan: string;
    amount: number;
    currency: string;
    tax_amount: number;
    total_amount: number;
    invoice_date: Date;
    pdf_path: string | null;
    metadata: Record<string, unknown> | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreateInvoiceData {
    invoice_number: string;
    payment_id: number;
    doctor_user_id: number;
    plan: string;
    amount: number;
    currency?: string;
    tax_amount?: number;
    total_amount: number;
    invoice_date?: Date;
    pdf_path?: string;
    metadata?: Record<string, unknown>;
}

export interface UpdateInvoiceData {
    pdf_path?: string;
    metadata?: Record<string, unknown>;
}

export class InvoiceModel {
    // Generate unique invoice number
    static async generateInvoiceNumber(): Promise<string> {
        const year = new Date().getFullYear();

        // Get the count of invoices for this year
        const result = await pool.query(
            `SELECT COUNT(*) as count FROM invoices WHERE EXTRACT(YEAR FROM invoice_date) = $1`,
            [year]
        );

        const count = parseInt(result.rows[0].count) + 1;
        const paddedCount = count.toString().padStart(6, '0');

        return `INV-${year}-${paddedCount}`;
    }

    // Create a new invoice
    static async create(invoiceData: CreateInvoiceData): Promise<Invoice> {
        const query = `
            INSERT INTO invoices (
                invoice_number, payment_id, doctor_user_id, plan,
                amount, currency, tax_amount, total_amount,
                invoice_date, pdf_path, metadata
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            RETURNING *
        `;

        const values = [
            invoiceData.invoice_number,
            invoiceData.payment_id,
            invoiceData.doctor_user_id,
            invoiceData.plan,
            invoiceData.amount,
            invoiceData.currency || 'DZD',
            invoiceData.tax_amount || 0,
            invoiceData.total_amount,
            invoiceData.invoice_date || new Date(),
            invoiceData.pdf_path || null,
            invoiceData.metadata ? JSON.stringify(invoiceData.metadata) : null
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find invoice by ID
    static async findById(id: number): Promise<Invoice | null> {
        const query = 'SELECT * FROM invoices WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find invoice by invoice number
    static async findByInvoiceNumber(invoiceNumber: string): Promise<Invoice | null> {
        const query = 'SELECT * FROM invoices WHERE invoice_number = $1';
        const result = await pool.query(query, [invoiceNumber]);
        return result.rows[0] || null;
    }

    // Find invoice by payment ID
    static async findByPaymentId(paymentId: number): Promise<Invoice | null> {
        const query = 'SELECT * FROM invoices WHERE payment_id = $1';
        const result = await pool.query(query, [paymentId]);
        return result.rows[0] || null;
    }

    // Find all invoices for a doctor
    static async findByDoctorUserId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<Invoice[]> {
        const query = `
            SELECT * FROM invoices
            WHERE doctor_user_id = $1
            ORDER BY invoice_date DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset]);
        return result.rows;
    }

    // Update invoice
    static async update(id: number, invoiceData: UpdateInvoiceData): Promise<Invoice | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (invoiceData.pdf_path !== undefined) {
            fields.push(`pdf_path = $${idx++}`);
            values.push(invoiceData.pdf_path);
        }
        if (invoiceData.metadata !== undefined) {
            fields.push(`metadata = $${idx++}`);
            values.push(JSON.stringify(invoiceData.metadata));
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE invoices SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Get all invoices with filters
    static async findAll(
        filters?: {
            plan?: string;
            limit?: number;
            offset?: number;
        }
    ): Promise<Invoice[]> {
        let query = 'SELECT * FROM invoices WHERE 1=1';
        const values: any[] = [];
        let idx = 1;

        if (filters?.plan) {
            query += ` AND plan = $${idx++}`;
            values.push(filters.plan);
        }

        query += ` ORDER BY invoice_date DESC LIMIT $${idx++} OFFSET $${idx++}`;
        values.push(filters?.limit || 50);
        values.push(filters?.offset || 0);

        const result = await pool.query(query, values);
        return result.rows;
    }

    // Delete an invoice
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM invoices WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }
}
