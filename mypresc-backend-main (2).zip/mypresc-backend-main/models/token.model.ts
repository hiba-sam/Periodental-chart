import pool from '../db';

export interface Token {
    id: number;
    user_id: number;
    token: string;
    type: 'registration' | 'verify' | 'reset';
    expires_at: Date;
    is_used: boolean;
    created_at: Date;
}

export interface CreateTokenData {
    user_id: number;
    token: string;
    type: 'registration' | 'verify' | 'reset';
    expires_at: Date;
}

export class TokenModel {
    static async create(tokenData: CreateTokenData): Promise<Token> {
        const query = `
            INSERT INTO tokens (user_id, token, type, expires_at)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        
        const result = await pool.query(query, [
            tokenData.user_id,
            tokenData.token,
            tokenData.type,
            tokenData.expires_at
        ]);
        
        return result.rows[0];
    }

    static async findByToken(token: string): Promise<Token | null> {
        const query = 'SELECT * FROM tokens WHERE token = $1 AND is_used = false AND expires_at > NOW()';
        const result = await pool.query(query, [token]);
        return result.rows[0] || null;
    }

    static async markAsUsed(token: string): Promise<boolean> {
        const query = 'UPDATE tokens SET is_used = true WHERE token = $1';
        const result = await pool.query(query, [token]);
        return (result.rowCount ?? 0) > 0;
    }

    static async deleteExpiredTokens(): Promise<void> {
        const query = 'DELETE FROM tokens WHERE expires_at < NOW()';
        await pool.query(query);
    }
} 