import pool from '../db.js';

export type DentalActScope = 'TOOTH' | 'MOUTH';
export type DentalActStatus = 'NON_COMMENCE' | 'EN_COURS' | 'TERMINE' | 'ANNULE';

export interface DentalAct {
    id: number;
    patient_id: string;
    doctor_user_id: number;
    scope: DentalActScope;
    teeth: string[] | null;
    surfaces: string[] | null;
    act_catalog_id: number | null;
    act_label_cache: string | null;
    act_code_cache: string | null;
    status: DentalActStatus;
    date_act: Date;
    notes: string | null;
    created_by: number | null;
    created_at: Date;
    updated_by: number | null;
    updated_at: Date;
    // Joined fields
    doctor_name?: string;
    doctor_family_name?: string;
    act_label?: string;
    act_code?: string;
}

export interface CreateDentalActData {
    patient_id: string;
    doctor_user_id: number;
    scope: DentalActScope;
    teeth?: string[];
    surfaces?: string[];
    act_catalog_id?: number;
    act_label_cache?: string;
    act_code_cache?: string;
    status?: DentalActStatus;
    date_act?: Date | string;
    notes?: string;
    created_by: number;
}

export interface UpdateDentalActData {
    scope?: DentalActScope;
    teeth?: string[] | null;
    surfaces?: string[] | null;
    act_catalog_id?: number;
    act_label_cache?: string;
    act_code_cache?: string;
    status?: DentalActStatus;
    date_act?: Date | string;
    notes?: string;
    updated_by: number;
}

export interface DentalActFilters {
    status?: DentalActStatus;
    fromDate?: string;
    toDate?: string;
    tooth?: string;
}

export class DentalActModel {
    /**
     * Create a new dental act
     */
    static async create(data: CreateDentalActData): Promise<DentalAct> {
        const query = `
            INSERT INTO dental_acts (
                patient_id, doctor_user_id, scope, teeth, surfaces,
                act_catalog_id, act_label_cache, act_code_cache,
                status, date_act, notes, created_by
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING *
        `;
        
        const values = [
            data.patient_id,
            data.doctor_user_id,
            data.scope,
            data.teeth || null,
            data.surfaces || null,
            data.act_catalog_id || null,
            data.act_label_cache || null,
            data.act_code_cache || null,
            data.status || 'NON_COMMENCE',
            data.date_act || new Date(),
            data.notes || null,
            data.created_by
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    /**
     * Get dental acts for a patient with optional filters
     */
    static async findByPatient(
        patientId: string, 
        filters?: DentalActFilters
    ): Promise<DentalAct[]> {
        let whereConditions = ['da.patient_id = $1'];
        let queryParams: any[] = [patientId];
        let paramIndex = 2;

        if (filters?.status) {
            whereConditions.push(`da.status = $${paramIndex}`);
            queryParams.push(filters.status);
            paramIndex++;
        }

        if (filters?.fromDate) {
            whereConditions.push(`da.date_act >= $${paramIndex}`);
            queryParams.push(filters.fromDate);
            paramIndex++;
        }

        if (filters?.toDate) {
            whereConditions.push(`da.date_act <= $${paramIndex}`);
            queryParams.push(filters.toDate);
            paramIndex++;
        }

        if (filters?.tooth) {
            whereConditions.push(`$${paramIndex} = ANY(da.teeth)`);
            queryParams.push(filters.tooth);
            paramIndex++;
        }

        const query = `
            SELECT 
                da.*,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                COALESCE(ac.label, da.act_label_cache) as act_label,
                COALESCE(ac.code_ccam, da.act_code_cache) as act_code
            FROM dental_acts da
            LEFT JOIN users u ON da.doctor_user_id = u.id
            LEFT JOIN act_catalog ac ON da.act_catalog_id = ac.id
            WHERE ${whereConditions.join(' AND ')}
            ORDER BY da.date_act DESC, da.created_at DESC
        `;

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    /**
     * Get dental act by ID with details
     */
    static async findById(id: number): Promise<DentalAct | null> {
        const query = `
            SELECT 
                da.*,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                COALESCE(ac.label, da.act_label_cache) as act_label,
                COALESCE(ac.code_ccam, da.act_code_cache) as act_code,
                cu.name as created_by_name,
                cu.family_name as created_by_family_name,
                uu.name as updated_by_name,
                uu.family_name as updated_by_family_name
            FROM dental_acts da
            LEFT JOIN users u ON da.doctor_user_id = u.id
            LEFT JOIN act_catalog ac ON da.act_catalog_id = ac.id
            LEFT JOIN users cu ON da.created_by = cu.id
            LEFT JOIN users uu ON da.updated_by = uu.id
            WHERE da.id = $1
        `;

        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    /**
     * Update a dental act
     */
    static async update(id: number, data: UpdateDentalActData): Promise<DentalAct | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let paramIndex = 1;

        if (data.scope !== undefined) {
            fields.push(`scope = $${paramIndex++}`);
            values.push(data.scope);
        }
        if (data.teeth !== undefined) {
            fields.push(`teeth = $${paramIndex++}`);
            values.push(data.teeth);
        }
        if (data.surfaces !== undefined) {
            fields.push(`surfaces = $${paramIndex++}`);
            values.push(data.surfaces);
        }
        if (data.act_catalog_id !== undefined) {
            fields.push(`act_catalog_id = $${paramIndex++}`);
            values.push(data.act_catalog_id);
        }
        if (data.act_label_cache !== undefined) {
            fields.push(`act_label_cache = $${paramIndex++}`);
            values.push(data.act_label_cache);
        }
        if (data.act_code_cache !== undefined) {
            fields.push(`act_code_cache = $${paramIndex++}`);
            values.push(data.act_code_cache);
        }
        if (data.status !== undefined) {
            fields.push(`status = $${paramIndex++}`);
            values.push(data.status);
        }
        if (data.date_act !== undefined) {
            fields.push(`date_act = $${paramIndex++}`);
            values.push(data.date_act);
        }
        if (data.notes !== undefined) {
            fields.push(`notes = $${paramIndex++}`);
            values.push(data.notes);
        }

        fields.push(`updated_by = $${paramIndex++}`);
        values.push(data.updated_by);

        if (fields.length === 1) {
            // Only updated_by, nothing to update
            return this.findById(id);
        }

        values.push(id);
        const query = `
            UPDATE dental_acts 
            SET ${fields.join(', ')}
            WHERE id = $${paramIndex}
            RETURNING *
        `;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    /**
     * Delete a dental act
     */
    static async delete(id: number): Promise<boolean> {
        const result = await pool.query(
            'DELETE FROM dental_acts WHERE id = $1',
            [id]
        );
        return (result.rowCount || 0) > 0;
    }

    /**
     * Check if user has access to dental act
     */
    static async checkAccess(actId: number, userId: number): Promise<boolean> {
        const result = await pool.query(
            'SELECT 1 FROM dental_acts WHERE id = $1 AND doctor_user_id = $2',
            [actId, userId]
        );
        return result.rows.length > 0;
    }

    /**
     * Get statistics for a patient's dental acts
     */
    static async getPatientStats(patientId: string): Promise<{
        total: number;
        byStatus: Record<string, number>;
        teethTreated: string[];
    }> {
        const statsQuery = `
            SELECT 
                COUNT(*) as total,
                COUNT(*) FILTER (WHERE status = 'NON_COMMENCE') as non_commence,
                COUNT(*) FILTER (WHERE status = 'EN_COURS') as en_cours,
                COUNT(*) FILTER (WHERE status = 'TERMINE') as termine,
                COUNT(*) FILTER (WHERE status = 'ANNULE') as annule
            FROM dental_acts
            WHERE patient_id = $1
        `;
        
        const teethQuery = `
            SELECT DISTINCT unnest(teeth) as tooth
            FROM dental_acts
            WHERE patient_id = $1 AND teeth IS NOT NULL
            ORDER BY tooth
        `;

        const [statsResult, teethResult] = await Promise.all([
            pool.query(statsQuery, [patientId]),
            pool.query(teethQuery, [patientId])
        ]);

        const stats = statsResult.rows[0];
        return {
            total: parseInt(stats.total),
            byStatus: {
                NON_COMMENCE: parseInt(stats.non_commence),
                EN_COURS: parseInt(stats.en_cours),
                TERMINE: parseInt(stats.termine),
                ANNULE: parseInt(stats.annule)
            },
            teethTreated: teethResult.rows.map(r => r.tooth)
        };
    }
}
