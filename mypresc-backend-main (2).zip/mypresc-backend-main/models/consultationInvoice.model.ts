import pool from '../db';

export interface ConsultationInvoiceItem {
    id: number;
    invoice_id: number;
    tarification_id?: number;
    label: string;
    price: number;
    created_at: Date;
}

export interface ConsultationInvoice {
    id: number;
    doctor_user_id: number;
    patient_id: string; // UUID
    total_price: number;
    amount_paid: number;
    status: 'paid' | 'unpaid' | 'partial' | 'free';
    items?: ConsultationInvoiceItem[];
    created_at: Date;
    updated_at: Date;
}

export interface CreateInvoiceItemData {
    tarification_id?: number;
    label: string;
    price: number;
}

export interface CreateInvoiceData {
    doctor_user_id: number;
    patient_id: string;
    total_price: number;
    items: CreateInvoiceItemData[];
    status?: 'paid' | 'unpaid' | 'partial' | 'free';
}

export class ConsultationInvoiceModel {
    /**
     * Create a new invoice
     */
    static async create(data: CreateInvoiceData): Promise<ConsultationInvoice> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            // 1. Create invoice
            const invoiceQuery = `
                INSERT INTO consultation_invoices (doctor_user_id, patient_id, total_price, status)
                VALUES ($1, $2, $3, $4)
                RETURNING *
            `;
            const invoiceResult = await client.query(invoiceQuery, [
                data.doctor_user_id,
                data.patient_id,
                data.total_price,
                data.status || 'unpaid'
            ]);
            const invoice = invoiceResult.rows[0];

            // 2. Create invoice items
            const items: ConsultationInvoiceItem[] = [];

            if (data.items && data.items.length > 0) {
                const itemValues = data.items.map((_, i) =>
                    `($1, $${i * 3 + 2}, $${i * 3 + 3}, $${i * 3 + 4})`
                ).join(',');

                const queryParams = [invoice.id];
                data.items.forEach(item => {
                    queryParams.push(item.tarification_id as any);
                    queryParams.push(item.label as any);
                    queryParams.push(item.price as any);
                });

                const itemsQuery = `
                    INSERT INTO consultation_invoice_items (invoice_id, tarification_id, label, price)
                    VALUES ${itemValues}
                    RETURNING *
                `;

                const itemsResult = await client.query(itemsQuery, queryParams);
                items.push(...itemsResult.rows);
            }

            await client.query('COMMIT');

            return {
                ...invoice,
                items
            };

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    /**
     * Get invoices by Patient ID
     */
    static async findByPatientId(patientId: string): Promise<ConsultationInvoice[]> {
        const query = `
            SELECT 
                ci.*,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', cii.id,
                            'tarification_id', cii.tarification_id,
                            'label', cii.label,
                            'price', cii.price
                        )
                    ) FILTER (WHERE cii.id IS NOT NULL),
                    '[]'
                ) as items
            FROM consultation_invoices ci
            LEFT JOIN consultation_invoice_items cii ON ci.id = cii.invoice_id
            WHERE ci.patient_id = $1
            GROUP BY ci.id
            ORDER BY ci.created_at DESC
        `;

        const result = await pool.query(query, [patientId]);
        return result.rows;
    }

    /**
     * Get invoices by Patient ID and Doctor User ID
     * Each doctor sees only their own invoices for a patient
     */
    static async findByPatientAndDoctor(patientId: string, doctorUserId: number): Promise<ConsultationInvoice[]> {
        const query = `
            SELECT 
                ci.*,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', cii.id,
                            'tarification_id', cii.tarification_id,
                            'label', cii.label,
                            'price', cii.price
                        )
                    ) FILTER (WHERE cii.id IS NOT NULL),
                    '[]'
                ) as items
            FROM consultation_invoices ci
            LEFT JOIN consultation_invoice_items cii ON ci.id = cii.invoice_id
            WHERE ci.patient_id = $1 AND ci.doctor_user_id = $2
            GROUP BY ci.id
            ORDER BY ci.created_at DESC
        `;

        const result = await pool.query(query, [patientId, doctorUserId]);
        return result.rows;
    }

    /**
     * Get invoices by Doctor User ID (recent first)
     */
    static async findByDoctorId(doctorUserId: number, limit: number = 20): Promise<ConsultationInvoice[]> {
        const query = `
            SELECT 
                ci.*,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', cii.id,
                            'tarification_id', cii.tarification_id,
                            'label', cii.label,
                            'price', cii.price
                        )
                    ) FILTER (WHERE cii.id IS NOT NULL),
                    '[]'
                ) as items
            FROM consultation_invoices ci
            LEFT JOIN consultation_invoice_items cii ON ci.id = cii.invoice_id
            WHERE ci.doctor_user_id = $1
            GROUP BY ci.id
            ORDER BY ci.created_at DESC
            LIMIT $2
        `;

        const result = await pool.query(query, [doctorUserId, limit]);
        return result.rows;
    }

    /**
     * Update invoice status
     */
    static async updateStatus(id: number, status: 'paid' | 'unpaid' | 'partial', doctorUserId: number): Promise<ConsultationInvoice | null> {
        const query = `
            UPDATE consultation_invoices 
            SET status = $1, updated_at = NOW()
            WHERE id = $2 AND doctor_user_id = $3
            RETURNING *
        `;
        const result = await pool.query(query, [status, id, doctorUserId]);
        return result.rows[0] || null;
    }

    /**
     * Add a payment to an invoice (supports partial payments)
     * Automatically updates status based on amount_paid vs total_price
     */
    static async addPayment(id: number, paymentAmount: number, doctorUserId: number): Promise<ConsultationInvoice | null> {
        const query = `
            UPDATE consultation_invoices 
            SET 
                amount_paid = amount_paid + $1,
                status = CASE 
                    WHEN (amount_paid + $1) >= total_price THEN 'paid'
                    WHEN (amount_paid + $1) > 0 THEN 'partial'
                    ELSE 'unpaid'
                END,
                updated_at = NOW()
            WHERE id = $2 AND doctor_user_id = $3
            RETURNING *
        `;
        const result = await pool.query(query, [paymentAmount, id, doctorUserId]);
        return result.rows[0] || null;
    }

    /**
     * Distribute a payment across multiple unpaid invoices for a patient
     * Pays oldest invoices first, then applies remaining to next invoice
     * Returns the list of updated invoices and any remaining amount
     */
    static async distributePayment(
        patientId: string,
        totalAmount: number,
        doctorUserId: number
    ): Promise<{ updatedInvoices: ConsultationInvoice[], remainingAmount: number, appliedPayments: Array<{ invoiceId: number, amount: number }> }> {
        // Get all unpaid/partial invoices for this patient, ordered by oldest first
        const invoicesQuery = `
            SELECT id, total_price, amount_paid, status
            FROM consultation_invoices
            WHERE patient_id = $1 AND doctor_user_id = $2 AND status IN ('unpaid', 'partial')
            ORDER BY created_at ASC
        `;
        const invoicesResult = await pool.query(invoicesQuery, [patientId, doctorUserId]);
        const invoices = invoicesResult.rows;

        let remainingAmount = totalAmount;
        const updatedInvoices: ConsultationInvoice[] = [];
        const appliedPayments: Array<{ invoiceId: number, amount: number }> = [];

        for (const invoice of invoices) {
            if (remainingAmount <= 0) break;

            const totalPrice = parseFloat(invoice.total_price);
            const amountPaid = parseFloat(invoice.amount_paid);
            const amountDue = totalPrice - amountPaid;

            if (amountDue <= 0) continue;

            // Calculate how much to apply to this invoice
            const paymentToApply = Math.min(remainingAmount, amountDue);
            remainingAmount -= paymentToApply;

            // Update the invoice
            const updatedInvoice = await this.addPayment(invoice.id, paymentToApply, doctorUserId);
            if (updatedInvoice) {
                updatedInvoices.push(updatedInvoice);
                appliedPayments.push({ invoiceId: invoice.id, amount: paymentToApply });
            }
        }

        return { updatedInvoices, remainingAmount, appliedPayments };
    }

    /**
     * Get invoice by ID with items
     */
    static async findById(id: number, doctorUserId: number): Promise<ConsultationInvoice | null> {
        const query = `
            SELECT 
                ci.*,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', cii.id,
                            'tarification_id', cii.tarification_id,
                            'label', cii.label,
                            'price', cii.price
                        )
                    ) FILTER (WHERE cii.id IS NOT NULL),
                    '[]'
                ) as items
            FROM consultation_invoices ci
            LEFT JOIN consultation_invoice_items cii ON ci.id = cii.invoice_id
            WHERE ci.id = $1 AND ci.doctor_user_id = $2
            GROUP BY ci.id
        `;
        const result = await pool.query(query, [id, doctorUserId]);
        return result.rows[0] || null;
    }

    /**
     * Delete invoice
     */
    static async delete(id: number, doctorUserId: number): Promise<{ success: boolean, patient_id?: string }> {
        const query = 'DELETE FROM consultation_invoices WHERE id = $1 AND doctor_user_id = $2 RETURNING patient_id';
        const result = await pool.query(query, [id, doctorUserId]);
        if (result.rowCount && result.rowCount > 0) {
            return { success: true, patient_id: result.rows[0].patient_id };
        }
        return { success: false };
    }

    /**
     * Get invoices created today for a specific doctor
     * Returns invoices with patient details (name, family_name)
     */
    static async findTodayInvoicesByDoctorId(doctorUserId: number): Promise<any[]> {
        const query = `
            SELECT 
                ci.*,
                pgp_sym_decrypt(p.name, $2) as patient_name,
                pgp_sym_decrypt(p.family_name, $2) as patient_family_name,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', cii.id,
                            'tarification_id', cii.tarification_id,
                            'label', cii.label,
                            'price', cii.price
                        )
                    ) FILTER (WHERE cii.id IS NOT NULL),
                    '[]'
                ) as items
            FROM consultation_invoices ci
            JOIN patients p ON ci.patient_id = p.id
            LEFT JOIN consultation_invoice_items cii ON ci.id = cii.invoice_id
            WHERE ci.doctor_user_id = $1
              AND ci.created_at::date = CURRENT_DATE
            GROUP BY ci.id, p.id
            ORDER BY ci.created_at DESC
        `;

        const result = await pool.query(query, [doctorUserId, process.env.ENCRYPTION_KEY]);
        return result.rows;
    }

    /**
     * Get unpaid invoices grouped by patient for a doctor
     * Returns patients with their total unpaid amount and invoice details
     */
    static async findUnpaidGroupedByPatient(doctorUserId: number, searchTerm?: string): Promise<any[]> {
        let query = `
            SELECT 
                ci.patient_id,
                pgp_sym_decrypt(p.name, $2) as patient_name,
                pgp_sym_decrypt(p.family_name, $2) as patient_family_name,
                SUM(ci.total_price - COALESCE(ci.amount_paid, 0)) as total_unpaid,
                COUNT(ci.id) as invoice_count,
                json_agg(
                    json_build_object(
                        'id', ci.id,
                        'total_price', ci.total_price,
                        'amount_paid', COALESCE(ci.amount_paid, 0),
                        'status', ci.status,
                        'created_at', ci.created_at,
                        'items', (
                            SELECT COALESCE(
                                json_agg(
                                    json_build_object(
                                        'id', cii.id,
                                        'tarification_id', cii.tarification_id,
                                        'label', cii.label,
                                        'price', cii.price
                                    )
                                ),
                                '[]'
                            )
                            FROM consultation_invoice_items cii
                            WHERE cii.invoice_id = ci.id
                        )
                    ) ORDER BY ci.created_at DESC
                ) as invoices
            FROM consultation_invoices ci
            JOIN patients p ON ci.patient_id = p.id
            WHERE ci.doctor_user_id = $1
              AND ci.status IN ('unpaid', 'partial')
        `;

        const params: any[] = [doctorUserId, process.env.ENCRYPTION_KEY];

        if (searchTerm && searchTerm.trim()) {
            query += `
              AND (
                pgp_sym_decrypt(p.name, $2) ILIKE $3
                OR pgp_sym_decrypt(p.family_name, $2) ILIKE $3
              )
            `;
            params.push(`%${searchTerm.trim()}%`);
        }

        query += `
            GROUP BY ci.patient_id, p.id
            ORDER BY total_unpaid DESC
        `;

        const result = await pool.query(query, params);
        return result.rows;
    }

    /**
     * Get financial statistics for a doctor
     * Returns weekly, monthly, and yearly revenue based on amount_paid (includes partial payments)
     */
    static async getStatistics(doctorUserId: number) {
        // 1. Weekly Data (Last 7 days including today)
        // Uses amount_paid to include partial payments
        const weeklyQuery = `
            SELECT 
                to_char(created_at, 'YYYY-MM-DD') as date,
                SUM(amount_paid) as total
            FROM consultation_invoices
            WHERE doctor_user_id = $1 
              AND amount_paid > 0
              AND created_at >= NOW() - INTERVAL '6 days'
            GROUP BY to_char(created_at, 'YYYY-MM-DD')
            ORDER BY date ASC
        `;

        // 2. Monthly Data (Last 12 months)
        const monthlyQuery = `
            SELECT 
                to_char(created_at, 'YYYY-MM') as month,
                SUM(amount_paid) as total
            FROM consultation_invoices
            WHERE doctor_user_id = $1
              AND amount_paid > 0
              AND created_at >= date_trunc('month', NOW() - INTERVAL '11 months')
            GROUP BY to_char(created_at, 'YYYY-MM')
            ORDER BY month ASC
        `;

        // 3. Yearly Data (Last 5 years)
        const yearlyQuery = `
            SELECT 
                to_char(created_at, 'YYYY') as year,
                SUM(amount_paid) as total
            FROM consultation_invoices
            WHERE doctor_user_id = $1
              AND amount_paid > 0
              AND created_at >= date_trunc('year', NOW() - INTERVAL '4 years')
            GROUP BY to_char(created_at, 'YYYY')
            ORDER BY year ASC
        `;

        const [weeklyRes, monthlyRes, yearlyRes] = await Promise.all([
            pool.query(weeklyQuery, [doctorUserId]),
            pool.query(monthlyQuery, [doctorUserId]),
            pool.query(yearlyQuery, [doctorUserId])
        ]);

        return {
            weekly: weeklyRes.rows,
            monthly: monthlyRes.rows,
            yearly: yearlyRes.rows
        };
    }

    /**
     * Fix invoice status in the database (used by verification service)
     * Lightweight update that only changes the status field
     */
    static async fixStatus(id: number, correctStatus: 'paid' | 'unpaid' | 'partial' | 'free'): Promise<void> {
        const query = `
            UPDATE consultation_invoices 
            SET status = $1, updated_at = NOW()
            WHERE id = $2
        `;
        await pool.query(query, [correctStatus, id]);
    }
}