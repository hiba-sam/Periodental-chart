import pool from '../db';

export interface Assistant {
    id: number;
    user_id: number | null;
    assistant_name: string;
    assistant_email: string;
    doctor_id: number;
    phone_number: string | null;
    invitation_token: string | null;
    is_active: boolean;
    created_at: Date;
    updated_at: Date;
}

export interface CreateAssistantInvitationData {
    assistant_name: string;
    assistant_email: string;
    doctor_id: number;
    invitation_token: string;
}

export interface CompleteAssistantRegistrationData {
    user_id: number;
    phone_number: string;
}

export interface UpdateAssistantData {
    assistant_name?: string;
    assistant_email?: string;
    phone_number?: string;
    is_active?: boolean;
}

export class AssistantModel {
    // Create a new assistant invitation record
    static async createInvitation(invitationData: CreateAssistantInvitationData): Promise<Assistant> {
        const query = `
            INSERT INTO assistants (
                assistant_name, assistant_email, doctor_id, invitation_token
            ) VALUES (
                $1, $2, $3, $4
            )
            RETURNING *
        `;

        const values = [
            invitationData.assistant_name,
            invitationData.assistant_email,
            invitationData.doctor_id,
            invitationData.invitation_token
        ];

        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Find assistant by invitation token
    static async findByInvitationToken(token: string): Promise<Assistant | null> {
        const query = 'SELECT * FROM assistants WHERE invitation_token = $1';
        const result = await pool.query(query, [token]);
        return result.rows[0] || null;
    }

    // Find assistant by ID
    static async findById(id: number): Promise<Assistant | null> {
        const query = 'SELECT * FROM assistants WHERE id = $1';
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find assistant by user_id
    static async findByUserId(userId: number): Promise<Assistant | null> {
        const query = 'SELECT * FROM assistants WHERE user_id = $1';
        const result = await pool.query(query, [userId]);
        return result.rows[0] || null;
    }

    // Find all assistants for a doctor
    static async findByDoctorId(doctorId: number): Promise<Assistant[]> {
        const query = `
            SELECT * FROM assistants
            WHERE doctor_id = $1
            ORDER BY created_at DESC
        `;
        const result = await pool.query(query, [doctorId]);
        return result.rows;
    }

    // Find all assistants for a doctor by user_id (for socket notifications)
    // Note: doctors table uses user_id as primary key, and assistants.doctor_id references doctors.user_id
    static async findByDoctorUserId(doctorUserId: number): Promise<Assistant[]> {
        const query = `
            SELECT a.* FROM assistants a
            WHERE a.doctor_id = $1 AND a.is_active = true
            ORDER BY a.created_at DESC
        `;
        const result = await pool.query(query, [doctorUserId]);
        return result.rows;
    }

    // Find assistant by email
    static async findByEmail(email: string): Promise<Assistant | null> {
        const query = 'SELECT * FROM assistants WHERE assistant_email = $1';
        const result = await pool.query(query, [email]);
        return result.rows[0] || null;
    }

    // Complete assistant registration (link to user account and activate)
    static async completeRegistration(
        invitationToken: string,
        registrationData: CompleteAssistantRegistrationData
    ): Promise<Assistant | null> {
        const query = `
            UPDATE assistants
            SET user_id = $1,
                phone_number = $2,
                is_active = true,
                invitation_token = NULL
            WHERE invitation_token = $3
            RETURNING *
        `;

        const values = [
            registrationData.user_id,
            registrationData.phone_number,
            invitationToken
        ];

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Update assistant profile
    static async update(id: number, assistantData: UpdateAssistantData): Promise<Assistant | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (assistantData.assistant_name !== undefined) {
            fields.push(`assistant_name = $${idx++}`);
            values.push(assistantData.assistant_name);
        }
        if (assistantData.assistant_email !== undefined) {
            fields.push(`assistant_email = $${idx++}`);
            values.push(assistantData.assistant_email);
        }
        if (assistantData.phone_number !== undefined) {
            fields.push(`phone_number = $${idx++}`);
            values.push(assistantData.phone_number);
        }
        if (assistantData.is_active !== undefined) {
            fields.push(`is_active = $${idx++}`);
            values.push(assistantData.is_active);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE assistants SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;

        const result = await pool.query(query, values);
        return result.rows[0] || null;
    }

    // Delete assistant
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM assistants WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all assistants
    static async findAll(limit: number = 50, offset: number = 0): Promise<Assistant[]> {
        const query = `
            SELECT * FROM assistants
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows;
    }

    // Get active assistants for a doctor
    static async findActiveBydoctorId(doctorId: number): Promise<Assistant[]> {
        const query = `
            SELECT * FROM assistants
            WHERE doctor_id = $1 AND is_active = true
            ORDER BY created_at DESC
        `;
        const result = await pool.query(query, [doctorId]);
        return result.rows;
    }

    // Get active assistants for a doctor by user_id
    // Note: assistants.doctor_id directly references the doctor's user_id
    static async findActiveByDoctorUserId(doctorUserId: number): Promise<Assistant[]> {
        const query = `
            SELECT a.* FROM assistants a
            WHERE a.doctor_id = $1 AND a.is_active = true
            ORDER BY a.created_at DESC
        `;
        const result = await pool.query(query, [doctorUserId]);
        return result.rows;
    }

    // Get pending invitations for a doctor
    static async findPendingByDoctorId(doctorId: number): Promise<Assistant[]> {
        const query = `
            SELECT * FROM assistants
            WHERE doctor_id = $1 AND user_id IS NULL
            ORDER BY created_at DESC
        `;
        const result = await pool.query(query, [doctorId]);
        return result.rows;
    }
}
