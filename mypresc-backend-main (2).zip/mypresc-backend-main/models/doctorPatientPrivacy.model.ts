import pool from '../db';

export interface DoctorPatientPrivacy {
    id: number;
    doctor_id: number;
    patient_id: string;
    privacy_choice: 'private' | 'shared';
    created_at: Date;
    updated_at: Date;
}

export class DoctorPatientPrivacyModel {
    
    // Get privacy choice for a doctor-patient pair
    static async getPrivacyChoice(doctorId: number, patientId: string): Promise<'private' | 'shared' | null> {
        const query = `
            SELECT privacy_choice 
            FROM doctor_patient_privacy 
            WHERE doctor_id = $1 AND patient_id = $2
        `;
        const result = await pool.query(query, [doctorId, patientId]);
        return result.rows[0]?.privacy_choice || null;
    }

    // Set privacy choice for a doctor-patient pair (upsert)
    static async setPrivacyChoice(
        doctorId: number, 
        patientId: string, 
        privacyChoice: 'private' | 'shared'
    ): Promise<DoctorPatientPrivacy> {
        const query = `
            INSERT INTO doctor_patient_privacy (doctor_id, patient_id, privacy_choice)
            VALUES ($1, $2, $3)
            ON CONFLICT (doctor_id, patient_id) 
            DO UPDATE SET privacy_choice = $3, updated_at = NOW()
            RETURNING *
        `;
        const result = await pool.query(query, [doctorId, patientId, privacyChoice]);
        return result.rows[0];
    }

    // Get all doctors who have chosen 'shared' for a patient
    // These doctors' prescriptions/reports are visible to everyone
    static async getDoctorsWithSharedChoice(patientId: string): Promise<number[]> {
        const query = `
            SELECT doctor_id 
            FROM doctor_patient_privacy 
            WHERE patient_id = $1::uuid AND privacy_choice = 'shared'
        `;
        const result = await pool.query(query, [patientId]);
        console.log(`[DoctorPatientPrivacy] Shared doctors for patient ${patientId}:`, result.rows);
        return result.rows.map(row => row.doctor_id);
    }

    // Get all doctors who have chosen 'private' for a patient
    static async getDoctorsWithPrivateChoice(patientId: string): Promise<number[]> {
        const query = `
            SELECT doctor_id 
            FROM doctor_patient_privacy 
            WHERE patient_id = $1 AND privacy_choice = 'private'
        `;
        const result = await pool.query(query, [patientId]);
        return result.rows.map(row => row.doctor_id);
    }

    // Delete privacy choice (reset to default)
    static async deletePrivacyChoice(doctorId: number, patientId: string): Promise<boolean> {
        const query = `
            DELETE FROM doctor_patient_privacy 
            WHERE doctor_id = $1 AND patient_id = $2
        `;
        const result = await pool.query(query, [doctorId, patientId]);
        return (result.rowCount ?? 0) > 0;
    }
}
