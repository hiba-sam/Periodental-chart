import pool from '../db';
import { MedicationModel, type Medication } from './medication.model';
import { CustomMedicationModel, type CustomMedication } from './customMedication.model';
import { PrescriptionMedicationModel } from './prescriptionMedication.model';
import { PrescriptionModel } from './prescription.model';

// ============================================================
// Interfaces
// ============================================================

export interface PrescriptionTypeMedication {
    id: number;
    prescription_type_id: number;
    medication_id: number | null;
    custom_medication_id: number | null;
    is_custom: boolean;
    quantity: number;
    dosage: string;
    note: string | null;
    sort_order: number;
    created_at: Date;
}

export interface PrescriptionTypeMedicationWithDetails extends PrescriptionTypeMedication {
    medication: Medication | CustomMedication | null;
    // Denormalized fields for convenience
    nom_de_marque: string;
    denomination_commune_internationale: string;
    med_dosage: string | null; // dosage from the medication record itself
}

export interface PrescriptionType {
    id: number;
    name: string;
    description: string | null;
    doctor_user_id: number;
    created_at: Date;
    updated_at: Date;
}

export interface PrescriptionTypeWithMedications extends PrescriptionType {
    medications: PrescriptionTypeMedicationWithDetails[];
}

export interface CreatePrescriptionTypeData {
    name: string;
    description?: string;
    doctor_user_id: number;
    medications: Array<{
        medication_id: number | null;
        custom_medication_id?: number | null;
        is_custom: boolean;
        quantity: number;
        dosage: string;
        note?: string;
        sort_order?: number;
    }>;
}

export interface UpdatePrescriptionTypeData {
    name?: string;
    description?: string;
    medications?: Array<{
        medication_id: number | null;
        custom_medication_id?: number | null;
        is_custom: boolean;
        quantity: number;
        dosage: string;
        note?: string;
        sort_order?: number;
    }>;
}

// ============================================================
// Model
// ============================================================

export class PrescriptionTypeModel {

    /**
     * Create a new prescription type (template) with its medications.
     * Wrapped in a transaction.
     */
    static async create(data: CreatePrescriptionTypeData): Promise<PrescriptionTypeWithMedications> {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Insert the type header
            const typeResult = await client.query(
                `INSERT INTO prescription_types (name, description, doctor_user_id)
                 VALUES ($1, $2, $3) RETURNING *`,
                [data.name, data.description || null, data.doctor_user_id]
            );
            const prescriptionType: PrescriptionType = typeResult.rows[0];

            // Insert medications
            for (let i = 0; i < data.medications.length; i++) {
                const med = data.medications[i];
                await client.query(
                    `INSERT INTO prescription_type_medications
                        (prescription_type_id, medication_id, custom_medication_id, is_custom, quantity, dosage, note, sort_order)
                     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
                    [
                        prescriptionType.id,
                        med.is_custom ? null : med.medication_id,
                        med.is_custom ? (med.custom_medication_id || med.medication_id) : null,
                        med.is_custom,
                        med.quantity,
                        med.dosage,
                        med.note || null,
                        med.sort_order ?? i,
                    ]
                );
            }

            await client.query('COMMIT');

            // Return with populated medication details
            return await this.findById(prescriptionType.id) as PrescriptionTypeWithMedications;

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    /**
     * Find a prescription type by ID, with full medication details.
     */
    static async findById(id: number): Promise<PrescriptionTypeWithMedications | null> {
        const typeResult = await pool.query(
            `SELECT * FROM prescription_types WHERE id = $1`,
            [id]
        );

        if (typeResult.rows.length === 0) return null;

        const prescriptionType: PrescriptionType = typeResult.rows[0];
        const medications = await this._getMedicationsForType(id);

        return { ...prescriptionType, medications };
    }

    /**
     * Find all types belonging to a doctor, ordered by most recent first.
     * Returns lightweight list (no medication details).
     */
    static async findByDoctor(
        doctorId: number,
        limit: number = 50,
        offset: number = 0
    ): Promise<(PrescriptionType & { medication_count: number })[]> {
        const result = await pool.query(
            `SELECT pt.*,
                    COUNT(ptm.id)::int AS medication_count
             FROM prescription_types pt
             LEFT JOIN prescription_type_medications ptm ON pt.id = ptm.prescription_type_id
             WHERE pt.doctor_user_id = $1
             GROUP BY pt.id
             ORDER BY pt.created_at DESC
             LIMIT $2 OFFSET $3`,
            [doctorId, limit, offset]
        );
        return result.rows;
    }

    /**
     * Find all types belonging to a doctor WITH full medication details.
     * Use for the type-selector dropdown on the prescription form.
     */
    static async findByDoctorWithMedications(
        doctorId: number
    ): Promise<PrescriptionTypeWithMedications[]> {
        const typesResult = await pool.query(
            `SELECT * FROM prescription_types
             WHERE doctor_user_id = $1
             ORDER BY name ASC`,
            [doctorId]
        );

        const types: PrescriptionTypeWithMedications[] = [];
        for (const row of typesResult.rows) {
            const medications = await this._getMedicationsForType(row.id);
            types.push({ ...row, medications });
        }
        return types;
    }

    /**
     * Update a prescription type (name/description + replace medications).
     */
    static async update(
        id: number,
        data: UpdatePrescriptionTypeData
    ): Promise<PrescriptionTypeWithMedications | null> {
        const client = await pool.connect();
        try {
            await client.query('BEGIN');

            // Update header fields
            const fields: string[] = [];
            const values: any[] = [];
            let paramCount = 1;

            if (data.name !== undefined) {
                fields.push(`name = $${paramCount++}`);
                values.push(data.name);
            }
            if (data.description !== undefined) {
                fields.push(`description = $${paramCount++}`);
                values.push(data.description);
            }

            if (fields.length > 0) {
                fields.push(`updated_at = CURRENT_TIMESTAMP`);
                values.push(id);
                await client.query(
                    `UPDATE prescription_types SET ${fields.join(', ')} WHERE id = $${paramCount}`,
                    values
                );
            }

            // Replace medications if provided
            if (data.medications !== undefined) {
                await client.query(
                    `DELETE FROM prescription_type_medications WHERE prescription_type_id = $1`,
                    [id]
                );

                for (let i = 0; i < data.medications.length; i++) {
                    const med = data.medications[i];
                    await client.query(
                        `INSERT INTO prescription_type_medications
                            (prescription_type_id, medication_id, custom_medication_id, is_custom, quantity, dosage, note, sort_order)
                         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
                        [
                            id,
                            med.is_custom ? null : med.medication_id,
                            med.is_custom ? (med.custom_medication_id || med.medication_id) : null,
                            med.is_custom,
                            med.quantity,
                            med.dosage,
                            med.note || null,
                            med.sort_order ?? i,
                        ]
                    );
                }
            }

            await client.query('COMMIT');
            return await this.findById(id);

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    /**
     * Delete a prescription type (cascade removes its medications automatically).
     */
    static async delete(id: number): Promise<boolean> {
        const result = await pool.query(
            `DELETE FROM prescription_types WHERE id = $1`,
            [id]
        );
        return (result.rowCount ?? 0) > 0;
    }

    /**
     * Create a prescription type from an existing prescription's medications.
     * Useful for "Save as Model" on the prescription form.
     */
    static async createFromPrescription(
        prescriptionId: number,
        name: string,
        doctorId: number,
        description?: string
    ): Promise<PrescriptionTypeWithMedications> {
        // Fetch existing prescription with medication details
        const prescription = await PrescriptionModel.findByIdWithDetails(prescriptionId);
        if (!prescription) {
            throw new Error(`Prescription ${prescriptionId} not found`);
        }

        // Map prescription medications to type medication format
        const medications = (prescription.medications || []).map((med, index) => ({
            medication_id: med.is_custom ? null : med.medication_id,
            custom_medication_id: med.is_custom ? med.custom_medication_id ?? null : null,
            is_custom: med.is_custom || false,
            quantity: med.quantity,
            dosage: med.dosage,
            note: med.note || undefined,
            sort_order: index,
        }));

        return await this.create({
            name,
            description,
            doctor_user_id: doctorId,
            medications,
        });
    }

    /**
     * Check if a prescription type belongs to a specific doctor.
     */
    static async belongsToDoctor(id: number, doctorId: number): Promise<boolean> {
        const result = await pool.query(
            `SELECT id FROM prescription_types WHERE id = $1 AND doctor_user_id = $2`,
            [id, doctorId]
        );
        return result.rows.length > 0;
    }

    // ────────────────────────────────────────────────────────
    // Private helpers
    // ────────────────────────────────────────────────────────

    /**
     * Fetch and populate medication details for a given prescription type.
     */
    private static async _getMedicationsForType(
        typeId: number
    ): Promise<PrescriptionTypeMedicationWithDetails[]> {
        const result = await pool.query(
            `SELECT * FROM prescription_type_medications
             WHERE prescription_type_id = $1
             ORDER BY sort_order ASC, id ASC`,
            [typeId]
        );

        const detailedMeds: PrescriptionTypeMedicationWithDetails[] = [];

        for (const row of result.rows) {
            let medication: Medication | CustomMedication | null = null;
            let nom_de_marque = '';
            let denomination_commune_internationale = '';
            let med_dosage: string | null = null;

            if (row.is_custom && row.custom_medication_id) {
                medication = await CustomMedicationModel.findById(row.custom_medication_id);
                if (medication) {
                    nom_de_marque = (medication as CustomMedication).nom_de_marque || '';
                    denomination_commune_internationale = (medication as CustomMedication).denomination_commune_internationale || '';
                    med_dosage = (medication as CustomMedication).dosage || null;
                }
            } else if (row.medication_id) {
                medication = await MedicationModel.findById(row.medication_id);
                if (medication) {
                    nom_de_marque = (medication as Medication).nom_de_marque || '';
                    denomination_commune_internationale = (medication as Medication).denomination_commune_internationale || '';
                    med_dosage = (medication as Medication).dosage || null;
                }
            }

            detailedMeds.push({
                ...row,
                medication,
                nom_de_marque,
                denomination_commune_internationale,
                med_dosage,
            });
        }

        return detailedMeds;
    }
}
