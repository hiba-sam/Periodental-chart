import pool from '../db';

export interface Tarification {
    id: number;
    doctor_user_id: number;
    service_label: string;
    price: number;
    created_at: Date;
    updated_at: Date;
}

export interface CreateTarificationData {
    doctor_user_id: number;
    service_label: string;
    price: number;
}

export interface UpdateTarificationData {
    service_label?: string;
    price?: number;
}

export class TarificationModel {
    private static mapRow(row: any): Tarification {
        return {
            id: row.id,
            doctor_user_id: row.doctor_user_id,
            service_label: row.service_label,
            price: parseFloat(row.price),
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    // Create a new tarification entry
    static async create(data: CreateTarificationData): Promise<Tarification> {
        const query = `
            INSERT INTO tarifications (
                doctor_user_id,
                service_label,
                price
            ) VALUES ($1, $2, $3)
            RETURNING *
        `;

        const values = [
            data.doctor_user_id,
            data.service_label,
            data.price
        ];

        const result = await pool.query(query, values);
        return this.mapRow(result.rows[0]);
    }

    // Create multiple tarification entries in a transaction
    static async createMany(entries: CreateTarificationData[]): Promise<Tarification[]> {
        const client = await pool.connect();

        try {
            await client.query('BEGIN');

            const results: Tarification[] = [];

            for (const entry of entries) {
                const query = `
                    INSERT INTO tarifications (
                        doctor_user_id,
                        service_label,
                        price
                    ) VALUES ($1, $2, $3)
                    RETURNING *
                `;

                const values = [
                    entry.doctor_user_id,
                    entry.service_label,
                    entry.price
                ];

                const result = await client.query(query, values);
                results.push(this.mapRow(result.rows[0]));
            }

            await client.query('COMMIT');
            return results;

        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    // Find tarification by ID
    static async findById(id: number): Promise<Tarification | null> {
        const query = 'SELECT * FROM tarifications WHERE id = $1';
        const result = await pool.query(query, [id]);

        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    // Find all tarifications for a specific doctor
    static async findByDoctorUserId(doctorUserId: number): Promise<Tarification[]> {
        const query = `
            SELECT * FROM tarifications
            WHERE doctor_user_id = $1
            ORDER BY service_label ASC
        `;
        const result = await pool.query(query, [doctorUserId]);
        return result.rows.map(this.mapRow);
    }

    // Check if a doctor has any tarification entries
    static async hasEntries(doctorUserId: number): Promise<boolean> {
        const query = 'SELECT 1 FROM tarifications WHERE doctor_user_id = $1 LIMIT 1';
        const result = await pool.query(query, [doctorUserId]);
        return result.rows.length > 0;
    }

    // Update a tarification entry
    static async update(id: number, data: UpdateTarificationData): Promise<Tarification | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.service_label !== undefined) {
            fields.push(`service_label = $${idx++}`);
            values.push(data.service_label);
        }
        if (data.price !== undefined) {
            fields.push(`price = $${idx++}`);
            values.push(data.price);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        // Always update the updated_at timestamp
        fields.push(`updated_at = NOW()`);

        values.push(id);
        const query = `
            UPDATE tarifications
            SET ${fields.join(', ')}
            WHERE id = $${idx}
            RETURNING *
        `;

        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;

        return this.mapRow(result.rows[0]);
    }

    // Delete a tarification entry
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM tarifications WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Delete all tarifications for a doctor (cascade helper)
    static async deleteByDoctorUserId(doctorUserId: number): Promise<number> {
        const query = 'DELETE FROM tarifications WHERE doctor_user_id = $1';
        const result = await pool.query(query, [doctorUserId]);
        return result.rowCount ?? 0;
    }

    // Get all tarifications (admin use case)
    static async findAll(limit: number = 50, offset: number = 0): Promise<Tarification[]> {
        const query = `
            SELECT * FROM tarifications
            ORDER BY doctor_user_id ASC, service_label ASC
            LIMIT $1 OFFSET $2
        `;
        const result = await pool.query(query, [limit, offset]);
        return result.rows.map(this.mapRow);
    }

    // Count total tarifications for a doctor
    static async countByDoctorUserId(doctorUserId: number): Promise<number> {
        const query = 'SELECT COUNT(*) as count FROM tarifications WHERE doctor_user_id = $1';
        const result = await pool.query(query, [doctorUserId]);
        return parseInt(result.rows[0].count, 10);
    }
}
