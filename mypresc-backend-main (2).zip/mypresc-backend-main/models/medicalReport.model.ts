import pool from '../db';
import { PatientModel, type Patient } from './patient.model';
import type { User } from './user.model';

export interface MedicalReport {
    id: number;
    patient_id: string; // UUID
    doctor_user_id: number;
    title: string;
    content: string;
    examination_date: Date;
    consultation_id?: number | null;
    created_at: Date;
    updated_at: Date;
}

export interface MedicalReportWithDetails extends MedicalReport {
    patient: Patient | null;
    doctor: User;
}

export interface CreateMedicalReportData {
    patient_id: string; // UUID
    doctor_user_id: number;
    title: string;
    content: string;
    examination_date?: Date;
    consultation_id?: number;
}

export interface UpdateMedicalReportData {
    title?: string;
    content?: string;
    examination_date?: Date;
}

export class MedicalReportModel {
    // Dynamic getter to ensure we read the latest env value
    private static get ENCRYPTION_KEY() {
        return process.env.ENCRYPTION_KEY;
    }

    // Check if encryption is enabled (when ENCRYPTION_KEY is set)
    private static get isEncryptionEnabled(): boolean {
        // Access getter to ensure dynamic read
        const key = this.ENCRYPTION_KEY;
        return !!key && key.length > 0;
    }

    // Helper method to decrypt data
    private static async decrypt(encryptedData: Buffer): Promise<string> {
        if (!encryptedData) return '';
        const result = await pool.query('SELECT pgp_sym_decrypt($1, $2) as decrypted', [encryptedData, this.ENCRYPTION_KEY]);
        return result.rows[0]?.decrypted || '';
    }

    // Helper to get title/content select clause based on encryption status
    private static getTitleContentSelect(prefix: string = ''): string {
        const p = prefix ? `${prefix}.` : '';
        if (this.isEncryptionEnabled) {
            return `pgp_sym_decrypt(${p}title, '${this.ENCRYPTION_KEY}') as title, pgp_sym_decrypt(${p}content, '${this.ENCRYPTION_KEY}') as content`;
        }
        return `convert_from(${p}title, 'UTF8') as title, convert_from(${p}content, 'UTF8') as content`;
    }

    // Create a new medical report (with encryption if enabled)
    static async create(data: CreateMedicalReportData): Promise<MedicalReport> {
        let query: string;
        let values: any[];

        if (this.isEncryptionEnabled) {
            query = `
                INSERT INTO medical_reports (
                    patient_id, doctor_user_id, 
                    title, content,
                    examination_date, consultation_id
                ) VALUES (
                    $1, 
                    $2, 
                    pgp_sym_encrypt($3, $7),
                    pgp_sym_encrypt($4, $7),
                    $5,
                    $6
                )
                RETURNING id, patient_id, doctor_user_id, 
                          examination_date, consultation_id, created_at, updated_at
            `;
            values = [
                data.patient_id,              // $1
                data.doctor_user_id,          // $2
                data.title,                   // $3
                data.content,                 // $4
                data.examination_date || new Date(), // $5
                data.consultation_id || null, // $6
                this.ENCRYPTION_KEY           // $7
            ];
        } else {
            // No encryption - store as plain bytea
            query = `
                INSERT INTO medical_reports (
                    patient_id, doctor_user_id, 
                    title, content,
                    examination_date, consultation_id
                ) VALUES (
                    $1, 
                    $2, 
                    $3,
                    $4,
                    $5,
                    $6
                )
                RETURNING id, patient_id, doctor_user_id, 
                          examination_date, consultation_id, created_at, updated_at
            `;
            values = [
                data.patient_id,              // $1
                data.doctor_user_id,          // $2
                data.title,                   // $3
                data.content,                 // $4
                data.examination_date || new Date(), // $5
                data.consultation_id || null  // $6
            ];
        }

        const result = await pool.query(query, values);
        const row = result.rows[0];

        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            title: data.title,
            content: data.content,
            examination_date: row.examination_date,
            consultation_id: row.consultation_id,
            created_at: row.created_at,
            updated_at: row.updated_at
        };
    }

    // Find medical report by ID
    static async findById(id: number): Promise<MedicalReport | null> {
        const query = `
            SELECT 
                id, patient_id, doctor_user_id,
                ${this.getTitleContentSelect()},
                examination_date, consultation_id, created_at, updated_at
            FROM medical_reports 
            WHERE id = $1
        `;
        const result = await pool.query(query, [id]);
        return result.rows[0] || null;
    }

    // Find medical report by ID with patient and doctor details
    static async findByIdWithDetails(id: number, requestingDoctorId?: number): Promise<MedicalReportWithDetails | null> {
        const reportQuery = `
            SELECT 
                mr.id, mr.patient_id, mr.doctor_user_id,
                ${this.getTitleContentSelect('mr')},
                mr.examination_date, mr.consultation_id, mr.created_at, mr.updated_at,
                u.id as doctor_id,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                u.email as doctor_email
            FROM medical_reports mr
            JOIN users u ON mr.doctor_user_id = u.id
            WHERE mr.id = $1
        `;

        const result = await pool.query(reportQuery, [id]);

        if (result.rows.length === 0) return null;

        const row = result.rows[0];

        // Get patient details
        const patient = await PatientModel.findById(row.patient_id, requestingDoctorId);

        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            title: row.title,
            content: row.content,
            examination_date: row.examination_date,
            consultation_id: row.consultation_id,
            created_at: row.created_at,
            updated_at: row.updated_at,
            patient,
            doctor: {
                id: row.doctor_id,
                name: row.doctor_name,
                family_name: row.doctor_family_name,
                email: row.doctor_email,
            } as User
        };
    }

    // Update medical report (with encryption if enabled)
    static async update(id: number, data: UpdateMedicalReportData): Promise<MedicalReport | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let paramCount = 1;

        if (this.isEncryptionEnabled) {
            // Add encryption key as first parameter for encrypted fields
            const encKeyParamIndex = paramCount++;
            values.push(this.ENCRYPTION_KEY);

            if (data.title !== undefined) {
                fields.push(`title = pgp_sym_encrypt($${paramCount++}, $${encKeyParamIndex})`);
                values.push(data.title);
            }
            if (data.content !== undefined) {
                fields.push(`content = pgp_sym_encrypt($${paramCount++}, $${encKeyParamIndex})`);
                values.push(data.content);
            }
        } else {
            if (data.title !== undefined) {
                fields.push(`title = $${paramCount++}`);
                values.push(data.title);
            }
            if (data.content !== undefined) {
                fields.push(`content = $${paramCount++}`);
                values.push(data.content);
            }
        }
        if (data.examination_date !== undefined) {
            fields.push(`examination_date = $${paramCount++}`);
            values.push(data.examination_date);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `
            UPDATE medical_reports 
            SET ${fields.join(', ')} 
            WHERE id = $${paramCount}
            RETURNING id
        `;

        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;

        // Return decrypted data
        return await this.findById(id);
    }

    // Delete medical report
    static async delete(id: number): Promise<boolean> {
        const query = 'DELETE FROM medical_reports WHERE id = $1';
        const result = await pool.query(query, [id]);
        return (result.rowCount ?? 0) > 0;
    }

    // Get all medical reports for a specific patient
    static async findByPatientId(patientId: string, limit: number = 50, offset: number = 0): Promise<MedicalReport[]> {
        const query = `
            SELECT 
                id, patient_id, doctor_user_id,
                ${this.getTitleContentSelect()},
                examination_date, consultation_id, created_at, updated_at
            FROM medical_reports 
            WHERE patient_id = $1 
            ORDER BY examination_date DESC, created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [patientId, limit, offset]);
        return result.rows;
    }

    // ⚡ OPTIMIZED: Get all medical reports for a specific patient with details
    // Returns: own reports + reports from doctors who have shared with requesting doctor
    static async findByPatientIdWithDetails(
        patientId: string,
        requestingDoctorId: number,
        limit: number = 50,
        offset: number = 0,
        patientData?: Patient | null  // Optional: pass patient if already fetched
    ): Promise<MedicalReportWithDetails[]> {
        // Use provided patient or fetch it (but controller should provide it)
        const patient = patientData ?? await PatientModel.findById(patientId, requestingDoctorId);

        if (!patient) {
            return [];
        }

        // Query that returns:
        // 1. Own reports (doctor_user_id = requestingDoctorId)
        // 2. Reports from doctors who have shared with requesting doctor (via medical_shares)
        // 3. Reports from doctors who have chosen "shared" privacy (via doctor_patient_privacy)
        const query = `
            SELECT DISTINCT
                mr.id, mr.patient_id, mr.doctor_user_id,
                ${this.getTitleContentSelect('mr')},
                mr.examination_date, mr.consultation_id, mr.created_at, mr.updated_at,
                u.id as doctor_id,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                u.email as doctor_email
            FROM medical_reports mr
            JOIN users u ON mr.doctor_user_id = u.id
            LEFT JOIN medical_shares ms ON ms.patient_id = mr.patient_id 
                AND ms.shared_by_doctor_id = mr.doctor_user_id 
                AND ms.shared_with_doctor_id = $2
                AND ms.status = 'active'
                AND ms.share_medical_reports = true
                AND ms.expires_at > NOW()
            LEFT JOIN doctor_patient_privacy dpp ON dpp.patient_id = mr.patient_id 
                AND dpp.doctor_id = mr.doctor_user_id 
                AND dpp.privacy_choice = 'shared'
            WHERE mr.patient_id = $1 
            AND (
                mr.doctor_user_id = $2
                OR ms.id IS NOT NULL
                OR dpp.id IS NOT NULL
            )
            ORDER BY mr.examination_date DESC, mr.created_at DESC
            LIMIT $3 OFFSET $4
        `;

        const params = [patientId, requestingDoctorId, limit, offset];

        console.log(`[MedicalReport] Query for patient ${patientId}, doctor ${requestingDoctorId}`);
        const result = await pool.query(query, params);
        console.log(`[MedicalReport] Found ${result.rows.length} reports`);

        return result.rows.map(row => ({
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            title: row.title,
            content: row.content,
            examination_date: row.examination_date,
            consultation_id: row.consultation_id,
            created_at: row.created_at,
            updated_at: row.updated_at,
            patient,
            doctor: {
                id: row.doctor_id,
                name: row.doctor_name,
                family_name: row.doctor_family_name,
                email: row.doctor_email,
            } as User
        }));
    }

    // Get all medical reports by a specific doctor
    static async findByDoctorId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<MedicalReport[]> {
        const query = `
            SELECT 
                id, patient_id, doctor_user_id,
                ${this.getTitleContentSelect()},
                examination_date, consultation_id, created_at, updated_at
            FROM medical_reports 
            WHERE doctor_user_id = $1 
            ORDER BY examination_date DESC, created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset]);
        return result.rows;
    }

    // Count medical reports for a patient
    static async countByPatientId(patientId: string): Promise<number> {
        const query = 'SELECT COUNT(*) as count FROM medical_reports WHERE patient_id = $1';
        const result = await pool.query(query, [patientId]);
        return parseInt(result.rows[0].count);
    }

    // Count medical reports by a doctor
    static async countByDoctorId(doctorUserId: number): Promise<number> {
        const query = 'SELECT COUNT(*) as count FROM medical_reports WHERE doctor_user_id = $1';
        const result = await pool.query(query, [doctorUserId]);
        return parseInt(result.rows[0].count);
    }
}
