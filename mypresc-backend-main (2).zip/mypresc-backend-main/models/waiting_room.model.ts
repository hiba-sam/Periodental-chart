import pool from '../db';

export interface WaitingEntry {
    id: string;
    patient_id: string;
    doctor_user_id: number;
    status: 'waiting' | 'called' | 'served' | 'left';
    arrived_at: Date;
    called_at?: Date | null;
    notes?: string | null;
    created_at: Date;
    updated_at: Date;
    patient_name: string;
    patient_family_name: string;
}

export interface CreateWaitingEntryData {
    patient_id: string;
    doctor_user_id: number;
    status?: 'waiting' | 'called' | 'served' | 'left';
    arrived_at?: Date;
    called_at?: Date | null;
    notes?: string;
}

export interface UpdateWaitingEntryData {
    patient_id?: string;
    doctor_user_id?: number;
    status?: 'waiting' | 'called' | 'served' | 'left';
    arrived_at?: Date;
    called_at?: Date | null;
    notes?: string | null;
}

export class WaitingRoomModel {
    private static readonly ENCRYPTION_KEY = process.env.ENCRYPTION_KEY;

    private static mapRow(row: any): WaitingEntry {
        return {
            id: row.id,
            patient_id: row.patient_id,
            doctor_user_id: row.doctor_user_id,
            status: row.status,
            arrived_at: row.arrived_at,
            called_at: row.called_at ?? null,
            notes: row.notes ?? null,
            created_at: row.created_at,
            updated_at: row.updated_at,
            patient_name: row.patient_name,
            patient_family_name: row.patient_family_name
        };
    }

    // Check if patient already has a waiting entry on the same day for this doctor
    static async existsSameDay(patientId: string, doctorUserId: number, date: Date): Promise<boolean> {
        const query = `
            SELECT 1
            FROM waiting_room
            WHERE patient_id = $1
              AND doctor_user_id = $2
              AND DATE(arrived_at) = DATE($3)
            LIMIT 1
        `;
        const result = await pool.query(query, [patientId, doctorUserId, date]);
        return result.rows.length > 0;
    }

    static async create(data: CreateWaitingEntryData): Promise<WaitingEntry> {
        const insertQuery = `
            INSERT INTO waiting_room (
                patient_id,
                doctor_user_id,
                status,
                arrived_at,
                called_at,
                notes
            ) VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id
        `;

        const insertValues = [
            data.patient_id,
            data.doctor_user_id,
            data.status ?? 'waiting',
            data.arrived_at ?? new Date(),
            data.called_at ?? null,
            data.notes ?? null,
        ];

        const inserted = await pool.query(insertQuery, insertValues);
        const newId = inserted.rows[0].id as string;
        return await this.findById(newId) as WaitingEntry;
    }

    static async findById(id: string): Promise<WaitingEntry | null> {
        const query = `
            SELECT w.*,
                   pgp_sym_decrypt(p.name, $2) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $2) AS patient_family_name
            FROM waiting_room w
            JOIN patients p ON p.id = w.patient_id
            WHERE w.id = $1
        `;
        const result = await pool.query(query, [id, this.ENCRYPTION_KEY]);
        if (result.rows.length === 0) return null;
        return this.mapRow(result.rows[0]);
    }

    static async update(id: string, data: UpdateWaitingEntryData): Promise<WaitingEntry | null> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.patient_id !== undefined) {
            fields.push(`patient_id = $${idx++}`);
            values.push(data.patient_id);
        }
        if (data.doctor_user_id !== undefined) {
            fields.push(`doctor_user_id = $${idx++}`);
            values.push(data.doctor_user_id);
        }
        if (data.status !== undefined) {
            fields.push(`status = $${idx++}`);
            values.push(data.status);
        }
        if (data.arrived_at !== undefined) {
            fields.push(`arrived_at = $${idx++}`);
            values.push(data.arrived_at);
        }
        if (data.called_at !== undefined) {
            fields.push(`called_at = $${idx++}`);
            values.push(data.called_at);
        }
        if (data.notes !== undefined) {
            fields.push(`notes = $${idx++}`);
            values.push(data.notes);
        }

        if (fields.length === 0) {
            return await this.findById(id);
        }

        values.push(id);
        const query = `UPDATE waiting_room w SET ${fields.join(', ')} WHERE w.id = $${idx} RETURNING w.id`;
        const result = await pool.query(query, values);
        if (result.rows.length === 0) return null;
        return await this.findById(id);
    }

    static async delete(id: string): Promise<boolean> {
        const result = await pool.query('DELETE FROM waiting_room WHERE id = $1', [id]);
        return (result.rowCount ?? 0) > 0;
    }

    static async findByDoctorUserId(doctorUserId: number, limit: number = 50, offset: number = 0): Promise<WaitingEntry[]> {
        const query = `
            SELECT w.*,
                   pgp_sym_decrypt(p.name, $4) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $4) AS patient_family_name
            FROM waiting_room w
            JOIN patients p ON p.id = w.patient_id
            WHERE w.doctor_user_id = $1
            ORDER BY w.arrived_at ASC
            LIMIT $2 OFFSET $3
        `;
        const result = await pool.query(query, [doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    static async findByStatusAndDoctor(status: 'waiting' | 'called' | 'served' | 'left', doctorUserId: number, limit: number = 50, offset: number = 0): Promise<WaitingEntry[]> {
        const query = `
            SELECT w.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM waiting_room w
            JOIN patients p ON p.id = w.patient_id
            WHERE w.status = $1 AND w.doctor_user_id = $2
            ORDER BY w.arrived_at ASC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [status, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    static async findByPatientAndDoctor(patientId: string, doctorUserId: number, limit: number = 50, offset: number = 0): Promise<WaitingEntry[]> {
        const query = `
            SELECT w.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM waiting_room w
            JOIN patients p ON p.id = w.patient_id
            WHERE w.patient_id = $1 AND w.doctor_user_id = $2
            ORDER BY w.arrived_at ASC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [patientId, doctorUserId, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }

    static async findByDoctorAndDate(doctorUserId: number, date: Date, limit: number = 200, offset: number = 0): Promise<WaitingEntry[]> {
        const query = `
            SELECT w.*,
                   pgp_sym_decrypt(p.name, $5) AS patient_name,
                   pgp_sym_decrypt(p.family_name, $5) AS patient_family_name
            FROM waiting_room w
            JOIN patients p ON p.id = w.patient_id
            WHERE w.doctor_user_id = $1 AND DATE(w.arrived_at) = DATE($2)
            ORDER BY w.arrived_at ASC
            LIMIT $3 OFFSET $4
        `;
        const result = await pool.query(query, [doctorUserId, date, limit, offset, this.ENCRYPTION_KEY]);
        return result.rows.map(this.mapRow);
    }
} 