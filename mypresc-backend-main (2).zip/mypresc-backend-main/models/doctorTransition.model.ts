import pool from '../db';

export interface DoctorTransition {
    id: number;
    patient_id: string;
    previous_doctor_id: number | null;
    new_doctor_id: number;
    comment: string;
    transition_date: Date;
    created_at: Date;
}

export interface CreateDoctorTransitionData {
    patient_id: string;
    previous_doctor_id: number | null;
    new_doctor_id: number;
    comment: string;
}

export class DoctorTransitionModel {
    // Create a new transition record
    static async create(data: CreateDoctorTransitionData): Promise<DoctorTransition> {
        const query = `
            INSERT INTO doctor_transitions (
                patient_id, previous_doctor_id, new_doctor_id, comment
            ) VALUES ($1, $2, $3, $4)
            RETURNING *
        `;
        const values = [
            data.patient_id,
            data.previous_doctor_id,
            data.new_doctor_id,
            data.comment
        ];
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    // Get all transitions for a patient
    static async findByPatientId(patientId: string): Promise<DoctorTransition[]> {
        const query = `
            SELECT * FROM doctor_transitions
            WHERE patient_id = $1
            ORDER BY transition_date DESC
        `;
        const result = await pool.query(query, [patientId]);
        return result.rows;
    }

    // Get all transitions where a doctor was the previous one (for notifications)
    static async findByPreviousDoctorId(doctorId: number, limit: number = 50): Promise<DoctorTransition[]> {
        const query = `
            SELECT dt.*, p.name, p.family_name
            FROM doctor_transitions dt
            JOIN patients p ON dt.patient_id = p.id
            WHERE dt.previous_doctor_id = $1
            ORDER BY dt.transition_date DESC
            LIMIT $2
        `;
        const result = await pool.query(query, [doctorId, limit]);
        return result.rows;
    }

    // Get the latest transition for a patient
    static async getLatestByPatientId(patientId: string): Promise<DoctorTransition | null> {
        const query = `
            SELECT * FROM doctor_transitions
            WHERE patient_id = $1
            ORDER BY transition_date DESC
            LIMIT 1
        `;
        const result = await pool.query(query, [patientId]);
        return result.rows.length > 0 ? result.rows[0] : null;
    }
}
