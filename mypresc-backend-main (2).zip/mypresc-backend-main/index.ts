/**

 * MyPresc Backend Server

 * 

 * Serveur Express sécurisé pour la gestion des prescriptions médicales

 * Conformité : RGPD, ANPDP, OWASP Top 10

 */



// Sentry MUST be imported and initialized before any other imports

import * as Sentry from '@sentry/node';



Sentry.init({

	dsn: process.env.SENTRY_DSN,

	environment: process.env.NODE_ENV || 'development',

	tracesSampleRate: 1.0,

	sendDefaultPii: true,

	integrations: [

		Sentry.httpIntegration(),

		Sentry.expressIntegration(),

	],

});



import express, { type Request, type Response, type NextFunction } from 'express';

import { createServer } from 'http';

import session from 'express-session';

import cookieParser from 'cookie-parser';

import passport from 'passport';

import helmet from 'helmet';

import cors from 'cors';

import dotenv from 'dotenv';

import { globalLimiter, sanitizeBody } from './middlewares/protections';

import { validateAndLogSecrets } from './config/secretsValidator';

import { loadSecrets } from './config/vault';

import { securityLogger, logServerStartup } from './utils/securityLogger';

import { forceHttps } from './middlewares/forceHttps';

import { corsOptions as advancedCorsOptions } from './config/cors';

import { waf } from './middlewares/waf';

import { ipFilter } from './middlewares/ipFilter';

import { i18nMiddleware } from './config/i18n';

import { languageMiddleware } from './middlewares/language.middleware';



// ============================================

// SECURITY INITIALIZATION

// ============================================

// Charger les variables d'environnement

dotenv.config();



// Charger et valider les secrets AVANT toute initialisation

(async () => {

	try {

		securityLogger.info('[STARTUP] Initializing secure backend server...');



		// 1. Charger les secrets (Vault OU .env)

		await loadSecrets();



		// 2. Valider la robustesse des secrets

		validateAndLogSecrets();



		securityLogger.info('[STARTUP] Security initialization completed ✅');



	} catch (error) {

		securityLogger.error('[STARTUP] Security initialization FAILED ❌', { error });

		console.error('\n❌ FATAL ERROR: Security initialization failed');

		console.error('Check logs/security.log for details\n');

		process.exit(1);

	}

})();



const app = express();

app.set('trust proxy', 1);

const httpServer = createServer(app);



// Security Headers with Helmet

app.use(helmet({

	contentSecurityPolicy: false, // Disable CSP for now to allow iframe embedding

	crossOriginEmbedderPolicy: false,

	crossOriginResourcePolicy: { policy: "cross-origin" },

	hsts: {

		maxAge: 31536000,

		includeSubDomains: true,

		preload: true

	}

}));



// Set custom CSP headers that allow iframe embedding from frontend origins

app.use((req: Request, res: Response, next: NextFunction) => {

	const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',').map(o => o.trim()).join(' ') ||

		'http://localhost:3000 http://localhost:3001 http://localhost:58544';



	res.setHeader('X-Frame-Options', 'SAMEORIGIN');

	res.setHeader('Content-Security-Policy', `frame-ancestors 'self' ${allowedOrigins}`);

	next();

});



// ============================================

// NETWORK SECURITY MIDDLEWARE (ORDRE IMPORTANT)

// ============================================



// 1. Force HTTPS en production (doit être en premier)

app.use(forceHttps);



// 2. CORS strict avec configuration avancée

app.use(cors(advancedCorsOptions));



// 3. WAF applicatif (après CORS, avant rate limiting)

app.use(waf);



// 4. Filtrage IP et géolocalisation

app.use(ipFilter);



// ============================================

// RATE LIMITING - GLOBAL PROTECTION

// ============================================

// Apply global rate limiter to all routes (100 requests / 15 min per IP)

// Protects against brute force, DoS attacks, and abusive requests

app.use(globalLimiter);



// ============================================

// WEBHOOK RAW BODY HANDLING (CRITICAL: BEFORE express.json())

// ============================================

// Import payment controller early to handle webhooks BEFORE JSON parsing

import paymentController from './controllers/payment.controller';



// Register ONLY the webhook route early with raw body parsing

// This MUST come before express.json() to receive raw body for signature verification

app.post('/payment/webhook', express.raw({ type: 'application/json' }), paymentController.SubscriptionWebhook);



// Request size limits

// These apply to all OTHER routes (webhook already registered above)

app.use(express.json({ limit: '10mb' }));

app.use(express.urlencoded({ extended: true, limit: '10mb' }));



// Call XSS Protection

app.use(sanitizeBody);



// Cookie Parser with secure secret

app.use(cookieParser(process.env.SESSION_SECRET));



// ============================================

// SESSION CONFIGURATION (Enhanced Security)

// ============================================

const sessionMiddleware = session({

	secret: process.env.SESSION_SECRET || 'our-secret-key',

	name: 'sessionId', // Custom name instead of default 'connect.sid'

	resave: false,

	saveUninitialized: false,

	rolling: true, // Reset maxAge on every response

	cookie: {

		secure: process.env.NODE_ENV === 'production', // HTTPS only in production

		httpOnly: true, // Prevent JavaScript access

		maxAge: 24 * 60 * 60 * 1000, // 24 hours

		// sameSite: 'strict',

	},

});



app.use(sessionMiddleware);



// Passport configuration

// Passport configuration

app.use(i18nMiddleware);

app.use(passport.initialize());

app.use(passport.session());

app.use(languageMiddleware);



// Main route with validation

app.get('/', (req: Request, res: Response) => {

	res.json({

		message: 'Hello World',

		user: req.user || null,

		session: req.sessionID,

		timestamp: new Date().toISOString()

	});

});



// Sentry error handler - MUST be before any other error middleware

Sentry.setupExpressErrorHandler(app);



// Error handling middleware

app.use((err: Error, req: Request, res: Response, next: NextFunction) => {

	console.error('Error:', err);



	// Don't leak error details in production

	const isDevelopment = process.env.NODE_ENV === 'development';



	res.status(500).json({

		error: isDevelopment ? err.message : 'Internal Server Error',

		...(isDevelopment && { stack: err.stack })

	});

});



// ============================================

// SOCKET.IO INITIALIZATION

// ============================================

import socketManager from './utils/socketManager';

import { SocketController } from './controllers/socket.controller';

import { startPresenceHeartbeat } from './utils/presenceHeartbeat';

const io = socketManager.initialize(httpServer, sessionMiddleware);



// Handle socket connections

io.on('connection', (socket) => {

	SocketController.handleConnection(socket);

});



// Start presence cleanup heartbeat (runs every 5 minutes)

startPresenceHeartbeat();



const PORT = process.env.PORT || 3333;

httpServer.listen(PORT, () => {

	const environment = process.env.NODE_ENV || 'development';



	console.log('\n╔════════════════════════════════════════════════════════════╗');

	console.log('║          MyPresc Backend - Server Started                 ║');

	console.log('╚════════════════════════════════════════════════════════════╝\n');

	console.log(`🚀 Server running on port ${PORT}`);

	console.log(`📍 Environment: ${environment}`);

	console.log(`🔐 Secrets source: ${process.env.VAULT_ENABLED === 'true' ? 'HashiCorp Vault' : '.env file'}`);

	console.log('\n🛡️  Security features enabled:');

	console.log('   ✓ Helmet.js (Security headers)');

	console.log('   ✓ CORS protection');

	console.log('   ✓ Rate Limiting (4 levels)');

	console.log('   ✓ XSS protection');

	console.log('   ✓ Session security');

	console.log('   ✓ Secrets validation');

	console.log('   ✓ Security logging');

	console.log('   ✓ Socket.io (Messaging)\n');

	console.log('📊 Check security logs: logs/security.log\n');



	// Log sécurisé du démarrage

	logServerStartup(Number(PORT), environment);

});



import { requireAuth, requireDoctorAuth } from './middlewares/auth';

import { setRLSContext } from './middlewares/rlsContext.middleware';



import authRouter from './routes/auth.route';

import adminRouter from './routes/admin.route';

import patientRouter from './routes/patient.route';

import appointmentRouter from './routes/appointment.route';

import waitingRouter from './routes/waitingRoom.route';

import userRouter from './routes/user.route';

import prescriptionRouter from './routes/prescription.route';
import prescriptionTypeRouter from './routes/prescriptionType.route';
import opticalCorrectionRouter from './routes/opticalCorrection.route';
import medicationRouter from './routes/medication.route';

import calendarRouter from './routes/calendar.route';

import notificationRouter from './routes/notification.route';

import tarificationRouter from './routes/tarification.route';

import messagingRouter from './routes/messaging.route';

import demandRouter from './routes/demand.route';

import paymentRouter from './routes/payment.route';

import medicalReportRouter from './routes/medicalReport.route';

import aiMedicalReportRouter from './routes/aiMedicalReport.route';

import { requireDoctorFromAuth } from './middlewares/doctor';

import contactRouter from './routes/contact.route';

import consultationInvoiceRouter from './routes/consultationInvoice.route';

import medicalShareRouter from './routes/medicalShare.route';

import patientCallNotificationRouter from './routes/patientCallNotification.route';

import doctorPatientPrivacyRouter from './routes/doctorPatientPrivacy.route';

import customMedicationRouter from './routes/customMedication.routes';

import dashboardRouter from './routes/dashboard.route';

import dentalActRouter from './routes/dentalAct.route';

import cardiologyReportRouter from './routes/cardiologyReport.route';

import ophthoReportRouter from './routes/ophthoReport.route';



// ============================================

// SENTRY TRACING MIDDLEWARE (Manual for Bun compatibility)

// ============================================

app.use((req: Request, res: Response, next: NextFunction) => {

	Sentry.startSpan(

		{

			op: 'http.server',

			name: `${req.method} ${req.path}`,

		},

		() => {

			next();

		}

	);

});



// ============================================

// ROUTES CONFIGURATION

// ============================================

// Health check endpoint for Docker/Kubernetes

app.get('/health', (req: Request, res: Response) => {

	res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });

});



// Auth routes have their own rate limiting applied per route (see auth.route.ts)

app.use('/auth', authRouter);

app.use('/demand', demandRouter);

app.use('/contact', contactRouter);



// Global Caching Middleware

// Applied after auth routes (which are public/sensitive) and before protected routes

import { cacheMiddleware, cacheInvalidationMiddleware } from './middlewares/cacheMiddleware';



// Cache invalidation on mutations (POST, PUT, DELETE) - MUST be before cacheMiddleware

app.use(cacheInvalidationMiddleware());



app.use(cacheMiddleware({

	duration: 300, // 5 minutes (reduced from 10 for faster updates)

	excludePaths: [

		'/auth', // double check

		'/payment', // Webhooks are POST but good to check

		'/admin',

		'/waiting-room/schedule', // Real-time data - no cache

		'/waiting-room', // Waiting room needs fresh data

		'/appointment', // Appointments need fresh data for dashboard sync

		'/calendar' // Calendar needs fresh data

	]

}));



// Static file serving for uploads with explicit CORS and content-type headers

app.use('/uploads', cors(advancedCorsOptions), (req: Request, res: Response, next: NextFunction) => {

	// Set additional headers for proper file serving

	res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');

	res.setHeader('X-Content-Type-Options', 'nosniff');

	next();

}, express.static('uploads', {

	setHeaders: (res: Response, path: string) => {

		// Set proper content type based on file extension

		if (path.endsWith('.pdf')) {

			res.setHeader('Content-Type', 'application/pdf');

			res.setHeader('Content-Disposition', 'inline');

		} else if (path.match(/\.(jpg|jpeg|png|gif)$/i)) {

			res.setHeader('Content-Type', 'image/' + path.split('.').pop());

		}

	}

}));



app.use('/user', requireAuth, userRouter);

app.use('/admin', adminRouter); // Admin routes



// ============================================

// ROUTES WITH RLS PROTECTION (Patient Data Access)

// Le middleware setRLSContext définit app.current_user_id pour PostgreSQL RLS

// ============================================

app.use('/patient', requireDoctorFromAuth, requireAuth, setRLSContext, patientRouter);

app.use('/appointment', requireAuth, setRLSContext, appointmentRouter);

app.use('/waiting-room', requireAuth, setRLSContext, waitingRouter);

app.use('/prescription', requireAuth, requireDoctorAuth, setRLSContext, prescriptionRouter);
app.use('/prescription-type', requireAuth, requireDoctorAuth, prescriptionTypeRouter);
app.use('/optical-correction', requireAuth, requireDoctorAuth, setRLSContext, opticalCorrectionRouter);
app.use('/medication', requireAuth, requireDoctorAuth, medicationRouter);

app.use('/calendar', requireAuth, setRLSContext, calendarRouter);

app.use('/notification', requireAuth, notificationRouter);

app.use('/tarification', requireAuth, tarificationRouter);

app.use('/messaging', requireAuth, messagingRouter);

app.use('/payment', paymentRouter); // Webhook already registered at line 110, this handles other payment routes

app.use('/medical-reports', requireAuth, medicalReportRouter); // Medical reports

app.use('/api/ai/medical-report', requireAuth, aiMedicalReportRouter); // AI medical report generation

app.use('/consultation-invoice', requireAuth, consultationInvoiceRouter); // Consultation invoices

app.use('/medical-shares', requireAuth, medicalShareRouter); // Medical shares between doctors

app.use('/patient-call-notifications', requireAuth, patientCallNotificationRouter); // Patient call notifications for assistant

app.use('/doctor-patient-privacy', requireAuth, doctorPatientPrivacyRouter); // Doctor privacy choice per patient

app.use('/custom-medications', customMedicationRouter); // Custom medications added by doctors

app.use('/dashboard', requireAuth, dashboardRouter); // Dashboard stats endpoint

app.use('/api', requireAuth, dentalActRouter); // Dental acts and catalog routes

app.use('/api', requireAuth, cardiologyReportRouter); // Cardiology reports and scores

app.use('/api', requireAuth, ophthoReportRouter); // Ophthalmology reports (XML import + PDF)

