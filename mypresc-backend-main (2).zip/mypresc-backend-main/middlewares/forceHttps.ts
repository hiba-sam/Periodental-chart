/**
 * Force HTTPS Middleware - MyPresc Backend
 * 
 * Redirige automatiquement les requêtes HTTP vers HTTPS en production
 * Détecte le protocole via X-Forwarded-Proto (derrière reverse proxy)
 * 
 * Conformité : OWASP A02:2021 (Cryptographic Failures)
 */

import type { Request, Response, NextFunction } from 'express';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CONFIGURATION
// ============================================

const FORCE_HTTPS = process.env.FORCE_HTTPS === 'true';
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

// ============================================
// MIDDLEWARE
// ============================================

/**
 * Force HTTPS en production
 */
export function forceHttps(req: Request, res: Response, next: NextFunction) {
    // Ignorer si FORCE_HTTPS désactivé ou pas en production
    if (!FORCE_HTTPS || !IS_PRODUCTION) {
        return next();
    }
    
    // Détecter le protocole
    const protocol = req.headers['x-forwarded-proto'] || req.protocol;
    
    // Si déjà HTTPS, continuer
    if (protocol === 'https') {
        return next();
    }
    
    // Si HTTP, rediriger vers HTTPS
    const host = req.headers.host || req.hostname;
    const url = req.url;
    const redirectUrl = `https://${host}${url}`;
    
    // Logger la redirection
    securityLogger.info('[HTTPS] Redirecting HTTP to HTTPS', {
        originalUrl: `http://${host}${url}`,
        redirectUrl,
        ip: req.ip || req.socket.remoteAddress,
        event: 'HTTPS_REDIRECT'
    });
    
    // Redirection permanente 301
    res.redirect(301, redirectUrl);
}

export default forceHttps;
