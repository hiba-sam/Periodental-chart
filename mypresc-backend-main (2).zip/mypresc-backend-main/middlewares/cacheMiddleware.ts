import type { Request, Response, NextFunction } from 'express';
import redisClient from '../config/redis';

interface CacheOptions {
    duration: number;
    excludePaths?: string[];
}

/**
 * Invalidate cache for ALL users matching specific patterns
 * This is needed because data is shared between doctor and assistant
 */
export const invalidateGlobalCache = async (patterns?: string[]) => {
    if (redisClient.status !== 'ready') return;
    
    try {
        // Get ALL cache keys
        const allKeys = await redisClient.keys(`cache:user:*`);
        
        if (patterns && patterns.length > 0) {
            // Only delete keys matching specific patterns
            const keysToDelete = allKeys.filter(key => 
                patterns.some(pattern => key.includes(pattern))
            );
            if (keysToDelete.length > 0) {
                await redisClient.del(...keysToDelete);
                console.log(`Global cache invalidated: ${keysToDelete.length} keys for patterns [${patterns.join(', ')}]`);
            }
        } else if (allKeys.length > 0) {
            // Delete all cache (use with caution)
            await redisClient.del(...allKeys);
            console.log(`Global cache invalidated: ${allKeys.length} keys`);
        }
    } catch (err) {
        console.error('Cache invalidation error:', err);
    }
};

/**
 * Middleware to automatically invalidate cache on mutations
 * Uses PRE-EMPTIVE invalidation: cache is cleared BEFORE the mutation
 * This ensures the next GET request will fetch fresh data
 */
export const cacheInvalidationMiddleware = () => {
    return async (req: Request, res: Response, next: NextFunction) => {
        // Only invalidate on mutations
        if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
            return next();
        }

        const userId = (req.user as any)?.id || (req.user as any)?._id;
        if (!userId) return next();

        // PRE-EMPTIVE: Invalidate cache BEFORE processing the mutation
        // This ensures that when the client fetches after the mutation response,
        // the cache is already cleared and fresh data will be fetched
        const patterns = getCachePatterns(req.originalUrl);
        try {
            await invalidateGlobalCache(patterns);
        } catch (err) {
            console.error('Pre-emptive cache invalidation failed:', err);
            // Continue anyway - don't block the mutation
        }

        next();
    };
};

/**
 * Get cache patterns to invalidate based on the mutation URL
 */
function getCachePatterns(url: string): string[] {
    // Map mutation endpoints to related cache patterns
    if (url.includes('/patient')) return ['/patient'];
    if (url.includes('/prescription')) return ['/prescription', '/patient'];
    if (url.includes('/medical-report') || url.includes('/compte-rendu')) return ['/medical-report', '/compte-rendu', '/patient'];
    if (url.includes('/message') || url.includes('/conversation')) return ['/message', '/conversation'];
    if (url.includes('/waiting-room')) return ['/waiting-room', '/appointment'];
    if (url.includes('/appointment')) return ['/appointment', '/calendar', '/waiting-room'];
    if (url.includes('/calendar')) return ['/calendar', '/appointment', '/waiting-room'];
    if (url.includes('/notification')) return ['/notification'];
    // Default: invalidate all cache for this user
    return [];
}

/**
 * Smart Cache Middleware
 * Caches responses based on User ID to ensure privacy.
 * @param options Configuration options
 */
export const cacheMiddleware = (options: CacheOptions = { duration: 600 }) => {
    return async (req: Request, res: Response, next: NextFunction) => {
        // 1. Only cache GET requests
        if (req.method !== 'GET') {
            return next();
        }

        // 2. Check exclusions
        if (options.excludePaths) {
            for (const path of options.excludePaths) {
                if (req.originalUrl.startsWith(path)) {
                    return next();
                }
            }
        }

        // 3. Fail-safe: If Redis is not ready, skip
        if (redisClient.status !== 'ready') {
            return next();
        }

        // 4. Privacy Guard: Strict User Isolation
        // If user is not authenticated, DO NOT cache to avoid leaking shared data
        // Assuming req.user is populated by passport/auth middleware
        const userId = (req.user as any)?.id || (req.user as any)?._id;

        if (!userId) {
            // Context: User said "There is no globale data, every endpoint personalized"
            // So if we don't know who it is, we can't safely cache it.
            return next();
        }

        const key = `cache:user:${userId}:${req.originalUrl}`;

        try {
            const cachedBody = await redisClient.get(key);
            if (cachedBody) {
                res.setHeader('X-Cache', 'HIT');
                res.setHeader('Content-Type', 'application/json');
                return res.send(cachedBody);
            }
        } catch (err) {
            console.error('Redis Get Error:', err);
            return next();
        }

        // Cache Miss
        res.setHeader('X-Cache', 'MISS');

        const originalJson = res.json.bind(res);

        res.json = (body: any): Response => {
            res.json = originalJson;

            if (redisClient.status === 'ready') {
                try {
                    redisClient.set(key, JSON.stringify(body), 'EX', options.duration)
                        .catch(err => console.error('Redis Set Error:', err));
                } catch (err) {
                    console.error('Redis Stringify Error:', err);
                }
            }

            return originalJson(body);
        };

        next();
    };
};
