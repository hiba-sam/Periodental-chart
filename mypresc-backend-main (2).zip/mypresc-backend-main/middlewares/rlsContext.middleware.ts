import type { Request, Response, NextFunction } from 'express';
import pool from '../db';

/**
 * Middleware pour définir le contexte utilisateur pour Row-Level Security (RLS)
 * 
 * Ce middleware définit la variable de session PostgreSQL `app.current_user_id`
 * qui est utilisée par les policies RLS pour filtrer les données.
 * 
 * Conformité: Loi 18-07 Algérie - Protection des données personnelles
 */
export async function setRLSContext(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
        // Récupérer l'ID utilisateur depuis le token JWT décodé
        const userId = (req as any).user?.id || (req as any).userId;

        if (userId) {
            // Définir le contexte utilisateur pour la session DB
            await pool.query('SELECT set_config($1, $2, false)', [
                'app.current_user_id',
                userId.toString()
            ]);
        }

        next();
    } catch (error) {
        console.error('[RLS Context] Error setting user context:', error);
        // Ne pas bloquer la requête si le RLS context échoue
        next();
    }
}

/**
 * Middleware pour nettoyer le contexte RLS après la requête
 * À utiliser comme middleware de fin de chaîne
 */
export async function clearRLSContext(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
        await pool.query('RESET app.current_user_id');
    } catch (error) {
        console.error('[RLS Context] Error clearing user context:', error);
    }
    next();
}

/**
 * Helper pour définir manuellement le contexte RLS
 * Utile pour les jobs batch ou scripts
 */
export async function setManualRLSContext(userId: number): Promise<void> {
    await pool.query('SELECT set_config($1, $2, false)', [
        'app.current_user_id',
        userId.toString()
    ]);
}

/**
 * Helper pour exécuter une requête avec un contexte RLS spécifique
 * Utile pour les opérations admin qui doivent accéder à tous les patients
 */
export async function withRLSContext<T>(
    userId: number,
    callback: () => Promise<T>
): Promise<T> {
    const client = await pool.connect();
    try {
        await client.query('SELECT set_config($1, $2, true)', [
            'app.current_user_id',
            userId.toString()
        ]);
        
        const result = await callback();
        
        return result;
    } finally {
        await client.query('RESET app.current_user_id');
        client.release();
    }
}

/**
 * Middleware combiné: définit le contexte et nettoie automatiquement
 */
export function withRLSMiddleware() {
    return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        const userId = (req as any).user?.id || (req as any).userId;

        if (!userId) {
            return next();
        }

        try {
            // Définir le contexte
            await pool.query('SELECT set_config($1, $2, false)', [
                'app.current_user_id',
                userId.toString()
            ]);

            // Nettoyer après la réponse
            res.on('finish', async () => {
                try {
                    await pool.query('RESET app.current_user_id');
                } catch (error) {
                    console.error('[RLS Context] Error clearing context on finish:', error);
                }
            });

            next();
        } catch (error) {
            console.error('[RLS Context] Error in middleware:', error);
            next();
        }
    };
}
