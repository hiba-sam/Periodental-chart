/**
 * IP & Country Filtering Middleware - MyPresc Backend
 * 
 * Filtrage basé sur :
 * - IP individuelles ou plages CIDR (allowlist/denylist)
 * - Géolocalisation par pays (si activé)
 * 
 * Conformité : OWASP A01:2021 (Broken Access Control)
 */

import type { Request, Response, NextFunction } from 'express';
import ipRangeCheck from 'ip-range-check';
// @ts-ignore - geoip-lite n'a pas de types officiels
import geoip from 'geoip-lite';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CONFIGURATION
// ============================================

// IP autorisées (CSV, support CIDR)
const ALLOWED_IPS = process.env.ALLOWED_IPS?.split(',')
    .map(ip => ip.trim())
    .filter(ip => ip.length > 0) || [];

// IP interdites (CSV, support CIDR)
const DENIED_IPS = process.env.DENIED_IPS?.split(',')
    .map(ip => ip.trim())
    .filter(ip => ip.length > 0) || [];

// Géolocalisation activée
const GEOIP_ENABLED = process.env.GEOIP_ENABLED === 'true';

// Pays autorisés (codes ISO 2 lettres : DZ, FR, etc.)
const ALLOWED_COUNTRIES = process.env.ALLOWED_COUNTRIES?.split(',')
    .map(c => c.trim().toUpperCase())
    .filter(c => c.length > 0) || [];

// ============================================
// FONCTIONS HELPER
// ============================================

/**
 * Extraire l'IP réelle du client (derrière proxy/load balancer)
 */
function getClientIP(req: Request): string {
    // Vérifier les headers de proxy
    const xForwardedFor = req.headers['x-forwarded-for'];
    
    if (xForwardedFor) {
        // X-Forwarded-For peut contenir plusieurs IPs séparées par des virgules
        // Prendre la première (IP originale du client)
        let ips: string = '';
        if (Array.isArray(xForwardedFor)) {
            ips = xForwardedFor[0] || '';
        } else {
            ips = xForwardedFor;
        }
        if (ips && ips.length > 0) {
            return ips.split(',')[0].trim();
        }
    }
    
    // Autres headers de proxy
    const xRealIP = req.headers['x-real-ip'];
    if (xRealIP && typeof xRealIP === 'string') {
        return xRealIP;
    }
    
    // IP directe
    return req.ip || req.socket.remoteAddress || 'unknown';
}

/**
 * Vérifier si une IP est dans une liste (support CIDR)
 */
function isIPInList(ip: string, list: string[]): boolean {
    if (list.length === 0) return false;
    
    try {
        return ipRangeCheck(ip, list);
    } catch (error) {
        securityLogger.error('[IPFILTER] Error checking IP range', {
            ip,
            list: list.join(', '),
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        return false;
    }
}

/**
 * Obtenir le pays d'une IP via géolocalisation
 */
function getCountryFromIP(ip: string): string | null {
    try {
        const geo = geoip.lookup(ip);
        return geo?.country || null;
    } catch (error) {
        securityLogger.error('[IPFILTER] GeoIP lookup error', {
            ip,
            error: error instanceof Error ? error.message : 'Unknown error'
        });
        return null;
    }
}

// ============================================
// MIDDLEWARE
// ============================================

/**
 * Middleware de filtrage IP et géolocalisation
 */
export function ipFilter(req: Request, res: Response, next: NextFunction) {
    const clientIP = getClientIP(req);
    const path = req.path;
    const method = req.method;
    
    // Ignorer les IPs locales en développement
    if (process.env.NODE_ENV !== 'production') {
        const localIPs = ['127.0.0.1', '::1', 'localhost', '::ffff:127.0.0.1'];
        if (localIPs.includes(clientIP)) {
            return next();
        }
    }
    
    // ============================================
    // 1. VÉRIFIER DENYLIST
    // ============================================
    
    if (DENIED_IPS.length > 0 && isIPInList(clientIP, DENIED_IPS)) {
        securityLogger.warn('[IPFILTER] Blocked denied IP', {
            ip: clientIP,
            path,
            method,
            reason: 'IP in denylist',
            event: 'IPFILTER_BLOCK'
        });
        
        return res.status(403).json({
            success: false,
            error: 'Access denied',
            code: 'IP_BLOCKED',
            message: 'Your IP address has been blocked.'
        });
    }
    
    // ============================================
    // 2. VÉRIFIER ALLOWLIST (si définie)
    // ============================================
    
    if (ALLOWED_IPS.length > 0) {
        if (!isIPInList(clientIP, ALLOWED_IPS)) {
            securityLogger.warn('[IPFILTER] Blocked non-whitelisted IP', {
                ip: clientIP,
                path,
                method,
                reason: 'IP not in allowlist',
                allowedIPs: ALLOWED_IPS.join(', '),
                event: 'IPFILTER_BLOCK'
            });
            
            return res.status(403).json({
                success: false,
                error: 'Access denied',
                code: 'IP_NOT_ALLOWED',
                message: 'Your IP address is not authorized to access this service.'
            });
        }
    }
    
    // ============================================
    // 3. VÉRIFIER GÉOLOCALISATION (si activée)
    // ============================================
    
    if (GEOIP_ENABLED && ALLOWED_COUNTRIES.length > 0) {
        const country = getCountryFromIP(clientIP);
        
        if (!country) {
            securityLogger.warn('[IPFILTER] Unable to determine country', {
                ip: clientIP,
                path,
                method,
                event: 'GEOIP_LOOKUP_FAILED'
            });
            
            // Décision : bloquer ou autoriser si géolocalisation échoue ?
            // Par défaut : autoriser (éviter faux positifs)
            // En production stricte, on peut bloquer
            if (process.env.GEOIP_STRICT === 'true') {
                return res.status(403).json({
                    success: false,
                    error: 'Access denied',
                    code: 'GEOIP_FAILED',
                    message: 'Unable to verify your location.'
                });
            }
        } else if (!ALLOWED_COUNTRIES.includes(country)) {
            securityLogger.warn('[IPFILTER] Blocked country', {
                ip: clientIP,
                country,
                path,
                method,
                reason: 'Country not in allowlist',
                allowedCountries: ALLOWED_COUNTRIES.join(', '),
                event: 'IPFILTER_BLOCK'
            });
            
            return res.status(403).json({
                success: false,
                error: 'Access denied',
                code: 'COUNTRY_BLOCKED',
                message: 'Access from your country is not allowed.'
            });
        }
    }
    
    // Tout est OK, continuer
    next();
}

/**
 * Fonction helper pour obtenir les informations d'une IP (debugging)
 */
export function getIPInfo(ip: string) {
    const geo = geoip.lookup(ip);
    return {
        ip,
        country: geo?.country || null,
        region: geo?.region || null,
        city: geo?.city || null,
        timezone: geo?.timezone || null,
        coordinates: geo?.ll || null
    };
}

export default ipFilter;
