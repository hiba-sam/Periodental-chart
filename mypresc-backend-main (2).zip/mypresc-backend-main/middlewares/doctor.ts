import type { NextFunction, Request, Response } from "express";
import { DoctorModel } from "../models/doctor.model";
import { UserModel, type User } from "../models/user.model";
import { AssistantModel } from "../models/assistant.model";
import dotenv from "dotenv";

dotenv.config();

// Extracts doctorUserId from authenticated user (req.user)
// If user is doctor: use user.id
// If user is assistant: use user.doctor_id
const requireDoctorFromAuth = async (
	req: Request,
	res: Response,
	next: NextFunction,
) => {
	const apiKey = req.headers["x-service-api-key"];
	const userid = req.headers["x-user-id"] as string;
	if (apiKey === process.env.CHATBOT_API_KEY && userid) {
		const user = await UserModel.findById(parseInt(userid));
		if (user) {
			req.user = user;
		}
	}
	const user = req.user as User;
	console.log("Authenticated user:", user);

	if (!user) {
		return res
			.status(401)
			.json({ success: false, error: "Authentication required" });
	}

	let doctorUserId: number;

	if (user.role === "doctor") {
		doctorUserId = user.id;
	} else if (user.role === "assistant") {
		const assistant = await AssistantModel.findByUserId(user.id);
		if (!assistant || !assistant.doctor_id) {
			return res.status(400).json({
				success: false,
				error: "Assistant account is not linked to a doctor",
			});
		}
		doctorUserId = assistant.doctor_id;
	} else {
		return res.status(403).json({
			success: false,
			error: "Only doctors and assistants can access this resource",
		});
	}

	// Verify doctor exists
	const doctor = await DoctorModel.findByUserId(doctorUserId);
	if (!doctor) {
		return res
			.status(400)
			.json({ success: false, error: "Doctor profile not found" });
	}

	res.locals.doctorUserId = doctorUserId;
	res.locals.userRole = user.role;
	next();
};

// Validates `doctorUserId` from query, ensures doctor exists, and exposes it via res.locals
const requireDoctorFromQuery = async (
	req: Request,
	res: Response,
	next: NextFunction,
) => {
	const { doctorUserId } = req.query as { doctorUserId?: string };

	if (!doctorUserId) {
		return res
			.status(400)
			.json({ success: false, error: "doctorUserId is required" });
	}

	const doctor = await DoctorModel.findByUserId(Number(doctorUserId));
	if (!doctor) {
		return res
			.status(400)
			.json({ success: false, error: "Doctor id is not valid" });
	}

	res.locals.doctorUserId = Number(doctorUserId);
	next();
};

// Validates `doctorUserId` from query OR body, ensures doctor exists, and exposes it via res.locals
const requireDoctor = async (
	req: Request,
	res: Response,
	next: NextFunction,
) => {
	// Try query first, then body
	const doctorUserIdStr =
		(req.query.doctorUserId as string) || (req.body.doctorUserId as string);

	if (!doctorUserIdStr) {
		return res
			.status(400)
			.json({ success: false, error: "doctorUserId is required" });
	}

	const doctorUserId = Number(doctorUserIdStr);
	if (isNaN(doctorUserId)) {
		return res
			.status(400)
			.json({ success: false, error: "doctorUserId must be a valid number" });
	}

	const doctor = await DoctorModel.findByUserId(doctorUserId);
	if (!doctor) {
		return res
			.status(400)
			.json({ success: false, error: "Doctor id is not valid" });
	}

	res.locals.doctorUserId = doctorUserId;
	next();
};

export { requireDoctorFromAuth, requireDoctorFromQuery, requireDoctor };
