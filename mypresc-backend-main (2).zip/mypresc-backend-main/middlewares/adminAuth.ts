import type { Request, Response, NextFunction } from "express";
import { AdminModel } from "../models/admin.model";

// ============================================
// EXTEND EXPRESS REQUEST TYPE
// ============================================
declare global {
    namespace Express {
        interface Request {
            admin?: {
                id: number;
                name: string;
                email: string;
                role: string;
            };
        }
    }
}

// ============================================
// ADMIN AUTHENTICATION MIDDLEWARE
// ============================================

/**
 * Verify that the user is an authenticated admin
 * Checks session and validates admin status
 */
export const requireAdmin = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        // Check if session exists and has admin data
        if (!req.session || !req.session.admin) {
            return res.status(401).json({
                success: false,
                error: "Unauthorized. Admin authentication required."
            });
        }

        const adminId = req.session.admin.id;

        // Verify admin exists and is active
        const admin = await AdminModel.findById(adminId);

        if (!admin) {
            // Admin no longer exists
            req.session.destroy(() => {});
            return res.status(401).json({
                success: false,
                error: "Admin account not found."
            });
        }

        if (!admin.is_active) {
            // Admin is deactivated
            req.session.destroy(() => {});
            return res.status(403).json({
                success: false,
                error: "Admin account is deactivated."
            });
        }

        // Attach admin info to request
        req.admin = {
            id: admin.id,
            name: admin.name,
            email: admin.email,
            role: admin.role
        };

        next();
    } catch (error) {
        console.error("❌ Admin authentication error:", error);
        res.status(500).json({
            success: false,
            error: "Authentication verification failed."
        });
    }
};

/**
 * Verify that the admin has super_admin role
 */
export const requireSuperAdmin = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        // First check if admin is authenticated
        if (!req.admin) {
            return res.status(401).json({
                success: false,
                error: "Unauthorized. Admin authentication required."
            });
        }

        // Check if super admin
        if (req.admin.role !== 'super_admin') {
            return res.status(403).json({
                success: false,
                error: "Forbidden. Super admin privileges required."
            });
        }

        next();
    } catch (error) {
        console.error("❌ Super admin verification error:", error);
        res.status(500).json({
            success: false,
            error: "Authorization verification failed."
        });
    }
};

/**
 * Optional admin auth - allows access but attaches admin if available
 */
export const optionalAdmin = async (
    req: Request,
    res: Response,
    next: NextFunction
) => {
    try {
        if (req.session && req.session.admin) {
            const adminId = req.session.admin.id;
            const admin = await AdminModel.findById(adminId);

            if (admin && admin.is_active) {
                req.admin = {
                    id: admin.id,
                    name: admin.name,
                    email: admin.email,
                    role: admin.role
                };
            }
        }

        next();
    } catch (error) {
        console.error("⚠️ Optional admin auth error:", error);
        // Don't block request on error
        next();
    }
};
