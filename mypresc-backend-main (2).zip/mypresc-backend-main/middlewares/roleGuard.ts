/**
 * Role Guard Middleware - MyPresc
 * 
 * Contrôle d'accès basé sur les rôles (RBAC)
 * Conformité : OWASP A05:2021, RGPD Art.5, ANPDP Art.25
 */

import type { Request, Response, NextFunction } from 'express';
import { UserRole, hasPermission } from '../types/roles';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// MIDDLEWARE PRINCIPAL
// ============================================

/**
 * Middleware de vérification de rôle
 * 
 * @param allowedRoles - Liste des rôles autorisés
 * @returns Middleware Express
 */
export function requireRole(allowedRoles: UserRole[] | UserRole) {
    // Normaliser en tableau
    const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
    
    return (req: Request, res: Response, next: NextFunction) => {
        // Vérifier que l'utilisateur est authentifié
        if (!req.user || !req.isAuthenticated()) {
            securityLogger.warn('[ACCESS] Unauthenticated access attempt', {
                event: 'ACCESS_DENIED',
                reason: 'NOT_AUTHENTICATED',
                ip: req.ip || 'unknown',
                method: req.method,
                path: req.path
            });
            
            return res.status(401).json({
                error: 'Authentication required',
                message: 'You must be logged in to access this resource'
            });
        }
        
        // Récupérer le rôle de l'utilisateur
        const userRole = req.user.role as UserRole;
        
        // Vérifier si le rôle est autorisé
        if (!roles.includes(userRole)) {
            securityLogger.warn('[ACCESS] Role access denied', {
                event: 'ACCESS_DENIED',
                reason: 'INSUFFICIENT_ROLE',
                userId: req.user.id,
                email: req.user.email,
                userRole: userRole,
                requiredRoles: roles,
                ip: req.ip || 'unknown',
                method: req.method,
                path: req.path
            });
            
            return res.status(403).json({
                error: 'Access forbidden',
                message: `Your role (${userRole}) is not authorized to access this resource`,
                requiredRoles: roles
            });
        }
        
        // Accès autorisé
        securityLogger.info('[ACCESS] Role access granted', {
            event: 'ACCESS_GRANTED',
            userId: req.user.id,
            email: req.user.email,
            userRole: userRole,
            method: req.method,
            path: req.path
        });
        
        next();
    };
}

// ============================================
// MIDDLEWARE SPÉCIFIQUES
// ============================================

/**
 * Autorise uniquement les docteurs
 */
export const requireDoctor = requireRole(UserRole.DOCTOR);

/**
 * Autorise docteurs et assistants
 */
export const requireMedicalStaff = requireRole([UserRole.DOCTOR, UserRole.ASSISTANT]);

/**
 * Autorise uniquement les admins
 */
export const requireAdmin = requireRole(UserRole.ADMIN);

/**
 * Autorise tous les utilisateurs authentifiés
 */
export const requireAnyRole = requireRole([
    UserRole.DOCTOR,
    UserRole.ASSISTANT,
    UserRole.PATIENT,
    UserRole.ADMIN
]);

// ============================================
// MIDDLEWARE DE VÉRIFICATION D'ÉCRITURE
// ============================================

/**
 * Vérifie que l'utilisateur peut modifier des données
 * (bloque les assistants en lecture seule)
 */
export function requireWriteAccess(req: Request, res: Response, next: NextFunction) {
    if (!req.user || !req.isAuthenticated()) {
        return res.status(401).json({
            error: 'Authentication required'
        });
    }
    
    const userRole = req.user.role as UserRole;
    
    // Les assistants ne peuvent pas modifier
    if (userRole === UserRole.ASSISTANT) {
        securityLogger.warn('[ACCESS] Write access denied for assistant', {
            event: 'ACCESS_DENIED',
            reason: 'READ_ONLY_ROLE',
            userId: req.user.id,
            email: req.user.email,
            userRole: userRole,
            method: req.method,
            path: req.path
        });
        
        return res.status(403).json({
            error: 'Access forbidden',
            message: 'Assistants have read-only access'
        });
    }
    
    next();
}

// ============================================
// MIDDLEWARE DE RESTRICTION PATIENT
// ============================================

/**
 * Vérifie que le patient ne peut accéder qu'à ses propres données
 * Les médecins et assistants ont accès à tous les patients (centralisation)
 */
export function requireOwnDataOrMedicalStaff(req: Request, res: Response, next: NextFunction) {
    if (!req.user || !req.isAuthenticated()) {
        return res.status(401).json({
            error: 'Authentication required'
        });
    }
    
    const userRole = req.user.role as UserRole;
    
    // Médecins et assistants : accès total (centralisation)
    if (userRole === UserRole.DOCTOR || userRole === UserRole.ASSISTANT || userRole === UserRole.ADMIN) {
        return next();
    }
    
    // Patients : uniquement leurs propres données
    if (userRole === UserRole.PATIENT) {
        const patientId = req.params.id || req.params.patientId || req.body.patientId;
        const userId = req.user.id;
        
        // Vérifier que le patient accède à ses propres données
        if (patientId && patientId !== userId.toString()) {
            securityLogger.warn('[ACCESS] Patient attempted to access other patient data', {
                event: 'ACCESS_DENIED',
                reason: 'NOT_OWN_DATA',
                userId: req.user.id,
                email: req.user.email,
                requestedPatientId: patientId,
                method: req.method,
                path: req.path
            });
            
            return res.status(403).json({
                error: 'Access forbidden',
                message: 'Patients can only access their own data'
            });
        }
    }
    
    next();
}

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Vérifie si l'utilisateur actuel a un rôle spécifique
 */
export function hasRole(req: Request, role: UserRole): boolean {
    return req.user && req.user.role === role;
}

/**
 * Vérifie si l'utilisateur actuel a l'un des rôles spécifiés
 */
export function hasAnyRole(req: Request, roles: UserRole[]): boolean {
    return req.user && roles.includes(req.user.role as UserRole);
}

/**
 * Retourne le rôle de l'utilisateur actuel
 */
export function getUserRole(req: Request): UserRole | null {
    return req.user ? (req.user.role as UserRole) : null;
}
