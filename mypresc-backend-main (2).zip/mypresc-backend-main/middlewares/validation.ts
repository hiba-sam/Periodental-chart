/**
 * Input Validation Middleware - MyPresc Backend
 * 
 * Système complet de validation et sanitisation des entrées
 * Protection contre : XSS, SQL Injection, NoSQL Injection, données invalides
 * Conformité : OWASP A03:2021 (Injection), RGPD art. 32
 */

import type { NextFunction, Request, Response } from "express";
import { body, param, query, validationResult } from "express-validator";
import { securityLogger } from "../utils/securityLogger";

// ============================================
// VALIDATION REQUEST HANDLER
// ============================================

/**
 * Middleware central de validation
 * Vérifie les erreurs et log les tentatives d'injection
 */
export const validateRequest = (req: Request, res: Response, next: NextFunction) => {
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
        // Log de sécurité : tentative d'injection ou données invalides
        securityLogger.warn('[VALIDATION] Input validation failed', {
            ip: req.ip || req.socket.remoteAddress,
            endpoint: `${req.method} ${req.path}`,
            errors: errors.array(),
            body: sanitizeForLog(req.body),
            timestamp: new Date().toISOString(),
            event: 'VALIDATION_FAILED'
        });

        return res.status(400).json({
            success: false,
            error: 'Validation failed',
            details: errors.array().map(err => ({
                field: err.type === 'field' ? err.path : 'unknown',
                message: err.msg
            }))
        });
    }
    
    next();
};

/**
 * Sanitise les données pour les logs (masque les mots de passe)
 */
function sanitizeForLog(data: any): any {
    if (!data) return data;
    
    const sanitized = { ...data };
    const sensitiveFields = ['password', 'token', 'secret'];
    
    for (const field of sensitiveFields) {
        if (sanitized[field]) {
            sanitized[field] = '***REDACTED***';
        }
    }
    
    return sanitized;
}

// ============================================
// AUTH VALIDATORS
// ============================================

export const registerValidator = [
    body('email')
        .trim()
        .isEmail().withMessage('Email must be valid')
        .normalizeEmail()
        .isLength({ max: 255 }).withMessage('Email must not exceed 255 characters'),
    
    body('password')
        .isLength({ min: 12 }).withMessage('Password must be at least 12 characters long')
        .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
        .matches(/[a-z]/).withMessage('Password must contain at least one lowercase letter')
        .matches(/[0-9]/).withMessage('Password must contain at least one number')
        .matches(/[@$!%*?&#]/).withMessage('Password must contain at least one special character'),
    
    body('name')
        .trim()
        .escape()
        .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Name contains invalid characters'),
    
    body('family_name')
        .trim()
        .escape()
        .isLength({ min: 2, max: 100 }).withMessage('Family name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Family name contains invalid characters'),
    
    body('role')
        .trim()
        .isIn(['doctor', 'assistant', 'patient']).withMessage('Role must be doctor, assistant, or patient')
];

// ============================================
// USER UPDATE VALIDATORS
// ============================================

export const updateMeValidator = [
    body('name')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Name contains invalid characters'),

    body('family_name')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 2, max: 100 }).withMessage('Family name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Family name contains invalid characters'),

    body('password')
        .optional(),

    body('currentPassword')
        .if(body('password').exists())
        .notEmpty().withMessage('Current password is required when changing password')
        .isString().withMessage('Current password must be a string'),

    // Doctor-specific fields
    body('phone_number')
        .optional()
        .matches(/^[0-9]{9,15}$/).withMessage('Phone number must be 9-15 digits'),

    body('birth_date')
        .optional()
        .isISO8601().withMessage('Birth date must be a valid date'),

    body('birth_place')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Birth place must not exceed 255 characters'),

    body('work_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('Work location must not exceed 500 characters'),

    body('home_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('Home location must not exceed 500 characters'),

    body('speciality')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Speciality must not exceed 255 characters'),

    body('experience')
        .optional()
        .isInt({ min: 0, max: 70 }).withMessage('Experience must be between 0 and 70 years'),

    body('about')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 2000 }).withMessage('About must not exceed 2000 characters'),

    body('languages')
        .optional()
        .isArray().withMessage('Languages must be an array'),

    body('work_time')
        .optional()
        .isArray().withMessage('Work time must be an array')
];

// ============================================
// PATIENT VALIDATORS
// ============================================

export const createPatientValidator = [
    body('name')
        .trim()
        .escape()
        .isLength({ min: 2, max: 255 }).withMessage('Name must be between 2 and 255 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Name contains invalid characters'),

    body('family_name')
        .trim()
        .escape()
        .isLength({ min: 2, max: 255 }).withMessage('Family name must be between 2 and 255 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Family name contains invalid characters'),

    body('date_naissance')
        .optional()
        .isISO8601().withMessage('Birth date must be a valid ISO 8601 date')
        .custom((value) => {
            const date = new Date(value);
            const now = new Date();
            if (date > now) {
                throw new Error('Birth date cannot be in the future');
            }
            return true;
        }),

    body('telephone')
        .optional()
        .matches(/^[0-9]{9,15}$/).withMessage('Phone number must be 9-15 digits'),

    body('genre')
        .optional()
        .isIn(['homme', 'femme']).withMessage('Genre must be homme or femme'),

    body('email')
        .optional()
        .trim()
        .isEmail().withMessage('Email must be valid')
        .normalizeEmail(),

    body('adresse')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('Address must not exceed 500 characters'),

    body('nin')
        .optional()
        .trim()
        .isLength({ max: 64 }).withMessage('National identity number must not exceed 64 characters'),

    body('numero_securite_sociale')
        .optional()
        .trim()
        .isLength({ max: 255 }).withMessage('Social security number must not exceed 255 characters'),

    body('medecin_traitant')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Treating physician name must not exceed 255 characters'),

    body('allergies')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Allergies must not exceed 5000 characters'),

    body('chronicdiseases')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Chronic diseases must not exceed 5000 characters'),

    body('emergencycontact')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Emergency contact must not exceed 255 characters'),

    body('emergencyphone')
        .optional()
        .trim()
        .matches(/^[0-9\s\-+()]{9,20}$/).withMessage('Emergency phone must be a valid phone number'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters')
];

// ============================================
// PRESCRIPTION VALIDATORS
// ============================================

export const createPrescriptionValidator = [
    body('doctor_user_id')
        .optional()
        .isInt({ min: 1 }).withMessage('Doctor user ID must be a positive integer'),

    body('confirmed_count')
        .optional()
        .isInt({ min: 1 }).withMessage('Confirmed count must be a positive integer'),

    body('remarks')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Remarks must not exceed 5000 characters'),

    body('prescription_medications')
        .optional()
        .isArray().withMessage('Prescription medications must be an array'),

    body('prescription_medications.*.medication_id')
        .optional()
        .isInt({ min: 1 }).withMessage('Medication ID must be a positive integer'),

    body('prescription_medications.*.quantity')
        .optional()
        .isInt({ min: 1 }).withMessage('Quantity must be a positive integer'),

    body('prescription_medications.*.dosage')
        .optional()
        .trim()
        .isLength({ max: 500 }).withMessage('Dosage must not exceed 500 characters'),

    body('prescription_medications.*.note')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 1000 }).withMessage('Medication note must not exceed 1000 characters')
];

export const getPrescriptionValidator = [
    param('id')
        .isInt({ min: 1 }).withMessage('Prescription ID must be a positive integer')
];

export const getPatientValidator = [
    param('id')
        .isUUID(4).withMessage('Patient ID must be a valid UUID')
];

export const getAppointmentValidator = [
    param('id')
        .isUUID(4).withMessage('Appointment ID must be a valid UUID')
];

export const updateAppointmentValidator = [
    param('id')
        .isUUID(4).withMessage('Appointment ID must be a valid UUID'),

    body('date')
        .optional()
        .isISO8601().withMessage('Date must be a valid ISO 8601 date'),

    body('time')
        .optional()
        .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9](\.\d{1,6})?)?$/).withMessage('Time must be in valid format (HH:MM or HH:MM:SS)'),

    body('duration')
        .optional()
        .isInt({ min: 5, max: 480 }).withMessage('Duration must be between 5 and 480 minutes'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters'),

    body('is_done')
        .optional()
        .isBoolean().withMessage('is_done must be a boolean'),

    body('color')
        .optional()
        .trim()
        .matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).withMessage('Color must be a valid hex color code'),

    body('confirmed_coming')
        .optional()
        .isBoolean().withMessage('confirmed_coming must be a boolean')
];

export const updatePatientValidator = [
    param('id')
        .isUUID(4).withMessage('Patient ID must be a valid UUID'),

    body('name')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 2, max: 255 }).withMessage('Name must be between 2 and 255 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Name contains invalid characters'),

    body('family_name')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 2, max: 255 }).withMessage('Family name must be between 2 and 255 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/).withMessage('Family name contains invalid characters'),

    body('age')
        .optional()
        .isInt({ min: 0, max: 120 }).withMessage('Age must be between 0 and 120'),

    body('date_naissance')
        .optional()
        .isISO8601().withMessage('Birth date must be a valid ISO 8601 date'),

    body('telephone')
        .optional()
        .matches(/^[0-9]{9,15}$/).withMessage('Phone number must be 9-15 digits'),

    body('genre')
        .optional()
        .isIn(['homme', 'femme']).withMessage('Genre must be homme or femme'),

    body('email')
        .optional()
        .trim()
        .isEmail().withMessage('Email must be valid')
        .normalizeEmail(),

    body('adresse')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('Address must not exceed 500 characters'),

    body('nin')
        .optional()
        .trim()
        .isLength({ max: 64 }).withMessage('National identity number must not exceed 64 characters'),

    body('numero_securite_sociale')
        .optional()
        .trim()
        .isLength({ max: 255 }).withMessage('Social security number must not exceed 255 characters'),

    body('medecin_traitant')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Treating physician name must not exceed 255 characters'),

    body('allergies')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Allergies must not exceed 5000 characters'),

    body('chronicdiseases')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Chronic diseases must not exceed 5000 characters'),

    body('emergencycontact')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Emergency contact must not exceed 255 characters'),

    body('emergencyphone')
        .optional()
        .trim()
        .matches(/^[0-9\s\-+()]{9,20}$/).withMessage('Emergency phone must be a valid phone number'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters')
];

// ============================================
// APPOINTMENT VALIDATORS
// ============================================

export const createAppointmentValidator = [
    body('patient_id')
        .notEmpty().withMessage('Patient ID is required'),

    body('doctor_user_id')
        .optional()
        .isInt({ min: 1 }).withMessage('Doctor user ID must be a positive integer'),

    body('date')
        .notEmpty().withMessage('Date is required')
        .isISO8601().withMessage('Date must be a valid ISO 8601 date')
        .custom((value) => {
            const date = new Date(value);
            const now = new Date();
            const oneYearFromNow = new Date();
            oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);

            if (date < now) {
                throw new Error('Appointment date must be in the future');
            }
            if (date > oneYearFromNow) {
                throw new Error('Appointment date cannot be more than 1 year in the future');
            }
            return true;
        }),

    body('time')
        .notEmpty().withMessage('Time is required')
        .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9](\.\d{1,6})?)?$/).withMessage('Time must be in valid format (HH:MM or HH:MM:SS)'),

    body('duration')
        .optional()
        .isInt({ min: 5, max: 480 }).withMessage('Duration must be between 5 and 480 minutes (8 hours)'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters'),

    body('is_done')
        .optional()
        .isBoolean().withMessage('is_done must be a boolean'),

    body('color')
        .optional()
        .trim()
        .matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).withMessage('Color must be a valid hex color code'),

    body('confirmed_coming')
        .optional()
        .isBoolean().withMessage('confirmed_coming must be a boolean')
];


// ============================================
// MEDICATION VALIDATORS
// ============================================

export const createMedicationValidator = [
    body('nom_de_marque')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('Brand name must not exceed 500 characters'),

    body('denomination_commune_internationale')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 500 }).withMessage('International common denomination must not exceed 500 characters'),

    body('code')
        .optional()
        .trim()
        .isLength({ max: 100 }).withMessage('Code must not exceed 100 characters'),

    body('num_enregistrement')
        .optional()
        .trim()
        .isLength({ max: 100 }).withMessage('Registration number must not exceed 100 characters'),

    body('forme')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Form must not exceed 200 characters'),

    body('dosage')
        .optional()
        .trim()
        .isLength({ max: 200 }).withMessage('Dosage must not exceed 200 characters'),

    body('laboratoire')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 300 }).withMessage('Laboratory must not exceed 300 characters'),

    body('prix')
        .optional()
        .trim()
        .isLength({ max: 50 }).withMessage('Price must not exceed 50 characters'),

    body('statut')
        .optional()
        .trim()
        .isLength({ max: 100 }).withMessage('Status must not exceed 100 characters')
];

export const getMedicationValidator = [
    param('id')
        .isInt({ min: 1 }).withMessage('Medication ID must be a positive integer')
];

// ============================================
// DOCTOR VALIDATORS
// ============================================

export const createDoctorProfileValidator = [
    body('birth_date')
        .optional()
        .isISO8601().withMessage('Birth date must be a valid ISO 8601 date')
        .custom((value) => {
            const date = new Date(value);
            const now = new Date();
            if (date > now) {
                throw new Error('Birth date cannot be in the future');
            }
            return true;
        }),

    body('birth_place')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Birth place must not exceed 200 characters'),

    body('work_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Work location must not exceed 200 characters'),

    body('home_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Home location must not exceed 200 characters'),

    body('phone_number')
        .optional()
        .matches(/^[0-9\s\-+()]{9,20}$/).withMessage('Phone number must be a valid phone number'),

    body('speciality')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Speciality must not exceed 255 characters'),

    body('experience')
        .optional()
        .isInt({ min: 0, max: 70 }).withMessage('Experience must be between 0 and 70 years'),

    body('order_num')
        .optional()
        .trim()
        .isLength({ max: 255 }).withMessage('Order number must not exceed 255 characters'),

    body('about')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('About must not exceed 5000 characters'),

    body('languages')
        .optional()
        .isArray().withMessage('Languages must be an array'),

    body('languages.*')
        .optional()
        .trim()
        .isLength({ max: 50 }).withMessage('Language name must not exceed 50 characters')
];

export const updateDoctorProfileValidator = [
    body('birth_date')
        .optional()
        .isISO8601().withMessage('Birth date must be a valid ISO 8601 date'),

    body('birth_place')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Birth place must not exceed 200 characters'),

    body('work_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Work location must not exceed 200 characters'),

    body('home_location')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 200 }).withMessage('Home location must not exceed 200 characters'),

    body('phone_number')
        .optional()
        .matches(/^[0-9\s\-+()]{9,20}$/).withMessage('Phone number must be a valid phone number'),

    body('speciality')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 255 }).withMessage('Speciality must not exceed 255 characters'),

    body('experience')
        .optional()
        .isInt({ min: 0, max: 70 }).withMessage('Experience must be between 0 and 70 years'),

    body('order_num')
        .optional()
        .trim()
        .isLength({ max: 255 }).withMessage('Order number must not exceed 255 characters'),

    body('about')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('About must not exceed 5000 characters'),

    body('languages')
        .optional()
        .isArray().withMessage('Languages must be an array')
];

export const getDoctorValidator = [
    param('user_id')
        .isInt({ min: 1 }).withMessage('Doctor user ID must be a positive integer')
];

// ============================================
// WAITING ROOM VALIDATORS
// ============================================

export const createWaitingRoomValidator = [
    body('patient_id')
        .notEmpty().withMessage('Patient ID is required')
        .isUUID(4).withMessage('Patient ID must be a valid UUID'),

    body('doctor_user_id')
        .optional()
        .isInt({ min: 1 }).withMessage('Doctor user ID must be a positive integer'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters')
];

export const updateWaitingRoomValidator = [
    param('id')
        .isUUID(4).withMessage('Waiting room entry ID must be a valid UUID'),

    body('status')
        .optional()
        .isIn(['waiting', 'called', 'served', 'left']).withMessage('Status must be one of: waiting, called, served, left'),

    body('notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Notes must not exceed 5000 characters')
];

export const getWaitingRoomValidator = [
    param('id')
        .isUUID(4).withMessage('Waiting room entry ID must be a valid UUID')
];

// ============================================
// CALENDAR VALIDATORS
// ============================================

export const createCalendarEventValidator = [
    body('note')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Note must not exceed 5000 characters'),
];

export const updateCalendarEventValidator = [
    body('title')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 1, max: 255 }).withMessage('Title must be between 1 and 255 characters'),

    body('note')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Note must not exceed 5000 characters'),

    body('date')
        .optional()
        .isISO8601().withMessage('Date must be a valid ISO 8601 date'),

    body('time')
        .optional()
        .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9](\.\d{1,6})?)?$/).withMessage('Time must be in valid format (HH:MM or HH:MM:SS)'),

    body('duration')
        .optional()
        .isInt({ min: 5, max: 480 }).withMessage('Duration must be between 5 and 480 minutes'),

    body('color')
        .optional()
        .trim()
        .matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).withMessage('Color must be a valid hex color code'),

    body('appointment_notes')
        .optional()
        .trim()
        .escape()
        .isLength({ max: 5000 }).withMessage('Appointment notes must not exceed 5000 characters'),

    body('is_done')
        .optional()
        .isBoolean().withMessage('is_done must be a boolean'),

    body('confirmed_coming')
        .optional()
        .isBoolean().withMessage('confirmed_coming must be a boolean')
];


// ============================================
// TARIFICATION VALIDATORS
// ============================================

export const createTarificationValidator = [
    body('service_label')
        .notEmpty().withMessage('Service label is required')
        .trim()
        .escape()
        .isLength({ min: 1, max: 255 }).withMessage('Service label must be between 1 and 255 characters'),

    body('price')
        .notEmpty().withMessage('Price is required')
        .isFloat({ min: 0, max: 999999.99 }).withMessage('Price must be a positive number not exceeding 999,999.99')
];

export const updateTarificationValidator = [
    param('id')
        .isInt({ min: 1 }).withMessage('Tarification ID must be a positive integer'),

    body('service_label')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 1, max: 255 }).withMessage('Service label must be between 1 and 255 characters'),

    body('price')
        .optional()
        .isFloat({ min: 0, max: 999999.99 }).withMessage('Price must be a positive number not exceeding 999,999.99')
];

export const getTarificationValidator = [
    param('id')
        .isInt({ min: 1 }).withMessage('Tarification ID must be a positive integer')
];

export const doctorUserIdQueryValidator = [
    query('doctorUserId')
        .notEmpty().withMessage('Doctor user ID is required')
        .isInt({ min: 1 }).withMessage('Doctor user ID must be a positive integer')
];

// ============================================
// QUERY VALIDATORS
// ============================================

export const paginationValidator = [
    query('offset')
        .optional()
        .isInt({ min: 0 }).withMessage('offset must be a positive integer'),
    
    query('limit')
        .optional()
        .isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100')
];

export const searchValidator = [
    query('q')
        .optional()
        .trim()
        .escape()
        .isLength({ min: 1, max: 100 }).withMessage('Search query must be between 1 and 100 characters'),
    
    ...paginationValidator
];

// ============================================
// EXPORTS
// ============================================

export {
    // Legacy export for backward compatibility
    validateRequest as validateInput
};