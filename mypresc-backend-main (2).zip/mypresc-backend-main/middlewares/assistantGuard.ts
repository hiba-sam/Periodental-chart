/**
 * Assistant Guard Middleware - MyPresc
 * 
 * Permet aux assistants de gérer les données administratives
 * tout en protégeant les données médicales
 * 
 * Cas d'usage :
 * - Créer un patient à l'accueil
 * - Modifier les coordonnées du patient
 * - Prendre/confirmer des rendez-vous
 * - MAIS bloquer la modification des données médicales
 */

import type { Request, Response, NextFunction } from 'express';
import { UserRole } from '../types/roles';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CHAMPS AUTORISÉS POUR ASSISTANTS
// ============================================

/**
 * Champs administratifs que les assistants peuvent créer/modifier
 */
const ASSISTANT_ALLOWED_FIELDS = [
    // Informations personnelles
    'firstName',
    'lastName',
    'birthDate',
    'gender',
    
    // Contact
    'email',
    'phone',
    'address',
    'city',
    'postalCode',
    'country',
    
    // Informations administratives
    'insuranceNumber',
    'emergencyContact',
    'emergencyPhone',
    
    // Notes administratives (pas médicales)
    'adminNotes',
    'preferredLanguage',
    'allergiesKnown' // Indication oui/non, pas le détail médical
];

/**
 * Champs médicaux INTERDITS aux assistants
 */
const ASSISTANT_FORBIDDEN_FIELDS = [
    // Données médicales
    'medical_history',
    'medicalHistory',
    'diagnosis',
    'currentMedications',
    'prescriptions',
    'allergies',        // Détail des allergies (médical)
    'bloodType',
    'chronicDiseases',
    'surgicalHistory',
    'familyHistory',
    
    // Notes médicales
    'doctorNotes',
    'clinicalNotes',
    'treatmentPlan',
    
    // Données sensibles
    'medicalRecords',
    'labResults',
    'imagingResults'
];

// ============================================
// MIDDLEWARE PRINCIPAL
// ============================================

/**
 * Vérifie que l'assistant ne modifie que les champs autorisés
 */
export function validateAssistantFields(req: Request, res: Response, next: NextFunction) {
    // Vérifier le rôle
    if (!req.user || req.user.role !== UserRole.ASSISTANT) {
        // Pas un assistant, passer au suivant
        return next();
    }
    
    // Récupérer les champs du body
    const bodyFields = Object.keys(req.body);
    
    // Vérifier s'il y a des champs interdits
    const forbiddenFieldsFound = bodyFields.filter(field => 
        ASSISTANT_FORBIDDEN_FIELDS.includes(field)
    );
    
    if (forbiddenFieldsFound.length > 0) {
        securityLogger.warn('[ASSISTANT] Attempted to modify medical fields', {
            event: 'ACCESS_DENIED',
            reason: 'FORBIDDEN_MEDICAL_FIELDS',
            userId: req.user.id,
            email: req.user.email,
            forbiddenFields: forbiddenFieldsFound,
            method: req.method,
            path: req.path
        });
        
        return res.status(403).json({
            error: 'Access forbidden',
            message: 'Assistants cannot modify medical data',
            forbiddenFields: forbiddenFieldsFound,
            allowedFields: ASSISTANT_ALLOWED_FIELDS,
            hint: 'Only doctors can modify medical information'
        });
    }
    
    // Tous les champs sont autorisés
    securityLogger.info('[ASSISTANT] Admin fields modification allowed', {
        event: 'ASSISTANT_ACCESS_GRANTED',
        userId: req.user.id,
        email: req.user.email,
        fields: bodyFields,
        method: req.method,
        path: req.path
    });
    
    next();
}

// ============================================
// MIDDLEWARE SPÉCIFIQUE : CRÉATION PATIENT
// ============================================

/**
 * Autorise les assistants à créer des patients (accueil)
 * avec uniquement les informations administratives
 */
export function allowAssistantCreatePatient(req: Request, res: Response, next: NextFunction) {
    if (!req.user) {
        return res.status(401).json({ error: 'Authentication required' });
    }
    
    const userRole = req.user.role as UserRole;
    
    // Médecins et admins : accès complet
    if (userRole === UserRole.DOCTOR || userRole === UserRole.ADMIN) {
        return next();
    }
    
    // Assistants : vérifier les champs
    if (userRole === UserRole.ASSISTANT) {
        return validateAssistantFields(req, res, next);
    }
    
    // Autres rôles : refuser
    return res.status(403).json({
        error: 'Access forbidden',
        message: 'Only medical staff can create patients'
    });
}

// ============================================
// MIDDLEWARE SPÉCIFIQUE : MODIFICATION PATIENT
// ============================================

/**
 * Autorise les assistants à modifier les infos admin uniquement
 */
export function allowAssistantUpdatePatient(req: Request, res: Response, next: NextFunction) {
    if (!req.user) {
        return res.status(401).json({ error: 'Authentication required' });
    }
    
    const userRole = req.user.role as UserRole;
    
    // Médecins et admins : accès complet
    if (userRole === UserRole.DOCTOR || userRole === UserRole.ADMIN) {
        return next();
    }
    
    // Assistants : vérifier les champs
    if (userRole === UserRole.ASSISTANT) {
        return validateAssistantFields(req, res, next);
    }
    
    // Autres rôles : refuser
    return res.status(403).json({
        error: 'Access forbidden',
        message: 'You do not have permission to modify patient data'
    });
}

// ============================================
// HELPER : Vérifier si un champ est médical
// ============================================

/**
 * Vérifie si un champ est considéré comme médical
 */
export function isMedicalField(fieldName: string): boolean {
    return ASSISTANT_FORBIDDEN_FIELDS.includes(fieldName);
}

/**
 * Vérifie si un champ est autorisé pour les assistants
 */
export function isAssistantAllowedField(fieldName: string): boolean {
    return ASSISTANT_ALLOWED_FIELDS.includes(fieldName);
}

/**
 * Filtre les champs d'un objet pour ne garder que ceux autorisés aux assistants
 */
export function filterAssistantFields(data: Record<string, any>): Record<string, any> {
    const filtered: Record<string, any> = {};
    
    for (const [key, value] of Object.entries(data)) {
        if (isAssistantAllowedField(key)) {
            filtered[key] = value;
        }
    }
    
    return filtered;
}

// ============================================
// EXPORT PAR DÉFAUT
// ============================================

export default {
    validateAssistantFields,
    allowAssistantCreatePatient,
    allowAssistantUpdatePatient,
    isMedicalField,
    isAssistantAllowedField,
    filterAssistantFields,
    ASSISTANT_ALLOWED_FIELDS,
    ASSISTANT_FORBIDDEN_FIELDS
};
