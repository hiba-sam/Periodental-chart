import type { NextFunction, Request, Response } from "express";
import rateLimit from "express-rate-limit";
import xss from "xss";

// ============================================
// XSS PROTECTION
// ============================================
// Sanitizes all string values in request body to prevent XSS attacks
// This prevents attackers from injecting malicious scripts into our app
function sanitizeBody(req: Request, _res: Response, next: NextFunction) {
    if (req.body) {
        for (const key in req.body) {
            if (typeof req.body[key] === 'string') {
                req.body[key] = xss(req.body[key]);
            }
        }
    }
    next();
};

// ============================================
// RATE LIMITING - GLOBAL
// ============================================
// Protects against brute force attacks, DoS attempts, and abusive requests
// Applied to all routes globally
const globalLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutes window
    max: 1000, // Maximum 100 requests per IP per window
    message: {
        success: false,
        error: 'Too many requests from this IP address. Please try again later.',
        retryAfter: '5 minutes'
    },
    standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
    legacyHeaders: false, // Disable `X-RateLimit-*` headers
    statusCode: 429, // HTTP 429 Too Many Requests
    handler: (req: Request, res: Response) => {
        res.status(429).json({
            success: false,
            error: 'Too many requests from this IP address. Please try again later.',
            retryAfter: '5 minutes',
            limit: 1000,
            windowMs: '5 minutes'
        });
    }
});

// ============================================
// RATE LIMITING - CRITICAL AUTH (Login/Register)
// ============================================
// Strictest rate limiting for login and registration endpoints
// Protects against credential stuffing and brute force attacks
const criticalAuthLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes window
    max: 10000, // TEMPORAIREMENT DÉSACTIVÉ - Remettre à 5 après tests
    message: {
        success: false,
        error: 'Too many authentication attempts. Please try again later.',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    statusCode: 429,
    skipSuccessfulRequests: false, // Count all requests, even successful ones
    handler: (req: Request, res: Response) => {
        res.status(429).json({
            success: false,
            error: 'Too many authentication attempts from this IP. Please try again later.',
            retryAfter: '15 minutes',
            limit: 5,
            windowMs: '15 minutes'
        });
    }
});

// ============================================
// RATE LIMITING - SESSION CHECK
// ============================================
// Moderate rate limiting for session verification endpoint (GET /auth/)
// Allows legitimate frequent navigation while preventing enumeration attacks
// Limit: 200 requests per 15 minutes (increased for development)
const sessionCheckLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes window
    max: 200, // Maximum 200 session checks per IP per window (increased for dev)
    message: {
        success: false,
        error: 'Too many session verification requests. Please try again later.',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    statusCode: 429,
    handler: (req: Request, res: Response) => {
        res.status(429).json({
            success: false,
            error: 'Too many session verification requests from this IP. Please try again later.',
            retryAfter: '15 minutes',
            limit: 200,
            windowMs: '15 minutes'
        });
    }
});

// ============================================
// RATE LIMITING - STANDARD AUTH
// ============================================
// Standard rate limiting for logout and other auth endpoints
const standardAuthLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes window
    max: 10, // Maximum 10 requests per IP per window
    message: {
        success: false,
        error: 'Too many requests. Please try again later.',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
    statusCode: 429,
    handler: (req: Request, res: Response) => {
        res.status(429).json({
            success: false,
            error: 'Too many requests from this IP. Please try again later.',
            retryAfter: '15 minutes',
            limit: 10,
            windowMs: '15 minutes'
        });
    }
});

export { sanitizeBody, globalLimiter, criticalAuthLimiter, sessionCheckLimiter, standardAuthLimiter }