/**
 * CSRF Protection Middleware - MyPresc Backend
 * 
 * Protection contre les attaques Cross-Site Request Forgery (CSRF)
 * Utilise le pattern "Double Submit Cookie" pour la sécurité
 * 
 * Conformité : OWASP A01:2021 (Broken Access Control), RGPD art. 32
 */

import type { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CONFIGURATION
// ============================================

const CSRF_COOKIE_NAME = 'XSRF-TOKEN';
const CSRF_HEADER_NAME = 'X-CSRF-Token';
const CSRF_TOKEN_LENGTH = 32;

// Méthodes HTTP qui nécessitent une protection CSRF
const PROTECTED_METHODS = ['POST', 'PUT', 'DELETE', 'PATCH'];

// Routes exclues de la protection CSRF (login, register)
const EXCLUDED_ROUTES = [
    '/auth/login',
    '/auth/register',
    '/auth/complete-registration'
];

// ============================================
// GÉNÉRATION DE TOKEN CSRF
// ============================================

/**
 * Génère un token CSRF cryptographiquement sécurisé
 */
export function generateCsrfToken(): string {
    return crypto.randomBytes(CSRF_TOKEN_LENGTH).toString('hex');
}

/**
 * Middleware pour générer et attacher un token CSRF à chaque requête
 */
export function attachCsrfToken(req: Request, res: Response, next: NextFunction) {
    // Vérifier si un token existe déjà dans le cookie
    let csrfToken = req.cookies[CSRF_COOKIE_NAME];
    
    // Si pas de token ou token invalide, en générer un nouveau
    if (!csrfToken || typeof csrfToken !== 'string' || csrfToken.length !== CSRF_TOKEN_LENGTH * 2) {
        csrfToken = generateCsrfToken();
        
        // Définir le cookie CSRF
        res.cookie(CSRF_COOKIE_NAME, csrfToken, {
            httpOnly: false, // Doit être accessible en JavaScript côté client
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 24 * 60 * 60 * 1000, // 24 heures
            path: '/'
        });
        
        securityLogger.debug('[CSRF] New CSRF token generated', {
            ip: req.ip || req.socket.remoteAddress,
            path: req.path
        });
    }
    
    // Attacher le token à l'objet request pour usage ultérieur
    req.csrfToken = () => csrfToken;
    
    next();
}

/**
 * Middleware pour valider le token CSRF sur les requêtes protégées
 */
export function verifyCsrfToken(req: Request, res: Response, next: NextFunction) {
    // Ignorer les méthodes GET, HEAD, OPTIONS (safe methods)
    if (!PROTECTED_METHODS.includes(req.method)) {
        return next();
    }
    
    // Ignorer les routes exclues (login, register)
    if (EXCLUDED_ROUTES.some(route => req.path.startsWith(route))) {
        return next();
    }
    
    // Récupérer le token depuis le cookie
    const cookieToken = req.cookies[CSRF_COOKIE_NAME];
    
    // Récupérer le token depuis le header
    const headerToken = req.headers[CSRF_HEADER_NAME.toLowerCase()] as string;
    
    // Vérifier que les deux tokens existent
    if (!cookieToken || !headerToken) {
        securityLogger.warn('[CSRF] CSRF token missing', {
            ip: req.ip || req.socket.remoteAddress,
            method: req.method,
            path: req.path,
            cookiePresent: !!cookieToken,
            headerPresent: !!headerToken,
            event: 'CSRF_TOKEN_MISSING'
        });
        
        return res.status(403).json({
            success: false,
            error: 'CSRF token missing',
            message: 'Missing CSRF protection token. Please refresh the page and try again.'
        });
    }
    
    // Vérifier que les tokens correspondent (double-submit pattern)
    if (cookieToken !== headerToken) {
        securityLogger.warn('[CSRF] CSRF token mismatch', {
            ip: req.ip || req.socket.remoteAddress,
            method: req.method,
            path: req.path,
            event: 'CSRF_TOKEN_MISMATCH'
        });
        
        return res.status(403).json({
            success: false,
            error: 'CSRF token mismatch',
            message: 'Invalid CSRF protection token. Please refresh the page and try again.'
        });
    }
    
    // Token valide, continuer
    next();
}

/**
 * Middleware combiné qui attache ET vérifie le token CSRF
 */
export function csrfProtection(req: Request, res: Response, next: NextFunction) {
    attachCsrfToken(req, res, () => {
        verifyCsrfToken(req, res, next);
    });
}

// ============================================
// HELPERS
// ============================================

/**
 * Nettoie le token CSRF (à utiliser lors du logout)
 */
export function clearCsrfToken(res: Response) {
    res.clearCookie(CSRF_COOKIE_NAME, {
        httpOnly: false,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/'
    });
}

// Augmentation du type Request pour inclure csrfToken
declare global {
    namespace Express {
        interface Request {
            csrfToken?: () => string;
        }
    }
}

export default {
    attachCsrfToken,
    verifyCsrfToken,
    csrfProtection,
    clearCsrfToken,
    generateCsrfToken
};
