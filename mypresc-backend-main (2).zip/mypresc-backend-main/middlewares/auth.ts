import type { NextFunction, Request, Response } from "express";
import { type User } from "../models/user.model";

// ============================================
// AUTHENTICATION MIDDLEWARE
// ============================================

// Simple authentication check - just verifies if user is logged in
const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
	if (req.user) {
		next();
	} else {
		return res.status(401).json({
			success: false,
			error: "Authentication required",
		});
	}
};

const requireDoctorAuth = (req: Request, res: Response, next: NextFunction) => {
	if (req.user && (req.user as User).role === "doctor") {
		next();
	} else {
		return res.status(401).json({
			success: false,
			error:
				"Authentication required, you must be a doctor to access this resource",
		});
	}
};

export { requireAuth, requireDoctorAuth };
