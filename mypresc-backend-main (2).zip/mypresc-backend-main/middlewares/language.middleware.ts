import type { Request, Response, NextFunction } from 'express';
import type { User } from '../models/user.model';

export const languageMiddleware = (req: Request, res: Response, next: NextFunction) => {
    if (req.user) {
        const user = req.user as User;
        if (user.language && req.i18n) {
            req.i18n.changeLanguage(user.language);
            // Set cookie so i18next uses user preference on next requests
            res.cookie('i18next', user.language, { 
                httpOnly: false, 
                maxAge: 365 * 24 * 60 * 60 * 1000, // 1 year
                sameSite: 'lax'
            });
        }
    }
    next();
};
