/**
 * Web Application Firewall (WAF) - MyPresc Backend
 *
 * Protection applicative contre :
 * - SQL Injection
 * - XSS (Cross-Site Scripting)
 * - Path Traversal
 * - User-Agents malveillants
 *
 * Conformité : OWASP A03:2021 (Injection), OWASP A05:2021 (Security Misconfiguration)
 */

import type { Request, Response, NextFunction } from "express";
import { securityLogger } from "../utils/securityLogger";

// ============================================
// CONFIGURATION WAF
// ============================================

// Mode WAF : 'block' (bloque les requêtes) ou 'monitor' (log seulement)
const WAF_MODE = process.env.WAF_MODE || "block";

// User-Agents interdits (CSV depuis .env)
const BLOCKED_UA = process.env.BLOCKED_UA?.split(",").map((ua) =>
	ua.trim().toLowerCase(),
) || ["curl", "sqlmap", "nikto", "nmap", "masscan", "zgrab", "scrapy"];

// Taille maximale d'URL (en caractères)
const MAX_URL_LENGTH = 2048;

// ============================================
// PATTERNS D'ATTAQUE
// ============================================

/**
 * Patterns SQL Injection
 */
const SQL_INJECTION_PATTERNS = [
	/(\bunion\b.*\bselect\b)/i,
	/(\bselect\b.*\bfrom\b.*\bwhere\b)/i,
	/(\bor\b\s+['"]\d+['"]?\s*=\s*['"]\d+['"])/i,
	/(\band\b\s+['"]\d+['"]?\s*=\s*['"]\d+['"])/i,
	/(sleep\s*\(\s*\d+\s*\))/i,
	/(benchmark\s*\()/i,
	/(information_schema)/i,
	/(concat\s*\()/i,
	/(load_file\s*\()/i,
	/(into\s+outfile)/i,
	/(\bdrop\b.*\btable\b)/i,
	/(\bexec\b.*\bxp_)/i,
];

/**
 * Patterns XSS (Cross-Site Scripting)
 */
const XSS_PATTERNS = [
	/<script[\s\S]*?>[\s\S]*?<\/script>/i,
	/<iframe[\s\S]*?>/i,
	/<object[\s\S]*?>/i,
	/<embed[\s\S]*?>/i,
	/on\w+\s*=\s*["'][^"']*["']/i, // onerror=, onload=, etc.
	/javascript\s*:/i,
	/data\s*:\s*text\/html/i,
	/<img[\s\S]*?onerror/i,
	/<svg[\s\S]*?onload/i,
	/eval\s*\(/i,
	/expression\s*\(/i,
];

/**
 * Patterns Path Traversal
 */
const PATH_TRAVERSAL_PATTERNS = [
	/\.\.\//,
	/\.\.\\/,
	/%2e%2e%2f/i,
	/%2e%2e\//i,
	/\.\.%2f/i,
	/%252e%252e%252f/i, // Double encoding
	/\.\./,
	/\/etc\/passwd/i,
	/\/windows\/system32/i,
];

/**
 * Headers suspicieux
 */
const SUSPICIOUS_HEADERS = [
	"X-Override-Method",
	"X-HTTP-Method-Override",
	"X-Method-Override",
];

// ============================================
// FONCTIONS DE DÉTECTION
// ============================================

/**
 * Vérifie si une chaîne contient un pattern SQL Injection
 */
function containsSQLInjection(value: string): boolean {
	return SQL_INJECTION_PATTERNS.some((pattern) => pattern.test(value));
}

/**
 * Vérifie si une chaîne contient un pattern XSS
 */
function containsXSS(value: string): boolean {
	return XSS_PATTERNS.some((pattern) => pattern.test(value));
}

/**
 * Vérifie si une chaîne contient un pattern Path Traversal
 */
function containsPathTraversal(value: string): boolean {
	return PATH_TRAVERSAL_PATTERNS.some((pattern) => pattern.test(value));
}

/**
 * Scanner récursif pour objets/tableaux
 */
function scanValue(value: any, scanFn: (val: string) => boolean): boolean {
	if (typeof value === "string") {
		return scanFn(value);
	}

	if (Array.isArray(value)) {
		return value.some((item) => scanValue(item, scanFn));
	}

	if (typeof value === "object" && value !== null) {
		return Object.values(value).some((val) => scanValue(val, scanFn));
	}

	return false;
}

// ============================================
// MIDDLEWARE WAF
// ============================================

/**
 * Middleware principal WAF
 */
export function waf(req: Request, res: Response, next: NextFunction) {
	const ip = req.ip || req.socket.remoteAddress;
	const userAgent = req.headers["user-agent"] || "";
	const path = req.path;
	const method = req.method;

	// 1. Vérifier la taille de l'URL
	const fullUrl = req.originalUrl || req.url;
	if (fullUrl.length > MAX_URL_LENGTH) {
		logAndBlock(
			req,
			res,
			"URL_TOO_LONG",
			`URL length: ${fullUrl.length} > ${MAX_URL_LENGTH}`,
		);
		return;
	}

	// 2. Vérifier les headers suspicieux
	for (const header of SUSPICIOUS_HEADERS) {
		if (req.headers[header.toLowerCase()]) {
			logAndBlock(req, res, "SUSPICIOUS_HEADER", `Header: ${header}`);
			return;
		}
	}

	// 3. Vérifier User-Agent interdit
	const userAgentLower = userAgent.toLowerCase();
	for (const blockedUA of BLOCKED_UA) {
		if (userAgentLower.includes(blockedUA)) {
			logAndBlock(req, res, "BLOCKED_USER_AGENT", `User-Agent: ${userAgent}`);
			return;
		}
	}

	// 4. Scanner les query parameters
	const queryString = JSON.stringify(req.query);
	if (containsSQLInjection(queryString)) {
		logAndBlock(
			req,
			res,
			"SQL_INJECTION_QUERY",
			`Query: ${queryString.substring(0, 100)}`,
		);
		return;
	}
	if (containsXSS(queryString)) {
		logAndBlock(
			req,
			res,
			"XSS_QUERY",
			`Query: ${queryString.substring(0, 100)}`,
		);
		return;
	}
	if (containsPathTraversal(fullUrl)) {
		logAndBlock(
			req,
			res,
			"PATH_TRAVERSAL_URL",
			`URL: ${fullUrl.substring(0, 100)}`,
		);
		return;
	}

	// 5. Scanner le body (POST/PUT/PATCH)
	if (["POST", "PUT", "PATCH"].includes(method) && req.body) {
		const bodyString = JSON.stringify(req.body);

		if (containsSQLInjection(bodyString)) {
			logAndBlock(
				req,
				res,
				"SQL_INJECTION_BODY",
				`Body: ${bodyString.substring(0, 100)}`,
			);
			return;
		}

		if (containsXSS(bodyString)) {
			logAndBlock(
				req,
				res,
				"XSS_BODY",
				`Body: ${bodyString.substring(0, 100)}`,
			);
			return;
		}

		if (containsPathTraversal(bodyString)) {
			logAndBlock(
				req,
				res,
				"PATH_TRAVERSAL_BODY",
				`Body: ${bodyString.substring(0, 100)}`,
			);
			return;
		}
	}

	// 6. Scanner les headers
	const headersString = JSON.stringify(req.headers);
	if (containsSQLInjection(headersString) || containsXSS(headersString)) {
		logAndBlock(
			req,
			res,
			"MALICIOUS_HEADERS",
			`Headers contain attack patterns`,
		);
		return;
	}

	// Tout est OK, continuer
	next();
}

/**
 * Logger et bloquer (ou juste logger en mode monitor)
 */
function logAndBlock(
	req: Request,
	res: Response,
	rule: string,
	sample: string,
) {
	const ip = req.ip || req.socket.remoteAddress;
	const userAgent = req.headers["user-agent"] || "Unknown";
	const path = req.path;
	const method = req.method;

	// Logger l'événement
	securityLogger.warn("[WAF] Attack pattern detected", {
		ip,
		method,
		path,
		rule,
		sample: sample.substring(0, 200),
		userAgent: userAgent.substring(0, 100),
		mode: WAF_MODE,
		event: "WAF_BLOCK",
	});

	// En mode 'block', rejeter la requête
	if (WAF_MODE === "block") {
		return res.status(406).json({
			success: false,
			error: "Request blocked by WAF",
			code: "WAF_BLOCKED",
			message:
				"Your request contains potentially malicious patterns and has been blocked.",
		});
	}

	// En mode 'monitor', juste logger et continuer
	// (next() sera appelé par le middleware parent)
}

export default waf;
