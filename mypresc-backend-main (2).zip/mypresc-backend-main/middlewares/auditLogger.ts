/**
 * Audit Logger Middleware - MyPresc
 * 
 * Journalisation sécurisée de tous les accès aux données sensibles
 * Conformité : RGPD Art.30, ANPDP Art.25, OWASP A09:2021
 */

import type { Request, Response, NextFunction } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import { UserRole, AuditAction, TargetType } from '../types/roles';
import { encryptJSON } from '../utils/dataEncryption';

// ============================================
// CONFIGURATION
// ============================================

const AUDIT_LOG_PATH = 'logs/audit-access.log';
const AUDIT_LOG_ENCRYPTED_PATH = 'logs/audit-access-encrypted.log';
const LOG_RETENTION_DAYS = parseInt(process.env.LOG_RETENTION_DAYS || '90', 10);
const ENCRYPT_AUDIT_LOGS = process.env.ENCRYPT_AUDIT_LOGS === 'true';

// ============================================
// TYPES
// ============================================

interface AuditLogEntry {
    event: string;
    userId: number | string;
    email: string;
    role: UserRole;
    method: string;
    endpoint: string;
    action: AuditAction;
    targetType: TargetType;
    targetId?: string | number;
    ip: string;
    userAgent?: string;
    timestamp: string;
    duration?: number;
    statusCode?: number;
}

// ============================================
// HELPERS
// ============================================

/**
 * Détermine le type de ressource cible à partir du path
 */
function getTargetTypeFromPath(path: string): TargetType {
    if (path.includes('/patient')) return TargetType.PATIENT_RECORD;
    if (path.includes('/prescription')) return TargetType.PRESCRIPTION;
    if (path.includes('/appointment')) return TargetType.APPOINTMENT;
    if (path.includes('/user')) return TargetType.USER;
    if (path.includes('/auth')) return TargetType.AUTH;
    return TargetType.PATIENT_RECORD; // Default
}

/**
 * Détermine l'action à partir de la méthode HTTP
 */
function getActionFromMethod(method: string): AuditAction {
    switch (method.toUpperCase()) {
        case 'GET':
            return AuditAction.READ;
        case 'POST':
            return AuditAction.CREATE;
        case 'PUT':
        case 'PATCH':
            return AuditAction.UPDATE;
        case 'DELETE':
            return AuditAction.DELETE;
        default:
            return AuditAction.READ;
    }
}

/**
 * Extrait l'ID de la ressource cible depuis params ou body
 */
function getTargetId(req: Request): string | number | undefined {
    return req.params.id || 
           req.params.patientId || 
           req.params.prescriptionId || 
           req.params.appointmentId ||
           req.body.id ||
           req.body.patientId;
}

/**
 * Écrit une entrée d'audit dans le fichier log
 */
function writeAuditLog(entry: AuditLogEntry): void {
    try {
        // Créer le répertoire si nécessaire
        const logDir = path.dirname(AUDIT_LOG_PATH);
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir, { recursive: true });
        }
        
        const logLine = JSON.stringify(entry) + '\n';
        
        // Écrire en clair (pour debug/développement)
        fs.appendFileSync(AUDIT_LOG_PATH, logLine, 'utf-8');
        
        // Écrire version chiffrée (production)
        if (ENCRYPT_AUDIT_LOGS) {
            try {
                const encrypted = encryptJSON(entry);
                const encryptedLine = JSON.stringify(encrypted) + '\n';
                fs.appendFileSync(AUDIT_LOG_ENCRYPTED_PATH, encryptedLine, 'utf-8');
            } catch (error) {
                console.error('[AUDIT] Failed to encrypt audit log:', error);
            }
        }
    } catch (error) {
        console.error('[AUDIT] Failed to write audit log:', error);
    }
}

// ============================================
// MIDDLEWARE PRINCIPAL
// ============================================

/**
 * Middleware d'audit pour journaliser les accès
 */
export function auditLogger(req: Request, res: Response, next: NextFunction) {
    // Capturer le timestamp de début
    const startTime = Date.now();
    
    // Vérifier que l'utilisateur est authentifié
    if (!req.user) {
        return next();
    }
    
    // Capturer la réponse pour obtenir le status code
    const originalSend = res.send;
    let statusCode = 200;
    
    res.send = function(data: any): Response {
        statusCode = res.statusCode;
        return originalSend.call(this, data);
    };
    
    // Après la réponse, logger l'accès
    res.on('finish', () => {
        const duration = Date.now() - startTime;
        
        const auditEntry: AuditLogEntry = {
            event: 'ACCESS_LOG',
            userId: req.user!.id,
            email: req.user!.email,
            role: req.user!.role as UserRole,
            method: req.method,
            endpoint: req.path,
            action: getActionFromMethod(req.method),
            targetType: getTargetTypeFromPath(req.path),
            targetId: getTargetId(req),
            ip: req.ip || req.socket.remoteAddress || 'unknown',
            userAgent: req.headers['user-agent'],
            timestamp: new Date().toISOString(),
            duration,
            statusCode
        };
        
        writeAuditLog(auditEntry);
    });
    
    next();
}

// ============================================
// MIDDLEWARE SPÉCIFIQUE : ACCESS DENIED
// ============================================

/**
 * Journalise une tentative d'accès refusée
 */
export function logAccessDenied(
    req: Request,
    reason: string,
    targetType?: TargetType,
    targetId?: string | number
): void {
    const auditEntry: AuditLogEntry = {
        event: 'ACCESS_DENIED',
        userId: req.user ? req.user.id : 'anonymous',
        email: req.user ? req.user.email : 'anonymous',
        role: req.user ? (req.user.role as UserRole) : UserRole.PATIENT,
        method: req.method,
        endpoint: req.path,
        action: AuditAction.ACCESS_DENIED,
        targetType: targetType || getTargetTypeFromPath(req.path),
        targetId: targetId || getTargetId(req),
        ip: req.ip || req.socket.remoteAddress || 'unknown',
        userAgent: req.headers['user-agent'],
        timestamp: new Date().toISOString()
    };
    
    writeAuditLog(auditEntry);
}

// ============================================
// MAINTENANCE : NETTOYAGE DES LOGS
// ============================================

/**
 * Supprime les logs d'audit plus anciens que LOG_RETENTION_DAYS
 */
export function cleanupOldAuditLogs(): void {
    try {
        if (!fs.existsSync(AUDIT_LOG_PATH)) {
            return;
        }
        
        const content = fs.readFileSync(AUDIT_LOG_PATH, 'utf-8');
        const lines = content.split('\n').filter(l => l.trim());
        
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - LOG_RETENTION_DAYS);
        
        const filteredLines = lines.filter(line => {
            try {
                const entry = JSON.parse(line);
                const entryDate = new Date(entry.timestamp);
                return entryDate > cutoffDate;
            } catch {
                return false;
            }
        });
        
        // Réécrire le fichier avec seulement les logs récents
        fs.writeFileSync(AUDIT_LOG_PATH, filteredLines.join('\n') + '\n', 'utf-8');
        
        console.log(`[AUDIT] Cleaned up old logs. Kept ${filteredLines.length}/${lines.length} entries`);
        
        // Nettoyer aussi les logs chiffrés
        if (ENCRYPT_AUDIT_LOGS && fs.existsSync(AUDIT_LOG_ENCRYPTED_PATH)) {
            const encryptedContent = fs.readFileSync(AUDIT_LOG_ENCRYPTED_PATH, 'utf-8');
            const encryptedLines = encryptedContent.split('\n').filter(l => l.trim());
            
            // Garder le même nombre de lignes que les logs en clair
            const keptEncrypted = encryptedLines.slice(-filteredLines.length);
            fs.writeFileSync(AUDIT_LOG_ENCRYPTED_PATH, keptEncrypted.join('\n') + '\n', 'utf-8');
        }
        
    } catch (error) {
        console.error('[AUDIT] Failed to cleanup old logs:', error);
    }
}

// ============================================
// ANALYTICS
// ============================================

/**
 * Retourne des statistiques d'audit
 */
export function getAuditStats(): {
    totalAccesses: number;
    accessesByRole: Record<string, number>;
    accessesByAction: Record<string, number>;
    deniedAccesses: number;
} {
    try {
        if (!fs.existsSync(AUDIT_LOG_PATH)) {
            return {
                totalAccesses: 0,
                accessesByRole: {},
                accessesByAction: {},
                deniedAccesses: 0
            };
        }
        
        const content = fs.readFileSync(AUDIT_LOG_PATH, 'utf-8');
        const lines = content.split('\n').filter(l => l.trim());
        
        const stats = {
            totalAccesses: 0,
            accessesByRole: {} as Record<string, number>,
            accessesByAction: {} as Record<string, number>,
            deniedAccesses: 0
        };
        
        for (const line of lines) {
            try {
                const entry = JSON.parse(line);
                stats.totalAccesses++;
                
                // Par rôle
                stats.accessesByRole[entry.role] = (stats.accessesByRole[entry.role] || 0) + 1;
                
                // Par action
                stats.accessesByAction[entry.action] = (stats.accessesByAction[entry.action] || 0) + 1;
                
                // Accès refusés
                if (entry.event === 'ACCESS_DENIED') {
                    stats.deniedAccesses++;
                }
            } catch {
                // Ignorer les lignes malformées
            }
        }
        
        return stats;
    } catch (error) {
        console.error('[AUDIT] Failed to get stats:', error);
        return {
            totalAccesses: 0,
            accessesByRole: {},
            accessesByAction: {},
            deniedAccesses: 0
        };
    }
}

// ============================================
// EXPORT PAR DÉFAUT
// ============================================

export default {
    auditLogger,
    logAccessDenied,
    cleanupOldAuditLogs,
    getAuditStats
};
