import jwt from 'jsonwebtoken';
import { Socket } from 'socket.io';
import { securityLogger } from '../utils/securityLogger';

interface JWTPayload {
  id: number;
  email: string;
  role: string;
  iat: number;
  exp: number;
}

// Extend Socket interface to include user data
declare module 'socket.io' {
  interface Socket {
    user?: {
      id: number;
      email: string;
      role: string;
      name?: string;
      family_name?: string;
    };
  }
}

/**
 * Socket.io authentication middleware
 * Validates JWT token from handshake.auth.token
 */
export const socketAuthMiddleware = async (
  socket: Socket,
  next: (err?: Error) => void
) => {
  try {
    // Get token from auth OR cookies (session-based)
    let token = socket.handshake.auth.token;
    
    // If no token in auth, try to get user from session (Passport.js)
    if (!token) {
      // Check if user is authenticated via session (cookies)
      const req = socket.request as any;
      
      // Try to get user from req.user (if Passport middleware already ran)
      if (req.user) {
        socket.user = {
          id: req.user.id,
          email: req.user.email,
          role: req.user.role,
          name: req.user.name,
          family_name: req.user.family_name,
        };
        
        // Verify user is a doctor or assistant
        if (socket.user.role !== 'doctor' && socket.user.role !== 'assistant') {
          securityLogger.warn('[Socket.io] Unauthorized user attempted connection', {
            userId: socket.user.id,
            role: socket.user.role,
            socketId: socket.id,
          });
          return next(new Error('Only doctors and assistants can access messaging'));
        }

        return next();
      }
      
      // Try to manually deserialize from session
      console.log('[Socket Auth] Session data:', JSON.stringify({
        sessionID: req.sessionID,
        hasSession: !!req.session,
        sessionKeys: req.session ? Object.keys(req.session) : [],
        passport: req.session?.passport,
      }));
      
      const userId = req.session?.passport?.user;
      if (userId) {
        try {
          // Manually load user from database
          const { UserModel } = await import('../models/user.model');
          const user = await UserModel.findById(userId);
          
          if (user) {
            socket.user = {
              id: user.id,
              email: user.email,
              role: user.role,
              name: user.name,
              family_name: user.family_name,
            };
            
            // Verify user is a doctor or assistant
            if (socket.user.role !== 'doctor' && socket.user.role !== 'assistant') {
              securityLogger.warn('[Socket.io] Unauthorized user attempted connection', {
                userId: socket.user.id,
                role: socket.user.role,
                socketId: socket.id,
              });
              return next(new Error('Only doctors and assistants can access messaging'));
            }

            return next();
          }
        } catch (error: any) {
          securityLogger.error('[Socket.io] Failed to deserialize user', {
            userId,
            error: error.message,
          });
        }
      }
      
      // No token and no session
      securityLogger.warn('[Socket.io] Connection attempt without authentication', {
        socketId: socket.id,
        ip: socket.handshake.address,
        hasSession: !!req.session,
        hasPassport: !!req.session?.passport,
        userId: req.session?.passport?.user || 'none',
      });
      return next(new Error('Authentication required'));
    }

    // Verify JWT token (fallback for token-based auth)
    const JWT_SECRET = process.env.JWT_SECRET;
    if (!JWT_SECRET) {
      securityLogger.error('[Socket.io] JWT_SECRET not configured');
      return next(new Error('Server configuration error'));
    }

    const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;

    // Verify user is a doctor or assistant
    if (decoded.role !== 'doctor' && decoded.role !== 'assistant') {
      securityLogger.warn('[Socket.io] Unauthorized user attempted connection', {
        userId: decoded.id,
        role: decoded.role,
        socketId: socket.id,
      });
      return next(new Error('Only doctors and assistants can access messaging'));
    }

    // Load user from database to get name and family_name
    try {
      const { UserModel } = await import('../models/user.model');
      const user = await UserModel.findById(decoded.id);

      if (user) {
        socket.user = {
          id: user.id,
          email: user.email,
          role: user.role,
          name: user.name,
          family_name: user.family_name,
        };
      } else {
        // Fallback if user not found in DB
        socket.user = {
          id: decoded.id,
          email: decoded.email,
          role: decoded.role,
        };
      }
    } catch (dbError) {
      // Fallback to JWT data if DB error
      socket.user = {
        id: decoded.id,
        email: decoded.email,
        role: decoded.role,
      };
    }

    next();
  } catch (error: any) {
    if (error.name === 'JsonWebTokenError') {
      securityLogger.warn('[Socket.io] Invalid JWT token', {
        socketId: socket.id,
        error: error.message,
      });
      return next(new Error('Invalid token'));
    }

    if (error.name === 'TokenExpiredError') {
      securityLogger.warn('[Socket.io] Expired JWT token', {
        socketId: socket.id,
      });
      return next(new Error('Token expired'));
    }

    securityLogger.error('[Socket.io] Authentication error', {
      socketId: socket.id,
      error: error.message,
    });

    return next(new Error('Authentication failed'));
  }
};

/**
 * Rate limiter for socket events (in-memory token bucket)
 */
class SocketRateLimiter {
  private buckets: Map<number, { tokens: number; lastRefill: number }> = new Map();
  private maxTokens: number;
  private refillRate: number; // tokens per second

  constructor(maxTokens: number = 10, refillRate: number = 1) {
    this.maxTokens = maxTokens;
    this.refillRate = refillRate;
  }

  canConsume(userId: number): boolean {
    const now = Date.now();
    let bucket = this.buckets.get(userId);

    if (!bucket) {
      bucket = { tokens: this.maxTokens - 1, lastRefill: now };
      this.buckets.set(userId, bucket);
      return true;
    }

    // Refill tokens based on time elapsed
    const timeElapsed = (now - bucket.lastRefill) / 1000;
    const tokensToAdd = timeElapsed * this.refillRate;
    bucket.tokens = Math.min(this.maxTokens, bucket.tokens + tokensToAdd);
    bucket.lastRefill = now;

    if (bucket.tokens >= 1) {
      bucket.tokens -= 1;
      return true;
    }

    return false;
  }

  cleanup() {
    // Remove stale buckets (older than 1 hour)
    const oneHourAgo = Date.now() - 3600000;
    for (const [userId, bucket] of this.buckets.entries()) {
      if (bucket.lastRefill < oneHourAgo) {
        this.buckets.delete(userId);
      }
    }
  }
}

// Global rate limiter instance
export const messagingRateLimiter = new SocketRateLimiter(10, 2); // 10 tokens, refill 2/sec

// Cleanup stale buckets every 10 minutes
setInterval(() => {
  messagingRateLimiter.cleanup();
}, 600000);
