-- Migration: Add 'free' status to consultation_invoices
-- This allows creating invoices with 0 DA that are marked as free/gratuit

-- Update the status CHECK constraint to include 'free'
ALTER TABLE consultation_invoices DROP CONSTRAINT IF EXISTS consultation_invoices_status_check;
ALTER TABLE consultation_invoices ADD CONSTRAINT consultation_invoices_status_check 
    CHECK (status IN ('paid', 'unpaid', 'partial', 'free'));

-- Comment
COMMENT ON COLUMN consultation_invoices.status IS 'Payment status: paid, unpaid, partial, or free (for 0 DA invoices)';
