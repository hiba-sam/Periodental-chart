-- Migration: Make telephone and age columns nullable
-- Created: 2026-01-23
-- Description: Allow patients to be created without telephone or age (if dateNaissance is provided)

-- Make telephone column nullable
ALTER TABLE patients ALTER COLUMN telephone DROP NOT NULL;

-- Make age column nullable
ALTER TABLE patients ALTER COLUMN age DROP NOT NULL;

-- Update comments
COMMENT ON COLUMN patients.telephone IS 'Encrypted patient phone number (BYTEA) - optional';
COMMENT ON COLUMN patients.age IS 'Encrypted patient age (BYTEA) - optional if date_naissance is provided';
