-- Migration: Create patients table
-- Created: 2024-01-01 00:00:00

-- Enable pgcrypto extension for encryption
CREATE EXTENSION IF NOT EXISTS pgcrypto;
-- Enable pg_trgm extension for trigram search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- ALL PATIENT DATA IS ENCRYPTED (BYTEA)
    -- Personal information
    name BYTEA NOT NULL, -- Encrypted last name
    family_name BYTEA NOT NULL, -- Encrypted first name
    age BYTEA NOT NULL, -- Encrypted age
    genre BYTEA NOT NULL, -- Encrypted gender
    telephone BYTEA NOT NULL, -- Encrypted phone number
    email BYTEA, -- Encrypted email
    adresse BYTEA, -- Encrypted address
    date_naissance BYTEA, -- Encrypted birth date
    numero_securite_sociale BYTEA, -- Encrypted social security number
    nin BYTEA NOT NULL, -- Encrypted national identity number
    emergencyContact BYTEA, -- Encrypted emergency contact
    emergencyPhone BYTEA, -- Encrypted emergency phone

    -- Medical data
    allergies BYTEA, -- Encrypted allergies
    chronicDiseases BYTEA, -- Encrypted chronic diseases
    notes BYTEA, -- Encrypted notes

    -- Blind indexes for searchable encrypted fields (SHA256 hashes)
    name_blind_index TEXT, -- Blind index for searchable name
    family_name_blind_index TEXT, -- Blind index for searchable family name
    full_name_blind_index TEXT, -- Blind index for combined "name family_name" search
    nin_blind_index TEXT NOT NULL, -- Blind index for searchable NIN

    -- Metadata (non-encrypted)
    consultations INTEGER DEFAULT 0, -- Consultation count
    medecin_traitant_id INTEGER REFERENCES users(id), -- Reference to assigned doctor
    is_private BOOLEAN DEFAULT false, -- Privacy flag

    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
-- Indexes on metadata
CREATE INDEX IF NOT EXISTS idx_patients_medecin_traitant_id ON patients(medecin_traitant_id);
CREATE INDEX IF NOT EXISTS idx_patients_consultations ON patients(consultations);
CREATE INDEX IF NOT EXISTS idx_patients_created_at ON patients(created_at);
CREATE INDEX IF NOT EXISTS idx_patients_is_private ON patients(is_private);

-- Blind index indexes for searchable encrypted fields (CRITICAL FOR SEARCH PERFORMANCE)
CREATE INDEX IF NOT EXISTS idx_patients_name_blind_index ON patients(name_blind_index);
CREATE INDEX IF NOT EXISTS idx_patients_family_name_blind_index ON patients(family_name_blind_index);
CREATE INDEX IF NOT EXISTS idx_patients_full_name_blind_index ON patients(full_name_blind_index);
CREATE INDEX IF NOT EXISTS idx_patients_nin_blind_index ON patients(nin_blind_index);


-- Create trigger to automatically update updated_at
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'update_patients_updated_at'
    ) THEN
CREATE TRIGGER update_patients_updated_at 
    BEFORE UPDATE ON patients 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();
    END IF;
END
$$;

-- Add comments for documentation
COMMENT ON TABLE patients IS 'Patient information and medical records table - ALL patient data fully encrypted';
COMMENT ON COLUMN patients.id IS 'Primary key (UUID)';
COMMENT ON COLUMN patients.name IS 'Encrypted patient last name (BYTEA)';
COMMENT ON COLUMN patients.family_name IS 'Encrypted patient first name (BYTEA)';
COMMENT ON COLUMN patients.age IS 'Encrypted patient age (BYTEA)';
COMMENT ON COLUMN patients.genre IS 'Encrypted patient gender (BYTEA)';
COMMENT ON COLUMN patients.telephone IS 'Encrypted patient phone number (BYTEA)';
COMMENT ON COLUMN patients.email IS 'Encrypted patient email address (BYTEA)';
COMMENT ON COLUMN patients.adresse IS 'Encrypted patient address (BYTEA)';
COMMENT ON COLUMN patients.date_naissance IS 'Encrypted patient birth date (BYTEA)';
COMMENT ON COLUMN patients.numero_securite_sociale IS 'Encrypted social security number (BYTEA)';
COMMENT ON COLUMN patients.nin IS 'Encrypted national identity number (BYTEA)';
COMMENT ON COLUMN patients.emergencyContact IS 'Encrypted emergency contact name (BYTEA)';
COMMENT ON COLUMN patients.emergencyPhone IS 'Encrypted emergency contact phone (BYTEA)';
COMMENT ON COLUMN patients.allergies IS 'Encrypted patient allergies (BYTEA)';
COMMENT ON COLUMN patients.chronicDiseases IS 'Encrypted chronic diseases (BYTEA)';
COMMENT ON COLUMN patients.notes IS 'Encrypted additional notes about the patient (BYTEA)';
COMMENT ON COLUMN patients.name_blind_index IS 'Blind index (SHA256 hash) for searchable encrypted name';
COMMENT ON COLUMN patients.family_name_blind_index IS 'Blind index (SHA256 hash) for searchable encrypted family name';
COMMENT ON COLUMN patients.full_name_blind_index IS 'Blind index (SHA256 hash) for combined "name family_name" search';
COMMENT ON COLUMN patients.nin_blind_index IS 'Blind index (SHA256 hash) for searchable encrypted NIN';
COMMENT ON COLUMN patients.consultations IS 'Number of consultations (non-encrypted metadata)';
COMMENT ON COLUMN patients.medecin_traitant_id IS 'Primary care physician - references users(id)';
COMMENT ON COLUMN patients.is_private IS 'Privacy flag - when true, only assigned doctor can see sensitive data';
COMMENT ON COLUMN patients.created_at IS 'Patient record creation timestamp';
COMMENT ON COLUMN patients.updated_at IS 'Last update timestamp';
