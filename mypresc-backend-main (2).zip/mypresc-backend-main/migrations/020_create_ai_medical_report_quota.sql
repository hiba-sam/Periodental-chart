-- Migration: 020_create_ai_medical_report_quota
-- Description: Créer les tables pour la gestion des quotas de génération de comptes rendus IA
-- Date: 2024-12-14

-- ==============================================
-- TABLE: ai_medical_report_quota
-- ==============================================
CREATE TABLE IF NOT EXISTS ai_medical_report_quota (
    id SERIAL PRIMARY KEY,
    doctor_user_id INTEGER NOT NULL,
    period VARCHAR(7) NOT NULL, -- Format: YYYY-MM
    used_count INTEGER NOT NULL DEFAULT 0,
    max_quota INTEGER NOT NULL DEFAULT 30,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Contraintes
    CONSTRAINT fk_doctor_user 
        FOREIGN KEY (doctor_user_id) 
        REFERENCES users(id) 
        ON DELETE CASCADE,
    
    CONSTRAINT check_used_count_positive 
        CHECK (used_count >= 0),
    
    CONSTRAINT check_used_count_max 
        CHECK (used_count <= max_quota),
    
    -- Un seul enregistrement par médecin par période
    CONSTRAINT unique_doctor_period 
        UNIQUE (doctor_user_id, period)
);

-- Index pour performance
CREATE INDEX IF NOT EXISTS idx_quota_doctor_period 
    ON ai_medical_report_quota(doctor_user_id, period);

CREATE INDEX IF NOT EXISTS idx_quota_period 
    ON ai_medical_report_quota(period);

-- Trigger pour updated_at
CREATE OR REPLACE FUNCTION update_ai_quota_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_ai_quota_timestamp ON ai_medical_report_quota;

CREATE TRIGGER trigger_update_ai_quota_timestamp
    BEFORE UPDATE ON ai_medical_report_quota
    FOR EACH ROW
    EXECUTE FUNCTION update_ai_quota_timestamp();

-- ==============================================
-- TABLE: ai_medical_report_logs
-- ==============================================
-- Table de logs sécurisés (pas de contenu médical)
CREATE TABLE IF NOT EXISTS ai_medical_report_logs (
    id SERIAL PRIMARY KEY,
    request_id UUID NOT NULL UNIQUE,
    doctor_user_id_hash VARCHAR(64) NOT NULL, -- Hash SHA256 pour anonymisation
    period VARCHAR(7) NOT NULL,
    audio_duration_seconds DECIMAL(5,2),
    audio_size_bytes INTEGER,
    transcription_duration_ms INTEGER,
    generation_duration_ms INTEGER,
    total_duration_ms INTEGER,
    status VARCHAR(20) NOT NULL, -- success, quota_exceeded, error, invalid_format, timeout
    error_code VARCHAR(50), -- optional
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Contrainte sur le statut
    CONSTRAINT check_status 
        CHECK (status IN ('success', 'quota_exceeded', 'error', 'invalid_format', 'timeout'))
);

-- Index pour analytics
CREATE INDEX IF NOT EXISTS idx_logs_doctor_hash_period 
    ON ai_medical_report_logs(doctor_user_id_hash, period);

CREATE INDEX IF NOT EXISTS idx_logs_status 
    ON ai_medical_report_logs(status);

CREATE INDEX IF NOT EXISTS idx_logs_created_at 
    ON ai_medical_report_logs(created_at);

CREATE INDEX IF NOT EXISTS idx_logs_request_id 
    ON ai_medical_report_logs(request_id);

-- ==============================================
-- VUES ANALYTICS (sans données sensibles)
-- ==============================================
CREATE OR REPLACE VIEW v_quota_usage_stats AS
SELECT 
    period,
    COUNT(DISTINCT doctor_user_id) as active_doctors,
    SUM(used_count) as total_reports_generated,
    ROUND(AVG(used_count), 2) as avg_reports_per_doctor,
    MAX(used_count) as max_reports_per_doctor
FROM ai_medical_report_quota
GROUP BY period
ORDER BY period DESC;

CREATE OR REPLACE VIEW v_ai_performance_stats AS
SELECT 
    period,
    status,
    COUNT(*) as request_count,
    ROUND(AVG(transcription_duration_ms), 2) as avg_transcription_ms,
    ROUND(AVG(generation_duration_ms), 2) as avg_generation_ms,
    ROUND(AVG(total_duration_ms), 2) as avg_total_ms,
    ROUND(AVG(audio_duration_seconds), 2) as avg_audio_duration_sec
FROM ai_medical_report_logs
GROUP BY period, status
ORDER BY period DESC, status;

-- ==============================================
-- COMMENTAIRES
-- ==============================================
COMMENT ON TABLE ai_medical_report_quota IS 
'Gestion des quotas mensuels de génération de comptes rendus médicaux par IA';

COMMENT ON COLUMN ai_medical_report_quota.period IS 
'Période au format YYYY-MM pour le suivi mensuel';

COMMENT ON COLUMN ai_medical_report_quota.used_count IS 
'Nombre de comptes rendus générés dans la période';

COMMENT ON TABLE ai_medical_report_logs IS 
'Logs sécurisés des requêtes de génération (sans contenu médical)';

COMMENT ON COLUMN ai_medical_report_logs.doctor_user_id_hash IS 
'Hash SHA256 du doctor_user_id pour anonymisation dans les logs';

-- ==============================================
-- DONNÉES DE TEST (optionnel, à supprimer en prod)
-- ==============================================
-- Décommenter pour tester en dev:
-- INSERT INTO ai_medical_report_quota (doctor_user_id, period, used_count, max_quota)
-- VALUES (1, '2024-12', 5, 20)
-- ON CONFLICT (doctor_user_id, period) DO NOTHING;
