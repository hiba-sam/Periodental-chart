-- ============================================
-- Test Script: Messaging Tables Constraints
-- Created: 2025-10-22
-- Purpose: Validate migration 014 constraints
-- ============================================

-- Run this after applying migration 014 to verify constraints

-- ============================================
-- 1. TEST DIRECT CONVERSATION UNIQUENESS
-- ============================================

DO $$
DECLARE
    v_user1 INT;
    v_user2 INT;
    v_conv1 INT;
    v_conv2 INT;
BEGIN
    RAISE NOTICE '=== TEST 1: Direct Conversation Uniqueness ===';
    
    -- Get two test users (assuming users exist)
    SELECT id INTO v_user1 FROM users WHERE role = 'doctor' LIMIT 1;
    SELECT id INTO v_user2 FROM users WHERE role = 'doctor' OFFSET 1 LIMIT 1;
    
    IF v_user1 IS NULL OR v_user2 IS NULL THEN
        RAISE NOTICE 'Skipping test: Need at least 2 doctor users';
        RETURN;
    END IF;
    
    RAISE NOTICE 'User 1: %', v_user1;
    RAISE NOTICE 'User 2: %', v_user2;
    
    -- Create first conversation
    v_conv1 := create_direct_conversation(v_user1, v_user2);
    RAISE NOTICE '✓ Created conversation: %', v_conv1;
    
    -- Try to create duplicate (should fail)
    BEGIN
        v_conv2 := create_direct_conversation(v_user2, v_user1);
        RAISE EXCEPTION '✗ FAILED: Duplicate conversation was created!';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLERRM LIKE '%already exists%' THEN
                RAISE NOTICE '✓ PASSED: Duplicate conversation blocked';
            ELSE
                RAISE;
            END IF;
    END;
    
    -- Verify get_direct_conversation returns same ID
    v_conv2 := get_direct_conversation(v_user2, v_user1);
    IF v_conv2 = v_conv1 THEN
        RAISE NOTICE '✓ PASSED: get_direct_conversation finds existing conversation';
    ELSE
        RAISE EXCEPTION '✗ FAILED: get_direct_conversation returned wrong ID';
    END IF;
    
    -- Cleanup
    DELETE FROM conversations WHERE id = v_conv1;
    RAISE NOTICE '✓ Cleanup completed';
    
END $$;

-- ============================================
-- 2. TEST MESSAGE CREATION
-- ============================================

DO $$
DECLARE
    v_user1 INT;
    v_user2 INT;
    v_conv INT;
    v_msg INT;
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=== TEST 2: Message Creation ===';
    
    -- Get two test users
    SELECT id INTO v_user1 FROM users WHERE role = 'doctor' LIMIT 1;
    SELECT id INTO v_user2 FROM users WHERE role = 'doctor' OFFSET 1 LIMIT 1;
    
    IF v_user1 IS NULL OR v_user2 IS NULL THEN
        RAISE NOTICE 'Skipping test: Need at least 2 doctor users';
        RETURN;
    END IF;
    
    -- Create conversation
    v_conv := create_direct_conversation(v_user1, v_user2);
    
    -- Send message
    INSERT INTO messages (conversation_id, sender_id, content)
    VALUES (v_conv, v_user1, 'Test message')
    RETURNING id INTO v_msg;
    
    RAISE NOTICE '✓ Message created: %', v_msg;
    
    -- Verify message exists
    IF EXISTS (SELECT 1 FROM messages WHERE id = v_msg) THEN
        RAISE NOTICE '✓ PASSED: Message found in database';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Message not found';
    END IF;
    
    -- Cleanup
    DELETE FROM conversations WHERE id = v_conv;
    RAISE NOTICE '✓ Cleanup completed';
    
END $$;

-- ============================================
-- 3. TEST MESSAGE READS
-- ============================================

DO $$
DECLARE
    v_user1 INT;
    v_user2 INT;
    v_conv INT;
    v_msg INT;
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=== TEST 3: Message Read Receipts ===';
    
    -- Get two test users
    SELECT id INTO v_user1 FROM users WHERE role = 'doctor' LIMIT 1;
    SELECT id INTO v_user2 FROM users WHERE role = 'doctor' OFFSET 1 LIMIT 1;
    
    IF v_user1 IS NULL OR v_user2 IS NULL THEN
        RAISE NOTICE 'Skipping test: Need at least 2 doctor users';
        RETURN;
    END IF;
    
    -- Create conversation
    v_conv := create_direct_conversation(v_user1, v_user2);
    
    -- Send message
    INSERT INTO messages (conversation_id, sender_id, content)
    VALUES (v_conv, v_user1, 'Test message for read receipt')
    RETURNING id INTO v_msg;
    
    -- Mark as read by recipient
    INSERT INTO message_reads (message_id, user_id)
    VALUES (v_msg, v_user2);
    
    -- Verify read receipt
    IF EXISTS (
        SELECT 1 FROM message_reads 
        WHERE message_id = v_msg AND user_id = v_user2
    ) THEN
        RAISE NOTICE '✓ PASSED: Read receipt recorded';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Read receipt not found';
    END IF;
    
    -- Try duplicate read (should be ignored by ON CONFLICT or fail)
    BEGIN
        INSERT INTO message_reads (message_id, user_id)
        VALUES (v_msg, v_user2);
        RAISE EXCEPTION '✗ FAILED: Duplicate read receipt allowed';
    EXCEPTION
        WHEN unique_violation THEN
            RAISE NOTICE '✓ PASSED: Duplicate read receipt blocked';
    END;
    
    -- Cleanup
    DELETE FROM conversations WHERE id = v_conv;
    RAISE NOTICE '✓ Cleanup completed';
    
END $$;

-- ============================================
-- 4. TEST CASCADE DELETION
-- ============================================

DO $$
DECLARE
    v_user1 INT;
    v_user2 INT;
    v_conv INT;
    v_msg_count INT;
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=== TEST 4: Cascade Deletion ===';
    
    -- Get two test users
    SELECT id INTO v_user1 FROM users WHERE role = 'doctor' LIMIT 1;
    SELECT id INTO v_user2 FROM users WHERE role = 'doctor' OFFSET 1 LIMIT 1;
    
    IF v_user1 IS NULL OR v_user2 IS NULL THEN
        RAISE NOTICE 'Skipping test: Need at least 2 doctor users';
        RETURN;
    END IF;
    
    -- Create conversation with messages
    v_conv := create_direct_conversation(v_user1, v_user2);
    
    INSERT INTO messages (conversation_id, sender_id, content)
    VALUES 
        (v_conv, v_user1, 'Message 1'),
        (v_conv, v_user2, 'Message 2'),
        (v_conv, v_user1, 'Message 3');
    
    -- Verify messages exist
    SELECT COUNT(*) INTO v_msg_count FROM messages WHERE conversation_id = v_conv;
    RAISE NOTICE 'Messages before delete: %', v_msg_count;
    
    -- Delete conversation
    DELETE FROM conversations WHERE id = v_conv;
    
    -- Verify cascade deletion
    SELECT COUNT(*) INTO v_msg_count FROM messages WHERE conversation_id = v_conv;
    
    IF v_msg_count = 0 THEN
        RAISE NOTICE '✓ PASSED: Messages cascade deleted';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Messages not deleted (found %)', v_msg_count;
    END IF;
    
    -- Verify members deleted
    IF NOT EXISTS (SELECT 1 FROM conversation_members WHERE conversation_id = v_conv) THEN
        RAISE NOTICE '✓ PASSED: Members cascade deleted';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Members not deleted';
    END IF;
    
    -- Verify direct pair deleted
    IF NOT EXISTS (SELECT 1 FROM conversation_direct_pairs WHERE conversation_id = v_conv) THEN
        RAISE NOTICE '✓ PASSED: Direct pair cascade deleted';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Direct pair not deleted';
    END IF;
    
END $$;

-- ============================================
-- 5. TEST USER PRESENCE
-- ============================================

DO $$
DECLARE
    v_user INT;
    v_status VARCHAR(20);
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=== TEST 5: User Presence ===';
    
    -- Get test user
    SELECT id INTO v_user FROM users LIMIT 1;
    
    IF v_user IS NULL THEN
        RAISE NOTICE 'Skipping test: No users found';
        RETURN;
    END IF;
    
    -- Update presence
    INSERT INTO user_presence (user_id, status, last_seen_at)
    VALUES (v_user, 'online', NOW())
    ON CONFLICT (user_id) DO UPDATE
    SET status = 'online', last_seen_at = NOW();
    
    -- Verify presence
    SELECT status INTO v_status FROM user_presence WHERE user_id = v_user;
    
    IF v_status = 'online' THEN
        RAISE NOTICE '✓ PASSED: Presence updated to online';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Presence status incorrect: %', v_status;
    END IF;
    
    -- Test invalid status (should fail)
    BEGIN
        UPDATE user_presence SET status = 'invalid' WHERE user_id = v_user;
        RAISE EXCEPTION '✗ FAILED: Invalid status allowed';
    EXCEPTION
        WHEN check_violation THEN
            RAISE NOTICE '✓ PASSED: Invalid status blocked';
    END;
    
END $$;

-- ============================================
-- 6. TEST INDEXES
-- ============================================

DO $$
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=== TEST 6: Index Existence ===';
    
    -- Check critical indexes
    IF EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_messages_conversation_created') THEN
        RAISE NOTICE '✓ idx_messages_conversation_created exists';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Critical index missing';
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_direct_pairs_users') THEN
        RAISE NOTICE '✓ idx_direct_pairs_users exists';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Critical index missing';
    END IF;
    
    IF EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_conversation_members_user_id') THEN
        RAISE NOTICE '✓ idx_conversation_members_user_id exists';
    ELSE
        RAISE EXCEPTION '✗ FAILED: Critical index missing';
    END IF;
    
    RAISE NOTICE '✓ PASSED: All critical indexes present';
    
END $$;

-- ============================================
-- SUMMARY
-- ============================================

DO $$
BEGIN
    RAISE NOTICE '';
    RAISE NOTICE '=========================================';
    RAISE NOTICE 'All tests completed successfully!';
    RAISE NOTICE 'Migration 014 is ready for production.';
    RAISE NOTICE '=========================================';
END $$;
