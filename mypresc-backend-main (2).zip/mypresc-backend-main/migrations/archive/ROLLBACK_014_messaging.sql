-- ============================================
-- Rollback: Drop messaging tables
-- Created: 2025-10-22
-- Purpose: Undo migration 014
-- ============================================

-- WARNING: This will delete ALL messaging data!
-- Use with caution in production.

-- ============================================
-- 1. DROP HELPER FUNCTIONS
-- ============================================
DROP FUNCTION IF EXISTS create_direct_conversation(INT, INT) CASCADE;
DROP FUNCTION IF EXISTS get_direct_conversation(INT, INT) CASCADE;

-- ============================================
-- 2. DROP TRIGGERS
-- ============================================
DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;
DROP TRIGGER IF EXISTS update_messages_updated_at ON messages;
DROP TRIGGER IF EXISTS update_user_presence_updated_at ON user_presence;

-- ============================================
-- 3. DROP TABLES (Reverse order of creation)
-- ============================================
-- Drop in reverse order to respect foreign key constraints

-- Typing indicators (no dependencies)
DROP TABLE IF EXISTS typing_indicators CASCADE;

-- User presence (no dependencies)
DROP TABLE IF EXISTS user_presence CASCADE;

-- Message reads (depends on messages)
DROP TABLE IF EXISTS message_reads CASCADE;

-- Messages (depends on conversations)
DROP TABLE IF EXISTS messages CASCADE;

-- Direct pairs (depends on conversations)
DROP TABLE IF EXISTS conversation_direct_pairs CASCADE;

-- Conversation members (depends on conversations)
DROP TABLE IF EXISTS conversation_members CASCADE;

-- Conversations (base table)
DROP TABLE IF EXISTS conversations CASCADE;

-- ============================================
-- 4. CLEANUP (Optional)
-- ============================================
-- If update_updated_at_column() was created in this migration only:
-- DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- Note: We keep update_updated_at_column() as it's likely used by other tables

-- ============================================
-- END OF ROLLBACK
-- ============================================
