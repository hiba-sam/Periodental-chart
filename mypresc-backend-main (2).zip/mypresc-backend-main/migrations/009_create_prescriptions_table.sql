-- Migration: Create prescriptions table
-- Created: 2025-10-02

CREATE TABLE IF NOT EXISTS prescriptions (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    confirmed_count INT DEFAULT 1,
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create junction table for prescription-medication relationships
CREATE TABLE IF NOT EXISTS prescription_medication_items (
    id SERIAL PRIMARY KEY,
    prescription_id INTEGER NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
    prescription_medication_id INTEGER NOT NULL REFERENCES prescription_medications(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_id ON prescriptions(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_doctor_user_id ON prescriptions(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_prescriptions_created_at ON prescriptions(created_at);

CREATE INDEX IF NOT EXISTS idx_prescription_medication_items_prescription_id ON prescription_medication_items(prescription_id);
CREATE INDEX IF NOT EXISTS idx_prescription_medication_items_prescription_medication_id ON prescription_medication_items(prescription_medication_id);

-- Add trigger to update updated_at timestamp for prescriptions
CREATE TRIGGER update_prescriptions_updated_at 
    BEFORE UPDATE ON prescriptions 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Add constraint to prevent duplicate medication items in same prescription
ALTER TABLE prescription_medication_items 
ADD CONSTRAINT unique_prescription_medication 
UNIQUE (prescription_id, prescription_medication_id); 