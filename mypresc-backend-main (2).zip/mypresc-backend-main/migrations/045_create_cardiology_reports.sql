-- Migration 045: Create cardiology_reports table for structured cardiology reports
-- Pattern: same as dental_acts (specialty-specific feature)

CREATE TABLE IF NOT EXISTS cardiology_reports (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- Link to parent medical report (optional)
    medical_report_id INTEGER REFERENCES medical_reports(id) ON DELETE SET NULL,

    -- Section 1: Patient info (cached from patient record)
    patient_age INTEGER,
    patient_sex VARCHAR(10), -- 'homme' | 'femme'
    patient_weight NUMERIC(5,1), -- kg
    patient_height NUMERIC(5,1), -- cm
    patient_bmi NUMERIC(4,1), -- auto-calculated

    -- Section 2: Clinical exam
    heart_rate INTEGER, -- bpm
    systolic_bp INTEGER, -- mmHg
    diastolic_bp INTEGER, -- mmHg
    auscultation VARCHAR(50), -- select value
    lower_limb_edema VARCHAR(20), -- select value
    nyha_class INTEGER CHECK (nyha_class IN (1, 2, 3, 4)),
    chest_pain VARCHAR(30), -- select value
    heart_failure_signs TEXT[], -- checkboxes array

    -- Section 3: Cardiology history (checkboxes)
    has_hta BOOLEAN DEFAULT FALSE,
    has_diabetes BOOLEAN DEFAULT FALSE,
    has_diabetes_insulin BOOLEAN DEFAULT FALSE,
    has_afib BOOLEAN DEFAULT FALSE,
    has_mi BOOLEAN DEFAULT FALSE, -- IDM
    has_stroke BOOLEAN DEFAULT FALSE, -- AVC/AIT
    has_heart_failure BOOLEAN DEFAULT FALSE,
    has_arteriopathy BOOLEAN DEFAULT FALSE,
    has_valvulopathy BOOLEAN DEFAULT FALSE,
    has_active_smoking BOOLEAN DEFAULT FALSE,
    has_stopped_smoking BOOLEAN DEFAULT FALSE,
    has_dyslipidemia BOOLEAN DEFAULT FALSE,
    has_endocarditis BOOLEAN DEFAULT FALSE,
    has_prior_cardiac_surgery BOOLEAN DEFAULT FALSE,
    has_chronic_lung_disease BOOLEAN DEFAULT FALSE,
    has_reduced_mobility BOOLEAN DEFAULT FALSE,
    known_lvef NUMERIC(5,2), -- FEVG connue (%)
    creatinine NUMERIC(7,2), -- µmol/L

    -- Section 4: Complementary exams
    -- ECG
    ecg_result VARCHAR(50), -- select
    ecg_detail TEXT,
    ecg_st_deviation BOOLEAN DEFAULT FALSE,

    -- Echo
    echo_lvef NUMERIC(5,2), -- FEVG %
    echo_lvedd NUMERIC(5,1), -- DTDVG mm
    echo_la_size NUMERIC(5,1), -- Taille OG mm
    echo_valvulopathies TEXT[], -- array of IM, IA, RM, RA, IT, IP
    echo_pulmonary_htn NUMERIC(5,1), -- HTAP mmHg

    -- Bio
    bio_bnp NUMERIC(10,2),
    bio_troponin NUMERIC(10,4),
    bio_ldl NUMERIC(5,2),
    bio_hdl NUMERIC(5,2),
    bio_total_cholesterol NUMERIC(5,2),
    bio_triglycerides NUMERIC(5,2),
    bio_hba1c NUMERIC(4,1),
    bio_creatinine NUMERIC(7,2),
    bio_inr NUMERIC(4,2),

    -- Section 5: Pre-operative (EuroSCORE II)
    preop_critical_state BOOLEAN DEFAULT FALSE,
    preop_urgency VARCHAR(20), -- 'elective' | 'urgent' | 'emergency' | 'salvage'
    preop_surgery_type VARCHAR(50),
    preop_thoracic_aorta BOOLEAN DEFAULT FALSE,
    preop_dialysis BOOLEAN DEFAULT FALSE,

    -- Section 6: Free notes
    free_notes TEXT,

    -- Computed scores (stored on save, recalculated server-side)
    score_cha2ds2_vasc INTEGER,
    score_has_bled INTEGER,
    score_grace INTEGER,
    score_framingham NUMERIC(5,1), -- percentage
    score_score2 NUMERIC(5,1), -- percentage
    score_nyha INTEGER,
    score_euroscore2 NUMERIC(5,2), -- percentage

    -- Generated report text
    generated_report TEXT,

    -- Audit
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_cardiology_reports_patient ON cardiology_reports(patient_id);
CREATE INDEX IF NOT EXISTS idx_cardiology_reports_doctor ON cardiology_reports(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_cardiology_reports_created ON cardiology_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_cardiology_reports_medical_report ON cardiology_reports(medical_report_id);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION update_cardiology_reports_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_cardiology_reports_updated_at ON cardiology_reports;
CREATE TRIGGER trigger_cardiology_reports_updated_at
    BEFORE UPDATE ON cardiology_reports
    FOR EACH ROW
    EXECUTE FUNCTION update_cardiology_reports_updated_at();

COMMENT ON TABLE cardiology_reports IS 'Structured cardiology reports with 7 auto-calculated scores';
COMMENT ON COLUMN cardiology_reports.nyha_class IS 'NYHA functional class: 1-4';
COMMENT ON COLUMN cardiology_reports.score_cha2ds2_vasc IS 'CHA2DS2-VASc score (0-9)';
COMMENT ON COLUMN cardiology_reports.score_has_bled IS 'HAS-BLED score (0-9)';
COMMENT ON COLUMN cardiology_reports.score_grace IS 'GRACE score for ACS mortality';
COMMENT ON COLUMN cardiology_reports.score_framingham IS 'Framingham 10-year CV risk %';
COMMENT ON COLUMN cardiology_reports.score_score2 IS 'SCORE2/SCORE2-OP 10-year fatal CV risk %';
COMMENT ON COLUMN cardiology_reports.score_euroscore2 IS 'EuroSCORE II predicted mortality %';
