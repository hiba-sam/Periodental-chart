-- ============================================
-- MIGRATION: 037_create_doctor_patient_privacy
-- Description: Table pour stocker le choix privé/partagé de chaque médecin par patient
-- ============================================

CREATE TABLE IF NOT EXISTS doctor_patient_privacy (
    id SERIAL PRIMARY KEY,
    
    -- Médecin qui fait le choix
    doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Patient concerné
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    
    -- Choix de confidentialité: 'private' ou 'shared'
    -- 'private' = données visibles uniquement par ce médecin (sauf partage explicite via medical_shares)
    -- 'shared' = données visibles par tous les médecins qui accèdent au patient
    privacy_choice VARCHAR(10) NOT NULL DEFAULT 'shared' CHECK (privacy_choice IN ('private', 'shared')),
    
    -- Métadonnées
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Un médecin ne peut avoir qu'un seul choix par patient
    UNIQUE(doctor_id, patient_id)
);

-- Index pour les requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_doctor_patient_privacy_doctor ON doctor_patient_privacy(doctor_id);
CREATE INDEX IF NOT EXISTS idx_doctor_patient_privacy_patient ON doctor_patient_privacy(patient_id);
CREATE INDEX IF NOT EXISTS idx_doctor_patient_privacy_choice ON doctor_patient_privacy(privacy_choice);

-- Commentaires
COMMENT ON TABLE doctor_patient_privacy IS 'Choix de confidentialité de chaque médecin par patient';
COMMENT ON COLUMN doctor_patient_privacy.privacy_choice IS 'private = données privées, shared = données visibles à tous';

-- Fonction pour mettre à jour updated_at
CREATE OR REPLACE FUNCTION update_doctor_patient_privacy_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_doctor_patient_privacy_updated_at ON doctor_patient_privacy;
CREATE TRIGGER trigger_doctor_patient_privacy_updated_at
    BEFORE UPDATE ON doctor_patient_privacy
    FOR EACH ROW
    EXECUTE FUNCTION update_doctor_patient_privacy_updated_at();
