-- Migration: Add plan and end_date to users table
-- Description: Add subscription plan tracking and expiration date for user accounts
-- Created: 2025-12-10

-- Add plan column with default value 'test'
ALTER TABLE users
ADD COLUMN IF NOT EXISTS plan VARCHAR(50) DEFAULT 'test'
CHECK (plan IN ('test', 'flex', 'smart', 'pro'));

-- Add end_date column for subscription expiration
ALTER TABLE users
ADD COLUMN IF NOT EXISTS end_date TIMESTAMP;

-- Add index for efficient queries on end_date
CREATE INDEX IF NOT EXISTS idx_users_end_date ON users(end_date);

-- Add index for efficient queries on plan
CREATE INDEX IF NOT EXISTS idx_users_plan ON users(plan);

-- Add comments for documentation
COMMENT ON COLUMN users.plan IS 'Subscription plan: test (7 days trial), flex (30 days), smart (180 days), pro (365 days)';
COMMENT ON COLUMN users.end_date IS 'Subscription expiration date - set to +7 days on registration approval for test plan';
