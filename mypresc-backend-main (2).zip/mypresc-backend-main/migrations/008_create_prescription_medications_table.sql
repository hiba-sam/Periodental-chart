-- Migration: Create prescription_medications table
-- Created: 2025-10-02

CREATE TABLE IF NOT EXISTS prescription_medications (
    id SERIAL PRIMARY KEY,
    medication_id INTEGER NOT NULL REFERENCES medications(id) ON DELETE CASCADE,
    quantity INTEGER NOT NULL,
    dosage TEXT NOT NULL,
    note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_prescription_medications_medication_id ON prescription_medications(medication_id);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_prescription_medications_updated_at 
    BEFORE UPDATE ON prescription_medications 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column(); 