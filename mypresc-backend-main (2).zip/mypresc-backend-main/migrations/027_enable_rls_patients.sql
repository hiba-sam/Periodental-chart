-- ============================================
-- MIGRATION: 027_enable_rls_patients
-- Priority: P1 (HIGH - Défense en profondeur)
-- Description: Activer Row-Level Security sur la table patients
-- ============================================

-- PHASE 1: Activer RLS
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;

-- PHASE 2: Policy pour médecin traitant (accès complet à ses patients)
DROP POLICY IF EXISTS patient_medecin_traitant_full_access ON patients;
CREATE POLICY patient_medecin_traitant_full_access ON patients
    FOR ALL
    USING (
        -- Le médecin traitant a accès complet
        medecin_traitant_id = NULLIF(current_setting('app.current_user_id', true), '')::INT
    )
    WITH CHECK (
        medecin_traitant_id = NULLIF(current_setting('app.current_user_id', true), '')::INT
    );

-- PHASE 3: Policy pour lecture des patients non-privés
DROP POLICY IF EXISTS patient_public_read_access ON patients;
CREATE POLICY patient_public_read_access ON patients
    FOR SELECT
    USING (
        -- Accès en lecture si patient non privé OU médecin traitant
        NOT is_private 
        OR medecin_traitant_id = NULLIF(current_setting('app.current_user_id', true), '')::INT
    );

-- PHASE 4: Policy pour les assistants (via relation avec doctor)
DROP POLICY IF EXISTS patient_assistant_access ON patients;
CREATE POLICY patient_assistant_access ON patients
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM assistants a
            WHERE a.user_id = NULLIF(current_setting('app.current_user_id', true), '')::INT
            AND a.doctor_id = patients.medecin_traitant_id
            AND a.is_active = true
        )
    );

-- PHASE 5: Policy bypass pour admins (si nécessaire)
-- Note: En production, créer un rôle admin avec BYPASSRLS
-- ALTER ROLE admin_role BYPASSRLS;

-- PHASE 6: Fonction helper pour set user context
CREATE OR REPLACE FUNCTION set_current_user_id(user_id INT)
RETURNS VOID AS $$
BEGIN
    PERFORM set_config('app.current_user_id', user_id::TEXT, false);
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION set_current_user_id IS 
'Définit l''ID utilisateur courant pour les policies RLS. Appeler depuis le middleware.';

-- PHASE 7: Index pour optimiser les policies
-- Note: CONCURRENTLY removed for transaction compatibility
CREATE INDEX IF NOT EXISTS idx_patients_rls_optimization 
ON patients(medecin_traitant_id, is_private);

-- ============================================
-- INSTRUCTIONS D'INTÉGRATION
-- ============================================
-- Dans le middleware Express, après authentification:
--
-- import pool from '../db';
-- 
-- async function setDbUserContext(userId: number) {
--     await pool.query('SELECT set_current_user_id($1)', [userId]);
-- }
--
-- // Dans le middleware auth:
-- req.on('close', async () => {
--     await pool.query('RESET app.current_user_id');
-- });
-- ============================================

-- ROLLBACK SCRIPT
-- DROP POLICY IF EXISTS patient_medecin_traitant_full_access ON patients;
-- DROP POLICY IF EXISTS patient_public_read_access ON patients;
-- DROP POLICY IF EXISTS patient_assistant_access ON patients;
-- DROP FUNCTION IF EXISTS set_current_user_id;
-- DROP INDEX IF EXISTS idx_patients_rls_optimization;
-- ALTER TABLE patients DISABLE ROW LEVEL SECURITY;
