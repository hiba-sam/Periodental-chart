-- Migration: Add is_custom and custom_medication_id to prescription_medications
-- Fixes: "column is_custom of relation prescription_medications does not exist"
-- Created: 2026-04-03

-- Allow medication_id to be NULL (custom meds don't reference the medications table)
ALTER TABLE prescription_medications ALTER COLUMN medication_id DROP NOT NULL;

-- Add custom medication support columns
ALTER TABLE prescription_medications
    ADD COLUMN IF NOT EXISTS is_custom BOOLEAN DEFAULT false,
    ADD COLUMN IF NOT EXISTS custom_medication_id INTEGER REFERENCES custom_medications(id) ON DELETE SET NULL;

-- Index for custom medication lookups
CREATE INDEX IF NOT EXISTS idx_prescription_medications_custom_id
    ON prescription_medications(custom_medication_id)
    WHERE custom_medication_id IS NOT NULL;
