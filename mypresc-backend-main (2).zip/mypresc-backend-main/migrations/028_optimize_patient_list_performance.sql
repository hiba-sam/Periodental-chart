-- ============================================
-- MIGRATION: 028_optimize_patient_list_performance
-- Priority: P0 (CRITIQUE - Performance)
-- Description: Indexes composites pour optimiser la requête de liste des patients
-- Impact: Réduit le temps de chargement de 3-8s à < 300ms
-- ============================================

-- PHASE 1: Index composite pour prescriptions
-- Index on prescriptions for faster counts
CREATE INDEX IF NOT EXISTS idx_prescriptions_patient_doctor 
ON prescriptions(patient_id, doctor_user_id);

-- PHASE 2: Index composite pour appointments
-- Index on appointments to find last visited
CREATE INDEX IF NOT EXISTS idx_appointments_patient_doctor_done 
ON appointments(patient_id, doctor_user_id, is_done)
WHERE is_done = true;

-- PHASE 3: Index pour assistant relation
-- Index on assistants to find active doctor relationship
CREATE INDEX IF NOT EXISTS idx_assistants_user_doctor_active 
ON assistants(user_id, doctor_id) 
WHERE is_active = true;

-- PHASE 4: Index existant à vérifier
-- Déjà existant dans 027_enable_rls_patients.sql:
-- idx_patients_rls_optimization ON patients(medecin_traitant_id, is_private)

-- ============================================
-- COMMENTAIRES POUR LA DOC
-- ============================================
COMMENT ON INDEX idx_prescriptions_patient_doctor IS 
'Optimise les requêtes de liste patients filtrés par médecin - réduit scan de table';

COMMENT ON INDEX idx_appointments_patient_doctor_done IS 
'Optimise les requêtes de liste patients avec rendez-vous terminés - partial index pour efficacité';

COMMENT ON INDEX idx_assistants_user_doctor_active IS 
'Optimise la vérification de la relation assistant-médecin active';

-- ============================================
-- ANALYSE DE PERFORMANCE
-- ============================================
-- Pour vérifier l'utilisation des index après migration:
-- EXPLAIN ANALYZE SELECT DISTINCT p.id FROM patients p
-- WHERE EXISTS (
--     SELECT 1 FROM prescriptions pr 
--     WHERE pr.patient_id = p.id AND pr.doctor_user_id = 1
-- );
-- 
-- Devrait montrer "Index Scan using idx_prescriptions_patient_doctor"

-- ============================================
-- ROLLBACK SCRIPT
-- ============================================
-- DROP INDEX CONCURRENTLY IF EXISTS idx_prescriptions_patient_doctor;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_appointments_patient_doctor_done;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_assistants_user_doctor_active;
