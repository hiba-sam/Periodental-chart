-- ============================================
-- MIGRATION: 027_medical_shares
-- Description: Table pour partager le dossier médical avec d'autres médecins
-- ============================================

CREATE TABLE IF NOT EXISTS medical_shares (
    id SERIAL PRIMARY KEY,
    
    -- Qui partage (le médecin qui a accès au patient)
    shared_by_doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Patient concerné
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    
    -- Médecin(s) avec qui on partage
    shared_with_doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Types de données partagées
    share_prescriptions BOOLEAN DEFAULT true,
    share_medical_reports BOOLEAN DEFAULT true,
    
    -- Visibilité temporelle: ne montrer que les documents jusqu'à cette date
    -- NULL = tous les documents
    visible_until_date TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    -- Durée du partage: date d'expiration
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    
    -- Statut
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
    
    -- Métadonnées
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Un médecin ne peut partager un patient qu'une fois avec un autre médecin
    UNIQUE(shared_by_doctor_id, patient_id, shared_with_doctor_id)
);

-- Index pour les requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_medical_shares_patient ON medical_shares(patient_id);
CREATE INDEX IF NOT EXISTS idx_medical_shares_shared_with ON medical_shares(shared_with_doctor_id);
CREATE INDEX IF NOT EXISTS idx_medical_shares_status ON medical_shares(status);
CREATE INDEX IF NOT EXISTS idx_medical_shares_expires ON medical_shares(expires_at);

-- Commentaires
COMMENT ON TABLE medical_shares IS 'Partages de dossiers médicaux entre médecins';
COMMENT ON COLUMN medical_shares.visible_until_date IS 'Ne montrer que les documents créés avant cette date (NULL = tous)';
COMMENT ON COLUMN medical_shares.expires_at IS 'Date d''expiration du partage';

-- Fonction pour mettre à jour updated_at
CREATE OR REPLACE FUNCTION update_medical_shares_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_medical_shares_updated_at ON medical_shares;
CREATE TRIGGER trigger_medical_shares_updated_at
    BEFORE UPDATE ON medical_shares
    FOR EACH ROW
    EXECUTE FUNCTION update_medical_shares_updated_at();

-- Fonction pour expirer automatiquement les partages
CREATE OR REPLACE FUNCTION expire_medical_shares()
RETURNS void AS $$
BEGIN
    UPDATE medical_shares 
    SET status = 'expired' 
    WHERE status = 'active' 
    AND expires_at < NOW();
END;
$$ LANGUAGE plpgsql;
