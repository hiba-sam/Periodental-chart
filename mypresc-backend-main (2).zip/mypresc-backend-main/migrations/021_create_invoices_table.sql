-- Migration: Create invoices table
-- Description: This table stores invoice information for payment transactions
-- Created: 2025-12-10

CREATE TABLE IF NOT EXISTS invoices (
    id SERIAL PRIMARY KEY,
    invoice_number VARCHAR(50) UNIQUE NOT NULL,
    payment_id INTEGER NOT NULL REFERENCES payments(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan VARCHAR(50) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'DZD',
    tax_amount DECIMAL(10, 2) DEFAULT 0,
    total_amount DECIMAL(10, 2) NOT NULL,
    invoice_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    pdf_path TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX idx_invoices_payment_id ON invoices(payment_id);
CREATE INDEX idx_invoices_doctor_user_id ON invoices(doctor_user_id);
CREATE INDEX idx_invoices_invoice_number ON invoices(invoice_number);
CREATE INDEX idx_invoices_invoice_date ON invoices(invoice_date DESC);

-- Create trigger to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_invoices_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_invoices_updated_at
    BEFORE UPDATE ON invoices
    FOR EACH ROW
    EXECUTE FUNCTION update_invoices_updated_at();

-- Add comments for documentation
COMMENT ON TABLE invoices IS 'Stores invoices for payment transactions';
COMMENT ON COLUMN invoices.invoice_number IS 'Unique invoice number (format: INV-YYYY-XXXXXX)';
COMMENT ON COLUMN invoices.payment_id IS 'Reference to the payment record';
COMMENT ON COLUMN invoices.doctor_user_id IS 'Reference to the doctor user';
COMMENT ON COLUMN invoices.plan IS 'Subscription plan: flex, smart, or pro';
COMMENT ON COLUMN invoices.amount IS 'Subtotal amount before tax';
COMMENT ON COLUMN invoices.tax_amount IS 'Tax amount (TVA)';
COMMENT ON COLUMN invoices.total_amount IS 'Total amount including tax';
COMMENT ON COLUMN invoices.pdf_path IS 'Path to the generated PDF invoice';
