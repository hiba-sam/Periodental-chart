-- Migration 048: Add extended echocardiography fields + SpO2 to cardiology_reports
-- Requested by cardiologist audit: 8 critical echo fields + SpO2 + valvulopathy severity

-- New echo fields
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_lvesd NUMERIC(5,1);        -- DTSVG (mm)
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_ivs_thickness NUMERIC(5,1); -- Épaisseur SIV (mm)
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_pw_thickness NUMERIC(5,1);  -- Épaisseur paroi postérieure (mm)
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_tapse NUMERIC(5,1);         -- TAPSE (mm)
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_wall_motion VARCHAR(30);    -- Cinétique segmentaire: normal/hypokinesia/akinesia/dyskinesia
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_wall_motion_detail TEXT;    -- Territoire concerné (si hypo/akinésie)
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_diastolic_function VARCHAR(30); -- Fonction diastolique: normal/relaxation_impaired/pseudonormal/restrictive
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_pericardial_effusion VARCHAR(20); -- Épanchement péricardique: absent/minime/modere/important

-- Valvulopathy severity (JSON object: {"IM": "legere", "IA": "severe", ...})
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS echo_valvulopathy_severity JSONB DEFAULT '{}';

-- SpO2 in clinical exam
ALTER TABLE cardiology_reports ADD COLUMN IF NOT EXISTS spo2 INTEGER; -- Saturation O2 (%)

-- Comments
COMMENT ON COLUMN cardiology_reports.echo_lvesd IS 'LV end-systolic diameter (DTSVG) in mm';
COMMENT ON COLUMN cardiology_reports.echo_ivs_thickness IS 'Interventricular septum thickness (SIV) in mm';
COMMENT ON COLUMN cardiology_reports.echo_pw_thickness IS 'Posterior wall thickness (PP) in mm';
COMMENT ON COLUMN cardiology_reports.echo_tapse IS 'Tricuspid annular plane systolic excursion in mm';
COMMENT ON COLUMN cardiology_reports.echo_wall_motion IS 'Segmental wall motion: normal, hypokinesia, akinesia, dyskinesia';
COMMENT ON COLUMN cardiology_reports.echo_wall_motion_detail IS 'Territory description when wall motion is abnormal';
COMMENT ON COLUMN cardiology_reports.echo_diastolic_function IS 'Diastolic function: normal, relaxation_impaired, pseudonormal, restrictive';
COMMENT ON COLUMN cardiology_reports.echo_pericardial_effusion IS 'Pericardial effusion: absent, minime, modere, important';
COMMENT ON COLUMN cardiology_reports.echo_valvulopathy_severity IS 'Severity per valve as JSON: {"IM":"legere","IA":"severe",...}';
COMMENT ON COLUMN cardiology_reports.spo2 IS 'Oxygen saturation SpO2 in %';
