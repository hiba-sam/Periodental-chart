-- Migration: Create medical_share_audit_logs table for tracking share actions
-- This table logs all medical share actions for legal compliance and audit purposes

CREATE TABLE IF NOT EXISTS medical_share_audit_logs (
    id SERIAL PRIMARY KEY,
    
    -- Who performed the action
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    doctor_name VARCHAR(255) NOT NULL,
    doctor_family_name VARCHAR(255) NOT NULL,
    doctor_email VARCHAR(255) NOT NULL,
    
    -- Patient information
    patient_id VARCHAR(255) NOT NULL,
    patient_name VARCHAR(255) NOT NULL,
    
    -- Share details
    shared_with_doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    shared_with_doctor_name VARCHAR(255) NOT NULL,
    shared_with_doctor_family_name VARCHAR(255) NOT NULL,
    shared_with_doctor_email VARCHAR(255) NOT NULL,
    
    -- What was shared
    share_prescriptions BOOLEAN DEFAULT false,
    share_medical_reports BOOLEAN DEFAULT false,
    visible_until_date DATE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    
    -- Reason and confirmation
    reason TEXT NOT NULL,
    patient_informed_confirmed BOOLEAN NOT NULL DEFAULT true,
    
    -- Action type
    action_type VARCHAR(50) NOT NULL DEFAULT 'share_created',
    -- Possible values: 'share_created', 'share_revoked', 'share_deleted', 'share_expired'
    
    -- Medical share reference (if still exists)
    medical_share_id INTEGER REFERENCES medical_shares(id) ON DELETE SET NULL,
    
    -- Metadata
    ip_address VARCHAR(45),
    user_agent TEXT,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Add index for common queries
    CONSTRAINT valid_action_type CHECK (action_type IN ('share_created', 'share_revoked', 'share_deleted', 'share_expired'))
);

-- Indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_audit_logs_doctor_user_id ON medical_share_audit_logs(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_patient_id ON medical_share_audit_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_shared_with_doctor_id ON medical_share_audit_logs(shared_with_doctor_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON medical_share_audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action_type ON medical_share_audit_logs(action_type);

-- Add reason column to medical_shares if not exists
ALTER TABLE medical_shares ADD COLUMN IF NOT EXISTS reason TEXT;

COMMENT ON TABLE medical_share_audit_logs IS 'Audit trail for all medical share actions - required for legal compliance per Algerian medical deontology code';
COMMENT ON COLUMN medical_share_audit_logs.reason IS 'Medical reason for sharing - required for legal documentation';
COMMENT ON COLUMN medical_share_audit_logs.patient_informed_confirmed IS 'Doctor confirmed patient was informed per law n°18-11';
