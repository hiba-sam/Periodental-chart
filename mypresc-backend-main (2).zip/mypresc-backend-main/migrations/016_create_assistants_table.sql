-- Migration: Create assistants table
-- Created: 2025-11-26

CREATE TABLE IF NOT EXISTS assistants (
    id SERIAL PRIMARY KEY,
    user_id INT UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    assistant_name VARCHAR(255) NOT NULL,
    assistant_email VARCHAR(255) NOT NULL,
    doctor_id INT NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
    phone_number VARCHAR(255),
    invitation_token VARCHAR(500) UNIQUE,
    is_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_assistants_user_id ON assistants(user_id);
CREATE INDEX IF NOT EXISTS idx_assistants_doctor_id ON assistants(doctor_id);
CREATE INDEX IF NOT EXISTS idx_assistants_is_active ON assistants(is_active);
CREATE INDEX IF NOT EXISTS idx_assistants_invitation_token ON assistants(invitation_token);
CREATE INDEX IF NOT EXISTS idx_assistants_email ON assistants(assistant_email);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_assistants_updated_at
    BEFORE UPDATE ON assistants
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE assistants IS 'Assistant profile information table - links assistants to their doctors, stores both pending invitations and active assistants';
COMMENT ON COLUMN assistants.id IS 'Primary key';
COMMENT ON COLUMN assistants.user_id IS 'Foreign key to users table - NULL until assistant completes registration';
COMMENT ON COLUMN assistants.assistant_name IS 'Assistant name provided during invitation';
COMMENT ON COLUMN assistants.assistant_email IS 'Assistant email address for invitation';
COMMENT ON COLUMN assistants.doctor_id IS 'Foreign key to doctors table - the doctor this assistant works for';
COMMENT ON COLUMN assistants.phone_number IS 'Assistant phone number - set after registration completion';
COMMENT ON COLUMN assistants.invitation_token IS 'Unique invitation token for assistant registration';
COMMENT ON COLUMN assistants.is_active IS 'Whether the assistant account is currently active - becomes true after registration';
COMMENT ON COLUMN assistants.created_at IS 'Record creation timestamp';
COMMENT ON COLUMN assistants.updated_at IS 'Last update timestamp';
