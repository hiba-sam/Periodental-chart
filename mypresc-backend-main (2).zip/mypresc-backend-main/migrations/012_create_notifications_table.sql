-- Migration: Create notifications table
-- Created: 2024-01-01 00:00:00

CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    link VARCHAR(500) NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('alert', 'check', 'error', 'info')),
    is_seen BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_is_seen ON notifications(is_seen);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_title ON notifications(title);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created_at ON notifications(user_id, created_at DESC);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_notifications_updated_at 
    BEFORE UPDATE ON notifications 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE notifications IS 'User-specific notifications table for alerts, info, errors, and check messages';
COMMENT ON COLUMN notifications.id IS 'Primary key (UUID)';
COMMENT ON COLUMN notifications.user_id IS 'Foreign key to users table - each notification belongs to a specific user';
COMMENT ON COLUMN notifications.title IS 'Notification title';
COMMENT ON COLUMN notifications.description IS 'Notification description/content';
COMMENT ON COLUMN notifications.link IS 'Optional link URL for the notification';
COMMENT ON COLUMN notifications.type IS 'Notification type (alert, check, error, info)';
COMMENT ON COLUMN notifications.is_seen IS 'Whether the notification has been seen';
COMMENT ON COLUMN notifications.created_at IS 'Notification creation timestamp';
COMMENT ON COLUMN notifications.updated_at IS 'Last update timestamp';
