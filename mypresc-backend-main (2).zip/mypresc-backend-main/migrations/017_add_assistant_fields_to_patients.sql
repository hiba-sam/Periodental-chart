-- Migration: Add assistant_id and is_chart_readed to patients table
-- Created: 2025-12-01

-- Add assistant_id field to track which assistant is managing the patient
ALTER TABLE patients
ADD COLUMN IF NOT EXISTS assistant_id INTEGER DEFAULT NULL REFERENCES users(id) ON DELETE SET NULL;

-- Add is_chart_readed field to track if the patient chart has been read
ALTER TABLE patients
ADD COLUMN IF NOT EXISTS is_chart_readed BOOLEAN DEFAULT false;

-- Create index for assistant_id for better performance
CREATE INDEX IF NOT EXISTS idx_patients_assistant_id ON patients(assistant_id);

-- Create index for is_chart_readed for filtering
CREATE INDEX IF NOT EXISTS idx_patients_is_chart_readed ON patients(is_chart_readed);

-- Add comments for documentation
COMMENT ON COLUMN patients.assistant_id IS 'Foreign key to assistants table - the assistant managing this patient (nullable)';
COMMENT ON COLUMN patients.is_chart_readed IS 'Flag indicating whether the patient chart has been read by the assistant';
