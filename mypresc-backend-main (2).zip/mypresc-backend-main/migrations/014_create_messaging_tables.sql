-- ============================================
-- Migration: Create messaging tables (1-to-1)
-- Created: 2025-10-22
-- Purpose: Direct messaging between doctors
-- ============================================

-- ============================================
-- 1. CONVERSATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    type VARCHAR(20) NOT NULL DEFAULT 'direct' CHECK (type IN ('direct')),
    created_by INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for filtering by type and creator
CREATE INDEX IF NOT EXISTS idx_conversations_type ON conversations(type);
CREATE INDEX IF NOT EXISTS idx_conversations_created_by ON conversations(created_by);
CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

-- Comments
COMMENT ON TABLE conversations IS 'Messaging conversations between users';
COMMENT ON COLUMN conversations.id IS 'Primary key';
COMMENT ON COLUMN conversations.type IS 'Conversation type (currently only direct)';
COMMENT ON COLUMN conversations.created_by IS 'User who initiated the conversation';
COMMENT ON COLUMN conversations.created_at IS 'Creation timestamp';
COMMENT ON COLUMN conversations.updated_at IS 'Last update timestamp';

-- ============================================
-- 2. CONVERSATION MEMBERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS conversation_members (
    id SERIAL PRIMARY KEY,
    conversation_id INT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    last_read_at TIMESTAMPTZ,
    UNIQUE(conversation_id, user_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_conversation_members_conversation_id ON conversation_members(conversation_id);
CREATE INDEX IF NOT EXISTS idx_conversation_members_user_id ON conversation_members(user_id);
CREATE INDEX IF NOT EXISTS idx_conversation_members_last_read_at ON conversation_members(last_read_at);

-- Comments
COMMENT ON TABLE conversation_members IS 'Members participating in conversations';
COMMENT ON COLUMN conversation_members.conversation_id IS 'Foreign key to conversations';
COMMENT ON COLUMN conversation_members.user_id IS 'Foreign key to users';
COMMENT ON COLUMN conversation_members.role IS 'Member role (admin or member)';
COMMENT ON COLUMN conversation_members.joined_at IS 'When user joined conversation';
COMMENT ON COLUMN conversation_members.last_read_at IS 'Last message read timestamp for unread badge calculation';

-- ============================================
-- 3. DIRECT CONVERSATION UNIQUENESS TABLE
-- ============================================
-- Purpose: Ensure only ONE direct conversation per user pair
-- Uses LEAST/GREATEST to normalize user order
CREATE TABLE IF NOT EXISTS conversation_direct_pairs (
    conversation_id INT PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
    user_a INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    user_b INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    -- Constraint: user_a must be less than user_b (normalized)
    CHECK (user_a < user_b),
    -- Unique constraint on the normalized pair
    UNIQUE(user_a, user_b)
);

-- Index for lookups
CREATE INDEX IF NOT EXISTS idx_direct_pairs_users ON conversation_direct_pairs(user_a, user_b);

-- Comments
COMMENT ON TABLE conversation_direct_pairs IS 'Ensures uniqueness of direct conversations between two users';
COMMENT ON COLUMN conversation_direct_pairs.conversation_id IS 'Foreign key to conversations';
COMMENT ON COLUMN conversation_direct_pairs.user_a IS 'First user ID (normalized: always < user_b)';
COMMENT ON COLUMN conversation_direct_pairs.user_b IS 'Second user ID (normalized: always > user_a)';

-- ============================================
-- 4. MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    conversation_id INT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id INT NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    is_edited BOOLEAN DEFAULT FALSE,
    edited_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance (critical for pagination)
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at_desc ON messages(created_at DESC);
-- Composite index for efficient conversation message pagination
CREATE INDEX IF NOT EXISTS idx_messages_conversation_created ON messages(conversation_id, created_at DESC);
-- Index for filtering non-deleted messages
CREATE INDEX IF NOT EXISTS idx_messages_deleted_at ON messages(deleted_at) WHERE deleted_at IS NULL;

-- Comments
COMMENT ON TABLE messages IS 'Messages sent in conversations';
COMMENT ON COLUMN messages.id IS 'Primary key';
COMMENT ON COLUMN messages.conversation_id IS 'Foreign key to conversations';
COMMENT ON COLUMN messages.sender_id IS 'Foreign key to users (message sender)';
COMMENT ON COLUMN messages.content IS 'Message text content';
COMMENT ON COLUMN messages.is_edited IS 'Whether message has been edited';
COMMENT ON COLUMN messages.edited_at IS 'Timestamp of last edit';
COMMENT ON COLUMN messages.deleted_at IS 'Soft delete timestamp (NULL if not deleted)';
COMMENT ON COLUMN messages.created_at IS 'Message creation timestamp';
COMMENT ON COLUMN messages.updated_at IS 'Last update timestamp';

-- ============================================
-- 5. MESSAGE READS TABLE (Read Receipts)
-- ============================================
CREATE TABLE IF NOT EXISTS message_reads (
    message_id INT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    read_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (message_id, user_id)
);

-- Index for querying read status by user
CREATE INDEX IF NOT EXISTS idx_message_reads_user_id ON message_reads(user_id);
CREATE INDEX IF NOT EXISTS idx_message_reads_read_at ON message_reads(read_at);

-- Comments
COMMENT ON TABLE message_reads IS 'Tracks which users have read which messages';
COMMENT ON COLUMN message_reads.message_id IS 'Foreign key to messages';
COMMENT ON COLUMN message_reads.user_id IS 'Foreign key to users';
COMMENT ON COLUMN message_reads.read_at IS 'When user read the message';

-- ============================================
-- 6. USER PRESENCE TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_presence (
    user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'offline' CHECK (status IN ('online', 'away', 'offline')),
    last_seen_at TIMESTAMPTZ,
    socket_id VARCHAR(100),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for filtering by status
CREATE INDEX IF NOT EXISTS idx_user_presence_status ON user_presence(status);
CREATE INDEX IF NOT EXISTS idx_user_presence_last_seen ON user_presence(last_seen_at DESC);

-- Comments
COMMENT ON TABLE user_presence IS 'Real-time user online/offline status';
COMMENT ON COLUMN user_presence.user_id IS 'Foreign key to users (primary key)';
COMMENT ON COLUMN user_presence.status IS 'Current presence status';
COMMENT ON COLUMN user_presence.last_seen_at IS 'Last activity timestamp';
COMMENT ON COLUMN user_presence.socket_id IS 'Socket.io connection ID';
COMMENT ON COLUMN user_presence.updated_at IS 'Last update timestamp';

-- ============================================
-- 7. TYPING INDICATORS TABLE (Optional)
-- ============================================
CREATE TABLE IF NOT EXISTS typing_indicators (
    conversation_id INT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (conversation_id, user_id)
);

-- Index for efficient cleanup of stale indicators
CREATE INDEX IF NOT EXISTS idx_typing_started_at ON typing_indicators(started_at);

-- Comments
COMMENT ON TABLE typing_indicators IS 'Temporary storage for "user is typing..." indicators';
COMMENT ON COLUMN typing_indicators.conversation_id IS 'Foreign key to conversations';
COMMENT ON COLUMN typing_indicators.user_id IS 'Foreign key to users (who is typing)';
COMMENT ON COLUMN typing_indicators.started_at IS 'When typing started (cleanup after 10s)';

-- ============================================
-- 8. TRIGGERS FOR AUTO-UPDATE TIMESTAMPS
-- ============================================
-- Note: update_updated_at_column() function should already exist from migration 001
-- If not, create it here:

-- Check if function exists, create if not
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
        CREATE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $func$
        BEGIN
            NEW.updated_at = CURRENT_TIMESTAMP;
            RETURN NEW;
        END;
        $func$ LANGUAGE plpgsql;
    END IF;
END
$$;

-- Apply triggers
CREATE TRIGGER update_conversations_updated_at
    BEFORE UPDATE ON conversations
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_messages_updated_at
    BEFORE UPDATE ON messages
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_presence_updated_at
    BEFORE UPDATE ON user_presence
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- 9. HELPER FUNCTION: Get or Create Direct Conversation
-- ============================================
-- Function to find existing conversation or return NULL
CREATE OR REPLACE FUNCTION get_direct_conversation(p_user_a INT, p_user_b INT)
RETURNS INT AS $$
DECLARE
    v_conversation_id INT;
    v_min_user INT;
    v_max_user INT;
BEGIN
    -- Normalize user order
    v_min_user := LEAST(p_user_a, p_user_b);
    v_max_user := GREATEST(p_user_a, p_user_b);
    
    -- Find existing conversation
    SELECT conversation_id INTO v_conversation_id
    FROM conversation_direct_pairs
    WHERE user_a = v_min_user AND user_b = v_max_user;
    
    RETURN v_conversation_id;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_direct_conversation IS 'Finds existing direct conversation between two users';

-- ============================================
-- 10. HELPER FUNCTION: Create Direct Conversation
-- ============================================
CREATE OR REPLACE FUNCTION create_direct_conversation(p_creator INT, p_other_user INT)
RETURNS INT AS $$
DECLARE
    v_conversation_id INT;
    v_min_user INT;
    v_max_user INT;
    v_existing_id INT;
BEGIN
    -- Check if conversation already exists
    v_existing_id := get_direct_conversation(p_creator, p_other_user);
    
    IF v_existing_id IS NOT NULL THEN
        RAISE EXCEPTION 'Conversation already exists: %', v_existing_id;
    END IF;
    
    -- Normalize user order
    v_min_user := LEAST(p_creator, p_other_user);
    v_max_user := GREATEST(p_creator, p_other_user);
    
    -- Create conversation
    INSERT INTO conversations (type, created_by)
    VALUES ('direct', p_creator)
    RETURNING id INTO v_conversation_id;
    
    -- Register in pairs table
    INSERT INTO conversation_direct_pairs (conversation_id, user_a, user_b)
    VALUES (v_conversation_id, v_min_user, v_max_user);
    
    -- Add both members
    INSERT INTO conversation_members (conversation_id, user_id, role)
    VALUES 
        (v_conversation_id, p_creator, 'member'),
        (v_conversation_id, p_other_user, 'member');
    
    RETURN v_conversation_id;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION create_direct_conversation IS 'Creates a new direct conversation between two users (idempotent)';

-- ============================================
-- 11. INITIAL DATA SEEDING
-- ============================================
-- Initialize presence for all existing users
INSERT INTO user_presence (user_id, status, last_seen_at)
SELECT id, 'offline', NOW()
FROM users
ON CONFLICT (user_id) DO NOTHING;

-- ============================================
-- END OF MIGRATION
-- ============================================
