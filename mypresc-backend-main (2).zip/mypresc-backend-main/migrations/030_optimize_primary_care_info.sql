-- ============================================
-- MIGRATION: 030_optimize_primary_care_info
-- Priority: P0 (CRITIQUE - Performance getPrimaryCareInfo)
-- Description: Index pour optimiser le JOIN patients-users-doctors
-- Impact: Réduit le temps de chargement de getPrimaryCareInfo
-- ============================================

-- PHASE 1: Index pour le JOIN doctors.user_id
-- Optimise: LEFT-- 1. Index sur doctors.user_id (pour jointure performante)
CREATE INDEX IF NOT EXISTS idx_doctors_user_id 
ON doctors(user_id);

-- PHASE 2: Index composite pour patients(id, medecin_traitant_id, shared_with_primary_care)
-- Optimise: SELECT ... FROM patients WHERE id = X (avec projection)
-- Note: patients(id) est déjà PK, mais index composite améliore la projection
CREATE INDEX IF NOT EXISTS idx_patients_id_medecin 
ON patients(id, medecin_traitant_id, shared_with_primary_care);

-- ============================================
-- COMMENTAIRES POUR LA DOC
-- ============================================
COMMENT ON INDEX idx_doctors_user_id IS 
'Optimise le JOIN entre users et doctors pour récupération rapide des infos médecin';

COMMENT ON INDEX idx_patients_id_medecin IS 
'Index covering pour getPrimaryCareInfo - évite table access supplémentaire';

-- ============================================
-- ANALYSE DE PERFORMANCE
-- ============================================
-- Pour vérifier l'utilisation des index après migration:
-- 
-- EXPLAIN ANALYZE 
-- SELECT p.medecin_traitant_id, p.shared_with_primary_care,
--        u.id, u.name, u.family_name, d.phone_number
-- FROM patients p
-- LEFT JOIN users u ON p.medecin_traitant_id = u.id
-- LEFT JOIN doctors d ON u.id = d.user_id
-- WHERE p.id = 'some-uuid';
-- 
-- Devrait montrer:
-- - "Index Scan using patients_pkey" ou "Index Only Scan using idx_patients_id_medecin"
-- - "Index Scan using users_pkey" pour users
-- - "Index Scan using idx_doctors_user_id" pour doctors

-- ============================================
-- ROLLBACK SCRIPT
-- ============================================
-- DROP INDEX CONCURRENTLY IF EXISTS idx_doctors_user_id;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_patients_id_medecin;
