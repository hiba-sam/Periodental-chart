-- Migration 050: Add missing HAS-BLED score fields to cardiology_reports
-- Adds: hepatic anomaly, bleeding history, NSAIDs/antiplatelets, excessive alcohol

ALTER TABLE cardiology_reports
    ADD COLUMN IF NOT EXISTS has_hepatic_anomaly BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS has_bleeding_history BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS has_nsaid_antiplatelet BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS has_excessive_alcohol BOOLEAN DEFAULT FALSE;

COMMENT ON COLUMN cardiology_reports.has_hepatic_anomaly IS 'HAS-BLED: Anomalie hépatique';
COMMENT ON COLUMN cardiology_reports.has_bleeding_history IS 'HAS-BLED: Antécédent hémorragique';
COMMENT ON COLUMN cardiology_reports.has_nsaid_antiplatelet IS 'HAS-BLED: Médicaments (AINS/antiagrégants)';
COMMENT ON COLUMN cardiology_reports.has_excessive_alcohol IS 'HAS-BLED: Alcool excessif';
