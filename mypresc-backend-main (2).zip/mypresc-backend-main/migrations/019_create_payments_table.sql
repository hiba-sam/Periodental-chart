-- Migration: Create payments table
-- Description: This table stores payment information for doctor subscriptions
-- Created: 2025-12-10

CREATE TABLE IF NOT EXISTS payments (
    id SERIAL PRIMARY KEY,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    checkout_id VARCHAR(255) UNIQUE NOT NULL,
    plan VARCHAR(50) NOT NULL CHECK (plan IN ('flex', 'smart', 'pro')),
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'DZD',
    status VARCHAR(50) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'expired', 'canceled')),
    payment_method VARCHAR(100),
    transaction_id VARCHAR(255),
    checkout_url TEXT,
    expires_at TIMESTAMP,
    paid_at TIMESTAMP,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX idx_payments_doctor_user_id ON payments(doctor_user_id);
CREATE INDEX idx_payments_checkout_id ON payments(checkout_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_created_at ON payments(created_at DESC);

-- Create trigger to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_payments_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_payments_updated_at
    BEFORE UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION update_payments_updated_at();

-- Add comments for documentation
COMMENT ON TABLE payments IS 'Stores payment transactions for doctor subscriptions';
COMMENT ON COLUMN payments.doctor_user_id IS 'Reference to the doctor user making the payment';
COMMENT ON COLUMN payments.checkout_id IS 'Chargily checkout ID';
COMMENT ON COLUMN payments.plan IS 'Subscription plan: flex (30 days), smart (180 days), or pro (365 days)';
COMMENT ON COLUMN payments.amount IS 'Payment amount in DZD';
COMMENT ON COLUMN payments.status IS 'Payment status: pending, paid, failed, expired, or canceled';
COMMENT ON COLUMN payments.transaction_id IS 'Chargily transaction ID after successful payment';
COMMENT ON COLUMN payments.checkout_url IS 'URL to redirect user for payment';
COMMENT ON COLUMN payments.metadata IS 'Additional payment metadata from Chargily';
