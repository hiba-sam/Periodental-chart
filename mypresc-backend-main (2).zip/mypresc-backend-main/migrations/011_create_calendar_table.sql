-- Migration: Create calendar table
-- Created: 2024-01-15 00:00:00

-- Enable pgcrypto extension for UUID generation
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS calendar (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doctor_user_id INT NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
    appointment_id UUID REFERENCES appointments(id) ON DELETE CASCADE ,
    title VARCHAR(255) NOT NULL,
    note TEXT,
    date DATE NOT NULL,
    time TIME NOT NULL,
    duration INTEGER NOT NULL DEFAULT 15, -- Duration in minutes
    color TEXT DEFAULT '#2563eb',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    -- Constraint: appointment_id must be either NULL (standalone event) or a valid UUID
    CONSTRAINT chk_calendar_event_type CHECK (
        -- Either it's a standalone event (appointment_id is NULL and title/note are custom)
        -- Or it's linked to an appointment (appointment_id is NOT NULL)
        (appointment_id IS NULL) OR (appointment_id IS NOT NULL)
    )
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_calendar_doctor_user_id ON calendar(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_calendar_appointment_id ON calendar(appointment_id);
CREATE INDEX IF NOT EXISTS idx_calendar_date ON calendar(date);
CREATE INDEX IF NOT EXISTS idx_calendar_time ON calendar(time);
CREATE INDEX IF NOT EXISTS idx_calendar_date_time ON calendar(date, time);
CREATE INDEX IF NOT EXISTS idx_calendar_created_at ON calendar(created_at);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_calendar_updated_at
    BEFORE UPDATE ON calendar
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create function to automatically set title from appointment when appointment_id is set
CREATE OR REPLACE FUNCTION set_calendar_title_from_appointment()
RETURNS TRIGGER AS $$
DECLARE
    patient_full_name TEXT;
    encryption_key TEXT;
BEGIN
    -- If appointment_id is provided, automatically set title from appointment
    IF NEW.appointment_id IS NOT NULL THEN
        -- Get encryption key from environment (must match ENCRYPTION_KEY)
        encryption_key := current_setting('app.encryption_key', true);

        -- Fallback to default key if not set (should match backend ENCRYPTION_KEY)
        IF encryption_key IS NULL OR encryption_key = '' THEN
            encryption_key := 'your-encryption-key-here';
        END IF;

        -- Get patient name from the appointment (decrypt the encrypted fields)
        SELECT CONCAT(
            pgp_sym_decrypt(p.name, encryption_key),
            ' ',
            pgp_sym_decrypt(p.family_name, encryption_key)
        )
        INTO patient_full_name
        FROM appointments a
        JOIN patients p ON p.id = a.patient_id
        WHERE a.id = NEW.appointment_id;

        -- Set title to patient name and clear note
        NEW.title := COALESCE(patient_full_name, 'Appointment');
        NEW.note := NULL;

        -- Also sync date, time, duration, and color from appointment
        SELECT a.date, a.time, a.duration, a.color
        INTO NEW.date, NEW.time, NEW.duration, NEW.color
        FROM appointments a
        WHERE a.id = NEW.appointment_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to set title from appointment before insert or update
CREATE TRIGGER set_calendar_title_from_appointment_trigger
    BEFORE INSERT OR UPDATE ON calendar
    FOR EACH ROW
    EXECUTE FUNCTION set_calendar_title_from_appointment();

-- Add comments for documentation
COMMENT ON TABLE calendar IS 'Calendar events table - can be linked to appointments or standalone events';
COMMENT ON COLUMN calendar.id IS 'Primary key (UUID)';
COMMENT ON COLUMN calendar.doctor_user_id IS 'Foreign key to doctors(user_id)';
COMMENT ON COLUMN calendar.appointment_id IS 'Foreign key to appointments(id) - NULL for standalone events';
COMMENT ON COLUMN calendar.title IS 'Event title - auto-set from appointment if appointment_id is provided';
COMMENT ON COLUMN calendar.note IS 'Event notes - NULL when linked to appointment, can be custom for standalone events';
COMMENT ON COLUMN calendar.date IS 'Event date';
COMMENT ON COLUMN calendar.time IS 'Event time';
COMMENT ON COLUMN calendar.duration IS 'Event duration in minutes';
COMMENT ON COLUMN calendar.color IS 'Event color for calendar display';
COMMENT ON COLUMN calendar.created_at IS 'Event creation timestamp';
COMMENT ON COLUMN calendar.updated_at IS 'Last update timestamp';
