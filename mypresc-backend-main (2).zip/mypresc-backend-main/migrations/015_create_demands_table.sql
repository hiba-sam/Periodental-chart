-- Migration: Create demands table
-- Created: 2025-11-02

-- Enable pgcrypto extension for encryption (if not already enabled)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS demands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    -- ALL DEMAND DATA IS ENCRYPTED (BYTEA)
    -- Personal information
    first_name BYTEA NOT NULL, -- Encrypted first name
    last_name BYTEA NOT NULL, -- Encrypted last name
    email BYTEA NOT NULL, -- Encrypted email
    phone BYTEA NOT NULL, -- Encrypted phone number
    specialty BYTEA NOT NULL, -- Encrypted specialty

    -- Blind indexes for searchable encrypted fields (SHA256 hashes)
    email_blind_index TEXT NOT NULL, -- Blind index for searchable email
    phone_blind_index TEXT NOT NULL, -- Blind index for searchable phone

    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_demands_created_at ON demands(created_at);
CREATE INDEX IF NOT EXISTS idx_demands_email_blind_index ON demands(email_blind_index);
CREATE INDEX IF NOT EXISTS idx_demands_phone_blind_index ON demands(phone_blind_index);

-- Create trigger to automatically update updated_at
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'update_demands_updated_at'
    ) THEN
CREATE TRIGGER update_demands_updated_at
    BEFORE UPDATE ON demands
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
    END IF;
END
$$;

-- Add comments for documentation
COMMENT ON TABLE demands IS 'Doctor registration demands table - ALL data fully encrypted';
COMMENT ON COLUMN demands.id IS 'Primary key (UUID)';
COMMENT ON COLUMN demands.first_name IS 'Encrypted doctor first name (BYTEA)';
COMMENT ON COLUMN demands.last_name IS 'Encrypted doctor last name (BYTEA)';
COMMENT ON COLUMN demands.email IS 'Encrypted doctor email address (BYTEA)';
COMMENT ON COLUMN demands.phone IS 'Encrypted doctor phone number (BYTEA)';
COMMENT ON COLUMN demands.specialty IS 'Encrypted doctor specialty (BYTEA)';
COMMENT ON COLUMN demands.email_blind_index IS 'Blind index (SHA256 hash) for searchable encrypted email';
COMMENT ON COLUMN demands.phone_blind_index IS 'Blind index (SHA256 hash) for searchable encrypted phone';
COMMENT ON COLUMN demands.created_at IS 'Demand record creation timestamp';
COMMENT ON COLUMN demands.updated_at IS 'Last update timestamp';
