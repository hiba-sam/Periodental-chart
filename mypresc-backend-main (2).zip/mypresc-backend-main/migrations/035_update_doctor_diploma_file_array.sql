-- Migration: Update doctors diploma_file to array
-- Created: 2025-12-29

-- Alter the column type to TEXT[] converting existing values to single-element arrays
ALTER TABLE doctors 
ALTER COLUMN diploma_file TYPE TEXT[] 
USING CASE 
    WHEN diploma_file IS NULL THEN NULL 
    ELSE ARRAY[diploma_file] 
END;

COMMENT ON COLUMN doctors.diploma_file IS 'Doctor diploma files (array)';
