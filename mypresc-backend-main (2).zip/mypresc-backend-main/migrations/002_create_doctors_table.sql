-- Migration: Create doctors table
-- Created: 2024-01-01 00:00:00

CREATE TABLE IF NOT EXISTS doctors (
    user_id INT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    birth_date DATE NOT NULL,
    birth_place VARCHAR(200) NOT NULL,
    work_location VARCHAR(200) NOT NULL,
    home_location VARCHAR(200) NOT NULL,
    diploma_file VARCHAR(255),
    certificates TEXT[],
    order_num VARCHAR(255) NOT NULL,
    order_num_file VARCHAR(255) ,
    id_card_file VARCHAR(255) ,
    phone_number VARCHAR(255) NOT NULL,
    work_time JSONB,
    languages TEXT[],
    about TEXT,
    speciality VARCHAR(255),
    experience INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_doctors_user_id ON doctors(user_id);
CREATE INDEX IF NOT EXISTS idx_doctors_birth_date ON doctors(birth_date);
CREATE INDEX IF NOT EXISTS idx_doctors_order_num ON doctors(order_num);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_doctors_updated_at 
    BEFORE UPDATE ON doctors 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE doctors IS 'Doctor profile information table';
COMMENT ON COLUMN doctors.user_id IS 'Foreign key to users table';
COMMENT ON COLUMN doctors.birth_date IS 'Doctor birth date';
COMMENT ON COLUMN doctors.birth_place IS 'Doctor birth place';
COMMENT ON COLUMN doctors.work_location IS 'Doctor work location';
COMMENT ON COLUMN doctors.home_location IS 'Doctor home location';
COMMENT ON COLUMN doctors.certificates IS 'Doctor certificates';
COMMENT ON COLUMN doctors.order_num IS 'Doctor order number';
COMMENT ON COLUMN doctors.order_num_file IS 'Doctor order number file';
COMMENT ON COLUMN doctors.id_card_file IS 'Doctor ID card file';
COMMENT ON COLUMN doctors.phone_number IS 'Doctor phone number';
COMMENT ON COLUMN doctors.work_time IS 'Doctor work time';
COMMENT ON COLUMN doctors.languages IS 'Doctor languages';
COMMENT ON COLUMN doctors.about IS 'Doctor about';
COMMENT ON COLUMN doctors.speciality IS 'Doctor speciality';
COMMENT ON COLUMN doctors.experience IS 'Doctor experience';
COMMENT ON COLUMN doctors.created_at IS 'Record creation timestamp';
COMMENT ON COLUMN doctors.updated_at IS 'Last update timestamp'; 