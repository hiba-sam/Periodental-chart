-- Migration 040: Add ATC (Anatomical Therapeutic Chemical) classification code
-- to medications and custom_medications tables for drug classification and comparison.
-- ATC codes follow the WHO standard: https://www.whocc.no/atc/structure_and_principles/
-- Level 1: C = Cardiovascular, A = Alimentary, B = Blood, etc.
-- Level 4 (first 5 chars): therapeutic subgroup (e.g., C09AA = ACE inhibitors plain)

-- 1. Add atc_code column to medications
ALTER TABLE medications ADD COLUMN IF NOT EXISTS atc_code VARCHAR(10);

-- 2. Add atc_code column to custom_medications
ALTER TABLE custom_medications ADD COLUMN IF NOT EXISTS atc_code VARCHAR(10);

-- 3. Create index for fast filtering by ATC class
CREATE INDEX IF NOT EXISTS idx_medications_atc_code ON medications(atc_code);
CREATE INDEX IF NOT EXISTS idx_custom_medications_atc_code ON custom_medications(atc_code);

-- 4. Populate ATC codes for known DCI values
-- Cardiovascular (C)
UPDATE medications SET atc_code = 'C09AA04' WHERE UPPER(denomination_commune_internationale) LIKE '%PERINDOPRIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09AA05' WHERE UPPER(denomination_commune_internationale) LIKE '%RAMIPRIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09AA02' WHERE UPPER(denomination_commune_internationale) LIKE '%ENALAPRIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09AA03' WHERE UPPER(denomination_commune_internationale) LIKE '%LISINOPRIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09AA01' WHERE UPPER(denomination_commune_internationale) LIKE '%CAPTOPRIL%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C09CA01' WHERE UPPER(denomination_commune_internationale) LIKE '%LOSARTAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09CA03' WHERE UPPER(denomination_commune_internationale) LIKE '%VALSARTAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09CA04' WHERE UPPER(denomination_commune_internationale) LIKE '%IRBESARTAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09CA06' WHERE UPPER(denomination_commune_internationale) LIKE '%CANDESARTAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09CA07' WHERE UPPER(denomination_commune_internationale) LIKE '%TELMISARTAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C09CA08' WHERE UPPER(denomination_commune_internationale) LIKE '%OLMESARTAN%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C08CA01' WHERE UPPER(denomination_commune_internationale) LIKE '%AMLODIPINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08CA02' WHERE UPPER(denomination_commune_internationale) LIKE '%FELODIPINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08CA05' WHERE UPPER(denomination_commune_internationale) LIKE '%NIFEDIPINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08DA01' WHERE UPPER(denomination_commune_internationale) LIKE '%VERAPAMIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08DB01' WHERE UPPER(denomination_commune_internationale) LIKE '%DILTIAZEM%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08CA13' WHERE UPPER(denomination_commune_internationale) LIKE '%LERCANIDIPINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C08CA06' WHERE UPPER(denomination_commune_internationale) LIKE '%NIMODIPINE%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C07AB07' WHERE UPPER(denomination_commune_internationale) LIKE '%BISOPROLOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C07AB02' WHERE UPPER(denomination_commune_internationale) LIKE '%METOPROLOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C07AB03' WHERE UPPER(denomination_commune_internationale) LIKE '%ATENOLOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C07AG02' WHERE UPPER(denomination_commune_internationale) LIKE '%CARVEDILOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C07AA05' WHERE UPPER(denomination_commune_internationale) LIKE '%PROPRANOLOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C07AB12' WHERE UPPER(denomination_commune_internationale) LIKE '%NEBIVOLOL%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C03CA01' WHERE UPPER(denomination_commune_internationale) LIKE '%FUROSEMIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C03AA03' WHERE UPPER(denomination_commune_internationale) LIKE '%HYDROCHLOROTHIAZIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C03BA11' WHERE UPPER(denomination_commune_internationale) LIKE '%INDAPAMIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C03DA01' WHERE UPPER(denomination_commune_internationale) LIKE '%SPIRONOLACTONE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C03DA04' WHERE UPPER(denomination_commune_internationale) LIKE '%EPLERENONE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C03CA02' WHERE UPPER(denomination_commune_internationale) LIKE '%BUMETANIDE%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C10AA05' WHERE UPPER(denomination_commune_internationale) LIKE '%ATORVASTATINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AA01' WHERE UPPER(denomination_commune_internationale) LIKE '%SIMVASTATINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AA07' WHERE UPPER(denomination_commune_internationale) LIKE '%ROSUVASTATINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AA04' WHERE UPPER(denomination_commune_internationale) LIKE '%FLUVASTATINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AA03' WHERE UPPER(denomination_commune_internationale) LIKE '%PRAVASTATINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AX09' WHERE UPPER(denomination_commune_internationale) LIKE '%EZETIMIBE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C10AB05' WHERE UPPER(denomination_commune_internationale) LIKE '%FENOFIBRATE%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C01AA05' WHERE UPPER(denomination_commune_internationale) LIKE '%DIGOXINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01BD01' WHERE UPPER(denomination_commune_internationale) LIKE '%AMIODARONE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01BD07' WHERE UPPER(denomination_commune_internationale) LIKE '%DRONEDARONE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01EB17' WHERE UPPER(denomination_commune_internationale) LIKE '%IVABRADINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01DA02' WHERE UPPER(denomination_commune_internationale) LIKE '%TRINITRINE%' OR UPPER(denomination_commune_internationale) LIKE '%GLYCERYL TRINITRATE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01DA08' WHERE UPPER(denomination_commune_internationale) LIKE '%ISOSORBIDE DINITRATE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01DA14' WHERE UPPER(denomination_commune_internationale) LIKE '%ISOSORBIDE MONONITRATE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01DX16' WHERE UPPER(denomination_commune_internationale) LIKE '%NICORANDIL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01EB15' WHERE UPPER(denomination_commune_internationale) LIKE '%TRIMETAZIDINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C01EB16' WHERE UPPER(denomination_commune_internationale) LIKE '%RANOLAZINE%' AND atc_code IS NULL;

UPDATE medications SET atc_code = 'C02AC01' WHERE UPPER(denomination_commune_internationale) LIKE '%CLONIDINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C02CA04' WHERE UPPER(denomination_commune_internationale) LIKE '%DOXAZOSINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C02DB02' WHERE UPPER(denomination_commune_internationale) LIKE '%HYDRALAZINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C02AC05' WHERE UPPER(denomination_commune_internationale) LIKE '%MOXONIDINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'C02AC06' WHERE UPPER(denomination_commune_internationale) LIKE '%RILMENIDINE%' AND atc_code IS NULL;

-- Antithrombotic agents (B01) - commonly used in cardiology
UPDATE medications SET atc_code = 'B01AC06' WHERE UPPER(denomination_commune_internationale) LIKE '%ACETYLSALICYLIQUE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AC04' WHERE UPPER(denomination_commune_internationale) LIKE '%CLOPIDOGREL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AC24' WHERE UPPER(denomination_commune_internationale) LIKE '%TICAGRELOR%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AC22' WHERE UPPER(denomination_commune_internationale) LIKE '%PRASUGREL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AF01' WHERE UPPER(denomination_commune_internationale) LIKE '%RIVAROXABAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AF02' WHERE UPPER(denomination_commune_internationale) LIKE '%APIXABAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AF03' WHERE UPPER(denomination_commune_internationale) LIKE '%EDOXABAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AE07' WHERE UPPER(denomination_commune_internationale) LIKE '%DABIGATRAN%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AA03' WHERE UPPER(denomination_commune_internationale) LIKE '%WARFARINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AA07' WHERE UPPER(denomination_commune_internationale) LIKE '%ACENOCOUMAROL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AB05' WHERE UPPER(denomination_commune_internationale) LIKE '%ENOXAPARINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'B01AB01' WHERE UPPER(denomination_commune_internationale) LIKE '%HEPARINE%' AND atc_code IS NULL;

-- Common non-cardiovascular medications for context
UPDATE medications SET atc_code = 'A10BA02' WHERE UPPER(denomination_commune_internationale) LIKE '%METFORMINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A10BB09' WHERE UPPER(denomination_commune_internationale) LIKE '%GLICLAZIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A10BK01' WHERE UPPER(denomination_commune_internationale) LIKE '%DAPAGLIFLOZINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A10BK02' WHERE UPPER(denomination_commune_internationale) LIKE '%EMPAGLIFLOZINE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A10BJ02' WHERE UPPER(denomination_commune_internationale) LIKE '%LIRAGLUTIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A10BJ06' WHERE UPPER(denomination_commune_internationale) LIKE '%SEMAGLUTIDE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'N02BE01' WHERE UPPER(denomination_commune_internationale) LIKE '%PARACETAMOL%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'M01AE01' WHERE UPPER(denomination_commune_internationale) LIKE '%IBUPROFENE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A02BC01' WHERE UPPER(denomination_commune_internationale) LIKE '%OMEPRAZOLE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A02BC02' WHERE UPPER(denomination_commune_internationale) LIKE '%PANTOPRAZOLE%' AND atc_code IS NULL;
UPDATE medications SET atc_code = 'A02BC05' WHERE UPPER(denomination_commune_internationale) LIKE '%ESOMEPRAZOLE%' AND atc_code IS NULL;
