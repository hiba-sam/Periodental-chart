-- Migration: Add share token for secure unique links
-- Date: 2024-12-29
-- Description: Adds a unique token for secure, non-shareable links to medical shares

-- Add share_token column
ALTER TABLE medical_shares
ADD COLUMN IF NOT EXISTS share_token VARCHAR(64) UNIQUE;

-- Generate tokens for existing shares
UPDATE medical_shares 
SET share_token = encode(gen_random_bytes(32), 'hex')
WHERE share_token IS NULL;

-- Make share_token NOT NULL for future inserts
ALTER TABLE medical_shares
ALTER COLUMN share_token SET NOT NULL;

-- Add default for new rows
ALTER TABLE medical_shares
ALTER COLUMN share_token SET DEFAULT encode(gen_random_bytes(32), 'hex');

-- Create index for fast token lookups
CREATE INDEX IF NOT EXISTS idx_medical_shares_token ON medical_shares(share_token);

-- Add comments
COMMENT ON COLUMN medical_shares.share_token IS 'Unique token for secure share links - non-shareable, one-time access';
