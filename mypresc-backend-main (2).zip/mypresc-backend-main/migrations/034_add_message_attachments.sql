-- Migration: Add attachment support to messages table
-- Date: 2024-12-29
-- Description: Adds columns to store file attachments (images and PDFs) in messages

-- Add attachment columns to messages table
ALTER TABLE messages
ADD COLUMN IF NOT EXISTS attachment_url VARCHAR(500),
ADD COLUMN IF NOT EXISTS attachment_type VARCHAR(10) CHECK (attachment_type IN ('image', 'pdf')),
ADD COLUMN IF NOT EXISTS attachment_name VARCHAR(255);

-- Create index for faster queries on messages with attachments
CREATE INDEX IF NOT EXISTS idx_messages_attachment_url ON messages(attachment_url) WHERE attachment_url IS NOT NULL;

-- Add comment for documentation
COMMENT ON COLUMN messages.attachment_url IS 'URL path to the attached file (image or PDF)';
COMMENT ON COLUMN messages.attachment_type IS 'Type of attachment: image or pdf';
COMMENT ON COLUMN messages.attachment_name IS 'Original filename of the attachment';
