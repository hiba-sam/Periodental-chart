-- ============================================
-- MIGRATION 049: Patient Performance Indexes
-- Phase 2 of patient endpoint performance fix
-- Target: GET /patient 15s → <500ms
-- ============================================

-- INDEX 1: patients.created_by_doctor_id
-- Fixes the 6th UNION branch: "p3.created_by_doctor_id = $3"
-- This was doing a full sequential scan on all 10k patients.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_patients_created_by_doctor
    ON patients(created_by_doctor_id)
    WHERE created_by_doctor_id IS NOT NULL;

-- INDEX 2: medical_shares — covering index for all 3 access conditions
-- Fixes the 5th UNION branch AND the is_shared_with_me EXISTS subquery.
-- Both use: patient_id + shared_with_doctor_id + status='active' + expires_at > NOW()
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_medical_shares_access
    ON medical_shares(patient_id, shared_with_doctor_id, expires_at)
    WHERE status = 'active';

-- INDEX 3: doctor_patient_privacy — covers the 7th UNION branch
-- Fixes: "dpp.patient_id = p.id AND dpp.doctor_id = $3"
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_doctor_patient_privacy_lookup
    ON doctor_patient_privacy(patient_id, doctor_id);

-- INDEX 4: Composite (created_at DESC, id DESC) for stable ORDER BY + pagination
-- Allows PostgreSQL to scan in sorted order, enabling early termination with LIMIT.
-- Works together with DISTINCT ON (p.created_at, p.id).
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_patients_created_at_id_desc
    ON patients(created_at DESC, id DESC);

-- INDEX 5: prescriptions — reverse direction (doctor → patient)
-- The existing idx_prescriptions_patient_doctor covers (patient_id, doctor_user_id).
-- This adds the reverse for the subquery: "WHERE doctor_user_id = $3 AND patient_id = p.id"
-- PostgreSQL can use this to quickly find which patients a doctor has prescribed to.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_prescriptions_doctor_patient
    ON prescriptions(doctor_user_id, patient_id);

-- INDEX 6: appointments — doctor + done + patient (reverse of existing index)
-- Existing: idx_appointments_patient_doctor_done ON (patient_id, doctor_user_id, is_done)
-- Adding reverse for: "WHERE doctor_user_id = $3 AND is_done = true AND patient_id = p.id"
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_appointments_doctor_done_patient
    ON appointments(doctor_user_id, patient_id)
    WHERE is_done = true;

-- ============================================
-- VERIFICATION AFTER RUNNING:
-- Run EXPLAIN (ANALYZE, BUFFERS) on the findAllByDoctorConsultations query.
-- All EXISTS branches should show "Index Scan" not "Seq Scan".
-- ORDER BY should use idx_patients_created_at_id_desc.
--
-- Expected improvement: 15s → 300-500ms
-- ============================================

-- ROLLBACK:
-- DROP INDEX CONCURRENTLY IF EXISTS idx_patients_created_by_doctor;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_medical_shares_access;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_doctor_patient_privacy_lookup;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_patients_created_at_id_desc;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_prescriptions_doctor_patient;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_appointments_doctor_done_patient;
