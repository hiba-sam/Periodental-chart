-- ============================================
-- MIGRATION: 025_encrypt_medical_reports
-- Priority: P0 (CRITICAL - Loi 18-07 Art. 15)
-- Strategy: Expand-Contract (Zero-Downtime)
-- Description: Chiffrement des colonnes title et content de medical_reports
-- ============================================

-- PHASE 1: EXPAND - Ajouter nouvelles colonnes chiffrées
ALTER TABLE medical_reports 
ADD COLUMN IF NOT EXISTS title_encrypted BYTEA,
ADD COLUMN IF NOT EXISTS content_encrypted BYTEA;

-- Ajouter commentaires
COMMENT ON COLUMN medical_reports.title_encrypted IS 'Titre chiffré AES-256 via pgp_sym_encrypt - Loi 18-07';
COMMENT ON COLUMN medical_reports.content_encrypted IS 'Contenu médical chiffré AES-256 via pgp_sym_encrypt - Loi 18-07';

-- PHASE 2: INDEX pour performance sur nouvelles colonnes
-- (Pas d'index sur colonnes chiffrées - pas searchable)

-- PHASE 3: Fonction de migration des données existantes
-- À exécuter manuellement avec la clé de chiffrement
CREATE OR REPLACE FUNCTION migrate_medical_reports_encryption(encryption_key TEXT)
RETURNS TABLE(migrated_count INT, error_count INT) AS $$
DECLARE
    batch_size INT := 500;
    total_migrated INT := 0;
    total_errors INT := 0;
    batch_migrated INT;
BEGIN
    -- Vérifier que la clé est fournie
    IF encryption_key IS NULL OR encryption_key = '' THEN
        RAISE EXCEPTION 'Encryption key is required';
    END IF;

    -- Migrer par batch pour éviter lock long
    LOOP
        WITH batch AS (
            SELECT id, title, content
            FROM medical_reports
            WHERE title_encrypted IS NULL
            LIMIT batch_size
            FOR UPDATE SKIP LOCKED
        )
        UPDATE medical_reports mr
        SET 
            title_encrypted = pgp_sym_encrypt(COALESCE(b.title, ''), encryption_key),
            content_encrypted = pgp_sym_encrypt(COALESCE(b.content, ''), encryption_key)
        FROM batch b
        WHERE mr.id = b.id;
        
        GET DIAGNOSTICS batch_migrated = ROW_COUNT;
        total_migrated := total_migrated + batch_migrated;
        
        EXIT WHEN batch_migrated = 0;
        
        -- Rate limiting pour ne pas surcharger la DB
        PERFORM pg_sleep(0.05);
    END LOOP;

    RETURN QUERY SELECT total_migrated, total_errors;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION migrate_medical_reports_encryption IS 
'Migre les données existantes vers colonnes chiffrées. Usage: SELECT * FROM migrate_medical_reports_encryption(''your-key'')';

-- PHASE 4: Fonction de vérification migration
CREATE OR REPLACE FUNCTION verify_medical_reports_encryption()
RETURNS TABLE(
    total_records BIGINT,
    encrypted_records BIGINT,
    pending_records BIGINT,
    migration_complete BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*)::BIGINT as total_records,
        COUNT(title_encrypted)::BIGINT as encrypted_records,
        (COUNT(*) - COUNT(title_encrypted))::BIGINT as pending_records,
        (COUNT(*) = COUNT(title_encrypted)) as migration_complete
    FROM medical_reports;
END;
$$ LANGUAGE plpgsql;

-- PHASE 5: Fonction de décryptage pour requêtes
CREATE OR REPLACE FUNCTION decrypt_medical_report(
    p_id INT,
    p_key TEXT
) RETURNS TABLE(
    id INT,
    patient_id UUID,
    doctor_user_id INT,
    title TEXT,
    content TEXT,
    examination_date DATE,
    consultation_id INT,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        mr.id,
        mr.patient_id,
        mr.doctor_user_id,
        CASE 
            WHEN mr.title_encrypted IS NOT NULL 
            THEN pgp_sym_decrypt(mr.title_encrypted, p_key)
            ELSE mr.title
        END as title,
        CASE 
            WHEN mr.content_encrypted IS NOT NULL 
            THEN pgp_sym_decrypt(mr.content_encrypted, p_key)
            ELSE mr.content
        END as content,
        mr.examination_date,
        mr.consultation_id,
        mr.created_at,
        mr.updated_at
    FROM medical_reports mr
    WHERE mr.id = p_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- INSTRUCTIONS POST-MIGRATION
-- ============================================
-- 1. Exécuter la migration des données:
--    SELECT * FROM migrate_medical_reports_encryption('VOTRE_ENCRYPTION_KEY');
--
-- 2. Vérifier que la migration est complète:
--    SELECT * FROM verify_medical_reports_encryption();
--
-- 3. Une fois le code TypeScript déployé et vérifié:
--    Exécuter 026_finalize_medical_reports_encryption.sql
-- ============================================

-- ROLLBACK SCRIPT (ne pas exécuter en production sans validation)
-- ALTER TABLE medical_reports DROP COLUMN IF EXISTS title_encrypted;
-- ALTER TABLE medical_reports DROP COLUMN IF EXISTS content_encrypted;
-- DROP FUNCTION IF EXISTS migrate_medical_reports_encryption;
-- DROP FUNCTION IF EXISTS verify_medical_reports_encryption;
-- DROP FUNCTION IF EXISTS decrypt_medical_report;
