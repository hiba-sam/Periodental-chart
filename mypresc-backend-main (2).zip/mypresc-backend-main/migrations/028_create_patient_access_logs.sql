-- ============================================
-- MIGRATION: 028_create_patient_access_logs
-- Priority: P1 (HIGH - Loi 25-11 Traçabilité)
-- Description: Table d'audit des accès aux données patients
-- ============================================

-- PHASE 1: Créer la table
CREATE TABLE IF NOT EXISTS patient_access_logs (
    id SERIAL PRIMARY KEY,
    
    -- Qui a accédé
    user_id INT NOT NULL,
    user_role VARCHAR(50) NOT NULL, -- doctor, assistant, admin
    
    -- À quoi
    patient_id UUID NOT NULL,
    
    -- Type d'action
    action VARCHAR(50) NOT NULL CHECK (action IN (
        'VIEW',           -- Consultation du dossier
        'VIEW_LIST',      -- Liste des patients
        'SEARCH',         -- Recherche patient
        'CREATE',         -- Création dossier
        'UPDATE',         -- Modification
        'DELETE',         -- Suppression
        'EXPORT',         -- Export données
        'PRINT',          -- Impression
        'SHARE'           -- Partage avec autre médecin
    )),
    
    -- Détails
    accessed_fields TEXT[],           -- Champs consultés ['name', 'allergies', etc.]
    query_params JSONB,               -- Paramètres de recherche (anonymisés)
    
    -- Contexte technique
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    request_id UUID,                  -- Pour corrélation avec logs applicatifs
    
    -- Résultat
    success BOOLEAN DEFAULT true,
    error_message TEXT,
    
    -- Timestamp
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- PHASE 2: Index pour requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_patient_id ON patient_access_logs(patient_id);
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_user_id ON patient_access_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_action ON patient_access_logs(action);
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_created_at ON patient_access_logs(created_at DESC);

-- Index composite pour audit par patient + période
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_patient_date 
ON patient_access_logs(patient_id, created_at DESC);

-- Index pour recherche par session
CREATE INDEX IF NOT EXISTS idx_patient_access_logs_session 
ON patient_access_logs(session_id) 
WHERE session_id IS NOT NULL;

-- PHASE 3: Partitionnement par mois (optionnel, pour gros volumes)
-- À activer si > 1M lignes/mois
-- CREATE TABLE patient_access_logs_partitioned (
--     LIKE patient_access_logs INCLUDING ALL
-- ) PARTITION BY RANGE (created_at);

-- PHASE 4: Politique de rétention (fonction de nettoyage)
CREATE OR REPLACE FUNCTION cleanup_old_patient_access_logs(retention_days INT DEFAULT 365)
RETURNS INT AS $$
DECLARE
    deleted_count INT;
BEGIN
    DELETE FROM patient_access_logs
    WHERE created_at < NOW() - (retention_days || ' days')::INTERVAL;
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    RAISE NOTICE 'Supprimé % logs de plus de % jours', deleted_count, retention_days;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_old_patient_access_logs IS 
'Nettoie les logs d''accès plus anciens que retention_days. Défaut: 365 jours (Loi 25-11)';

-- PHASE 5: Vue pour rapports d'audit
CREATE OR REPLACE VIEW v_patient_access_summary AS
SELECT 
    DATE(created_at) as access_date,
    user_role,
    action,
    COUNT(*) as access_count,
    COUNT(DISTINCT user_id) as unique_users,
    COUNT(DISTINCT patient_id) as unique_patients
FROM patient_access_logs
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY DATE(created_at), user_role, action
ORDER BY access_date DESC, access_count DESC;

-- Vue pour accès suspects (volume anormal)
CREATE OR REPLACE VIEW v_suspicious_patient_access AS
SELECT 
    user_id,
    user_role,
    DATE(created_at) as access_date,
    COUNT(*) as total_accesses,
    COUNT(DISTINCT patient_id) as unique_patients,
    ARRAY_AGG(DISTINCT action) as actions
FROM patient_access_logs
WHERE created_at >= NOW() - INTERVAL '24 hours'
GROUP BY user_id, user_role, DATE(created_at)
HAVING COUNT(*) > 100  -- Seuil à ajuster selon usage normal
   OR COUNT(DISTINCT patient_id) > 50
ORDER BY total_accesses DESC;

-- PHASE 6: Fonction helper pour logger facilement
CREATE OR REPLACE FUNCTION log_patient_access(
    p_user_id INT,
    p_user_role VARCHAR(50),
    p_patient_id UUID,
    p_action VARCHAR(50),
    p_accessed_fields TEXT[] DEFAULT NULL,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL,
    p_session_id VARCHAR(255) DEFAULT NULL,
    p_request_id UUID DEFAULT NULL,
    p_success BOOLEAN DEFAULT true,
    p_error_message TEXT DEFAULT NULL
) RETURNS INT AS $$
DECLARE
    log_id INT;
BEGIN
    INSERT INTO patient_access_logs (
        user_id, user_role, patient_id, action,
        accessed_fields, ip_address, user_agent,
        session_id, request_id, success, error_message
    ) VALUES (
        p_user_id, p_user_role, p_patient_id, p_action,
        p_accessed_fields, p_ip_address, p_user_agent,
        p_session_id, p_request_id, p_success, p_error_message
    )
    RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION log_patient_access IS 
'Helper pour logger un accès patient. Utiliser depuis le code applicatif.';

-- PHASE 7: Commentaires table
COMMENT ON TABLE patient_access_logs IS 
'Audit trail des accès aux données patients - Conformité Loi 25-11 Algérie';
COMMENT ON COLUMN patient_access_logs.user_id IS 'ID de l''utilisateur ayant accédé';
COMMENT ON COLUMN patient_access_logs.patient_id IS 'ID du patient concerné';
COMMENT ON COLUMN patient_access_logs.action IS 'Type d''action effectuée';
COMMENT ON COLUMN patient_access_logs.accessed_fields IS 'Liste des champs consultés (pour audit granulaire)';

-- ============================================
-- ROLLBACK SCRIPT
-- ============================================
-- DROP VIEW IF EXISTS v_suspicious_patient_access;
-- DROP VIEW IF EXISTS v_patient_access_summary;
-- DROP FUNCTION IF EXISTS log_patient_access;
-- DROP FUNCTION IF EXISTS cleanup_old_patient_access_logs;
-- DROP TABLE IF EXISTS patient_access_logs;
