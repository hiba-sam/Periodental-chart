-- Migration: Add created_by_doctor_id column to patients table
-- This column tracks which doctor created the patient (without forcing them to be médecin traitant)
-- Used for determining patient ownership for access control popups

-- Add the column
ALTER TABLE patients ADD COLUMN IF NOT EXISTS created_by_doctor_id INTEGER REFERENCES users(id) ON DELETE SET NULL;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_patients_created_by_doctor_id ON patients(created_by_doctor_id);

-- Backfill existing data: 
-- For patients created by assistants, use the assistant's doctor_id
-- For patients with medecin_traitant_id set, use that as the creator
UPDATE patients p
SET created_by_doctor_id = COALESCE(
    (SELECT a.doctor_id FROM assistants a WHERE a.user_id = p.assistant_id),
    p.medecin_traitant_id
)
WHERE p.created_by_doctor_id IS NULL;

-- Add comment for documentation
COMMENT ON COLUMN patients.created_by_doctor_id IS 'ID of the doctor who created this patient (directly or via assistant). Used for ownership checks without forcing médecin traitant role.';
