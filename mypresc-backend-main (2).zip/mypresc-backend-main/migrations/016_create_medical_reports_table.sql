-- Migration: Create medical_reports table
-- Description: Table pour stocker les comptes rendus médicaux des patients

CREATE TABLE IF NOT EXISTS medical_reports (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    examination_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_medical_reports_patient_id ON medical_reports(patient_id);
CREATE INDEX IF NOT EXISTS idx_medical_reports_doctor_user_id ON medical_reports(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_medical_reports_examination_date ON medical_reports(examination_date DESC);
CREATE INDEX IF NOT EXISTS idx_medical_reports_created_at ON medical_reports(created_at DESC);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_medical_reports_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_trigger WHERE tgname = 'trigger_update_medical_reports_updated_at'
    ) THEN
        CREATE TRIGGER trigger_update_medical_reports_updated_at
            BEFORE UPDATE ON medical_reports
            FOR EACH ROW
            EXECUTE FUNCTION update_medical_reports_updated_at();
    END IF;
END
$$;

-- Add comment to table
COMMENT ON TABLE medical_reports IS 'Comptes rendus médicaux créés par les médecins pour leurs patients';
COMMENT ON COLUMN medical_reports.title IS 'Titre du compte rendu (ex: Consultation du 22/11/2024)';
COMMENT ON COLUMN medical_reports.content IS 'Contenu détaillé du compte rendu médical';
COMMENT ON COLUMN medical_reports.examination_date IS 'Date de l''examen ou de la consultation';
