-- Migration: Create tarifications table
-- Created: 2025-01-21 00:00:00

CREATE TABLE IF NOT EXISTS tarifications (
    id SERIAL PRIMARY KEY,
    doctor_user_id INT NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
    service_label VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tarifications_doctor_user_id ON tarifications(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_tarifications_service_label ON tarifications(service_label);
CREATE INDEX IF NOT EXISTS idx_tarifications_created_at ON tarifications(created_at);

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_tarifications_updated_at
    BEFORE UPDATE ON tarifications
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE tarifications IS 'Doctor pricing/tarification table';
COMMENT ON COLUMN tarifications.id IS 'Primary key (auto-increment)';
COMMENT ON COLUMN tarifications.doctor_user_id IS 'Foreign key to doctors(user_id)';
COMMENT ON COLUMN tarifications.service_label IS 'Medical service description';
COMMENT ON COLUMN tarifications.price IS 'Service price in local currency (non-negative)';
COMMENT ON COLUMN tarifications.created_at IS 'Record creation timestamp';
COMMENT ON COLUMN tarifications.updated_at IS 'Last update timestamp';
