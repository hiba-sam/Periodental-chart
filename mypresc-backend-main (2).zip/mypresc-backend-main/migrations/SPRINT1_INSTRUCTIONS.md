# 🚀 SPRINT 1 - Instructions de Déploiement

## Vue d'ensemble

Ce sprint implémente les mesures de sécurité prioritaires pour la conformité Loi 18-07 / 25-11 Algérie.

### Migrations incluses

| # | Fichier | Priorité | Description |
|---|---------|----------|-------------|
| 025 | `025_encrypt_medical_reports.sql` | P0 | Chiffrement des rapports médicaux |
| 026 | `026_finalize_medical_reports_encryption.sql` | P0 | Finalisation (post-déploiement code) |
| 027 | `027_enable_rls_patients.sql` | P1 | Row-Level Security sur patients |
| 028 | `028_create_patient_access_logs.sql` | P1 | Audit trail accès patients |

---

## 📋 Ordre d'exécution

### Étape 1: Backup (OBLIGATOIRE)

```bash
# Backup complet de la base
pg_dump -h localhost -U postgres -d mypresc -F c -f backup_pre_sprint1_$(date +%Y%m%d).dump

# Backup spécifique medical_reports
pg_dump -h localhost -U postgres -d mypresc -t medical_reports -F c -f backup_medical_reports_$(date +%Y%m%d).dump
```

### Étape 2: Exécuter migrations 025, 027, 028

```bash
# Via psql
psql -h localhost -U postgres -d mypresc -f migrations/025_encrypt_medical_reports.sql
psql -h localhost -U postgres -d mypresc -f 027_enable_rls_patients.sql
psql -h localhost -U postgres -d mypresc -f migrations/028_create_patient_access_logs.sql
```

### Étape 3: Migrer les données existantes (025)

```sql
-- Définir la clé de chiffrement
SET app.encryption_key = 'VOTRE_ENCRYPTION_KEY';

-- Exécuter la migration
SELECT * FROM migrate_medical_reports_encryption('VOTRE_ENCRYPTION_KEY');

-- Vérifier
SELECT * FROM verify_medical_reports_encryption();
-- Doit retourner: migration_complete = true
```

### Étape 4: Déployer le code TypeScript

Le fichier `MedicalReportModel.ts` a été modifié pour:
- Chiffrer `title` et `content` à la création
- Déchiffrer automatiquement à la lecture
- Chiffrer les mises à jour

**Fichiers modifiés:**
- `backend/models/medicalReport.model.ts`

**Nouveaux fichiers:**
- `backend/utils/patientAccessLogger.ts`
- `backend/middlewares/rlsContext.middleware.ts`

### Étape 5: Intégrer le middleware RLS

Dans votre fichier de routes ou app principal:

```typescript
import { setRLSContext } from './middlewares/rlsContext.middleware';

// Après le middleware d'authentification
app.use(setRLSContext);
```

### Étape 6: Intégrer l'audit logger

Dans vos controllers patients:

```typescript
import { PatientAccessLogger, extractRequestContext } from '../utils/patientAccessLogger';

// Exemple dans un controller
async function getPatient(req, res) {
    const patient = await PatientModel.findById(req.params.id);
    
    // Logger l'accès
    await PatientAccessLogger.logView(
        req.user.id,
        req.user.role,
        req.params.id,
        ['name', 'family_name', 'allergies'], // champs accédés
        extractRequestContext(req)
    );
    
    res.json(patient);
}
```

### Étape 7: Tester en staging

```sql
-- Test chiffrement medical_reports
INSERT INTO medical_reports (patient_id, doctor_user_id, title, content, examination_date)
VALUES (
    'uuid-patient-test',
    1,
    pgp_sym_encrypt('Test Title', 'VOTRE_ENCRYPTION_KEY'),
    pgp_sym_encrypt('Test Content', 'VOTRE_ENCRYPTION_KEY'),
    CURRENT_DATE
);

-- Vérifier le chiffrement
SELECT 
    id,
    pgp_sym_decrypt(title, 'VOTRE_ENCRYPTION_KEY') as title_decrypted
FROM medical_reports
WHERE id = (SELECT MAX(id) FROM medical_reports);

-- Test RLS
SET app.current_user_id = '1';
SELECT COUNT(*) FROM patients; -- Devrait filtrer selon le médecin
RESET app.current_user_id;

-- Test audit logs
SELECT * FROM patient_access_logs ORDER BY created_at DESC LIMIT 10;
```

### Étape 8: Finaliser le chiffrement (après validation)

**⚠️ UNIQUEMENT après avoir validé que tout fonctionne:**

```bash
psql -h localhost -U postgres -d mypresc -f migrations/026_finalize_medical_reports_encryption.sql
```

---

## 🔄 Rollback

### Rollback complet

```bash
# Restaurer le backup
pg_restore -h localhost -U postgres -d mypresc -c backup_pre_sprint1_YYYYMMDD.dump
```

### Rollback migration 025 (avant finalisation)

```sql
ALTER TABLE medical_reports DROP COLUMN IF EXISTS title_encrypted;
ALTER TABLE medical_reports DROP COLUMN IF EXISTS content_encrypted;
DROP FUNCTION IF EXISTS migrate_medical_reports_encryption;
DROP FUNCTION IF EXISTS verify_medical_reports_encryption;
DROP FUNCTION IF EXISTS decrypt_medical_report;
```

### Rollback migration 027

```sql
DROP POLICY IF EXISTS patient_medecin_traitant_full_access ON patients;
DROP POLICY IF EXISTS patient_public_read_access ON patients;
DROP POLICY IF EXISTS patient_assistant_access ON patients;
DROP FUNCTION IF EXISTS set_current_user_id;
DROP INDEX IF EXISTS idx_patients_rls_optimization;
ALTER TABLE patients DISABLE ROW LEVEL SECURITY;
```

### Rollback migration 028

```sql
DROP VIEW IF EXISTS v_suspicious_patient_access;
DROP VIEW IF EXISTS v_patient_access_summary;
DROP FUNCTION IF EXISTS log_patient_access;
DROP FUNCTION IF EXISTS cleanup_old_patient_access_logs;
DROP TABLE IF EXISTS patient_access_logs;
```

---

## ✅ Checklist de validation

- [ ] Backup effectué
- [ ] Migration 025 exécutée
- [ ] Données migrées (verify_medical_reports_encryption = true)
- [ ] Migration 027 exécutée
- [ ] Migration 028 exécutée
- [ ] Code TypeScript déployé
- [ ] Middleware RLS intégré
- [ ] Tests en staging passés
- [ ] Migration 026 exécutée (finalisation)
- [ ] Tests en production passés

---

## 📞 Support

En cas de problème:
1. Vérifier les logs PostgreSQL
2. Vérifier que `ENCRYPTION_KEY` est défini dans `.env`
3. Vérifier les permissions de l'utilisateur DB

**Variables d'environnement requises:**
```env
ENCRYPTION_KEY=votre-cle-aes-256-securisee
```
