-- Migration: Add share_dental_acts to medical_shares
-- Description: Permet de partager les actes dentaires comme les prescriptions et comptes rendus

-- Add column for dental acts sharing
ALTER TABLE medical_shares 
ADD COLUMN IF NOT EXISTS share_dental_acts BOOLEAN DEFAULT true;

-- Comment
COMMENT ON COLUMN medical_shares.share_dental_acts IS 'Whether dental acts are included in the share';
