-- Migration 046: Create ophthalmology_reports table
-- Stores machine-imported refraction data from computerised phoropters / chart projectors
-- Supports TOPCON CV-5000 (JOIA standard v1.2); extendable to other vendors
-- Patient identity always resolved from our DB via route :patientId — NOT from XML

CREATE TABLE IF NOT EXISTS ophthalmology_reports (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- Machine metadata (from XML nsCommon:Common)
    machine_company     VARCHAR(100),           -- e.g. TOPCON
    machine_model       VARCHAR(100),           -- e.g. CV-5000
    machine_no          VARCHAR(100),           -- serial number
    machine_rom_version VARCHAR(50),
    schema_version      VARCHAR(20),            -- JOIA schema version e.g. 1.2
    exam_date           DATE NOT NULL,          -- date of exam from machine
    exam_time           TIME NOT NULL,          -- time of exam from machine
    exam_duration       VARCHAR(20),            -- HH:MM:SS
    xml_raw             TEXT,                   -- full original XML for audit

    -- Prescription (Type 1) — Far distance (~500 cm) — PRIMARY clinical data
    rx_far_right_sph    NUMERIC(5,2),           -- Diopters
    rx_far_right_cyl    NUMERIC(5,2),           -- Diopters (negative convention)
    rx_far_right_axis   INTEGER,                -- Degrees 0-180
    rx_far_right_h_pri  NUMERIC(5,2),           -- Horizontal prism (prism D)
    rx_far_right_v_pri  NUMERIC(5,2),           -- Vertical prism
    rx_far_left_sph     NUMERIC(5,2),
    rx_far_left_cyl     NUMERIC(5,2),
    rx_far_left_axis    INTEGER,
    rx_far_left_h_pri   NUMERIC(5,2),
    rx_far_left_v_pri   NUMERIC(5,2),
    rx_far_vd           NUMERIC(5,2),           -- Vertex distance (mm)
    rx_far_pd_r         NUMERIC(5,2),           -- PD right (mm)
    rx_far_pd_l         NUMERIC(5,2),           -- PD left (mm)
    rx_far_pd_b         NUMERIC(5,2),           -- PD binocular (mm)

    -- Prescription (Type 1) — Near distance (~67 cm)
    rx_near_right_sph   NUMERIC(5,2),
    rx_near_right_cyl   NUMERIC(5,2),
    rx_near_right_axis  INTEGER,
    rx_near_right_h_pri NUMERIC(5,2),
    rx_near_right_v_pri NUMERIC(5,2),
    rx_near_left_sph    NUMERIC(5,2),
    rx_near_left_cyl    NUMERIC(5,2),
    rx_near_left_axis   INTEGER,
    rx_near_left_h_pri  NUMERIC(5,2),
    rx_near_left_v_pri  NUMERIC(5,2),
    rx_near_vd          NUMERIC(5,2),
    rx_near_pd_r        NUMERIC(5,2),
    rx_near_pd_l        NUMERIC(5,2),
    rx_near_pd_b        NUMERIC(5,2),

    -- Doctor annotations (added after import)
    clinical_notes      TEXT,
    diagnosis           TEXT,

    -- Full measurement dump: all 3 types × 2 distances (for future use / reference)
    raw_measurements    JSONB,

    -- Audit
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_ophtho_reports_patient  ON ophthalmology_reports(patient_id);
CREATE INDEX IF NOT EXISTS idx_ophtho_reports_doctor   ON ophthalmology_reports(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_ophtho_reports_date     ON ophthalmology_reports(exam_date DESC);
CREATE INDEX IF NOT EXISTS idx_ophtho_reports_created  ON ophthalmology_reports(created_at DESC);

-- updated_at trigger
CREATE OR REPLACE FUNCTION update_ophthalmology_reports_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_ophtho_reports_updated_at ON ophthalmology_reports;
CREATE TRIGGER trigger_ophtho_reports_updated_at
    BEFORE UPDATE ON ophthalmology_reports
    FOR EACH ROW
    EXECUTE FUNCTION update_ophthalmology_reports_updated_at();

COMMENT ON TABLE ophthalmology_reports IS 'Machine-imported subjective refraction data from computerised phoropters (TOPCON CV-5000 and compatible JOIA-standard devices)';
COMMENT ON COLUMN ophthalmology_reports.rx_far_right_sph  IS 'Prescription far-distance OD sphere (Diopters)';
COMMENT ON COLUMN ophthalmology_reports.rx_near_right_sph IS 'Prescription near-distance OD sphere (Diopters) — ADD = near_sph - far_sph';
COMMENT ON COLUMN ophthalmology_reports.raw_measurements  IS 'Full JSONB dump of all 3 measurement types × 2 distances from the XML';
