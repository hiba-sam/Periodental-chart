-- ==============================================
-- MIGRATION: Create consultations table
-- Description: Track unique consultation sessions between doctor and patient
-- A consultation groups all activities (prescriptions, medical reports) done on the same day
-- ==============================================

-- Create consultations table
CREATE TABLE IF NOT EXISTS consultations (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    consultation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    
    -- Track what was done during consultation
    has_prescription BOOLEAN DEFAULT false,
    has_medical_report BOOLEAN DEFAULT false,
    appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
    
    -- Notes about the consultation
    notes TEXT,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Ensure one consultation per day per doctor-patient pair
    CONSTRAINT unique_consultation_per_day UNIQUE(patient_id, doctor_user_id, consultation_date)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_consultations_patient_id ON consultations(patient_id);
CREATE INDEX IF NOT EXISTS idx_consultations_doctor_user_id ON consultations(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_consultations_date ON consultations(consultation_date DESC);
CREATE INDEX IF NOT EXISTS idx_consultations_created_at ON consultations(created_at DESC);

-- Add comments
COMMENT ON TABLE consultations IS 'Track unique consultation sessions - one per day per doctor-patient pair';
COMMENT ON COLUMN consultations.patient_id IS 'Patient who was consulted';
COMMENT ON COLUMN consultations.doctor_user_id IS 'Doctor who performed the consultation';
COMMENT ON COLUMN consultations.consultation_date IS 'Date of consultation (used for grouping same-day activities)';
COMMENT ON COLUMN consultations.has_prescription IS 'Whether a prescription was created during this consultation';
COMMENT ON COLUMN consultations.has_medical_report IS 'Whether a medical report was created during this consultation';
COMMENT ON COLUMN consultations.appointment_id IS 'Optional link to appointment if consultation started from an appointment';
COMMENT ON COLUMN consultations.notes IS 'Additional notes about the consultation';

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_consultations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-update updated_at
-- Trigger to auto-update updated_at
DROP TRIGGER IF EXISTS trigger_consultations_updated_at ON consultations;
CREATE TRIGGER trigger_consultations_updated_at
    BEFORE UPDATE ON consultations
    FOR EACH ROW
    EXECUTE FUNCTION update_consultations_updated_at();

-- Function to increment patient consultations counter
CREATE OR REPLACE FUNCTION increment_patient_consultations()
RETURNS TRIGGER AS $$
BEGIN
    -- Increment the consultations counter in patients table
    UPDATE patients 
    SET consultations = consultations + 1 
    WHERE id = NEW.patient_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-increment patient consultations counter
DROP TRIGGER IF EXISTS trigger_increment_patient_consultations ON consultations;
CREATE TRIGGER trigger_increment_patient_consultations
    AFTER INSERT ON consultations
    FOR EACH ROW
    EXECUTE FUNCTION increment_patient_consultations();

-- Add consultation_id to prescriptions table
ALTER TABLE prescriptions 
ADD COLUMN IF NOT EXISTS consultation_id INTEGER REFERENCES consultations(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_prescriptions_consultation_id ON prescriptions(consultation_id);
COMMENT ON COLUMN prescriptions.consultation_id IS 'Link to the consultation session this prescription belongs to';

-- Add consultation_id to medical_reports table
ALTER TABLE medical_reports 
ADD COLUMN IF NOT EXISTS consultation_id INTEGER REFERENCES consultations(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_medical_reports_consultation_id ON medical_reports(consultation_id);
COMMENT ON COLUMN medical_reports.consultation_id IS 'Link to the consultation session this medical report belongs to';
