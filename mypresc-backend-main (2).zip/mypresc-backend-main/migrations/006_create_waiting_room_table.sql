-- Migration: Create waiting_room table
-- Created: 2025-09-29 00:00:00

-- Enable pgcrypto for UUID generation (safe if already enabled)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS waiting_room (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INT NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting','called','served','left')),
    arrived_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    called_at TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_waiting_room_patient_id ON waiting_room(patient_id);
CREATE INDEX IF NOT EXISTS idx_waiting_room_doctor_user_id ON waiting_room(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_waiting_room_status ON waiting_room(status);
CREATE INDEX IF NOT EXISTS idx_waiting_room_arrived_at ON waiting_room(arrived_at);

-- Trigger to auto-update updated_at
CREATE TRIGGER update_waiting_room_updated_at 
    BEFORE UPDATE ON waiting_room 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Comments for documentation
COMMENT ON TABLE waiting_room IS 'Queue of patients waiting to see a doctor';
COMMENT ON COLUMN waiting_room.id IS 'Primary key (UUID)';
COMMENT ON COLUMN waiting_room.patient_id IS 'Foreign key to patients(id)';
COMMENT ON COLUMN waiting_room.doctor_user_id IS 'Foreign key to doctors(user_id)';
COMMENT ON COLUMN waiting_room.status IS 'Queue status: waiting/called/served/left';
COMMENT ON COLUMN waiting_room.arrived_at IS 'Timestamp when patient arrived to waiting room';
COMMENT ON COLUMN waiting_room.called_at IS 'Timestamp when patient was called';
COMMENT ON COLUMN waiting_room.notes IS 'Optional notes for triage or staff';
COMMENT ON COLUMN waiting_room.created_at IS 'Record creation timestamp';
COMMENT ON COLUMN waiting_room.updated_at IS 'Last update timestamp'; 