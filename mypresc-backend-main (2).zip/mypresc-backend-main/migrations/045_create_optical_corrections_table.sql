-- Migration: Create optical corrections table
-- Created: 2026-03-11

CREATE TABLE IF NOT EXISTS optical_corrections (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Right Eye (Oeil Droit - OD)
    od_sph VARCHAR(10),
    od_cyl VARCHAR(10),
    od_axis VARCHAR(10),
    od_add VARCHAR(10),
    od_pd VARCHAR(10),
    
    -- Left Eye (Oeil Gauche - OG)
    os_sph VARCHAR(10),
    os_cyl VARCHAR(10),
    os_axis VARCHAR(10),
    os_add VARCHAR(10),
    os_pd VARCHAR(10),
    
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_optical_corrections_patient_id ON optical_corrections(patient_id);
CREATE INDEX IF NOT EXISTS idx_optical_corrections_doctor_user_id ON optical_corrections(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_optical_corrections_created_at ON optical_corrections(created_at);

-- Add trigger to update updated_at timestamp
CREATE TRIGGER update_optical_corrections_updated_at 
    BEFORE UPDATE ON optical_corrections 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
