-- Migration: Add arrived_at field to appointments table
-- This tracks when a patient with RDV actually arrived (clicked "Arrivé")

ALTER TABLE appointments
ADD COLUMN IF NOT EXISTS arrived_at TIMESTAMP WITH TIME ZONE;

-- Add index for performance (filtering by arrived patients)
CREATE INDEX IF NOT EXISTS idx_appointments_arrived_at ON appointments(arrived_at);

-- Comment for documentation
COMMENT ON COLUMN appointments.arrived_at IS 'Timestamp when patient actually arrived (set when clicking Arrivé button)';
