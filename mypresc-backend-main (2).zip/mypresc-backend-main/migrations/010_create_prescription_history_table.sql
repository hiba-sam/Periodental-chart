-- Migration: Create prescription_history table
-- Created: 2025-10-02

CREATE TABLE IF NOT EXISTS prescription_history (
    id SERIAL PRIMARY KEY,
    prescription_id INTEGER NOT NULL REFERENCES prescriptions(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_prescription_history_prescription_id ON prescription_history(prescription_id);
CREATE INDEX IF NOT EXISTS idx_prescription_history_patient_id ON prescription_history(patient_id);
CREATE INDEX IF NOT EXISTS idx_prescription_history_doctor_user_id ON prescription_history(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_prescription_history_created_at ON prescription_history(created_at);

-- Add comments for clarity
COMMENT ON TABLE prescription_history IS 'Tracks prescription records for audit purposes';
COMMENT ON COLUMN prescription_history.prescription_id IS 'Reference to the prescription';
COMMENT ON COLUMN prescription_history.patient_id IS 'Reference to the patient';
COMMENT ON COLUMN prescription_history.doctor_user_id IS 'Reference to the doctor who created the prescription'; 