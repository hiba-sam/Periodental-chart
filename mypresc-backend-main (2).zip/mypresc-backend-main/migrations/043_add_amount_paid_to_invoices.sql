-- Migration: Add amount_paid to consultation_invoices
-- Description: Adds partial payment tracking to invoices
-- Created: 2025-01-25

-- Add amount_paid column to track partial payments
ALTER TABLE consultation_invoices 
ADD COLUMN IF NOT EXISTS amount_paid DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (amount_paid >= 0);

-- Update status based on payment: 'paid' when amount_paid >= total_price, 'partial' when 0 < amount_paid < total_price, 'unpaid' when amount_paid = 0
-- First, modify the status CHECK constraint to include 'partial'
ALTER TABLE consultation_invoices DROP CONSTRAINT IF EXISTS consultation_invoices_status_check;
ALTER TABLE consultation_invoices ADD CONSTRAINT consultation_invoices_status_check 
    CHECK (status IN ('paid', 'unpaid', 'partial', 'free'));

-- Comments
COMMENT ON COLUMN consultation_invoices.amount_paid IS 'Total amount paid so far (supports partial payments)';
