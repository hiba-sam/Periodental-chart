-- Migration: Create custom_medications table
-- Description: Stores medications added by doctors that don't exist in the main medications table
-- Date: 2026-01-05

-- ==============================================
-- TABLE: custom_medications
-- ==============================================
CREATE TABLE IF NOT EXISTS custom_medications (
    id SERIAL PRIMARY KEY,
    nom_de_marque VARCHAR(255) NOT NULL,
    denomination_commune_internationale VARCHAR(255),
    dosage VARCHAR(100),
    forme VARCHAR(100),
    laboratoire VARCHAR(255),
    added_by_doctor_id INTEGER NOT NULL,
    status VARCHAR(50) DEFAULT 'pending', -- pending, approved, rejected
    approved_at TIMESTAMP,
    approved_by_admin_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign keys
    CONSTRAINT fk_custom_med_doctor 
        FOREIGN KEY (added_by_doctor_id) 
        REFERENCES users(id) 
        ON DELETE CASCADE,
    
    CONSTRAINT fk_custom_med_admin 
        FOREIGN KEY (approved_by_admin_id) 
        REFERENCES users(id) 
        ON DELETE SET NULL
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_custom_medications_doctor ON custom_medications(added_by_doctor_id);
CREATE INDEX IF NOT EXISTS idx_custom_medications_status ON custom_medications(status);
CREATE INDEX IF NOT EXISTS idx_custom_medications_name ON custom_medications(nom_de_marque);

-- Add column to prescription_medication_items to support custom medications
ALTER TABLE prescription_medication_items 
ADD COLUMN IF NOT EXISTS custom_medication_id INTEGER REFERENCES custom_medications(id),
ADD COLUMN IF NOT EXISTS is_custom BOOLEAN DEFAULT FALSE;

-- Comments
COMMENT ON TABLE custom_medications IS 'Stores custom medications added by doctors that are not in the main database';
COMMENT ON COLUMN custom_medications.status IS 'Status: pending (awaiting review), approved (added to main DB), rejected';
