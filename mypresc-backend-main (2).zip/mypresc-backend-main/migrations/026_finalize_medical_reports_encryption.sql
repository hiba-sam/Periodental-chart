-- ============================================
-- MIGRATION: 026_finalize_medical_reports_encryption
-- Priority: P0 (CRITICAL)
-- Description: Finalisation du chiffrement - suppression colonnes en clair
-- ⚠️ EXÉCUTER UNIQUEMENT APRÈS:
--    1. Migration 025 exécutée et données migrées
--    2. Code TypeScript MedicalReportModel.ts mis à jour
--    3. Tests passés en environnement de staging
-- ============================================

-- PHASE 1: Vérification préalable
DO $$
DECLARE
    pending_count BIGINT;
BEGIN
    SELECT COUNT(*) INTO pending_count
    FROM medical_reports
    WHERE title_encrypted IS NULL;
    
    IF pending_count > 0 THEN
        RAISE EXCEPTION 'Migration incomplète: % enregistrements non chiffrés', pending_count;
    END IF;
    
    RAISE NOTICE 'Vérification OK: tous les enregistrements sont chiffrés';
END $$;

-- PHASE 2: CONTRACT - Supprimer anciennes colonnes
-- ⚠️ IRRÉVERSIBLE - Faire un backup avant!

-- Sauvegarder les anciennes colonnes temporairement (optionnel, pour rollback)
-- CREATE TABLE medical_reports_backup_plaintext AS 
-- SELECT id, title, content FROM medical_reports;

-- Supprimer les colonnes en clair
ALTER TABLE medical_reports DROP COLUMN IF EXISTS title;
ALTER TABLE medical_reports DROP COLUMN IF EXISTS content;

-- Renommer les colonnes chiffrées
ALTER TABLE medical_reports RENAME COLUMN title_encrypted TO title;
ALTER TABLE medical_reports RENAME COLUMN content_encrypted TO content;

-- Mettre à jour les commentaires
COMMENT ON COLUMN medical_reports.title IS 'Titre du rapport médical - CHIFFRÉ AES-256 (Loi 18-07)';
COMMENT ON COLUMN medical_reports.content IS 'Contenu du rapport médical - CHIFFRÉ AES-256 (Loi 18-07)';

-- PHASE 3: Nettoyer les fonctions de migration temporaires
DROP FUNCTION IF EXISTS migrate_medical_reports_encryption(TEXT);
DROP FUNCTION IF EXISTS verify_medical_reports_encryption();

-- Garder la fonction de décryptage pour usage runtime
-- decrypt_medical_report reste disponible

-- ============================================
-- POST-MIGRATION CHECKLIST
-- ============================================
-- [ ] Vérifier que l'application fonctionne
-- [ ] Tester création nouveau rapport
-- [ ] Tester lecture rapport existant
-- [ ] Supprimer la table backup après 30 jours
-- ============================================
