-- Migration: Create medications table and insert data from JSON
-- Created: 2025-10-02

CREATE TABLE IF NOT EXISTS medications (
    id SERIAL PRIMARY KEY,
    num_enregistrement TEXT,
    code TEXT,
    denomination_commune_internationale TEXT,
    nom_de_marque TEXT,
    forme TEXT,
    dosage TEXT,
    cond TEXT,
    liste TEXT,
    p1 TEXT,
    p2 TEXT,
    obs TEXT,
    laboratoire TEXT,
    pays_laboratoire TEXT,
    date_enregistrement_initial DATE,
    date_enregistrement_final DATE,
    type TEXT,
    statut TEXT,
    duree_stabilite TEXT,
    prix TEXT,
    remboursement TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for commonly queried fields
CREATE INDEX IF NOT EXISTS idx_medications_code ON medications(code);
CREATE INDEX IF NOT EXISTS idx_medications_nom_de_marque ON medications(nom_de_marque);
CREATE INDEX IF NOT EXISTS idx_medications_denomination ON medications(denomination_commune_internationale);
CREATE INDEX IF NOT EXISTS idx_medications_laboratoire ON medications(laboratoire);
CREATE INDEX IF NOT EXISTS idx_medications_statut ON medications(statut);

-- Create a temporary function to insert medication data from JSON
CREATE OR REPLACE FUNCTION insert_medications_from_json() RETURNS VOID AS $$
DECLARE
    json_data JSONB;
    medication_record JSONB;
BEGIN
    -- Read the JSON file content (this will be handled by the migration runner)
    -- For now, we'll create a placeholder that can be replaced with actual data
    RAISE NOTICE 'Medications table created successfully. JSON data insertion will be handled by the migration runner.';
END;
$$ LANGUAGE plpgsql;

-- Call the function
SELECT insert_medications_from_json();

-- Drop the temporary function
DROP FUNCTION insert_medications_from_json(); 