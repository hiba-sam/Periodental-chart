-- Migration: Create act_catalog table for CCAM acts
-- This table stores the official French CCAM medical acts catalog

CREATE TABLE IF NOT EXISTS act_catalog (
    id SERIAL PRIMARY KEY,
    code_ccam VARCHAR(20) NOT NULL,           -- Full CCAM code (e.g., AAFA0020)
    code_short VARCHAR(10) NOT NULL,          -- Short code (e.g., AAFA002)
    label TEXT NOT NULL,                       -- Act description in French
    chapter_code VARCHAR(10),                  -- Chapter code
    chapter_label VARCHAR(255),                -- Chapter name
    parent_code VARCHAR(20),                   -- Parent category code
    parent_label VARCHAR(255),                 -- Parent category name
    topography VARCHAR(10),                    -- Anatomical zone code
    topography_label VARCHAR(255),             -- Anatomical zone name
    action VARCHAR(5),                         -- Action code
    action_label VARCHAR(100),                 -- Action name
    mode_access VARCHAR(5),                    -- Access mode code
    mode_access_label VARCHAR(255),            -- Access mode name
    family_code VARCHAR(10),                   -- Family code
    family_label VARCHAR(255),                 -- Family name
    source VARCHAR(50) DEFAULT 'CCAM',         -- Data source
    is_dental BOOLEAN DEFAULT FALSE,           -- Flag for dental acts (for future filtering)
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT act_catalog_code_ccam_unique UNIQUE (code_ccam)
);

-- Indexes for fast search
CREATE INDEX IF NOT EXISTS idx_act_catalog_code_short ON act_catalog(code_short);
CREATE INDEX IF NOT EXISTS idx_act_catalog_label_trgm ON act_catalog USING gin(label gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_act_catalog_chapter ON act_catalog(chapter_code);
CREATE INDEX IF NOT EXISTS idx_act_catalog_family ON act_catalog(family_code);
CREATE INDEX IF NOT EXISTS idx_act_catalog_is_dental ON act_catalog(is_dental);

-- Enable trigram extension for text search (if not already enabled)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Comment
COMMENT ON TABLE act_catalog IS 'CCAM medical acts catalog imported from official French health insurance data';
