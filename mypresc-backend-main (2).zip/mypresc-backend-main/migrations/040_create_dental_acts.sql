-- Migration: Create dental_acts table for patient dental procedures
-- This table stores dental acts performed on patients

CREATE TABLE IF NOT EXISTS dental_acts (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Scope: determines if act is on specific teeth or whole mouth
    scope VARCHAR(10) NOT NULL CHECK (scope IN ('TOOTH', 'MOUTH')),
    
    -- Teeth selection (FDI notation, e.g., ['11', '12', '21'])
    -- Nullable if scope is MOUTH
    teeth TEXT[] DEFAULT NULL,
    
    -- Surfaces selection (e.g., ['O', 'M', 'D', 'B', 'L'])
    -- O=Occlusal, M=Mesial, D=Distal, B=Buccal/Vestibular, L=Lingual/Palatal
    -- Nullable if scope is MOUTH
    surfaces TEXT[] DEFAULT NULL,
    
    -- Reference to act catalog
    act_catalog_id INTEGER REFERENCES act_catalog(id) ON DELETE SET NULL,
    
    -- Cached act label for display (in case catalog entry is deleted)
    act_label_cache VARCHAR(500),
    act_code_cache VARCHAR(20),
    
    -- Status of the act
    status VARCHAR(20) NOT NULL DEFAULT 'NON_COMMENCE' 
        CHECK (status IN ('NON_COMMENCE', 'EN_COURS', 'TERMINE', 'ANNULE')),
    
    -- Date when the act was/will be performed
    date_act DATE NOT NULL DEFAULT CURRENT_DATE,
    
    -- Additional notes
    notes TEXT,
    
    -- Audit fields
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    
    -- Validation constraints
    CONSTRAINT dental_acts_teeth_required CHECK (
        (scope = 'TOOTH' AND teeth IS NOT NULL AND array_length(teeth, 1) > 0)
        OR scope = 'MOUTH'
    ),
    CONSTRAINT dental_acts_mouth_no_teeth CHECK (
        scope != 'MOUTH' OR teeth IS NULL OR array_length(teeth, 1) IS NULL
    )
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_dental_acts_patient ON dental_acts(patient_id);
CREATE INDEX IF NOT EXISTS idx_dental_acts_doctor ON dental_acts(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_dental_acts_date ON dental_acts(date_act DESC);
CREATE INDEX IF NOT EXISTS idx_dental_acts_status ON dental_acts(status);
CREATE INDEX IF NOT EXISTS idx_dental_acts_catalog ON dental_acts(act_catalog_id);

-- Trigger to update updated_at
CREATE OR REPLACE FUNCTION update_dental_acts_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_dental_acts_updated_at ON dental_acts;
CREATE TRIGGER trigger_dental_acts_updated_at
    BEFORE UPDATE ON dental_acts
    FOR EACH ROW
    EXECUTE FUNCTION update_dental_acts_updated_at();

-- Comment
COMMENT ON TABLE dental_acts IS 'Dental acts performed on patients, linked to CCAM catalog';
COMMENT ON COLUMN dental_acts.scope IS 'TOOTH for specific teeth, MOUTH for whole mouth procedures';
COMMENT ON COLUMN dental_acts.teeth IS 'Array of FDI tooth numbers (11-48 for permanent, 51-85 for deciduous)';
COMMENT ON COLUMN dental_acts.surfaces IS 'Array of tooth surfaces: O(cclusal), M(esial), D(istal), B(uccal), L(ingual)';
