-- ============================================
-- MIGRATION: 029_optimize_medical_reports_performance
-- Priority: P0 (CRITIQUE - Performance dossier patient)
-- Description: Index pour optimiser le chargement des rapports médicaux
-- Impact: Réduit le temps de chargement du dossier patient
-- ============================================

-- PHASE 1: Index composite pour récupération rapide des rapports par patient
-- Optimise: SELECT * FROM medical_reports WHERE patient_id = X ORDER BY examination_date DESC
-- 1. Index pour filtrer par patient + tri par date (très fréquent)
CREATE INDEX IF NOT EXISTS idx_medical_reports_patient_date 
ON medical_reports(patient_id, created_at DESC);

-- 2. Index pour filtrer par patient + médecin (contexte RLS)
CREATE INDEX IF NOT EXISTS idx_medical_reports_patient_doctor 
ON medical_reports(patient_id, doctor_user_id);

-- 3. Index pour filtrer par médecin (tableau de bord)
-- Note: id est déjà indexé (PK), doctor_user_id seul l'est aussi (FK)
-- Mais pourORDER BY date pour un médecin :
CREATE INDEX IF NOT EXISTS idx_medical_reports_doctor_date 
ON medical_reports(doctor_user_id, created_at DESC);

-- PHASE 3: Index pour comptage rapide des rapports par patient
-- Optimise: SELECT COUNT(*) FROM medical_reports WHERE patient_id = X
-- Note: L'index idx_medical_reports_patient_date couvre déjà ce cas

-- ============================================
-- COMMENTAIRES POUR LA DOC
-- ============================================
COMMENT ON INDEX idx_medical_reports_patient_date IS 
'Optimise la récupération des rapports médicaux par patient - tri par date inclus';

COMMENT ON INDEX idx_medical_reports_patient_doctor IS 
'Optimise le filtrage des rapports pour patients en mode privé - accès restreint au médecin assigné';

COMMENT ON INDEX idx_medical_reports_doctor_date IS 
'Optimise la récupération des rapports créés par un médecin spécifique';

-- ============================================
-- ANALYSE DE PERFORMANCE
-- ============================================
-- Pour vérifier l'utilisation des index après migration:
-- 
-- EXPLAIN ANALYZE 
-- SELECT * FROM medical_reports 
-- WHERE patient_id = 'some-uuid' 
-- ORDER BY examination_date DESC, created_at DESC
-- LIMIT 50;
-- 
-- Devrait montrer "Index Scan using idx_medical_reports_patient_date"

-- ============================================
-- ROLLBACK SCRIPT
-- ============================================
-- DROP INDEX CONCURRENTLY IF EXISTS idx_medical_reports_patient_date;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_medical_reports_patient_doctor;
-- DROP INDEX CONCURRENTLY IF EXISTS idx_medical_reports_doctor_date;
