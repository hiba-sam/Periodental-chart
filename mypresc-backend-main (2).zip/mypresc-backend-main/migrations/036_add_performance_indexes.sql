-- Migration 036: Add performance indexes for dashboard queries
-- This migration adds composite indexes to speed up common dashboard queries

-- Index for appointments by doctor and date (used in dashboard stats)
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_date 
ON appointments (doctor_user_id, date);

-- Index for waiting_room by doctor (used in dashboard)
CREATE INDEX IF NOT EXISTS idx_waiting_room_doctor 
ON waiting_room (doctor_user_id, arrived_at);

-- Index for consultation_invoices by doctor and created_at (used in statistics)
CREATE INDEX IF NOT EXISTS idx_consultation_invoices_doctor_created 
ON consultation_invoices (doctor_user_id, created_at);

-- Index for consultation_invoices by doctor and status (used in unpaid queries)
CREATE INDEX IF NOT EXISTS idx_consultation_invoices_doctor_status 
ON consultation_invoices (doctor_user_id, status);
