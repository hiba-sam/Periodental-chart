-- Migration: Create doctor_transitions table for tracking primary care physician changes
-- Created: 2024-12-15

CREATE TABLE IF NOT EXISTS doctor_transitions (
    id SERIAL PRIMARY KEY,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    previous_doctor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    new_doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    comment TEXT NOT NULL, -- Reason for the transition (required)
    transition_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_doctor_transitions_patient_id ON doctor_transitions(patient_id);
CREATE INDEX IF NOT EXISTS idx_doctor_transitions_previous_doctor_id ON doctor_transitions(previous_doctor_id);
CREATE INDEX IF NOT EXISTS idx_doctor_transitions_new_doctor_id ON doctor_transitions(new_doctor_id);
CREATE INDEX IF NOT EXISTS idx_doctor_transitions_transition_date ON doctor_transitions(transition_date);

-- Add comments for documentation
COMMENT ON TABLE doctor_transitions IS 'Historical record of primary care physician changes with reasons';
COMMENT ON COLUMN doctor_transitions.id IS 'Primary key';
COMMENT ON COLUMN doctor_transitions.patient_id IS 'Patient whose doctor is changing';
COMMENT ON COLUMN doctor_transitions.previous_doctor_id IS 'Previous primary care physician (NULL if first assignment)';
COMMENT ON COLUMN doctor_transitions.new_doctor_id IS 'New primary care physician';
COMMENT ON COLUMN doctor_transitions.comment IS 'Mandatory comment explaining the reason for transition';
COMMENT ON COLUMN doctor_transitions.transition_date IS 'When the transition occurred';
