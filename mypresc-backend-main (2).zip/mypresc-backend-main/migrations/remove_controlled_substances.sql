-- ============================================================================
-- Migration: Remove controlled substances requiring 3-copy prescriptions
-- Based on: Arrêté interministériel du 11 août 2021 (JO n°61)
-- ============================================================================
-- 
-- DCI to remove:
-- 1. Buprénorphine
-- 2. Tramadol (all forms and dosages)
-- 3. Paracétamol + Tramadol (association)
-- 4. Clonazépam
-- 5. Prégabaline (Lyrica + all generics)
-- 6. Trihexyphénidyle
-- 7. Clorazépate dipotassique
-- 8. Midazolam
-- 9. Zolpidem
-- ============================================================================

-- ============================================================================
-- ÉTAPE 1: VÉRIFICATION - Compter les médicaments à supprimer
-- Exécutez cette requête EN PREMIER pour voir combien seront supprimés
-- ============================================================================
SELECT 
    COUNT(*) as nombre_total,
    denomination_commune_internationale as dci
FROM medications 
WHERE 
    denomination_commune_internationale ILIKE '%buprenorphine%'
    OR denomination_commune_internationale ILIKE '%buprénorphine%'
    OR denomination_commune_internationale ILIKE '%tramadol%'
    OR denomination_commune_internationale ILIKE '%clonazepam%'
    OR denomination_commune_internationale ILIKE '%clonazépam%'
    OR denomination_commune_internationale ILIKE '%pregabaline%'
    OR denomination_commune_internationale ILIKE '%prégabaline%'
    OR denomination_commune_internationale ILIKE '%trihexyphenidyle%'
    OR denomination_commune_internationale ILIKE '%trihexyphénidyle%'
    OR denomination_commune_internationale ILIKE '%clorazepate%'
    OR denomination_commune_internationale ILIKE '%clorazépate%'
    OR denomination_commune_internationale ILIKE '%midazolam%'
    OR denomination_commune_internationale ILIKE '%zolpidem%'
GROUP BY denomination_commune_internationale
ORDER BY denomination_commune_internationale;

-- ============================================================================
-- ÉTAPE 2: VOIR LA LISTE DÉTAILLÉE des médicaments à supprimer
-- ============================================================================
SELECT 
    id,
    nom_de_marque,
    denomination_commune_internationale,
    dosage,
    forme
FROM medications 
WHERE 
    denomination_commune_internationale ILIKE '%buprenorphine%'
    OR denomination_commune_internationale ILIKE '%buprénorphine%'
    OR denomination_commune_internationale ILIKE '%tramadol%'
    OR denomination_commune_internationale ILIKE '%clonazepam%'
    OR denomination_commune_internationale ILIKE '%clonazépam%'
    OR denomination_commune_internationale ILIKE '%pregabaline%'
    OR denomination_commune_internationale ILIKE '%prégabaline%'
    OR denomination_commune_internationale ILIKE '%trihexyphenidyle%'
    OR denomination_commune_internationale ILIKE '%trihexyphénidyle%'
    OR denomination_commune_internationale ILIKE '%clorazepate%'
    OR denomination_commune_internationale ILIKE '%clorazépate%'
    OR denomination_commune_internationale ILIKE '%midazolam%'
    OR denomination_commune_internationale ILIKE '%zolpidem%'
ORDER BY denomination_commune_internationale, nom_de_marque;

-- ============================================================================
-- ÉTAPE 3: SUPPRESSION - Exécutez APRÈS avoir vérifié les étapes 1 et 2
-- ============================================================================
DELETE FROM medications 
WHERE 
    -- Buprénorphine
    denomination_commune_internationale ILIKE '%buprenorphine%'
    OR denomination_commune_internationale ILIKE '%buprénorphine%'
    -- Tramadol (includes Paracétamol + Tramadol associations)
    OR denomination_commune_internationale ILIKE '%tramadol%'
    -- Clonazépam
    OR denomination_commune_internationale ILIKE '%clonazepam%'
    OR denomination_commune_internationale ILIKE '%clonazépam%'
    -- Prégabaline
    OR denomination_commune_internationale ILIKE '%pregabaline%'
    OR denomination_commune_internationale ILIKE '%prégabaline%'
    -- Trihexyphénidyle
    OR denomination_commune_internationale ILIKE '%trihexyphenidyle%'
    OR denomination_commune_internationale ILIKE '%trihexyphénidyle%'
    -- Clorazépate dipotassique
    OR denomination_commune_internationale ILIKE '%clorazepate%'
    OR denomination_commune_internationale ILIKE '%clorazépate%'
    -- Midazolam
    OR denomination_commune_internationale ILIKE '%midazolam%'
    -- Zolpidem
    OR denomination_commune_internationale ILIKE '%zolpidem%';

-- ============================================================================
-- ÉTAPE 4: VÉRIFICATION FINALE - Confirmer que les médicaments sont supprimés
-- ============================================================================
SELECT COUNT(*) as remaining FROM medications 
WHERE 
    denomination_commune_internationale ILIKE '%buprenorphine%'
    OR denomination_commune_internationale ILIKE '%buprénorphine%'
    OR denomination_commune_internationale ILIKE '%tramadol%'
    OR denomination_commune_internationale ILIKE '%clonazepam%'
    OR denomination_commune_internationale ILIKE '%clonazépam%'
    OR denomination_commune_internationale ILIKE '%pregabaline%'
    OR denomination_commune_internationale ILIKE '%prégabaline%'
    OR denomination_commune_internationale ILIKE '%trihexyphenidyle%'
    OR denomination_commune_internationale ILIKE '%trihexyphénidyle%'
    OR denomination_commune_internationale ILIKE '%clorazepate%'
    OR denomination_commune_internationale ILIKE '%clorazépate%'
    OR denomination_commune_internationale ILIKE '%midazolam%'
    OR denomination_commune_internationale ILIKE '%zolpidem%';
-- Le résultat doit être 0
