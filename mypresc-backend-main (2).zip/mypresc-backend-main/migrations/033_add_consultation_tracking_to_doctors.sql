-- Migration: Add consultation tracking fields to doctors table
-- This tracks the current consultation state for the "Patient suivant" feature

ALTER TABLE doctors
ADD COLUMN IF NOT EXISTS consultation_started_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS consultation_ended_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS current_patient_id UUID REFERENCES patients(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS current_patient_type VARCHAR(20) DEFAULT NULL; -- 'appointment' or 'waiting'

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_doctors_current_patient ON doctors(current_patient_id);

-- Comments for documentation
COMMENT ON COLUMN doctors.consultation_started_at IS 'When the current consultation started';
COMMENT ON COLUMN doctors.consultation_ended_at IS 'When the last consultation ended (used to determine who arrived DURING consultation)';
COMMENT ON COLUMN doctors.current_patient_id IS 'Patient currently in consultation';
COMMENT ON COLUMN doctors.current_patient_type IS 'Type of current patient: appointment or waiting';
