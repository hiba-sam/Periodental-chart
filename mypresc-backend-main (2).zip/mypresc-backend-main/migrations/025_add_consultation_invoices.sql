-- Migration: Add Consultation Invoices
-- Description: Adds invoicing capability
-- Created: 2025-12-25

-- De-commented if needed
-- 1. Add has_invoice to consultations table
ALTER TABLE consultations ADD COLUMN IF NOT EXISTS has_invoice BOOLEAN DEFAULT false;

-- 2. Create consultation_invoices table (Decoupled from specific consultation)
CREATE TABLE IF NOT EXISTS consultation_invoices (
    id SERIAL PRIMARY KEY,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    total_price DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (total_price >= 0),
    status VARCHAR(20) NOT NULL DEFAULT 'unpaid' CHECK (status IN ('paid', 'unpaid')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for consultation_invoices
CREATE INDEX IF NOT EXISTS idx_consultation_invoices_doctor_user_id ON consultation_invoices(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_consultation_invoices_patient_id ON consultation_invoices(patient_id);
CREATE INDEX IF NOT EXISTS idx_consultation_invoices_created_at ON consultation_invoices(created_at);

-- Trigger for updated_at on consultation_invoices
DROP TRIGGER IF EXISTS update_consultation_invoices_updated_at ON consultation_invoices;
CREATE TRIGGER update_consultation_invoices_updated_at
    BEFORE UPDATE ON consultation_invoices
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Comments
COMMENT ON TABLE consultation_invoices IS 'Stores invoice summary for patients';
COMMENT ON COLUMN consultation_invoices.doctor_user_id IS 'Doctor issuing the invoice';
COMMENT ON COLUMN consultation_invoices.patient_id IS 'Patient receiving the invoice';
COMMENT ON COLUMN consultation_invoices.total_price IS 'Total amount charged';
COMMENT ON COLUMN consultation_invoices.status IS 'Payment status: paid or unpaid';

-- 2. Create consultation_invoice_items table
CREATE TABLE IF NOT EXISTS consultation_invoice_items (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER NOT NULL REFERENCES consultation_invoices(id) ON DELETE CASCADE,
    tarification_id INTEGER REFERENCES tarifications(id) ON DELETE SET NULL, -- Optional link to original service
    label VARCHAR(255) NOT NULL, -- Snapshot of the service name
    price DECIMAL(10, 2) NOT NULL DEFAULT 0 CHECK (price >= 0), -- Snapshot of the price
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for consultation_invoice_items
CREATE INDEX IF NOT EXISTS idx_consultation_invoice_items_invoice_id ON consultation_invoice_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_consultation_invoice_items_tarification_id ON consultation_invoice_items(tarification_id);

-- Comments
COMMENT ON TABLE consultation_invoice_items IS 'Line items for invoices';
COMMENT ON COLUMN consultation_invoice_items.tarification_id IS 'Optional link to the original tarification (service)';
COMMENT ON COLUMN consultation_invoice_items.label IS 'Name of the service/act (snapshot)';
COMMENT ON COLUMN consultation_invoice_items.price IS 'Price charged for this item (snapshot)';
