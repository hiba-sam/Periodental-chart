-- Migration: Add venue_confirmed field to appointments table
-- This separates "patient confirmed they will come" from "patient has arrived"
-- venue_confirmed = patient confirmed venue (by phone, etc.) - visual only
-- confirmed_coming = patient has arrived -> appears in ordre de passage

ALTER TABLE appointments 
ADD COLUMN IF NOT EXISTS venue_confirmed BOOLEAN DEFAULT false;

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_appointments_venue_confirmed ON appointments(venue_confirmed);

-- Comment for documentation
COMMENT ON COLUMN appointments.venue_confirmed IS 'True if patient has confirmed they will attend (separate from actually arriving)';
