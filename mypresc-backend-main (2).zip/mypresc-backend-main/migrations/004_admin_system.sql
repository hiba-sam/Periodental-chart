-- ============================================
-- MIGRATION: Admin System & Audit Logs
-- Version: 004
-- Description: Tables pour le système d'administration et traçabilité
-- ============================================

-- ============================================
-- TABLE: admins
-- Description: Administrateurs du système
-- ============================================
CREATE TABLE IF NOT EXISTS admins (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'admin', -- admin, super_admin
    is_active BOOLEAN DEFAULT TRUE,
    phone_number VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    created_by INTEGER REFERENCES admins(id) ON DELETE SET NULL
);

-- Index pour performances
CREATE INDEX idx_admins_email ON admins(email);
CREATE INDEX idx_admins_is_active ON admins(is_active);

-- ============================================
-- TABLE: audit_logs
-- Description: Logs de toutes les actions administratives
-- ============================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
    admin_name VARCHAR(100) NOT NULL,
    admin_email VARCHAR(255) NOT NULL,
    action VARCHAR(100) NOT NULL, -- APPROVE_REGISTRATION, REJECT_REGISTRATION, LOGIN, LOGOUT, etc.
    target_type VARCHAR(50), -- user, doctor, appointment, etc.
    target_id INTEGER,
    target_name VARCHAR(255),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45), -- IPv6 compatible
    user_agent TEXT,
    session_id VARCHAR(255),
    notes TEXT,
    metadata JSONB, -- Données supplémentaires en JSON
    status VARCHAR(50) DEFAULT 'success' -- success, failed, pending
);

-- Index pour performances et recherches
CREATE INDEX idx_audit_logs_admin_id ON audit_logs(admin_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX idx_audit_logs_target ON audit_logs(target_type, target_id);
CREATE INDEX idx_audit_logs_metadata ON audit_logs USING gin(metadata);

-- ============================================
-- ADMIN PAR DÉFAUT
-- Password: Admin123! (à changer en production)
-- ============================================
INSERT INTO admins (name, email, password, role) 
VALUES (
    'Admin Principal',
    'admin@mypresc.com',
    '$2b$10$YourHashedPasswordHere', -- Remplacer par hash réel
    'super_admin'
) ON CONFLICT (email) DO NOTHING;

-- ============================================
-- TRIGGER: Update timestamp
-- ============================================
CREATE OR REPLACE FUNCTION update_admins_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_admins_updated_at
    BEFORE UPDATE ON admins
    FOR EACH ROW
    EXECUTE FUNCTION update_admins_updated_at();

-- ============================================
-- COMMENTS
-- ============================================
COMMENT ON TABLE admins IS 'Administrateurs du système avec authentification';
COMMENT ON TABLE audit_logs IS 'Logs d audit pour traçabilité complète des actions';
COMMENT ON COLUMN audit_logs.metadata IS 'Données JSON pour contexte supplémentaire';
