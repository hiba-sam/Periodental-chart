﻿import pool from '../db.js'; // adjust extension if needed (.ts when compiled, .js at runtime)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class MigrationRunner {
    static async runMigrations(): Promise<void> {
        try {
            // Ensure migrations table exists
            await pool.query(`
                CREATE TABLE IF NOT EXISTS migrations (
                    id SERIAL PRIMARY KEY,
                    filename VARCHAR(255) UNIQUE NOT NULL,
                    executed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Location of .sql files
            const migrationsDir = path.join(__dirname); // or path.join(__dirname, "sql") if they are in a subfolder
            const migrationFiles = fs.readdirSync(migrationsDir)
                .filter(file => file.endsWith('.sql'))
                .sort();

            console.log('Found migration files:', migrationFiles);

            for (const filename of migrationFiles) {
                // Skip already executed migrations
                const result = await pool.query(
                    'SELECT id FROM migrations WHERE filename = $1',
                    [filename]
                );

                if (result.rows.length > 0) {
                    console.log(`Migration ${filename} already executed, skipping...`);
                    continue;
                }

                // Read and execute SQL
                const migrationPath = path.join(migrationsDir, filename);
                const migrationSQL = fs.readFileSync(migrationPath, 'utf8').trim();

                if (!migrationSQL) {
                    console.warn(`⚠️ Skipping ${filename} because file is empty`);
                    continue;
                }

                console.log(`\n--- Executing migration: ${filename} ---`);
                console.log(migrationSQL);
                console.log('----------------------------------------\n');

                await pool.query(migrationSQL);

                // Special handling for medications table migration
                if (filename === '007_create_medications_table.sql') {
                    await this.insertMedicationsData();
                }

                // Record migration
                await pool.query(
                    'INSERT INTO migrations (filename) VALUES ($1)',
                    [filename]
                );

                console.log(`✅ Migration ${filename} executed successfully`);
            }

            console.log('🎉 All migrations completed successfully');
        } catch (error) {
            console.error('❌ Migration failed:', error);
            throw error;
        }
    }

    static async insertMedicationsData(): Promise<void> {
        try {
            console.log('📥 Inserting medications data from JSON file...');
            
            // Check if data already exists to avoid duplicates
            const existingCount = await pool.query('SELECT COUNT(*) FROM medications');
            if (parseInt(existingCount.rows[0].count) > 0) {
                console.log(`⚠️ Found ${existingCount.rows[0].count} existing medications. Skipping insertion to avoid duplicates.`);
                return;
            }
            
            // Read the JSON file
            const jsonPath = path.join(__dirname, '..', 'jsons', 'medicament.json');
            const jsonContent = fs.readFileSync(jsonPath, 'utf8');
            const jsonData = JSON.parse(jsonContent);
            
            console.log('🔍 Examining JSON structure...');
            console.log('JSON is array:', Array.isArray(jsonData));
            console.log('JSON length:', jsonData.length);
            
            // Extract the medications data array - handle different possible structures
            let medicationsData;
            
            if (Array.isArray(jsonData)) {
                // Find the object that contains the data array
                for (let i = 0; i < jsonData.length; i++) {
                    console.log(`Item ${i}:`, typeof jsonData[i], jsonData[i]?.type, jsonData[i]?.name);
                    if (jsonData[i] && jsonData[i].data && Array.isArray(jsonData[i].data)) {
                        medicationsData = jsonData[i].data;
                        console.log(`✅ Found medications data at index ${i}`);
                        break;
                    }
                }
            } else if (jsonData.data && Array.isArray(jsonData.data)) {
                medicationsData = jsonData.data;
                console.log('✅ Found medications data at root level');
            } else {
                throw new Error('Could not find medications data array in JSON structure');
            }
            
            if (!medicationsData) {
                throw new Error('No medications data found in JSON file');
            }
            
            console.log(`📊 Found ${medicationsData.length} medications to insert (expecting 5000)`);
            
            if (medicationsData.length !== 5000) {
                console.warn(`⚠️ Warning: Expected 5000 medications but found ${medicationsData.length}`);
            }
            
            // Insert medications in batches to avoid memory issues
            const batchSize = 100;
            let insertedCount = 0;
            let failedCount = 0;
            const totalBatches = Math.ceil(medicationsData.length / batchSize);
            
            console.log(`🔄 Processing ${totalBatches} batches of ${batchSize} medications each...`);
            
            for (let i = 0; i < medicationsData.length; i += batchSize) {
                const batch = medicationsData.slice(i, i + batchSize);
                const currentBatch = Math.floor(i / batchSize) + 1;
                
                console.log(`\n📦 Processing batch ${currentBatch}/${totalBatches} (medications ${i + 1}-${Math.min(i + batchSize, medicationsData.length)})`);
                
                // Use transaction for each batch to ensure data integrity
                const client = await pool.connect();
                try {
                    await client.query('BEGIN');
                    
                    for (const med of batch) {
                        try {
                            await client.query(`
                                INSERT INTO medications (
                                    num_enregistrement, code, denomination_commune_internationale, 
                                    nom_de_marque, forme, dosage, cond, liste, p1, p2, obs,
                                    laboratoire, pays_laboratoire, date_enregistrement_initial,
                                    date_enregistrement_final, type, statut, duree_stabilite,
                                    prix, remboursement
                                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
                            `, [
                                med.NUM_ENREGISTREMENT,
                                med.CODE,
                                med.DENOMINATION_COMMUNE_INTERNATIONALE,
                                med.NOM_DE_MARQUE,
                                med.FORME,
                                med.DOSAGE,
                                med.COND,
                                med.LISTE,
                                med.P1,
                                med.P2,
                                med.OBS,
                                med.LABORATOIRES_DETENTEUR_DE_LA_DECISION_DENREGISTREMENT,
                                med.PAYS_DU_LABORATOIRE_DETENTEUR_DE_LA_DECISION_DENREGISTREMENT,
                                med.DATE_DENREGISTREMENT_INITIAL ? new Date(med.DATE_DENREGISTREMENT_INITIAL) : null,
                                med.DATE_DENREGISTREMENT_FINAL ? new Date(med.DATE_DENREGISTREMENT_FINAL) : null,
                                med.TYPE,
                                med.STATUT,
                                med.DUREE_DE_STABILITE,
                                med.PRIX_PORTE_SUR_LA_DECISION_DENREGISTREMENT,
                                med.REMBOURSEMENT
                            ]);
                            insertedCount++;
                        } catch (medError: any) {
                            console.error(`❌ Failed to insert medication ID ${med.ID}:`, medError.message);
                            failedCount++;
                        }
                    }
                    
                    await client.query('COMMIT');
                    console.log(`✅ Batch ${currentBatch} completed: ${batch.length} medications processed`);
                    
                } catch (batchError: any) {
                    await client.query('ROLLBACK');
                    console.error(`❌ Batch ${currentBatch} failed, rolling back:`, batchError.message);
                    failedCount += batch.length;
                } finally {
                    client.release();
                }
                
                // Progress update
                const progress = ((i + batchSize) / medicationsData.length * 100).toFixed(1);
                console.log(`📈 Progress: ${Math.min(i + batchSize, medicationsData.length)}/${medicationsData.length} (${progress}%)`);
            }
            
            // Final verification
            const finalCount = await pool.query('SELECT COUNT(*) FROM medications');
            const actualInserted = parseInt(finalCount.rows[0].count);
            
            console.log('\n🎯 INSERTION SUMMARY:');
            console.log(`📊 Total medications in JSON: ${medicationsData.length}`);
            console.log(`✅ Successfully inserted: ${insertedCount}`);
            console.log(`❌ Failed insertions: ${failedCount}`);
            console.log(`🔢 Final count in database: ${actualInserted}`);
            
            if (actualInserted === medicationsData.length) {
                console.log('🎉 SUCCESS: All medications inserted successfully!');
            } else {
                console.warn(`⚠️ WARNING: Expected ${medicationsData.length} but database contains ${actualInserted} medications`);
            }
            
        } catch (error) {
            console.error('❌ Failed to insert medications data:', error);
            throw error;
        }
    }

    static async checkDatabaseConnection(): Promise<boolean> {
        try {
            await pool.query('SELECT 1');
            console.log('✅ Database connection successful');
            return true;
        } catch (error) {
            console.error('❌ Database connection failed:', error);
            return false;
        }
    }
}

// Run directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
    MigrationRunner.checkDatabaseConnection()
        .then(() => MigrationRunner.runMigrations())
        .then(() => {
            console.log('🚀 Migration process completed');
            process.exit(0);
        })
        .catch((error) => {
            console.error('Migration process failed:', error);
            process.exit(1);
        });
}
