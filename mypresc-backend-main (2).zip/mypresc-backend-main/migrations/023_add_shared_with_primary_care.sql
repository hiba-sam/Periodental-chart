-- Migration 023: Add shared_with_primary_care column to patients table
-- This allows patients to share their medical records specifically with their primary care physician

ALTER TABLE patients 
ADD COLUMN IF NOT EXISTS shared_with_primary_care BOOLEAN DEFAULT FALSE;

-- Add index for better performance when querying shared patients
CREATE INDEX IF NOT EXISTS idx_patients_shared_primary_care 
ON patients(medecin_traitant_id, shared_with_primary_care) 
WHERE shared_with_primary_care = TRUE;

COMMENT ON COLUMN patients.shared_with_primary_care IS 'Indicates if patient medical records are shared with their primary care physician';
