-- Migration: Create appointments table
-- Created: 2024-01-01 00:00:00

-- Enable pgcrypto extension for UUID generation
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_user_id INT NOT NULL REFERENCES doctors(user_id) ON DELETE CASCADE,
    date DATE NOT NULL,
    time TIME NOT NULL,
    duration INTEGER NOT NULL DEFAULT 30, -- Duration in minutes
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_done BOOLEAN DEFAULT false,
    color TEXT DEFAULT '#2563eb',
    confirmed_coming BOOLEAN DEFAULT false
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_user_id ON appointments(doctor_user_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(date);
CREATE INDEX IF NOT EXISTS idx_appointments_time ON appointments(time);
CREATE INDEX IF NOT EXISTS idx_appointments_confirmed_coming ON appointments(confirmed_coming);
CREATE INDEX IF NOT EXISTS idx_appointments_created_at ON appointments(created_at);

-- Create trigger to automatically update updated_at
DROP TRIGGER IF EXISTS update_appointments_updated_at ON appointments;
CREATE TRIGGER update_appointments_updated_at 
    BEFORE UPDATE ON appointments 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- Add comments for documentation
COMMENT ON TABLE appointments IS 'Medical appointments table';
COMMENT ON COLUMN appointments.id IS 'Primary key (UUID)';
COMMENT ON COLUMN appointments.patient_id IS 'Foreign key to patients(id)';
COMMENT ON COLUMN appointments.doctor_user_id IS 'Foreign key to doctors(user_id)';
COMMENT ON COLUMN appointments.date IS 'Appointment date';
COMMENT ON COLUMN appointments.time IS 'Appointment time';
COMMENT ON COLUMN appointments.duration IS 'Appointment duration in minutes';
COMMENT ON COLUMN appointments.notes IS 'Additional notes about the appointment';
COMMENT ON COLUMN appointments.created_at IS 'Appointment creation timestamp';
COMMENT ON COLUMN appointments.updated_at IS 'Last update timestamp';
COMMENT ON COLUMN appointments.confirmed_coming IS 'Patient confirmation status';
