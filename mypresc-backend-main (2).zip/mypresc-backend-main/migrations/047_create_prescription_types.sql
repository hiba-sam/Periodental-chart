-- Migration: Create prescription_types and prescription_type_medications tables
-- Created: 2026-03-18
-- Purpose: Support reusable prescription templates ("Modèles d'ordonnance")

-- ============================================================
-- TABLE: prescription_types (template header)
-- ============================================================
CREATE TABLE IF NOT EXISTS prescription_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    doctor_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: prescription_type_medications (medications in template)
-- ============================================================
CREATE TABLE IF NOT EXISTS prescription_type_medications (
    id SERIAL PRIMARY KEY,
    prescription_type_id INTEGER NOT NULL REFERENCES prescription_types(id) ON DELETE CASCADE,
    -- Reference to standard medication (nullable for custom meds)
    medication_id INTEGER REFERENCES medications(id) ON DELETE SET NULL,
    -- Reference to custom medication (nullable for standard meds)
    custom_medication_id INTEGER REFERENCES custom_medications(id) ON DELETE SET NULL,
    is_custom BOOLEAN DEFAULT FALSE,
    quantity INTEGER NOT NULL DEFAULT 1,
    dosage TEXT NOT NULL,
    note TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_prescription_types_doctor_id
    ON prescription_types(doctor_user_id);

CREATE INDEX IF NOT EXISTS idx_prescription_types_created_at
    ON prescription_types(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_prescription_type_medications_type_id
    ON prescription_type_medications(prescription_type_id);

-- ============================================================
-- TRIGGER: auto-update updated_at on prescription_types
-- ============================================================
CREATE TRIGGER update_prescription_types_updated_at
    BEFORE UPDATE ON prescription_types
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
