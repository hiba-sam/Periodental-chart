import type { Request, Response } from 'express';
import { WhisperService } from '../services/whisper.service';
import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Configuration multer pour l'upload audio
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = 'uploads/audio';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'audio-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage,
    limits: {
        fileSize: 25 * 1024 * 1024, // 25MB max (limite Whisper)
    },
    fileFilter: (req, file, cb) => {
        const allowedMimes = [
            'audio/mpeg',
            'audio/mp3',
            'audio/wav',
            'audio/webm',
            'audio/mp4',
            'audio/m4a',
        ];
        if (allowedMimes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Format audio non supporté. Utilisez MP3, WAV, WEBM, ou M4A.'));
        }
    }
});

/**
 * Middleware multer pour l'upload
 */
export const uploadAudio = upload.single('audio');

/**
 * Transcrit un fichier audio en texte avec Whisper
 */
export const transcribeAudio = async (req: Request, res: Response) => {
    try {
        if (!(req as any).file) {
            return res.status(400).json({
                success: false,
                error: req.t('transcription.no_file')
            });
        }

        const audioPath = (req as any).file.path;

        console.log(`🎤 Transcription audio: ${(req as any).file.originalname} (${((req as any).file.size / 1024).toFixed(2)} KB)`);

        // Transcription avec Whisper Local
        const transcription = await WhisperService.transcribeAudio(audioPath, {
            language: 'fr',
        });

        // Nettoyer le fichier temporaire
        fs.unlinkSync(audioPath);

        console.log(`✅ Transcription réussie: ${transcription.substring(0, 100)}...`);

        return res.json({
            success: true,
            data: {
                transcription,
                originalFileName: (req as any).file.originalname,
                duration: req.body.duration || null,
            }
        });

    } catch (error: any) {
        console.error('❌ Erreur de transcription:', error);

        // Nettoyer le fichier en cas d'erreur
        if ((req as any).file?.path && fs.existsSync((req as any).file.path)) {
            fs.unlinkSync((req as any).file.path);
        }

        return res.status(500).json({
            success: false,
            error: error.message || req.t('transcription.error')
        });
    }
};

/**
 * Vérifie si Whisper local est installé
 */
export const checkWhisperStatus = async (req: Request, res: Response) => {
    try {
        const status = await WhisperService.checkInstallation();

        return res.json({
            success: true,
            data: {
                whisperEnabled: status.installed,
                version: status.version,
                message: status.installed
                    ? req.t('transcription.whisper_ready', { version: status.version })
                    : status.error || req.t('transcription.whisper_not_installed'),
                model: process.env.WHISPER_MODEL || 'base',
                language: process.env.WHISPER_LANGUAGE || 'fr',
                cost: 'GRATUIT - 100% local'
            }
        });
    } catch (error: any) {
        return res.json({
            success: false,
            data: {
                whisperEnabled: false,
                message: req.t('transcription.check_error'),
                error: error.message
            }
        });
    }
};
