import type { Request, Response } from 'express';
import { z } from 'zod';
import { MessagingService } from '../services/messaging.service';
import { ConversationModel } from '../models/conversation.model';
import { MessageModel } from '../models/message.model';
import socketManager from '../utils/socketManager';
import path from 'path';

// Validation schemas
const SearchDoctorsSchema = z.object({
  query: z.string().min(1).max(100),
  limit: z.number().int().min(1).max(50).optional(),
});

const CreateConversationSchema = z.object({
  peerUserId: z.number().int().positive(),
});

const GetMessagesSchema = z.object({
  page: z.number().int().min(1).optional(),
  pageSize: z.number().int().min(1).max(100).optional(),
});

const SendMessageSchema = z.object({
  content: z.string().min(1).max(5000),
});

/**
 * Messaging REST API Controller
 */
export class MessagingController {
  /**
   * GET /messaging/users/search
   * Search for doctors
   */
  static async searchDoctors(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;

      // Validate query params
      const queryParam = req.query.query as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const { query, limit } = SearchDoctorsSchema.parse({
        query: queryParam,
        limit: limitParam ? parseInt(limitParam) : 20,
      });

      const doctors = await MessagingService.searchDoctors(query, userId, limit);

      res.json({
        success: true,
        data: doctors,
        count: doctors.length,
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.invalid_query'),
          details: error.issues,
        });
        return;
      }

      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.search_error'),
      });
    }
  }

  /**
   * GET /messaging/conversation-partner
   * Get conversation partner based on user role
   * - For assistants: returns their doctor
   * - For doctors: returns their assistant
   */
  static async getConversationPartner(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;

      const partner = await MessagingService.getConversationPartner(userId);

      if (!partner) {
        res.status(404).json({
          success: false,
          error: req.t('messaging.partner_not_found'),
        });
        return;
      }

      res.json({
        success: true,
        data: partner,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.partner_fetch_error'),
      });
    }
  }

  /**
   * GET /messaging/conversations
   * Get all conversations for current user
   */
  static async getConversations(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;

      const conversations = await ConversationModel.getUserConversations(userId);

      res.json({
        success: true,
        data: conversations,
        count: conversations.length,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.conversations_fetch_error'),
      });
    }
  }

  /**
   * POST /messaging/conversations
   * Create or get direct conversation
   */
  static async createConversation(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;

      // Validate body
      const { peerUserId } = CreateConversationSchema.parse(req.body);

      // Can't create conversation with yourself
      if (peerUserId === userId) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.self_conversation_error'),
        });
        return;
      }

      // Create or get conversation
      const conversationId = await MessagingService.createOrGetConversation(
        userId,
        peerUserId
      );

      // Get conversation details
      const conversations = await ConversationModel.getUserConversations(userId);
      const conversation = conversations.find((c) => c.id === conversationId);

      res.json({
        success: true,
        data: {
          conversationId,
          conversation,
        },
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.invalid_body'),
          details: error.issues,
        });
        return;
      }

      if (error.message.includes('not found')) {
        res.status(404).json({
          success: false,
          error: error.message,
        });
        return;
      }

      if (error.message.includes('Invalid conversation participants') || error.message.includes('can only message')) {
        res.status(403).json({
          success: false,
          error: error.message,
        });
        return;
      }

      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create conversation',
      });
    }
  }

  /**
   * GET /messaging/conversations/:id/messages
   * Get messages for a conversation (paginated)
   */
  static async getMessages(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;
      const conversationId = parseInt(req.params.id!);

      if (isNaN(conversationId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.conversation_id_invalid'),
        });
        return;
      }

      // Validate query params
      const pageParam = req.query.page as string | undefined;
      const pageSizeParam = req.query.pageSize as string | undefined;

      const { page, pageSize } = GetMessagesSchema.parse({
        page: pageParam ? parseInt(pageParam) : 1,
        pageSize: pageSizeParam ? parseInt(pageSizeParam) : 50,
      });

      const result = await MessagingService.getMessages(
        conversationId,
        userId,
        page,
        pageSize
      );

      res.json({
        success: true,
        data: result.messages,
        pagination: {
          page: result.page,
          pageSize: result.pageSize,
          hasMore: result.hasMore,
        },
      });
    } catch (error: any) {
      if (error.message.includes('not a member')) {
        res.status(403).json({
          success: false,
          error: error.message,
        });
        return;
      }

      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.messages_fetch_error'),
      });
    }
  }

  /**
   * GET /messaging/conversations/:id/search
   * Search messages within a conversation
   */
  static async searchMessages(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;
      const conversationId = parseInt(req.params.id!);
      const query = req.query.q as string;
      const limitParam = req.query.limit as string | undefined;

      if (isNaN(conversationId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.conversation_id_invalid'),
        });
        return;
      }

      if (!query || query.trim().length < 2) {
        res.status(400).json({
          success: false,
          error: 'Search query must be at least 2 characters',
        });
        return;
      }

      // Verify user is member of conversation
      const isMember = await ConversationModel.isUserMember(conversationId, userId);
      if (!isMember) {
        res.status(403).json({
          success: false,
          error: 'Not a member of this conversation',
        });
        return;
      }

      const limit = limitParam ? Math.min(parseInt(limitParam), 50) : 50;
      const messages = await MessageModel.searchByContent(
        conversationId,
        query.trim(),
        userId,
        limit
      );

      res.json({
        success: true,
        data: messages,
        query: query.trim(),
        count: messages.length,
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Search failed',
      });
    }
  }

  /**
   * POST /messaging/conversations/:id/messages
   * Send a message in a conversation
   */
  static async sendMessage(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;
      const conversationId = parseInt(req.params.id!);

      if (isNaN(conversationId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.conversation_id_invalid'),
        });
        return;
      }

      // Validate body
      const { content } = SendMessageSchema.parse(req.body);

      const message = await MessagingService.sendMessage(
        conversationId,
        userId,
        content
      );

      res.json({
        success: true,
        data: message,
      });
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.invalid_body'),
          details: error.issues,
        });
        return;
      }

      if (error.message.includes('not a member')) {
        res.status(403).json({
          success: false,
          error: error.message,
        });
        return;
      }

      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.send_error'),
      });
    }
  }

  /**
   * POST /messaging/messages/:id/read
   * Mark message as read
   */
  static async markAsRead(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;
      const messageId = parseInt(req.params.id!);

      if (isNaN(messageId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.message_id_invalid'),
        });
        return;
      }

      await MessagingService.markMessageAsRead(messageId, userId);

      res.json({
        success: true,
        message: req.t('messaging.read_success'),
      });
    } catch (error: any) {
      if (error.message.includes('not found')) {
        res.status(404).json({
          success: false,
          error: error.message,
        });
        return;
      }

      if (error.message.includes('not a member')) {
        res.status(403).json({
          success: false,
          error: error.message,
        });
        return;
      }

      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.read_error'),
      });
    }
  }

  /**
   * POST /messaging/conversations/:id/read
   * Mark all messages in a conversation as read
   */
  static async markConversationAsRead(req: Request, res: Response): Promise<void> {
    try {
      const userId = (req.user as any).id;
      const conversationId = parseInt(req.params.id!);

      console.log(`[markConversationAsRead] userId: ${userId}, conversationId: ${conversationId}`);

      if (isNaN(conversationId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.conversation_id_invalid'),
        });
        return;
      }

      await MessagingService.markAllAsRead(conversationId, userId);
      console.log(`[markConversationAsRead] Successfully marked conversation ${conversationId} as read for user ${userId}`);

      // Emit socket event to notify sender that messages were read
      socketManager.emitToConversation(conversationId, 'message:read', {
        conversationId,
        userId,
        readAt: new Date().toISOString(),
      });

      res.json({
        success: true,
        message: req.t('messaging.conversation_read_success'),
      });
    } catch (error: any) {
      console.error(`[markConversationAsRead] Error:`, error);
      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.read_error'),
      });
    }
  }

  /**
   * GET /messaging/users/:id/presence
   * Get user presence status
   */
  static async getUserPresence(req: Request, res: Response): Promise<void> {
    try {
      const userId = parseInt(req.params.id!);

      if (isNaN(userId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.user_id_invalid'),
        });
        return;
      }

      const presence = await MessagingService.getUserPresence(userId);

      res.json({
        success: true,
        data: presence || {
          user_id: userId,
          status: 'offline',
          last_seen_at: null,
        },
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || req.t('messaging.presence_fetch_error'),
      });
    }
  }

  /**
   * POST /messaging/conversations/:id/attachment
   * Send a message with an attachment (doctors only)
   */
  static async sendAttachment(req: Request, res: Response): Promise<void> {
    try {
      const user = req.user as any;
      const userId = user.id;
      const userRole = user.role;
      const conversationId = parseInt(req.params.id!);

      // Only doctors can send attachments
      if (userRole !== 'doctor') {
        res.status(403).json({
          success: false,
          error: 'Only doctors can send attachments',
        });
        return;
      }

      if (isNaN(conversationId)) {
        res.status(400).json({
          success: false,
          error: req.t('messaging.conversation_id_invalid'),
        });
        return;
      }

      // Check if user is member of conversation
      const isMember = await ConversationModel.isUserMember(conversationId, userId);
      if (!isMember) {
        res.status(403).json({
          success: false,
          error: 'You are not a member of this conversation',
        });
        return;
      }

      // Check if file was uploaded
      const file = req.file;
      if (!file) {
        res.status(400).json({
          success: false,
          error: 'No file uploaded',
        });
        return;
      }

      // Determine file type
      const ext = path.extname(file.originalname).toLowerCase();
      const isImage = ['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(ext);
      const attachmentType: 'image' | 'pdf' = isImage ? 'image' : 'pdf';

      // Create the attachment URL (relative path for serving)
      const attachmentUrl = `/uploads/message_attachments/${file.filename}`;

      // Get optional message content
      const content = req.body.content || '';

      // Create message with attachment
      const message = await MessageModel.create(
        conversationId,
        userId,
        content,
        {
          url: attachmentUrl,
          type: attachmentType,
          name: file.originalname,
        }
      );

      // Get sender name for socket emission
      const senderName = `${user.name || ''} ${user.family_name || ''}`.trim() || 'Doctor';

      // Emit to conversation room
      socketManager.emitToConversation(conversationId, 'message:new', {
        message: {
          ...message,
          sender_name: senderName,
          is_read: false,
        },
        conversationId,
        senderId: userId,
      });

      // Also emit directly to recipient for instant notification
      const recipientId = await ConversationModel.getOtherUserId(conversationId, userId);
      if (recipientId) {
        socketManager.emitToUser(recipientId, 'message:new', {
          message: {
            ...message,
            sender_name: senderName,
            is_read: false,
          },
          conversationId,
          senderId: userId,
        });
      }

      res.json({
        success: true,
        data: {
          ...message,
          sender_name: senderName,
        },
      });
    } catch (error: any) {
      console.error('Error sending attachment:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to send attachment',
      });
    }
  }
}
