import type { Request, Response } from "express";
import { AppointmentModel, type CreateAppointmentData, type UpdateAppointmentData } from "../models/appointment.model";
import { createAppointmentValidated, updateAppointmentValidated } from "../services/appointment.service";
import { DoctorModel } from "../models/doctor.model";
import { UserModel } from "../models/user.model";
import {
    notifyUser,
    notifyDoctorAppointmentConfirmed
} from "../services/notification.service";
import SocketManager from "../utils/socketManager";
import { AssistantModel } from "../models/assistant.model";

// check if doctor is valid
export const checkDoctor = async (doctorUserId: string, res: Response, req: Request): Promise<boolean> => {
    const doctor = await DoctorModel.findByUserId(Number(doctorUserId));
    if (!doctor) {
        res.status(400).json({ success: false, error: req.t('appointment.doctor_not_found') });
        return false;
    }
    return true;
}

const createAppointment = async (req: Request, res: Response) => {
    try {
        const { patient_id, date, time, duration, notes, color, confirmed_coming, is_done } = req.body;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patient_id || !date || !time) {
            return res.status(400).json({
                success: false,
                error: req.t('appointment.missing_fields')
            });
        }

        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }

        const result = await createAppointmentValidated(Number(doctorUserId), {
            patient_id,
            date,
            time,
            duration,
            notes,
            color,
            confirmed_coming,
            is_done
        });

        if (!result.ok) {
            return res.status(result.status).json({ success: false, error: result.error });
        }
        const appointment = result.appointment;

        // ✅ Notification: Appointment created
        // Notify the doctor about the new appointment
        try {
            const appointmentDate = new Date(appointment.date).toLocaleDateString('fr-FR');
            const patientName = `${appointment.patient_name} ${appointment.patient_family_name}`;

            await notifyUser(
                doctorUserId,
                'Nouveau rendez-vous créé',
                `Rendez-vous avec ${patientName} programmé le ${appointmentDate} à ${appointment.time}.`,
                'info',
                `/appointments/${appointment.id}`
            );
        } catch (notifError) {
            console.error('[Notification] Failed to send appointment creation notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Emit socket event for real-time update
        SocketManager.emitToUser(doctorUserId, 'appointment:created', appointment);
        // Emit to all assistants of the doctor
        const assistants = await AssistantModel.findActiveBydoctorId(doctorUserId);
        assistants.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'appointment:created', appointment);
            }
        });

        return res.status(201).json({
            success: true,
            message: req.t('appointment.created_success'),
            data: appointment
        });
    } catch (error) {
        console.error("Error creating appointment:", error);
        return res.status(500).json({
            success: false,
            error: req.t('appointment.create_error')
        });
    }
};

const updateAppointment = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('appointment.id_required')
            });
        }

        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }

        const result = await updateAppointmentValidated(Number(doctorUserId), id, req.body);
        if (!result.ok) {
            return res.status(result.status).json({ success: false, error: result.error });
        }

        const updatedAppointment = result.appointment;

        // ✅ Notification: Appointment updated
        // Notify the doctor about appointment modification
        try {
            const appointmentDate = new Date(updatedAppointment.date).toLocaleDateString('fr-FR');
            const patientName = `${updatedAppointment.patient_name} ${updatedAppointment.patient_family_name}`;

            // Check if patient confirmed their attendance
            if (req.body.confirmed_coming === true) {
                await notifyDoctorAppointmentConfirmed(
                    doctorUserId,
                    patientName,
                    appointmentDate,
                    updatedAppointment.time,
                    updatedAppointment.id
                );
            } else {
                // General update notification
                await notifyUser(
                    doctorUserId,
                    'Rendez-vous modifié',
                    `Le rendez-vous avec ${patientName} du ${appointmentDate} à ${updatedAppointment.time} a été modifié.`,
                    'info',
                    `/appointments/${updatedAppointment.id}`
                );
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send appointment update notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Emit socket event for real-time update
        SocketManager.emitToUser(doctorUserId, 'appointment:updated', result.appointment);
        // Emit to all assistants of the doctor
        const assistantsUpdate = await AssistantModel.findActiveBydoctorId(doctorUserId);
        assistantsUpdate.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'appointment:updated', result.appointment);
            }
        });

        return res.status(200).json({
            success: true,
            message: req.t('appointment.updated_success'),
            data: result.appointment
        });
    } catch (error) {
        console.error("Error updating appointment:", error);
        return res.status(500).json({
            success: false,
            error: req.t('appointment.update_error')
        });
    }
};

const deleteAppointment = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('appointment.id_required')
            });
        }
        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }
        const appointment = await AppointmentModel.findById(id);
        if (!appointment) {
            return res.status(404).json({ success: false, error: "Appointment not found" });
        }
        if (appointment.doctor_user_id !== Number(doctorUserId)) {
            return res.status(403).json({ success: false, error: "Appointment does not belong to the specified doctor" });
        }

        // Store appointment info before deletion for notification
        const appointmentDate = new Date(appointment.date).toLocaleDateString('fr-FR');
        const patientName = `${appointment.patient_name} ${appointment.patient_family_name}`;
        const appointmentTime = appointment.time;

        await AppointmentModel.delete(id);

        // ✅ Notification: Appointment cancelled/deleted
        // Notify the doctor about appointment cancellation
        try {
            await notifyUser(
                doctorUserId,
                'Rendez-vous annulé',
                `Le rendez-vous avec ${patientName} du ${appointmentDate} à ${appointmentTime} a été annulé.`,
                'alert',
                `/appointments`
            );
        } catch (notifError) {
            console.error('[Notification] Failed to send appointment deletion notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Emit socket event for real-time update
        SocketManager.emitToUser(doctorUserId, 'appointment:deleted', { id });
        // Emit to all assistants of the doctor
        const assistantsDelete = await AssistantModel.findActiveBydoctorId(doctorUserId);
        assistantsDelete.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'appointment:deleted', { id });
            }
        });

        return res.status(200).json({ success: true, message: req.t('appointment.deleted_success') });
    } catch (error) {
        console.error("Error deleting appointment:", error);
        return res.status(500).json({ success: false, error: req.t('appointment.delete_error') });
    }
};

const getAppointment = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        if (!id) {
            return res.status(400).json({ success: false, error: req.t('appointment.id_required') });
        }
        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }
        const appointment = await AppointmentModel.findById(id);
        if (!appointment) {
            return res.status(404).json({ success: false, error: req.t('appointment.not_found') });
        }
        if (appointment.doctor_user_id !== Number(doctorUserId)) {
            return res.status(403).json({ success: false, error: req.t('appointment.not_belong_doctor') });
        }

        return res.status(200).json({ success: true, data: appointment });
    } catch (error) {
        console.error("Error getting appointment:", error);
        return res.status(500).json({ success: false, error: req.t('appointment.get_error') });
    }
};

const getAllAppointments = async (req: Request, res: Response) => {
    try {
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: "doctorUserId is required" });
        }
        const appointments = await AppointmentModel.findByDoctorUserId(Number(doctorUserId), limit, offset);

        // Return all appointments for today (regardless of time) plus all future dates
        const now = new Date();
        const today = new Date(now);
        today.setHours(0, 0, 0, 0);

        const upcoming = appointments.filter((a) => {
            const apptDateObj = new Date(a.date);
            const apptDay = new Date(apptDateObj);
            apptDay.setHours(0, 0, 0, 0);

            if (apptDay >= today) return true;         // today or any future date
            return false;                               // past dates excluded
        });

        return res.status(200).json({ success: true, data: upcoming, count: upcoming.length });
    } catch (error) {
        console.error("Error getting appointments:", error);
        return res.status(500).json({ success: false, error: req.t('appointment.get_all_error') });
    }
};

const getAppointmentsByDate = async (req: Request, res: Response) => {
    try {
        const { date } = req.query as { date?: string };
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        const limit = parseInt(req.query.limit as string) || 100;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!date) {
            return res.status(400).json({ success: false, error: req.t('appointment.date_required') });
        }
        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }
        const parsedDate = new Date(date);
        if (isNaN(parsedDate.getTime())) {
            return res.status(400).json({ success: false, error: req.t('appointment.date_invalid') });
        }

        const appointments = await AppointmentModel.findByDateAndDoctor(parsedDate, Number(doctorUserId), limit, offset);
        return res.status(200).json({ success: true, data: appointments, count: appointments.length });
    } catch (error) {
        console.error("Error getting appointments by date:", error);
        return res.status(500).json({ success: false, error: req.t('appointment.get_by_date_error') });
    }
};

const getAppointmentsByPatient = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!patientId) {
            return res.status(400).json({ success: false, error: req.t('appointment.patient_id_required') });
        }
        if (doctorUserId === undefined) {
            return res.status(400).json({ success: false, error: req.t('appointment.doctor_user_id_required') });
        }
        const appointments = await AppointmentModel.findByPatientAndDoctor(patientId, Number(doctorUserId), limit, offset);
        return res.status(200).json({ success: true, data: appointments, count: appointments.length });
    } catch (error) {
        console.error("Error getting appointments by patient:", error);
        return res.status(500).json({ success: false, error: req.t('appointment.get_by_patient_error') });
    }
};

export {
    createAppointment,
    updateAppointment,
    getAppointment,
    getAllAppointments,
    getAppointmentsByDate,
    getAppointmentsByPatient,
    deleteAppointment
};