import type { Request, Response } from 'express';
import { MedicalShareModel } from '../models/medicalShare.model';
import { MedicalShareAuditLogModel } from '../models/medicalShareAuditLog.model';
import { DoctorModel } from '../models/doctor.model';
import { PatientModel } from '../models/patient.model';
import pool from '../db';

// Créer un partage
export const createShare = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { 
            patient_id, 
            shared_with_doctor_ids, // Array d'IDs de médecins
            share_prescriptions,
            share_medical_reports,
            share_dental_acts,
            visible_until_date,
            expires_at,
            reason
        } = req.body;

        if (!patient_id || !shared_with_doctor_ids || !Array.isArray(shared_with_doctor_ids) || shared_with_doctor_ids.length === 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'patient_id et shared_with_doctor_ids sont requis' 
            });
        }

        if (!expires_at) {
            return res.status(400).json({ 
                success: false, 
                error: 'expires_at est requis' 
            });
        }

        if (!reason || reason.trim().length === 0) {
            return res.status(400).json({ 
                success: false, 
                error: 'La raison du partage est requise' 
            });
        }

        // Get current doctor info for audit log
        const currentDoctorQuery = await pool.query(
            'SELECT u.id, u.name, u.family_name, u.email FROM users u WHERE u.id = $1',
            [userId]
        );
        const currentDoctor = currentDoctorQuery.rows[0];
        if (!currentDoctor) {
            return res.status(404).json({ success: false, error: 'Médecin non trouvé' });
        }

        // Get patient info for audit log
        const patient = await PatientModel.findById(patient_id);
        const patientName = patient ? `${patient.name} ${patient.family_name}` : `Patient ID: ${patient_id}`;

        const shares = [];
        const auditLogs = [];
        
        for (const doctorId of shared_with_doctor_ids) {
            // Ne pas permettre de se partager à soi-même
            if (doctorId === userId) continue;

            // Get target doctor info for audit log
            const targetDoctorQuery = await pool.query(
                'SELECT u.id, u.name, u.family_name, u.email FROM users u WHERE u.id = $1',
                [doctorId]
            );
            const targetDoctor = targetDoctorQuery.rows[0];
            if (!targetDoctor) continue;
            
            const share = await MedicalShareModel.create({
                shared_by_doctor_id: userId,
                patient_id,
                shared_with_doctor_id: doctorId,
                share_prescriptions: share_prescriptions ?? true,
                share_medical_reports: share_medical_reports ?? true,
                share_dental_acts: share_dental_acts ?? true,
                visible_until_date: visible_until_date ? new Date(visible_until_date) : null,
                expires_at: new Date(expires_at),
                reason: reason.trim()
            });
            
            shares.push(share);

            // Create audit log for legal compliance
            const auditLog = await MedicalShareAuditLogModel.create({
                doctor_user_id: userId,
                doctor_name: currentDoctor.name,
                doctor_family_name: currentDoctor.family_name,
                doctor_email: currentDoctor.email,
                patient_id,
                patient_name: patientName,
                shared_with_doctor_id: doctorId,
                shared_with_doctor_name: targetDoctor.name,
                shared_with_doctor_family_name: targetDoctor.family_name,
                shared_with_doctor_email: targetDoctor.email,
                share_prescriptions: share_prescriptions ?? true,
                share_medical_reports: share_medical_reports ?? true,
                visible_until_date: visible_until_date ? new Date(visible_until_date) : null,
                expires_at: new Date(expires_at),
                reason: reason.trim(),
                patient_informed_confirmed: true,
                action_type: 'share_created',
                medical_share_id: share.id,
                ip_address: req.ip || req.headers['x-forwarded-for'] as string || undefined,
                user_agent: req.headers['user-agent'] || undefined
            });
            auditLogs.push(auditLog);
        }

        console.log(`📋 Audit: Dr. ${currentDoctor.name} ${currentDoctor.family_name} shared patient ${patientName} with ${shares.length} doctor(s). Reason: ${reason.trim()}`);

        return res.status(201).json({
            success: true,
            data: shares,
            message: `Dossier partagé avec ${shares.length} médecin(s)`,
            audit_logged: true
        });
    } catch (error: any) {
        console.error('Error creating medical share:', error);
        return res.status(500).json({ 
            success: false, 
            error: error.message || 'Erreur lors de la création du partage' 
        });
    }
};

// Lister les partages d'un patient (créés par le médecin connecté)
export const getSharesByPatient = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { patientId } = req.params;
        if (!patientId) {
            return res.status(400).json({ success: false, error: 'patientId requis' });
        }

        const shares = await MedicalShareModel.findByPatientAndDoctor(patientId, userId);

        return res.status(200).json({
            success: true,
            data: shares
        });
    } catch (error: any) {
        console.error('Error fetching medical shares:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération des partages' 
        });
    }
};

// Lister les partages reçus par le médecin connecté
export const getReceivedShares = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const shares = await MedicalShareModel.findSharedWithDoctor(userId);

        return res.status(200).json({
            success: true,
            data: shares
        });
    } catch (error: any) {
        console.error('Error fetching received shares:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération des partages reçus' 
        });
    }
};

// Révoquer un partage
export const revokeShare = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { id } = req.params;
        if (!id) {
            return res.status(400).json({ success: false, error: 'id requis' });
        }

        const revoked = await MedicalShareModel.revoke(parseInt(id), userId);

        if (!revoked) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé ou vous n\'avez pas les droits' 
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Partage révoqué avec succès'
        });
    } catch (error: any) {
        console.error('Error revoking medical share:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la révocation du partage' 
        });
    }
};

// Supprimer un partage
export const deleteShare = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { id } = req.params;
        if (!id) {
            return res.status(400).json({ success: false, error: 'id requis' });
        }

        const deleted = await MedicalShareModel.delete(parseInt(id), userId);

        if (!deleted) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé ou vous n\'avez pas les droits' 
            });
        }

        return res.status(200).json({
            success: true,
            message: 'Partage supprimé avec succès'
        });
    } catch (error: any) {
        console.error('Error deleting medical share:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la suppression du partage' 
        });
    }
};

// Rechercher des médecins pour le partage
export const searchDoctorsForShare = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { q } = req.query;

        if (!q || typeof q !== 'string' || q.length < 2) {
            return res.status(200).json({
                success: true,
                data: []
            });
        }

        const doctors = await DoctorModel.searchForShare(q, userId);

        return res.status(200).json({
            success: true,
            data: doctors
        });
    } catch (error: any) {
        console.error('Error searching doctors:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la recherche de médecins' 
        });
    }
};

// Récupérer les prescriptions via token de partage
export const getSharedPrescriptions = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { token } = req.params;
        if (!token) {
            return res.status(400).json({ success: false, error: 'Token requis' });
        }

        const share = await MedicalShareModel.findByToken(token, userId);

        if (!share) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé, expiré ou vous n\'avez pas les droits d\'accès' 
            });
        }

        if (!share.share_prescriptions) {
            return res.status(403).json({ 
                success: false, 
                error: 'Les prescriptions ne sont pas incluses dans ce partage' 
            });
        }

        // Use the prescription model to fetch prescriptions properly
        const { PrescriptionModel } = await import('../models/prescription.model');
        let prescriptions = await PrescriptionModel.findByPatientId(share.patient_id, 50, 0);

        // Filter by visible_until_date if set
        // IMPORTANT: Only apply date filter to OTHER doctors' prescriptions, NOT the requesting doctor's own prescriptions
        // NOTE: Use local date (not UTC) to avoid timezone issues
        if (share.visible_until_date) {
            const getLocalDateStr = (date: Date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            const visibleDateStr = getLocalDateStr(new Date(share.visible_until_date));
            prescriptions = prescriptions.filter(p => {
                // Always show the requesting doctor's own prescriptions (no date restriction)
                if (p.doctor_user_id === userId) {
                    return true;
                }
                // Apply date filter only to other doctors' prescriptions
                // Compare local date strings (YYYY-MM-DD) to handle timezone correctly
                const createdDateStr = getLocalDateStr(new Date(p.created_at));
                return createdDateStr >= visibleDateStr;
            });
        }

        return res.status(200).json({
            success: true,
            prescriptions: prescriptions
        });
    } catch (error: any) {
        console.error('Error fetching shared prescriptions:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération des prescriptions' 
        });
    }
};

// Récupérer les comptes rendus via token de partage
export const getSharedMedicalReports = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { token } = req.params;
        if (!token) {
            return res.status(400).json({ success: false, error: 'Token requis' });
        }

        const share = await MedicalShareModel.findByToken(token, userId);

        if (!share) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé, expiré ou vous n\'avez pas les droits d\'accès' 
            });
        }

        if (!share.share_medical_reports) {
            return res.status(403).json({ 
                success: false, 
                error: 'Les comptes rendus ne sont pas inclus dans ce partage' 
            });
        }

        // Use the medical report model to fetch reports properly
        const { MedicalReportModel } = await import('../models/medicalReport.model');
        let reports = await MedicalReportModel.findByPatientId(share.patient_id, 50, 0);

        // Filter by visible_until_date if set
        // IMPORTANT: Only apply date filter to OTHER doctors' reports, NOT the requesting doctor's own reports
        // NOTE: Use local date (not UTC) to avoid timezone issues
        if (share.visible_until_date) {
            const getLocalDateStr = (date: Date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            const visibleDateStr = getLocalDateStr(new Date(share.visible_until_date));
            reports = reports.filter(r => {
                // Always show the requesting doctor's own reports (no date restriction)
                if (r.doctor_user_id === userId) {
                    return true;
                }
                // Apply date filter only to other doctors' reports
                // Compare local date strings (YYYY-MM-DD) to handle timezone correctly
                const createdDateStr = getLocalDateStr(new Date(r.created_at));
                return createdDateStr >= visibleDateStr;
            });
        }

        return res.status(200).json({
            success: true,
            reports: reports
        });
    } catch (error: any) {
        console.error('Error fetching shared medical reports:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération des comptes rendus' 
        });
    }
};

// Récupérer les actes dentaires via token de partage
export const getSharedDentalActs = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { token } = req.params;
        if (!token) {
            return res.status(400).json({ success: false, error: 'Token requis' });
        }

        const share = await MedicalShareModel.findByToken(token, userId);

        if (!share) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé, expiré ou vous n\'avez pas les droits d\'accès' 
            });
        }

        if (!share.share_dental_acts) {
            return res.status(403).json({ 
                success: false, 
                error: 'Les actes dentaires ne sont pas inclus dans ce partage' 
            });
        }

        // Use the dental act model to fetch dental acts
        const { DentalActModel } = await import('../models/dentalAct.model');
        let dentalActs = await DentalActModel.findByPatientId(share.patient_id);

        // Filter by visible_until_date if set
        if (share.visible_until_date) {
            const getLocalDateStr = (date: Date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            const visibleDateStr = getLocalDateStr(new Date(share.visible_until_date));
            dentalActs = dentalActs.filter(a => {
                // Always show the requesting doctor's own dental acts (no date restriction)
                if (a.doctor_user_id === userId) {
                    return true;
                }
                // Apply date filter only to other doctors' dental acts
                const createdDateStr = getLocalDateStr(new Date(a.created_at));
                return createdDateStr >= visibleDateStr;
            });
        }

        return res.status(200).json({
            success: true,
            dental_acts: dentalActs
        });
    } catch (error: any) {
        console.error('Error fetching shared dental acts:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération des actes dentaires' 
        });
    }
};

// Accéder à un partage via token unique
export const getShareByToken = async (req: Request, res: Response) => {
    try {
        const userId = (req as any).user?.id;
        if (!userId) {
            return res.status(401).json({ success: false, error: 'Non authentifié' });
        }

        const { token } = req.params;
        if (!token) {
            return res.status(400).json({ success: false, error: 'Token requis' });
        }

        const share = await MedicalShareModel.findByToken(token, userId);

        if (!share) {
            return res.status(404).json({ 
                success: false, 
                error: 'Partage non trouvé, expiré ou vous n\'avez pas les droits d\'accès' 
            });
        }

        return res.status(200).json({
            success: true,
            data: share
        });
    } catch (error: any) {
        console.error('Error fetching share by token:', error);
        return res.status(500).json({ 
            success: false, 
            error: 'Erreur lors de la récupération du partage' 
        });
    }
};
