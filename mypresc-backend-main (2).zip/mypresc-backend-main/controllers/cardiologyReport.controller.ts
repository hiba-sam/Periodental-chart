import type { Request, Response } from 'express';
import { CardiologyReportModel } from '../models/cardiologyReport.model.js';
import type { CardiologyReport } from '../models/cardiologyReport.model.js';
import { generateCardiologyReportPdf } from '../utils/cardiologyReportPdf.js';

// ============================================
// ROBUST TYPE HELPERS — handle pg/Bun string coercion
// PostgreSQL via pg under Bun may return 't'/'f' strings
// instead of true/false for BOOLEAN columns.
// ============================================
function toBool(v: any): boolean {
    if (typeof v === 'boolean') return v;
    if (typeof v === 'string') return v === 'true' || v === 't' || v === '1';
    if (typeof v === 'number') return v !== 0;
    return false;
}

function toNum(v: any): number | null {
    if (v == null) return null;
    if (typeof v === 'number') return v;
    const n = Number(v);
    return isNaN(n) ? null : n;
}

// ============================================
// SCORE CALCULATION FUNCTIONS (server-side, authoritative)
// ============================================

function calcCHA2DS2VASc(r: Partial<CardiologyReport>): number | null {
    // Requires at least age + sex to be meaningful
    const age = toNum(r.patient_age);
    if (age == null || !r.patient_sex) return null;
    let score = 0;
    if (toBool(r.has_heart_failure)) score += 1;
    if (toBool(r.has_hta)) score += 1;
    if (age >= 75) score += 2;
    else if (age >= 65) score += 1;
    if (toBool(r.has_diabetes)) score += 1;
    if (toBool(r.has_stroke)) score += 2;
    if (toBool(r.has_arteriopathy)) score += 1;
    if (r.patient_sex === 'femme') score += 1;
    return score;
}

function calcHASBLED(r: Partial<CardiologyReport>): number | null {
    const age = toNum(r.patient_age);
    if (age == null) return null;
    let score = 0;
    // H - Hypertension (PAS > 160)
    const sbp = toNum(r.systolic_bp);
    if (toBool(r.has_hta) && sbp != null && sbp > 160) score += 1;
    // A - Abnormal renal function (creatinine > 200 µmol/L)
    const creat = toNum(r.bio_creatinine) ?? toNum(r.creatinine);
    if (creat != null && creat > 200) score += 1;
    // A - Abnormal liver function
    if (toBool(r.has_hepatic_anomaly)) score += 1;
    // S - Stroke
    if (toBool(r.has_stroke)) score += 1;
    // B - Bleeding history
    if (toBool(r.has_bleeding_history)) score += 1;
    // L - Labile INR
    const inr = toNum(r.bio_inr);
    if (inr != null && (inr < 2 || inr > 3)) score += 1;
    // E - Elderly (> 65)
    if (age > 65) score += 1;
    // D - Drugs (NSAIDs / antiplatelets)
    if (toBool(r.has_nsaid_antiplatelet)) score += 1;
    // D - Alcohol
    if (toBool(r.has_excessive_alcohol)) score += 1;
    return score;
}

function calcGRACE(r: Partial<CardiologyReport>): number | null {
    if (r.patient_age == null || r.heart_rate == null || r.systolic_bp == null) return null;
    let score = 0;

    // Age points
    const age = r.patient_age;
    if (age < 30) score += 0;
    else if (age < 40) score += 8;
    else if (age < 50) score += 25;
    else if (age < 60) score += 41;
    else if (age < 70) score += 58;
    else if (age < 80) score += 75;
    else if (age < 90) score += 91;
    else score += 100;

    // Heart rate points
    const hr = r.heart_rate;
    if (hr < 50) score += 0;
    else if (hr < 70) score += 3;
    else if (hr < 90) score += 9;
    else if (hr < 110) score += 15;
    else if (hr < 150) score += 24;
    else if (hr < 200) score += 38;
    else score += 46;

    // Systolic BP (inverse)
    const sbp = r.systolic_bp;
    if (sbp < 80) score += 58;
    else if (sbp < 100) score += 53;
    else if (sbp < 120) score += 43;
    else if (sbp < 140) score += 34;
    else if (sbp < 160) score += 24;
    else if (sbp < 200) score += 10;
    else score += 0;

    // Creatinine
    const creat = r.bio_creatinine ?? r.creatinine;
    if (creat != null) {
        // Convert µmol/L to mg/dL: divide by 88.4
        const creatMgDl = creat / 88.4;
        if (creatMgDl < 0.4) score += 1;
        else if (creatMgDl < 0.8) score += 4;
        else if (creatMgDl < 1.2) score += 7;
        else if (creatMgDl < 1.6) score += 10;
        else if (creatMgDl < 2.0) score += 13;
        else if (creatMgDl < 4.0) score += 21;
        else score += 28;
    }

    // Killip class (approximate from NYHA/clinical signs)
    const killip = r.nyha_class ?? 1;
    if (killip === 1) score += 0;
    else if (killip === 2) score += 20;
    else if (killip === 3) score += 39;
    else if (killip === 4) score += 59;

    // Cardiac arrest: not directly tracked, skip
    if (toBool(r.ecg_st_deviation)) score += 28;
    const trop = toNum(r.bio_troponin);
    if (trop != null && trop > 0) score += 14;

    return score;
}

function calcFramingham(r: Partial<CardiologyReport>): number | null {
    if (r.patient_age == null || !r.patient_sex || r.bio_total_cholesterol == null ||
        r.bio_hdl == null || r.systolic_bp == null) return null;

    const age = r.patient_age;
    const isMale = r.patient_sex === 'homme';
    const tc = r.bio_total_cholesterol;
    const hdl = r.bio_hdl;
    const sbp = r.systolic_bp;
    const treated = toBool(r.has_hta);
    const smoker = toBool(r.has_active_smoking);
    const diabetes = toBool(r.has_diabetes);

    if (isMale) {
        // Simplified Framingham male calculation
        let points = 0;
        // Age
        if (age >= 20 && age <= 34) points += -9;
        else if (age <= 39) points += -4;
        else if (age <= 44) points += 0;
        else if (age <= 49) points += 3;
        else if (age <= 54) points += 6;
        else if (age <= 59) points += 8;
        else if (age <= 64) points += 10;
        else if (age <= 69) points += 11;
        else if (age <= 74) points += 12;
        else points += 13;

        // Total cholesterol (age-adjusted simplified)
        if (tc < 1.6) points += 0;
        else if (tc < 2.0) points += 4;
        else if (tc < 2.4) points += 7;
        else if (tc < 2.8) points += 9;
        else points += 11;

        // HDL
        if (hdl >= 0.6) points += -1;
        else if (hdl >= 0.5) points += 0;
        else if (hdl >= 0.4) points += 1;
        else points += 2;

        // SBP
        if (treated) {
            if (sbp < 120) points += 0;
            else if (sbp < 130) points += 1;
            else if (sbp < 140) points += 2;
            else if (sbp < 160) points += 2;
            else points += 3;
        } else {
            if (sbp < 120) points += 0;
            else if (sbp < 130) points += 0;
            else if (sbp < 140) points += 1;
            else if (sbp < 160) points += 1;
            else points += 2;
        }

        if (smoker) points += 8;
        if (diabetes) points += 5;

        // Points to risk % (simplified lookup)
        const riskTable: Record<number, number> = {
            0: 1, 1: 1, 2: 1, 3: 1, 4: 1, 5: 2, 6: 2, 7: 3, 8: 4,
            9: 5, 10: 6, 11: 8, 12: 10, 13: 12, 14: 16, 15: 20, 16: 25, 17: 30
        };
        const clampedPoints = Math.max(0, Math.min(17, points));
        return riskTable[clampedPoints] ?? (points < 0 ? 1 : 30);
    } else {
        // Female
        let points = 0;
        if (age >= 20 && age <= 34) points += -7;
        else if (age <= 39) points += -3;
        else if (age <= 44) points += 0;
        else if (age <= 49) points += 3;
        else if (age <= 54) points += 6;
        else if (age <= 59) points += 8;
        else if (age <= 64) points += 10;
        else if (age <= 69) points += 12;
        else if (age <= 74) points += 14;
        else points += 16;

        if (tc < 1.6) points += 0;
        else if (tc < 2.0) points += 4;
        else if (tc < 2.4) points += 8;
        else if (tc < 2.8) points += 11;
        else points += 13;

        if (hdl >= 0.6) points += -1;
        else if (hdl >= 0.5) points += 0;
        else if (hdl >= 0.4) points += 1;
        else points += 2;

        if (treated) {
            if (sbp < 120) points += 0;
            else if (sbp < 130) points += 3;
            else if (sbp < 140) points += 4;
            else if (sbp < 160) points += 5;
            else points += 6;
        } else {
            if (sbp < 120) points += 0;
            else if (sbp < 130) points += 1;
            else if (sbp < 140) points += 2;
            else if (sbp < 160) points += 3;
            else points += 4;
        }

        if (smoker) points += 9;
        if (diabetes) points += 7;

        const riskTable: Record<number, number> = {
            9: 1, 10: 1, 11: 1, 12: 1, 13: 2, 14: 2, 15: 3, 16: 4,
            17: 5, 18: 6, 19: 8, 20: 11, 21: 14, 22: 17, 23: 22, 24: 27, 25: 30
        };
        const clampedPoints = Math.max(9, Math.min(25, points));
        return riskTable[clampedPoints] ?? (points < 9 ? 1 : 30);
    }
}

// SCORE2 (<70 ans) / SCORE2-OP (≥70 ans) — ESC 2021
// Région de risque modéré (Algérie/Maghreb)
function calcSCORE2(r: Partial<CardiologyReport>): number | null {
    if (r.patient_age == null || !r.patient_sex || r.systolic_bp == null ||
        r.bio_total_cholesterol == null || r.bio_hdl == null) return null;

    const age = r.patient_age;
    const isMale = r.patient_sex === 'homme';
    const sbp = r.systolic_bp;
    const nonHDL = r.bio_total_cholesterol - r.bio_hdl;
    const smoker = toBool(r.has_active_smoking);
    const isOP = age >= 70;

    // Base risk by age/sex — moderate risk region
    let baseRisk: number;
    if (isOP) {
        // SCORE2-OP base risk tables (≥70 ans)
        if (isMale) {
            if (age < 75) baseRisk = 13.0;
            else if (age < 80) baseRisk = 16.0;
            else if (age < 85) baseRisk = 19.0;
            else baseRisk = 22.0;
        } else {
            if (age < 75) baseRisk = 9.0;
            else if (age < 80) baseRisk = 12.0;
            else if (age < 85) baseRisk = 15.0;
            else baseRisk = 18.0;
        }
    } else {
        // SCORE2 base risk tables (<70 ans)
        if (isMale) {
            if (age < 40) baseRisk = 0.5;
            else if (age < 50) baseRisk = 1.5;
            else if (age < 55) baseRisk = 3.0;
            else if (age < 60) baseRisk = 4.5;
            else if (age < 65) baseRisk = 6.5;
            else baseRisk = 9.0;
        } else {
            if (age < 40) baseRisk = 0.3;
            else if (age < 50) baseRisk = 0.8;
            else if (age < 55) baseRisk = 1.5;
            else if (age < 60) baseRisk = 2.5;
            else if (age < 65) baseRisk = 4.0;
            else baseRisk = 6.0;
        }
    }

    // Risk modifiers (common to SCORE2 and SCORE2-OP)
    let modifier = 1.0;
    if (smoker) modifier *= 2.0;
    if (sbp >= 160) modifier *= 1.8;
    else if (sbp >= 140) modifier *= 1.4;
    else if (sbp >= 120) modifier *= 1.1;
    // Non-HDL cholesterol (g/L): >1.6 increases risk
    if (nonHDL > 1.9) modifier *= 1.6;
    else if (nonHDL > 1.6) modifier *= 1.3;
    else if (nonHDL > 1.3) modifier *= 1.1;

    return Math.round(baseRisk * modifier * 10) / 10;
}

function calcEuroSCORE2(r: Partial<CardiologyReport>): number | null {
    // Requires pre-op data to be meaningful
    if (!r.preop_urgency && !r.preop_surgery_type) return null;
    if (r.patient_age == null || !r.patient_sex) return null;

    // Simplified EuroSCORE II logistic model
    let logit = -5.324;

    // Age (per year over 60)
    const age = r.patient_age;
    if (age > 60) logit += 0.0285181 * (age - 60);

    // Female
    if (r.patient_sex === 'femme') logit += 0.2196434;

    // Creatinine clearance (Cockcroft-Gault)
    const creat = r.bio_creatinine ?? r.creatinine;
    if (creat && r.patient_weight && age) {
        const sexFactor = r.patient_sex === 'femme' ? 0.85 : 1.0;
        const clCr = ((140 - age) * r.patient_weight * sexFactor) / (0.814 * creat);
        if (clCr < 50) logit += 0.6421508;
        else if (clCr < 85) logit += 0.3034948;
    }
    if (toBool(r.preop_dialysis)) logit += 0.6421508;

    // Extracardiac arteriopathy
    if (toBool(r.has_arteriopathy)) logit += 0.5360268;

    // Reduced mobility
    if (toBool(r.has_reduced_mobility)) logit += 0.2407181;

    // Previous cardiac surgery
    if (toBool(r.has_prior_cardiac_surgery)) logit += 1.118599;

    // Chronic lung disease
    if (toBool(r.has_chronic_lung_disease)) logit += 0.1886564;

    // Active endocarditis
    if (toBool(r.has_endocarditis)) logit += 0.6194522;

    // Critical preoperative state
    if (toBool(r.preop_critical_state)) logit += 0.9058132;

    // Diabetes on insulin
    if (toBool(r.has_diabetes_insulin)) logit += 0.3542749;

    // NYHA class
    const nyha = r.nyha_class ?? 1;
    if (nyha === 2) logit += 0.1070545;
    else if (nyha === 3) logit += 0.2958358;
    else if (nyha === 4) logit += 0.5597929;

    // LVEF
    const lvef = r.echo_lvef ?? r.known_lvef;
    if (lvef != null) {
        if (lvef < 21) logit += 0.9346919;
        else if (lvef < 31) logit += 0.5460218;
        else if (lvef < 51) logit += 0.2407181;
    }

    // Pulmonary hypertension
    if (r.echo_pulmonary_htn != null) {
        if (r.echo_pulmonary_htn > 55) logit += 0.5983526;
        else if (r.echo_pulmonary_htn > 31) logit += 0.1886564;
    }

    // Urgency
    if (r.preop_urgency === 'urgent') logit += 0.3174673;
    else if (r.preop_urgency === 'emergency') logit += 0.7039121;
    else if (r.preop_urgency === 'salvage') logit += 1.362947;

    // Thoracic aorta surgery
    if (toBool(r.preop_thoracic_aorta)) logit += 0.6527205;

    // Predicted mortality
    const mortality = (Math.exp(logit) / (1 + Math.exp(logit))) * 100;
    return Math.round(mortality * 100) / 100;
}

function recalculateScores(data: Partial<CardiologyReport>): Partial<CardiologyReport> {
    const scores = {
        score_cha2ds2_vasc: calcCHA2DS2VASc(data),
        score_has_bled: calcHASBLED(data),
        score_grace: calcGRACE(data),
        score_framingham: calcFramingham(data),
        score_score2: calcSCORE2(data),
        score_nyha: data.nyha_class ?? null,
        score_euroscore2: calcEuroSCORE2(data),
    };
    // Diagnostic log — helps trace production type coercion issues
    console.log('[CardioScores] recalculate input types:', {
        has_hta: `${typeof data.has_hta}=${data.has_hta}`,
        has_diabetes: `${typeof data.has_diabetes}=${data.has_diabetes}`,
        has_stroke: `${typeof data.has_stroke}=${data.has_stroke}`,
        has_heart_failure: `${typeof data.has_heart_failure}=${data.has_heart_failure}`,
        patient_age: `${typeof data.patient_age}=${data.patient_age}`,
        patient_sex: `${typeof data.patient_sex}=${data.patient_sex}`,
    });
    console.log('[CardioScores] computed:', scores);
    return scores;
}

// ============================================
// CONTROLLER FUNCTIONS
// ============================================

/**
 * GET /api/patients/:patientId/cardiology-reports
 */
export const getPatientCardiologyReports = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const reports = await CardiologyReportModel.findByPatient(patientId);
        res.json({ success: true, data: reports });
    } catch (error) {
        console.error('Get cardiology reports error:', error);
        res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * POST /api/patients/:patientId/cardiology-reports
 */
export const createCardiologyReport = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const userId = req.user!.id;
        const body = req.body;

        // Recalculate scores server-side
        const scores = recalculateScores({ ...body, patient_id: patientId });

        const data = {
            ...body,
            ...scores,
            patient_id: patientId,
            doctor_user_id: userId,
        };

        const report = await CardiologyReportModel.create(data);
        const fullReport = await CardiologyReportModel.findById(report.id);

        res.status(201).json({ success: true, data: fullReport });
    } catch (error) {
        console.error('Create cardiology report error:', error);
        res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * GET /api/cardiology-reports/:id
 */
export const getCardiologyReport = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id);
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const report = await CardiologyReportModel.findById(id);
        if (!report) return res.status(404).json({ success: false, error: 'Report not found' });

        res.json({ success: true, data: report });
    } catch (error) {
        console.error('Get cardiology report error:', error);
        res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * PATCH /api/cardiology-reports/:id
 */
export const updateCardiologyReport = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id);
        const userId = req.user!.id;
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const existing = await CardiologyReportModel.findById(id);
        if (!existing) return res.status(404).json({ success: false, error: 'Report not found' });

        const hasAccess = await CardiologyReportModel.checkAccess(id, userId);
        if (!hasAccess) return res.status(403).json({ success: false, error: 'Not authorized' });

        // Merge existing + new data for score recalculation
        const merged = { ...existing, ...req.body };
        const scores = recalculateScores(merged);

        const updated = await CardiologyReportModel.update(id, { ...req.body, ...scores });
        res.json({ success: true, data: updated });
    } catch (error) {
        console.error('Update cardiology report error:', error);
        res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * DELETE /api/cardiology-reports/:id
 */
export const deleteCardiologyReport = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id);
        const userId = req.user!.id;
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const hasAccess = await CardiologyReportModel.checkAccess(id, userId);
        if (!hasAccess) return res.status(403).json({ success: false, error: 'Not authorized' });

        const deleted = await CardiologyReportModel.delete(id);
        if (!deleted) return res.status(404).json({ success: false, error: 'Report not found' });

        res.json({ success: true, message: 'Cardiology report deleted' });
    } catch (error) {
        console.error('Delete cardiology report error:', error);
        res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * GET /api/cardiology-reports/:id/pdf
 */
export const generateCardiologyReportPdfController = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id);
        const requestingDoctorId = (req.user as any)?.id;

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'Invalid ID' });
        }

        if (!requestingDoctorId) {
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        }

        await generateCardiologyReportPdf(id, res, requestingDoctorId);
    } catch (error) {
        console.error('Generate cardiology report PDF error:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};
