import type { Request, Response } from "express";
import { CalendarModel, type CreateCalendarEventData, type UpdateCalendarEventData } from "../models/calendar.model";
import { AppointmentModel, type UpdateAppointmentData } from "../models/appointment.model";
import { createAppointmentValidated, updateAppointmentValidated, type UpdateAppointmentInput } from "../services/appointment.service";
import { DoctorModel } from "../models/doctor.model";
import { PatientModel } from "../models/patient.model";
import { notifyUser, notifyCalendarEvent } from "../services/notification.service";
import { checkDoctor } from "./appointment.controller";
import SocketManager from "../utils/socketManager";
import { AssistantModel } from "../models/assistant.model";

// Check if doctor is valid


/**
 * Create a new calendar event
 * - Can be standalone (custom title, note, date, time)
 * - Can be linked to appointment (appointment object provided, creates both appointment and event)
 */
const createCalendarEvent = async (req: Request, res: Response) => {
    try {
        console.log(req.body);
        const { appointment, title, note, date, time, duration, color } = req.body;
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        let appointmentId: string | null = null;

        // Validate based on event type
        // Standalone event - require title, date, time
        if (!date || !time) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.standalone_fields_required')
            });
        }

        const parsedDate = new Date(date);
        if (isNaN(parsedDate.getTime())) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.date_invalid')
            });
        }
        const toTimeString = (d: Date) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
        const parseTimeOnDate = (baseDate: Date, t: string) => {
            const [hh, mm, ss] = (t || "00:00:00").split(":").map((v: string) => parseInt(v || "0", 10));
            const d = new Date(baseDate);
            d.setHours(hh || 0, mm || 0, ss || 0, 0);
            return d;
        };
        if (appointment) {
            const result = await createAppointmentValidated(Number(doctorUserId), {
                patient_id: appointment.patient_id,
                date: parsedDate,
                time: time,
                duration: duration ?? 15,
                notes: note ?? null,
                color: color ?? '#2563eb',
                confirmed_coming: appointment.confirmed_coming ?? false,
                is_done: appointment.is_done ?? false
            });
            if (!result.ok) {
                return res.status(result.status).json({ success: false, error: result.error });
            }
            console.log(result.appointment);
            appointmentId = result.appointment?.id ?? null;

            // Emit socket event for real-time update
            if (result.appointment) {
                SocketManager.emitToUser(Number(doctorUserId), 'appointment:created', result.appointment);
                const assistants = await AssistantModel.findActiveBydoctorId(Number(doctorUserId));
                assistants.forEach(assistant => {
                    if (assistant.user_id) {
                        SocketManager.emitToUser(assistant.user_id, 'appointment:created', result.appointment);
                    }
                });
            }
        }

        // Validate color format if provided
        if (color && !/^#([0-9A-F]{3}){1,2}$/i.test(color)) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.color_invalid')
            });
        }

        // If this is a standalone blocking "free" event, only detect overlaps and return conflict info (no modifications)
        if (!appointment && !appointmentId) {
            const durMin = (duration ?? 15) as number;
            const startDateTime = parseTimeOnDate(parsedDate, time);
            const endDateTime = new Date(startDateTime.getTime() + durMin * 60000);
            const startTimeStr = toTimeString(startDateTime);
            const endTimeStr = toTimeString(endDateTime);

            const overlapping = await CalendarModel.findInRange(Number(doctorUserId), parsedDate, startTimeStr, endTimeStr);
            if (overlapping.length > 0) {
                const conflicts = overlapping.map(ev => ({
                    id: ev.id,
                    appointment_id: ev.appointment_id,
                    title: ev.title,
                    date: ev.date,
                    time: ev.time,
                    duration: ev.duration
                }));
                return res.status(409).json({
                    success: false,
                    error: req.t('calendar.overlap_error'),
                    conflicts
                });
            }
        }

        const data: CreateCalendarEventData = {
            doctor_user_id: Number(doctorUserId),
            appointment_id: appointmentId,
            title: title ?? (appointmentId ? "Appointment" : "Event"),
            note,
            date: parsedDate, // Utiliser parsedDate pour garantir synchronisation avec appointment
            time,
            duration,
            color
        };

        const event = await CalendarModel.create(data);

        // ✅ Notification: Calendar event created
        // Notify the doctor about the new calendar event
        try {
            const eventDate = new Date(event.date).toLocaleDateString('fr-FR');
            const eventTitle = event.title || 'Événement';

            if (appointmentId && appointment) {
                // Appointment-linked event - get patient details
                const patient = await PatientModel.findById(appointment.patient_id);
                if (patient) {
                    const patientName = `${patient.name} ${patient.family_name}`;
                    await notifyUser(
                        Number(doctorUserId),
                        'Rendez-vous ajouté au calendrier',
                        `Rendez-vous avec ${patientName} ajouté au calendrier le ${eventDate} à ${event.time}.`,
                        'info',
                        `/calendar`
                    );
                }
            } else {
                // Standalone calendar event
                await notifyCalendarEvent(
                    Number(doctorUserId),
                    eventTitle,
                    eventDate,
                    event.time,
                    event.id
                );
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send calendar event creation notification:', notifError);
            // Don't fail the request if notification fails
        }

        return res.status(201).json({
            success: true,
            message: appointmentId
                ? req.t('calendar.created_linked_success')
                : req.t('calendar.created_success'),
            data: event
        });
    } catch (error: any) {
        console.error("Error creating calendar event:", error);
        return res.status(500).json({
            success: false,
            error: error.message || req.t('calendar.create_error')
        });
    }
};

/**
 * Update a calendar event
 * - If linked to appointment, updates the appointment first, then syncs calendar
 * - If standalone, updates calendar directly
 */
const updateCalendarEvent = async (req: Request, res: Response) => {
    try {
        console.log(req.body);
        const { id } = req.params;
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.id_required')
            });
        }

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        // Find the calendar event
        const calendarEvent = await CalendarModel.findById(id, Number(doctorUserId));
        if (!calendarEvent) {
            return res.status(404).json({
                success: false,
                error: req.t('calendar.not_found')
            });
        }

        // Validate color format if provided
        if (req.body.color && !/^#([0-9A-F]{3}){1,2}$/i.test(req.body.color)) {
            return res.status(400).json({
                success: false,
                error: "Invalid color format. Use hex color (e.g., #2563eb)"
            });
        }

        // Préparer les données de mise à jour
        const updateData: UpdateCalendarEventData = {};

        if (req.body.title !== undefined) updateData.title = req.body.title;
        if (req.body.note !== undefined) updateData.note = req.body.note;
        if (req.body.date !== undefined) {
            const parsedDate = new Date(req.body.date);
            if (isNaN(parsedDate.getTime())) {
                return res.status(400).json({ success: false, error: req.t('calendar.date_invalid') });
            }
            updateData.date = parsedDate;
        }
        if (req.body.time !== undefined) updateData.time = req.body.time;
        if (req.body.duration !== undefined) updateData.duration = req.body.duration;
        if (req.body.color !== undefined) updateData.color = req.body.color;

        let updatedAppointment = {} as UpdateAppointmentData | null;

        // ⚠️ IMPORTANT: Mettre à jour l'APPOINTMENT EN PREMIER si lié
        // Car le trigger sur calendar lit appointments.date pour synchroniser
        if (calendarEvent.appointment_id) {
            const updatePayload: UpdateAppointmentInput = {
                date: updateData.date,
                time: req.body.time,
                duration: req.body.duration,
                color: req.body.color,
                notes: req.body.appointment_notes,
                is_done: req.body.is_done,
                confirmed_coming: req.body.confirmed_coming,
                venue_confirmed: req.body.venue_confirmed
            };

            const result = await updateAppointmentValidated(Number(doctorUserId), calendarEvent.appointment_id!, updatePayload);
            if (!result.ok) {
                return res.status(result.status).json({ success: false, error: result.error });
            }

            updatedAppointment = result.appointment;

            // Emit socket event for real-time update
            if (result.appointment) {
                console.log(`[Calendar] Emitting appointment:updated to doctor ${doctorUserId}`);
                SocketManager.emitToUser(Number(doctorUserId), 'appointment:updated', result.appointment);
                const assistants = await AssistantModel.findActiveBydoctorId(Number(doctorUserId));
                console.log(`[Calendar] Found ${assistants.length} assistants for doctor ${doctorUserId}:`, assistants.map(a => a.user_id));
                assistants.forEach(assistant => {
                    if (assistant.user_id) {
                        console.log(`[Calendar] Emitting appointment:updated to assistant ${assistant.user_id}`);
                        SocketManager.emitToUser(assistant.user_id, 'appointment:updated', result.appointment);
                    }
                });
            }
        }

        // Maintenant mettre à jour le calendar (le trigger lira la date mise à jour)
        const updated = await CalendarModel.update(id as string, updateData);
        if (!updated) {
            return res.status(404).json({
                success: false,
                error: req.t('calendar.not_found_or_no_changes')
            });
        }

        // If the updated event is a standalone "free" blocker, only detect overlaps and return conflict info (no modifications)
        const maybeFree = (!calendarEvent.appointment_id) && (req.body.title ? String(req.body.title).trim().toLowerCase() === 'free' : (calendarEvent.title || '').trim().toLowerCase() === 'free');
        if (maybeFree) {
            const baseDate = req.body.date ? new Date(req.body.date) : calendarEvent.date;
            const baseTime = (req.body.time ?? calendarEvent.time) as string;
            const baseDuration = (req.body.duration ?? calendarEvent.duration) as number;
            const toTimeString = (d: Date) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
            const parseTimeOnDate = (d: Date, t: string) => {
                const [hh, mm, ss] = (t || '00:00:00').split(':').map((v: string) => parseInt(v || '0', 10));
                const x = new Date(d);
                x.setHours(hh || 0, mm || 0, ss || 0, 0);
                return x;
            };

            const startDateTime = parseTimeOnDate(baseDate, baseTime);
            const endDateTime = new Date(startDateTime.getTime() + baseDuration * 60000);
            const startTimeStr = toTimeString(startDateTime);
            const endTimeStr = toTimeString(endDateTime);

            const overlapping = await CalendarModel.findInRange(Number(doctorUserId), baseDate, startTimeStr, endTimeStr);
            const conflicts = overlapping.filter(ev => ev.id !== id).map(ev => ({
                id: ev.id,
                appointment_id: ev.appointment_id,
                title: ev.title,
                date: ev.date,
                time: ev.time,
                duration: ev.duration
            }));
            if (conflicts.length > 0) {
                return res.status(409).json({
                    success: false,
                    error: "Free event overlaps with existing items",
                    conflicts
                });
            }
        }

        const returnData = {
            ...updated,
            ...updatedAppointment,
            id: updated.id
        };

        // ✅ Notification: Calendar event updated
        // Notify the doctor about the calendar event modification
        try {
            const eventDate = new Date(updated.date).toLocaleDateString('fr-FR');
            const eventTitle = updated.title || 'Événement';

            if (calendarEvent.appointment_id && updatedAppointment) {
                // Appointment-linked event - get appointment details
                const appointment = await AppointmentModel.findById(calendarEvent.appointment_id);
                if (appointment) {
                    const patientName = `${appointment.patient_name} ${appointment.patient_family_name}`;
                    await notifyUser(
                        Number(doctorUserId),
                        'Rendez-vous modifié dans le calendrier',
                        `Le rendez-vous avec ${patientName} a été modifié: ${eventDate} à ${updated.time}.`,
                        'info',
                        `/calendar`
                    );
                }
            } else {
                // Standalone calendar event
                await notifyUser(
                    Number(doctorUserId),
                    'Événement calendrier modifié',
                    `"${eventTitle}" modifié: ${eventDate} à ${updated.time}.`,
                    'info',
                    `/calendar`
                );
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send calendar event update notification:', notifError);
            // Don't fail the request if notification fails
        }

        return res.status(200).json({
            success: true,
            message: req.t('calendar.updated_success'),
            data: returnData
        });
    } catch (error) {
        console.error("Error updating calendar event:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.update_error')
        });
    }
};

/**
 * Delete a calendar event
 * - If linked to appointment, deletes the appointment first (cascade will delete calendar event)
 * - If standalone, deletes calendar event directly
 */
const deleteCalendarEvent = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();

        if (!id) {
            return res.status(400).json({ success: false, error: req.t('calendar.id_required') });
        }

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        // Find the calendar event
        const calendarEvent = await CalendarModel.findById(id, Number(doctorUserId));
        if (!calendarEvent) {
            return res.status(404).json({ success: false, error: req.t('calendar.not_found') });
        }

        // Store event info before deletion for notification
        const eventDate = new Date(calendarEvent.date).toLocaleDateString('fr-FR');
        const eventTitle = calendarEvent.title || 'Événement';
        const eventTime = calendarEvent.time;

        // If event is linked to appointment, delete appointment first
        // (ON DELETE CASCADE will handle calendar event deletion)
        if (calendarEvent.appointment_id) {
            const appointment = await AppointmentModel.findById(calendarEvent.appointment_id);
            const patientName = appointment ? `${appointment.patient_name} ${appointment.patient_family_name}` : 'Patient';

            if (appointment) {
                await AppointmentModel.delete(calendarEvent.appointment_id);

                // Emit socket event for real-time update
                SocketManager.emitToUser(Number(doctorUserId), 'appointment:deleted', { id: calendarEvent.appointment_id });
                const assistants = await AssistantModel.findActiveBydoctorId(Number(doctorUserId));
                assistants.forEach(assistant => {
                    if (assistant.user_id) {
                        SocketManager.emitToUser(assistant.user_id, 'appointment:deleted', { id: calendarEvent.appointment_id });
                    }
                });
            }

            // ✅ Notification: Appointment-linked calendar event deleted
            try {
                await notifyUser(
                    Number(doctorUserId),
                    'Rendez-vous supprimé du calendrier',
                    `Le rendez-vous avec ${patientName} du ${eventDate} à ${eventTime} a été supprimé du calendrier.`,
                    'alert',
                    `/calendar`
                );
            } catch (notifError) {
                console.error('[Notification] Failed to send calendar event deletion notification:', notifError);
            }

            return res.status(200).json({
                success: true,
                message: req.t('calendar.deleted_linked_success')
            });
        }

        // Standalone event - delete calendar event directly
        const deleted = await CalendarModel.delete(id);
        if (!deleted) {
            return res.status(404).json({
                success: false,
                error: req.t('calendar.not_found')
            });
        }

        // ✅ Notification: Standalone calendar event deleted
        try {
            await notifyUser(
                Number(doctorUserId),
                'Événement calendrier supprimé',
                `"${eventTitle}" du ${eventDate} à ${eventTime} a été supprimé.`,
                'alert',
                `/calendar`
            );
        } catch (notifError) {
            console.error('[Notification] Failed to send calendar event deletion notification:', notifError);
        }

        return res.status(200).json({
            success: true,
            message: req.t('calendar.deleted_success')
        });
    } catch (error) {
        console.error("Error deleting calendar event:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.delete_error')
        });
    }
};

/**
 * Get a single calendar event by ID
 */
const getCalendarEvent = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();

        if (!id) {
            return res.status(400).json({ success: false, error: req.t('calendar.id_required') });
        }

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const event = await CalendarModel.findById(id, Number(doctorUserId));
        if (!event) {
            return res.status(404).json({ success: false, error: req.t('calendar.not_found') });
        }

        return res.status(200).json({ success: true, data: event });
    } catch (error) {
        console.error("Error getting calendar event:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_error')
        });
    }
};

/**
 * Get all calendar events for a doctor
 */
const getAllCalendarEvents = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        const limit = parseInt(req.query.limit as string) || 100;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const events = await CalendarModel.findAll(Number(doctorUserId), limit, offset);

        return res.status(200).json({
            success: true,
            data: events,
            count: events.length
        });
    } catch (error) {
        console.error("Error getting calendar events:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_all_error')
        });
    }
};

/**
 * Get calendar events by specific date
 */
const getCalendarEventsByDate = async (req: Request, res: Response) => {
    try {
        const { date } = req.query as { date?: string };
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();
        const limit = parseInt(req.query.limit as string) || 100;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!date) {
            return res.status(400).json({ success: false, error: req.t('calendar.date_required') });
        }

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const parsedDate = new Date(date);
        if (isNaN(parsedDate.getTime())) {
            return res.status(400).json({ success: false, error: req.t('calendar.date_invalid') });
        }

        const events = await CalendarModel.findByDate(parsedDate, Number(doctorUserId), limit, offset);

        return res.status(200).json({
            success: true,
            data: events,
            count: events.length
        });
    } catch (error) {
        console.error("Error getting calendar events by date:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_by_date_error')
        });
    }
};

/**
 * Get calendar events by date range
 */
const getCalendarEventsByDateRange = async (req: Request, res: Response) => {
    try {
        const { startDate, endDate } = req.query as {
            startDate?: string;
            endDate?: string;
        };
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();
        const limit = parseInt(req.query.limit as string) || 500;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!startDate || !endDate) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.range_required')
            });
        }

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const parsedStartDate = new Date(startDate);
        const parsedEndDate = new Date(endDate);

        if (isNaN(parsedStartDate.getTime()) || isNaN(parsedEndDate.getTime())) {
            return res.status(400).json({ success: false, error: req.t('calendar.date_invalid') });
        }

        if (parsedStartDate > parsedEndDate) {
            return res.status(400).json({
                success: false,
                error: req.t('calendar.range_invalid')
            });
        }

        const events = await CalendarModel.findByDateRange(
            parsedStartDate,
            parsedEndDate,
            Number(doctorUserId),
            limit,
            offset
        );

        return res.status(200).json({
            success: true,
            data: events,
            count: events.length
        });
    } catch (error) {
        console.error("Error getting calendar events by date range:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_by_range_error')
        });
    }
};

/**
 * Get only appointment-linked calendar events
 */
const getAppointmentLinkedEvents = async (req: Request, res: Response) => {
    try {
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();
        const limit = parseInt(req.query.limit as string) || 100;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const events = await CalendarModel.findAppointmentLinkedEvents(Number(doctorUserId), limit, offset);

        return res.status(200).json({
            success: true,
            data: events,
            count: events.length
        });
    } catch (error) {
        console.error("Error getting appointment-linked events:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_linked_error')
        });
    }
};

/**
 * Get only standalone calendar events
 */
const getStandaloneEvents = async (req: Request, res: Response) => {
    try {
        const doctorUserId = (res.locals.doctorUserId as number | undefined)?.toString();
        const limit = parseInt(req.query.limit as string) || 100;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('calendar.doctor_user_id_required') });
        }

        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const events = await CalendarModel.findStandaloneEvents(Number(doctorUserId), limit, offset);

        return res.status(200).json({
            success: true,
            data: events,
            count: events.length
        });
    } catch (error) {
        console.error("Error getting standalone events:", error);
        return res.status(500).json({
            success: false,
            error: req.t('calendar.get_standalone_error')
        });
    }
};

export {
    createCalendarEvent,
    updateCalendarEvent,
    deleteCalendarEvent,
    getCalendarEvent,
    getAllCalendarEvents,
    getCalendarEventsByDate,
    getCalendarEventsByDateRange,
    getAppointmentLinkedEvents,
    getStandaloneEvents
};
