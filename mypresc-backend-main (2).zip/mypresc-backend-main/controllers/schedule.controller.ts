import type { Request, Response } from "express";
import { AppointmentModel } from "../models/appointment.model";
import { WaitingRoomModel } from "../models/waiting_room.model";
import { DoctorModel } from "../models/doctor.model";
import { checkDoctor } from "./appointment.controller";
import pool from "../db";
import socketManager from "../utils/socketManager";
import { AssistantModel } from "../models/assistant.model";
import { getAlgeriaToday, getAlgeriaMinutesNow } from "../utils/timezone";

const SLOT_MINUTES = 15;

function toMinutes(time: string): number {
    const [h, m, s] = time.split(":").map((v) => parseInt(v || '0', 10));
    return h! * 60 + m! + (s ? Math.floor(s / 60) : 0);
}

function formatTime(minutes: number): string {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:00`;
}

/**
 * Calculer le temps moyen de consultation du médecin (en minutes)
 * Basé sur les consultations terminées des 30 derniers jours
 */
async function getAverageConsultationTime(doctorUserId: number): Promise<number> {
    // Temps de consultation réaliste: 10-20 min
    // On utilise une valeur fixe car served_at - arrived_at inclut le temps d'attente
    const DEFAULT_CONSULTATION_TIME = 15; // 15 min par défaut
    return DEFAULT_CONSULTATION_TIME;
}

/**
 * Get doctor's consultation state (started_at, ended_at, current_patient)
 */
async function getDoctorConsultationState(doctorUserId: number) {
    const result = await pool.query(`
        SELECT consultation_started_at, consultation_ended_at, current_patient_id, current_patient_type
        FROM doctors WHERE user_id = $1
    `, [doctorUserId]);
    return result.rows[0] || null;
}

/**
 * Update doctor's consultation state
 */
async function updateDoctorConsultationState(
    doctorUserId: number, 
    data: { 
        consultation_started_at?: Date | null; 
        consultation_ended_at?: Date | null;
        current_patient_id?: string | null;
        current_patient_type?: string | null;
    }
) {
    const fields: string[] = [];
    const values: any[] = [];
    let idx = 1;

    if (data.consultation_started_at !== undefined) {
        fields.push(`consultation_started_at = $${idx++}`);
        values.push(data.consultation_started_at);
    }
    if (data.consultation_ended_at !== undefined) {
        fields.push(`consultation_ended_at = $${idx++}`);
        values.push(data.consultation_ended_at);
    }
    if (data.current_patient_id !== undefined) {
        fields.push(`current_patient_id = $${idx++}`);
        values.push(data.current_patient_id);
    }
    if (data.current_patient_type !== undefined) {
        fields.push(`current_patient_type = $${idx++}`);
        values.push(data.current_patient_type);
    }

    if (fields.length === 0) return;

    values.push(doctorUserId);
    await pool.query(`UPDATE doctors SET ${fields.join(', ')} WHERE user_id = $${idx}`, values);
}

/**
 * Nouvelle logique Ordre de passage:
 * 1. RDV en retard arrivés PENDANT consultation → PROCHAIN
 * 2. RDV à l'heure arrivés → PROCHAIN  
 * 3. RDV en retard skipés (arrivés AVANT consultation)
 * 4. SA en attente (FIFO) avec RDV non arrivés intercalés selon temps moyen
 */
export const getTodaySchedule = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('schedule.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        // Use Algeria timezone (UTC+1) for date calculations
        const today = getAlgeriaToday();
        const minutesNow = getAlgeriaMinutesNow();

        // Get doctor consultation state and average consultation time
        const [consultationState, avgConsultationTime] = await Promise.all([
            getDoctorConsultationState(Number(doctorUserId)),
            getAverageConsultationTime(Number(doctorUserId))
        ]);
        
        const consultationStartedAt = consultationState?.consultation_started_at 
            ? new Date(consultationState.consultation_started_at) 
            : null;

        console.log('[Schedule] Average consultation time:', avgConsultationTime, 'min');

        // Load today's appointments and waiting entries
        const [allAppointments, allWaiting] = await Promise.all([
            AppointmentModel.findByDoctorUserId(Number(doctorUserId), 1000, 0),
            WaitingRoomModel.findByDoctorUserId(Number(doctorUserId), 1000, 0)
        ]);

        const isSameLocalDate = (d: Date, ref: Date) => {
            return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth() && d.getDate() === ref.getDate();
        };

        const todayAppts = allAppointments.filter(a => isSameLocalDate(new Date(a.date), today));

        // RDV du jour qui sont ARRIVÉS et pas encore servis
        const rdvArrived = todayAppts.filter(a => a.arrived_at && !a.is_done);

        // RDV du jour NON ARRIVÉS et pas encore servis
        const rdvNotArrived = todayAppts.filter(a => !a.arrived_at && !a.is_done);

        // SA en attente
        const waiting = allWaiting.filter(w => w.status === 'waiting' || w.status === 'called');

        console.log('[Schedule DEBUG] todayAppts:', todayAppts.length);
        console.log('[Schedule DEBUG] rdvArrived:', rdvArrived.map(a => ({ id: a.id, time: a.time, arrived_at: a.arrived_at, is_done: a.is_done })));
        console.log('[Schedule DEBUG] rdvNotArrived:', rdvNotArrived.length);
        console.log('[Schedule DEBUG] waiting:', waiting.length);
        console.log('[Schedule DEBUG] minutesNow:', minutesNow);
        
        // Debug catégorisation
        setTimeout(() => {}, 0); // Force sync logging

        // Catégoriser les RDV arrivés
        const rdvLateArrivedDuring: typeof rdvArrived = []; // Arrivés PENDANT consultation → priorité max
        const rdvOnTimeArrived: typeof rdvArrived = [];     // À l'heure et arrivés → prochain
        const rdvLateSkipped: typeof rdvArrived = [];       // En retard, arrivés AVANT consultation

        for (const appt of rdvArrived) {
            const apptMinutes = toMinutes(appt.time);
            const arrivedAt = new Date(appt.arrived_at!);
            const isLate = apptMinutes < minutesNow;

            if (isLate) {
                if (consultationStartedAt && arrivedAt > consultationStartedAt) {
                    rdvLateArrivedDuring.push(appt);
                } else {
                    rdvLateSkipped.push(appt);
                }
            } else {
                // RDV à venir et patient arrivé → prochain
                rdvOnTimeArrived.push(appt);
            }
        }

        // Trier
        rdvLateArrivedDuring.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvOnTimeArrived.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvLateSkipped.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        
        const sortedWaiting = [...waiting].sort((a, b) => 
            new Date(a.arrived_at || a.created_at).getTime() - new Date(b.arrived_at || b.created_at).getTime()
        );
        
        const sortedNotArrived = [...rdvNotArrived].sort((a, b) => toMinutes(a.time) - toMinutes(b.time));

        // Construire l'ordre de passage final
        const patients: Array<{ type: 'appointment' | 'waiting'; appointment?: any; waiting?: any; priority?: number; estimatedTime?: number }> = [];

        // Priorité 1: RDV en retard arrivés PENDANT consultation
        for (const appt of rdvLateArrivedDuring) {
            patients.push({ type: 'appointment', appointment: appt, priority: 1 });
        }

        // Priorité 2: RDV en retard skipés
        for (const appt of rdvLateSkipped) {
            patients.push({ type: 'appointment', appointment: appt, priority: 2 });
        }

        // Priorité 3: SA avec RDV (arrivés à l'heure + non arrivés) intercalés selon temps moyen
        // Les RDV à l'heure sont intercalés pour montrer leur position estimée
        // Calculer le temps estimé de passage pour chaque position
        let estimatedPassageTime = minutesNow;
        const saWithRdvIntercales: Array<{ type: 'appointment' | 'waiting'; appointment?: any; waiting?: any; priority: number; estimatedTime: number }> = [];

        // Ajouter tous les SA avec leur temps de passage estimé
        for (let i = 0; i < sortedWaiting.length; i++) {
            saWithRdvIntercales.push({ 
                type: 'waiting', 
                waiting: sortedWaiting[i], 
                priority: 4,
                estimatedTime: estimatedPassageTime + (i * avgConsultationTime)
            });
        }

        // Seuls les RDV ARRIVÉS à l'heure sont intercalés (les non arrivés ne sont pas dans l'ordre de passage)
        const allRdvToIntercalate = [...rdvOnTimeArrived].sort((a, b) => toMinutes(a.time) - toMinutes(b.time));

        // Intercaler les RDV à la bonne position selon leur heure
        for (const appt of allRdvToIntercalate) {
            const rdvMinutes = toMinutes(appt.time);
            const isArrived = !!appt.arrived_at;
            
            // Trouver la position où insérer ce RDV
            // Le RDV est inséré après le dernier SA qui FINIT avant l'heure du RDV
            let insertIndex = 0; // Par défaut au début
            
            for (let i = 0; i < saWithRdvIntercales.length; i++) {
                // Temps de FIN de la consultation à cette position
                const estimatedEndTime = minutesNow + ((i + 1) * avgConsultationTime);
                if (estimatedEndTime <= rdvMinutes) {
                    // Ce SA finit avant l'heure du RDV, on peut insérer après
                    insertIndex = i + 1;
                } else {
                    break;
                }
            }

            // Insérer le RDV à la position calculée
            // Priorité 3 si arrivé, 5 si non arrivé
            saWithRdvIntercales.splice(insertIndex, 0, {
                type: 'appointment',
                appointment: appt,
                priority: isArrived ? 3 : 5,
                estimatedTime: rdvMinutes
            });
        }

        // Ajouter tous les éléments intercalés à la liste finale
        for (const item of saWithRdvIntercales) {
            patients.push(item);
        }

        console.log('[Schedule DEBUG] Final patients list:', patients.slice(0, 5).map(p => ({
            type: p.type,
            priority: p.priority,
            id: p.appointment?.id || p.waiting?.id,
            name: p.appointment ? `${p.appointment.patient_name} ${p.appointment.patient_family_name}` : `${p.waiting?.patient_name} ${p.waiting?.patient_family_name}`
        })));
        console.log('[Schedule DEBUG] rdvOnTimeArrived count:', rdvOnTimeArrived.length);

        return res.status(200).json({
            success: true,
            data: patients,
            avgConsultationTime
        });
    } catch (error) {
        console.error("Error generating schedule:", error);
        return res.status(500).json({ success: false, error: req.t('schedule.generate_error') });
    }
};

/**
 * Peek next patient - Retourne le prochain patient SANS le marquer comme servi
 * Utilisé pour afficher le popup de confirmation avant d'appeler
 */
export const peekNextPatient = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('schedule.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        // Use Algeria timezone (UTC+1) for date calculations
        const today = getAlgeriaToday();
        const minutesNow = getAlgeriaMinutesNow();

        const consultationState = await getDoctorConsultationState(Number(doctorUserId));
        const consultationStartedAt = consultationState?.consultation_started_at 
            ? new Date(consultationState.consultation_started_at) 
            : null;

        const [allAppointments, allWaiting] = await Promise.all([
            AppointmentModel.findByDoctorUserId(Number(doctorUserId), 1000, 0),
            WaitingRoomModel.findByDoctorUserId(Number(doctorUserId), 1000, 0)
        ]);

        const isSameLocalDate = (d: Date, ref: Date) => {
            return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth() && d.getDate() === ref.getDate();
        };

        const rdvArrived = allAppointments.filter(a => 
            a.arrived_at && 
            !a.is_done
        );

        const waiting = allWaiting
            .filter(w => w.status === 'waiting' || w.status === 'called');

        let nextPatientData: { type: 'appointment' | 'waiting'; id: string; patientId: string; patientName: string } | null = null;

        const rdvLateArrivedDuring: typeof rdvArrived = [];
        const rdvLateSkipped: typeof rdvArrived = [];

        for (const appt of rdvArrived) {
            const apptMinutes = toMinutes(appt.time);
            const arrivedAt = new Date(appt.arrived_at!);
            const isLate = apptMinutes < minutesNow;

            if (isLate) {
                if (consultationStartedAt && arrivedAt > consultationStartedAt) {
                    rdvLateArrivedDuring.push(appt);
                } else {
                    rdvLateSkipped.push(appt);
                }
            }
        }

        const rdvOnTime = rdvArrived.filter(a => toMinutes(a.time) >= minutesNow);

        rdvLateArrivedDuring.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvLateSkipped.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvOnTime.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        const sortedWaiting = [...waiting].sort((a, b) => 
            new Date(a.arrived_at || a.created_at).getTime() - new Date(b.arrived_at || b.created_at).getTime()
        );

        // Filtrer les RDV à l'heure qui peuvent être appelés (heure actuelle >= heure RDV)
        const rdvOnTimeCallable = rdvOnTime.filter(a => toMinutes(a.time) <= minutesNow);

        if (rdvLateArrivedDuring.length > 0) {
            const appt = rdvLateArrivedDuring[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        } else if (rdvOnTimeCallable.length > 0) {
            // RDV arrivé et son heure est passée ou égale → prochain
            const appt = rdvOnTimeCallable[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        } else if (rdvLateSkipped.length > 0) {
            const appt = rdvLateSkipped[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        } else if (sortedWaiting.length > 0) {
            // SA si pas de RDV en retard et pas de RDV callable
            const w = sortedWaiting[0]!;
            nextPatientData = {
                type: 'waiting',
                id: w.id,
                patientId: w.patient_id,
                patientName: `${w.patient_name} ${w.patient_family_name}`.trim()
            };
        } else if (rdvOnTime.length > 0) {
            // RDV à l'heure mais pas encore callable (heure pas atteinte) - afficher quand même si rien d'autre
            const appt = rdvOnTime[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        }

        return res.status(200).json({
            success: true,
            data: nextPatientData
        });
    } catch (error) {
        console.error("Error peeking next patient:", error);
        return res.status(500).json({ success: false, error: 'Erreur lors de la récupération du patient suivant' });
    }
};

/**
 * Patient suivant - Appelé quand le médecin clique sur le bouton
 * Retourne le prochain patient selon la logique de priorité
 */
export const nextPatient = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('schedule.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        // Use Algeria timezone (UTC+1) for date calculations
        const now = new Date(); // Keep real UTC time for timestamps
        const today = getAlgeriaToday();
        const minutesNow = getAlgeriaMinutesNow();

        // 1. Marquer la fin de la consultation précédente
        const consultationState = await getDoctorConsultationState(Number(doctorUserId));
        const consultationStartedAt = consultationState?.consultation_started_at 
            ? new Date(consultationState.consultation_started_at) 
            : null;

        // Note: On ne marque PAS le patient précédent ici car il est déjà marqué immédiatement lors de sa sélection

        // 2. Enregistrer la fin de consultation
        await updateDoctorConsultationState(Number(doctorUserId), {
            consultation_ended_at: now
        });

        // 3. Charger les données
        const [allAppointments, allWaiting] = await Promise.all([
            AppointmentModel.findByDoctorUserId(Number(doctorUserId), 1000, 0),
            WaitingRoomModel.findByDoctorUserId(Number(doctorUserId), 1000, 0)
        ]);

        const isSameLocalDate = (d: Date, ref: Date) => {
            return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth() && d.getDate() === ref.getDate();
        };

        // RDV du jour ARRIVÉS et pas servis
        const rdvArrived = allAppointments.filter(a => 
            a.arrived_at && // truthy check
            !a.is_done
        );

        // SA en attente - inclure TOUS les patients en attente (pas de filtre de date)
        const waiting = allWaiting
            .filter(w => w.status === 'waiting' || w.status === 'called');

        // 4. Trouver le prochain patient selon la priorité
        let nextPatientData: { type: 'appointment' | 'waiting'; id: string; patientId: string; patientName: string } | null = null;

        // Catégoriser les RDV
        const rdvLateArrivedDuring: typeof rdvArrived = []; // Arrivés PENDANT consultation
        const rdvLateSkipped: typeof rdvArrived = [];       // Arrivés AVANT (skipés)

        for (const appt of rdvArrived) {
            const apptMinutes = toMinutes(appt.time);
            const arrivedAt = new Date(appt.arrived_at!);
            const isLate = apptMinutes < minutesNow;

            if (isLate) {
                if (consultationStartedAt && arrivedAt > consultationStartedAt) {
                    rdvLateArrivedDuring.push(appt);
                } else {
                    rdvLateSkipped.push(appt);
                }
            }
        }

        // RDV à l'heure (non en retard)
        const rdvOnTime = rdvArrived.filter(a => toMinutes(a.time) >= minutesNow);

        // Trier par heure de RDV
        rdvLateArrivedDuring.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvLateSkipped.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        rdvOnTime.sort((a, b) => toMinutes(a.time) - toMinutes(b.time));
        const sortedWaiting = [...waiting].sort((a, b) => 
            new Date(a.arrived_at || a.created_at).getTime() - new Date(b.arrived_at || b.created_at).getTime()
        );

        // Filtrer les RDV à l'heure qui peuvent être appelés (heure actuelle >= heure RDV)
        const rdvOnTimeCallable = rdvOnTime.filter(a => toMinutes(a.time) <= minutesNow);

        // Priorité 1: RDV en retard arrivés PENDANT consultation
        if (rdvLateArrivedDuring.length > 0) {
            const appt = rdvLateArrivedDuring[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        }
        // Priorité 2: RDV arrivé et son heure est passée → prochain
        else if (rdvOnTimeCallable.length > 0) {
            const appt = rdvOnTimeCallable[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        }
        // Priorité 3: RDV en retard skipés
        else if (rdvLateSkipped.length > 0) {
            const appt = rdvLateSkipped[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        }
        // Priorité 4: SA (si pas de RDV callable)
        else if (sortedWaiting.length > 0) {
            const w = sortedWaiting[0]!;
            nextPatientData = {
                type: 'waiting',
                id: w.id,
                patientId: w.patient_id,
                patientName: `${w.patient_name} ${w.patient_family_name}`.trim()
            };
        }
        // Priorité 5: RDV à l'heure non callable (seulement si rien d'autre)
        else if (rdvOnTime.length > 0) {
            const appt = rdvOnTime[0]!;
            nextPatientData = {
                type: 'appointment',
                id: appt.id,
                patientId: appt.patient_id,
                patientName: `${appt.patient_name} ${appt.patient_family_name}`.trim()
            };
        }

        if (!nextPatientData) {
            // Reset l'état si aucun patient
            await updateDoctorConsultationState(Number(doctorUserId), {
                current_patient_id: null,
                current_patient_type: null
            });
            return res.status(200).json({
                success: true,
                data: null,
                message: 'Aucun patient en attente'
            });
        }

        // 5. Marquer CE patient comme servi IMMÉDIATEMENT (pas au prochain clic)
        if (nextPatientData.type === 'appointment') {
            const updatedAppointment = await AppointmentModel.update(nextPatientData.id, { is_done: true, served_at: now });
            
            // Emit socket event for real-time update (appointment marked as done)
            if (updatedAppointment) {
                socketManager.emitToUser(Number(doctorUserId), 'appointment:updated', updatedAppointment);
                const assistantsForUpdate = await AssistantModel.findActiveByDoctorUserId(Number(doctorUserId));
                assistantsForUpdate.forEach(assistant => {
                    if (assistant.user_id) {
                        socketManager.emitToUser(assistant.user_id, 'appointment:updated', updatedAppointment);
                    }
                });
            }
        } else if (nextPatientData.type === 'waiting') {
            await WaitingRoomModel.update(nextPatientData.id, { status: 'served' });
        }

        // 6. Mettre à jour l'état du médecin (pour référence seulement)
        await updateDoctorConsultationState(Number(doctorUserId), {
            consultation_started_at: now,
            current_patient_id: nextPatientData.id,
            current_patient_type: nextPatientData.type
        });

        // 7. Notifier les assistants via Socket.io (room-based approach)
        try {
            const roomName = `doctor-assistants:${doctorUserId}`;
            console.log('[Schedule] Emitting patient:call to room:', roomName);
            
            socketManager.getIO().to(roomName).emit('patient:call', {
                patientName: nextPatientData.patientName,
                patientId: nextPatientData.patientId,
                type: nextPatientData.type,
                timestamp: now.toISOString()
            });
        } catch (socketError) {
            console.error("Error notifying assistant:", socketError);
            // Ne pas bloquer la réponse si la notification échoue
        }

        return res.status(200).json({
            success: true,
            data: nextPatientData
        });
    } catch (error) {
        console.error("Error getting next patient:", error);
        return res.status(500).json({ success: false, error: 'Erreur lors de la récupération du patient suivant' });
    }
};

/**
 * Get current call - Pour l'assistant, voir si un patient doit être appelé
 */
export const getCurrentCall = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('schedule.doctor_user_id_required') });
        }

        const consultationState = await getDoctorConsultationState(Number(doctorUserId));
        
        if (!consultationState?.current_patient_id) {
            return res.status(200).json({
                success: true,
                data: null
            });
        }

        // Récupérer le nom du patient
        const patientResult = await pool.query(`
            SELECT pgp_sym_decrypt(name, $2) as name, pgp_sym_decrypt(family_name, $2) as family_name
            FROM patients WHERE id = $1
        `, [consultationState.current_patient_id, process.env.ENCRYPTION_KEY]);

        const patient = patientResult.rows[0];
        const patientName = patient ? `${patient.name} ${patient.family_name}`.trim() : 'Patient';

        return res.status(200).json({
            success: true,
            data: {
                patientId: consultationState.current_patient_id,
                patientName,
                type: consultationState.current_patient_type,
                consultationStartedAt: consultationState.consultation_started_at
            }
        });
    } catch (error) {
        console.error("Error getting current call:", error);
        return res.status(500).json({ success: false, error: 'Erreur' });
    }
};