import type { Request, Response } from 'express';
import type { User } from '../models/user.model';
import { PaymentModel } from '../models/payment.model';
import { UserModel } from '../models/user.model';
import { InvoiceModel } from '../models/invoice.model';
import { emailService } from '../utils/email';
import { generateInvoicePdf, saveInvoicePdf } from '../utils/invoicePdf';
import crypto from 'crypto';

// Chargily API response types
interface ChargilyCheckout {
    id: string;
    checkout_url: string;
    amount: number;
    currency: string;
    status?: string;
}

interface ChargilyApiResponse {
    checkout?: ChargilyCheckout;
    id?: string;
    checkout_url?: string;
    amount?: number;
    currency?: string;
}

// Subscription endpoint
const Subscription = async (req: Request, res: Response) => {
    try {
        const { plan } = req.body;
        const user = req.user as User;
        const doctor_user_id = user.id;

        // Validate plan
        if (!plan || !['flex', 'smart', 'pro'].includes(plan)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid subscription plan. Please choose flex, smart, or pro.'
            });
        }

        const subscriptionDetails: Record<string, { amount: number; duration: number }> = {
            flex: {
                amount: 3000,
                duration: 1, // 1 month
            },
            smart: {
                amount: 16800,
                duration: 6, // 6 months
            },
            pro: {
                amount: 30000,
                duration: 12, // 1 year
            },
        };

        const selectedPlan = subscriptionDetails[plan as keyof typeof subscriptionDetails];
        const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';
        const backendUrl = process.env.BASE_URL || 'http://localhost:3333';

        // Create checkout with Chargily API (direct HTTP request)
        const chargilyApiUrl = process.env.CHARGILY_MODE === 'live'
            ? 'https://pay.chargily.net/api/v2/checkouts'
            : 'https://pay.chargily.net/test/api/v2/checkouts';

        const checkoutPayload = {
            amount: selectedPlan?.amount!,
            currency: 'dzd',
            success_url: `${frontendUrl}/dashboard?status=success`,
            failure_url: `${frontendUrl}/dashboard?status=failed`,
            locale: 'fr',
            metadata: {
                doctor_user_id: doctor_user_id.toString(),
                plan: plan,
                user_email: user.email,
                user_name: `${user.name} ${user.family_name}`
            },
            description: `Abonnement ${plan} - MyPrescription (${selectedPlan?.duration} mois)`
        };

        const chargilyResponse = await fetch(chargilyApiUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${process.env.CHARGILY_SECRET_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(checkoutPayload)
        });

        if (!chargilyResponse.ok) {
            const errorData = await chargilyResponse.json().catch(() => ({}));
            console.error('Chargily API error:', errorData);
            return res.status(500).json({
                success: false,
                error: 'Failed to create checkout with payment gateway',
                details: errorData
            });
        }

        const chargilyData = await chargilyResponse.json() as ChargilyApiResponse;
        const checkout = chargilyData.checkout || chargilyData;

        if (!checkout || !checkout.id) {
            return res.status(500).json({
                success: false,
                error: 'Failed to create checkout with payment gateway'
            });
        }

        // Calculate expiration date (24 hours from now)
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);

        // Save payment record in database
        await PaymentModel.create({
            doctor_user_id,
            checkout_id: checkout.id,
            plan: plan as 'flex' | 'smart' | 'pro',
            amount: selectedPlan?.amount!,
            currency: 'DZD',
            checkout_url: checkout.checkout_url,
            expires_at: expiresAt,
            metadata: {
                plan_duration: selectedPlan?.duration,
                checkout_data: checkout
            }
        });

        return res.status(200).json({
            success: true,
            message: 'Checkout created successfully',
            data: {
                checkout_id: checkout.id,
                checkout_url: checkout.checkout_url,
                amount: selectedPlan?.amount!,
                currency: 'DZD',
                plan: plan,
                expires_at: expiresAt
            }
        });

    } catch (error: any) {
        console.error('Subscription error:', error);
        return res.status(500).json({
            success: false,
            error: 'An error occurred while processing your subscription',
            details: error.message
        });
    }
};

// Webhook endpoint - handles payment status updates from Chargily
const SubscriptionWebhook = async (req: Request, res: Response) => {
    // Always return 200 OK to acknowledge receipt (prevent retries)
    // Even if processing fails, we don't want Chargily to retry

    try {
        // 1. SIGNATURE VERIFICATION
        // Try multiple possible header names (case-insensitive)
        const signature = (
            req.headers['signature'] ||
            req.headers['x-signature'] ||
            req.headers['Signature'] ||
            req.headers['X-Signature']
        ) as string;

        const secretKey = process.env.CHARGILY_SECRET_KEY;

        if (!signature) {
            console.error('[Webhook] Missing signature header');
            return res.status(200).json({ received: true });
        }

        if (!secretKey) {
            console.error('[Webhook] CHARGILY_SECRET_KEY not configured');
            return res.status(200).json({ received: true });
        }

        // Get raw body for signature verification
        // req.body MUST be Buffer when using express.raw() middleware
        let rawBody: string;

        if (Buffer.isBuffer(req.body)) {
            rawBody = req.body.toString('utf8');
        } else {
            console.error('[Webhook] Body is NOT a Buffer - middleware might be misconfigured');
            rawBody = JSON.stringify(req.body);
        }

        // Calculate HMAC SHA-256 signature
        const calculatedSignature = crypto
            .createHmac('sha256', secretKey)
            .update(rawBody)
            .digest('hex');

        // Compare signatures safely
        // Use simple comparison first to avoid timingSafeEqual length errors
        if (signature !== calculatedSignature) {
            console.error('[Webhook] Invalid signature');
            return res.status(200).json({ received: true });
        }

        // Additional constant-time comparison for extra security
        try {
            if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(calculatedSignature))) {
                console.error('[Webhook] timingSafeEqual check failed');
                return res.status(200).json({ received: true });
            }
        } catch (error) {
            console.error('[Webhook] timingSafeEqual error:', error);
            return res.status(200).json({ received: true });
        }

        // 2. PARSE WEBHOOK DATA
        const webhookData = Buffer.isBuffer(req.body) ? JSON.parse(req.body.toString('utf8')) : req.body;

        if (!webhookData || !webhookData.type || !webhookData.data) {
            console.error('[Webhook] Invalid webhook payload structure:', webhookData);
            return res.status(200).json({ received: true });
        }

        const eventType = webhookData.type;
        const eventData = webhookData.data;
        const checkoutId = eventData.id;

        // 3. FIND PAYMENT RECORD
        const payment = await PaymentModel.findByCheckoutId(checkoutId);

        if (!payment) {
            console.error(`[Webhook] Payment not found for checkout ID: ${checkoutId}`);
            return res.status(200).json({ received: true });
        }

        // 4. GET USER INFORMATION
        const user = await UserModel.findById(payment.doctor_user_id);

        if (!user) {
            console.error(`[Webhook] User not found for ID: ${payment.doctor_user_id}`);
            return res.status(200).json({ received: true });
        }

        // 5. HANDLE EVENTS
        switch (eventType) {
            case 'checkout.paid': {
                try {
                    // Idempotency check: prevent double processing
                    if (payment.status === 'paid') {
                        break;
                    }

                    // Calculate subscription end date based on plan (in months)
                    const planDurations: Record<string, number> = {
                        flex: 1,
                        smart: 6,
                        pro: 12
                    };

                    const planDuration = planDurations[payment.plan as keyof typeof planDurations] || 1;

                    let startDate = new Date();
                    // Check if user has an existing active subscription
                    if (user.end_date) {
                        const currentEndDate = new Date(user.end_date);
                        // If currentEndDate is in the future, start the new duration from then
                        if (currentEndDate > startDate) {
                            startDate = currentEndDate;
                        }
                    }

                    // Add months with clamping to handle end-of-month edge cases
                    const endDate = new Date(startDate);
                    const targetMonth = endDate.getMonth() + planDuration;
                    endDate.setMonth(targetMonth);

                    // If we overshot the month (e.g. Jan 31 -> Feb -> Mar 2), roll back to last day of intended month
                    // The modulo arithmetic handles year wrapping correctly for positive months
                    // Note: targetMonth can be > 11, getMonth is 0-11
                    const expectedMonthIndex = targetMonth % 12;
                    if (endDate.getMonth() !== expectedMonthIndex) {
                        endDate.setDate(0);
                    }

                    // Update payment status
                    const updatedPayment = await PaymentModel.update(checkoutId, {
                        status: 'paid',
                        paid_at: new Date(),
                        transaction_id: eventData.invoice_id || checkoutId,
                        payment_method: eventData.payment_method || 'card',
                        expires_at: endDate,
                        metadata: {
                            ...payment.metadata,
                            webhook_data: eventData,
                            fees: eventData.fees,
                            amount_paid: eventData.amount
                        }
                    });

                    if (!updatedPayment) {
                        throw new Error('Failed to update payment');
                    }

                    // Update user's subscription plan and end date
                    await UserModel.update(payment.doctor_user_id, {
                        plan: payment.plan,
                        end_date: endDate
                    });

                    // Generate invoice
                    const invoiceNumber = await InvoiceModel.generateInvoiceNumber();
                    const invoiceDate = new Date();


                    // Generate invoice PDF
                    const invoicePdfBuffer = await generateInvoicePdf({
                        invoiceNumber,
                        invoiceDate,
                        user,
                        payment: updatedPayment
                    });

                    // Save invoice PDF to file system
                    const pdfPath = await saveInvoicePdf(invoiceNumber, invoicePdfBuffer);

                    // Create invoice record in database
                    await InvoiceModel.create({
                        invoice_number: invoiceNumber,
                        payment_id: updatedPayment.id,
                        doctor_user_id: payment.doctor_user_id,
                        plan: payment.plan,
                        amount: payment.amount,
                        currency: payment.currency,
                        tax_amount: payment.amount * 0.19, // 19% TVA
                        total_amount: payment.amount * 1.19,
                        invoice_date: invoiceDate,
                        pdf_path: pdfPath,
                        metadata: {
                            transaction_id: updatedPayment.transaction_id,
                            payment_method: updatedPayment.payment_method,
                            fees: eventData.fees
                        }
                    });


                    // Send success email with invoice attachment
                    await emailService.sendPaymentSuccessEmail(
                        user.email,
                        `${user.name} ${user.family_name}`,
                        payment.plan,
                        payment.amount,
                        eventData.invoice_id || checkoutId,
                        invoicePdfBuffer,
                        invoiceNumber
                    );

                    console.log(`[Webhook] ✅ Payment successful for checkout ID: ${checkoutId}`);
                    console.log(`[Webhook] ✅ Updated user ${user.id} plan to '${payment.plan}' until ${endDate.toISOString()}`);
                    console.log(`[Webhook] ✅ Invoice ${invoiceNumber} sent to ${user.email}`);
                } catch (error) {
                    console.error('[Webhook] Error processing checkout.paid:', error);
                }
                break;
            }

            case 'checkout.failed': {
                try {
                    // Update payment status
                    await PaymentModel.update(checkoutId, {
                        status: 'failed',
                        metadata: {
                            ...payment.metadata,
                            webhook_data: eventData,
                            failure_reason: eventData.failure_reason || 'Payment declined'
                        }
                    });

                    // Send failure email
                    await emailService.sendPaymentFailedEmail(
                        user.email,
                        `${user.name} ${user.family_name}`,
                        payment.plan,
                        payment.amount,
                        eventData.failure_reason || 'Payment processing failed. Please try again.'
                    );

                    console.log(`[Webhook] ❌ Payment failed for checkout ID: ${checkoutId}`);
                } catch (error) {
                    console.error('[Webhook] Error processing checkout.failed:', error);
                }
                break;
            }

            case 'checkout.expired': {
                try {
                    await PaymentModel.update(checkoutId, {
                        status: 'expired',
                        metadata: {
                            ...payment.metadata,
                            webhook_data: eventData
                        }
                    });
                    console.log(`[Webhook] ⏰ Payment expired for checkout ID: ${checkoutId}`);
                } catch (error) {
                    console.error('[Webhook] Error processing checkout.expired:', error);
                }
                break;
            }

            case 'checkout.canceled': {
                try {
                    await PaymentModel.update(checkoutId, {
                        status: 'canceled',
                        metadata: {
                            ...payment.metadata,
                            webhook_data: eventData
                        }
                    });
                    console.log(`[Webhook] 🚫 Payment canceled for checkout ID: ${checkoutId}`);
                } catch (error) {
                    console.error('[Webhook] Error processing checkout.canceled:', error);
                }
                break;
            }

            default:
                console.log(`[Webhook] ⚠️ Unhandled webhook event type: ${eventType}`);
                break;
        }

        // Always return 200 OK to acknowledge receipt
        return res.status(200).json({ received: true });

    } catch (error: any) {
        console.error('[Webhook] Unexpected error:', error);
        // Still return 200 OK to prevent retries
        return res.status(200).json({ received: true });
    }
};

export default { Subscription, SubscriptionWebhook };
