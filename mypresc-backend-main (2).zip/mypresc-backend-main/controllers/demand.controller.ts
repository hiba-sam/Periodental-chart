import type { Request, Response } from "express";
import { DemandModel, type CreateDemandData } from "../models/demand.model";
import { emailService } from "../utils/email";

/**
 * Register a new demand for doctor registration
 * All data is encrypted using pgcrypto before storage
 */
const demandRegistration = async (req: Request, res: Response) => {
    try {
        const { firstName, lastName, email, phone, specialty } = req.body;

        // Validate required fields
        if (!firstName || !lastName || !email || !phone || !specialty) {
            return res.status(400).json({
                success: false,
                error: req.t('demand.missing_fields')
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                error: req.t('demand.email_invalid')
            });
        }

        // Validate phone format (basic validation)
        const phoneRegex = /^[\d\s+()-]+$/;
        if (!phoneRegex.test(phone)) {
            return res.status(400).json({
                success: false,
                error: req.t('demand.phone_invalid')
            });
        }

        // Create demand data
        const demandData: CreateDemandData = {
            firstName: firstName.trim(),
            lastName: lastName.trim(),
            email: email.trim().toLowerCase(),
            phone: phone.trim(),
            specialty: specialty.trim()
        };

        // Create the demand (data will be encrypted in the model)
        const newDemand = await DemandModel.create(demandData);

        // Send email notification to team (don't await to avoid blocking the response)
        emailService.sendDemandRegistrationToTeam({
            firstName: newDemand.firstName,
            lastName: newDemand.lastName,
            email: newDemand.email,
            phone: newDemand.phone,
            specialty: newDemand.specialty,
            id: newDemand.id,
            created_at: newDemand.created_at
        }).catch(error => {
            console.error('Failed to send demand registration email to team:', error);
            // Don't fail the request if email fails
        });

        // Return success response (without sensitive data in logs)
        res.status(201).json({
            success: true,
            message: req.t('demand.success'),
            data: {
                id: newDemand.id,
                created_at: newDemand.created_at
            }
        });

    } catch (error) {
        console.error('Error during demand registration:', error);
        res.status(500).json({
            success: false,
            error: req.t('demand.server_error_retry')
        });
    }
};

/**
 * Get all demands (admin only - should be protected by auth middleware)
 */
const getAllDemands = async (req: Request, res: Response) => {
    try {
        const demands = await DemandModel.findAll();

        res.status(200).json({
            success: true,
            data: demands
        });

    } catch (error) {
        console.error('Error fetching demands:', error);
        res.status(500).json({
            success: false,
            error: req.t('demand.server_error')
        });
    }
};

/**
 * Get a single demand by ID (admin only - should be protected by auth middleware)
 */
const getDemandById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('demand.id_required')
            });
        }

        const demand = await DemandModel.findById(id);

        if (!demand) {
            return res.status(404).json({
                success: false,
                error: req.t('demand.not_found')
            });
        }

        res.status(200).json({
            success: true,
            data: demand
        });

    } catch (error) {
        console.error('Error fetching demand:', error);
        res.status(500).json({
            success: false,
            error: req.t('demand.server_error')
        });
    }
};

/**
 * Delete a demand (admin only - should be protected by auth middleware)
 */
const deleteDemand = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('demand.id_required')
            });
        }

        const deleted = await DemandModel.delete(id);

        if (!deleted) {
            return res.status(404).json({
                success: false,
                error: req.t('demand.not_found')
            });
        }

        res.status(200).json({
            success: true,
            message: req.t('demand.delete_success')
        });

    } catch (error) {
        console.error('Error deleting demand:', error);
        res.status(500).json({
            success: false,
            error: req.t('demand.server_error')
        });
    }
};

export { demandRegistration, getAllDemands, getDemandById, deleteDemand };
