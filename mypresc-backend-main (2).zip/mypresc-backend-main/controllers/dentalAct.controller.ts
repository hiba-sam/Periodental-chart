import type { Request, Response } from 'express';
import { DentalActModel } from '../models/dentalAct.model.js';
import type { CreateDentalActData, UpdateDentalActData } from '../models/dentalAct.model.js';
import { ActCatalogModel } from '../models/actCatalog.model.js';

/**
 * Search acts catalog
 * GET /api/catalog/acts
 */
export const searchCatalog = async (req: Request, res: Response) => {
    try {
        const { q, chapter, family, isDental, page = '1', limit = '20' } = req.query;

        const result = await ActCatalogModel.search({
            q: q as string,
            chapter: chapter as string,
            family: family as string,
            isDental: isDental === 'true' ? true : isDental === 'false' ? false : undefined,
            page: parseInt(page as string),
            limit: Math.min(parseInt(limit as string), 100) // Max 100 per page
        });

        res.json({
            success: true,
            data: {
                acts: result.acts,
                total: result.total,
                page: parseInt(page as string),
                limit: parseInt(limit as string),
                totalPages: Math.ceil(result.total / parseInt(limit as string))
            }
        });
    } catch (error) {
        console.error('Search catalog error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get catalog act by ID
 * GET /api/catalog/acts/:id
 */
export const getCatalogAct = async (req: Request, res: Response) => {
    try {
        const actId = parseInt(req.params.id);
        
        if (isNaN(actId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid act ID'
            });
        }

        const act = await ActCatalogModel.findById(actId);

        if (!act) {
            return res.status(404).json({
                success: false,
                error: 'Act not found'
            });
        }

        res.json({
            success: true,
            data: act
        });
    } catch (error) {
        console.error('Get catalog act error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get catalog chapters for filtering
 * GET /api/catalog/chapters
 */
export const getCatalogChapters = async (req: Request, res: Response) => {
    try {
        const chapters = await ActCatalogModel.getChapters();
        res.json({
            success: true,
            data: chapters
        });
    } catch (error) {
        console.error('Get chapters error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get catalog families for filtering
 * GET /api/catalog/families
 */
export const getCatalogFamilies = async (req: Request, res: Response) => {
    try {
        const families = await ActCatalogModel.getFamilies();
        res.json({
            success: true,
            data: families
        });
    } catch (error) {
        console.error('Get families error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get dental acts for a patient
 * GET /api/patients/:patientId/dental-acts
 */
export const getPatientDentalActs = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const { status, fromDate, toDate, tooth } = req.query;

        const acts = await DentalActModel.findByPatient(patientId, {
            status: status as any,
            fromDate: fromDate as string,
            toDate: toDate as string,
            tooth: tooth as string
        });

        res.json({
            success: true,
            data: acts
        });
    } catch (error) {
        console.error('Get patient dental acts error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Create a dental act for a patient
 * POST /api/patients/:patientId/dental-acts
 */
export const createDentalAct = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const userId = req.user!.id;
        const { scope, teeth, surfaces, act_catalog_id, custom_act_label, status, date_act, notes } = req.body;

        // Validate scope
        if (!scope || !['TOOTH', 'MOUTH'].includes(scope)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid scope. Must be TOOTH or MOUTH'
            });
        }

        // Validate teeth for TOOTH scope
        if (scope === 'TOOTH') {
            if (!teeth || !Array.isArray(teeth) || teeth.length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'Teeth selection required for TOOTH scope'
                });
            }
        }

        // Validate that either act_catalog_id or custom_act_label is provided
        if (!act_catalog_id && !custom_act_label) {
            return res.status(400).json({
                success: false,
                error: 'Either act_catalog_id or custom_act_label is required'
            });
        }

        // Get act details from catalog if provided, or use custom label
        let actLabelCache: string | undefined;
        let actCodeCache: string | undefined;

        if (act_catalog_id) {
            const catalogAct = await ActCatalogModel.findById(act_catalog_id);
            if (catalogAct) {
                actLabelCache = catalogAct.label;
                actCodeCache = catalogAct.code_ccam;
            }
        } else if (custom_act_label) {
            // Custom act - use the provided label, no code
            actLabelCache = custom_act_label;
            actCodeCache = undefined;
        }

        const data: CreateDentalActData = {
            patient_id: patientId,
            doctor_user_id: userId,
            scope,
            teeth: scope === 'TOOTH' ? teeth : null,
            surfaces: scope === 'TOOTH' ? surfaces : null,
            act_catalog_id,
            act_label_cache: actLabelCache,
            act_code_cache: actCodeCache,
            status: status || 'NON_COMMENCE',
            date_act: date_act || new Date(),
            notes,
            created_by: userId
        };

        const act = await DentalActModel.create(data);

        // Fetch full act with joins
        const fullAct = await DentalActModel.findById(act.id);

        res.status(201).json({
            success: true,
            data: fullAct
        });
    } catch (error) {
        console.error('Create dental act error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get dental act details
 * GET /api/dental-acts/:id
 */
export const getDentalAct = async (req: Request, res: Response) => {
    try {
        const actId = parseInt(req.params.id);

        if (isNaN(actId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid act ID'
            });
        }

        const act = await DentalActModel.findById(actId);

        if (!act) {
            return res.status(404).json({
                success: false,
                error: 'Dental act not found'
            });
        }

        res.json({
            success: true,
            data: act
        });
    } catch (error) {
        console.error('Get dental act error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Update a dental act
 * PATCH /api/dental-acts/:id
 */
export const updateDentalAct = async (req: Request, res: Response) => {
    try {
        const actId = parseInt(req.params.id);
        const userId = req.user!.id;

        if (isNaN(actId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid act ID'
            });
        }

        // Check if act exists
        const existingAct = await DentalActModel.findById(actId);
        if (!existingAct) {
            return res.status(404).json({
                success: false,
                error: 'Dental act not found'
            });
        }

        // Check access (only creator can update)
        const hasAccess = await DentalActModel.checkAccess(actId, userId);
        if (!hasAccess) {
            return res.status(403).json({
                success: false,
                error: 'Not authorized to update this act'
            });
        }

        const { scope, teeth, surfaces, act_catalog_id, status, date_act, notes } = req.body;

        // Validate scope if provided
        if (scope && !['TOOTH', 'MOUTH'].includes(scope)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid scope. Must be TOOTH or MOUTH'
            });
        }

        // Get act details from catalog if changed
        let actLabelCache: string | undefined;
        let actCodeCache: string | undefined;

        if (act_catalog_id && act_catalog_id !== existingAct.act_catalog_id) {
            const catalogAct = await ActCatalogModel.findById(act_catalog_id);
            if (catalogAct) {
                actLabelCache = catalogAct.label;
                actCodeCache = catalogAct.code_ccam;
            }
        }

        const updateData: UpdateDentalActData = {
            updated_by: userId
        };

        if (scope !== undefined) updateData.scope = scope;
        if (teeth !== undefined) updateData.teeth = teeth;
        if (surfaces !== undefined) updateData.surfaces = surfaces;
        if (act_catalog_id !== undefined) updateData.act_catalog_id = act_catalog_id;
        if (actLabelCache) updateData.act_label_cache = actLabelCache;
        if (actCodeCache) updateData.act_code_cache = actCodeCache;
        if (status !== undefined) updateData.status = status;
        if (date_act !== undefined) updateData.date_act = date_act;
        if (notes !== undefined) updateData.notes = notes;

        await DentalActModel.update(actId, updateData);

        // Fetch updated act with joins
        const updatedAct = await DentalActModel.findById(actId);

        res.json({
            success: true,
            data: updatedAct
        });
    } catch (error) {
        console.error('Update dental act error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Delete a dental act
 * DELETE /api/dental-acts/:id
 */
export const deleteDentalAct = async (req: Request, res: Response) => {
    try {
        const actId = parseInt(req.params.id);
        const userId = req.user!.id;

        if (isNaN(actId)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid act ID'
            });
        }

        // Check access
        const hasAccess = await DentalActModel.checkAccess(actId, userId);
        if (!hasAccess) {
            return res.status(403).json({
                success: false,
                error: 'Not authorized to delete this act'
            });
        }

        const deleted = await DentalActModel.delete(actId);

        if (!deleted) {
            return res.status(404).json({
                success: false,
                error: 'Dental act not found'
            });
        }

        res.json({
            success: true,
            message: 'Dental act deleted successfully'
        });
    } catch (error) {
        console.error('Delete dental act error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get patient dental stats
 * GET /api/patients/:patientId/dental-stats
 */
export const getPatientDentalStats = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;

        const stats = await DentalActModel.getPatientStats(patientId);

        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Get dental stats error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};
