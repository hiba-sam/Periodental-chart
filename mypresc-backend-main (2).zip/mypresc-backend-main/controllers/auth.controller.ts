import type { NextFunction, Request, Response } from "express";
import { UserModel, type CreateUserData } from "../models/user.model";
import { DoctorModel, type CreateDoctorData } from "../models/doctor.model";
import { AssistantModel, type CreateAssistantInvitationData } from "../models/assistant.model";
import { NotificationModel } from "../models/notification.model";
import { TarificationModel, type CreateTarificationData } from "../models/tarification.model";
import jwt from 'jsonwebtoken';
import { emailService } from '../utils/email';
import bcrypt from 'bcrypt';
import passport from 'passport';
import '../strategies/localStrategy';
import { generateRegistrationToken, generateAssistantInvitationToken, generatePasswordResetToken } from "../utils/token";
import { clearCsrfToken } from "../middlewares/csrfProtection";
import { notifyUserRegistration, notifyAccountReactivation } from "../services/notification.service";
import { getUploadedFiles, deleteUploadedFiles } from "../config/multer";
import { TokenModel } from "../models/token.model";
import { isPlanExpired } from "../utils/planHelper";


const register = async (req: Request, res: Response) => {
    try {
        // Extract formData fields
        const {
            // Step 1
            firstName,
            lastName,
            email,
            phone,
            specialty,
            // Step 2
            birthDate,
            birthPlace,
            workLocation,
            homeLocation,
            nin,
            numeroOrdre,
            assistantName,
            assistantEmail,
            // Step 4
            password,
            confirmPassword,
        } = req.body;
        const uploadedFiles = getUploadedFiles(req);
        const { diplomaFile, idCardFile, numeroOrdreFile } = uploadedFiles;

        // --- Step 1 Validation ---
        if (!firstName) return res.status(400).json({ success: false, error: "Le prénom est requis.", field: "firstName", step: 1 });
        if (!lastName) return res.status(400).json({ success: false, error: "Le nom est requis.", field: "lastName", step: 1 });
        if (!email) return res.status(400).json({ success: false, error: "L'email est requis.", field: "email", step: 1 });
        if (!phone) return res.status(400).json({ success: false, error: "Le téléphone est requis.", field: "phone", step: 1 });
        if (!specialty) return res.status(400).json({ success: false, error: "La spécialité est requise.", field: "specialty", step: 1 });

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            // Clean up uploaded files
            if (req.files) {
                const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
                deleteUploadedFiles(files);
            }
            return res.status(400).json({
                success: false,
                error: "Format d'email invalide.",
                field: "email",
                step: 1
            });
        }

        // Check if user already exists
        const existingUser = await UserModel.findByEmail(email);
        if (existingUser) {
            // Clean up uploaded files
            if (req.files) {
                const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
                deleteUploadedFiles(files);
            }
            return res.status(409).json({
                success: false,
                error: "Cet email est déjà utilisé.",
                field: "email",
                step: 1
            });
        }


        // --- Step 2 Validation ---
        if (!birthDate) return res.status(400).json({ success: false, error: "La date de naissance est requise.", field: "birthDate", step: 2 });
        if (!birthPlace) return res.status(400).json({ success: false, error: "Le lieu de naissance est requis.", field: "birthPlace", step: 2 });
        if (!homeLocation) return res.status(400).json({ success: false, error: "L'adresse personnelle est requise.", field: "homeLocation", step: 2 });
        if (!numeroOrdre) return res.status(400).json({ success: false, error: "Le numéro d'ordre est requis.", field: "numeroOrdre", step: 2 });
        if (!nin) return res.status(400).json({ success: false, error: "Le NIN est requis.", field: "nin", step: 2 });


        // --- Step 3 Validation (Files) ---
        // diplomaFile is now an array, check if it exists and has length > 0
        if (!diplomaFile || (Array.isArray(diplomaFile) && diplomaFile.length === 0)) {
            if (req.files) { const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat(); deleteUploadedFiles(files); }
            return res.status(400).json({ success: false, error: "Le fichier du diplôme est requis.", field: "diplomaFile", step: 3 });
        }
        if (!idCardFile) {
            if (req.files) { const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat(); deleteUploadedFiles(files); }
            return res.status(400).json({ success: false, error: "La carte d'identité est requise.", field: "idCardFile", step: 3 });
        }
        if (!numeroOrdreFile) {
            if (req.files) { const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat(); deleteUploadedFiles(files); }
            return res.status(400).json({ success: false, error: "La carte professionnelle est requise.", field: "numeroOrdreFile", step: 3 });
        }

        // --- Step 4 Validation ---
        if (!password) return res.status(400).json({ success: false, error: "Le mot de passe est requis.", field: "password", step: 4 });
        if (!confirmPassword) return res.status(400).json({ success: false, error: "La confirmation du mot de passe est requise.", field: "confirmPassword", step: 4 });

        // Validate password match
        if (password !== confirmPassword) {
            // Clean up uploaded files if validation fails
            if (req.files) {
                const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
                deleteUploadedFiles(files);
            }
            return res.status(400).json({
                success: false,
                error: "Les mots de passe ne correspondent pas.",
                field: "confirmPassword",
                step: 4
            });
        }

        // Check if NIN already exists
        const existingNin = await DoctorModel.findByNin(nin);
        if (existingNin) {
            // Clean up uploaded files
            if (req.files) {
                const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
                deleteUploadedFiles(files);
            }
            return res.status(409).json({
                success: false,
                error: "Ce numéro d'identification nationale (NIN) est déjà lié à un compte.",
                field: "nin",
                step: 2
            });
        }

        // Check if Order Number already exists
        const existingOrderNum = await DoctorModel.findByOrderNum(numeroOrdre);
        if (existingOrderNum) {
            // Clean up uploaded files
            if (req.files) {
                const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
                deleteUploadedFiles(files);
            }
            return res.status(409).json({
                success: false,
                error: "Ce numéro d'ordre est déjà lié à un compte.",
                field: "numeroOrdre", // Matching the field name in frontend form
                step: 2
            });
        }

        // Hash password
        const cryptedPassword = await bcrypt.hash(password, 10);

        // Create user data (doctors are always created with role 'doctor')
        const userData: CreateUserData = {
            name: lastName, // Map lastName to name field
            family_name: firstName, // Map firstName to family_name field
            email,
            password: cryptedPassword,
            role: 'doctor' // All registrations through this form are doctors
        };

        const newUser = await UserModel.create(userData);

        // Create doctor profile
        const doctorData: CreateDoctorData = {
            user_id: newUser.id,
            birth_date: birthDate,
            birth_place: birthPlace,
            work_location: workLocation || '', // Optional field
            home_location: homeLocation,
            diploma_file: diplomaFile, // Now passed as array
            certificates: [], // Empty array for now
            order_num: numeroOrdre,
            order_num_file: numeroOrdreFile,
            id_card_file: idCardFile,
            phone_number: phone,
            work_time: {}, // Empty object for now
            languages: ["arabic", "français"], // Empty array for now
            about: '', // Not in formData, set empty
            speciality: specialty,
            experience: 0,// Default to 0 years
            nin: nin,
        };

        const doctor = await DoctorModel.create(doctorData);

        // Create default tarification services for the new doctor
        const DEFAULT_SERVICES = [
            { service_label: "Consultation générale", price: 2000 },
            { service_label: "Consultation de suivi", price: 2500 },
            { service_label: "Consultation durgence", price: 3000 }
        ];

        try {
            const defaultTarifications: CreateTarificationData[] = DEFAULT_SERVICES.map(service => ({
                doctor_user_id: newUser.id,
                service_label: service.service_label,
                price: service.price
            }));

            await TarificationModel.createMany(defaultTarifications);
        } catch (tarificationError) {
            console.error('Error creating default tarifications:', tarificationError);
            // Don't fail registration if tarification creation fails
        }

        // Generate approval/rejection links
        const approve_link = generateRegistrationToken(newUser.id, "approve");
        const reject_link = generateRegistrationToken(newUser.id, "reject");

        // Send registration email to team for confirmation
        await emailService.sendRegistrationToTeam(approve_link, reject_link, newUser, {
            birth_date: birthDate,
            birth_place: birthPlace,
            work_location: workLocation || '',
            home_location: homeLocation,
            order_num: doctor.order_num,
            order_num_file: doctor.order_num_file,
            id_card_file: doctor.id_card_file,
            diploma_file: doctor.diploma_file, // Array
            phone_number: phone,
            speciality: specialty,
            nin: nin || 'N/A'
        });

        // Send confirmation email to doctor (don't await to avoid blocking response)
        emailService.sendRegistrationConfirmationToDoctor(
            email,
            `${firstName} ${lastName}`
        ).catch(error => {
            console.error('Failed to send confirmation email to doctor:', error);
            // Don't fail the request if email fails
        });

        // Store assistant invitation if provided (email will be sent after doctor approval)
        if (assistantName && assistantEmail) {
            try {
                // Generate invitation token containing doctor ID and assistant info
                const invitationToken = generateAssistantInvitationToken(
                    newUser.id,
                    assistantEmail,
                    assistantName
                );
                console.log('Generated assistant invitation token:', invitationToken);

                // Save the invitation to the database (without sending email yet)
                const assistantInvitationData: CreateAssistantInvitationData = {
                    assistant_name: assistantName,
                    assistant_email: assistantEmail,
                    doctor_id: newUser.id,
                    invitation_token: invitationToken
                };
                console.log('Assistant invitation data prepared:', assistantInvitationData);

                await AssistantModel.createInvitation(assistantInvitationData);


                console.log(`Assistant invitation stored for ${assistantEmail} - will be sent after doctor approval`);
            } catch (error) {
                console.error('Error storing assistant invitation:', error);
                // Don't fail the registration if assistant invitation storage fails
            }
        }

        res.status(201).json({
            success: true,
            message: req.t('auth.registration_success'),
            data: {
                user: {
                    id: newUser.id,
                    name: newUser.name,
                    family_name: newUser.family_name,
                    email: newUser.email,
                    role: newUser.role,
                    is_active: newUser.is_active
                },
            }
        });

    } catch (error) {
        console.error('Error during registration:', error);

        // Clean up uploaded files in case of error
        if (req.files) {
            const files = Object.values(req.files as { [key: string]: Express.Multer.File[] }).flat();
            deleteUploadedFiles(files);
        }

        res.status(500).json({
            success: false,
            error: req.t('auth.registration_error')
        });
    }
};

const checkAssistantInvitation = async (req: Request, res: Response) => {
    try {
        const { token } = req.params;

        if (!token) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_missing')
            });
        }

        // Verify and decode token
        try {
            jwt.verify(token, process.env.JWT_SECRET!);
        } catch (error: any) {
            if (error.name === "TokenExpiredError") {
                return res.status(400).json({
                    success: false,
                    error: req.t('auth.token_expired')
                });
            }
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_invalid')
            });
        }

        // Check if invitation exists in database
        const assistant = await AssistantModel.findByInvitationToken(token);

        if (!assistant) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_invalid')
            });
        }

        // Check if the invitation has already been used (user_id is not null)
        if (assistant.user_id !== null) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_invalid')
            });
        }

        // Return valid invitation data
        return res.status(200).json({
            success: true,
            data: {
                email: assistant.assistant_email,
                assistantName: assistant.assistant_name
            }
        });

    } catch (error) {
        console.error('Error checking assistant invitation:', error);
        return res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

const assistantRegistration = async (req: Request, res: Response) => {
    try {
        const { name, email, phone, password, token } = req.body;

        // Validate required fields
        if (!name || !email || !phone || !password || !token) {
            return res.status(400).json({
                success: false,
                error: "Missing required fields (name, email, phone, password, token)"
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                error: "Invalid email format"
            });
        }

        // Verify token
        try {
            jwt.verify(token, process.env.JWT_SECRET!);
        } catch (error: any) {
            if (error.name === "TokenExpiredError") {
                return res.status(400).json({
                    success: false,
                    error: "Invitation token has expired"
                });
            }
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_invalid')
            });
        }

        // Find assistant invitation by token
        const assistant = await AssistantModel.findByInvitationToken(token);

        if (!assistant) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_invalid')
            });
        }

        // Check if invitation has already been used
        if (assistant.user_id !== null) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.invitation_used')
            });
        }

        // Verify email matches the invitation
        if (assistant.assistant_email !== email) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.email_mismatch_invitation')
            });
        }

        // Check if user with this email already exists
        const existingUser = await UserModel.findByEmail(email);
        if (existingUser) {
            return res.status(409).json({
                success: false,
                error: req.t('auth.user_exists')
            });
        }

        // Hash password
        const cryptedPassword = await bcrypt.hash(password, 10);

        // Create user with assistant role
        const userData: CreateUserData = {
            name: name.split(' ')[0] || name, // First part of name
            family_name: name.split(' ').slice(1).join(' ') || '', // Rest of name
            email,
            password: cryptedPassword,
            role: 'assistant'
        };

        const newUser = await UserModel.create(userData);

        // Update assistant record: link user_id, add phone, clear token, activate
        const updatedAssistant = await AssistantModel.completeRegistration(token, {
            user_id: newUser.id,
            phone_number: phone
        });

        if (!updatedAssistant) {
            // Rollback: delete the created user if assistant update fails
            await UserModel.delete(newUser.id);
            return res.status(500).json({
                success: false,
                error: "Failed to complete assistant registration"
            });
        }

        // Activate the user account
        await UserModel.update(newUser.id, { is_active: true });

        // Create success notification for the doctor
        try {
            await NotificationModel.create({
                user_id: updatedAssistant.doctor_id,
                title: "Assistant Registration Complete",
                description: `${updatedAssistant.assistant_name} has successfully completed registration and is now active.`,
                type: 'check',
                link: null
            });
        } catch (notifError) {
            console.error('[Notification] Failed to send assistant registration notification:', notifError);
            // Don't fail the request if notification fails
        }

        return res.status(201).json({
            success: true,
            message: req.t('auth.assistant_registration_success'),
            data: {
                user: {
                    id: newUser.id,
                    name: newUser.name,
                    family_name: newUser.family_name,
                    email: newUser.email,
                    role: newUser.role,
                    is_active: true
                },
                assistant: {
                    id: updatedAssistant.id,
                    assistant_name: updatedAssistant.assistant_name,
                    doctor_id: updatedAssistant.doctor_id,
                    phone_number: updatedAssistant.phone_number
                }
            }
        });

    } catch (error) {
        console.error('Error during assistant registration:', error);
        return res.status(500).json({
            success: false,
            error: req.t('auth.assistant_registration_error')
        });
    }
};

const completeRegistration = async (req: Request, res: Response) => {
    try {
        const { token } = req.params;

        if (!token) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_missing')
            });
        }

        // Verify and decode token
        const payload = jwt.verify(token, process.env.JWT_SECRET!) as {
            userId: number;
            action: string;
            iat: number;
            exp: number;
        };

        // Get user details
        const user = await UserModel.findById(payload.userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: req.t('auth.user_not_found')
            });
        }

        // Check current state to avoid double action
        if (payload.action === "approve") {
            if (user.is_active) {
                return res.status(400).json({
                    success: false,
                    error: req.t('auth.user_already_approved')
                });
            }

            const updatedUser = await UserModel.update(user.id, { is_active: true });
            if (!updatedUser) {
                return res.status(500).json({
                    success: false,
                    error: req.t('auth.approval_error')
                });
            }

            // ✅ Notification: User registration approved
            // Send welcome notification to the newly approved user
            await notifyUserRegistration(
                updatedUser.id,
                `${updatedUser.name} ${updatedUser.family_name}`
            );

            // Send assistant invitation emails if any were stored during registration
            if (updatedUser.role === 'doctor') {
                try {
                    const pendingInvitations = await AssistantModel.findPendingByDoctorId(updatedUser.id);

                    if (pendingInvitations.length > 0) {
                        const doctorName = `${updatedUser.name} ${updatedUser.family_name}`;

                        // Send invitation emails to all pending assistants
                        for (const invitation of pendingInvitations) {
                            if (invitation.invitation_token) {
                                emailService.sendAssistantInvitation(
                                    invitation.assistant_email,
                                    invitation.assistant_name,
                                    doctorName,
                                    invitation.invitation_token
                                ).catch(error => {
                                    console.error(`Failed to send invitation email to ${invitation.assistant_email}:`, error);
                                });
                            }
                        }

                        console.log(`Sent ${pendingInvitations.length} assistant invitation(s) for approved doctor ${updatedUser.id}`);
                    }
                } catch (error) {
                    console.error('Error sending assistant invitations:', error);
                    // Don't fail the approval if invitation emails fail
                }
            }

            return res.status(200).json({
                success: true,
                message: req.t('auth.registration_approved')
            });
        }

        if (payload.action === "reject") {
            if (!user.is_active) {
                // Already inactive means can't reject twice
                await UserModel.delete(user.id);
                if (user.role === "doctor") {
                    await DoctorModel.delete(user.id);

                    // Clean up any pending assistant invitations for rejected doctor
                    try {
                        const pendingInvitations = await AssistantModel.findPendingByDoctorId(user.id);
                        for (const invitation of pendingInvitations) {
                            await AssistantModel.delete(invitation.id);
                        }
                        if (pendingInvitations.length > 0) {
                            console.log(`Cleaned up ${pendingInvitations.length} pending assistant invitation(s) for rejected doctor ${user.id}`);
                        }
                    } catch (error) {
                        console.error('Error cleaning up assistant invitations:', error);
                        // Don't fail the rejection if cleanup fails
                    }
                }

                return res.status(200).json({
                    success: true,
                    message: req.t('auth.registration_rejected')
                });
            }

            return res.status(400).json({
                success: false,
                error: req.t('auth.user_already_inactive')
            });
        }

        res.status(400).json({
            success: false,
            error: req.t('auth.unknown_action')
        });
    } catch (error: any) {
        console.error("Error during complete registration:", error);

        if (error.name === "TokenExpiredError") {
            return res.status(400).json({
                success: false,
                error: req.t('auth.token_expired')
            });
        }

        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

const login = (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
        // Handle unexpected server or DB errors
        if (err) {
            console.error("❌ Error during login:", err);
            return res.status(500).json({
                success: false,
                error: req.t('error.server_error'),
            });
        }

        //  Handle failed authentication (invalid credentials, etc.)
        if (!user) {
            return res.status(401).json({
                success: false,
                error: info?.message || req.t('auth.invalid_credentials'),
            });
        }

        //  Check user active status (optional but recommended)
        if (user.is_active === false) {
            return res.status(403).json({
                success: false,
                error: req.t('auth.account_deactivated'),
            });
        }

        //  Create session & set cookie
        req.login(user, async (err) => {
            if (err) {
                console.error("❌ Error during req.login:", err);
                return res.status(500).json({
                    success: false,
                    error: req.t('auth.login_failed'),
                });
            }

            // If doctor doesn't have an end_date, set it to +14 days from now (trial period)
            if (user.role === 'doctor' && !user.end_date) {
                const trialEndDate = new Date();
                trialEndDate.setDate(trialEndDate.getDate() + 14);

                const updatedUser = await UserModel.update(user.id, {
                    end_date: trialEndDate,
                    plan: user.plan || 'test'
                });

                if (updatedUser) {
                    user.end_date = updatedUser.end_date;
                    user.plan = updatedUser.plan;
                }
            }

            // if assistant role, fetch linked doctor id
            let doctor_id = null;
            if (user.role === 'assistant') {
                const assistant = await AssistantModel.findByUserId(user.id);
                if (assistant) {
                    doctor_id = assistant.doctor_id;
                }
            }

            // Check if plan is expired
            const is_plan_expired = isPlanExpired(user.end_date);

            //  Successful login
            return res.status(200).json({
                success: true,
                message: req.t('auth.login_success'),
                data: {
                    user: {
                        id: user.role === 'assistant' ? doctor_id : user.id,
                        assistant_id: user.role === 'assistant' ? user.id : null,
                        name: user.name,
                        family_name: user.family_name,
                        email: user.email,
                        role: user.role,
                        is_active: user.is_active,
                        plan: user.plan,
                        end_date: user.end_date,
                        is_plan_expired: is_plan_expired,
                    },
                },
            });
        });
    })(req, res, next);
};


const logout = (req: Request, res: Response) => {
    // 1️⃣ Check if a user is logged in
    if (!req.user) {
        return res.status(400).json({
            success: false,
            error: req.t('auth.no_session'),
        });
    }

    // 2️⃣ Use Passport's logout (since you're using req.login)
    req.logout((err) => {
        if (err) {
            console.error("❌ Error during logout:", err);
            return res.status(500).json({
                success: false,
                error: req.t('auth.logout_failed'),
            });
        }

        // 3️⃣ Destroy the session completely
        req.session.destroy((sessionErr) => {
            if (sessionErr) {
                console.error("⚠️ Error destroying session:", sessionErr);
            }

            // 4️⃣ Clear session cookie (must match name in session config: 'sessionId')
            res.clearCookie("sessionId", { path: "/" });

            // 5️⃣ Send success response
            return res.status(200).json({
                success: true,
                message: req.t('auth.logout_success'),
            });
        });
    });
};


const checkUserLogging = async (req: Request, res: Response) => {
    try {
        // Check if user is authenticated via session
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: req.t('auth.no_session')
            });
        }

        // Get user data from session
        const user = req.user as any;

        // if assistant role, fetch linked doctor id (same as login)
        let doctor_id = null;
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (assistant) {
                doctor_id = assistant.doctor_id;
            }
        }

        // Check if plan is expired
        const is_plan_expired = isPlanExpired(user.end_date);

        res.json({
            success: true,
            message: req.t('auth.session_valid'),
            data: {
                user: {
                    id: user.role === 'assistant' ? doctor_id : user.id,
                    assistant_id: user.role === 'assistant' ? user.id : null,
                    name: user.name,
                    family_name: user.family_name,
                    email: user.email,
                    role: user.role,
                    is_active: user.is_active,
                    plan: user.plan,
                    end_date: user.end_date,
                    is_plan_expired: is_plan_expired,
                }
            }
        });

    } catch (error) {
        console.error('Error during session check:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};



// for resseting password
const resetPassword = async (req: Request, res: Response) => {
    try {
        const { email } = req.body;

        // Validate email field
        if (!email) {
            return res.status(400).json({
                success: false,
                error: req.t('auth.email_required')
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                error: "Invalid email format"
            });
        }

        // Check if user exists
        const user = await UserModel.findByEmail(email);
        if (!user) {
            // For security reasons, we return success even if user doesn't exist
            // This prevents email enumeration attacks
            return res.status(200).json({
                success: true,
                message: req.t('auth.password_reset_sent')
            });
        }

        // Check if user is active
        if (!user.is_active) {
            return res.status(403).json({
                success: false,
                error: "This account is not active. Please contact support."
            });
        }

        // Generate password reset token
        const resetToken = generatePasswordResetToken(user.id, user.email);

        // Calculate expiration time (1 hour from now)
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 1);

        // Store token in database
        await TokenModel.create({
            user_id: user.id,
            token: resetToken,
            type: 'reset',
            expires_at: expiresAt
        });

        // Send password reset email
        const userName = `${user.name} ${user.family_name}`;
        await emailService.sendPasswordResetEmail(user.email, userName, resetToken);

        return res.status(200).json({
            success: true,
            message: "If an account with this email exists, a password reset link has been sent."
        });

    } catch (error) {
        console.error('Error during password reset request:', error);
        return res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
}

const changePassword = async (req: Request, res: Response) => {
    try {
        const { token, password, confirmPassword } = req.body;

        // Validate required fields
        if (!token || !password || !confirmPassword) {
            return res.status(400).json({
                success: false,
                error: "Token, password, and confirmPassword are required"
            });
        }

        // Validate password match
        if (password !== confirmPassword) {
            return res.status(400).json({
                success: false,
                error: "Passwords do not match"
            });
        }

        // Validate password strength (minimum 8 characters)
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                error: "Password must be at least 8 characters long"
            });
        }

        // Verify JWT token first
        let decoded: any;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET!);
        } catch (error: any) {
            if (error.name === "TokenExpiredError") {
                return res.status(400).json({
                    success: false,
                    error: "Reset link has expired. Please request a new password reset."
                });
            }
            return res.status(400).json({
                success: false,
                error: "Invalid or malformed reset token"
            });
        }

        // Verify token type
        if (decoded.type !== 'reset') {
            return res.status(400).json({
                success: false,
                error: "Invalid token type"
            });
        }

        // Check if token exists in database and is not used
        const tokenRecord = await TokenModel.findByToken(token);
        if (!tokenRecord) {
            return res.status(400).json({
                success: false,
                error: "Invalid or expired reset token. This link may have already been used."
            });
        }

        // Verify user exists
        const user = await UserModel.findById(decoded.userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: "User not found"
            });
        }

        // Verify email matches (extra security)
        if (user.email !== decoded.email) {
            return res.status(400).json({
                success: false,
                error: "Invalid reset token"
            });
        }

        // Update user's password
        const updatedUser = await UserModel.update(user.id, { password });

        if (!updatedUser) {
            return res.status(500).json({
                success: false,
                error: "Failed to update password"
            });
        }

        // Mark token as used
        await TokenModel.markAsUsed(token);

        return res.status(200).json({
            success: true,
            message: "Password has been reset successfully. You can now login with your new password."
        });

    } catch (error) {
        console.error('Error during password change:', error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
}

export { register, completeRegistration, login, logout, checkUserLogging, checkAssistantInvitation, assistantRegistration, resetPassword, changePassword };