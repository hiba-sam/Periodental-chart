import type { Request, Response } from "express";
import { OpticalCorrectionModel, type CreateOpticalCorrectionData } from "../models/opticalCorrection.model";
import type { User } from "../models/user.model";
import { generateOpticalCorrectionPdf } from "../utils/opticalCorrectionPdf";
import { PatientModel } from "../models/patient.model";
import { MedicalShareModel } from "../models/medicalShare.model";
import { notifyUser } from "../services/notification.service";
import { getOrCreateTodayConsultation, markConsultationHasPrescription } from "../utils/consultationHelper";

// Create a new optical correction
const createOpticalCorrection = async (req: Request, res: Response) => {
  try {
    const {
      patient_id,
      od_sph, od_cyl, od_axis, od_add, od_pd,
      os_sph, os_cyl, os_axis, os_add, os_pd,
      remarks
    } = req.body;

    const user = req.user as User;
    const doctor_user_id = user.id;

    if (!patient_id) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.missing_fields'),
      });
    }

    const correctionData: CreateOpticalCorrectionData = {
      patient_id,
      doctor_user_id,
      od_sph, od_cyl, od_axis, od_add, od_pd,
      os_sph, os_cyl, os_axis, os_add, os_pd,
      remarks
    };

    const correction = await OpticalCorrectionModel.create(correctionData);

    // Link to consultation if needed
    try {
      const consultationId = await getOrCreateTodayConsultation(patient_id, doctor_user_id);
      await markConsultationHasPrescription(consultationId);
      console.log(`✅ Optical Correction linked to consultation ${consultationId}`);
    } catch (consultationError) {
      console.error('⚠️ Failed to link correction to consultation:', consultationError);
    }

    // Optional notification
    try {
      const patient = await PatientModel.findById(patient_id);
      if (patient) {
        const patientName = `${patient.name} ${patient.family_name}`;
        await notifyUser(
          doctor_user_id,
          'Ordonnance optique créée',
          `Ordonnance optique créée pour ${patientName}.`,
          'check'
        );
      }
    } catch (notifError) {
      console.error('[Notification] Failed to send optical correction notification:', notifError);
    }

    res.status(201).json({
      success: true,
      data: correction,
    });
  } catch (error) {
    console.error("Error creating optical correction:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Generate prescription pdf by ID
const generateThePdf = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id) return res.status(400).json({
      success: false,
      error: req.t('prescription.id_required')
    });

    await generateOpticalCorrectionPdf(parseInt(id), res);
  } catch (error) {
    console.error('Error during generating optical correction pdf', error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error')
    });
  }
};

// Get optical correction by ID with full details
const getOpticalCorrectionById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.id_invalid'),
      });
    }

    const correction = await OpticalCorrectionModel.findByIdWithDetails(parseInt(id));

    if (!correction) {
      return res.status(404).json({
        success: false,
        error: req.t('prescription.not_found'),
      });
    }

    res.json({
      success: true,
      data: correction,
    });
  } catch (error) {
    console.error("Error fetching optical correction:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Get optical corrections by patient ID (handling privacy)
const getOpticalCorrectionsByPatient = async (req: Request, res: Response) => {
  try {
    const { patientId } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    const requestingDoctorId = (req.user as any)?.id as number | undefined;

    if (!patientId) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.patient_id_invalid'),
      });
    }

    const patient = await PatientModel.findById(patientId, requestingDoctorId);

    // Share access logic
    let shareVisibleUntilDate: Date | null = null;

    if (!patient && requestingDoctorId) {
      const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'prescription');
      if (shareAccess.hasAccess) {
        shareVisibleUntilDate = shareAccess.visibleUntilDate;
      } else {
        return res.status(404).json({
           success: false,
           error: req.t('prescription.patient_not_found'),
        });
      }
    } else if (!patient) {
      return res.status(404).json({
          success: false,
          error: req.t('prescription.patient_not_found'),
      });
    } else if (requestingDoctorId) {
        const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'prescription');
        if (shareAccess.hasAccess) {
            shareVisibleUntilDate = shareAccess.visibleUntilDate;
        }
    }

    let corrections = await OpticalCorrectionModel.findByPatientId(
      patientId,
      parseInt(limit as string),
      parseInt(offset as string)
    );

    // Privacy & Share filters
    if (requestingDoctorId) {
      const { DoctorPatientPrivacyModel } = await import('../models/doctorPatientPrivacy.model');
      const sharedDoctorIds = await DoctorPatientPrivacyModel.getDoctorsWithSharedChoice(patientId);
      const receivedShares = await MedicalShareModel.findSharedWithDoctor(requestingDoctorId);
      const explicitlySharedDoctorIds = receivedShares
        .filter(s => String(s.patient_id) === String(patientId) && s.share_prescriptions)
        .map(s => s.shared_by_doctor_id);

      corrections = corrections.filter(p =>
        p.doctor_user_id === requestingDoctorId ||
        sharedDoctorIds.includes(p.doctor_user_id) ||
        explicitlySharedDoctorIds.includes(p.doctor_user_id)
      );
    }

    if (shareVisibleUntilDate) {
      const getLocalDateStr = (date: Date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      };
      const visibleDateStr = getLocalDateStr(shareVisibleUntilDate);
      
      corrections = corrections.filter(correction => {
        if (correction.doctor_user_id === requestingDoctorId) return true;
        const createdAt = new Date(correction.created_at);
        const createdDateStr = getLocalDateStr(createdAt);
        return createdDateStr >= visibleDateStr;
      });
    }

    res.json({
      success: true,
      data: corrections,
    });
  } catch (error) {
    console.error("Error fetching optical corrections by patient:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

export {
  createOpticalCorrection,
  getOpticalCorrectionById,
  getOpticalCorrectionsByPatient,
  generateThePdf
};
