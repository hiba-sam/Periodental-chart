import type { Request, Response } from 'express';
import { CustomMedicationModel } from '../models/customMedication.model';

/**
 * POST /api/custom-medications
 * Create a new custom medication
 */
export const createCustomMedication = async (req: Request, res: Response) => {
    try {
        const doctorId = (req.user as any)?.id;
        
        if (!doctorId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
        }

        const { nom_de_marque, denomination_commune_internationale, dosage, forme, laboratoire } = req.body;

        if (!nom_de_marque || nom_de_marque.trim() === '') {
            return res.status(400).json({
                success: false,
                error: 'Le nom du médicament est requis'
            });
        }

        // Check if similar medication already exists
        const existing = await CustomMedicationModel.findSimilar(nom_de_marque.trim());
        if (existing) {
            // Return existing one instead of creating duplicate
            return res.json({
                success: true,
                data: existing,
                message: 'Un médicament similaire existe déjà'
            });
        }

        const customMedication = await CustomMedicationModel.create({
            nom_de_marque: nom_de_marque.trim(),
            denomination_commune_internationale: denomination_commune_internationale?.trim(),
            dosage: dosage?.trim(),
            forme: forme?.trim(),
            laboratoire: laboratoire?.trim(),
            added_by_doctor_id: doctorId
        });

        return res.status(201).json({
            success: true,
            data: customMedication,
            message: 'Médicament personnalisé créé avec succès'
        });

    } catch (error: any) {
        console.error('❌ Create Custom Medication Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur lors de la création du médicament personnalisé'
        });
    }
};

/**
 * GET /api/custom-medications/search
 * Search custom medications
 */
export const searchCustomMedications = async (req: Request, res: Response) => {
    try {
        const { q, limit = '10' } = req.query;
        
        if (!q || typeof q !== 'string') {
            return res.json({
                success: true,
                data: []
            });
        }

        const results = await CustomMedicationModel.search(q, parseInt(limit as string));

        return res.json({
            success: true,
            data: results
        });

    } catch (error: any) {
        console.error('❌ Search Custom Medications Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur lors de la recherche'
        });
    }
};

/**
 * GET /api/custom-medications/pending
 * Get all pending custom medications (admin only)
 */
export const getPendingCustomMedications = async (req: Request, res: Response) => {
    try {
        const userRole = (req.user as any)?.role;
        
        if (userRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: 'Accès non autorisé'
            });
        }

        const medications = await CustomMedicationModel.findAllPending();

        return res.json({
            success: true,
            data: medications
        });

    } catch (error: any) {
        console.error('❌ Get Pending Custom Medications Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur lors de la récupération des médicaments'
        });
    }
};

/**
 * PUT /api/custom-medications/:id/status
 * Update custom medication status (admin only)
 */
export const updateCustomMedicationStatus = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const adminId = (req.user as any)?.id;
        const userRole = (req.user as any)?.role;
        
        if (userRole !== 'admin') {
            return res.status(403).json({
                success: false,
                error: 'Accès non autorisé'
            });
        }

        if (!['approved', 'rejected'].includes(status)) {
            return res.status(400).json({
                success: false,
                error: 'Statut invalide'
            });
        }

        const updated = await CustomMedicationModel.updateStatus(
            parseInt(id),
            status as 'approved' | 'rejected',
            adminId as number
        );

        if (!updated) {
            return res.status(404).json({
                success: false,
                error: 'Médicament non trouvé'
            });
        }

        return res.json({
            success: true,
            data: updated,
            message: `Médicament ${status === 'approved' ? 'approuvé' : 'rejeté'}`
        });

    } catch (error: any) {
        console.error('❌ Update Custom Medication Status Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur lors de la mise à jour du statut'
        });
    }
};

/**
 * GET /api/custom-medications/my
 * Get custom medications added by current doctor
 */
export const getMyCustomMedications = async (req: Request, res: Response) => {
    try {
        const doctorId = (req.user as any)?.id;
        
        if (!doctorId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
        }

        const medications = await CustomMedicationModel.findByDoctor(doctorId);

        return res.json({
            success: true,
            data: medications
        });

    } catch (error: any) {
        console.error('❌ Get My Custom Medications Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur lors de la récupération des médicaments'
        });
    }
};
