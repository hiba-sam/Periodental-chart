import type { Request, Response } from "express";
import { getRelatedPatients } from "../services/patient.service";

/**
 * Patient Statistics Controller
 *
 * Provides analytics for new and old patients grouped by:
 * - Week (last 7 days)
 * - Month (last 12 months)
 * - Year (last 5 years)
 *
 * Classification:
 * - New patients: created within last 6 months
 * - Old patients: created more than 6 months ago
 */

// French month names (abbreviated)
const FRENCH_MONTHS = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jui', 'Juil', 'Août', 'Sep', 'Oct', 'Nov', 'Déc'];

// French day names (abbreviated)
const FRENCH_DAYS = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];

interface PeriodData {
    period: string;
    patients: number;
}

interface StatisticsResponse {
    newPatients: {
        weeklyData: PeriodData[];
        monthlyData: PeriodData[];
        yearlyData: PeriodData[];
        total: number;
    };
    oldPatients: {
        weeklyData: PeriodData[];
        monthlyData: PeriodData[];
        yearlyData: PeriodData[];
        total: number;
    };
    summary: {
        totalPatients: number;
        newPatientsCount: number;
        oldPatientsCount: number;
        newPatientsPercentage: number;
        oldPatientsPercentage: number;
    };
}

/**
 * Generate weekly data (last 7 days)
 * Returns data for Mon-Sun of current week
 */
function generateWeeklyData(patients: any[]): PeriodData[] {
    const today = new Date();
    const weeklyData: PeriodData[] = [];

    // Get the start of the week (Monday)
    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
    const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // Adjust for Monday start
    const monday = new Date(today);
    monday.setDate(today.getDate() + mondayOffset);
    monday.setHours(0, 0, 0, 0);

    // Generate data for each day of the week (Mon-Sun)
    for (let i = 0; i < 7; i++) {
        const currentDay = new Date(monday);
        currentDay.setDate(monday.getDate() + i);
        const nextDay = new Date(currentDay);
        nextDay.setDate(currentDay.getDate() + 1);

        // Count patients created on this day
        const count = patients.filter(patient => {
            const createdAt = new Date(patient.created_at);
            return createdAt >= currentDay && createdAt < nextDay;
        }).length;

        // Monday = 1, so we need to map: Mon=1, Tue=2, ..., Sun=0
        const dayIndex = (i + 1) % 7; // Mon=1, Tue=2, ..., Sun=0
        weeklyData.push({
            period: FRENCH_DAYS[dayIndex] as string,
            patients: count
        });
    }

    return weeklyData;
}

/**
 * Generate monthly data (last 12 months)
 * Returns data for each of the last 12 months
 */
function generateMonthlyData(patients: any[]): PeriodData[] {
    const monthlyData: PeriodData[] = [];
    const today = new Date();

    // Generate data for last 12 months
    for (let i = 11; i >= 0; i--) {
        const monthDate = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const nextMonthDate = new Date(today.getFullYear(), today.getMonth() - i + 1, 1);

        // Count patients created in this month
        const count = patients.filter(patient => {
            const createdAt = new Date(patient.created_at);
            return createdAt >= monthDate && createdAt < nextMonthDate;
        }).length;

        monthlyData.push({
            period: FRENCH_MONTHS[monthDate.getMonth()] as string,
            patients: count
        });
    }

    return monthlyData;
}

/**
 * Generate yearly data (last 5 years)
 * Returns data for each of the last 5 years
 */
function generateYearlyData(patients: any[]): PeriodData[] {
    const yearlyData: PeriodData[] = [];
    const currentYear = new Date().getFullYear();

    // Generate data for last 5 years
    for (let i = 4; i >= 0; i--) {
        const year = currentYear - i;
        const yearStart = new Date(year, 0, 1);
        const yearEnd = new Date(year + 1, 0, 1);

        // Count patients created in this year
        const count = patients.filter(patient => {
            const createdAt = new Date(patient.created_at);
            return createdAt >= yearStart && createdAt < yearEnd;
        }).length;

        yearlyData.push({
            period: year.toString(),
            patients: count
        });
    }

    return yearlyData;
}

/**
 * Classify patients as new or old based on creation date
 * New: created within last 6 months
 * Old: created more than 6 months ago
 */
function classifyPatients(patients: any[]) {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const newPatients = patients.filter(patient => {
        const createdAt = new Date(patient.created_at);
        return createdAt >= sixMonthsAgo;
    });

    const oldPatients = patients.filter(patient => {
        const createdAt = new Date(patient.created_at);
        return createdAt < sixMonthsAgo;
    });

    return { newPatients, oldPatients };
}

/**
 * Remove duplicate patients based on patient ID
 */
function removeDuplicates(patients: any[]): any[] {
    const seen = new Set();
    return patients.filter(patient => {
        const id = patient.id;
        if (seen.has(id)) {
            return false;
        }
        seen.add(id);
        return true;
    });
}

/**
 * GET /patient/stat
 *
 * Get patient statistics for a doctor
 * Query param: doctorUserId (required)
 *
 * Returns analytics grouped by week, month, and year
 * for both new patients (last 6 months) and old patients (>6 months)
 */
export const getPatientStatistics = async (req: Request, res: Response) => {
    try {
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        // Validate doctor user ID
        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient_statistics.doctor_user_id_required')
            });
        }

        // Fetch only patients related to this doctor (patients with prescriptions from this doctor)
        const allPatients = await getRelatedPatients(doctorUserId);

        if (!allPatients || allPatients.length === 0) {
            return res.status(200).json({
                success: true,
                data: {
                    newPatients: {
                        weeklyData: generateWeeklyData([]),
                        monthlyData: generateMonthlyData([]),
                        yearlyData: generateYearlyData([]),
                        total: 0
                    },
                    oldPatients: {
                        weeklyData: generateWeeklyData([]),
                        monthlyData: generateMonthlyData([]),
                        yearlyData: generateYearlyData([]),
                        total: 0
                    },
                    summary: {
                        totalPatients: 0,
                        newPatientsCount: 0,
                        oldPatientsCount: 0,
                        newPatientsPercentage: 0,
                        oldPatientsPercentage: 0
                    }
                },
                message: req.t('patient_statistics.no_patients')
            });
        }

        // Remove duplicate patients
        const uniquePatients = removeDuplicates(allPatients);

        // Classify patients as new or old
        const { newPatients, oldPatients } = classifyPatients(uniquePatients);

        // Generate statistics for new patients
        const newPatientsStats = {
            weeklyData: generateWeeklyData(newPatients),
            monthlyData: generateMonthlyData(newPatients),
            yearlyData: generateYearlyData(newPatients),
            total: newPatients.length
        };

        // Generate statistics for old patients
        const oldPatientsStats = {
            weeklyData: generateWeeklyData(oldPatients),
            monthlyData: generateMonthlyData(oldPatients),
            yearlyData: generateYearlyData(oldPatients),
            total: oldPatients.length
        };

        // Calculate summary statistics
        const totalPatients = uniquePatients.length;
        const newPatientsCount = newPatients.length;
        const oldPatientsCount = oldPatients.length;

        const response: StatisticsResponse = {
            newPatients: newPatientsStats,
            oldPatients: oldPatientsStats,
            summary: {
                totalPatients,
                newPatientsCount,
                oldPatientsCount,
                newPatientsPercentage: totalPatients > 0
                    ? Math.round((newPatientsCount / totalPatients) * 100)
                    : 0,
                oldPatientsPercentage: totalPatients > 0
                    ? Math.round((oldPatientsCount / totalPatients) * 100)
                    : 0
            }
        };

        return res.status(200).json({
            success: true,
            data: response
        });

    } catch (error) {
        console.error("Error generating patient statistics:", error);
        return res.status(500).json({
            success: false,
            error: req.t('patient_statistics.generate_error')
        });
    }
};

/**
 * GET /patient/stat/summary
 *
 * Get quick summary statistics for a doctor's patients
 * Query param: doctorUserId (required)
 */
export const getPatientStatisticsSummary = async (req: Request, res: Response) => {
    try {
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient_statistics.doctor_user_id_required')
            });
        }

        // Fetch only patients related to this doctor (patients with prescriptions from this doctor)
        const allPatients = await getRelatedPatients(doctorUserId);

        if (!allPatients || allPatients.length === 0) {
            return res.status(200).json({
                success: true,
                data: {
                    totalPatients: 0,
                    newPatients: 0,
                    oldPatients: 0,
                    thisWeek: 0,
                    thisMonth: 0,
                    thisYear: 0
                }
            });
        }

        // Remove duplicates
        const uniquePatients = removeDuplicates(allPatients);

        // Classify patients
        const { newPatients, oldPatients } = classifyPatients(uniquePatients);

        // Calculate time-based counts
        const now = new Date();
        const startOfWeek = new Date(now);
        const dayOfWeek = now.getDay();
        const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
        startOfWeek.setDate(now.getDate() + mondayOffset);
        startOfWeek.setHours(0, 0, 0, 0);

        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const startOfYear = new Date(now.getFullYear(), 0, 1);

        const thisWeek = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfWeek
        ).length;

        const thisMonth = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfMonth
        ).length;

        const thisYear = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfYear
        ).length;

        return res.status(200).json({
            success: true,
            data: {
                totalPatients: uniquePatients.length,
                newPatients: newPatients.length,
                oldPatients: oldPatients.length,
                thisWeek,
                thisMonth,
                thisYear
            }
        });

    } catch (error) {
        console.error("Error generating patient statistics summary:", error);
        return res.status(500).json({
            success: false,
            error: req.t('patient_statistics.summary_error')
        });
    }
};

/**
 * GET /patient/stat/growth
 *
 * Get patient growth rate statistics
 * Query param: doctorUserId (required)
 */
export const getPatientGrowthRate = async (req: Request, res: Response) => {
    try {
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient_statistics.doctor_user_id_required')
            });
        }

        // Fetch only patients related to this doctor (patients with prescriptions from this doctor)
        const allPatients = await getRelatedPatients(doctorUserId);

        if (!allPatients || allPatients.length === 0) {
            return res.status(200).json({
                success: true,
                data: {
                    weeklyGrowth: 0,
                    monthlyGrowth: 0,
                    yearlyGrowth: 0
                }
            });
        }

        // Remove duplicates
        const uniquePatients = removeDuplicates(allPatients);

        const now = new Date();

        // This week vs last week
        const startOfThisWeek = new Date(now);
        const dayOfWeek = now.getDay();
        const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
        startOfThisWeek.setDate(now.getDate() + mondayOffset);
        startOfThisWeek.setHours(0, 0, 0, 0);

        const startOfLastWeek = new Date(startOfThisWeek);
        startOfLastWeek.setDate(startOfThisWeek.getDate() - 7);

        const thisWeekCount = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfThisWeek
        ).length;

        const lastWeekCount = uniquePatients.filter(p => {
            const created = new Date(p.created_at);
            return created >= startOfLastWeek && created < startOfThisWeek;
        }).length;

        const weeklyGrowth = lastWeekCount > 0
            ? Math.round(((thisWeekCount - lastWeekCount) / lastWeekCount) * 100)
            : thisWeekCount > 0 ? 100 : 0;

        // This month vs last month
        const startOfThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

        const thisMonthCount = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfThisMonth
        ).length;

        const lastMonthCount = uniquePatients.filter(p => {
            const created = new Date(p.created_at);
            return created >= startOfLastMonth && created < startOfThisMonth;
        }).length;

        const monthlyGrowth = lastMonthCount > 0
            ? Math.round(((thisMonthCount - lastMonthCount) / lastMonthCount) * 100)
            : thisMonthCount > 0 ? 100 : 0;

        // This year vs last year
        const startOfThisYear = new Date(now.getFullYear(), 0, 1);
        const startOfLastYear = new Date(now.getFullYear() - 1, 0, 1);

        const thisYearCount = uniquePatients.filter(p =>
            new Date(p.created_at) >= startOfThisYear
        ).length;

        const lastYearCount = uniquePatients.filter(p => {
            const created = new Date(p.created_at);
            return created >= startOfLastYear && created < startOfThisYear;
        }).length;

        const yearlyGrowth = lastYearCount > 0
            ? Math.round(((thisYearCount - lastYearCount) / lastYearCount) * 100)
            : thisYearCount > 0 ? 100 : 0;

        return res.status(200).json({
            success: true,
            data: {
                weeklyGrowth,
                monthlyGrowth,
                yearlyGrowth,
                details: {
                    week: { current: thisWeekCount, previous: lastWeekCount },
                    month: { current: thisMonthCount, previous: lastMonthCount },
                    year: { current: thisYearCount, previous: lastYearCount }
                }
            }
        });

    } catch (error) {
        console.error("Error calculating patient growth rate:", error);
        return res.status(500).json({
            success: false,
            error: req.t('patient_statistics.growth_error')
        });
    }
};
