import type { Request, Response } from "express";
import { AdminModel } from "../models/admin.model";
import { AuditModel } from "../models/audit.model";
import { UserModel } from "../models/user.model";
import { DoctorModel } from "../models/doctor.model";
import { AssistantModel } from "../models/assistant.model";
import bcrypt from 'bcrypt';
import { notifyUserRegistration } from "../services/notification.service";
import { emailService } from "../utils/email";

// ============================================
// ADMIN AUTHENTICATION
// ============================================

/**
 * Admin login
 */
export const adminLogin = async (req: Request, res: Response) => {
    try {
        const { email, password } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.email_password_required')
            });
        }

        // Find admin by email
        const admin = await AdminModel.findByEmail(email);

        if (!admin) {
            // Log failed attempt
            await AuditModel.create({
                admin_id: null,
                admin_name: 'Unknown',
                admin_email: email,
                action: 'LOGIN_FAILED',
                ip_address: req.ip,
                user_agent: req.get('user-agent'),
                notes: 'Admin not found',
                status: 'failed'
            });

            return res.status(401).json({
                success: false,
                error: req.t('admin.invalid_credentials')
            });
        }

        // Check if admin is active
        if (!admin.is_active) {
            await AuditModel.create({
                admin_id: admin.id,
                admin_name: admin.name,
                admin_email: admin.email,
                action: 'LOGIN_FAILED',
                ip_address: req.ip,
                user_agent: req.get('user-agent'),
                notes: 'Account deactivated',
                status: 'failed'
            });

            return res.status(403).json({
                success: false,
                error: req.t('admin.account_deactivated')
            });
        }

        // Verify password
        const passwordMatch = await bcrypt.compare(password, admin.password);

        if (!passwordMatch) {
            await AuditModel.create({
                admin_id: admin.id,
                admin_name: admin.name,
                admin_email: admin.email,
                action: 'LOGIN_FAILED',
                ip_address: req.ip,
                user_agent: req.get('user-agent'),
                notes: 'Invalid password',
                status: 'failed'
            });

            return res.status(401).json({
                success: false,
                error: req.t('admin.invalid_credentials')
            });
        }

        // Update last login
        await AdminModel.updateLastLogin(admin.id);

        // Create session
        req.session.admin = {
            id: admin.id,
            name: admin.name,
            email: admin.email,
            role: admin.role
        };

        // Log successful login
        await AuditModel.create({
            admin_id: admin.id,
            admin_name: admin.name,
            admin_email: admin.email,
            action: 'LOGIN_SUCCESS',
            ip_address: req.ip,
            user_agent: req.get('user-agent'),
            session_id: req.sessionID,
            status: 'success'
        });

        res.json({
            success: true,
            message: req.t('admin.login_success'),
            data: {
                admin: {
                    id: admin.id,
                    name: admin.name,
                    email: admin.email,
                    role: admin.role
                }
            }
        });

    } catch (error) {
        console.error('❌ Admin login error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Admin logout
 */
export const adminLogout = async (req: Request, res: Response) => {
    try {
        const admin = req.admin;

        if (admin) {
            // Log logout
            await AuditModel.create({
                admin_id: admin.id,
                admin_name: admin.name,
                admin_email: admin.email,
                action: 'LOGOUT',
                ip_address: req.ip,
                user_agent: req.get('user-agent'),
                status: 'success'
            });
        }

        // Destroy session
        req.session.destroy((err) => {
            if (err) {
                console.error('⚠️ Session destruction error:', err);
            }
        });

        res.clearCookie("connect.sid");

        res.json({
            success: true,
            message: req.t('admin.logout_success')
        });

    } catch (error) {
        console.error('❌ Admin logout error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Check admin session
 */
export const checkAdminSession = async (req: Request, res: Response) => {
    try {
        if (!req.admin) {
            return res.status(401).json({
                success: false,
                error: req.t('admin.not_authenticated')
            });
        }

        res.json({
            success: true,
            data: {
                admin: req.admin
            }
        });

    } catch (error) {
        console.error('❌ Session check error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

// ============================================
// REGISTRATION MANAGEMENT
// ============================================

/**
 * Get pending registrations
 */
export const getPendingRegistrations = async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        // Get inactive users (pending approval)
        const users = await UserModel.getInactive(limit, offset);

        // For doctors, get additional info
        const usersWithDetails = await Promise.all(
            users.map(async (user) => {
                if (user.role === 'doctor') {
                    const doctorInfo = await DoctorModel.findByUserId(user.id);
                    return {
                        ...user,
                        doctor_info: doctorInfo
                    };
                }
                return user;
            })
        );

        res.json({
            success: true,
            data: {
                registrations: usersWithDetails,
                total: usersWithDetails.length
            }
        });

    } catch (error) {
        console.error('❌ Get pending registrations error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get registration details by ID
 */
export const getRegistrationDetails = async (req: Request, res: Response) => {
    try {
        const userId = parseInt(req.params.id as string);

        if (isNaN(userId)) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.invalid_user_id')
            });
        }

        const user = await UserModel.findById(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: req.t('admin.user_not_found')
            });
        }

        let doctorInfo = await DoctorModel.findByUserId(user.id);
        let assistantInfo = await AssistantModel.findByDoctorId(user.id);

        // Get audit history for this user
        const auditHistory = await AuditModel.getByTarget('user', userId, 10, 0);

        res.json({
            success: true,
            data: {
                user,
                doctor_info: doctorInfo,
                assistant_info: assistantInfo,
                audit_history: auditHistory
            }
        });

    } catch (error) {
        console.error('❌ Get registration details error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Approve registration
 */
export const approveRegistration = async (req: Request, res: Response) => {
    try {
        const userId = parseInt(req.params.id as string);
        const { notes, certificates, experience } = req.body;
        const admin = req.admin!;

        if (isNaN(userId)) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.invalid_user_id')
            });
        }

        // Get user
        const user = await UserModel.findById(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: req.t('admin.user_not_found')
            });
        }

        // Check if already active
        if (user.is_active) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.user_already_approved')
            });
        }

        // Calculate end_date: +14 days from now for test plan
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + 14);

        // Update doctor details if provided
        if (user.role === 'doctor' && (certificates || experience)) {
            await DoctorModel.update(userId, {
                certificates: certificates,
                experience: experience
            });
        }

        // Activate user and set test plan with 14-day trial
        const updatedUser = await UserModel.update(userId, {
            is_active: true,
            plan: 'test',
            end_date: endDate
        });

        if (!updatedUser) {
            throw new Error(req.t('admin.failed_update_user'));
        }

        // Create audit log
        await AuditModel.create({
            admin_id: admin.id,
            admin_name: admin.name,
            admin_email: admin.email,
            action: 'APPROVE_REGISTRATION',
            target_type: 'user',
            target_id: userId,
            target_name: `${user.name} ${user.family_name}`,
            ip_address: req.ip,
            user_agent: req.get('user-agent'),
            session_id: req.sessionID,
            notes: notes || 'Registration approved',
            metadata: {
                user_email: user.email,
                user_role: user.role
            },
            status: 'success'
        });

        // Send notification to user
        await notifyUserRegistration(
            updatedUser.id,
            `${updatedUser.name} ${updatedUser.family_name}`
        );

        // Send approval email to user
        try {
            await emailService.sendApprovalEmail(
                updatedUser.email,
                updatedUser.name
            );
            console.log(`✅ Approval email sent to ${updatedUser.email}`);
        } catch (emailError) {
            console.error('⚠️ Failed to send approval email:', emailError);
            // Don't fail the request if email fails
        }

        // Send assistant invitation emails if any were stored during registration
        if (updatedUser.role === 'doctor') {
            try {
                const pendingInvitations = await AssistantModel.findPendingByDoctorId(updatedUser.id);

                if (pendingInvitations.length > 0) {
                    const doctorName = `${updatedUser.name} ${updatedUser.family_name}`;

                    // Send invitation emails to all pending assistants
                    for (const invitation of pendingInvitations) {
                        if (invitation.invitation_token) {
                            emailService.sendAssistantInvitation(
                                invitation.assistant_email,
                                invitation.assistant_name,
                                doctorName,
                                invitation.invitation_token
                            ).catch(error => {
                                console.error(`⚠️ Failed to send invitation email to ${invitation.assistant_email}:`, error);
                            });
                        }
                    }

                    console.log(`✅ Sent ${pendingInvitations.length} assistant invitation(s) for approved doctor ${updatedUser.id}`);
                }
            } catch (error) {
                console.error('⚠️ Error sending assistant invitations:', error);
                // Don't fail the approval if invitation emails fail
            }
        }

        res.json({
            success: true,
            message: req.t('admin.registration_approved'),
            data: {
                user: updatedUser
            }
        });

    } catch (error) {
        console.error('❌ Approve registration error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Reject registration
 */
export const rejectRegistration = async (req: Request, res: Response) => {
    try {
        const userId = parseInt(req.params.id as string);
        const { notes, reason } = req.body;
        const admin = req.admin!;

        if (isNaN(userId)) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.invalid_user_id')
            });
        }

        // Get user
        const user = await UserModel.findById(userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: req.t('admin.user_not_found')
            });
        }

        // Check if already active
        if (user.is_active) {
            return res.status(400).json({
                success: false,
                error: req.t('admin.cannot_reject_approved')
            });
        }

        // Send rejection email to user BEFORE deletion
        try {
            await emailService.sendRejectionEmail(
                user.email,
                user.name,
                reason || notes
            );
            console.log(`✅ Rejection email sent to ${user.email}`);
        } catch (emailError) {
            console.error('⚠️ Failed to send rejection email:', emailError);
            // Don't fail the request if email fails
        }

        // Create audit log before deletion
        await AuditModel.create({
            admin_id: admin.id,
            admin_name: admin.name,
            admin_email: admin.email,
            action: 'REJECT_REGISTRATION',
            target_type: 'user',
            target_id: userId,
            target_name: `${user.name} ${user.family_name}`,
            ip_address: req.ip,
            user_agent: req.get('user-agent'),
            session_id: req.sessionID,
            notes: notes || reason || 'Registration rejected',
            metadata: {
                user_email: user.email,
                user_role: user.role,
                rejection_reason: reason || notes
            },
            status: 'success'
        });

        // Delete user and related data
        if (user.role === 'doctor') {
            // Clean up any pending assistant invitations for rejected doctor
            try {
                const pendingInvitations = await AssistantModel.findPendingByDoctorId(userId);
                for (const invitation of pendingInvitations) {
                    await AssistantModel.delete(invitation.id);
                }
                if (pendingInvitations.length > 0) {
                    console.log(`✅ Cleaned up ${pendingInvitations.length} pending assistant invitation(s) for rejected doctor ${userId}`);
                }
            } catch (error) {
                console.error('⚠️ Error cleaning up assistant invitations:', error);
                // Don't fail the rejection if cleanup fails
            }

            await DoctorModel.delete(userId);
        }
        await UserModel.delete(userId);

        res.json({
            success: true,
            message: req.t('admin.registration_rejected')
        });

    } catch (error) {
        console.error('❌ Reject registration error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

// ============================================
// AUDIT LOGS
// ============================================

/**
 * Get audit logs
 */
export const getAuditLogs = async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;
        const action = req.query.action as string;
        const adminId = req.query.admin_id ? parseInt(req.query.admin_id as string) : undefined;

        const filters: any = {};
        if (action) filters.action = action;
        if (adminId) filters.admin_id = adminId;

        const logs = await AuditModel.getFiltered(filters, limit, offset);
        const totalCount = await AuditModel.getCount(filters);

        res.json({
            success: true,
            data: {
                logs,
                total: totalCount,
                limit,
                offset
            }
        });

    } catch (error) {
        console.error('❌ Get audit logs error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};

/**
 * Get audit statistics
 */
export const getAuditStats = async (req: Request, res: Response) => {
    try {
        const actionStats = await AuditModel.getActionStats();
        const adminStats = await AuditModel.getAdminStats(30);

        res.json({
            success: true,
            data: {
                action_stats: actionStats,
                admin_stats: adminStats
            }
        });

    } catch (error) {
        console.error('❌ Get audit stats error:', error);
        res.status(500).json({
            success: false,
            error: req.t('error.server_error')
        });
    }
};
