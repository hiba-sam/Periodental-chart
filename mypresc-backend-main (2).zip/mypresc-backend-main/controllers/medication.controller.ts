import type { Request, Response } from "express";
import { MedicationModel } from "../models/medication.model";

// Get medication by ID
const getMedicationById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({
        success: false,
        error: req.t('medication.id_invalid'),
      });
    }

    const medication = await MedicationModel.findById(parseInt(id));

    if (!medication) {
      return res.status(404).json({
        success: false,
        error: req.t('medication.not_found'),
      });
    }

    res.json({
      success: true,
      data: medication,
    });
  } catch (error) {
    console.error("Error fetching medication:", error);
    res.status(500).json({
      success: false,
      error: req.t('medication.server_error'),
    });
  }
};

// Search medications
const searchMedications = async (req: Request, res: Response) => {
  try {
    const { searchTerm, limit = 50 } = req.query;

    if (!searchTerm || typeof searchTerm !== 'string') {
      return res.status(400).json({
        success: false,
        error: req.t('medication.search_term_required'),
      });
    }

    const medications = await MedicationModel.search(searchTerm, parseInt(limit as string));

    res.json({
      success: true,
      data: medications,
      count: medications.length,
    });
  } catch (error) {
    console.error("Error searching medications:", error);
    res.status(500).json({
      success: false,
      error: req.t('medication.server_error'),
    });
  }
};

// Get all medications with pagination
const getAllMedications = async (req: Request, res: Response) => {
  try {
    const { limit = 50, offset = 0 } = req.query;

    const medications = await MedicationModel.findAll(
      parseInt(limit as string),
      parseInt(offset as string)
    );

    res.json({
      success: true,
      data: medications,
      count: medications.length,
    });
  } catch (error) {
    console.error("Error fetching medications:", error);
    res.status(500).json({
      success: false,
      error: req.t('medication.server_error'),
    });
  }
};

export {
  getMedicationById,
  searchMedications,
  getAllMedications,
}; 