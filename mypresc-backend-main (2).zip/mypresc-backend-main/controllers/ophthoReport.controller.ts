import type { Request, Response } from 'express';
import multer from 'multer';
import { OphthoReportModel } from '../models/ophthoReport.model.js';
import { parseOphthoXml, flattenForDb } from '../utils/ophthoXmlParser.js';
import { generateOphthoReportPdf } from '../utils/ophthoReportPdf.js';

// ─── Multer: memory storage for XML upload ───────────────────────────────────
export const xmlUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
        if (
            file.mimetype === 'text/xml' ||
            file.mimetype === 'application/xml' ||
            file.originalname.endsWith('.xml')
        ) {
            cb(null, true);
        } else {
            cb(new Error('Only XML files are accepted'));
        }
    },
});

// ─── POST /api/patients/:patientId/ophtho-reports/upload ─────────────────────
export const uploadOphthoReport = async (req: Request, res: Response) => {
    try {
        const patientId = String(req.params.patientId ?? '');
        const userId    = (req.user as any)?.id as number;

        if (!req.file) {
            return res.status(400).json({ success: false, error: 'No XML file uploaded' });
        }

        let parsed;
        try {
            parsed = parseOphthoXml(req.file.buffer);
        } catch (parseErr: any) {
            return res.status(422).json({
                success: false,
                error: `XML parse error: ${parseErr.message}`,
            });
        }

        const xmlRaw = req.file.buffer.toString('utf-8');
        const dbData = flattenForDb(parsed, patientId, userId, xmlRaw);

        const report = await OphthoReportModel.create({
            patient_id:    patientId,
            doctor_user_id: userId,
            ...dbData,
        });
        const full = await OphthoReportModel.findById(report.id);

        return res.status(201).json({ success: true, data: full });
    } catch (error) {
        console.error('Upload ophtho report error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};

// ─── GET /api/patients/:patientId/ophtho-reports ─────────────────────────────
export const getPatientOphthoReports = async (req: Request, res: Response) => {
    try {
        const patientId = String(req.params.patientId ?? '');
        const reports   = await OphthoReportModel.findByPatient(patientId);
        return res.json({ success: true, data: reports });
    } catch (error) {
        console.error('Get ophtho reports error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};

// ─── GET /api/ophtho-reports/:id ─────────────────────────────────────────────
export const getOphthoReport = async (req: Request, res: Response) => {
    try {
        const id = parseInt(String(req.params.id ?? ''));
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const report = await OphthoReportModel.findById(id);
        if (!report) return res.status(404).json({ success: false, error: 'Report not found' });

        return res.json({ success: true, data: report });
    } catch (error) {
        console.error('Get ophtho report error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};

// ─── PATCH /api/ophtho-reports/:id ───────────────────────────────────────────
export const updateOphthoReport = async (req: Request, res: Response) => {
    try {
        const id     = parseInt(String(req.params.id ?? ''));
        const userId = (req.user as any)?.id as number;
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const isOwner = await OphthoReportModel.checkOwnership(id, userId);
        if (!isOwner) return res.status(403).json({ success: false, error: 'Not authorized' });

        const { clinical_notes, diagnosis } = req.body;
        const updated = await OphthoReportModel.update(id, { clinical_notes, diagnosis });
        if (!updated) return res.status(404).json({ success: false, error: 'Report not found' });

        return res.json({ success: true, data: updated });
    } catch (error) {
        console.error('Update ophtho report error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};

// ─── DELETE /api/ophtho-reports/:id ──────────────────────────────────────────
export const deleteOphthoReport = async (req: Request, res: Response) => {
    try {
        const id     = parseInt(String(req.params.id ?? ''));
        const userId = (req.user as any)?.id as number;
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });

        const isOwner = await OphthoReportModel.checkOwnership(id, userId);
        if (!isOwner) return res.status(403).json({ success: false, error: 'Not authorized' });

        const deleted = await OphthoReportModel.delete(id);
        if (!deleted) return res.status(404).json({ success: false, error: 'Report not found' });

        return res.json({ success: true, message: 'Ophthalmology report deleted' });
    } catch (error) {
        console.error('Delete ophtho report error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};

// ─── GET /api/ophtho-reports/:id/pdf ─────────────────────────────────────────
export const generateOphthoReportPdfController = async (req: Request, res: Response) => {
    try {
        const id     = parseInt(String(req.params.id ?? ''));
        const userId = (req.user as any)?.id as number;
        if (isNaN(id)) return res.status(400).json({ success: false, error: 'Invalid ID' });
        if (!userId)   return res.status(401).json({ success: false, error: 'Unauthorized' });

        await generateOphthoReportPdf(id, res, userId);
    } catch (error) {
        console.error('Generate ophtho PDF error:', error);
        return res.status(500).json({ success: false, error: 'Internal server error' });
    }
};
