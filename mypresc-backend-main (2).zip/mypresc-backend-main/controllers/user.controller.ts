import type { Request, Response } from "express";
import { UserModel, type UpdateUserData } from "../models/user.model";
import { DoctorModel, type UpdateDoctorData } from "../models/doctor.model";
import { notifyProfileUpdate, notifyPasswordReset } from "../services/notification.service";
import bcrypt from 'bcrypt';
import { AssistantModel } from "../models/assistant.model";
import { isPlanExpired } from "../utils/planHelper";
import { ProfileStatisticService } from "../services/profileStatistic.service";

const standardWorkTime = {
    "Friday": "Closed",
    "Monday": "08:00 - 16:00",
    "Sunday": "08:00- 16:00",
    "Tuesday": "08:00- 16:00",
    "Saturday": "08:00- 16:00",
    "Thursday": "08:00- 16:00",
    "Wednesday": "08:00 - 16:00"
};

export const getMe = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({ success: false, error: req.t('user.auth_required') });
        }

        // Ensure we have the most up-to-date user from DB (and to get typings consistent)
        const user = await UserModel.findById((req.user as any).id);
        if (!user) {
            return res.status(404).json({ success: false, error: req.t('user.user_not_found') });
        }

        let doctor = null as any;
        let assistant = null as any;

        // Check if plan is expired
        const is_plan_expired = isPlanExpired(user.end_date);

        // sent back data based on role
        let sentedData = {};
        if (user.role === "doctor") {
            doctor = await DoctorModel.findByUserId(user.id);

            // Get statistics
            const statistics = await ProfileStatisticService.getDoctorStatistics(user.id);

            sentedData = {
                ...user,
                ...doctor,
                work_time: Object.keys(doctor?.work_time || {}).length === 0
                    ? standardWorkTime : doctor?.work_time,
                is_plan_expired,
                statistics,
            };
        } else if (user.role === "assistant") {
            assistant = await AssistantModel.findByUserId(user.id);
            doctor = await DoctorModel.findByUserId(assistant?.doctor_id);
            const doctorUser = doctor ? await UserModel.findById(doctor.user_id) : null;

            // Check plan expiration for the doctor (assistants inherit doctor's plan)
            const doctor_plan_expired = isPlanExpired(doctorUser?.end_date);

            sentedData = {
                doctor_name: doctorUser?.name,
                doctor_family_name: doctorUser?.family_name,
                doctor_email: doctorUser?.email,
                doctor_phone_number: doctor?.phone_number,
                phone_number: assistant?.phone_number,
                id: assistant?.doctor_id,
                assistant_id: user.id,
                name: user.name,
                family_name: user.family_name,
                email: user.email,
                role: user.role,
                is_active: user.is_active,
                created_at: user.created_at,
                updated_at: user.updated_at,
                work_time: Object.keys(doctor?.work_time || {}).length === 0
                    ? standardWorkTime : doctor?.work_time,
                work_location: doctor?.work_location,
                plan: doctorUser?.plan,
                end_date: doctorUser?.end_date,
                is_plan_expired: doctor_plan_expired,
            };
        } else {
            // Default (e.g. admin)
            sentedData = {
                ...user
            };
        }

        return res.status(200).json({
            success: true,
            data: sentedData,
        });
    } catch (error) {
        console.error("Error in getMe:", error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

export const updateMe = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({ success: false, error: req.t('user.auth_required') });
        }

        let userId = (req.user as any).id as number;

        // Split user vs doctor update data
        const {
            name,
            family_name,
            password,
            currentPassword,
            is_active,
            // doctor fields (optional)
            birth_date,
            birth_place,
            work_location,
            home_location,
            phone_number,
            work_time,
            languages,
            about,
            speciality,
            experience,
            // doctor user id from assistant role
            doctor_id
        } = req.body || {};

        // ✅ Security: Verify current password before allowing password change
        if (password !== undefined) {
            // Password change requires current password
            if (!currentPassword) {
                return res.status(400).json({
                    success: false,
                    error: req.t('user.current_password_required')
                });
            }

            // Fetch user to verify current password
            const user = await UserModel.findById(userId);
            if (!user) {
                return res.status(404).json({
                    success: false,
                    error: req.t('user.user_not_found')
                });
            }

            // Verify current password
            const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
            if (!isPasswordValid) {
                return res.status(401).json({
                    success: false,
                    error: req.t('user.current_password_incorrect')
                });
            }

            // Ensure new password is different from current password
            const isSamePassword = await bcrypt.compare(password, user.password);
            if (isSamePassword) {
                return res.status(400).json({
                    success: false,
                    error: req.t('user.new_password_different')
                });
            }
        }

        const userUpdate: UpdateUserData = {};
        if (name !== undefined) userUpdate.name = name;
        if (family_name !== undefined) userUpdate.family_name = family_name;
        if (password !== undefined) {
            userUpdate.password = password;
        }
        if (is_active !== undefined) userUpdate.is_active = is_active; // typically admin only
        // do not allow changing role here

        let updatedUser = null;
        if (Object.keys(userUpdate).length > 0) {
            updatedUser = await UserModel.update(userId, userUpdate);
        }

        const freshUser = updatedUser ?? (await UserModel.findById(userId));
        let updatedDoctor = null;
        let updatedAssistant = null;

        if (freshUser) {

            // For assistants: update assistant's phone_number separately
            if (freshUser.role === 'assistant' && phone_number !== undefined) {
                const assistant = await AssistantModel.findByUserId(freshUser.id);
                if (assistant) {
                    updatedAssistant = await AssistantModel.update(assistant.id, { phone_number });
                }
            }

            const doctorUpdate: UpdateDoctorData = {};
            if (birth_date !== undefined) doctorUpdate.birth_date = birth_date;
            if (birth_place !== undefined) doctorUpdate.birth_place = birth_place;
            if (work_location !== undefined) doctorUpdate.work_location = work_location;
            if (home_location !== undefined) doctorUpdate.home_location = home_location;
            // For doctors: update phone_number in doctor table
            // For assistants: skip phone_number (already updated in assistant table)
            if (phone_number !== undefined && freshUser.role === 'doctor') {
                doctorUpdate.phone_number = phone_number;
            }
            if (work_time !== undefined) doctorUpdate.work_time = work_time;
            if (languages !== undefined) doctorUpdate.languages = languages;
            if (about !== undefined) doctorUpdate.about = about;
            if (speciality !== undefined) doctorUpdate.speciality = speciality;
            if (experience !== undefined) doctorUpdate.experience = experience;

            if (Object.keys(doctorUpdate).length > 0) {
                updatedDoctor = await DoctorModel.update(freshUser.role === 'assistant' ? doctor_id : userId, doctorUpdate);
            } else {
                updatedDoctor = await DoctorModel.findByUserId(freshUser.role === 'assistant' ? doctor_id : userId);
            }
        } else {
            return res.status(404).json({ success: false, error: req.t('user.user_not_found') });
        }

        // ✅ Notification: Profile updated
        // Notify the user about their profile update
        try {
            const wasPasswordChanged = password !== undefined;

            if (wasPasswordChanged) {
                // Special notification for password change
                await notifyPasswordReset(userId);
            } else if (Object.keys(userUpdate).length > 0 || (updatedDoctor && Object.keys(updatedDoctor || {}).length > 0)) {
                // Regular profile update notification
                await notifyProfileUpdate(userId);
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send profile update notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Return data in the same format as getMe
        let sentedData = {} as any;
        if (freshUser.role === "doctor") {
            sentedData = {
                ...freshUser,
                ...updatedDoctor
            };
        } else if (freshUser.role === "assistant") {
            // Fetch fresh assistant data (to get updated phone_number)
            const assistant = updatedAssistant || await AssistantModel.findByUserId(freshUser.id);
            const doctor = assistant?.doctor_id ? await DoctorModel.findByUserId(assistant.doctor_id) : null;
            const doctorUser = doctor ? await UserModel.findById(doctor.user_id) : null;
            sentedData = {
                doctor_name: doctorUser?.name,
                doctor_family_name: doctorUser?.family_name,
                doctor_email: doctorUser?.email,
                doctor_phone_number: doctor?.phone_number,
                phone_number: assistant?.phone_number,
                id: assistant?.doctor_id,
                assistant_id: freshUser.id,
                name: freshUser.name,
                family_name: freshUser.family_name,
                email: freshUser.email,
                role: freshUser.role,
                is_active: freshUser.is_active,
                created_at: freshUser.created_at,
                updated_at: freshUser.updated_at,
                work_time: doctor?.work_time,
                work_location: doctor?.work_location,
            };
        }

        return res.status(200).json({
            success: true,
            message: req.t('user.profile_update_success'),
            data: sentedData
        });
    } catch (error) {
        console.error("Error in updateMe:", error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

export const changeLanguage = async (req: Request, res: Response) => {
    try {
        const { language } = req.body;

        if (!language) {
            return res.status(400).json({ success: false, error: "Language is required" });
        }

        const allowedLanguages = ['en', 'fr', 'ar'];
        if (!allowedLanguages.includes(language)) {
            return res.status(400).json({ success: false, error: "Invalid language. Allowed: en, fr, ar" });
        }

        const userId = (req.user as any).id as number;
        const updatedUser = await UserModel.update(userId, { language });

        if (!updatedUser) {
            return res.status(404).json({ success: false, error: req.t('user.user_not_found') });
        }

        return res.status(200).json({
            success: true,
            data: { language: updatedUser.language },
            message: "Language updated successfully"
        });

    } catch (error) {
        console.error("Error in changeLanguage:", error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};