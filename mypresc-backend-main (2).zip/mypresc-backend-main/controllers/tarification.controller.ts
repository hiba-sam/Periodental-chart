import type { Request, Response } from "express";
import { TarificationModel, type CreateTarificationData, type UpdateTarificationData } from "../models/tarification.model";
import type { User } from "../models/user.model";
import { AssistantModel } from "../models/assistant.model";

/**
 * Helper function to get the doctor user ID based on user role
 * - For doctors: returns their own user ID
 * - For assistants: returns their associated doctor's user ID
 */
const getDoctorUserId = async (user: User): Promise<number | null> => {
    if (user.role === 'doctor') {
        return user.id;
    } else if (user.role === 'assistant') {
        const assistant = await AssistantModel.findByUserId(user.id);
        return assistant?.doctor_id || null;
    }
    return null;
};

/**
 * Get all tarifications for a doctor
 * Works for both doctors and assistants
 * Note: Default tarifications are created during doctor registration
 */
const getTarificationsByDoctor = async (req: Request, res: Response) => {
    try {
        const user = req?.user as User;

        if (!user) {
            return res.status(401).json({
                success: false,
                error: req.t('tarification.auth_required')
            });
        }

        const doctorUserId = await getDoctorUserId(user);

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.doctor_user_id_not_found')
            });
        }

        // Return all tarifications for the doctor (default services are created during registration)
        const tarifications = await TarificationModel.findByDoctorUserId(doctorUserId);

        res.status(200).json({
            success: true,
            data: tarifications
        });

    } catch (error) {
        console.error("Error getting tarifications:", error);
        res.status(500).json({
            success: false,
            error: req.t('tarification.server_error')
        });
    }
};

/**
 * Get a single tarification by ID
 */
const getTarificationById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const user = req.user as User;

        if (!id || isNaN(Number(id))) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.id_required')
            });
        }

        const tarification = await TarificationModel.findById(Number(id));

        if (!tarification) {
            return res.status(404).json({
                success: false,
                error: req.t('tarification.not_found')
            });
        }

        // Authorization check: only the owning doctor or their assistant can view
        const doctorUserId = await getDoctorUserId(user);
        if (doctorUserId && tarification.doctor_user_id !== doctorUserId) {
            return res.status(403).json({
                success: false,
                error: req.t('tarification.forbidden_view')
            });
        }

        res.status(200).json({
            success: true,
            data: tarification
        });

    } catch (error) {
        console.error("Error getting tarification by ID:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

/**
 * Create a new tarification
 */
const createTarification = async (req: Request, res: Response) => {
    try {
        const { service_label, price } = req.body;
        const user = req.user as User;

        // Get the doctor user ID (works for both doctors and assistants)
        const doctorUserId = await getDoctorUserId(user);

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: "Doctor user ID not found"
            });
        }

        // Validation: service_label required
        if (!service_label || service_label.trim().length === 0) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.service_label_required')
            });
        }

        // Validation: service_label length
        if (service_label.length > 255) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.service_label_length')
            });
        }

        // Validation: price required
        if (price === undefined || price === null || price === '') {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.price_required')
            });
        }

        // Parse and validate price
        const parsedPrice = typeof price === 'string' ? parseFloat(price) : price;
        if (isNaN(parsedPrice)) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.price_invalid')
            });
        }

        // Validation: price must be positive
        if (parsedPrice < 0) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.price_positive')
            });
        }

        // Validation: price max value (reasonable limit)
        if (parsedPrice > 999999.99) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.price_limit')
            });
        }

        const data: CreateTarificationData = {
            doctor_user_id: doctorUserId,
            service_label: service_label.trim(),
            price: parsedPrice
        };

        const tarification = await TarificationModel.create(data);

        res.status(201).json({
            success: true,
            message: req.t('tarification.create_success'),
            data: tarification
        });

    } catch (error) {
        console.error("Error creating tarification:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

/**
 * Update a tarification
 */
const updateTarification = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { service_label, price } = req.body;
        const user = req.user as User;

        if (!id || isNaN(Number(id))) {
            return res.status(400).json({
                success: false,
                error: "Valid tarification ID is required"
            });
        }

        // Check if tarification exists
        const existing = await TarificationModel.findById(Number(id));
        if (!existing) {
            return res.status(404).json({
                success: false,
                error: req.t('tarification.not_found')
            });
        }

        // Authorization: verify the tarification belongs to this doctor or their assistant
        const doctorUserId = await getDoctorUserId(user);
        if (!doctorUserId || existing.doctor_user_id !== doctorUserId) {
            return res.status(403).json({
                success: false,
                error: req.t('tarification.forbidden_update')
            });
        }

        const updateData: UpdateTarificationData = {};

        // Validate and add service_label if provided
        if (service_label !== undefined) {
            if (service_label.trim().length === 0) {
                return res.status(400).json({
                    success: false,
                    error: req.t('tarification.service_label_empty')
                });
            }
            if (service_label.length > 255) {
                return res.status(400).json({
                    success: false,
                    error: req.t('tarification.service_label_length')
                });
            }
            updateData.service_label = service_label.trim();
        }

        // Validate and add price if provided
        if (price !== undefined) {
            const parsedPrice = typeof price === 'string' ? parseFloat(price) : price;
            if (isNaN(parsedPrice)) {
                return res.status(400).json({
                    success: false,
                    error: req.t('tarification.price_invalid')
                });
            }
            if (parsedPrice < 0) {
                return res.status(400).json({
                    success: false,
                    error: req.t('tarification.price_positive')
                });
            }
            if (parsedPrice > 999999.99) {
                return res.status(400).json({
                    success: false,
                    error: req.t('tarification.price_limit')
                });
            }
            updateData.price = parsedPrice;
        }

        // Check if any fields to update
        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({
                success: false,
                error: req.t('tarification.no_update_fields')
            });
        }

        const updated = await TarificationModel.update(Number(id), updateData);
        if (!updated) {
            return res.status(404).json({
                success: false,
                error: req.t('tarification.update_failed')
            });
        }

        res.status(200).json({
            success: true,
            message: req.t('tarification.update_success'),
            data: updated
        });

    } catch (error) {
        console.error("Error updating tarification:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

/**
 * Delete a tarification
 */
const deleteTarification = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const user = req.user as User;

        if (!id || isNaN(Number(id))) {
            return res.status(400).json({
                success: false,
                error: "Valid tarification ID is required"
            });
        }

        // Check if tarification exists
        const existing = await TarificationModel.findById(Number(id));
        if (!existing) {
            return res.status(404).json({
                success: false,
                error: req.t('tarification.not_found')
            });
        }

        // Authorization: verify the tarification belongs to this doctor or their assistant
        const doctorUserId = await getDoctorUserId(user);
        if (!doctorUserId || existing.doctor_user_id !== doctorUserId) {
            return res.status(403).json({
                success: false,
                error: req.t('tarification.forbidden_delete')
            });
        }

        const deleted = await TarificationModel.delete(Number(id));
        if (!deleted) {
            return res.status(404).json({
                success: false,
                error: req.t('tarification.delete_failed')
            });
        }

        res.status(200).json({
            success: true,
            message: req.t('tarification.delete_success')
        });

    } catch (error) {
        console.error("Error deleting tarification:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

/**
 * Get all tarifications (admin only - optional for future use)
 */
const getAllTarifications = async (req: Request, res: Response) => {
    try {
        const limit = Number(req.query.limit) || 50;
        const offset = Number(req.query.offset) || 0;

        const tarifications = await TarificationModel.findAll(limit, offset);

        res.status(200).json({
            success: true,
            data: tarifications
        });

    } catch (error) {
        console.error("Error getting all tarifications:", error);
        res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

export {
    getTarificationsByDoctor,
    getTarificationById,
    createTarification,
    updateTarification,
    deleteTarification,
    getAllTarifications
};
