import type { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { unlink } from 'fs/promises';
import { AIMedicalReportQuotaModel } from '../models/aiMedicalReportQuota.model';
import { OpenAIService } from '../services/openai.service';
import { DataSanitizer, AudioValidator } from '../utils/dataSanitization';

/**
 * POST /api/ai/medical-report
 * 
 * Générer un compte rendu médical structuré à partir d'une dictée vocale
 * 
 * Sécurité:
 * - Authentification requise (doctor only)
 * - Quota mensuel: 20 comptes rendus/médecin
 * - Audio non stocké (suppression immédiate)
 * - Données sanitizées avant envoi à OpenAI
 * - Logs sans contenu médical
 */
export const generateMedicalReportFromAudio = async (req: Request, res: Response) => {
    const requestId = uuidv4();
    const startTime = Date.now();
    let audioPath: string | null = null;
    let quotaReserved = false;
    let currentPeriod = '';

    try {
        // 1. AUTHENTIFICATION
        const doctorUserId = (req.user as any)?.id;
        if (!doctorUserId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized: Doctor authentication required'
            });
        }

        // 2. VALIDATION FICHIER AUDIO
        if (!req.file) {
            return res.status(400).json({
                success: false,
                error: 'No audio file provided'
            });
        }

        const audioFile = req.file;
        audioPath = audioFile.path;

        // Valider format et taille
        const validation = AudioValidator.validateAudioFile({
            size: audioFile.size,
            mimetype: audioFile.mimetype,
            originalname: audioFile.originalname
        });

        if (!validation.valid) {
            await cleanupAudioFile(audioPath);
            
            const statusCode = validation.error?.includes('too large') ? 413 : 415;
            return res.status(statusCode).json({
                success: false,
                error: validation.error
            });
        }

        // 3. CHECK & RESERVE QUOTA (TRANSACTION ATOMIQUE)
        const quotaResult = await AIMedicalReportQuotaModel.checkAndReserveQuota(doctorUserId);
        
        if (!quotaResult.success) {
            await cleanupAudioFile(audioPath);

            // Logger l'échec de quota
            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: quotaResult.period,
                audio_size_bytes: audioFile.size,
                status: 'quota_exceeded',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(403).json({
                success: false,
                error: 'Monthly quota exceeded',
                quota: {
                    remaining: 0,
                    max: 30,
                    period: quotaResult.period
                }
            });
        }

        quotaReserved = true;
        currentPeriod = quotaResult.period;

        // 4. TRANSCRIPTION AUDIO (Whisper)
        const transcriptionStart = Date.now();
        let transcriptionResult;
        
        try {
            transcriptionResult = await OpenAIService.transcribeAudio(
                audioPath,
                audioFile.originalname
            );
        } catch (error: any) {
            // Annuler la réservation en cas d'erreur
            await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            quotaReserved = false;

            await cleanupAudioFile(audioPath);

            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: currentPeriod,
                audio_size_bytes: audioFile.size,
                status: 'error',
                error_code: 'transcription_failed',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(502).json({
                success: false,
                error: 'Transcription failed',
                details: error.message
            });
        }

        const transcriptionDuration = Date.now() - transcriptionStart;

        // Vérifier que la transcription n'est pas vide
        if (!transcriptionResult.text || transcriptionResult.text.trim().length < 10) {
            await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            quotaReserved = false;

            await cleanupAudioFile(audioPath);

            return res.status(422).json({
                success: false,
                error: 'Transcription is empty or too short'
            });
        }

        // 5. SUPPRESSION IMMÉDIATE DE L'AUDIO
        await cleanupAudioFile(audioPath);
        audioPath = null;

        // 6. SANITIZATION DES DONNÉES (avant envoi à GPT)
        const sanitizedText = DataSanitizer.sanitizeText(transcriptionResult.text);

        // Optionnel: masquer les noms connus du patient/médecin
        // const patientInfo = await getPatientInfo(req.body.patientId);
        // const finalSanitized = DataSanitizer.maskKnownIdentifiers(sanitizedText, {
        //     patientName: patientInfo?.name,
        //     patientFamilyName: patientInfo?.family_name
        // });

        // 7. GÉNÉRATION DU COMPTE RENDU STRUCTURÉ (GPT)
        const generationStart = Date.now();
        let reportResult;

        try {
            reportResult = await OpenAIService.generateMedicalReport(
                transcriptionResult.text,
                sanitizedText
            );
        } catch (error: any) {
            // Ne pas annuler le quota ici car la transcription a réussi
            // (décision métier: la transcription a une valeur)
            
            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: currentPeriod,
                audio_size_bytes: audioFile.size,
                transcription_duration_ms: transcriptionDuration,
                status: 'error',
                error_code: 'generation_failed',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(502).json({
                success: false,
                error: 'Report generation failed',
                details: error.message,
                transcription: transcriptionResult.text // Retourner au moins la transcription
            });
        }

        const generationDuration = Date.now() - generationStart;
        const totalDuration = Date.now() - startTime;

        // 8. LOG SUCCESS (sans données médicales)
        await AIMedicalReportQuotaModel.logOperation({
            request_id: requestId,
            doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
            period: currentPeriod,
            audio_size_bytes: audioFile.size,
            audio_duration_seconds: AudioValidator.estimateDuration(
                audioFile.size,
                audioFile.mimetype
            ),
            transcription_duration_ms: transcriptionDuration,
            generation_duration_ms: generationDuration,
            total_duration_ms: totalDuration,
            status: 'success'
        });

        // 9. RÉPONSE FINALE
        return res.status(200).json({
            success: true,
            data: {
                request_id: requestId,
                transcription: transcriptionResult.text,
                medical_report: reportResult.report,
                quota: {
                    remaining: quotaResult.remaining,
                    max: 30,
                    period: currentPeriod
                },
                processing_time: {
                    transcription_ms: transcriptionDuration,
                    generation_ms: generationDuration,
                    total_ms: totalDuration
                }
            }
        });

    } catch (error: any) {
        console.error('❌ AI Medical Report Error:', {
            request_id: requestId,
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });

        // Cleanup et annulation quota si nécessaire
        if (audioPath) {
            await cleanupAudioFile(audioPath);
        }

        if (quotaReserved && currentPeriod) {
            const doctorUserId = (req.user as any)?.id;
            if (doctorUserId) {
                await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            }
        }

        return res.status(500).json({
            success: false,
            error: 'Internal server error',
            request_id: requestId
        });
    }
};

/**
 * POST /api/ai/cardiology-report
 * 
 * Générer un rapport cardiologique structuré à partir d'une dictée vocale
 * Extrait les valeurs (PA, FC, FEVG, antécédents, biologie, etc.) et les mappe
 * directement dans les champs CardiologyFormData.
 * 
 * Sécurité: même pipeline que medical-report (auth, quota, cleanup)
 */
export const generateCardiologyReportFromAudio = async (req: Request, res: Response) => {
    const requestId = uuidv4();
    const startTime = Date.now();
    let audioPath: string | null = null;
    let quotaReserved = false;
    let currentPeriod = '';

    try {
        // 1. AUTHENTIFICATION
        const doctorUserId = (req.user as any)?.id;
        if (!doctorUserId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized: Doctor authentication required'
            });
        }

        // 2. VALIDATION FICHIER AUDIO
        if (!req.file) {
            return res.status(400).json({
                success: false,
                error: 'No audio file provided'
            });
        }

        const audioFile = req.file;
        audioPath = audioFile.path;

        const validation = AudioValidator.validateAudioFile({
            size: audioFile.size,
            mimetype: audioFile.mimetype,
            originalname: audioFile.originalname
        });

        if (!validation.valid) {
            await cleanupAudioFile(audioPath);
            const statusCode = validation.error?.includes('too large') ? 413 : 415;
            return res.status(statusCode).json({
                success: false,
                error: validation.error
            });
        }

        // 3. CHECK & RESERVE QUOTA (same quota pool as medical reports)
        const quotaResult = await AIMedicalReportQuotaModel.checkAndReserveQuota(doctorUserId);

        if (!quotaResult.success) {
            await cleanupAudioFile(audioPath);

            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: quotaResult.period,
                audio_size_bytes: audioFile.size,
                status: 'quota_exceeded',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(403).json({
                success: false,
                error: 'Monthly quota exceeded',
                quota: { remaining: 0, max: 30, period: quotaResult.period }
            });
        }

        quotaReserved = true;
        currentPeriod = quotaResult.period;

        // 4. TRANSCRIPTION AUDIO (Whisper via OpenAI)
        const transcriptionStart = Date.now();
        let transcriptionResult;

        try {
            transcriptionResult = await OpenAIService.transcribeAudio(
                audioPath,
                audioFile.originalname
            );
        } catch (error: any) {
            await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            quotaReserved = false;
            await cleanupAudioFile(audioPath);

            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: currentPeriod,
                audio_size_bytes: audioFile.size,
                status: 'error',
                error_code: 'transcription_failed',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(502).json({
                success: false,
                error: 'Transcription failed',
                details: error.message
            });
        }

        const transcriptionDuration = Date.now() - transcriptionStart;

        if (!transcriptionResult.text || transcriptionResult.text.trim().length < 10) {
            await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            quotaReserved = false;
            await cleanupAudioFile(audioPath);

            return res.status(422).json({
                success: false,
                error: 'Transcription is empty or too short'
            });
        }

        // 5. SUPPRESSION IMMÉDIATE DE L'AUDIO
        await cleanupAudioFile(audioPath);
        audioPath = null;

        // 6. SANITIZATION
        const sanitizedText = DataSanitizer.sanitizeText(transcriptionResult.text);

        // 7. EXTRACTION STRUCTURÉE CARDIO (GPT)
        const generationStart = Date.now();
        let reportResult;

        try {
            reportResult = await OpenAIService.generateCardiologyReport(
                transcriptionResult.text,
                sanitizedText
            );
        } catch (error: any) {
            await AIMedicalReportQuotaModel.logOperation({
                request_id: requestId,
                doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
                period: currentPeriod,
                audio_size_bytes: audioFile.size,
                transcription_duration_ms: transcriptionDuration,
                status: 'error',
                error_code: 'cardiology_generation_failed',
                total_duration_ms: Date.now() - startTime
            });

            return res.status(502).json({
                success: false,
                error: 'Cardiology report generation failed',
                details: error.message,
                transcription: transcriptionResult.text
            });
        }

        const generationDuration = Date.now() - generationStart;
        const totalDuration = Date.now() - startTime;

        // 8. LOG SUCCESS
        await AIMedicalReportQuotaModel.logOperation({
            request_id: requestId,
            doctor_user_id_hash: AIMedicalReportQuotaModel.hashDoctorId(doctorUserId),
            period: currentPeriod,
            audio_size_bytes: audioFile.size,
            audio_duration_seconds: AudioValidator.estimateDuration(audioFile.size, audioFile.mimetype),
            transcription_duration_ms: transcriptionDuration,
            generation_duration_ms: generationDuration,
            total_duration_ms: totalDuration,
            status: 'success'
        });

        // 9. RÉPONSE
        return res.status(200).json({
            success: true,
            data: {
                request_id: requestId,
                transcription: transcriptionResult.text,
                cardiology_data: reportResult.report,
                quota: {
                    remaining: quotaResult.remaining,
                    max: 30,
                    period: currentPeriod
                },
                processing_time: {
                    transcription_ms: transcriptionDuration,
                    generation_ms: generationDuration,
                    total_ms: totalDuration
                }
            }
        });

    } catch (error: any) {
        console.error('❌ AI Cardiology Report Error:', {
            request_id: requestId,
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });

        if (audioPath) await cleanupAudioFile(audioPath);

        if (quotaReserved && currentPeriod) {
            const doctorUserId = (req.user as any)?.id;
            if (doctorUserId) {
                await AIMedicalReportQuotaModel.cancelReservation(doctorUserId, currentPeriod);
            }
        }

        return res.status(500).json({
            success: false,
            error: 'Internal server error',
            request_id: requestId
        });
    }
};

/**
 * GET /api/ai/medical-report/quota
 * 
 * Obtenir le quota restant pour le médecin connecté
 */
export const getQuotaStatus = async (req: Request, res: Response) => {
    try {
        const doctorUserId = (req.user as any)?.id;
        
        if (!doctorUserId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
        }

        const quota = await AIMedicalReportQuotaModel.getRemainingQuota(doctorUserId);

        return res.json({
            success: true,
            data: {
                used: quota.used,
                max: quota.max,
                remaining: quota.remaining,
                period: quota.period,
                percentage_used: Math.round((quota.used / quota.max) * 100)
            }
        });

    } catch (error: any) {
        console.error('❌ Get Quota Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

/**
 * GET /api/ai/medical-report/usage-stats
 * 
 * Obtenir l'historique d'utilisation du médecin
 */
export const getUsageStats = async (req: Request, res: Response) => {
    try {
        const doctorUserId = (req.user as any)?.id;
        
        if (!doctorUserId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
        }

        const months = parseInt(req.query.months as string) || 6;
        const stats = await AIMedicalReportQuotaModel.getDoctorUsageStats(doctorUserId, months);

        return res.json({
            success: true,
            data: {
                history: stats,
                total_used: stats.reduce((sum, s) => sum + s.used_count, 0)
            }
        });

    } catch (error: any) {
        console.error('❌ Get Usage Stats Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

/**
 * Utility: Nettoyer le fichier audio en toute sécurité
 */
async function cleanupAudioFile(path: string | null): Promise<void> {
    if (!path) return;
    
    try {
        await unlink(path);
    } catch (error) {
        // Silence - fichier peut ne pas exister
        console.warn('⚠️  Could not delete audio file:', path);
    }
}
