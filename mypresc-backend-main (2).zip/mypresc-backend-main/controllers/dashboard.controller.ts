import type { Request, Response } from "express";
import { AppointmentModel, type Appointment } from "../models/appointment.model";
import { WaitingRoomModel } from "../models/waiting_room.model";

/**
 * Get all dashboard stats in a single request
 * Combines: appointments, waiting entries, schedule
 */
const getDashboardStats = async (req: Request, res: Response) => {
    try {
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!doctorUserId) {
            return res.status(400).json({ 
                success: false, 
                error: req.t('dashboard.doctor_user_id_required') || 'Doctor user ID required' 
            });
        }

        // Use Algeria timezone (UTC+1) for date calculation
        const now = new Date();
        const algeriaOffset = 1 * 60; // UTC+1 in minutes
        const algeriaTime = new Date(now.getTime() + (algeriaOffset + now.getTimezoneOffset()) * 60000);
        const todayStr = `${algeriaTime.getFullYear()}-${String(algeriaTime.getMonth() + 1).padStart(2, '0')}-${String(algeriaTime.getDate()).padStart(2, '0')}`;

        // Execute all queries in parallel for maximum performance
        const [
            todayAppointments,
            waitingEntries,
        ] = await Promise.all([
            // Get TODAY's appointments only (optimized — no JS filtering needed)
            AppointmentModel.findByDateAndDoctor(new Date(todayStr), doctorUserId, 200, 0),
            // Get waiting room entries
            WaitingRoomModel.findByDoctorUserId(doctorUserId, 50, 0),
        ]);

        // Filter waiting entries (non-served)
        const activeWaitingEntries = waitingEntries.filter((e: any) => e.status !== 'served');

        // Calculate stats
        const arrivedAppointments = todayAppointments.filter((app: Appointment) => app.arrived_at && !app.is_done);
        const completedAppointments = todayAppointments.filter((app: Appointment) => app.is_done);
        const totalOrdrePassage = activeWaitingEntries.length + arrivedAppointments.length;

        // Get upcoming appointments (next 5 not done)
        const upcomingAppointments = todayAppointments
            .filter((app: Appointment) => !app.is_done)
            .sort((a: Appointment, b: Appointment) => {
                const timeA = a.time || '23:59';
                const timeB = b.time || '23:59';
                return timeA.localeCompare(timeB);
            })
            .slice(0, 5);

        return res.status(200).json({
            success: true,
            data: {
                stats: {
                    totalAppointmentsToday: todayAppointments.length,
                    completedAppointments: completedAppointments.length,
                    waitingPatients: totalOrdrePassage,
                    arrivedAppointments: arrivedAppointments.length
                },
                todayAppointments,
                upcomingAppointments,
                waitingEntries: activeWaitingEntries,
            }
        });
    } catch (error) {
        console.error("Error getting dashboard stats:", error);
        return res.status(500).json({
            success: false,
            error: req.t('dashboard.stats_error') || 'Error fetching dashboard stats'
        });
    }
};

export { getDashboardStats };
