import type { Request, Response } from 'express';
import { ConsultationInvoiceModel, type CreateInvoiceData } from '../models/consultationInvoice.model';
import SocketManager from '../utils/socketManager';
import { AssistantModel } from '../models/assistant.model';
import redisClient from '../config/redis';
import { computeCorrectStatus, verifyAndFixInvoiceStatuses, validateStatusTransition } from '../services/consultationInvoice.service';

// Helper to clear cache for doctor and all assistants
const clearInvoiceCache = async (doctorUserId: number, patientId?: string) => {
    try {
        const assistants = await AssistantModel.findActiveBydoctorId(doctorUserId);
        // Include the doctor and all active assistants (filter out null user_ids)
        const userIds = [doctorUserId, ...assistants.map(a => a.user_id).filter((id): id is number => id !== null)];

        const keysToDelete: string[] = [];

        for (const uid of userIds) {
            // Clear today's invoice cache (for assistant/doctor dashboard)
            // Key format from cacheMiddleware: `cache:user:${userId}:${req.originalUrl}`
            keysToDelete.push(`cache:user:${uid}:/consultation-invoice/today`);

            // Clear specific patient invoice cache if patientId provided
            if (patientId) {
                keysToDelete.push(`cache:user:${uid}:/consultation-invoice/patient/${patientId}`);
            }
        }

        if (keysToDelete.length > 0) {
            await redisClient.del(...keysToDelete);
            console.log(`[Cache] Cleared invoice cache for doctor ${doctorUserId} and assistants. Keys cleaned: ${keysToDelete.length}`);
        }
    } catch (error) {
        console.error('Error clearing invoice cache:', error);
    }
};

/**
 * Create a new invoice
 */
export const create = async (req: Request, res: Response) => {
    try {
        const user = req.user as any;
        let userId = user.id;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            userId = assistant.doctor_id;
        }

        const body = req.body;

        if (!body.patient_id) {
            return res.status(400).json({ success: false, error: req.t('invoice.patient_required') || 'Patient ID is required' });
        }

        // Compute correct status from financial data (single source of truth)
        const invoiceStatus = computeCorrectStatus(body.total_price, 0);

        const data: CreateInvoiceData = {
            doctor_user_id: userId,
            patient_id: body.patient_id,
            total_price: body.total_price,
            items: body.items,
            status: invoiceStatus
        };

        const invoice = await ConsultationInvoiceModel.create(data);

        // Emit socket event to doctor
        SocketManager.emitToUser(userId, 'invoice:created', invoice);

        // Emit socket event to all active assistants of the doctor
        const assistants = await AssistantModel.findActiveBydoctorId(userId);
        assistants.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'invoice:created', invoice);
            }
        });

        // Clear cache
        await clearInvoiceCache(userId, body.patient_id);

        return res.status(201).json({
            success: true,
            data: invoice,
            message: req.t('invoice.created_success') || 'Invoice created successfully'
        });
    } catch (error) {
        console.error('Error creating consultation invoice:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Get invoices by Patient ID
 * Each doctor sees only their own invoices for a patient
 */
export const getByPatientId = async (req: Request, res: Response) => {
    try {
        const patientId = req.params.patientId;
        const user = req.user as any;
        let doctorUserId = user.id;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            doctorUserId = assistant.doctor_id;
        }

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Invalid patient ID' });
        }

        // Filter invoices by doctor - each doctor sees only their own invoices
        const invoices = await ConsultationInvoiceModel.findByPatientAndDoctor(patientId, doctorUserId);

        // Verify and fix any incorrect statuses before returning
        const verifiedInvoices = verifyAndFixInvoiceStatuses(invoices);

        return res.status(200).json({
            success: true,
            data: verifiedInvoices
        });
    } catch (error) {
        console.error('Error fetching patient invoices:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Get today's invoices for the current doctor (or assistant's doctor)
 */
export const getTodayInvoices = async (req: Request, res: Response) => {
    try {
        const user = req.user as any;
        let doctorUserId = user.id;

        // If assistant, fetch associated doctor ID
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            doctorUserId = assistant.doctor_id;
        }

        const invoices = await ConsultationInvoiceModel.findTodayInvoicesByDoctorId(doctorUserId);

        // Verify and fix any incorrect statuses before returning
        const verifiedInvoices = verifyAndFixInvoiceStatuses(invoices);

        return res.status(200).json({
            success: true,
            data: verifiedInvoices
        });
    } catch (error) {
        console.error('Error fetching today invoices:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Update invoice status
 */
export const updateStatus = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id || '');
        const user = req.user as any;
        let userId = user.id;
        const { status } = req.body;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            userId = assistant.doctor_id;
        }

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'Invalid invoice ID' });
        }

        // Validate status transition against financial data
        const validation = await validateStatusTransition(id, status, userId);
        if (!validation.ok) {
            return res.status(400).json({ success: false, error: validation.error });
        }

        const updatedInvoice = await ConsultationInvoiceModel.updateStatus(id, status, userId);

        if (!updatedInvoice) {
            return res.status(404).json({ success: false, error: req.t('invoice.not_found') || 'Invoice not found' });
        }

        // Emit update event
        SocketManager.emitToUser(userId, 'invoice:updated', updatedInvoice);
        const assistants = await AssistantModel.findActiveBydoctorId(userId);
        assistants.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'invoice:updated', updatedInvoice);
            }
        });

        // Clear cache
        await clearInvoiceCache(userId, updatedInvoice.patient_id);

        return res.status(200).json({
            success: true,
            data: updatedInvoice,
            message: req.t('invoice.status_updated') || 'Invoice status updated successfully'
        });
    } catch (error) {
        console.error('Error updating invoice status:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Add payment to an invoice (supports partial payments)
 */
export const addPayment = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id || '');
        const user = req.user as any;
        let userId = user.id;
        const { amount } = req.body;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            userId = assistant.doctor_id;
        }

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'Invalid invoice ID' });
        }

        const paymentAmount = parseFloat(amount);
        if (isNaN(paymentAmount) || paymentAmount <= 0) {
            return res.status(400).json({ success: false, error: req.t('invoice.invalid_amount') || 'Invalid payment amount. Must be greater than 0.' });
        }

        const updatedInvoice = await ConsultationInvoiceModel.addPayment(id, paymentAmount, userId);

        if (!updatedInvoice) {
            return res.status(404).json({ success: false, error: req.t('invoice.not_found') || 'Invoice not found' });
        }

        // Emit update event
        SocketManager.emitToUser(userId, 'invoice:updated', updatedInvoice);
        const assistants = await AssistantModel.findActiveBydoctorId(userId);
        assistants.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'invoice:updated', updatedInvoice);
            }
        });

        // Clear cache
        await clearInvoiceCache(userId, updatedInvoice.patient_id);

        return res.status(200).json({
            success: true,
            data: updatedInvoice,
            message: req.t('invoice.payment_added') || 'Payment added successfully'
        });
    } catch (error) {
        console.error('Error adding payment to invoice:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Distribute a payment across multiple unpaid invoices for a patient
 * Pays oldest invoices first, then applies remaining to next invoice
 */
export const distributePayment = async (req: Request, res: Response) => {
    try {
        const { patientId, amount } = req.body;
        const user = req.user as any;
        let userId = user.id;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            userId = assistant.doctor_id;
        }

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Patient ID is required' });
        }

        const paymentAmount = parseFloat(amount);
        if (isNaN(paymentAmount) || paymentAmount <= 0) {
            return res.status(400).json({ success: false, error: req.t('invoice.invalid_amount') || 'Invalid payment amount. Must be greater than 0.' });
        }

        const result = await ConsultationInvoiceModel.distributePayment(patientId, paymentAmount, userId);

        if (result.updatedInvoices.length === 0) {
            return res.status(404).json({ success: false, error: 'No unpaid invoices found for this patient' });
        }

        // Emit update events for each updated invoice
        for (const invoice of result.updatedInvoices) {
            SocketManager.emitToUser(userId, 'invoice:updated', invoice);
        }
        const assistants = await AssistantModel.findActiveBydoctorId(userId);
        for (const invoice of result.updatedInvoices) {
            assistants.forEach(assistant => {
                if (assistant.user_id) {
                    SocketManager.emitToUser(assistant.user_id, 'invoice:updated', invoice);
                }
            });
        }

        // Clear cache
        await clearInvoiceCache(userId, patientId);

        return res.status(200).json({
            success: true,
            data: {
                updatedInvoices: result.updatedInvoices,
                appliedPayments: result.appliedPayments,
                remainingAmount: result.remainingAmount
            },
            message: result.remainingAmount > 0
                ? `Paiement réparti. Reste: ${result.remainingAmount} DA (aucune facture restante)`
                : 'Paiement réparti avec succès'
        });
    } catch (error) {
        console.error('Error distributing payment:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Delete invoice
 */
export const deleteInvoice = async (req: Request, res: Response) => {
    try {
        const id = parseInt(req.params.id || '');
        const user = req.user as any;
        let doctorUserId = user.id;

        // If assistant, use doctor_id
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            doctorUserId = assistant.doctor_id;
        }

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'Invalid invoice ID' });
        }

        // Pass userId to ensure doctor only deletes own invoices
        const result = await ConsultationInvoiceModel.delete(id, doctorUserId);

        if (!result.success) {
            return res.status(404).json({ success: false, error: req.t('invoice.not_found') || 'Invoice not found' });
        }

        // Emit delete event
        SocketManager.emitToUser(doctorUserId, 'invoice:deleted', { id });
        const assistants = await AssistantModel.findActiveBydoctorId(doctorUserId);
        assistants.forEach(assistant => {
            if (assistant.user_id) {
                SocketManager.emitToUser(assistant.user_id, 'invoice:deleted', { id });
            }
        });

        // Clear cache
        await clearInvoiceCache(doctorUserId, result.patient_id);

        return res.status(200).json({
            success: true,
            message: req.t('invoice.deleted_success') || 'Invoice deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting consultation invoice:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Get unpaid invoices grouped by patient
 */
export const getUnpaidByPatient = async (req: Request, res: Response) => {
    try {
        const user = req.user as any;
        let doctorUserId = user.id;

        // If assistant, fetch associated doctor ID
        if (user.role === 'assistant') {
            const assistant = await AssistantModel.findByUserId(user.id);
            if (!assistant) {
                return res.status(403).json({ success: false, error: 'Assistant profile not found' });
            }
            doctorUserId = assistant.doctor_id;
        }

        const searchTerm = req.query.search as string | undefined;
        const data = await ConsultationInvoiceModel.findUnpaidGroupedByPatient(doctorUserId, searchTerm);

        // Verify and fix statuses within each patient's nested invoices
        for (const patient of data) {
            if (patient.invoices && Array.isArray(patient.invoices)) {
                verifyAndFixInvoiceStatuses(patient.invoices);
            }
        }

        return res.status(200).json({
            success: true,
            data
        });
    } catch (error) {
        console.error('Error fetching unpaid invoices by patient:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};

/**
 * Get financial statistics
 */
export const getStatistics = async (req: Request, res: Response) => {
    try {
        const user = req.user as any;
        let doctorUserId = user.id;

        const stats = await ConsultationInvoiceModel.getStatistics(doctorUserId);

        // --- Helpers for Formatting ---

        // French mappings
        const dayMap: { [key: number]: string } = { 0: 'Dim', 1: 'Lun', 2: 'Mar', 3: 'Mer', 4: 'Jeu', 5: 'Ven', 6: 'Sam' };
        const monthMap: { [key: number]: string } = {
            0: 'Jan', 1: 'Fév', 2: 'Mar', 3: 'Avr', 4: 'Mai', 5: 'Jui',
            6: 'Juil', 7: 'Août', 8: 'Sep', 9: 'Oct', 10: 'Nov', 11: 'Déc'
        };

        // --- 1. Process Weekly Data (Last 7 days) ---
        // Expected: "period": "Lun", "paiements": 120
        // We need to generate the last 6 days + today
        const weeklyData = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            const dateStr = d.toISOString().split('T')[0]; // YYYY-MM-DD
            const dayName = dayMap[d.getDay()];

            // Find matching data from DB
            const match = stats.weekly.find((item: any) => item.date === dateStr);

            weeklyData.push({
                period: dayName,
                paiements: match ? parseFloat(match.total) : 0
            });
        }

        // --- 2. Process Monthly Data (Last 12 months) ---
        // Expected: "period": "Jan", "paiements": 2400
        const monthlyData = [];
        for (let i = 11; i >= 0; i--) {
            const d = new Date();
            d.setMonth(d.getMonth() - i);
            // Format "YYYY-MM" to match DB
            const monthNum = d.getMonth() + 1;
            const monthStr = `${d.getFullYear()}-${monthNum.toString().padStart(2, '0')}`;
            const monthName = monthMap[d.getMonth()];

            const match = stats.monthly.find((item: any) => item.month === monthStr);

            monthlyData.push({
                period: monthName,
                paiements: match ? parseFloat(match.total) : 0
            });
        }

        // --- 3. Process Yearly Data (Last 5 years) ---
        // Expected: "period": "2020", "paiements": 28000
        const yearlyData = [];
        for (let i = 4; i >= 0; i--) {
            const d = new Date();
            d.setFullYear(d.getFullYear() - i);
            const yearStr = d.getFullYear().toString();

            const match = stats.yearly.find((item: any) => item.year === yearStr);

            yearlyData.push({
                period: yearStr,
                paiements: match ? parseFloat(match.total) : 0
            });
        }

        console.log('weeklyData', weeklyData);
        console.log('monthlyData', monthlyData);
        console.log('yearlyData', yearlyData);

        return res.status(200).json({
            success: true,
            data: {
                weeklyData,
                monthlyData,
                yearlyData
            }
        });

    } catch (error) {
        console.error('Error fetching invoice statistics:', error);
        return res.status(500).json({ success: false, error: req.t('error.server_error') });
    }
};