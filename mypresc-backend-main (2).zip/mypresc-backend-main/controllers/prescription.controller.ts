import type { Request, Response } from "express";
import { PrescriptionModel, type CreatePrescriptionData, type UpdatePrescriptionData } from "../models/prescription.model";
import { PrescriptionMedicationModel } from "../models/prescriptionMedication.model";
import { PrescriptionHistoryModel } from "../models/prescriptionHistory.model";
import type { User } from "../models/user.model";
import { generatePrescription as generatePrescriptionPdf } from "../utils/prescriptionPdf";
import { generatePrescriptionExportCsv } from "../utils/prescriptionExportCsv";
import { PatientModel } from "../models/patient.model";
import { MedicalShareModel } from "../models/medicalShare.model";
import { notifyUser } from "../services/notification.service";
import { getOrCreateTodayConsultation, markConsultationHasPrescription } from "../utils/consultationHelper";

// Create a new prescription
const createPrescription = async (req: Request, res: Response) => {
  try {
    const {
      patient_id,
      confirmed_count,
      remarks,
      medications // Array of { medication_id, quantity, dosage , note}
    } = req.body;

    const user = req.user as User;
    const doctor_user_id = user.id;

    // Validate required fields
    if (!patient_id || !medications) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.missing_fields'),
      });
    }

    // Create prescription medications first if provided
    const medicationIds: number[] = [];
    if (medications && Array.isArray(medications)) {
      for (const med of medications) {
        // For custom medications, medication_id can be 0 or the custom_medication_id
        if ((!med.medication_id && !med.is_custom) || !med.dosage) {
          return res.status(400).json({
            success: false,
            error: req.t('prescription.medication_details_required'),
          });
        }

        const prescriptionMedication = await PrescriptionMedicationModel.create({
          medication_id: med.is_custom ? null : med.medication_id,
          quantity: med.quantity || 1,
          dosage: med.dosage,
          note: med.note || "",
          is_custom: med.is_custom || false,
          custom_medication_id: med.is_custom ? med.medication_id : null,
        });
        medicationIds.push(prescriptionMedication.id);
      }
    }

    const prescriptionData: CreatePrescriptionData = {
      patient_id: patient_id,
      doctor_user_id: doctor_user_id,
      confirmed_count,
      remarks,
      medication_ids: medicationIds
    };

    const prescription = await PrescriptionModel.create(prescriptionData);

    // 🔢 Get or create consultation for today (smart counter - no duplicates)
    try {
      const consultationId = await getOrCreateTodayConsultation(patient_id, doctor_user_id);
      await markConsultationHasPrescription(consultationId);
      console.log(`✅ Prescription linked to consultation ${consultationId}`);
    } catch (consultationError) {
      console.error('⚠️ Failed to link prescription to consultation:', consultationError);
      // Don't fail the request if consultation tracking fails
    }

    // Log to history
    await PrescriptionHistoryModel.create({
      prescription_id: prescription.id,
      patient_id: prescription.patient_id,
      doctor_user_id: prescription.doctor_user_id
    });

    // ✅ Notification: Prescription created
    // Notify the doctor about the new prescription
    try {
      const patient = await PatientModel.findById(patient_id);
      if (patient) {
        const patientName = `${patient.name} ${patient.family_name}`;
        const medicationCount = medications.length;

        await notifyUser(
          doctor_user_id,
          'Ordonnance créée',
          `Ordonnance créée pour ${patientName} avec ${medicationCount} médicament(s).`,
          'check',
          `/patients/${patient.id}`
        );
      }
    } catch (notifError) {
      console.error('[Notification] Failed to send prescription creation notification:', notifError);
      // Don't fail the request if notification fails
    }

    // Auto-generate PDF if
    // Delegate to the same generator (expects req.params.id)
    generatePrescriptionPdf(prescription.id, res);
  } catch (error) {
    console.error("Error creating prescription:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// generate prescription pdf
const generateThePdf = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id) return res.status(400).json({
      success: false,
      error: req.t('prescription.id_required')
    });

    await generatePrescriptionPdf(parseInt(id), res);
  } catch (error) {
    console.error('Error during generating prescription pdf', error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error')
    });
  }
};

// Get prescription by ID with full details
const getPrescriptionById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id || isNaN(parseInt(id))) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.id_invalid'),
      });
    }

    const prescription = await PrescriptionModel.findByIdWithDetails(parseInt(id));

    if (!prescription) {
      return res.status(404).json({
        success: false,
        error: req.t('prescription.not_found'),
      });
    }

    res.json({
      success: true,
      data: prescription,
    });
  } catch (error) {
    console.error("Error fetching prescription:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Get prescriptions by patient ID
// NOTE: If patient is private, only show prescriptions from the requesting doctor
//       UNLESS the patient is shared with the médecin traitant (shared_with_primary_care = true)
const getPrescriptionsByPatient = async (req: Request, res: Response) => {
  try {
    const { patientId } = req.params;
    const { limit = 50, offset = 0 } = req.query;
    const requestingDoctorId = (req.user as any)?.id as number | undefined;

    console.log(`[Prescription] GET /patient/${patientId} by doctor ${requestingDoctorId}`);

    if (!patientId) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.patient_id_invalid'),
      });
    }

    // Get patient to check privacy and sharing settings
    const patient = await PatientModel.findById(patientId, requestingDoctorId);

    // Check if doctor has access via share (for date filtering)
    let shareVisibleUntilDate: Date | null = null;

    if (!patient && requestingDoctorId) {
      // Patient not directly accessible, check share access
      const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'prescription');
      if (shareAccess.hasAccess) {
        shareVisibleUntilDate = shareAccess.visibleUntilDate;
      } else {
        return res.status(404).json({
          success: false,
          error: req.t('prescription.patient_not_found'),
        });
      }
    } else if (!patient) {
      return res.status(404).json({
        success: false,
        error: req.t('prescription.patient_not_found'),
      });
    } else if (requestingDoctorId) {
      // Patient found - but still check for share access for date filtering
      // This handles the case where patient is visible via is_shared_with_me
      const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'prescription');
      if (shareAccess.hasAccess) {
        shareVisibleUntilDate = shareAccess.visibleUntilDate;
      }
    }

    // Get all prescriptions first, then filter based on visibility rules
    let prescriptions = await PrescriptionModel.findByPatientId(
      patientId,
      parseInt(limit as string),
      parseInt(offset as string)
    );

    // Filter prescriptions based on visibility rules:
    // 1. Own prescriptions (always visible)
    // 2. Prescriptions from doctors who shared via medical_shares
    // 3. Prescriptions from doctors who chose "shared" in doctor_patient_privacy
    if (requestingDoctorId) {
      const { DoctorPatientPrivacyModel } = await import('../models/doctorPatientPrivacy.model');

      // Get doctors who chose "shared" for this patient
      const sharedDoctorIds = await DoctorPatientPrivacyModel.getDoctorsWithSharedChoice(patientId);

      // Get doctors who shared via medical_shares with current doctor
      const receivedShares = await MedicalShareModel.findSharedWithDoctor(requestingDoctorId);
      const explicitlySharedDoctorIds = receivedShares
        .filter(s => String(s.patient_id) === String(patientId) && s.share_prescriptions)
        .map(s => s.shared_by_doctor_id);

      console.log(`[Prescription Filter] Doctor ${requestingDoctorId} for patient ${patientId}`);
      console.log(`[Prescription Filter] Shared doctors (privacy=shared):`, sharedDoctorIds);
      console.log(`[Prescription Filter] Explicit shares:`, explicitlySharedDoctorIds);
      console.log(`[Prescription Filter] Visible until date:`, shareVisibleUntilDate);

      // Filter: own + shared privacy + explicit shares
      prescriptions = prescriptions.filter(p =>
        p.doctor_user_id === requestingDoctorId ||
        sharedDoctorIds.includes(p.doctor_user_id) ||
        explicitlySharedDoctorIds.includes(p.doctor_user_id)
      );

      console.log(`[Prescription Filter] After doctor filter: ${prescriptions.length} prescriptions`);
    }

    // Filter by visible_until_date if accessing via share
    // Only show documents created ON or AFTER the visible_until_date
    // IMPORTANT: Only apply date filter to OTHER doctors' prescriptions, NOT the requesting doctor's own prescriptions
    // NOTE: Use local date (not UTC) to avoid timezone issues
    if (shareVisibleUntilDate) {
      console.log(`[Prescription Filter] Applying date filter: >= ${shareVisibleUntilDate}`);
      // Helper to get local date string (YYYY-MM-DD) without UTC conversion
      const getLocalDateStr = (date: Date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
      };
      const visibleDateStr = getLocalDateStr(shareVisibleUntilDate);
      prescriptions = prescriptions.filter(prescription => {
        // Always show the requesting doctor's own prescriptions (no date restriction)
        if (prescription.doctor_user_id === requestingDoctorId) {
          console.log(`[Prescription Filter] ${prescription.id}: Own prescription - always visible`);
          return true;
        }
        // Apply date filter only to other doctors' prescriptions accessed via share
        // Compare local date strings (YYYY-MM-DD) to handle timezone correctly
        const createdAt = new Date(prescription.created_at);
        const createdDateStr = getLocalDateStr(createdAt);
        const isAfter = createdDateStr >= visibleDateStr;
        console.log(`[Prescription Filter] ${prescription.id}: ${createdDateStr} >= ${visibleDateStr} = ${isAfter}`);
        return isAfter;
      });
      console.log(`[Prescription Filter] After date filter: ${prescriptions.length} prescriptions`);
    }

    res.json({
      success: true,
      data: prescriptions,
    });
  } catch (error) {
    console.error("Error fetching prescriptions by patient:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Get prescriptions by doctor ID
const getPrescriptionsByDoctor = async (req: Request, res: Response) => {
  try {
    const { doctorId } = req.params;
    const { limit = 50, offset = 0 } = req.query;

    if (!doctorId || isNaN(parseInt(doctorId))) {
      return res.status(400).json({
        success: false,
        error: req.t('prescription.doctor_id_invalid'),
      });
    }

    const prescriptions = await PrescriptionModel.findByDoctorId(
      parseInt(doctorId),
      parseInt(limit as string),
      parseInt(offset as string)
    );

    res.json({
      success: true,
      data: prescriptions,
    });
  } catch (error) {
    console.error("Error fetching prescriptions by doctor:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Get all prescriptions
const getAllPrescriptions = async (req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;

    const prescriptions = await PrescriptionModel.findAll(limit, offset)

    res.json({
      success: true,
      data: prescriptions,
    });
  } catch (error) {
    console.error("Error fetching prescriptions:", error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error'),
    });
  }
};

// Export all prescriptions for a doctor as CSV
const exportPrescriptions = async (req: Request, res: Response) => {
  try {
    const user = req.user as User;
    const doctor_user_id = user.id;

    if (!doctor_user_id) {
      return res.status(401).json({
        success: false,
        error: req.t('prescription.auth_required')
      });
    }


    // Generate and send CSV export
    const { patients, is_all } = req.body;
    console.log('Exporting prescriptions for doctor:', doctor_user_id, 'Patients:', patients, 'Is all:', is_all);
    await generatePrescriptionExportCsv(doctor_user_id, patients, is_all, res);
  } catch (error) {
    console.error('Error during prescription export:', error);
    res.status(500).json({
      success: false,
      error: req.t('prescription.server_error')
    });
  }
};

export {
  createPrescription,
  getPrescriptionById,
  getPrescriptionsByPatient,
  getPrescriptionsByDoctor,
  getAllPrescriptions,
  generateThePdf,
  exportPrescriptions
}; 