import type { Request, Response } from "express";
import { PatientModel, type CreatePatientData, type UpdatePatientData } from "../models/patient.model";
import { notifyPatientCreated, notifyPatientUpdated } from "../services/notification.service";
import type { User } from "../models/user.model";
import { PrescriptionModel } from "../models/prescription.model";
import { getRelatedPatients } from "../services/patient.service";
import { generatePatientExportCsv } from "../utils/patientExportCsv";
import { DoctorTransitionModel } from "../models/doctorTransition.model";
import { NotificationModel } from "../models/notification.model";
import pool from "../db";
import socketManager from "../utils/socketManager";


const createPatient = async (req: Request, res: Response) => {
    try {
        const {
            name,
            family_name,
            dateNaissance,
            age: providedAge,
            genre,
            telephone,
            email,
            adresse,
            numeroSecuriteSociale,
            allergies,
            chronicDiseases,
            notes,
            nin,
            emergencyContact,
            emergencyPhone,
            is_private
        } = req.body;


        // Validate required fields (only name, family_name, genre are mandatory)
        if (!name || !family_name || !genre) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.missing_fields'),
            });
        }

        const user = req.user as User;
        // Use doctorUserId from middleware (handles both doctor and assistant cases)
        const doctorId = res.locals.doctorUserId as number | null;

        // Validate doctorId if is_private is true
        if (is_private && !doctorId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_id_required_private'),
            });
        }

        // Validate genre
        if (!["homme", "femme"].includes(genre)) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.genre_invalid'),
            });
        }

        // Validate that either dateNaissance or age is provided
        if (!dateNaissance && (providedAge === null || providedAge === undefined || providedAge === '')) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.age_or_birthdate_required') || 'La date de naissance ou l\'âge est requis',
            });
        }

        // Calculate age from dateNaissance or use provided age
        let age: number | null = null;
        if (dateNaissance) {
            const birthDate = new Date(dateNaissance);
            if (isNaN(birthDate.getTime())) {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.birthdate_invalid'),
                });
            }

            const today = new Date();
            age =
                today.getFullYear() -
                birthDate.getFullYear() -
                (today < new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate()) ? 1 : 0);

            // Validate age range
            if (age < 0 || age > 120) {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.age_invalid'),
                });
            }
        } else if (providedAge !== null && providedAge !== undefined && providedAge !== '') {
            // Use provided age directly
            age = parseInt(providedAge, 10);
            if (isNaN(age) || age < 0 || age > 120) {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.age_invalid') || 'Âge invalide (0-120)',
                });
            }
        }

        // Check for NIN duplicates (per doctor, not global)
        if (nin && nin.trim() !== '' && doctorId) {
            const ninCheck = await PatientModel.isNinUsedByDoctor(nin, doctorId);
            if (ninCheck.exists) {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.nin_already_used', { patientName: ninCheck.patientName }) || `Ce NIN est déjà utilisé par le patient: ${ninCheck.patientName}`,
                    code: 'NIN_DUPLICATE'
                });
            }
        }

        // Check for patient duplicates (name + family_name + birthDate) per doctor
        if (doctorId && dateNaissance) {
            const duplicateCheck = await PatientModel.isPatientDuplicateForDoctor(name, family_name, dateNaissance, doctorId);
            if (duplicateCheck.exists) {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.patient_exists') || `Un patient avec le même nom, prénom et date de naissance existe déjà`,
                    code: 'PATIENT_DUPLICATE'
                });
            }
        }

        // Determine assistant_id based on role
        const assistant_id = user.role === 'assistant' ? user.id : null;

        // Prepare patient data
        // NOTE: medecinTraitant is NOT auto-assigned - doctor must explicitly accept via popup
        // created_by_doctor_id tracks who created the patient (for ownership without forcing medecin traitant role)
        const patientData: CreatePatientData = {
            name,
            family_name,
            age, // ✅ computed automatically
            genre,
            telephone,
            email,
            adresse,
            dateNaissance,
            numeroSecuriteSociale,
            medecinTraitant: undefined, // Will be set only when doctor explicitly accepts
            allergies,
            chronicDiseases,
            notes,
            nin,
            emergencyContact,
            emergencyPhone,
            is_private: is_private || false,
            assistant_id,
            is_chart_readed: user?.role === 'doctor', // true if the creator is a doctor
            created_by_doctor_id: doctorId ?? undefined, // Track who created the patient
        };

        // Save patient
        const patient = await PatientModel.create(patientData);

        // ✅ Notification: Patient created
        // Notify the doctor/assistant who created the patient
        try {
            if (req.user) {
                const user = req.user as User;
                const patientFullName = `${patient.name} ${patient.family_name}`;

                await notifyPatientCreated(
                    user.id,
                    patientFullName,
                    patient.id
                );

                // 🔄 Real-time sync: Notify doctor if patient was created by assistant
                if (user.role === 'assistant' && doctorId) {
                    socketManager.emitToRoom(`doctor-assistants:${doctorId}`, 'patient:created', {
                        patient,
                        createdBy: {
                            id: user.id,
                            name: `${user.name} ${user.family_name}`,
                            role: user.role
                        }
                    });
                    console.log(`[Socket] Emitted patient:created to doctor-assistants:${doctorId}`);
                }
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send patient creation notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Primary care info for frontend
        // medecinTraitant is NOT auto-assigned, so doctor can choose to become primary care
        const primaryCareInfo = {
            hasPrimaryCare: false, // No primary care until doctor explicitly accepts
            isCurrentDoctor: false,
            canBecomePrimaryCare: true, // Doctor can choose to become primary care via popup
            needsTransitionComment: false
        };

        return res.status(201).json({
            success: true,
            message: req.t('patient.created_success'),
            data: patient,
            primaryCareInfo
        });
    } catch (error) {
        console.error("Error creating patient:", error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.create_error'),
        });
    }
};

const updatePatient = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const updateData: UpdatePatientData = req.body;


        // Validate patient ID
        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        // Check if patient exists
        const existingPatient = await PatientModel.findById(id);
        if (!existingPatient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        // Validate genre if provided
        if (updateData.genre && !['homme', 'femme'].includes(updateData.genre)) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.genre_invalid')
            });
        }

        // Validate age if provided
        if (updateData.age !== undefined && (updateData.age < 0 || updateData.age > 150)) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.age_range_invalid')
            });
        }

        // NOTE: medecinTraitant validation removed - doctor will be asked via popup AFTER update
        // The popup for "médecin traitant" is shown after the update succeeds

        // Update the patient
        const updatedPatient = await PatientModel.update(id, updateData);

        if (!updatedPatient) {
            return res.status(500).json({
                success: false,
                error: req.t('patient.update_failed')
            });
        }

        // ✅ Notification: Patient updated
        // Notify the doctor/assistant who updated the patient
        try {
            if (req.user) {
                const user = req.user as User;
                const patientFullName = `${updatedPatient.name} ${updatedPatient.family_name}`;

                await notifyPatientUpdated(
                    user.id,
                    patientFullName,
                    updatedPatient.id
                );
            }
        } catch (notifError) {
            console.error('[Notification] Failed to send patient update notification:', notifError);
            // Don't fail the request if notification fails
        }

        // Check primary care physician status for frontend popups
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        let primaryCareInfo: any = null;

        if (doctorUserId) {
            const hasPrimaryCare = updatedPatient.medecinTraitant !== null && updatedPatient.medecinTraitant !== undefined;
            const isCurrentDoctor = updatedPatient.medecinTraitant === doctorUserId;

            primaryCareInfo = {
                hasPrimaryCare,
                isCurrentDoctor,
                canBecomePrimaryCare: !isCurrentDoctor,
                needsTransitionComment: hasPrimaryCare && !isCurrentDoctor,
                currentPrimaryCareId: updatedPatient.medecinTraitant
            };

            // Si le patient a un médecin traitant différent, récupérer ses infos
            if (hasPrimaryCare && !isCurrentDoctor && updatedPatient.medecinTraitant) {
                try {
                    const doctorInfoQuery = await pool.query(
                        'SELECT u.name, u.family_name FROM users u WHERE u.id = $1',
                        [updatedPatient.medecinTraitant]
                    );
                    if (doctorInfoQuery.rows.length > 0) {
                        primaryCareInfo.currentPrimaryCareDoctor = {
                            name: doctorInfoQuery.rows[0].name,
                            family_name: doctorInfoQuery.rows[0].family_name
                        };
                    }
                } catch (err) {
                    console.error('Error fetching current primary care doctor info:', err);
                }
            }
        }

        return res.status(200).json({
            success: true,
            message: req.t('patient.updated_success'),
            data: updatedPatient,
            primaryCareInfo
        });

    } catch (error) {
        console.error('Error updating patient:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.update_error')
        });
    }
};

const getPatient = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        if (doctorUserId === undefined) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        // ⚡ Task 1.7: findById now returns a fully-filtered patient in 1 query
        // (medical_shares check + doctor info embedded via LEFT JOIN)
        const patient = await PatientModel.findById(id, doctorUserId);

        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        return res.status(200).json({
            success: true,
            data: patient
        });

    } catch (error) {
        console.error('Error getting patient:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.get_error')
        });
    }
};

const getAllPatients = async (req: Request, res: Response) => {
    try {
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (doctorUserId === undefined) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        // ⚡ Task 4.2: Decode cursor if provided (keyset pagination)
        // Falls back to offset when no cursor is given (backward compatible)
        let cursor: { created_at: string; id: string } | null = null;
        const cursorParam = req.query.cursor as string | undefined;
        if (cursorParam) {
            try {
                cursor = JSON.parse(Buffer.from(cursorParam, 'base64url').toString('utf8'));
            } catch {
                return res.status(400).json({ success: false, error: 'Invalid cursor' });
            }
        }

        // ⚡ Task 1.6 + 4.2: 1 SQL query, cursor or offset based pagination
        const patients = await PatientModel.findAllByDoctorConsultations(limit, offset, doctorUserId, cursor);

        // Sync filter — no DB calls, no await needed
        const filteredPatients = patients.map(
            patient => PatientModel.applyPrivacyFilterSync(patient, doctorUserId)
        );

        // Build next cursor from the last item for the frontend to use on the next call
        const lastItem = filteredPatients[filteredPatients.length - 1] as any;
        const nextCursor = lastItem && filteredPatients.length === limit
            ? Buffer.from(JSON.stringify({
                created_at: lastItem.created_at,
                id: lastItem.id
            }), 'utf8').toString('base64url')
            : null;

        return res.status(200).json({
            success: true,
            data: filteredPatients,
            pagination: {
                limit,
                offset,           // kept for backward compat
                count: filteredPatients.length,
                nextCursor,       // null when no more pages
                hasMore: filteredPatients.length === limit
            }
        });

    } catch (error) {
        console.error('Error getting patients:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.get_all_error')
        });
    }
};


const searchPatients = async (req: Request, res: Response) => {
    try {
        const { searchTerm, includeAll } = req.query;
        const limit = parseInt(req.query.limit as string) || 50;
        const doctorUserId = res.locals.doctorUserId as number | undefined;
        const includeAllPatients = includeAll === 'true';

        if (!searchTerm) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.search_term_required')
            });
        }

        if (doctorUserId === undefined) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        const searchTermStr = searchTerm as string;
        let patients: any[] = [];

        // Déterminer si c'est un NIN (numérique, au moins 15 chiffres)
        const isNinSearch = /^\d{15,}$/.test(searchTermStr.trim());

        if (isNinSearch) {
            // NIN search - find ANY patient (discovery mode)
            const patient = await PatientModel.searchByNinExact(searchTermStr);
            if (patient) {
                const isAccessible = await PatientModel.isDoctorAccessible(patient.id, doctorUserId);
                // ⚡ Task 1.8: applyPrivacyFilterAsync kept here because searchByNinExact
                // does NOT embed doctor info via LEFT JOIN (isolated path, rare call)
                const filteredPatient = await PatientModel.applyPrivacyFilterAsync(patient, doctorUserId);
                patients = [{ ...filteredPatient, is_discovery: !isAccessible }];
            }
        } else {
            // Name/family name search — searchAccessiblePatients now embeds doctor info
            // ⚡ Task 1.8: use sync filter since LEFT JOIN columns are present
            const rawPatients = await PatientModel.searchAccessiblePatients(searchTermStr, doctorUserId, limit);
            patients = rawPatients.map(
                patient => PatientModel.applyPrivacyFilterSync(patient, doctorUserId)
            );
        }

        return res.status(200).json({
            success: true,
            data: patients,
            searchTerm,
            count: patients.length
        });

    } catch (error) {
        console.error('Error searching patients:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.search_error')
        });
    }
};

const deletePatient = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        // Check if patient exists
        const existingPatient = await PatientModel.findById(id);
        if (!existingPatient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        const deleted = await PatientModel.delete(id);

        if (!deleted) {
            return res.status(500).json({
                success: false,
                error: req.t('patient.delete_failed')
            });
        }

        return res.status(200).json({
            success: true,
            message: req.t('patient.deleted_success')
        });

    } catch (error) {
        console.error('Error deleting patient:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.delete_error')
        });
    }
};

const getDoctorPatients = async (req: Request, res: Response) => {
    try {
        const doctorId = res.locals.doctorUserId as number;

        if (!doctorId) {
            return res.status(401).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        const patients = await getRelatedPatients(doctorId);

        return res.status(200).json({
            success: true,
            data: patients,
            count: patients.length
        });

    } catch (error) {
        console.error('Error getting doctor patients:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.get_doctor_patients_error')
        });
    }
};

// Export all patients for a doctor as CSV
const exportPatients = async (req: Request, res: Response) => {
    try {
        const user = req.user as User;
        const doctor_user_id = user.id;

        if (!doctor_user_id) {
            return res.status(401).json({
                success: false,
                error: req.t('patient.auth_required')
            });
        }

        // Generate and send CSV export
        await generatePatientExportCsv(doctor_user_id, res);
    } catch (error) {
        console.error('Error during patient export:', error);
        res.status(500).json({
            success: false,
            error: req.t('patient.server_error')
        });
    }
};

// Check if patient has a primary care physician and return status
const checkPrimaryCareStatus = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        const patient = await PatientModel.findById(patientId, doctorUserId);

        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        // Check if patient has a primary care physician
        const hasPrimaryCare = patient.medecinTraitant !== null && patient.medecinTraitant !== undefined;
        const isCurrentDoctor = patient.medecinTraitant === doctorUserId;

        return res.status(200).json({
            success: true,
            data: {
                hasPrimaryCare,
                isCurrentDoctor,
                currentPrimaryCareId: patient.medecinTraitant,
                needsTransitionComment: hasPrimaryCare && !isCurrentDoctor
            }
        });

    } catch (error) {
        console.error('Error checking primary care status:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.server_error')
        });
    }
};

// Assign or transition primary care physician
const assignPrimaryCarePhysician = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const { becomePrimaryCare, transitionComment } = req.body;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        // Validate input
        if (typeof becomePrimaryCare !== 'boolean') {
            return res.status(400).json({
                success: false,
                error: req.t('patient.become_primary_care_required')
            });
        }

        const patient = await PatientModel.findById(patientId, doctorUserId);

        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        const currentPrimaryCareId = patient.medecinTraitant;

        // If doctor wants to become primary care
        if (becomePrimaryCare) {
            // If patient already has a different primary care physician
            if (currentPrimaryCareId && currentPrimaryCareId !== doctorUserId) {
                // Transition comment is required
                if (!transitionComment || transitionComment.trim().length === 0) {
                    return res.status(400).json({
                        success: false,
                        error: req.t('patient.transition_comment_required')
                    });
                }

                // Create transition record
                await DoctorTransitionModel.create({
                    patient_id: patientId,
                    previous_doctor_id: currentPrimaryCareId,
                    new_doctor_id: doctorUserId,
                    comment: transitionComment.trim()
                });

                // Create notification for previous doctor
                await NotificationModel.create({
                    user_id: currentPrimaryCareId,
                    type: 'alert',
                    title: 'Changement de médecin traitant',
                    description: `Vous n'êtes plus le médecin traitant de ${patient.name} ${patient.family_name}. Raison: ${transitionComment}`,
                    link: `/patients/${patientId}`
                });
            } else if (!currentPrimaryCareId) {
                // First time assignment
                await DoctorTransitionModel.create({
                    patient_id: patientId,
                    previous_doctor_id: null,
                    new_doctor_id: doctorUserId,
                    comment: transitionComment || 'Première assignation du médecin traitant'
                });
            }

            // Update patient's primary care physician
            await PatientModel.update(patientId, {
                medecinTraitant: doctorUserId
            });

            return res.status(200).json({
                success: true,
                message: req.t('patient.primary_care_assigned'),
                data: {
                    medecinTraitant: doctorUserId
                }
            });

        } else {
            // If doctor wants to remove themselves as primary care
            if (currentPrimaryCareId === doctorUserId) {
                await PatientModel.update(patientId, {
                    medecinTraitant: null
                });

                await DoctorTransitionModel.create({
                    patient_id: patientId,
                    previous_doctor_id: doctorUserId,
                    new_doctor_id: doctorUserId, // Same doctor removing themselves
                    comment: 'Le médecin a retiré sa désignation de médecin traitant'
                });

                return res.status(200).json({
                    success: true,
                    message: req.t('patient.primary_care_removed')
                });
            } else {
                return res.status(400).json({
                    success: false,
                    error: req.t('patient.not_current_primary_care')
                });
            }
        }

    } catch (error) {
        console.error('Error assigning primary care physician:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.server_error')
        });
    }
};

// Get transition history for a patient
const getTransitionHistory = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.doctor_auth_required')
            });
        }

        const patient = await PatientModel.findById(patientId, doctorUserId);

        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        const transitions = await DoctorTransitionModel.findByPatientId(patientId);

        return res.status(200).json({
            success: true,
            data: transitions
        });

    } catch (error) {
        console.error('Error getting transition history:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.server_error')
        });
    }
};

// Toggle share with primary care physician
const toggleShareWithPrimaryCare = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const { share } = req.body; // true to share, false to un-share
        const doctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        if (share === undefined || share === null) {
            return res.status(400).json({
                success: false,
                error: 'Le statut de partage est requis'
            });
        }

        // Get patient to verify existence and ownership
        const patient = await PatientModel.findById(patientId);
        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        // Verify patient has a primary care physician
        if (!patient.medecinTraitant) {
            return res.status(400).json({
                success: false,
                error: 'Ce patient n\'a pas de médecin traitant'
            });
        }

        // Update shared_with_primary_care status
        const updateQuery = `
            UPDATE patients 
            SET shared_with_primary_care = $1, updated_at = NOW()
            WHERE id = $2
            RETURNING shared_with_primary_care
        `;

        const result = await pool.query(updateQuery, [share, patientId]);

        return res.status(200).json({
            success: true,
            message: share
                ? 'Dossier partagé avec le médecin traitant'
                : 'Partage avec le médecin traitant désactivé',
            data: {
                shared_with_primary_care: result.rows[0].shared_with_primary_care
            }
        });

    } catch (error) {
        console.error('Error toggling share with primary care:', error);
        return res.status(500).json({
            success: false,
            error: req.t('patient.update_error')
        });
    }
};

// ⚡ OPTIMIZED: Get primary care physician info for a patient
// BEFORE: 2 separate queries (patient + doctor) with RLS overhead
// AFTER: 1 single JOIN query, bypasses RLS for non-sensitive data
const getPrimaryCareInfo = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const currentDoctorUserId = res.locals.doctorUserId as number | undefined;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        // ⚡ OPTIMIZATION: Single query with LEFT JOIN to get patient + doctor info
        // Uses only non-sensitive fields (medecin_traitant_id, shared_with_primary_care)
        // Avoids RLS policy overhead by selecting minimal fields
        // Also checks if current doctor is the "owner" (created by doctor or their assistant)
        const query = `
            SELECT 
                p.medecin_traitant_id,
                p.shared_with_primary_care,
                p.assistant_id,
                p.created_by_doctor_id,
                u.id as doctor_id,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                u.email as doctor_email,
                d.phone_number as doctor_phone,
                a.doctor_id as assistant_doctor_id
            FROM patients p
            LEFT JOIN users u ON p.medecin_traitant_id = u.id
            LEFT JOIN doctors d ON u.id = d.user_id
            LEFT JOIN assistants a ON p.assistant_id = a.user_id
            WHERE p.id = $1
        `;

        const result = await pool.query(query, [patientId]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        const row = result.rows[0];

        // Check if current user is the primary care doctor
        const isCurrentDoctor = currentDoctorUserId ? row.medecin_traitant_id === currentDoctorUserId : false;

        // Check if patient was created directly by the current doctor
        const isCreatedByMe = currentDoctorUserId ? row.created_by_doctor_id === currentDoctorUserId : false;

        // Check if patient was created by the current doctor's assistant
        const isCreatedByMyAssistant = currentDoctorUserId ? row.assistant_doctor_id === currentDoctorUserId : false;

        // isPatientOwner = true if doctor created the patient OR their assistant created it
        const isPatientOwner = isCreatedByMe || isCreatedByMyAssistant;

        // If no primary care physician
        if (!row.medecin_traitant_id) {
            return res.status(200).json({
                success: true,
                data: {
                    hasPrimaryCare: false,
                    isCurrentDoctor: false,
                    isPatientOwner,
                    shared: false
                }
            });
        }

        // If doctor info not found (should not happen with valid medecin_traitant_id)
        if (!row.doctor_id) {
            return res.status(200).json({
                success: true,
                data: {
                    hasPrimaryCare: false,
                    isCurrentDoctor: false,
                    isPatientOwner,
                    shared: row.shared_with_primary_care || false
                }
            });
        }

        return res.status(200).json({
            success: true,
            data: {
                hasPrimaryCare: true,
                isCurrentDoctor,
                isPatientOwner,
                shared: row.shared_with_primary_care || false,
                primaryCareDoctor: {
                    id: row.doctor_id,
                    name: row.doctor_name,
                    family_name: row.doctor_family_name,
                    email: row.doctor_email,
                    phone: row.doctor_phone
                }
            }
        });

    } catch (error: any) {
        console.error('❌ Error getting primary care info:', error);
        return res.status(500).json({
            success: false,
            error: error.message || req.t('patient.get_error')
        });
    }
};

// Get patient interaction history (all doctors who interacted with patient)
// Enhanced: Finds all matching patients (by NIN or demographics) and aggregates history
const getPatientHistory = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        console.log('📜 Getting patient history for:', patientId);

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('patient.id_required')
            });
        }

        // Step 1: Fetch the patient to get their identifiers
        const patient = await PatientModel.findById(patientId);
        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('patient.not_found')
            });
        }

        // Step 2: Find all matching patients (by NIN or demographics)
        let matchingPatientIds: string[] = [patientId];
        let searchMethod: 'nin' | 'demographic' = 'nin';

        if (patient.nin) {
            // Primary: Search by NIN - find all patients with same NIN
            console.log('🔍 Searching for patients with same NIN:', patient.nin);
            const matchingPatients = await PatientModel.findAllByNin(patient.nin);
            if (matchingPatients.length > 0) {
                matchingPatientIds = matchingPatients.map(p => p.id);
            }
        } else if (patient.name && patient.family_name && patient.dateNaissance) {
            // Fallback: Search by name + familyName + birthDate
            searchMethod = 'demographic';
            const birthDateStr = patient.dateNaissance instanceof Date
                ? patient.dateNaissance.toISOString().split('T')[0]
                : String(patient.dateNaissance).split('T')[0];
            console.log('🔍 Searching for patients with same demographics:', patient.name, patient.family_name, birthDateStr);
            const matchingPatients = await PatientModel.findByNameAndBirthDate(
                patient.name,
                patient.family_name,
                birthDateStr
            );
            if (matchingPatients.length > 0) {
                matchingPatientIds = matchingPatients.map(p => p.id);
            }
        }

        console.log(`🔍 Found ${matchingPatientIds.length} matching patient(s) via ${searchMethod}`);

        // Step 3: Get all interactions for ALL matching patients
        const historyQuery = `
            WITH prescription_interactions AS (
                SELECT 
                    p.doctor_user_id as doctor_id,
                    p.created_at,
                    'prescription' as interaction_type,
                    p.id as interaction_id,
                    p.patient_id
                FROM prescriptions p
                WHERE p.patient_id = ANY($1::uuid[])
            ),
            report_interactions AS (
                SELECT 
                    mr.doctor_user_id as doctor_id,
                    mr.created_at,
                    'medical_report' as interaction_type,
                    mr.id as interaction_id,
                    mr.patient_id
                FROM medical_reports mr
                WHERE mr.patient_id = ANY($1::uuid[])
            ),
            dental_interactions AS (
                SELECT 
                    da.doctor_user_id as doctor_id,
                    da.created_at,
                    'dental_act' as interaction_type,
                    da.id as interaction_id,
                    da.patient_id
                FROM dental_acts da
                WHERE da.patient_id = ANY($1::uuid[])
            ),
            all_interactions AS (
                SELECT * FROM prescription_interactions
                UNION ALL
                SELECT * FROM report_interactions
                UNION ALL
                SELECT * FROM dental_interactions
            )
            SELECT 
                ai.doctor_id,
                u.name as doctor_name,
                u.family_name as doctor_family_name,
                u.email as doctor_email,
                d.phone_number as doctor_phone,
                d.speciality as doctor_speciality,
                ai.created_at,
                ai.interaction_type,
                ai.interaction_id,
                ai.patient_id,
                COUNT(*) OVER (PARTITION BY ai.doctor_id, ai.interaction_type) as interaction_count
            FROM all_interactions ai
            JOIN users u ON ai.doctor_id = u.id
            LEFT JOIN doctors d ON u.id = d.user_id
            ORDER BY ai.created_at DESC
        `;

        const result = await pool.query(historyQuery, [matchingPatientIds]);
        console.log(`📊 Query returned ${result.rows.length} rows`);
        if (result.rows.length > 0) {
            console.log('📊 Sample row:', result.rows[0]);
        }

        // Group by doctor and aggregate interactions
        const doctorMap = new Map();

        result.rows.forEach(row => {
            if (!doctorMap.has(row.doctor_id)) {
                doctorMap.set(row.doctor_id, {
                    doctorId: row.doctor_id,
                    doctorName: row.doctor_name,
                    doctorFamilyName: row.doctor_family_name,
                    doctorEmail: row.doctor_email,
                    doctorPhone: row.doctor_phone,
                    doctorSpeciality: row.doctor_speciality,
                    prescriptionCount: 0,
                    medicalReportCount: 0,
                    dentalActCount: 0,
                    lastInteraction: row.created_at,
                    interactions: []
                });
            }

            const doctor = doctorMap.get(row.doctor_id);

            // Update counts
            if (row.interaction_type === 'prescription') {
                doctor.prescriptionCount++;
            } else if (row.interaction_type === 'medical_report') {
                doctor.medicalReportCount++;
            } else if (row.interaction_type === 'dental_act') {
                doctor.dentalActCount++;
            }

            // Add to interactions list
            doctor.interactions.push({
                type: row.interaction_type,
                id: row.interaction_id,
                date: row.created_at,
                patientId: row.patient_id
            });

            // Update last interaction if this one is more recent
            if (new Date(row.created_at) > new Date(doctor.lastInteraction)) {
                doctor.lastInteraction = row.created_at;
            }
        });

        // Convert map to array and sort by last interaction
        const history = Array.from(doctorMap.values()).sort((a, b) =>
            new Date(b.lastInteraction).getTime() - new Date(a.lastInteraction).getTime()
        );

        console.log(`✅ Found ${history.length} doctors in patient history`);

        return res.status(200).json({
            success: true,
            data: history,
            metadata: {
                patientCount: matchingPatientIds.length,
                searchMethod,
                hasDuplicates: matchingPatientIds.length > 1
            }
        });

    } catch (error: any) {
        console.error('❌ Error getting patient history:', error);
        return res.status(500).json({
            success: false,
            error: error.message || req.t('patient.get_error')
        });
    }
};

/**
 * Get visit count for a specific patient by the doctor
 * Counts unique days where the doctor created a prescription OR medical report
 * Works for both doctor and assistant (uses doctorUserId from middleware)
 */
const getPatientVisitCount = async (req: Request, res: Response) => {
    try {
        const { id: patientId } = req.params;

        // Use doctorUserId from middleware (handles both doctor and assistant)
        const doctorUserId = res.locals.doctorUserId as number | null;

        if (!doctorUserId) {
            return res.status(400).json({
                success: false,
                error: 'Doctor ID not found'
            });
        }

        // Count unique days with prescriptions OR medical reports by this doctor for this patient
        const query = `
            SELECT COUNT(DISTINCT visit_date) as visit_count
            FROM (
                SELECT DATE(created_at) as visit_date
                FROM prescriptions
                WHERE patient_id = $1 AND doctor_user_id = $2
                UNION
                SELECT DATE(COALESCE(examination_date, created_at)) as visit_date
                FROM medical_reports
                WHERE patient_id = $1 AND doctor_user_id = $2
            ) as visits
        `;

        const result = await pool.query(query, [patientId, doctorUserId]);
        const visitCount = parseInt(result.rows[0]?.visit_count || '0');

        return res.status(200).json({
            success: true,
            data: {
                patientId,
                doctorUserId,
                visitCount
            }
        });

    } catch (error: any) {
        console.error('❌ Error getting patient visit count:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Error getting visit count'
        });
    }
};

/**
 * Get all medications for a patient, aggregated from prescriptions.
 * Returns current medications (from most recent prescription) and full history.
 * Supports ?cardio=true to filter only cardiovascular + antithrombotic medications (ATC C* + B01*).
 * Includes change_status comparison between current and previous prescription:
 *   - "maintained": same DCI + same dosage
 *   - "dose_changed": same DCI + different dosage
 *   - "replacement": different DCI but same ATC subclass (4 chars)
 *   - "new": no match found in previous prescription
 *   - "stopped": was in previous prescription but not in current (only in stopped array)
 */
const getPatientMedications = async (req: Request, res: Response) => {
    try {
        const { patientId } = req.params;
        const cardioOnly = req.query.cardio === 'true';

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Patient ID is required' });
        }

        // Get all prescriptions for this patient with their medications
        const query = `
            SELECT 
                p.id AS prescription_id,
                p.created_at AS prescription_date,
                p.doctor_user_id,
                u.name AS doctor_name,
                u.family_name AS doctor_family_name,
                pm.id AS prescription_medication_id,
                pm.medication_id,
                pm.quantity,
                pm.dosage,
                pm.note,
                pm.is_custom,
                pm.custom_medication_id,
                COALESCE(m.nom_de_marque, cm.nom_de_marque) AS nom_de_marque,
                COALESCE(m.denomination_commune_internationale, cm.denomination_commune_internationale) AS dci,
                COALESCE(m.dosage, cm.dosage) AS med_dosage,
                COALESCE(m.forme, cm.forme) AS forme,
                COALESCE(m.atc_code, cm.atc_code) AS atc_code
            FROM prescriptions p
            JOIN prescription_medication_items pmi ON pmi.prescription_id = p.id
            JOIN prescription_medications pm ON pm.id = pmi.prescription_medication_id
            LEFT JOIN medications m ON pm.medication_id = m.id AND (pm.is_custom IS NULL OR pm.is_custom = false)
            LEFT JOIN custom_medications cm ON pm.custom_medication_id = cm.id AND pm.is_custom = true
            LEFT JOIN users u ON p.doctor_user_id = u.id
            WHERE p.patient_id = $1
            ORDER BY p.created_at DESC, pm.id ASC
        `;

        const result = await pool.query(query, [patientId]);
        const rows = result.rows;

        if (rows.length === 0) {
            return res.status(200).json({
                success: true,
                data: { current: [], previous: [], stopped: [], prescriptionCount: 0 }
            });
        }

        // Group rows by prescription_id (ordered by date DESC)
        const prescriptionMap = new Map<string, any[]>();
        for (const row of rows) {
            const pid = row.prescription_id;
            if (!prescriptionMap.has(pid)) prescriptionMap.set(pid, []);
            prescriptionMap.get(pid)!.push(row);
        }
        const prescriptionIds = Array.from(prescriptionMap.keys());
        const latestPrescriptionId = prescriptionIds[0];
        const previousPrescriptionId = prescriptionIds.length > 1 ? prescriptionIds[1] : null;

        // Helper: normalize DCI for comparison (uppercase, trim, remove salt forms)
        const normalizeDci = (dci: string | null): string => {
            if (!dci) return '';
            return dci.toUpperCase().replace(/\s+(CHLORHYDRATE|FUMARATE|BESILATE|ARGININE|SODIQUE|TARTRATE|MESILATE|ETEXILATE|HYDROGENOSULFATE|BISULFATE|MAGNESIUM|TRIHYDRATE|SESQUIHYDRATE|EXPRIME EN .+)/gi, '').trim();
        };

        // Helper: get ATC subclass (first 5 chars = therapeutic subgroup level 4)
        const atcSubclass = (atc: string | null): string => {
            if (!atc || atc.length < 5) return '';
            return atc.substring(0, 5).toUpperCase();
        };

        // Helper: is cardiovascular or antithrombotic
        const isCardioRelevant = (atc: string | null): boolean => {
            if (!atc) return false;
            const upper = atc.toUpperCase();
            return upper.startsWith('C') || upper.startsWith('B01');
        };

        // Build medication item
        const buildMedItem = (row: any) => ({
            prescription_medication_id: row.prescription_medication_id,
            prescription_id: row.prescription_id,
            prescription_date: row.prescription_date,
            medication_id: row.medication_id,
            custom_medication_id: row.custom_medication_id,
            is_custom: row.is_custom || false,
            nom_de_marque: row.nom_de_marque,
            dci: row.dci,
            med_dosage: row.med_dosage,
            forme: row.forme,
            quantity: row.quantity,
            dosage: row.dosage,
            note: row.note,
            atc_code: row.atc_code,
            doctor_name: row.doctor_name,
            doctor_family_name: row.doctor_family_name,
        });

        // Current prescription medications
        const currentRows = prescriptionMap.get(latestPrescriptionId) || [];
        const previousRows = previousPrescriptionId ? (prescriptionMap.get(previousPrescriptionId) || []) : [];

        // Apply cardio filter if requested
        const filterFn = cardioOnly ? (r: any) => isCardioRelevant(r.atc_code) : () => true;
        const filteredCurrent = currentRows.filter(filterFn);
        const filteredPrevious = previousRows.filter(filterFn);

        // Compare current vs previous to determine change_status
        const current: any[] = [];
        const usedPreviousIndices = new Set<number>();

        for (const row of filteredCurrent) {
            const med = buildMedItem(row);
            const currentDci = normalizeDci(row.dci);
            const currentAtcSub = atcSubclass(row.atc_code);

            // 1. Check for same DCI in previous prescription
            const sameDciIdx = filteredPrevious.findIndex((prev, idx) =>
                !usedPreviousIndices.has(idx) && normalizeDci(prev.dci) === currentDci && currentDci !== ''
            );

            if (sameDciIdx !== -1) {
                usedPreviousIndices.add(sameDciIdx);
                const prev = filteredPrevious[sameDciIdx];
                if (row.med_dosage === prev.med_dosage) {
                    // Same DCI + same dosage = maintained
                    (med as any).change_status = 'maintained';
                } else {
                    // Same DCI + different dosage = dose changed
                    (med as any).change_status = 'dose_changed';
                    (med as any).previous_dosage = prev.med_dosage;
                    (med as any).previous_nom_de_marque = prev.nom_de_marque;
                }
            } else if (currentAtcSub !== '') {
                // 2. Check for same ATC subclass (replacement)
                const sameAtcIdx = filteredPrevious.findIndex((prev, idx) =>
                    !usedPreviousIndices.has(idx) && atcSubclass(prev.atc_code) === currentAtcSub
                );

                if (sameAtcIdx !== -1) {
                    usedPreviousIndices.add(sameAtcIdx);
                    const prev = filteredPrevious[sameAtcIdx];
                    (med as any).change_status = 'replacement';
                    (med as any).replaces_dci = prev.dci;
                    (med as any).replaces_nom_de_marque = prev.nom_de_marque;
                    (med as any).replaces_dosage = prev.med_dosage;
                } else {
                    (med as any).change_status = 'new';
                }
            } else {
                (med as any).change_status = previousRows.length > 0 ? 'new' : 'initial';
            }

            current.push(med);
        }

        // Detect stopped medications (in previous but not matched to current)
        const stopped: any[] = [];
        filteredPrevious.forEach((row, idx) => {
            if (!usedPreviousIndices.has(idx)) {
                const med = buildMedItem(row);
                (med as any).change_status = 'stopped';
                stopped.push(med);
            }
        });

        // Build history (all prescriptions except latest)
        const history: any[] = [];
        for (const [pid, pRows] of prescriptionMap) {
            if (pid === latestPrescriptionId) continue;
            for (const row of pRows) {
                if (!cardioOnly || isCardioRelevant(row.atc_code)) {
                    history.push(buildMedItem(row));
                }
            }
        }

        return res.status(200).json({
            success: true,
            data: {
                current,
                stopped,
                history,
                prescriptionCount: prescriptionIds.length,
                latestPrescriptionDate: rows[0].prescription_date,
                previousPrescriptionDate: previousRows.length > 0 ? previousRows[0].prescription_date : null,
            }
        });

    } catch (error: any) {
        console.error('❌ Error getting patient medications:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Error getting patient medications'
        });
    }
};

export {
    createPatient,
    updatePatient,
    getPatient,
    getAllPatients,
    searchPatients,
    deletePatient,
    getDoctorPatients,
    exportPatients,
    checkPrimaryCareStatus,
    assignPrimaryCarePhysician,
    getTransitionHistory,
    toggleShareWithPrimaryCare,
    getPrimaryCareInfo,
    getPatientHistory,
    getPatientVisitCount,
    getPatientMedications
};
