import type { Request, Response } from 'express';
import { DoctorPatientPrivacyModel } from '../models/doctorPatientPrivacy.model';

/**
 * Get privacy choice for current doctor and a patient
 */
export const getPrivacyChoice = async (req: Request, res: Response) => {
    try {
        const doctorId = (req.user as any)?.id;
        const patientId = req.params.patientId;

        if (!doctorId) {
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        }

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Patient ID required' });
        }

        const privacyChoice = await DoctorPatientPrivacyModel.getPrivacyChoice(doctorId, patientId);

        return res.json({
            success: true,
            data: {
                privacy_choice: privacyChoice // null if not set yet
            }
        });
    } catch (error) {
        console.error('❌ Get privacy choice error:', error);
        return res.status(500).json({ success: false, error: 'Server error' });
    }
};

/**
 * Set privacy choice for current doctor and a patient
 */
export const setPrivacyChoice = async (req: Request, res: Response) => {
    try {
        const doctorId = (req.user as any)?.id;
        const patientId = req.params.patientId;
        const { privacy_choice } = req.body;
        
        console.log(`[SetPrivacyChoice] Doctor: ${doctorId}, Patient: ${patientId}, Choice: ${privacy_choice}`);

        if (!doctorId) {
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        }

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Patient ID required' });
        }

        if (!privacy_choice || !['private', 'shared'].includes(privacy_choice)) {
            return res.status(400).json({ 
                success: false, 
                error: 'Invalid privacy choice. Must be "private" or "shared"' 
            });
        }

        const result = await DoctorPatientPrivacyModel.setPrivacyChoice(
            doctorId, 
            patientId, 
            privacy_choice
        );

        return res.json({
            success: true,
            data: result
        });
    } catch (error) {
        console.error('❌ Set privacy choice error:', error);
        return res.status(500).json({ success: false, error: 'Server error' });
    }
};

/**
 * Get doctors with shared choice for a patient (for filtering)
 */
export const getDoctorsWithSharedChoice = async (req: Request, res: Response) => {
    try {
        const doctorId = (req.user as any)?.id;
        const patientId = req.params.patientId;

        if (!doctorId) {
            return res.status(401).json({ success: false, error: 'Unauthorized' });
        }

        if (!patientId) {
            return res.status(400).json({ success: false, error: 'Patient ID required' });
        }

        const sharedDoctorIds = await DoctorPatientPrivacyModel.getDoctorsWithSharedChoice(patientId);

        return res.json({
            success: true,
            data: {
                shared_doctor_ids: sharedDoctorIds
            }
        });
    } catch (error) {
        console.error('❌ Get doctors with shared choice error:', error);
        return res.status(500).json({ success: false, error: 'Server error' });
    }
};
