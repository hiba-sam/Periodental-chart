import type { Request, Response } from 'express';
import {
    PrescriptionTypeModel,
    type CreatePrescriptionTypeData,
    type UpdatePrescriptionTypeData,
} from '../models/prescriptionType.model';
import type { User } from '../models/user.model';

// ─────────────────────────────────────────────────────────────────────────────
// Helper: extract doctor ID from request
// ─────────────────────────────────────────────────────────────────────────────

function getDoctorId(req: Request): number {
    return (req.user as User).id;
}

// ─────────────────────────────────────────────────────────────────────────────
// POST /prescription-type
// Create a new prescription type (template)
// ─────────────────────────────────────────────────────────────────────────────

export const createType = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const { name, description, medications } = req.body;

        if (!name || typeof name !== 'string' || !name.trim()) {
            return res.status(400).json({
                success: false,
                error: 'Le nom du modèle est requis.',
            });
        }

        if (!Array.isArray(medications) || medications.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'Au moins un médicament est requis pour créer un modèle.',
            });
        }

        // Validate each medication entry
        for (const med of medications) {
            if (!med.dosage || !med.dosage.trim()) {
                return res.status(400).json({
                    success: false,
                    error: 'Chaque médicament doit avoir une posologie (dosage).',
                });
            }
        }

        const data: CreatePrescriptionTypeData = {
            name: name.trim(),
            description: description?.trim() || undefined,
            doctor_user_id: doctorId,
            medications,
        };

        const created = await PrescriptionTypeModel.create(data);

        return res.status(201).json({
            success: true,
            data: created,
        });

    } catch (error) {
        console.error('[PrescriptionType] createType error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur serveur lors de la création du modèle.',
        });
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /prescription-type
// List current doctor's prescription types (with medication count)
// ─────────────────────────────────────────────────────────────────────────────

export const getMyTypes = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;
        // ?withMedications=true returns full medication details (for the selector dropdown)
        const withMedications = req.query.withMedications === 'true';

        let types;
        if (withMedications) {
            types = await PrescriptionTypeModel.findByDoctorWithMedications(doctorId);
        } else {
            types = await PrescriptionTypeModel.findByDoctor(doctorId, limit, offset);
        }

        return res.json({
            success: true,
            data: types,
        });

    } catch (error) {
        console.error('[PrescriptionType] getMyTypes error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur serveur lors de la récupération des modèles.',
        });
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// GET /prescription-type/:id
// Get a single prescription type with full medication details
// ─────────────────────────────────────────────────────────────────────────────

export const getTypeById = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const id = parseInt(String(req.params.id));

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'ID invalide.' });
        }

        const type = await PrescriptionTypeModel.findById(id);

        if (!type) {
            return res.status(404).json({ success: false, error: 'Modèle non trouvé.' });
        }

        // Ownership check — doctors can only access their own templates
        if (type.doctor_user_id !== doctorId) {
            return res.status(403).json({ success: false, error: 'Accès interdit.' });
        }

        return res.json({ success: true, data: type });

    } catch (error) {
        console.error('[PrescriptionType] getTypeById error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur serveur.',
        });
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// PUT /prescription-type/:id
// Update a prescription type
// ─────────────────────────────────────────────────────────────────────────────

export const updateType = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const id = parseInt(String(req.params.id));

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'ID invalide.' });
        }

        // Ownership check
        const owned = await PrescriptionTypeModel.belongsToDoctor(id, doctorId);
        if (!owned) {
            return res.status(403).json({ success: false, error: 'Accès interdit.' });
        }

        const { name, description, medications } = req.body;

        const updateData: UpdatePrescriptionTypeData = {};
        if (name !== undefined) updateData.name = name.trim();
        if (description !== undefined) updateData.description = description?.trim() || null as any;
        if (medications !== undefined) {
            if (!Array.isArray(medications) || medications.length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'Au moins un médicament est requis.',
                });
            }
            updateData.medications = medications;
        }

        const updated = await PrescriptionTypeModel.update(id, updateData);

        if (!updated) {
            return res.status(404).json({ success: false, error: 'Modèle non trouvé.' });
        }

        return res.json({ success: true, data: updated });

    } catch (error) {
        console.error('[PrescriptionType] updateType error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur serveur lors de la mise à jour du modèle.',
        });
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /prescription-type/:id
// Delete a prescription type
// ─────────────────────────────────────────────────────────────────────────────

export const deleteType = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const id = parseInt(String(req.params.id));

        if (isNaN(id)) {
            return res.status(400).json({ success: false, error: 'ID invalide.' });
        }

        // Ownership check
        const owned = await PrescriptionTypeModel.belongsToDoctor(id, doctorId);
        if (!owned) {
            return res.status(403).json({ success: false, error: 'Accès interdit.' });
        }

        const deleted = await PrescriptionTypeModel.delete(id);

        if (!deleted) {
            return res.status(404).json({ success: false, error: 'Modèle non trouvé.' });
        }

        return res.json({
            success: true,
            message: 'Modèle supprimé avec succès.',
        });

    } catch (error) {
        console.error('[PrescriptionType] deleteType error:', error);
        return res.status(500).json({
            success: false,
            error: 'Erreur serveur lors de la suppression du modèle.',
        });
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /prescription-type/from-prescription/:prescriptionId
// "Save as Model" — create a type from an existing prescription
// ─────────────────────────────────────────────────────────────────────────────

export const createFromPrescription = async (req: Request, res: Response) => {
    try {
        const doctorId = getDoctorId(req);
        const prescriptionId = parseInt(String(req.params.prescriptionId));
        const { name, description } = req.body;

        if (isNaN(prescriptionId)) {
            return res.status(400).json({ success: false, error: 'ID d\'ordonnance invalide.' });
        }

        if (!name || typeof name !== 'string' || !name.trim()) {
            return res.status(400).json({
                success: false,
                error: 'Le nom du modèle est requis.',
            });
        }

        const created = await PrescriptionTypeModel.createFromPrescription(
            prescriptionId,
            name.trim(),
            doctorId,
            description?.trim()
        );

        return res.status(201).json({ success: true, data: created });

    } catch (error: any) {
        console.error('[PrescriptionType] createFromPrescription error:', error);

        if (error.message?.includes('not found')) {
            return res.status(404).json({
                success: false,
                error: 'Ordonnance non trouvée.',
            });
        }

        return res.status(500).json({
            success: false,
            error: 'Erreur serveur lors de la création du modèle.',
        });
    }
};
