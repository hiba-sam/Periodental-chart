import type { Request, Response } from "express";
import { NotificationModel, type CreateNotificationData, type UpdateNotificationData } from "../models/notification.model";
import type { User } from "../models/user.model";
import { AssistantModel } from "../models/assistant.model";

// Helper function to get doctor user ID based on role
const getDoctorUserId = async (user: User): Promise<number | null> => {
    if (user.role === 'doctor') {
        return user.id;
    } else if (user.role === 'assistant') {
        const assistant = await AssistantModel.findByUserId(user.id);
        return assistant?.doctor_id || null;
    }
    return null;
};

// Get all notifications for the authenticated user
export const getAllNotifications = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: req.t('notification.auth_required')
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: req.t('notification.context_error')
            });
        }

        const { limit = 50, offset = 0, type, seen } = req.query;

        let notifications;

        if (type && ['alert', 'check', 'error', 'info'].includes(type as string)) {
            notifications = await NotificationModel.findByType(userId, type as 'alert' | 'check' | 'error' | 'info', Number(limit), Number(offset));
        } else if (seen === 'true') {
            notifications = await NotificationModel.findSeen(userId, Number(limit), Number(offset));
        } else if (seen === 'false') {
            notifications = await NotificationModel.findUnseen(userId, Number(limit), Number(offset));
        } else {
            notifications = await NotificationModel.findAll(userId, Number(limit), Number(offset));
        }

        // Exclude notifications with "ordonnance" in the title only for assistants
        let filteredNotifications = notifications;
        if (user.role === 'assistant') {
            filteredNotifications = notifications.filter(notification =>
                !notification.title.toLowerCase().includes('ordonnance')
            );
        }

        return res.status(200).json({
            success: true,
            data: filteredNotifications
        });
    } catch (error) {
        console.error("Error in getAllNotifications:", error);
        return res.status(500).json({
            success: false,
            error: req.t('notification.server_error')
        });
    }
};

// Delete notification (for the authenticated user)
export const deleteNotification = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: req.t('notification.id_required')
            });
        }

        // Check if notification exists and belongs to the user
        const existingNotification = await NotificationModel.findById(id, userId);
        if (!existingNotification) {
            return res.status(404).json({
                success: false,
                error: req.t('notification.not_found')
            });
        }

        const deleted = await NotificationModel.delete(id, userId);

        if (!deleted) {
            return res.status(500).json({
                success: false,
                error: req.t('notification.delete_failed')
            });
        }

        return res.status(200).json({
            success: true,
            message: req.t('notification.delete_success')
        });
    } catch (error) {
        console.error("Error in deleteNotification:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Mark notification as seen (for the authenticated user)
export const markAsSeen = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: "Notification ID is required"
            });
        }

        const notification = await NotificationModel.markAsSeen(id, userId);

        if (!notification) {
            return res.status(404).json({
                success: false,
                error: "Notification not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: req.t('notification.seen_success'),
            data: notification
        });
    } catch (error) {
        console.error("Error in markAsSeen:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Mark notification as unseen (for the authenticated user)
export const markAsUnseen = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: "Notification ID is required"
            });
        }

        const notification = await NotificationModel.markAsUnseen(id, userId);

        if (!notification) {
            return res.status(404).json({
                success: false,
                error: "Notification not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: req.t('notification.unseen_success'),
            data: notification
        });
    } catch (error) {
        console.error("Error in markAsUnseen:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Mark all notifications as seen (for the authenticated user)
export const markAllAsSeen = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const updatedCount = await NotificationModel.markAllAsSeen(userId);

        return res.status(200).json({
            success: true,
            message: req.t('notification.marked_all_seen', { count: updatedCount }),
            data: { updatedCount }
        });
    } catch (error) {
        console.error("Error in markAllAsSeen:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Get notification statistics (for the authenticated user)
export const getNotificationStats = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const [totalCount, unseenCount] = await Promise.all([
            NotificationModel.count(userId),
            NotificationModel.countUnseen(userId)
        ]);

        return res.status(200).json({
            success: true,
            data: {
                total: totalCount,
                unseen: unseenCount,
                seen: totalCount - unseenCount
            }
        });
    } catch (error) {
        console.error("Error in getNotificationStats:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Search notifications (for the authenticated user)
export const searchNotifications = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { q, limit = 50, offset = 0 } = req.query;

        if (!q || typeof q !== 'string') {
            return res.status(400).json({
                success: false,
                error: req.t('notification.search_query_required')
            });
        }

        const notifications = await NotificationModel.search(userId, q, Number(limit), Number(offset));

        return res.status(200).json({
            success: true,
            data: notifications
        });
    } catch (error) {
        console.error("Error in searchNotifications:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Get notification by ID (for the authenticated user)
export const getNotificationById = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { id } = req.params;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: "Notification ID is required"
            });
        }

        const notification = await NotificationModel.findById(id, userId);

        if (!notification) {
            return res.status(404).json({
                success: false,
                error: "Notification not found"
            });
        }

        return res.status(200).json({
            success: true,
            data: notification
        });
    } catch (error) {
        console.error("Error in getNotificationById:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Create new notification (for the authenticated user)
export const createNotification = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { title, description, link, type } = req.body;

        // Validation
        if (!title || !description || !type) {
            return res.status(400).json({
                success: false,
                error: req.t('notification.fields_required')
            });
        }

        if (!['alert', 'check', 'error', 'info'].includes(type)) {
            return res.status(400).json({
                success: false,
                error: req.t('notification.type_invalid')
            });
        }

        const notificationData: CreateNotificationData = {
            user_id: userId,
            title,
            description,
            link: link || null,
            type
        };

        const notification = await NotificationModel.create(notificationData);

        return res.status(201).json({
            success: true,
            message: req.t('notification.create_success'),
            data: notification
        });
    } catch (error) {
        console.error("Error in createNotification:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

// Update notification (for the authenticated user)
export const updateNotification = async (req: Request, res: Response) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: "Authentication required"
            });
        }

        const user = req.user as User;
        const userId = await getDoctorUserId(user);

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: "Unable to determine user context"
            });
        }

        const { id } = req.params;
        const { title, description, link, type, is_seen } = req.body;

        if (!id) {
            return res.status(400).json({
                success: false,
                error: "Notification ID is required"
            });
        }

        // Check if notification exists and belongs to the user
        const existingNotification = await NotificationModel.findById(id, userId);
        if (!existingNotification) {
            return res.status(404).json({
                success: false,
                error: "Notification not found"
            });
        }

        // Validation for type if provided
        if (type && !['alert', 'check', 'error', 'info'].includes(type)) {
            return res.status(400).json({
                success: false,
                error: "Type must be one of: alert, check, error, info"
            });
        }

        const updateData: UpdateNotificationData = {};
        if (title !== undefined) updateData.title = title;
        if (description !== undefined) updateData.description = description;
        if (link !== undefined) updateData.link = link;
        if (type !== undefined) updateData.type = type;
        if (is_seen !== undefined) updateData.is_seen = is_seen;

        const updatedNotification = await NotificationModel.update(id, updateData, userId);

        return res.status(200).json({
            success: true,
            message: req.t('notification.update_success'),
            data: updatedNotification
        });
    } catch (error) {
        console.error("Error in updateNotification:", error);
        return res.status(500).json({
            success: false,
            error: "Internal server error"
        });
    }
};

