import type { Request, Response } from "express";
import { WaitingRoomModel, type CreateWaitingEntryData, type UpdateWaitingEntryData } from "../models/waiting_room.model";
import { checkDoctor } from "./appointment.controller";
import { PatientModel } from "../models/patient.model";
import { notifyWaitingRoomEntry } from "../services/notification.service";
import socketManager from "../utils/socketManager";
import { AssistantModel } from "../models/assistant.model";

const createWaitingEntry = async (req: Request, res: Response) => {
    try {
        const { patient_id, status, arrived_at, called_at, notes } = req.body;
        const { doctorUserId } = req.query as { doctorUserId?: string };

        if (!patient_id) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.patient_id_required') });
        }
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const data: CreateWaitingEntryData = {
            patient_id,
            doctor_user_id: Number(doctorUserId),
            status,
            arrived_at: arrived_at ? new Date(arrived_at) : undefined,
            called_at: called_at ? new Date(called_at) : undefined,
            notes
        };

        const now = new Date();
        const isDuplicateToday = await WaitingRoomModel.existsSameDay(patient_id, Number(doctorUserId), now);
        if (isDuplicateToday) {
            return res.status(409).json({ success: false, error: req.t('waiting_room.duplicate_entry') });
        }

        const entry = await WaitingRoomModel.create(data);

        // ✅ Notification: Patient entered waiting room
        // Notify the doctor about the new patient arrival
        try {
            const patient = await PatientModel.findById(patient_id);
            if (patient) {
                const patientName = `${patient.name} ${patient.family_name}`;
                await notifyWaitingRoomEntry(
                    Number(doctorUserId),
                    patientName,
                    entry.id
                );
            }
        } catch (notifError) {
            // Don't fail the request if notification fails
        }

        // ✅ Socket.io: Notify doctor and assistants via shared room
        try {
            const room = `doctor-assistants:${doctorUserId}`;
            console.log(`[WaitingRoom Socket] Emitting waitingRoom:created to room: ${room}`);
            socketManager.emitToRoom(room, 'waitingRoom:created', entry);
            console.log(`[WaitingRoom Socket] Emitted successfully to room: ${room}`);
        } catch (socketError) {
            console.error('[WaitingRoom Socket] Failed to emit waitingRoom:created:', socketError);
        }

        return res.status(201).json({ success: true, message: req.t('waiting_room.create_success'), data: entry });
    } catch (error) {
        console.error("Error creating waiting entry:", error);
        return res.status(500).json({ success: false, error: req.t('waiting_room.create_error') });
    }
};

const updateWaitingEntry = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { doctorUserId } = req.query as { doctorUserId?: string };

        if (!id) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.id_required') });
        }
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const entry = await WaitingRoomModel.findById(id);
        if (!entry) {
            return res.status(404).json({ success: false, error: req.t('waiting_room.not_found') });
        }
        if (entry.doctor_user_id !== Number(doctorUserId)) {
            return res.status(403).json({ success: false, error: req.t('waiting_room.forbidden') });
        }

        const updateData: UpdateWaitingEntryData = { ...req.body };
        if (updateData.arrived_at) updateData.arrived_at = new Date(updateData.arrived_at as any);
        if (updateData.called_at) updateData.called_at = new Date(updateData.called_at as any);

        const updated = await WaitingRoomModel.update(id, updateData);

        // ✅ Socket.io: Notify doctor and assistants via shared room
        try {
            socketManager.emitToRoom(`doctor-assistants:${doctorUserId}`, 'waitingRoom:updated', updated);
        } catch (socketError) {
            // Failed to emit waitingRoom:updated
        }

        return res.status(200).json({ success: true, message: req.t('waiting_room.update_success'), data: updated });
    } catch (error) {
        console.error("Error updating waiting entry:", error);
        return res.status(500).json({ success: false, error: req.t('waiting_room.update_error') });
    }
};

const getWaitingEntry = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { doctorUserId } = req.query as { doctorUserId?: string };

        if (!id) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.id_required') });
        }
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const entry = await WaitingRoomModel.findById(id);
        if (!entry) {
            return res.status(404).json({ success: false, error: req.t('waiting_room.not_found') });
        }
        if (entry.doctor_user_id !== Number(doctorUserId)) {
            return res.status(403).json({ success: false, error: req.t('waiting_room.forbidden') });
        }

        return res.status(200).json({ success: true, data: entry });
    } catch (error) {
        console.error("Error getting waiting entry:", error);
        return res.status(500).json({ success: false, error: req.t('waiting_room.get_error') });
    }
};

const getWaitingEntries = async (req: Request, res: Response) => {
    try {
        const { doctorUserId } = req.query as { doctorUserId?: string };
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const entries = await WaitingRoomModel.findByDoctorUserId(Number(doctorUserId), limit, offset);
        return res.status(200).json({ success: true, data: entries, count: entries.length });
    } catch (error) {
        console.error("Error getting waiting entries by doctor:", error);
        return res.status(500).json({ success: false, error: req.t('waiting_room.get_all_error') });
    }
};

const deleteWaitingEntry = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { doctorUserId } = req.query as { doctorUserId?: string };

        if (!id) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.id_required') });
        }
        if (!doctorUserId) {
            return res.status(400).json({ success: false, error: req.t('waiting_room.doctor_user_id_required') });
        }
        const isValidDoctor = await checkDoctor(doctorUserId, res, req);
        if (!isValidDoctor) return;

        const entry = await WaitingRoomModel.findById(id);
        if (!entry) {
            return res.status(404).json({ success: false, error: req.t('waiting_room.not_found') });
        }
        if (entry.doctor_user_id !== Number(doctorUserId)) {
            return res.status(403).json({ success: false, error: req.t('waiting_room.forbidden') });
        }

        await WaitingRoomModel.delete(id);

        // ✅ Socket.io: Notify doctor and assistants via shared room
        try {
            socketManager.emitToRoom(`doctor-assistants:${doctorUserId}`, 'waitingRoom:deleted', { id });
        } catch (socketError) {
            // Failed to emit waitingRoom:deleted
        }

        return res.status(200).json({ success: true, message: req.t('waiting_room.delete_success') });
    } catch (error) {
        console.error("Error deleting waiting entry:", error);
        return res.status(500).json({ success: false, error: req.t('waiting_room.delete_error') });
    }
};


export {
    createWaitingEntry,
    updateWaitingEntry,
    getWaitingEntry,
    getWaitingEntries,
    deleteWaitingEntry
};