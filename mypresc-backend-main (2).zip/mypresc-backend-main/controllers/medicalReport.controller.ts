import type { Request, Response } from 'express';
import { MedicalReportModel } from '../models/medicalReport.model';
import type { CreateMedicalReportData } from '../models/medicalReport.model';
import { PatientModel } from '../models/patient.model';
import { MedicalShareModel } from '../models/medicalShare.model';
import { generateMedicalReportPdf } from '../utils/medicalReportPdf';
import { getOrCreateTodayConsultation, markConsultationHasMedicalReport } from '../utils/consultationHelper';

/**
 * Create a new medical report
 */
export const createMedicalReport = async (req: Request, res: Response) => {
    try {
        const { patient_id, title, content, examination_date } = req.body;
        const doctor_user_id = (req.user as any)?.id;

        // Debug logs
        console.log('📝 Create medical report request:', {
            patient_id,
            title: title || 'EMPTY/NULL',
            content: content ? `${content.substring(0, 50)}...` : 'EMPTY/NULL',
            doctor_user_id
        });

        // Validate required fields with stronger checks
        if (!patient_id) {
            console.error('❌ Missing patient_id');
            return res.status(400).json({
                success: false,
                error: 'Patient ID is required'
            });
        }

        if (!title || title.trim().length === 0) {
            console.error('❌ Missing or empty title');
            return res.status(400).json({
                success: false,
                error: 'Le titre est obligatoire'
            });
        }

        if (!content || content.trim().length === 0) {
            console.error('❌ Missing or empty content');
            return res.status(400).json({
                success: false,
                error: 'Le contenu est obligatoire'
            });
        }

        // Verify doctor is authenticated
        if (!doctor_user_id) {
            return res.status(401).json({
                success: false,
                error: req.t('medical_report.doctor_id_not_found')
            });
        }

        // Verify patient exists
        const patient = await PatientModel.findById(patient_id);
        if (!patient) {
            return res.status(404).json({
                success: false,
                error: req.t('medical_report.patient_not_found')
            });
        }

        // Create medical report
        const reportData: CreateMedicalReportData = {
            patient_id,
            doctor_user_id,
            title,
            content,
            examination_date: examination_date ? new Date(examination_date) : new Date()
        };

        const report = await MedicalReportModel.create(reportData);

        // 🔢 Get or create consultation for today (smart counter - no duplicates)
        try {
            const consultationId = await getOrCreateTodayConsultation(patient_id, doctor_user_id);
            await markConsultationHasMedicalReport(consultationId);
            console.log(`✅ Medical report linked to consultation ${consultationId}`);
        } catch (consultationError) {
            console.error('⚠️ Failed to link medical report to consultation:', consultationError);
            // Don't fail the request if consultation tracking fails
        }

        return res.status(201).json({
            success: true,
            data: { report }
        });
    } catch (error) {
        console.error('❌ Create medical report error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Get medical report by ID
 */
export const getMedicalReportById = async (req: Request, res: Response) => {
    try {
        const reportId = parseInt(req.params.id || '');
        const requestingDoctorId = (req.user as any)?.id;

        if (isNaN(reportId)) {
            return res.status(400).json({
                success: false,
                error: req.t('medical_report.invalid_id')
            });
        }

        const report = await MedicalReportModel.findByIdWithDetails(reportId, requestingDoctorId);

        if (!report) {
            return res.status(404).json({
                success: false,
                error: req.t('medical_report.not_found')
            });
        }

        return res.json({
            success: true,
            data: { report }
        });
    } catch (error) {
        console.error('❌ Get medical report error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Get all medical reports for a specific patient
 */
export const getMedicalReportsByPatient = async (req: Request, res: Response) => {
    try {
        const patientId = req.params.patientId;
        const requestingDoctorId = (req.user as any)?.id;
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!patientId) {
            return res.status(400).json({
                success: false,
                error: req.t('medical_report.patient_id_required')
            });
        }

        if (!requestingDoctorId) {
            return res.status(401).json({
                success: false,
                error: 'Unauthorized'
            });
        }

        // ⚡ OPTIMIZED: Fetch patient once and pass to model to avoid redundant queries
        // BEFORE: PatientModel.findById called twice (here + in findByPatientIdWithDetails)
        // AFTER: Called once, passed to model
        const patient = await PatientModel.findById(patientId, requestingDoctorId);

        // Check if doctor has access via share (for date filtering)
        let shareVisibleUntilDate: Date | null = null;

        if (!patient) {
            // Patient not directly accessible, check share access
            const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'medical_report');
            if (shareAccess.hasAccess) {
                shareVisibleUntilDate = shareAccess.visibleUntilDate;
            } else {
                return res.status(404).json({
                    success: false,
                    error: req.t('medical_report.patient_not_found')
                });
            }
        } else {
            // Patient found - but still check for share access for date filtering
            // This handles the case where patient is visible via is_shared_with_me
            const shareAccess = await MedicalShareModel.checkAccess(patientId, requestingDoctorId, 'medical_report');
            if (shareAccess.hasAccess) {
                shareVisibleUntilDate = shareAccess.visibleUntilDate;
            }
        }

        let reports = await MedicalReportModel.findByPatientIdWithDetails(
            patientId,
            requestingDoctorId,
            limit,
            offset,
            patient  // Pass already-fetched patient to avoid re-fetching
        );

        // Filter by visible_until_date if accessing via share
        // Only show documents created ON or AFTER the visible_until_date
        // IMPORTANT: Only apply date filter to OTHER doctors' reports, NOT the requesting doctor's own reports
        // NOTE: Use local date (not UTC) to avoid timezone issues
        if (shareVisibleUntilDate) {
            console.log(`[MedicalReport Filter] Applying date filter: >= ${shareVisibleUntilDate}`);
            // Helper to get local date string (YYYY-MM-DD) without UTC conversion
            const getLocalDateStr = (date: Date) => {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };
            const visibleDateStr = getLocalDateStr(shareVisibleUntilDate);
            reports = reports.filter(report => {
                // Always show the requesting doctor's own reports (no date restriction)
                if (report.doctor_user_id === requestingDoctorId) {
                    console.log(`[MedicalReport Filter] ${report.id}: Own report - always visible`);
                    return true;
                }
                // Apply date filter only to other doctors' reports accessed via share
                // Compare local date strings (YYYY-MM-DD) to handle timezone correctly
                const createdAt = new Date(report.created_at);
                const createdDateStr = getLocalDateStr(createdAt);
                const isAfter = createdDateStr >= visibleDateStr;
                console.log(`[MedicalReport Filter] ${report.id}: ${createdDateStr} >= ${visibleDateStr} = ${isAfter}`);
                return isAfter;
            });
            console.log(`[MedicalReport Filter] After date filter: ${reports.length} reports`);
        }

        const total = await MedicalReportModel.countByPatientId(patientId);

        return res.json({
            success: true,
            data: {
                reports,
                total,
                limit,
                offset
            }
        });
    } catch (error) {
        console.error('❌ Get medical reports by patient error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Update a medical report
 */
export const updateMedicalReport = async (req: Request, res: Response) => {
    try {
        const reportId = parseInt(req.params.id || '');
        const doctorUserId = (req.user as any)?.id;
        const { title, content, examination_date } = req.body;

        if (isNaN(reportId)) {
            return res.status(400).json({
                success: false,
                error: req.t('medical_report.invalid_id')
            });
        }

        // Verify report exists
        const existingReport = await MedicalReportModel.findById(reportId);
        if (!existingReport) {
            return res.status(404).json({
                success: false,
                error: req.t('medical_report.not_found')
            });
        }

        // Verify the requesting doctor is the author
        if (existingReport.doctor_user_id !== doctorUserId) {
            return res.status(403).json({
                success: false,
                error: req.t('medical_report.forbidden_update')
            });
        }

        // Update report
        const updatedReport = await MedicalReportModel.update(reportId, {
            title,
            content,
            examination_date: examination_date ? new Date(examination_date) : undefined
        });

        return res.json({
            success: true,
            data: { report: updatedReport }
        });
    } catch (error) {
        console.error('❌ Update medical report error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Delete a medical report
 */
export const deleteMedicalReport = async (req: Request, res: Response) => {
    try {
        const reportId = parseInt(req.params.id || '');
        const doctorUserId = (req.user as any)?.id;

        if (isNaN(reportId)) {
            return res.status(400).json({
                success: false,
                error: req.t('medical_report.invalid_id')
            });
        }

        // Verify report exists
        const existingReport = await MedicalReportModel.findById(reportId);
        if (!existingReport) {
            return res.status(404).json({
                success: false,
                error: req.t('medical_report.not_found')
            });
        }

        // Verify the requesting doctor is the author
        if (existingReport.doctor_user_id !== doctorUserId) {
            return res.status(403).json({
                success: false,
                error: req.t('medical_report.forbidden_delete')
            });
        }

        // Delete report
        await MedicalReportModel.delete(reportId);

        return res.json({
            success: true,
            message: req.t('medical_report.delete_success')
        });
    } catch (error) {
        console.error('❌ Delete medical report error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Get all medical reports created by the authenticated doctor
 */
export const getMyMedicalReports = async (req: Request, res: Response) => {
    try {
        const doctorUserId = (req.user as any)?.id;
        const limit = parseInt(req.query.limit as string) || 50;
        const offset = parseInt(req.query.offset as string) || 0;

        if (!doctorUserId) {
            return res.status(401).json({
                success: false,
                error: req.t('medical_report.unauthorized')
            });
        }

        const reports = await MedicalReportModel.findByDoctorId(doctorUserId, limit, offset);
        const total = await MedicalReportModel.countByDoctorId(doctorUserId);

        return res.json({
            success: true,
            data: {
                reports,
                total,
                limit,
                offset
            }
        });
    } catch (error) {
        console.error('❌ Get my medical reports error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};

/**
 * Generate PDF for a medical report
 */
export const generateMedicalReportPdfController = async (req: Request, res: Response) => {
    try {
        const reportId = parseInt(req.params.id || '');
        const requestingDoctorId = (req.user as any)?.id;

        if (isNaN(reportId)) {
            return res.status(400).json({
                success: false,
                error: req.t('medical_report.invalid_id')
            });
        }

        if (!requestingDoctorId) {
            return res.status(401).json({
                success: false,
                error: req.t('medical_report.unauthorized')
            });
        }

        // Generate and return PDF
        await generateMedicalReportPdf(reportId, res, requestingDoctorId);
    } catch (error) {
        console.error('❌ Generate medical report PDF error:', error);
        return res.status(500).json({
            success: false,
            error: req.t('medical_report.server_error')
        });
    }
};
