import { Socket } from 'socket.io';
import { z } from 'zod';
import { MessagingService } from '../services/messaging.service';
import { ConversationModel } from '../models/conversation.model';
import { MessageModel } from '../models/message.model';
import socketManager from '../utils/socketManager';
import { securityLogger } from '../utils/securityLogger';
import { messagingRateLimiter } from '../middlewares/socketAuth';

// Validation schemas
const MessageSendSchema = z.object({
  conversationId: z.number().int().positive(),
  content: z.string().min(1).max(5000),
});

const MessageReadSchema = z.object({
  messageId: z.number().int().positive(),
});

const PresenceUpdateSchema = z.object({
  status: z.enum(['online', 'away', 'offline']),
});

const ConversationJoinSchema = z.object({
  conversationId: z.number().int().positive(),
});

const ConversationLeaveSchema = z.object({
  conversationId: z.number().int().positive(),
});

const TypingSchema = z.object({
  conversationId: z.number().int().positive(),
});

/**
 * Socket.io event handlers
 */
export class SocketController {
  /**
   * Handle new socket connection
   */
  static handleConnection(socket: Socket): void {
    if (!socket.user) {
      socket.disconnect();
      return;
    }

    const userId = socket.user.id;

    // Join user's personal room
    socket.join(`user:${userId}`);
    
    // Doctor joins their own shared room for real-time updates with assistants
    if (socket.user.role === 'doctor') {
      socket.join(`doctor-assistants:${userId}`);
      console.log(`[Socket] Doctor joined room doctor-assistants:${userId}`);
    }
    
    console.log(`[Socket] User connected: ${socket.user.name} ${socket.user.family_name} (user_id: ${userId}, role: ${socket.user.role}, socket: ${socket.id})`);

    // Set user online and broadcast to conversation partners
    MessagingService.updatePresence(userId, 'online', socket.id)
      .then(() => {
        // Broadcast presence change to conversation partners
        socketManager.broadcastPresenceChange(userId, 'online');
      })
      .catch((err) => {
        securityLogger.error('[Socket.io] Failed to update presence', {
          userId,
          error: err.message,
        });
      });

    // Register event handlers
    SocketController.registerHandlers(socket);
  }

  /**
   * Register all event handlers
   */
  private static registerHandlers(socket: Socket): void {
    socket.on('message:send', (data, callback) =>
      SocketController.handleMessageSend(socket, data, callback)
    );

    socket.on('message:read', (data, callback) =>
      SocketController.handleMessageRead(socket, data, callback)
    );

    socket.on('presence:update', (data, callback) =>
      SocketController.handlePresenceUpdate(socket, data, callback)
    );

    socket.on('conversation:join', (data, callback) =>
      SocketController.handleConversationJoin(socket, data, callback)
    );

    // Handle assistant joining doctor's notification room
    socket.on('join:doctor-assistants', (data, callback) =>
      SocketController.handleJoinDoctorAssistants(socket, data, callback)
    );

    socket.on('conversation:leave', (data, callback) =>
      SocketController.handleConversationLeave(socket, data, callback)
    );

    // Typing indicators
    socket.on('typing:start', (data, callback) =>
      SocketController.handleTypingStart(socket, data, callback)
    );

    socket.on('typing:stop', (data, callback) =>
      SocketController.handleTypingStop(socket, data, callback)
    );

    socket.on('disconnect', () => SocketController.handleDisconnect(socket));

    socket.on('error', (error) =>
      securityLogger.error('[Socket.io] Socket error', {
        userId: socket.user?.id,
        socketId: socket.id,
        error: error.message,
      })
    );
  }

  /**
   *  OPTIMIZED: Handle message:send event
   * Emits immediately, saves to DB in background
   */
  private static async handleMessageSend(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;
    const startTime = Date.now();

    try {
      // Rate limiting (fast check)
      if (!messagingRateLimiter.canConsume(userId)) {
        if (callback) callback({ error: 'socket.rate_limit' });
        return;
      }

      // Validate payload (fast check)
      const validated = MessageSendSchema.parse(data);

      // Generate temp ID for optimistic updates
      const tempId = data.tempId || `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const now = new Date();

      // Create optimistic message object
      const optimisticMessage = {
        tempId,
        id: null,
        conversation_id: validated.conversationId,
        sender_id: userId,
        content: validated.content,
        created_at: now,
        is_edited: false,
        sender_name: `${socket.user!.name || ''} ${socket.user!.family_name || ''}`.trim() || 'User',
        is_read: false,
      };

      //  EMIT IMMEDIATELY (don't wait for DB)
      socketManager.emitToConversation(validated.conversationId, 'message:new', {
        message: optimisticMessage,
        conversationId: validated.conversationId,
        senderId: userId,
        tempId,
      });

      // Also emit directly to recipient for instant notification (only if NOT in conversation room)
      ConversationModel.getOtherUserId(validated.conversationId, userId).then(recipientId => {
        if (recipientId) {
          // Check if recipient is already in the conversation room
          const isInConversationRoom = socketManager.isUserInRoom(recipientId, `conversation:${validated.conversationId}`);
          if (!isInConversationRoom) {
            socketManager.emitToUser(recipientId, 'message:new', {
              message: optimisticMessage,
              conversationId: validated.conversationId,
              senderId: userId,
              tempId,
            });
          }
        }
      }).catch(() => {});

      //  INSTANT CALLBACK (user sees success immediately)
      if (callback) {
        callback({
          success: true,
          tempId,
          timestamp: now.toISOString(),
          latency: Date.now() - startTime,
        });
      }

      // Save to database in background (doesn't block)
      setImmediate(async () => {
        try {
          const savedMessage = await MessagingService.sendMessage(
            validated.conversationId,
            userId,
            validated.content
          );

          // Send confirmation with real database ID
          socketManager.emitToConversation(validated.conversationId, 'message:confirmed', {
            tempId,
            realId: savedMessage.id,
            conversationId: validated.conversationId,
            message: savedMessage,
          });

        } catch (dbError: any) {
          securityLogger.error('[Socket.io] DB save failed', {
            userId,
            tempId,
            error: dbError.message,
          });

          // Notify client to rollback optimistic message
          socketManager.emitToConversation(validated.conversationId, 'message:failed', {
            tempId,
            conversationId: validated.conversationId,
            error: 'socket.save_failed',
          });

          socket.emit('message:failed', {
            tempId,
            error: 'socket.not_saved',
          });
        }
      });

    } catch (error: any) {
      securityLogger.error('[Socket.io] Error sending message', {
        userId,
        error: error.message,
      });

      const response = {
        error: error instanceof z.ZodError
          ? 'socket.invalid_format'
          : error.message || 'socket.send_failed',
      };

      if (callback) callback(response);
    }
  }

  /**
   * Handle message:read event
   */
  private static async handleMessageRead(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;

    try {
      const validated = MessageReadSchema.parse(data);

      await MessagingService.markMessageAsRead(validated.messageId, userId);

      // Get message to find conversation
      const message = await MessageModel.getById(validated.messageId);

      if (message) {
        // Notify sender that message was read
        socketManager.emitToConversation(message.conversation_id, 'message:read', {
          messageId: validated.messageId,
          userId,
          readAt: new Date(),
        });
      }

      if (callback) {
        callback({ success: true });
      }
    } catch (error: any) {
      if (callback) {
        callback({ error: error.message || 'socket.mark_read_failed' });
      }
    }
  }

  /**
   * Handle presence:update event
   */
  private static async handlePresenceUpdate(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;

    try {
      const validated = PresenceUpdateSchema.parse(data);

      await MessagingService.updatePresence(userId, validated.status, socket.id);

      // Broadcast presence change to conversation partners
      socketManager.broadcastPresenceChange(userId, validated.status);

      if (callback) {
        callback({ success: true });
      }
    } catch (error: any) {
      if (callback) {
        callback({ error: error.message || 'socket.presence_failed' });
      }
    }
  }

  /**
   * Handle conversation:join event
   */
  private static async handleConversationJoin(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;

    try {
      const validated = ConversationJoinSchema.parse(data);

      // Verify user is member
      const isMember = await ConversationModel.isUserMember(
        validated.conversationId,
        userId
      );

      if (!isMember) {
        if (callback) {
          callback({ error: 'socket.not_member' });
        }
        return;
      }

      // Join conversation room
      socket.join(`conversation:${validated.conversationId}`);

      if (callback) {
        callback({ success: true });
      }
    } catch (error: any) {
      if (callback) {
        callback({ error: error.message || 'socket.join_failed' });
      }
    }
  }

  /**
   * Handle conversation:leave event
   */
  private static async handleConversationLeave(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    try {
      const validated = ConversationLeaveSchema.parse(data);

      socket.leave(`conversation:${validated.conversationId}`);

      if (callback) {
        callback({ success: true });
      }
    } catch (error: any) {
      if (callback) {
        callback({ error: error.message || 'socket.leave_failed' });
      }
    }
  }

  /**
   * Handle join:doctor-assistants event - Allow assistants to join a room for their doctor
   */
  private static handleJoinDoctorAssistants(socket: Socket, data: any, callback?: (response: any) => void): void {
    const { doctorId } = data;

    if (!doctorId) {
      console.log('[Socket] join:doctor-assistants - No doctorId provided');
      if (callback) callback({ success: false, error: 'No doctorId' });
      return;
    }

    // Join the doctor's assistant notification room
    const roomName = `doctor-assistants:${doctorId}`;
    socket.join(roomName);
    console.log(`[Socket] User joined room ${roomName} (socket: ${socket.id})`);

    if (callback) callback({ success: true, room: roomName });
  }

  /**
   * Handle disconnect event
   */
  private static async handleDisconnect(socket: Socket): Promise<void> {
    const userId = socket.user?.id;

    if (!userId) return;

    // Check if user has other active sockets
    const userSockets = socketManager.getUserSockets(userId);

    if (userSockets.length === 0) {
      // No more active sockets, set offline and broadcast to partners
      await MessagingService.updatePresence(userId, 'offline');

      // Broadcast offline status to conversation partners
      socketManager.broadcastPresenceChange(userId, 'offline');
    }
  }

  /**
   * Handle typing:start event
   */
  private static async handleTypingStart(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;
    const userName = `${socket.user!.name || ''} ${socket.user!.family_name || ''}`.trim() || 'User';

    try {
      const validated = TypingSchema.parse(data);

      // Verify user is member of conversation
      const isMember = await ConversationModel.isUserMember(validated.conversationId, userId);
      if (!isMember) {
        if (callback) callback({ error: 'socket.not_member' });
        return;
      }

      // Broadcast typing status to conversation room
      socketManager.emitToConversation(validated.conversationId, 'typing:update', {
        conversationId: validated.conversationId,
        userId,
        userName,
        isTyping: true,
      });

      if (callback) callback({ success: true });
    } catch (error: any) {
      if (callback) callback({ error: error.message || 'socket.typing_failed' });
    }
  }

  /**
   * Handle typing:stop event
   */
  private static async handleTypingStop(
    socket: Socket,
    data: any,
    callback?: Function
  ): Promise<void> {
    const userId = socket.user!.id;

    try {
      const validated = TypingSchema.parse(data);

      // Broadcast stop typing to conversation room
      socketManager.emitToConversation(validated.conversationId, 'typing:update', {
        conversationId: validated.conversationId,
        userId,
        isTyping: false,
      });

      if (callback) callback({ success: true });
    } catch (error: any) {
      if (callback) callback({ error: error.message || 'socket.typing_failed' });
    }
  }
}
