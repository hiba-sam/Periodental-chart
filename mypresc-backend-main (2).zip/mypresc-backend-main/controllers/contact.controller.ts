
import { type Request, type Response } from 'express';
import { emailService } from '../utils/email';

export const postContact = async (req: Request, res: Response) => {
    try {
        const { fullName, email, phone, subject, message } = req.body;

        // Validation
        if (!fullName || !email || !subject || !message) {
            return res.status(400).json({
                success: false,
                error: req.t('common.missing_fields') || 'Veuillez remplir tous les champs obligatoires.'
            });
        }

        // Send email
        await emailService.sendContactEmail({
            fullName,
            email,
            phone: phone || 'Non renseigné',
            subject,
            message
        });

        return res.status(200).json({
            success: true,
            message: req.t('contact.success') || 'Votre message a été envoyé avec succès.'
        });

    } catch (error) {
        console.error('Error in postContact:', error);
        return res.status(500).json({
            success: false,
            error: req.t('common.server_error') || 'Une erreur est survenue lors de l\'envoi du message.'
        });
    }
};

export const contactController = {
    postContact
};
