import Redis from 'ioredis';
import dotenv from 'dotenv';

dotenv.config();

const redisUrl = process.env.REDIS_URL;

const options: any = {
    retryStrategy: (times: number) => {
        // Max 2 seconds delay
        const delay = Math.min(times * 50, 2000);
        return delay;
    },
    reconnectOnError: (err: Error) => {
        const targetError = 'READONLY';
        if (err.message.includes(targetError)) {
            return true;
        }
        return false;
    }
};

let redisClient: Redis;

if (redisUrl) {
    redisClient = new Redis(redisUrl, options);
} else {
    // Default to localhost:6379 if no URL provided, with same retry strategy
    redisClient = new Redis(options);
}

redisClient.on('error', (err) => {
    // Prevent app crash on Redis connection errors
    // We log it but don't throw
    console.error('Redis Client Error:', err.message);
});

redisClient.on('connect', () => {
    console.log('Redis Client Connected');
});

export default redisClient;
