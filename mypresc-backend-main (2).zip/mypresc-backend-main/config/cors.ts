/**
 * CORS Configuration - MyPresc Backend
 * 
 * Configuration stricte et dynamique de CORS
 * Protection contre les requêtes cross-origin non autorisées
 * 
 * Conformité : OWASP A05:2021 (Security Misconfiguration)
 */

import type { CorsOptions } from 'cors';
import { securityLogger } from '../utils/securityLogger';

// ============================================
// CONFIGURATION CORS
// ============================================

// Origines autorisées (depuis .env, CSV)
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',').map(o => o.trim()) || [
    'http://localhost:3000',
    'http://localhost:3001',
    'https://app.myprescription.dz',
    'https://myprescription.dz',
    'https://api.myprescription.dz',
];

// Méthodes HTTP autorisées
const allowedMethods = process.env.CORS_METHODS?.split(',').map(m => m.trim()) || [
    'GET',
    'POST',
    'PUT',
    'DELETE',
    'OPTIONS',
    'PATCH'
];

// Cache de preflight (en secondes)
const maxAge = parseInt(process.env.CORS_MAX_AGE || '600', 10);

// Credentials autorisés (FORCÉ pour le développement)
const credentials = true; // process.env.CORS_CREDENTIALS === 'true';

/**
 * Configuration CORS stricte avec logging des rejets
 */
export const corsOptions: CorsOptions = {
    origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
        // Autoriser les requêtes sans origin (mobile apps, Postman, curl en local)
        if (!origin) {
            // En production, on peut restreindre cela
            if (process.env.NODE_ENV === 'production') {
                securityLogger.warn('[CORS] Request without origin header', {
                    event: 'CORS_NO_ORIGIN'
                });
                // En production stricte, décommenter pour bloquer :
                // return callback(new Error('Origin header required'), false);
            }
            return callback(null, true);
        }

        // Vérifier si l'origine est autorisée
        if (allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            // Logger le rejet
            securityLogger.warn('[CORS] Blocked unauthorized origin', {
                origin,
                allowedOrigins: allowedOrigins.join(', '),
                event: 'CORS_BLOCK'
            });

            callback(new Error(`Origin ${origin} not allowed by CORS`), false);
        }
    },

    // Credentials (cookies, authorization headers)
    credentials,

    // Code de succès pour OPTIONS
    optionsSuccessStatus: 204,

    // Ne pas passer au handler suivant après OPTIONS
    preflightContinue: false,

    // Méthodes autorisées
    methods: allowedMethods,

    // Headers autorisés dans les requêtes
    allowedHeaders: [
        'Content-Type',
        'Authorization',
        'X-Requested-With',
        'X-CSRF-Token',
        'X-Client-Version'
    ],

    // Headers exposés dans les réponses
    exposedHeaders: [
        'X-RateLimit-Limit',
        'X-RateLimit-Remaining',
        'X-RateLimit-Reset'
    ],

    // Cache de preflight
    maxAge
};

/**
 * Fonction helper pour valider manuellement une origine
 */
export function isOriginAllowed(origin: string | undefined): boolean {
    if (!origin) return process.env.NODE_ENV !== 'production';
    return allowedOrigins.includes(origin);
}

/**
 * Fonction helper pour obtenir les origines autorisées
 */
export function getAllowedOrigins(): string[] {
    return [...allowedOrigins];
}

export default corsOptions;
