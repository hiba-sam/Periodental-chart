/**
 * Security Configuration Constants
 * 
 * Centralized security settings for the application
 * Conformité : OWASP ASVS 4.0
 */

// ============================================
// PASSWORD HASHING
// ============================================

/**
 * Bcrypt rounds for password hashing
 * 
 * Recommended values (2025):
 * - Minimum: 12 rounds
 * - Standard: 12-14 rounds
 * - High security: 16+ rounds
 * 
 * Each additional round doubles the computation time
 * 12 rounds ≈ 250ms on modern hardware
 */
export const BCRYPT_ROUNDS = 12;

// ============================================
// SESSION CONFIGURATION
// ============================================

/**
 * Session timeout in milliseconds
 * Default: 24 hours
 */
export const SESSION_MAX_AGE = 24 * 60 * 60 * 1000;

/**
 * Session idle timeout in milliseconds
 * Default: 30 minutes
 */
export const SESSION_IDLE_TIMEOUT = 30 * 60 * 1000;

// ============================================
// TOKEN CONFIGURATION
// ============================================

/**
 * JWT token expiration time
 * Default: 7 days
 */
export const JWT_EXPIRES_IN = '7d';

/**
 * Registration token expiration time
 * Default: 7 days
 */
export const REGISTRATION_TOKEN_EXPIRES_IN = '7d';

// ============================================
// SECURITY LIMITS
// ============================================

/**
 * Maximum failed login attempts before lockout
 */
export const MAX_LOGIN_ATTEMPTS = 5;

/**
 * Account lockout duration in milliseconds
 * Default: 15 minutes
 */
export const LOCKOUT_DURATION = 15 * 60 * 1000;

/**
 * Password minimum length
 */
export const PASSWORD_MIN_LENGTH = 12;

/**
 * Password complexity requirements
 */
export const PASSWORD_REQUIREMENTS = {
    minLength: PASSWORD_MIN_LENGTH,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
};

export default {
    BCRYPT_ROUNDS,
    SESSION_MAX_AGE,
    SESSION_IDLE_TIMEOUT,
    JWT_EXPIRES_IN,
    REGISTRATION_TOKEN_EXPIRES_IN,
    MAX_LOGIN_ATTEMPTS,
    LOCKOUT_DURATION,
    PASSWORD_MIN_LENGTH,
    PASSWORD_REQUIREMENTS,
};
