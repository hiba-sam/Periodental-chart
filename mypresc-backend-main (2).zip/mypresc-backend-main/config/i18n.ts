import i18next from 'i18next';
import { handle, LanguageDetector } from 'i18next-http-middleware';
import Backend from 'i18next-fs-backend';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

i18next
    .use(Backend)
    .use(LanguageDetector)
    .init({
        backend: {
            loadPath: path.join(__dirname, '../locales/{{lng}}/{{ns}}.json'),
        },
        fallbackLng: 'fr',
        lng: 'fr', // Force French as default language
        preload: ['fr', 'en', 'ar'],
        detection: {
            order: ['cookie', 'querystring', 'header'], // Check cookie first, header last
            caches: ['cookie'],
            lookupCookie: 'i18next',
            lookupQuerystring: 'lng'
        }
    });

export const i18nMiddleware = handle(i18next);
export default i18next;
