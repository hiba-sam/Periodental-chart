/**
 * HashiCorp Vault Integration for MyPresc Backend
 * 
 * Permet de charger les secrets depuis Vault en production
 * Fallback sur .env en développement
 * 
 * Conformité : OWASP A02:2021, ISO 27001:2013 A.10
 */

import vault from 'node-vault';
import { securityLogger, logSecretsLoaded, logSecretsLoadFailure } from '../utils/securityLogger';

interface VaultSecrets {
    JWT_SECRET: string;
    SESSION_SECRET: string;
    ENCRYPTION_KEY: string;
    DATABASE_URL: string;
    SMTP_USER: string;
    SMTP_PASS: string;
}

// ============================================
// VAULT CLIENT INITIALIZATION
// ============================================

let vaultClient: any = null;

/**
 * Initialise le client Vault
 */
function initializeVaultClient() {
    if (!vaultClient && process.env.VAULT_ENABLED === 'true') {
        try {
            vaultClient = vault({
                endpoint: process.env.VAULT_ADDR || 'http://127.0.0.1:8200',
                token: process.env.VAULT_TOKEN,
                apiVersion: 'v1'
            });

            securityLogger.info('[VAULT] Vault client initialized', {
                endpoint: process.env.VAULT_ADDR
            });
        } catch (error) {
            securityLogger.error('[VAULT] Failed to initialize Vault client', { error });
            throw error;
        }
    }

    return vaultClient;
}

// ============================================
// SECRETS LOADING
// ============================================

/**
 * Charge les secrets depuis HashiCorp Vault
 */
export async function loadSecretsFromVault(): Promise<VaultSecrets> {
    const client = initializeVaultClient();

    if (!client) {
        throw new Error('Vault client not initialized. Set VAULT_ENABLED=true');
    }

    try {
        const vaultPath = process.env.VAULT_PATH || 'secret/data/mypresc';
        
        securityLogger.info('[VAULT] Loading secrets from Vault...', { path: vaultPath });

        const response = await client.read(vaultPath);
        
        if (!response || !response.data || !response.data.data) {
            throw new Error('Invalid response from Vault');
        }

        const secrets: VaultSecrets = response.data.data;

        // Vérifier que tous les secrets requis sont présents
        const requiredSecrets: (keyof VaultSecrets)[] = [
            'JWT_SECRET',
            'SESSION_SECRET',
            'ENCRYPTION_KEY',
            'DATABASE_URL',
            'SMTP_USER',
            'SMTP_PASS'
        ];

        for (const secretKey of requiredSecrets) {
            if (!secrets[secretKey]) {
                throw new Error(`Missing required secret in Vault: ${secretKey}`);
            }
        }

        logSecretsLoaded('vault');

        return secrets;
    } catch (error) {
        logSecretsLoadFailure(error as Error, 'vault');
        throw error;
    }
}

/**
 * Écrit des secrets dans Vault (pour rotation)
 */
export async function writeSecretsToVault(secrets: Partial<VaultSecrets>): Promise<void> {
    const client = initializeVaultClient();

    if (!client) {
        throw new Error('Vault client not initialized. Set VAULT_ENABLED=true');
    }

    try {
        const vaultPath = process.env.VAULT_PATH || 'secret/data/mypresc';

        securityLogger.info('[VAULT] Writing secrets to Vault...', {
            path: vaultPath,
            keys: Object.keys(secrets)
        });

        await client.write(vaultPath, { data: secrets });

        securityLogger.info('[VAULT] Secrets written successfully to Vault');
    } catch (error) {
        securityLogger.error('[VAULT] Failed to write secrets to Vault', { error });
        throw error;
    }
}

// ============================================
// SECRETS INJECTION
// ============================================

/**
 * Injecte les secrets dans process.env
 */
export function injectSecretsIntoEnv(secrets: VaultSecrets): void {
    process.env.JWT_SECRET = secrets.JWT_SECRET;
    process.env.SESSION_SECRET = secrets.SESSION_SECRET;
    process.env.ENCRYPTION_KEY = secrets.ENCRYPTION_KEY;
    process.env.DATABASE_URL = secrets.DATABASE_URL;
    process.env.SMTP_USER = secrets.SMTP_USER;
    process.env.SMTP_PASS = secrets.SMTP_PASS;

    securityLogger.info('[VAULT] Secrets injected into environment variables');
}

/**
 * Charge les secrets depuis Vault OU .env
 * 
 * - Si VAULT_ENABLED=true : Charge depuis Vault
 * - Sinon : Utilise les variables .env existantes
 */
export async function loadSecrets(): Promise<void> {
    const vaultEnabled = process.env.VAULT_ENABLED === 'true';

    try {
        if (vaultEnabled) {
            securityLogger.info('[SECRETS] Loading secrets from Vault (production mode)');
            const secrets = await loadSecretsFromVault();
            injectSecretsIntoEnv(secrets);
        } else {
            securityLogger.info('[SECRETS] Using secrets from .env file (development mode)');
            logSecretsLoaded('env');
        }
    } catch (error) {
        securityLogger.error('[SECRETS] Failed to load secrets', { error });
        throw new Error('Failed to load application secrets. Server cannot start.');
    }
}

export default {
    loadSecrets,
    loadSecretsFromVault,
    writeSecretsToVault,
    injectSecretsIntoEnv
};
