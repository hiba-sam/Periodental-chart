import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Ensure upload directories exist
const uploadDirs = {
    idCard: 'uploads/id_card',
    diploma: 'uploads/diploma',
    numeroOrdre: 'uploads/num_ordre',
    messageAttachments: 'uploads/message_attachments'
};

// Create directories if they don't exist
Object.values(uploadDirs).forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
});

// Allowed file types (PDF and common image formats, including iOS HEIC)
const allowedMimeTypes = [
    'application/pdf',
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/heic',
    'image/heif',
    'application/octet-stream' // iOS sometimes sends camera photos with this mime type
];

const allowedExtensions = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.heic', '.heif'];

// File filter to validate file types
const fileFilter = (req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const mimeType = file.mimetype.toLowerCase();

    // For iOS camera photos, sometimes extension is missing or mime type is octet-stream
    // Accept if either mime type OR extension is valid (more lenient for mobile cameras)
    const isValidMime = allowedMimeTypes.includes(mimeType);
    const isValidExt = allowedExtensions.includes(ext);
    
    // Special handling for iOS: accept octet-stream with valid image extensions
    const isIOSPhoto = mimeType === 'application/octet-stream' && 
        ['.jpg', '.jpeg', '.png', '.heic', '.heif'].includes(ext);

    if ((isValidMime && isValidExt) || isIOSPhoto) {
        cb(null, true);
    } else {
        cb(new Error(`Invalid file type. Only PDF and image files (JPG, PNG, GIF, WEBP, HEIC) are allowed. Received: ${ext || 'unknown'} (${mimeType})`));
    }
};

// Storage configuration for registration files
const registrationStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        let uploadPath = '';

        // Determine destination based on field name
        if (file.fieldname === 'idCardFile') {
            uploadPath = uploadDirs.idCard;
        } else if (file.fieldname === 'diplomaFile') {
            uploadPath = uploadDirs.diploma;
        } else if (file.fieldname === 'numeroOrdreFile') {
            uploadPath = uploadDirs.numeroOrdre;
        } else {
            return cb(new Error(`Invalid field name: ${file.fieldname}`), '');
        }

        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        try {
            // Extract data from request body
            const { firstName, lastName, birthDate } = req.body;

            if (!firstName || !lastName || !birthDate) {
                return cb(new Error('Missing required fields: firstName, lastName, or birthDate'), '');
            }

            // Clean and format the names (remove special characters and spaces)
            const cleanFirstName = firstName.trim().replace(/[^a-zA-Z0-9]/g, '_');
            const cleanLastName = lastName.trim().replace(/[^a-zA-Z0-9]/g, '_');

            // Format birthDate (assuming format: YYYY-MM-DD or similar)
            const cleanBirthDate = birthDate.replace(/[^0-9-]/g, '');

            // Get current date for upload date
            const uploadDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format

            // Get file extension
            const ext = path.extname(file.originalname).toLowerCase();

            // Create filename: firstName_lastName_birthDate_uploadDate_timestamp_random.extension
            // We adding a unique suffix (timestamp + random) to prevent overwriting when multiple files are uploaded
            const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
            const filename = `${cleanFirstName}_${cleanLastName}_${cleanBirthDate}_${uploadDate}_${uniqueSuffix}${ext}`;

            cb(null, filename);
        } catch (error) {
            cb(error as Error, '');
        }
    }
});

// Multer upload configuration for registration
export const uploadRegistrationFiles = multer({
    storage: registrationStorage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB max file size
        files: 10 // Increased to accommodate multiple diploma files (max 10 total)
    }
}).fields([
    { name: 'idCardFile', maxCount: 1 },
    { name: 'diplomaFile', maxCount: 5 }, // Allow up to 5 diploma files
    { name: 'numeroOrdreFile', maxCount: 1 }
]);

// Error handler for multer
export const handleMulterError = (err: any, req: any, res: any, next: any) => {
    if (err instanceof multer.MulterError) {
        // Multer-specific errors
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(400).json({
                success: false,
                error: 'File size too large. Maximum allowed size is 10MB.'
            });
        }
        if (err.code === 'LIMIT_FILE_COUNT') {
            return res.status(400).json({
                success: false,
                error: 'Too many files. Maximum 3 files allowed.'
            });
        }
        if (err.code === 'LIMIT_UNEXPECTED_FILE') {
            return res.status(400).json({
                success: false,
                error: `Unexpected field: ${err.field}. Expected fields are: idCardFile, diplomaFile, numeroOrdreFile`
            });
        }

        return res.status(400).json({
            success: false,
            error: `File upload error: ${err.message}`
        });
    }

    if (err) {
        // Other errors (like file type validation)
        return res.status(400).json({
            success: false,
            error: err.message || 'File upload failed'
        });
    }

    next();
};

// Utility function to delete uploaded files in case of error
export const deleteUploadedFiles = (files: Express.Multer.File[]) => {
    files.forEach(file => {
        if (fs.existsSync(file.path)) {
            fs.unlinkSync(file.path);
        }
    });
};

// Utility function to get uploaded files from request
export const getUploadedFiles = (req: any): { idCardFile?: string; diplomaFile?: string[]; numeroOrdreFile?: string } => {
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };

    const diplomaFiles = files?.diplomaFile?.map(file => file.path) || [];

    return {
        idCardFile: files?.idCardFile?.[0]?.path,
        diplomaFile: diplomaFiles.length > 0 ? diplomaFiles : undefined,
        numeroOrdreFile: files?.numeroOrdreFile?.[0]?.path
    };
};

// ============================================
// MESSAGE ATTACHMENTS UPLOAD
// ============================================

// Storage configuration for message attachments
const messageAttachmentStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDirs.messageAttachments);
    },
    filename: (req, file, cb) => {
        try {
            const userId = (req as any).user?.id || 'unknown';
            const timestamp = Date.now();
            const randomSuffix = Math.random().toString(36).substring(2, 8);
            const ext = path.extname(file.originalname).toLowerCase();
            const cleanOriginalName = path.basename(file.originalname, ext)
                .replace(/[^a-zA-Z0-9]/g, '_')
                .substring(0, 50);
            
            const filename = `${userId}_${timestamp}_${randomSuffix}_${cleanOriginalName}${ext}`;
            cb(null, filename);
        } catch (error) {
            cb(error as Error, '');
        }
    }
});

// Multer upload configuration for message attachments
export const uploadMessageAttachment = multer({
    storage: messageAttachmentStorage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB max file size
        files: 1 // One file at a time
    }
}).single('attachment');
