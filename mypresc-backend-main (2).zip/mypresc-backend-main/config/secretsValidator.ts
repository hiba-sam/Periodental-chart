/**
 * Secrets Validator for MyPresc Backend
 * 
 * Valide la robustesse et la présence de tous les secrets requis
 * Conformité : OWASP A02:2021, RGPD art. 32
 */

import { securityLogger } from '../utils/securityLogger';

interface SecretValidationResult {
    isValid: boolean;
    errors: string[];
    warnings: string[];
}

// ============================================
// VALIDATION RULES
// ============================================

/**
 * Vérifie qu'un secret a une longueur minimale
 */
function validateMinLength(secret: string, minLength: number, secretName: string): string | null {
    if (!secret || secret.length < minLength) {
        return `${secretName} must be at least ${minLength} characters long (current: ${secret?.length || 0})`;
    }
    return null;
}

/**
 * Vérifie qu'un secret n'est pas un secret faible connu
 */
function validateNotWeakSecret(secret: string, secretName: string): string | null {
    const weakSecrets = [
        'secret',
        'password',
        'test',
        '123456',
        'changeme',
        'my_simple_secret_for_now',
        'our-secret-key',
        'my_simple_encryption_key_for_now'
    ];

    const secretLower = secret.toLowerCase();
    for (const weak of weakSecrets) {
        if (secretLower.includes(weak)) {
            return `${secretName} appears to be a weak/default secret. Please generate a strong random secret.`;
        }
    }
    return null;
}

/**
 * Vérifie l'entropie d'un secret (mesure de randomness)
 */
function validateEntropy(secret: string, secretName: string): string | null {
    // Vérifier la diversité des caractères
    const hasUpperCase = /[A-Z]/.test(secret);
    const hasLowerCase = /[a-z]/.test(secret);
    const hasNumbers = /[0-9]/.test(secret);
    const hasSpecialChars = /[^A-Za-z0-9]/.test(secret);

    const diversity = [hasUpperCase, hasLowerCase, hasNumbers, hasSpecialChars].filter(Boolean).length;

    if (diversity < 3) {
        return `${secretName} has low entropy. Use a mix of uppercase, lowercase, numbers, and special characters.`;
    }

    return null;
}

/**
 * Vérifie la date de rotation des secrets
 */
function validateRotationDate(lastRotation: string, maxDays: number): string | null {
    try {
        const rotationDate = new Date(lastRotation);
        const now = new Date();
        const daysSinceRotation = Math.floor((now.getTime() - rotationDate.getTime()) / (1000 * 60 * 60 * 24));

        if (daysSinceRotation > maxDays) {
            return `Secrets are outdated (last rotation: ${daysSinceRotation} days ago). Rotation recommended every ${maxDays} days.`;
        }
    } catch (error) {
        return 'Invalid SECRETS_LAST_ROTATION date format. Use ISO 8601 format.';
    }

    return null;
}

// ============================================
// MAIN VALIDATION FUNCTION
// ============================================

/**
 * Valide tous les secrets de l'application
 */
export function validateSecrets(): SecretValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Vérifier la présence des variables obligatoires
    const requiredEnvVars = [
        'JWT_SECRET',
        'SESSION_SECRET',
        'ENCRYPTION_KEY',
        'DATABASE_URL',
        'SMTP_USER',
        'SMTP_PASS'
    ];

    for (const envVar of requiredEnvVars) {
        if (!process.env[envVar]) {
            errors.push(`Missing required environment variable: ${envVar}`);
        }
    }

    // Si des variables manquent, arrêter ici
    if (errors.length > 0) {
        return { isValid: false, errors, warnings };
    }

    // Valider JWT_SECRET
    const jwtSecret = process.env.JWT_SECRET!;
    const jwtMinLengthError = validateMinLength(jwtSecret, 64, 'JWT_SECRET');
    const jwtWeakError = validateNotWeakSecret(jwtSecret, 'JWT_SECRET');
    const jwtEntropyError = validateEntropy(jwtSecret, 'JWT_SECRET');

    if (jwtMinLengthError) errors.push(jwtMinLengthError);
    if (jwtWeakError) errors.push(jwtWeakError);
    if (jwtEntropyError) warnings.push(jwtEntropyError);

    // Valider SESSION_SECRET
    const sessionSecret = process.env.SESSION_SECRET!;
    const sessionMinLengthError = validateMinLength(sessionSecret, 64, 'SESSION_SECRET');
    const sessionWeakError = validateNotWeakSecret(sessionSecret, 'SESSION_SECRET');
    const sessionEntropyError = validateEntropy(sessionSecret, 'SESSION_SECRET');

    if (sessionMinLengthError) errors.push(sessionMinLengthError);
    if (sessionWeakError) errors.push(sessionWeakError);
    if (sessionEntropyError) warnings.push(sessionEntropyError);

    // Valider ENCRYPTION_KEY
    const encryptionKey = process.env.ENCRYPTION_KEY!;
    const encryptionMinLengthError = validateMinLength(encryptionKey, 32, 'ENCRYPTION_KEY');
    const encryptionWeakError = validateNotWeakSecret(encryptionKey, 'ENCRYPTION_KEY');

    if (encryptionMinLengthError) errors.push(encryptionMinLengthError);
    if (encryptionWeakError) errors.push(encryptionWeakError);

    // Valider la rotation des secrets
    if (process.env.SECRETS_LAST_ROTATION) {
        const rotationDays = parseInt(process.env.SECRETS_ROTATION_DAYS || '90');
        const rotationError = validateRotationDate(process.env.SECRETS_LAST_ROTATION, rotationDays);
        if (rotationError) warnings.push(rotationError);
    } else {
        warnings.push('SECRETS_LAST_ROTATION not set. Unable to track secret rotation.');
    }

    // Valider DATABASE_URL (pas de mot de passe simple)
    const dbUrl = process.env.DATABASE_URL!;
    if (dbUrl.includes('password') || dbUrl.includes('123456')) {
        warnings.push('DATABASE_URL appears to contain a weak password');
    }

    return {
        isValid: errors.length === 0,
        errors,
        warnings
    };
}

/**
 * Valide les secrets et log les résultats
 * Lance une erreur fatale si validation échoue
 */
export function validateAndLogSecrets(): void {
    securityLogger.info('[VALIDATION] Starting secrets validation...');

    const result = validateSecrets();

    // Log des warnings
    if (result.warnings.length > 0) {
        result.warnings.forEach(warning => {
            securityLogger.warn(`[VALIDATION] ${warning}`);
        });
    }

    // Log et erreur fatale si échec
    if (!result.isValid) {
        result.errors.forEach(error => {
            securityLogger.error(`[VALIDATION] ${error}`);
        });

        securityLogger.error('[VALIDATION] Secrets validation FAILED. Server startup aborted.');
        throw new Error('Secrets validation failed. Check security.log for details.');
    }

    securityLogger.info('[VALIDATION] Secrets validation PASSED ✅');
}

export default validateSecrets;
