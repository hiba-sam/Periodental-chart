# 🖥️ Configuration NGINX - MyPresc Backend

## 📋 Vue d'ensemble

Configuration NGINX optimisée pour la production avec :
- ✅ TLS 1.2/1.3 uniquement
- ✅ Ciphers modernes (ECDHE + AESGCM/CHACHA20)
- ✅ HSTS avec preload
- ✅ Headers de sécurité complets
- ✅ Rate limiting (API + Auth)
- ✅ Redirection HTTP → HTTPS
- ✅ Support HTTP/2
- ✅ OCSP Stapling

---

## 🚀 Installation

### **1. Copier la configuration**

```bash
sudo cp mypresc.conf /etc/nginx/sites-available/mypresc
sudo ln -s /etc/nginx/sites-available/mypresc /etc/nginx/sites-enabled/
```

### **2. Obtenir un certificat SSL (Let's Encrypt)**

```bash
# Installer certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx

# Obtenir le certificat
sudo certbot --nginx -d mypresc.dz -d www.mypresc.dz -d api.mypresc.dz

# Renouvellement automatique (cron)
sudo certbot renew --dry-run
```

**Paths des certificats** :
- Certificate: `/etc/letsencrypt/live/mypresc.dz/fullchain.pem`
- Private Key: `/etc/letsencrypt/live/mypresc.dz/privkey.pem`
- Chain: `/etc/letsencrypt/live/mypresc.dz/chain.pem`

### **3. Vérifier la configuration**

```bash
# Tester la syntaxe
sudo nginx -t

# Si OK, recharger
sudo systemctl reload nginx

# Vérifier le status
sudo systemctl status nginx
```

---

## 🔧 Configuration du Backend

**Modifier `.env`** :

```env
# S'assurer que le backend écoute uniquement en local
HOST=localhost
PORT=3333

# Activer Force HTTPS
FORCE_HTTPS=true
NODE_ENV=production
```

Le backend sera accessible uniquement via NGINX (reverse proxy).

---

## 🔐 Sécurité TLS

### **Protocols supportés**

- ✅ TLS 1.3 (priorité)
- ✅ TLS 1.2
- ❌ TLS 1.1, TLS 1.0, SSLv3 (désactivés)

### **Ciphers** (ordre de préférence)

1. `ECDHE-ECDSA-AES128-GCM-SHA256`
2. `ECDHE-RSA-AES128-GCM-SHA256`
3. `ECDHE-ECDSA-AES256-GCM-SHA384`
4. `ECDHE-RSA-AES256-GCM-SHA384`
5. `ECDHE-ECDSA-CHACHA20-POLY1305`
6. `ECDHE-RSA-CHACHA20-POLY1305`

**Vérifier avec SSL Labs** :
```
https://www.ssllabs.com/ssltest/analyze.html?d=mypresc.dz
```

Cible : **A+ rating**

---

## 📊 Rate Limiting

| Zone | Route | Limite | Burst |
|------|-------|--------|-------|
| **api** | Toutes | 30 req/min | 20 |
| **auth** | `/auth/login`, `/auth/register` | 5 req/min | 3 |

**Personnalisation** :

```nginx
limit_req_zone $binary_remote_addr zone=api:10m rate=30r/m;
                                                     ↑
                                              Modifier ici
```

---

## 🛡️ Headers de Sécurité

| Header | Valeur | Protection |
|--------|--------|------------|
| **HSTS** | `max-age=31536000; includeSubDomains; preload` | Force HTTPS |
| **X-Content-Type-Options** | `nosniff` | Anti-MIME sniffing |
| **X-Frame-Options** | `DENY` | Anti-clickjacking |
| **X-XSS-Protection** | `1; mode=block` | Anti-XSS (legacy) |
| **CSP** | `default-src 'self'; ...` | Content Security Policy |
| **Referrer-Policy** | `strict-origin-when-cross-origin` | Contrôle referrer |

---

## 📈 Monitoring & Logs

### **Logs d'accès**

```bash
# Voir les logs en temps réel
sudo tail -f /var/log/nginx/mypresc_access.log

# Filtrer les erreurs 4xx/5xx
sudo tail -f /var/log/nginx/mypresc_access.log | grep -E ' (4|5)[0-9]{2} '

# Top 10 IPs
sudo awk '{print $1}' /var/log/nginx/mypresc_access.log | sort | uniq -c | sort -rn | head -10
```

### **Logs d'erreur**

```bash
sudo tail -f /var/log/nginx/mypresc_error.log
```

### **Statistiques**

```bash
# Requêtes par code status
sudo awk '{print $9}' /var/log/nginx/mypresc_access.log | sort | uniq -c | sort -rn

# User-Agents bloqués
sudo grep ' 403 ' /var/log/nginx/mypresc_access.log | awk -F'"' '{print $6}' | sort | uniq -c | sort -rn
```

---

## 🧪 Tests

### **Test HTTPS Redirect**

```bash
curl -I http://mypresc.dz
# Attendu : HTTP/1.1 301 Moved Permanently
# Location: https://mypresc.dz/
```

### **Test TLS**

```bash
# Vérifier TLS 1.3
openssl s_client -connect mypresc.dz:443 -tls1_3

# Vérifier les ciphers
nmap --script ssl-enum-ciphers -p 443 mypresc.dz
```

### **Test Headers**

```bash
curl -I https://mypresc.dz
# Vérifier présence de HSTS, CSP, etc.
```

### **Test Rate Limiting**

```bash
# Spam de requêtes (doit être bloqué après 30)
for i in {1..50}; do
    curl -s -o /dev/null -w "%{http_code}\n" https://mypresc.dz/api/test
done
# Attendu : 200...200, 503, 503 (rate limit hit)
```

---

## 🔧 Optimisations Avancées

### **1. Enable HTTP/2 Server Push** (optionnel)

```nginx
location / {
    http2_push /static/app.js;
    http2_push /static/app.css;
    ...
}
```

### **2. Caching statique**

```nginx
location ~* \.(jpg|jpeg|png|gif|ico|css|js|woff2)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### **3. Compression gzip**

```nginx
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml;
```

### **4. Installer ModSecurity (WAF NGINX)**

```bash
sudo apt install libnginx-mod-security2

# Télécharger OWASP CRS
cd /etc/nginx
sudo git clone https://github.com/coreruleset/coreruleset.git modsec-crs
cd modsec-crs
sudo cp crs-setup.conf.example crs-setup.conf

# Activer dans nginx.conf
modsecurity on;
modsecurity_rules_file /etc/nginx/modsec/main.conf;
```

---

## ⚠️ Troubleshooting

### **Erreur : "could not build optimal types_hash"**

```nginx
http {
    types_hash_max_size 2048;
    types_hash_bucket_size 64;
    ...
}
```

### **Erreur : "upstream timed out"**

```nginx
proxy_connect_timeout 120s;
proxy_send_timeout 120s;
proxy_read_timeout 120s;
```

### **Erreur : "413 Request Entity Too Large"**

```nginx
client_max_body_size 20m;  # Augmenter si besoin
```

### **Rate limiting trop strict**

```nginx
# Augmenter la limite ou le burst
limit_req_zone $binary_remote_addr zone=api:10m rate=60r/m;
limit_req zone=api burst=40 nodelay;
```

---

## 📚 Références

- [NGINX Security Best Practices](https://www.nginx.com/blog/nginx-security-best-practices/)
- [Mozilla SSL Configuration Generator](https://ssl-config.mozilla.org/)
- [OWASP ModSecurity Core Rule Set](https://coreruleset.org/)
- [Let's Encrypt Documentation](https://letsencrypt.org/docs/)

---

## 📝 Checklist de Déploiement

- [ ] Certificat SSL installé et valide
- [ ] HSTS activé (`Strict-Transport-Security` header)
- [ ] TLS 1.2/1.3 uniquement
- [ ] Redirection HTTP → HTTPS active
- [ ] Rate limiting configuré
- [ ] Headers de sécurité présents
- [ ] Logs fonctionnels (`/var/log/nginx/`)
- [ ] Test SSL Labs → A+ rating
- [ ] Backend accessible uniquement via localhost
- [ ] Firewall configuré (UFW/iptables)
- [ ] Monitoring actif (Prometheus/Grafana ou équivalent)

---

**Dernière mise à jour** : 2025-10-15  
**Version NGINX minimale** : 1.18+  
**OS recommandé** : Ubuntu 22.04 LTS / Debian 11+
